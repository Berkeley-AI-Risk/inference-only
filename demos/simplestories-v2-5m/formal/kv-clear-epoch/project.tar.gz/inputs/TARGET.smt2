; Readable target only. No assumptions, solver submission or theorem is asserted.
; Load native/native.smt2, MESSAGE.smt2, NATIVE-VIEW.smt2 and NATIVE-HISTORY.smt2.
; ReadSnapshot must be constructed at actual read admission by the independent
; legitimate-write reference. Its implementation correspondence is OPEN.
(declare-datatype ReadSnapshot ((read-snapshot
 (read-owned Bool) (read-id Int) (read-generation Int) (read-cancelled Bool)
 (read-legal Bool) (read-layer (_ BitVec 3)) (read-position (_ BitVec 12))
 (read-head (_ BitVec 2)) (read-word (_ BitVec 4)) (read-record Int)
 (read-expected (_ BitVec 256)))))
(define-fun Target-live-read
 ((a |board1_kv_integrity_guard_s|) (h OriginHistory) (r ReadSnapshot)) Bool
 (=> (v-live-response a)
  (and (read-owned r) (read-legal r) (not (read-cancelled r))
   (= (read-id r) (g-owner h)) (= (read-generation r) (g-generation h))
   (< 0 (read-record r))
   (= (read-layer r) (|board1_kv_integrity_guard_n layer_q| a))
   (= ((_ extract 10 4) (read-position r)) (|board1_kv_integrity_guard_n page_q| a))
   (= (read-head r) (ite (|board1_kv_integrity_guard_n group_head_q| a) #b01 #b00))
   (= (|board1_kv_integrity_guard_n target_slot_q| a)
    (bvadd (bvmul ((_ zero_extend 3) ((_ extract 3 0) (read-position r))) (_ bv5 7))
     (ite (= (read-word r) (_ bv8 4)) (_ bv4 7)
      ((_ zero_extend 5) ((_ extract 1 0) (read-word r))))))
   (=> (distinct (read-word r) (_ bv8 4))
    (= (= ((_ extract 2 2) (read-word r)) #b1)
     (|board1_kv_integrity_guard_n role_q| a)))
   (= (|board1_kv_integrity_guard_n s_rd_rsp_data| a) (read-expected r)))))
(define-fun Target-cancelled-drain-mask
 ((a |board1_kv_integrity_guard_s|)) Bool
 (=> (v-cancelled-drain a)
  (= (|board1_kv_integrity_guard_n s_rd_rsp_data| a) (_ bv0 256))))
; Cancellation must additionally retain the original ticket until its actual
; retirement and the real parent must discard that ticket. Zero data alone
; proves neither property, and a zero-valued legitimate read can be successful.

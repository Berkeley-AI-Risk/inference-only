; Explicit relevant completed-message cryptographic premise, separated from induction.
; It is not a global finite-hash injectivity axiom or a desired private reply.
(define-fun actual-cache-pair-no-substitution ((h OriginHistory) (q ReadOriginState)) Bool
 (=> (and (q-cache-valid q) (cc-watched (q-cache q))) (relevant-no-substitution (origin-message (select (g-origins h) (cc-tag-origin (q-cache q)))) (origin-message (select (g-origins h) (cc-read-origin (q-cache q)))) (origin-digest (select (g-origins h) (cc-tag-origin (q-cache q)))) (origin-digest (select (g-origins h) (cc-read-origin (q-cache q)))))))
(define-fun original-owned-read-snapshot ((r LegitimateState)) ReadSnapshot
 (read-snapshot (r-owner-live r) (la-id (r-owner r)) (la-generation (r-owner r)) (r-owner-cancelled r) (and (la-legal (r-owner r)) (not (la-write (r-owner r)))) (d-layer (la-descriptor (r-owner r))) (d-position (la-descriptor (r-owner r))) (d-head (la-descriptor (r-owner r))) (d-word (la-descriptor (r-owner r))) (la-record (r-owner r)) (la-value (r-owner r))))
(define-fun local-read-integrity-target ((a |board1_kv_integrity_guard_s|) (h OriginHistory) (r LegitimateState) (watched-key (_ BitVec 12))) Bool
 (=> (= watched-key (v-key a)) (Target-live-read a h (original-owned-read-snapshot r))))

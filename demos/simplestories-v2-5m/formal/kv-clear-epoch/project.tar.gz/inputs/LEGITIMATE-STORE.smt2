; Independent normative store: admissions and upper retirements only.
; No lower DDR data, hash digest or desired returned word updates this state.
(declare-datatype LogicalDescriptor ((logical-descriptor
 (d-layer (_ BitVec 3))
 (d-position (_ BitVec 12))
 (d-head (_ BitVec 2))
 (d-word (_ BitVec 4))
 (d-shadow (_ BitVec 19)))))
(declare-datatype LegitimateRecord ((legitimate-record
 (lr-valid Bool)
 (lr-id Int)
 (lr-generation Int)
 (lr-layer (_ BitVec 3))
 (lr-position (_ BitVec 12))
 (lr-words (Array (_ BitVec 5) (_ BitVec 256)))
 (lr-admissions (Array (_ BitVec 5) Int)))))
(declare-datatype LegitimateAdmission ((legitimate-admission
 (la-valid Bool)
 (la-id Int)
 (la-generation Int)
 (la-write Bool)
 (la-legal Bool)
 (la-descriptor LogicalDescriptor)
 (la-record Int)
 (la-value (_ BitVec 256)))))
(declare-datatype LegitimateState ((legitimate-state
 (r-generation Int)
 (r-clear-seen Bool)
 (r-terminal Bool)
 (r-edge Int)
 (r-next-ticket Int)
 (r-next-record Int)
 (r-owner-live Bool)
 (r-owner-cancelled Bool)
 (r-owner LegitimateAdmission)
 (r-builder-active Bool)
 (r-builder-id Int)
 (r-builder-layer (_ BitVec 3))
 (r-builder-position (_ BitVec 12))
 (r-builder-next (_ BitVec 5))
 (r-builder-words (Array (_ BitVec 5) (_ BitVec 256)))
 (r-builder-admissions (Array (_ BitVec 5) Int))
 (r-prefix (Array (_ BitVec 3) (_ BitVec 12)))
 (r-current (Array (_ BitVec 15) Int))
 (r-records (Array Int LegitimateRecord))
 (r-admissions (Array Int LegitimateAdmission))
 (r-bad Bool))))
(define-fun zero-descriptor () LogicalDescriptor
 (logical-descriptor (_ bv0 3) (_ bv0 12) (_ bv0 2) (_ bv0 4) (_ bv0 19)))
(define-fun zero-record () LegitimateRecord
 (legitimate-record false 0 0 (_ bv0 3) (_ bv0 12) ((as const (Array (_ BitVec 5) (_ BitVec 256))) (_ bv0 256)) ((as const (Array (_ BitVec 5) Int)) 0)))
(define-fun zero-admission () LegitimateAdmission
 (legitimate-admission false 0 0 false false zero-descriptor 0 (_ bv0 256)))
(define-fun legitimate-zero () LegitimateState
 (legitimate-state 0 false false 0 1 1 false false zero-admission false 0 (_ bv0 3) (_ bv0 12) (_ bv0 5) ((as const (Array (_ BitVec 5) (_ BitVec 256))) (_ bv0 256)) ((as const (Array (_ BitVec 5) Int)) 0) ((as const (Array (_ BitVec 3) (_ BitVec 12))) (_ bv0 12)) ((as const (Array (_ BitVec 15) Int)) 0) ((as const (Array Int LegitimateRecord)) zero-record) ((as const (Array Int LegitimateAdmission)) zero-admission) false))
(define-fun logical-key ((d LogicalDescriptor)) (_ BitVec 15)
 (concat (d-layer d) (d-position d)))
(define-fun logical-ordinal ((d LogicalDescriptor)) (_ BitVec 5)
 (bvadd ((_ zero_extend 1) (d-word d)) (ite (= (d-head d) (_ bv1 2)) (_ bv9 5) (_ bv0 5))))
(define-fun logical-address ((d LogicalDescriptor)) (_ BitVec 19)
 (bvadd (_ bv227072 19) (bvadd (bvmul (bvadd (bvmul (bvadd (bvmul ((_ zero_extend 16) (d-layer d)) (_ bv2048 19)) ((_ zero_extend 7) (d-position d))) (_ bv2 19)) ((_ zero_extend 17) (d-head d))) (_ bv9 19)) ((_ zero_extend 15) (d-word d)))))
(define-fun logical-shape ((d LogicalDescriptor)) Bool
 (and (bvult (d-layer d) (_ bv6 3)) (bvult (d-position d) (_ bv2048 12)) (bvult (d-head d) (_ bv2 2)) (bvult (d-word d) (_ bv9 4)) (= (d-shadow d) (logical-address d))))
(define-fun native-write-descriptor ((a |board1_kv_integrity_guard_s|)) LogicalDescriptor
 (logical-descriptor (|board1_kv_integrity_guard_n s_wr_layer| a) (|board1_kv_integrity_guard_n s_wr_position| a) (|board1_kv_integrity_guard_n s_wr_head| a) (|board1_kv_integrity_guard_n s_wr_word| a) (|board1_kv_integrity_guard_n s_wr_shadow| a)))
(define-fun native-read-descriptor ((a |board1_kv_integrity_guard_s|)) LogicalDescriptor
 (logical-descriptor (|board1_kv_integrity_guard_n s_rd_layer| a) (|board1_kv_integrity_guard_n s_rd_position| a) (|board1_kv_integrity_guard_n s_rd_head| a) (|board1_kv_integrity_guard_n s_rd_word| a) (|board1_kv_integrity_guard_n s_rd_shadow| a)))
(define-fun legitimate-write-legal ((r LegitimateState) (d LogicalDescriptor)) Bool
 (and (logical-shape d) (ite (r-builder-active r) (and (= (d-layer d) (r-builder-layer r)) (= (d-position d) (r-builder-position r)) (= (logical-ordinal d) (r-builder-next r))) (and (= (d-head d) (_ bv0 2)) (= (d-word d) (_ bv0 4)) (= (d-position d) (select (r-prefix r) (d-layer d)))))))
(define-fun legitimate-read-legal ((r LegitimateState) (d LogicalDescriptor)) Bool
 (and (logical-shape d) (not (r-builder-active r)) (bvult (d-position d) (select (r-prefix r) (d-layer d))) (lr-valid (select (r-records r) (select (r-current r) (logical-key d)))) (= (lr-generation (select (r-records r) (select (r-current r) (logical-key d)))) (r-generation r)) (= (lr-layer (select (r-records r) (select (r-current r) (logical-key d)))) (d-layer d)) (= (lr-position (select (r-records r) (select (r-current r) (logical-key d)))) (d-position d))))
(define-fun legitimate-environment ((a |board1_kv_integrity_guard_s|) (r LegitimateState)) LegitimateState
 (legitimate-state (+ (r-generation r) (ite (and (|board1_kv_integrity_guard_n clear_i| a) (not (r-clear-seen r))) 1 0)) (|board1_kv_integrity_guard_n clear_i| a) (or (r-terminal r) (|board1_kv_integrity_guard_n terminal_now| a)) (r-edge r) (r-next-ticket r) (r-next-record r) (r-owner-live r) (and (r-owner-live r) (or (r-owner-cancelled r) (|board1_kv_integrity_guard_n clear_i| a) (|board1_kv_integrity_guard_n terminal_now| a))) (r-owner r) (ite (|board1_kv_integrity_guard_n clear_i| a) false (r-builder-active r)) (r-builder-id r) (r-builder-layer r) (r-builder-position r) (ite (|board1_kv_integrity_guard_n clear_i| a) (_ bv0 5) (r-builder-next r)) (r-builder-words r) (r-builder-admissions r) (ite (|board1_kv_integrity_guard_n clear_i| a) ((as const (Array (_ BitVec 3) (_ BitVec 12))) (_ bv0 12)) (r-prefix r)) (r-current r) (r-records r) (r-admissions r) (r-bad r)))
(define-fun legitimate-retirement ((a |board1_kv_integrity_guard_s|) (r LegitimateState)) LegitimateState
 (legitimate-state (r-generation r) (r-clear-seen r) (r-terminal r) (r-edge r) (r-next-ticket r) (r-next-record r) (ite (or (v-write-retire a) (v-read-retire a)) false (r-owner-live r)) (r-owner-cancelled r) (r-owner r) (ite (and (v-write-retire a) (and (r-owner-live r) (la-legal (r-owner r)) (not (r-owner-cancelled r)) (not (r-terminal r)) (not (|board1_kv_integrity_guard_n clear_i| a)) (not (|board1_kv_integrity_guard_n terminal_now| a)) (not (|board1_kv_integrity_guard_n s_wr_cpl_fault| a))) (la-write (r-owner r)) (and (r-builder-active r) (= (r-builder-id r) (la-record (r-owner r))) (= (r-builder-next r) (logical-ordinal (la-descriptor (r-owner r))))) (= (logical-ordinal (la-descriptor (r-owner r))) (_ bv17 5)) (lr-valid (select (r-records r) (la-record (r-owner r))))) false (r-builder-active r)) (r-builder-id r) (r-builder-layer r) (r-builder-position r) (ite (and (v-write-retire a) (and (r-owner-live r) (la-legal (r-owner r)) (not (r-owner-cancelled r)) (not (r-terminal r)) (not (|board1_kv_integrity_guard_n clear_i| a)) (not (|board1_kv_integrity_guard_n terminal_now| a)) (not (|board1_kv_integrity_guard_n s_wr_cpl_fault| a))) (la-write (r-owner r)) (and (r-builder-active r) (= (r-builder-id r) (la-record (r-owner r))) (= (r-builder-next r) (logical-ordinal (la-descriptor (r-owner r))))) (not (= (logical-ordinal (la-descriptor (r-owner r))) (_ bv17 5)))) (bvadd (r-builder-next r) (_ bv1 5)) (r-builder-next r)) (r-builder-words r) (r-builder-admissions r) (ite (and (v-write-retire a) (and (r-owner-live r) (la-legal (r-owner r)) (not (r-owner-cancelled r)) (not (r-terminal r)) (not (|board1_kv_integrity_guard_n clear_i| a)) (not (|board1_kv_integrity_guard_n terminal_now| a)) (not (|board1_kv_integrity_guard_n s_wr_cpl_fault| a))) (la-write (r-owner r)) (and (r-builder-active r) (= (r-builder-id r) (la-record (r-owner r))) (= (r-builder-next r) (logical-ordinal (la-descriptor (r-owner r))))) (= (logical-ordinal (la-descriptor (r-owner r))) (_ bv17 5)) (lr-valid (select (r-records r) (la-record (r-owner r))))) (store (r-prefix r) (d-layer (la-descriptor (r-owner r))) (bvadd (select (r-prefix r) (d-layer (la-descriptor (r-owner r)))) (_ bv1 12))) (r-prefix r)) (ite (and (v-write-retire a) (and (r-owner-live r) (la-legal (r-owner r)) (not (r-owner-cancelled r)) (not (r-terminal r)) (not (|board1_kv_integrity_guard_n clear_i| a)) (not (|board1_kv_integrity_guard_n terminal_now| a)) (not (|board1_kv_integrity_guard_n s_wr_cpl_fault| a))) (la-write (r-owner r)) (and (r-builder-active r) (= (r-builder-id r) (la-record (r-owner r))) (= (r-builder-next r) (logical-ordinal (la-descriptor (r-owner r))))) (= (logical-ordinal (la-descriptor (r-owner r))) (_ bv17 5)) (lr-valid (select (r-records r) (la-record (r-owner r))))) (store (r-current r) (logical-key (la-descriptor (r-owner r))) (la-record (r-owner r))) (r-current r)) (r-records r) (r-admissions r) (or (r-bad r) (or (and (or (v-write-retire a) (v-read-retire a)) (or (not (r-owner-live r)) (not (= (v-write-retire a) (la-write (r-owner r)))) (and (v-write-retire a) (v-read-retire a)))) (and (v-write-retire a) (and (r-owner-live r) (la-legal (r-owner r)) (not (r-owner-cancelled r)) (not (r-terminal r)) (not (|board1_kv_integrity_guard_n clear_i| a)) (not (|board1_kv_integrity_guard_n terminal_now| a)) (not (|board1_kv_integrity_guard_n s_wr_cpl_fault| a))) (la-write (r-owner r)) (or (not (and (r-builder-active r) (= (r-builder-id r) (la-record (r-owner r))) (= (r-builder-next r) (logical-ordinal (la-descriptor (r-owner r)))))) (and (= (logical-ordinal (la-descriptor (r-owner r))) (_ bv17 5)) (not (lr-valid (select (r-records r) (la-record (r-owner r))))))))))))
(define-fun legitimate-admission-step ((a |board1_kv_integrity_guard_s|) (r LegitimateState) (had-owner Bool)) LegitimateState
 (let ((wf (|board1_kv_integrity_guard_n write_fire| a))) (let ((rf (|board1_kv_integrity_guard_n read_fire| a))) (let ((attempt (or wf rf))) (let ((admit (and attempt (not had-owner) (not (and wf rf)) (not (|board1_kv_integrity_guard_n clear_i| a)) (not (|board1_kv_integrity_guard_n terminal_now| a)) (not (r-terminal r))))) (let ((d (ite wf (native-write-descriptor a) (native-read-descriptor a)))) (let ((legal (ite wf (legitimate-write-legal r d) (legitimate-read-legal r d)))) (let ((new-builder (and admit wf legal (not (r-builder-active r))))) (let ((rid (ite wf (ite legal (ite new-builder (r-next-record r) (r-builder-id r)) 0) (ite legal (select (r-current r) (logical-key d)) 0)))) (let ((v (ite wf (|board1_kv_integrity_guard_n s_wr_data| a) (ite legal (select (lr-words (select (r-records r) rid)) (logical-ordinal d)) (_ bv0 256))))) (let ((w (store (ite new-builder ((as const (Array (_ BitVec 5) (_ BitVec 256))) (_ bv0 256)) (r-builder-words r)) (logical-ordinal d) v))) (let ((ids (store (ite new-builder ((as const (Array (_ BitVec 5) Int)) 0) (r-builder-admissions r)) (logical-ordinal d) (r-next-ticket r)))) (let ((ticket (legitimate-admission true (r-next-ticket r) (r-generation r) wf legal d rid v))) (legitimate-state (r-generation r) (r-clear-seen r) (r-terminal r) (r-edge r) (ite admit (+ (r-next-ticket r) 1) (r-next-ticket r)) (ite new-builder (+ (r-next-record r) 1) (r-next-record r)) (ite admit true (r-owner-live r)) (ite admit false (r-owner-cancelled r)) (ite admit ticket (r-owner r)) (ite (and admit wf legal) true (r-builder-active r)) (ite new-builder rid (r-builder-id r)) (ite new-builder (d-layer d) (r-builder-layer r)) (ite new-builder (d-position d) (r-builder-position r)) (ite new-builder (_ bv0 5) (r-builder-next r)) (ite (and admit wf legal) w (r-builder-words r)) (ite (and admit wf legal) ids (r-builder-admissions r)) (r-prefix r) (r-current r) (ite (and admit wf legal (= (logical-ordinal d) (_ bv17 5))) (store (r-records r) rid (legitimate-record true rid (r-generation r) (d-layer d) (d-position d) w ids)) (r-records r)) (ite admit (store (r-admissions r) (r-next-ticket r) ticket) (r-admissions r)) (or (r-bad r) (and attempt (not admit)))))))))))))))))
(define-fun legitimate-next ((a |board1_kv_integrity_guard_s|) (b |board1_kv_integrity_guard_s|) (r LegitimateState)) LegitimateState
 (ite (or (not (|board1_kv_integrity_guard_n reset_n| a)) (not (|board1_kv_integrity_guard_n reset_n| b))) legitimate-zero (let ((advanced (legitimate-admission-step a (legitimate-retirement a (legitimate-environment a r)) (r-owner-live r)))) (legitimate-state (r-generation advanced) (r-clear-seen advanced) (r-terminal advanced) (+ (r-edge r) 1) (r-next-ticket advanced) (r-next-record advanced) (r-owner-live advanced) (r-owner-cancelled advanced) (r-owner advanced) (r-builder-active advanced) (r-builder-id advanced) (r-builder-layer advanced) (r-builder-position advanced) (r-builder-next advanced) (r-builder-words advanced) (r-builder-admissions advanced) (r-prefix advanced) (r-current advanced) (r-records advanced) (r-admissions advanced) (r-bad advanced)))))

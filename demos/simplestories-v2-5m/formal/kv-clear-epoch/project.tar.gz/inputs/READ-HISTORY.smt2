; Total read-only histories. Stage values come from actual arbitrary lower replies.
; No legitimate expected value or cryptographic premise drives the circuit/history.
(declare-datatype StageJob ((stage-job
 (sj-valid Bool)
 (sj-hash Int)
 (sj-owner Int)
 (sj-generation Int)
 (sj-stage Int)
 (sj-message KVMessage))))
(declare-datatype CacheCertificate ((cache-certificate
 (cc-valid Bool)
 (cc-tag-origin Int)
 (cc-read-origin Int)
 (cc-hash Int)
 (cc-owner Int)
 (cc-generation Int)
 (cc-stage Int)
 (cc-key (_ BitVec 12))
 (cc-positions (_ BitVec 5))
 (cc-watched Bool))))
(declare-datatype ReadOriginState ((read-origin-state
 (q-next-stage Int)
 (q-stage-active Bool)
 (q-stage-id Int)
 (q-stage-owner Int)
 (q-stage-generation Int)
 (q-stage-key (_ BitVec 12))
 (q-stage-positions (_ BitVec 5))
 (q-stage-values (Array (_ BitVec 7) (_ BitVec 256)))
 (q-stage-masks (Array (_ BitVec 7) (_ BitVec 8)))
 (q-lower-seen Bool)
 (q-lower-slot (_ BitVec 7))
 (q-lower-owner Int)
 (q-lower-value (_ BitVec 256))
 (q-read-seen Bool)
 (q-read-slot (_ BitVec 7))
 (q-read-chunk (_ BitVec 3))
 (q-read-stage Int)
 (q-read-value (_ BitVec 32))
 (q-jobs (Array Int StageJob))
 (q-cache-valid Bool)
 (q-cache CacheCertificate))))
(define-fun zero-stage-job () StageJob
 (stage-job false 0 0 0 0 empty-message))
(define-fun zero-cache-certificate () CacheCertificate
 (cache-certificate false 0 0 0 0 0 0 (_ bv0 12) (_ bv0 5) false))
(define-fun read-origin-zero () ReadOriginState
 (read-origin-state 1 false 0 0 0 (_ bv0 12) (_ bv0 5) ((as const (Array (_ BitVec 7) (_ BitVec 256))) (_ bv0 256)) ((as const (Array (_ BitVec 7) (_ BitVec 8))) (_ bv0 8)) false (_ bv0 7) 0 (_ bv0 256) false (_ bv0 7) (_ bv0 3) 0 (_ bv0 32) ((as const (Array Int StageJob)) zero-stage-job) false zero-cache-certificate))
(define-fun actual-read-miss ((a |board1_kv_integrity_guard_s|)) Bool
 (and (|board1_kv_integrity_guard_n read_fire| a) (|board1_kv_integrity_guard_n rd_legal| a) (not (|board1_kv_integrity_guard_n cache_hit| a))))
(define-fun actual-stage-reply ((a |board1_kv_integrity_guard_s|)) Bool
 (and (|board1_kv_integrity_guard_n live| a) (= (|board1_kv_integrity_guard_n state_q| a) (_ bv6 5)) (|board1_kv_integrity_guard_n m_rd_rsp_valid| a)))
(define-fun actual-stage-write ((a |board1_kv_integrity_guard_s|)) Bool
 (and (|board1_kv_integrity_guard_n live| a) (= (|board1_kv_integrity_guard_n state_q| a) (_ bv7 5))))
(define-fun actual-stage-read ((a |board1_kv_integrity_guard_s|)) Bool
 (and (|board1_kv_integrity_guard_n live| a) (or (and (= (|board1_kv_integrity_guard_n state_q| a) (_ bv11 5)) (not (|board1_kv_integrity_guard_n hash_write_q| a))) (= (|board1_kv_integrity_guard_n state_q| a) (_ bv16 5)))))
(define-fun actual-read-hash-begin ((a |board1_kv_integrity_guard_s|)) Bool
 (and (v-hash-begin a) (not (|board1_kv_integrity_guard_n hash_write_q| a))))
(define-fun actual-cache-verify ((a |board1_kv_integrity_guard_s|)) Bool
 (and (|board1_kv_integrity_guard_n live| a) (= (|board1_kv_integrity_guard_n owner_q| a) (_ bv2 2)) (= (|board1_kv_integrity_guard_n state_q| a) (_ bv14 5)) (not (|board1_kv_integrity_guard_n hash_write_q| a)) (|board1_kv_integrity_guard_n hash_digest_valid| a) (= (|board1_kv_integrity_guard_n hash_digest| a) (|board1_kv_integrity_guard_n expected_q| a))))
(define-fun stage-job-at-begin ((a |board1_kv_integrity_guard_s|) (h OriginHistory) (r LegitimateState) (q ReadOriginState)) StageJob
 (stage-job true (g-next-hash h) (la-id (r-owner r)) (r-generation r) (q-stage-id q) (kv-message (v-hash-header a) (page-word-count (|board1_kv_integrity_guard_n positions_q| a)) (q-stage-values q))))
(define-fun certificate-at-verification ((a |board1_kv_integrity_guard_s|) (h OriginHistory) (r LegitimateState) (q ReadOriginState) (watched-key (_ BitVec 12))) CacheCertificate
 (cache-certificate true (ite (= (v-key a) watched-key) (g-selected h) 0) (g-next-origin h) (g-hash-id h) (la-id (r-owner r)) (r-generation r) (q-stage-id q) (v-key a) (|board1_kv_integrity_guard_n positions_q| a) (= (v-key a) watched-key)))
(define-fun read-origin-next ((a |board1_kv_integrity_guard_s|) (b |board1_kv_integrity_guard_s|) (h OriginHistory) (r LegitimateState) (q ReadOriginState) (watched-key (_ BitVec 12))) ReadOriginState
 (ite (or (not (|board1_kv_integrity_guard_n reset_n| a)) (not (|board1_kv_integrity_guard_n reset_n| b))) read-origin-zero (let ((incoming (native-read-descriptor a))) (read-origin-state (ite (actual-read-miss a) (+ (q-next-stage q) 1) (q-next-stage q)) (ite (or (|board1_kv_integrity_guard_n clear_i| a) (|board1_kv_integrity_guard_n terminal_now| a) (|board1_kv_integrity_guard_n write_fire| a) (actual-read-miss a)) (actual-read-miss a) (q-stage-active q)) (ite (actual-read-miss a) (q-next-stage q) (q-stage-id q)) (ite (actual-read-miss a) (r-next-ticket r) (q-stage-owner q)) (ite (actual-read-miss a) (r-generation r) (q-stage-generation q)) (ite (actual-read-miss a) (concat (d-layer incoming) (concat ((_ extract 10 4) (d-position incoming)) (concat ((_ extract 0 0) (d-head incoming)) (ite (|board1_kv_integrity_guard_n read_role| a) (_ bv1 1) (_ bv0 1))))) (q-stage-key q)) (ite (actual-read-miss a) (|board1_kv_integrity_guard_n read_positions| a) (q-stage-positions q)) (ite (actual-stage-reply a) (store (q-stage-values q) (|board1_kv_integrity_guard_n scan_slot_q| a) (|board1_kv_integrity_guard_n m_rd_rsp_data| a)) (q-stage-values q)) (ite (or (|board1_kv_integrity_guard_n clear_i| a) (|board1_kv_integrity_guard_n terminal_now| a) (|board1_kv_integrity_guard_n write_fire| a) (actual-read-miss a)) ((as const (Array (_ BitVec 7) (_ BitVec 8))) (_ bv0 8)) (ite (actual-stage-write a) (store (q-stage-masks q) (|board1_kv_integrity_guard_n scan_slot_q| a) (bvor (select (q-stage-masks q) (|board1_kv_integrity_guard_n scan_slot_q| a)) (bvshl (_ bv1 8) ((_ zero_extend 5) (|board1_kv_integrity_guard_n chunk_q| a))))) (q-stage-masks q))) (ite (or (|board1_kv_integrity_guard_n clear_i| a) (|board1_kv_integrity_guard_n terminal_now| a) (|board1_kv_integrity_guard_n write_fire| a) (actual-read-miss a)) false (ite (actual-stage-reply a) true (q-lower-seen q))) (ite (actual-stage-reply a) (|board1_kv_integrity_guard_n scan_slot_q| a) (q-lower-slot q)) (ite (actual-stage-reply a) (la-id (r-owner r)) (q-lower-owner q)) (ite (actual-stage-reply a) (|board1_kv_integrity_guard_n m_rd_rsp_data| a) (q-lower-value q)) (ite (or (|board1_kv_integrity_guard_n clear_i| a) (|board1_kv_integrity_guard_n terminal_now| a) (|board1_kv_integrity_guard_n write_fire| a) (actual-read-miss a)) false (ite (actual-stage-read a) true (q-read-seen q))) (ite (actual-stage-read a) (|board1_kv_integrity_guard_n stage_slot| a) (q-read-slot q)) (ite (actual-stage-read a) (|board1_kv_integrity_guard_n chunk_q| a) (q-read-chunk q)) (ite (actual-stage-read a) (q-stage-id q) (q-read-stage q)) (ite (actual-stage-read a) (word-chunk (select (q-stage-values q) (|board1_kv_integrity_guard_n stage_slot| a)) (|board1_kv_integrity_guard_n chunk_q| a)) (q-read-value q)) (ite (actual-read-hash-begin a) (store (q-jobs q) (g-next-hash h) (stage-job-at-begin a h r q)) (q-jobs q)) (ite (or (|board1_kv_integrity_guard_n clear_i| a) (|board1_kv_integrity_guard_n terminal_now| a) (|board1_kv_integrity_guard_n write_fire| a) (actual-read-miss a)) false (ite (actual-cache-verify a) true (q-cache-valid q))) (ite (actual-cache-verify a) (certificate-at-verification a h r q watched-key) (q-cache q))))))

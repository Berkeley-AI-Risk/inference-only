"""Engine-free sort checker for the explicit SMT subset used by this packet.

Native Yosys function signatures are imported from the pinned model; their
bodies are not reverified here. Custom definitions and every generated query
assertion are checked. This is neither an SMT solver nor a proof checker.
"""
import re


def parse(text):
    tokens = re.findall(r';[^\n]*|\|[^|]*\||"(?:[^"]|"")*"|[()]|[^()\s;]+', text)
    stack, out = [], []
    for token in tokens:
        if token.startswith(";"):
            continue
        if token == "(":
            stack.append([])
        elif token == ")":
            if not stack:
                raise ValueError("Unbalanced closing parenthesis")
            form = stack.pop()
            (stack[-1] if stack else out).append(form)
        else:
            if not stack:
                raise ValueError("Unexpected top-level atom")
            stack[-1].append(token)
    if stack:
        raise ValueError("Unbalanced open parenthesis")
    return out


def sort(x):
    if isinstance(x, str):
        return x
    if x[:2] == ["_", "BitVec"] and len(x) == 3:
        assert int(x[2]) > 0
        return "BV", int(x[2])
    if len(x) == 3 and x[0] == "Array":
        return "Array", sort(x[1]), sort(x[2])
    raise ValueError("Unsupported sort " + str(x))


class Checker:
    def __init__(self):
        self.functions = {}
        self.definitions = {}
        self.constructors = {}
        self.selectors = {}
        self.checked = 0
        self.native_signatures = 0

    def load(self, forms, native=False):
        for f in forms:
            kind = f[0]
            if kind in ["set-option", "set-logic", "check-sat", "get-model", "exit", "declare-sort"]:
                continue
            if kind == "declare-datatype":
                name = f[1]
                for c in f[2]:
                    self.functions[c[0]] = tuple(sort(v[1]) for v in c[1:]), name
                    self.constructors[c[0]] = (name, tuple(v[0] for v in c[1:]))
                    for i, (selector, result) in enumerate(c[1:]):
                        self.functions[selector] = (name,), sort(result)
                        self.selectors[selector] = c[0], i
            elif kind in ["declare-fun", "declare-const"]:
                self.functions[f[1]] = (tuple(sort(a) for a in f[2]), sort(f[3])) if kind == "declare-fun" else ((), sort(f[2]))
            elif kind == "define-fun":
                assert len(f) == 5
                args = {name: sort(s) for name, s in f[2]}
                result = sort(f[3])
                # Definitions in this packet are nonrecursive and ordered.
                if not native:
                    actual = self.infer(f[4], args)
                    if actual != result:
                        raise ValueError(f"Result sort {f[1]}: {actual} != {result}")
                    self.checked += 1
                else:
                    self.native_signatures += 1
                self.functions[f[1]] = tuple(args.values()), result
                self.definitions[f[1]] = f[2], f[4]
            elif kind == "assert":
                assert self.infer(f[1], {}) == "Bool"
                self.checked += 1
            else:
                raise ValueError("Unsupported command " + str(kind))

    def infer(self, x, env):
        if isinstance(x, str):
            if x in env:
                return env[x]
            if x in ["true", "false"]:
                return "Bool"
            if re.fullmatch(r"[0-9]+", x):
                return "Int"
            if x.startswith("#x"):
                return "BV", 4 * len(x[2:])
            if x.startswith("#b"):
                return "BV", len(x[2:])
            if x in self.functions and not self.functions[x][0]:
                return self.functions[x][1]
            raise ValueError("Unbound atom " + x)
        op = x[0]
        if op == "_":
            assert len(x) == 3 and x[1].startswith("bv")
            assert 0 <= int(x[1][2:]) < 1 << int(x[2])
            return "BV", int(x[2])
        if isinstance(op, list):
            if op[:2] == ["as", "const"]:
                a = sort(op[2]);assert a[0] == "Array" and len(x) == 2
                assert self.infer(x[1], env) == a[2]
                return a
            assert op[0] == "_" and len(x) == 2
            a = self.infer(x[1], env)
            if op[1] == "int_to_bv":
                assert a == "Int"
                return "BV", int(op[2])
            assert a[0] == "BV"
            if op[1] in ["zero_extend", "sign_extend"]:
                return "BV", a[1] + int(op[2])
            if op[1] == "extract":
                hi, lo = map(int, op[2:]);assert 0 <= lo <= hi < a[1]
                return "BV", hi - lo + 1
            raise ValueError("Unsupported indexed operation " + str(op))
        if op == "let":
            local = dict(env)
            additions = {k: self.infer(v, env) for k, v in x[1]}
            local.update(additions)
            return self.infer(x[2], local)
        if op in ["forall", "exists"]:
            local = dict(env);local.update({k: sort(s) for k, s in x[1]})
            assert self.infer(x[2], local) == "Bool"
            return "Bool"
        args = [self.infer(a, env) for a in x[1:]]
        if op in ["and", "or", "not", "=>", "xor"]:
            assert all(a == "Bool" for a in args), (op, args)
            if op == "not":assert len(args) == 1
            if op in ["=>", "xor"]:assert len(args) >= 2
            return "Bool"
        if op in ["=", "distinct"]:
            assert len(args) >= 2 and all(a == args[0] for a in args), (op, args)
            return "Bool"
        if op == "ite":
            assert len(args) == 3 and args[0] == "Bool" and args[1] == args[2], args
            return args[1]
        if op == "select":
            assert len(args) == 2 and args[0][0] == "Array" and args[0][1] == args[1], args
            return args[0][2]
        if op == "store":
            assert len(args) == 3 and args[0][0] == "Array" and args[0][1:] == tuple(args[1:]), args
            return args[0]
        if op == "concat":
            assert len(args) == 2 and all(a[0] == "BV" for a in args), args
            return "BV", sum(a[1] for a in args)
        if op in ["+", "-", "*", "<", "<=", ">", ">="]:
            assert args and all(a == "Int" for a in args), (op, args)
            return "Bool" if op in ["<", "<=", ">", ">="] else "Int"
        if isinstance(op, str) and op.startswith("bv"):
            assert args and all(a[0] == "BV" and a == args[0] for a in args), (op, args)
            if op in ["bvult", "bvule", "bvugt", "bvuge", "bvslt", "bvsle", "bvsgt", "bvsge"]:
                assert len(args) == 2
                return "Bool"
            assert op in ["bvadd", "bvsub", "bvmul", "bvudiv", "bvurem", "bvshl", "bvlshr", "bvand", "bvor", "bvxor", "bvnot", "bvneg"], op
            assert len(args) == (1 if op in ["bvnot", "bvneg"] else 2)
            return args[0]
        if op not in self.functions:
            raise ValueError("Unbound function " + str(op))
        wanted, result = self.functions[op]
        if tuple(args) != wanted:
            raise ValueError(f"Arguments {op}: {args} != {wanted}")
        return result

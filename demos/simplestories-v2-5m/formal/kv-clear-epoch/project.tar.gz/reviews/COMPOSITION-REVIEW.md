# Independent final composition review

Verdict: **ACCEPT the scalar epoch proof composition.** I found no circularity,
unproved application premise, changed source, conversion mismatch, or reset/max
vacuity that blocks closing the exact original R3 epoch preservation obligation.
This accepts the recorded engine-checked argument, not the complete local
read-integrity invariant or a whole-device theorem.

Reviewer: `/root/fresh_clear_epoch_plan_review`. Read-only audit completed
November 6, 2026, approximately 05:29 UTC. I launched no solver, compiler,
simulator, or subagent. The only audit write is this new review file. My earlier
independent plan review remains unchanged.

## Logic of the composition

Write A for the exact original full-step antecedent; N for the four source
projection conclusions; J for the original R3 predicate plus reset-conditional
native/reference clear-seen equality; B for both resets high, healthy successor,
and a fresh native CLEAR; P for the instantiated arithmetic premises; and C for
the instantiated arithmetic conclusion.

The checked providers establish A=>N and A=>J at the predecessor. The original
activation query establishes A and N and J and B => P. It contains neither the
arithmetic conclusion nor a desired successor invariant. The source-independent
arithmetic provider establishes P=>C for arbitrary Int g and 64-bit e. Therefore
A entails the guarded conclusion B=>C. The original consumer checks A and N
and J and (B=>C) => the exact original successor R3. This closes the original
implication by ordinary implication composition. The joint consumer has the
same acyclic structure from its smaller antecedent and establishes successor J.

The activation use of a healthy successor is legitimate: native terminal/fault
stickiness is proved from the actual transition, which recovers pre-state
health. Healthy predecessor or nonoverflow hardware is never assumed globally.
All consumer source equations are conclusions of closed source providers whose
premises are literal subsets of the retained antecedent. The R6-to-J weakening
and original-antecedent-to-joint-antecedent queries also close.

## Exact formula and receipt checks

I inspected SCALAR.smt2, prepare.py, compose.py, PROVIDER-BINDINGS.json,
COMPOSITION-PLAN.json, MATH-PLAN.json, activation acceptance records, actual query
tails, runner receipt handling, and raw result files. Independent parsing and
hash checks established:

- The epoch-original body is AST-identical to the frozen original R3 body.
  Every ordered input in the six initial plans matches its recorded SHA-256.
  All 36 initial rule queries contain exactly their planned assertions and
  definitions; no hidden push/pop/reset or check-sat-assuming changes the formula.
- All seven bound providers match their recorded assumptions, conclusions,
  query identities, receipt identities, and raw-log hashes. The 32 clean
  initial/rebound receipts checked have the required exact SAT/UNSAT reply,
  clean exit, and no stop reason. Unexecuted diagnostics are not counted.
- The simultaneous substitution is exactly g=r-generation(ra),
  e=native epoch_q(a), with verified Int and 64-bit sorts. Its premise and
  conclusion ASTs equal those in the activation/consumer plan. The substitution
  introduces no binder capture. The consumer's extra arithmetic assertion is
  precisely B=>C, never unconditional C.
- Each of the four composed original case queries retains the exact frozen
  case antecedent as its prefix and the exact original conclusion. Its added
  assertions are only N, predecessor J, and B=>C. All four are clean UNSAT;
  so are the combined original consumer and joint consumer. The case coverage
  clause is the original exhaustive reset/no-new/fresh partition.

The CVC5 increment provider uses the original int_to_bv64 encoding and actual
64-bit bvadd. Its query differs from the pure math-plan input only by
`(set-logic ALL)`. The saved normalized and unexpanded CVC5 inputs are
byte-identical; the normalization ledger lists no changed definitions,
aliases, or assertions. The clean UNSAT reply used
`--solve-bv-as-int=sum`. No unsigned-conversion axiom, reduced counter width, or
bound on CLEAR events is imported into this provider or consumer.

## Nonvacuity, controls and rebound

The four SAT contexts contain the full original antecedent and actual native
transition. Normal first CLEAR has a short native reset-rooted prefix and a
healthy successor at generation/epoch one. Held CLEAR remains healthy without
increment. Held CLEAR at max epoch is explicitly healthy. Fresh exhausted
CLEAR is explicitly terminal immediately and in the successor, keeps native
epoch at all-ones, and advances the mathematical generation to 2^64. The last
three are accurately labeled arbitrary-state witnesses; none claims a short
reset-reachable trace to counter exhaustion.

I inspected contexts.py, control_queries.py, compile_controls.py, both source
patches and COMPILE records, and both strengthened CONTROL-EPOCH plans. Each
shadow source is exactly the original bundled source with its single named
replacement. Compiler recipes are byte-identical to the original. Saved native
SMT/source/JSON hashes match their receipts and the full RAM geometry is retained.
Control queries use their own mutated native definitions with the unchanged
history/reference definitions; no positive native/reference provider equations
are asserted.

The strengthened controls require successor native/reference clear-seen
equality and negate epoch-original itself. Both are clean SAT:

- Omitted increment: `runs/control-omit-increment-epoch-query-20261106T052645493182Z/RESULT.json`.
- Suppressed exhaustion fault: `runs/control-suppress-exhaustion-fault-epoch-query-20261106T052647904103Z/RESULT.json`.

Thus control detection concerns the exact range/epoch relation, not merely the
broader joint predicate. The ordinary control retains the native reset-rooted
prefix; exhaustion remains an accurately labeled arbitrary-state control.

Original-source rebound receipts are clean for native update, native exhaustion,
joint reset base, joint composed preservation, original composed preservation,
and original fresh CLEAR. These rebound runs followed the original mutant runs;
the later strengthened control queries reuse the same unchanged mutant models.
No production source was restored from a mutant because production was never
edited. Original input hashes remain equal to their frozen identities.

## Accepted scope and closeout

The proof graph can now qualify the original scalar R3 preservation result,
with explicit ledger links from provider to application to consumer. At audit
time the prepared provider metadata still says proof_graph_complete=false;
that is a conservative pending-qualification flag, not an additional theorem
failure. The final qualifier should bind these existing closed nodes and avoid
crediting unused or unexecuted arithmetic diagnostics.

No additional experiment is required by this audit. Preserve the fixed
05:51:30 UTC development stop and 06:01:30 UTC hard closeout. Tag/cache/RAM
structural preservation, the joined parent/attention consumer theorem, model
provenance, implementation evidence, and residual-training conclusions remain
outside this accepted result.

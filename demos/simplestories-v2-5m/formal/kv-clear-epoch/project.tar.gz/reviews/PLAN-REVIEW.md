# Independent review: CLEAR epoch pilot

Verdict: **GO for the bounded pilot under the existing deadlines**, with the
execution constraints below. The scalar proof can discharge the exact original
R3 preservation obligation without a new environmental or cryptographic
assumption. This is a mathematical assessment of the proposed proof structure,
not an engine result or a prediction that mixed Int/64-bit arithmetic will close
within the budget.

Fresh reviewer: `/root/fresh_clear_epoch_plan_review`, with no earlier conversation
context. Review completed November 6, 2026, approximately 05:10 UTC. No solver,
compiler, simulator, production edit, or subagent was used. Only this review
document was written.

## What I inspected

I read applicable repository AGENTS.md, PLAN.md, the closed parent gate report,
the exact R6 R3 predicate and enclosing predecessor, all four epoch case tails
and their CASE-PLAN entries, the legitimate store's generation/clear/reset
updates, the frozen SystemVerilog epoch/fault assignments, and the actual native
SMT reset views, epoch update, fault cone, and transition equalities.

All 12 ordered CASE-PLAN inputs and the four selected epoch case files match
their recorded SHA-256 hashes. The setup manifest also matches the inspected
guard snapshot, native SMT, combined native source, and compiler script. The
native compiler script uses full flatten/async2sync/memory_collect and rejects
assert/assume/anyconst/anyseq cells. I did not independently rebuild it or
re-audit every source transformation.

## Why the reduction is sufficient

Let M=18446744073709551616, g=r-generation(ra), e=epoch_q(a),
c=clear_i(a), and s=clear_seen_q(a). The exact goal only requires range and
encoding when reset_n(b) and not terminal_now(b). The predecessor contains the
same original R3 predicate at a and equality of native/reference clear-seen
when reset_n(a).

The actual scalar equations support the following argument:

1. If reset is low at either endpoint, legitimate-next returns generation zero.
   Native epoch_q(b) is zero too: reset at a clears the internal successor;
   reset at b masks the observed successor. If reset_n(b) is false, the exact
   target is itself vacuous. This uses the inspected async2sync translation,
   not a guessed synchronous-reset model.
2. With both resets high, native terminal_now(a) implies fault_q(b), hence
   terminal_now(b). Fault assignments elsewhere in the source only set the
   sticky bit. Thus a healthy b implies a healthy a. This supplies the missing
   pre-health premise needed to activate the original R3 range/encoding fact;
   it must be proved, never added as an unconditional premise.
3. With both resets high, native e' is e+1 modulo 64 bits exactly when
   c and not s and e is not all-ones; otherwise it is e. Native/reference
   clear-seen equality makes the legitimate generation update g+1 on precisely
   the same fresh-CLEAR event, and g otherwise.
4. A fresh CLEAR at all-ones implies terminal_now(a) directly through
   fault_event, and then terminal_now(b) through the latch. Consequently this
   boundary cannot occur in the healthy-post-state branch. From 0<=g<M and
   e=int_to_bv64(g), excluding all-ones gives g<M-1. The increment has range
   0<=g+1<M and int_to_bv64(g+1)=bvadd(e,1). Held/no-new CLEAR keeps both values.

Nothing in this argument needs the RAM contents, SHA response, lower-memory
honesty, or a bound on the number of CLEAR events. Stronger scalar implications
proved from weaker native premises are useful here: the original full
predecessor implies their premises. This does not permit deleting the native
transition or changing the final goal.

## Minimal useful proof structure

Prefer a few source providers for native reset/update, native terminal-to-next
fault, exhaustion-to-terminal, and exact legitimate generation/clear-seen
updates. Prove the full-predecessor weakening to original R3 plus clear-seen
equality. Arithmetic providers need only (a) range plus encoding identifies
all-ones with M-1 and (b) compatible increment with its successor range. A
single scalar theorem can consume these facts; then replay the unchanged
reset/no-new/fresh cases and coverage.

The owner's proposed smaller joint invariant is also sound and preferable for
the first attempt: J(a,ra) is exactly original R3(a,ra) conjoined with
reset_n(a) => clear_seen_q(a)=r-clear-seen(ra). Prove preservation of J from
J(a,ra), actual native h/t, and rb=legitimate-next(a,b,ra), leaving all other
R6 state free. Successor clear-seen equality follows from the actual update
or reset even across reset release. Check full R6 => J at the predecessor and
J => original R3 at the successor. This proves a stronger implication from a
weaker antecedent; it does not cut the RTL or replace the original consumer.

For a lemma DAG, save each provider's entire implication, declarations,
assumptions, query hash and raw answer. Use simultaneous, sort-checked AST
substitution at applications. Prove every provider-premise implication from
the actual consumer antecedent; textual similarity or a matching conclusion
name is insufficient. No provider may depend on the desired successor R3 or
on another unclosed provider. The final consumer must retain the exact original
antecedent and conclusion. Asserted instantiated lemmas are justified only by
those closed providers and the recorded premise/application checks.

## Required execution constraints and sensitivity checks

- Do not impose healthy a on the original exhausted fresh-CLEAR context: the
  source makes that a terminal state immediately. Conversely, all-ones with
  held/no-new CLEAR may remain healthy. Excluding all max-epoch states would
  change the obligation.
- Generation can advance past M after exhaustion while native epoch saturates.
  The original invariant deliberately says nothing about generation range in
  terminal states. Do not demand unconditional range or epoch equality there.
  Prove terminal persistence to justify the target's conditional shape.
- Establish SAT of the full original antecedent for normal fresh and held
  CLEAR, including healthy post-states, not merely SAT of a reduced scalar
  abstraction. For exhaustion, retain a source transition at max epoch with
  actual immediate and successor terminal behavior. Label it arbitrary-state;
  no short reset-born trace can reach that boundary.
- The increment-omission control should fail a normal healthy CLEAR instance.
  The suppressed-exhaustion-fault control should permit a max-epoch fresh
  CLEAR with other fault causes inactive and a healthy successor, violating
  the reference range/encoding obligation. Select those fields only in the
  existence/control query. Do not carry such restrictions into universal
  source providers or the original consumer. Use the mutated native source,
  not unchanged-original native equations accidentally combined with it.
- Immediate overflow detection and its latch deserve explicit source results:
  the conditional R3 goal alone does not express every part of that behavior.
  Preserve the original-source positive rebound after controls.

The one-hour scope and stop rule are appropriate for this unresolved bottleneck.
Keep development/engine stop at 05:51:30 UTC and closeout at 06:01:30 UTC;
review time does not move them. Reserve time for the two required controls and
rebound before optional held-CLEAR mutation or long retries. Enforce the
aggregate solver/RSS limits across concurrent workers. If only providers close,
report those providers as partial results; do not call the original preservation
obligation closed until its exact composition and all selected cases close.

No change to the target, threat model, RTL, or overall theorem scope is needed
for this pilot. The main remaining risk is tractability of the exact conversion
bridge and its checked composition, not a missing logical assumption in the
scalar proof outline.

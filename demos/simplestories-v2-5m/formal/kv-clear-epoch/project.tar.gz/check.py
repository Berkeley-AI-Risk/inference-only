"""Recorded formula/source/application checks; SMT engines establish the lemmas."""
from pathlib import Path
import json,hashlib,re,sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'tools'))
from smt_check import parse,Checker
def sha(b):return hashlib.sha256(b).hexdigest()
def pp(x):return '('+' '.join(map(pp,x))+')'if isinstance(x,list)else x
def ast(s):return parse(s)[0]
def modules(raw):return{m[1]:m[0]for m in re.finditer(r'^module\s+(\w+)\b[\s\S]*?^endmodule',raw,re.M)}
def assemble(source,files):
 pieces=[]
 for name in source['module_file_order']:
  defs=modules(files[name].decode())
  row=source['production_files']['variants/kv-protected/hardware/project/'+name]
  pieces.extend(defs[n]for n in row['modules'])
 return(source['assembly_header']+'\n\n'.join(pieces)+'\n').encode()
def build_query(project,node,overrides=None):
 inputs=[]
 for path in node['inputs']:
  f=(overrides or{}).get(path,project/path);inputs.append(Path(f).read_text())
 declarations='\n'.join('(declare-const '+n+' '+s+')'for n,s in node['declarations'])
 assertions=node['assumptions']+(['(not '+node['conclusion']+')']if node['conclusion']is not None else[])
 tail='\n'.join('(assert '+x+')'for x in assertions)+'\n(check-sat)\n'
 if node['format']=='simple-math':text='(set-option :produce-models true)\n'+declarations+'\n'+tail
 else:text='(set-option :produce-models true)\n'+'\n'.join(inputs)+'\n'+declarations+'\n'+tail
 if node['logic']:text='(set-logic '+node['logic']+')\n'+text
 return text.encode()
def verify_contents(project):
 manifest=json.loads((project/'CONTENTS.json').read_text())
 actual={str(f.relative_to(project))for f in project.rglob('*')if f.is_file()and f.name!='CONTENTS.json'}
 assert actual==set(manifest['files']),'Unexpected or missing project file'
 for name,row in manifest['files'].items():
  f=project/name;assert f.is_file()and not f.is_symlink()
  assert f.stat().st_size==row['bytes']and sha(f.read_bytes())==row['sha256'],name
def check_graph(project,g):
 nodes=g['nodes'];q=lambda n:nodes[n]
 N=['(|board1_kv_integrity_guard_h| a)','(|board1_kv_integrity_guard_h| b)','(|board1_kv_integrity_guard_t| a b)']
 A=N+['(= rb (legitimate-next a b ra))','(epoch-joint a ra)']
 assert g['joint_antecedent']==A
 OA=g['original_antecedent'];assert OA[:3]==N
 names=['native-update','native-sticky','native-exhaustion','reference-update'];assert g['source_nodes']==names
 NC=[q(n)['conclusion']for n in names];J='(epoch-joint a ra)'
 assert q('native-update')['assumptions']==N and q('native-sticky')['assumptions']==N and q('native-exhaustion')['assumptions']==N
 assert q('reference-update')['assumptions']==N[:2]+['(= rb (legitimate-next a b ra))']
 for n in names:assert all(x in A and x in OA for x in q(n)['assumptions'])
 assert q('joint-reset-base')['assumptions']==[N[0],'(|board1_kv_integrity_guard_i| a)','(not (|board1_kv_integrity_guard_n reset_n| a))','(= ra legitimate-zero)']
 assert q('joint-reset-base')['conclusion']=='(epoch-joint a ra)'
 assert q('R6-supplies-joint')['assumptions']==['(full-local-read-structural-I a ha ra pa qa watched-key)']
 assert q('R6-supplies-joint')['assumptions'][0]in OA and q('R6-supplies-joint')['conclusion']==J
 assert q('joint-supplies-original')['assumptions']==['(epoch-joint b rb)']
 target='(R3-nonterminal-epoch-correspondence b hb rb pb qb watched-key)'
 assert q('joint-supplies-original')['conclusion']==target
 # Body identity binds the published statement to the unchanged original goal.
 defs=[x for x in parse((project/g['original_R3_input']).read_text())if x[0]=='define-fun']
 original=next(x for x in defs if x[1]==g['goal'])
 scalar=[x for x in parse((project/g['scalar_input']).read_text())if x[0]=='define-fun']
 exact=next(x for x in scalar if x[1]=='epoch-original')
 assert original[4]==exact[4]
 expected='(=> (and (|board1_kv_integrity_guard_n reset_n| a) (not (|board1_kv_integrity_guard_n terminal_now| a))) (and (<= 0 (r-generation r)) (< (r-generation r) 18446744073709551616) (= (|board1_kv_integrity_guard_n epoch_q| a) ((_ int_to_bv 64) (r-generation r)))))'
 assert exact[4]==ast(expected),'Statement drift'
 # Independently check sorts and simultaneous, capture-free arithmetic binding.
 checker=Checker();positive=q('native-update')
 for i,name in enumerate(positive['inputs']):checker.load(parse((project/name).read_text()),native=i==0)
 for name,s in positive['declarations']:checker.load(parse('(declare-const '+name+' '+s+')'))
 sub={n:ast(s)for n,s in g['math_substitution'].items()}
 assert sub=={'g':ast('(r-generation ra)'),'e':ast('(|board1_kv_integrity_guard_n epoch_q| a)')}
 assert checker.infer(sub['g'],{})=='Int'and checker.infer(sub['e'],{})==('BV',64)
 def subst(x):
  if isinstance(x,str):return sub.get(x,x)
  assert x[0]not in['forall','exists','let']
  return[subst(y)for y in x]
 math=q('math-increment')
 assert math['declarations']==[['g','Int'],['e','(_ BitVec 64)']]
 assert math['assumptions']==['(<= 0 g)','(< g 18446744073709551616)','(= e ((_ int_to_bv 64) g))','(not (= e (_ bv18446744073709551615 64)))']
 assert ast(math['conclusion'])==ast('(and (<= 0 (+ g 1)) (< (+ g 1) 18446744073709551616) (= (bvadd e (_ bv1 64)) ((_ int_to_bv 64) (+ g 1))))')
 P=['and']+[subst(ast(x))for x in math['assumptions']];C=subst(ast(math['conclusion']))
 assert P==ast(g['math_premise'])and C==ast(g['math_conclusion'])
 B=g['activation_guard'];G=g['guarded_math']
 assert ast(G)==['=>',ast(B),C]
 assert ast(B)==ast('(and (|board1_kv_integrity_guard_n reset_n| a) (|board1_kv_integrity_guard_n reset_n| b) (not (|board1_kv_integrity_guard_n terminal_now| b)) (|board1_kv_integrity_guard_n clear_i| a) (not (|board1_kv_integrity_guard_n clear_seen_q| a)))')
 for name,pre in [('joint-math-activation',A+NC+[B]),('original-math-activation',OA+NC+[J,B])]:
  assert q(name)['assumptions']==pre and ast(q(name)['conclusion'])==P
 assert q('original-supplies-joint-antecedent')['assumptions']==OA
 assert ast(q('original-supplies-joint-antecedent')['conclusion'])==['and']+[ast(x)for x in A]
 assert q('joint-composed-step')['assumptions']==A+NC+[G]
 assert q('joint-composed-step')['conclusion']=='(epoch-joint b rb)'
 assert q('original-composed-step')['assumptions']==OA+NC+[J,G]
 assert q('original-composed-step')['conclusion']==target
 for name,row in g['original_cases'].items():
  node=q('composed-'+name);assert node['assumptions']==row['assumptions']+NC+[J,G]
  assert ast(node['conclusion'])==ast(row['conclusion'])
 coverage=g['original_cases']['epoch-case-coverage'];parts=ast(coverage['conclusion'])
 assert coverage['assumptions']==OA and parts[0]=='or'and len(parts)==4
 for name,index in [('epoch-reset-edge',1),('epoch-fresh-clear',2),('epoch-not-fresh-clear',3)]:
  assert[ast(x)for x in g['original_cases'][name]['assumptions']]==[ast(x)for x in OA]+[parts[index]]
 # Every consumer dependency is earlier in the fixed acyclic proof order.
 closed=set(names+['math-increment','math-inverse','math-boundary','joint-reset-base','R6-supplies-joint','joint-supplies-original'])
 order=['native-provider-premises','original-supplies-joint-antecedent','joint-math-activation','original-math-activation','joint-composed-step','original-composed-step','composed-epoch-case-coverage','composed-epoch-reset-edge','composed-epoch-not-fresh-clear','composed-epoch-fresh-clear']
 expected_deps={
  'native-provider-premises':[],'original-supplies-joint-antecedent':[],
  'joint-math-activation':names,'original-math-activation':names+['R6-supplies-joint'],
  'joint-composed-step':names+['math-increment','joint-math-activation'],
  'original-composed-step':names+['R6-supplies-joint','math-increment','original-math-activation']}
 for name in order:
  expected=expected_deps.get(name,names+['R6-supplies-joint','math-increment','original-math-activation'])
  assert set(q(name)['dependencies'])==set(expected),(name,'Missing/extra dependency')
  assert set(q(name)['dependencies'])<=closed,(name,'Cyclic or unclosed dependency')
  closed.add(name)
 for name,control in [('control-omit-increment-epoch','omit-increment'),('control-suppress-exhaustion-fault-epoch','suppress-exhaustion-fault')]:
  n=q(name);assert n['inputs'][0]=='models/'+control+'/native.smt2'
  assert '(not (epoch-original b rb))'in n['assumptions']
  assert '(= (|board1_kv_integrity_guard_n clear_seen_q| b) (r-clear-seen rb))'in n['assumptions']
  assert not any('epoch-native-'in x or'epoch-reference-update'in x for x in n['assumptions'])
 assert len(nodes)==26
 return{'selected_nodes':len(nodes),'unbounded_scalar_joint_induction':True,'exact_original_epoch_preservation':True,'whole_local_read_integrity':False,'whole_device_theorem':False}
def validate(project,source,model,theorem):
 verify_contents(project);g=json.loads((project/'GRAPH.json').read_text())
 assert(theorem.read_bytes()==(project/g['scalar_input']).read_bytes())
 raw={}
 for relative,row in source['production_files'].items():
  live=model/relative;assert sha(live.read_bytes())==row['sha256'],('Production source mismatch',relative)
  snapshot=project/row['snapshot'];assert snapshot.read_bytes()==live.read_bytes()
  raw[Path(relative).name]=snapshot.read_bytes()
 assembled=assemble(source,raw)
 assert sha(assembled)==source['source_sha256']
 assert assembled==(project/'models/original/native.sv').read_bytes()
 assert sha((project/'models/original/native.smt2').read_bytes())==source['native_smt_sha256']
 assert sha((project/'models/original/native.json').read_bytes())==source['native_json_sha256']
 assert sha((project/'models/original/compile.ys').read_bytes())==source['recipe_sha256']
 changes={'omit-increment':("epoch_q<=epoch_q+1'b1;","epoch_q<=epoch_q;"),'suppress-exhaustion-fault':("(clear_i && !clear_seen_q && &epoch_q) ||","1'b0 ||")}
 expected=sorted([(640,32),(13824,32)]+[(4096,32)]*6+[(64,32)])
 for role in ['original',*changes]:
  d=project/'models'/role
  if role in changes:
   old,new=changes[role];text=assembled.decode();assert text.count(old)==1
   assert(d/'native.sv').read_text()==text.replace(old,new)
   assert(d/'compile.ys').read_bytes()==(project/'models/original/compile.ys').read_bytes()
  graph=json.loads((d/'native.json').read_text())['modules'][source['top']]
  mems=sorted((int(c['parameters']['SIZE'],2),int(c['parameters']['WIDTH'],2))for c in graph['cells'].values()if c['type']=='$mem_v2')
  assert mems==expected
  assert not any(c['type']in['$assert','$assume','$anyconst','$anyseq']for c in graph['cells'].values())
  assert int(graph['parameter_default_values']['DDR_TIMEOUT_CYCLES'],2)==50000000
 for name,node in g['nodes'].items():
  query=(project/node['query']).read_bytes();assert sha(query)==node['query_sha256']
  assert build_query(project,node)==query,('Query reconstruction mismatch',name)
  forms=parse(query.decode());got=[x[1]for x in forms if x[0]=='assert']
  want=[ast(x)for x in node['assumptions']]+([['not',ast(node['conclusion'])]]if node['conclusion']is not None else[])
  assert got==want
  assert sum(x[0]=='check-sat'for x in forms)==1
  assert not any(x[0]in['push','pop','reset','check-sat-assuming']for x in forms)
  for inp in node['inputs']:assert not any(x[0]=='assert'for x in parse((project/inp).read_text()))
  log=(project/node['log']).read_bytes();assert sha(log)==node['log_sha256']
  record=json.loads((project/node['record']).read_text())
  assert record['query_sha256']==node['query_sha256']and record['log_sha256']==node['log_sha256']
  assert record['exit_code']==0 and record['stop_reason']is None and record['answer']==node['expected']
  assert log.strip().decode()==node['expected']
 return check_graph(project,g),g

"""Freeze native owner/packer histories and induction obligations before solving.

These are component lemmas inside the Q pilot, not the composed Q theorem.
There is no correct-data assumption at either module's input.
"""
from pathlib import Path
import json
import re
import subprocess
import sys

from source_policy import HERE, native_source, require_exact, controls, sha, write_json, PUBLIC

PREFIX='fpga/token_only_model0_ddr_board1/'
ARBITER=PREFIX+'fixed_token_machine0/rtl/board1_fixed_private_ddr_arbiter.sv'
PACKER=PREFIX+'ddr_phy_open0/rtl/board1_private_ddr256_to_w640.sv'
FIFO=PREFIX+'ddr_preboard_closure0/rtl/board1_ddr_request_fifo2.sv'


def conj(xs):
    return '(and '+' '.join(xs)+')' if xs else 'true'


def bv(v,w):
    return f'(_ bv{v} {w})'


def compile_native(label, top, selection, params):
    d=HERE/label
    source,rows=native_source(selection); require_exact(source,selection)
    if d.exists():
        m=json.loads((HERE/(label+'-SOURCES.json')).read_text())
        if (d/'native.sv').read_text()!=source or m['parameters']!=params or sha((d/'native.smt2').read_bytes())!=m['native_smt_sha256']:
            raise ValueError('Changed existing native model')
        return d,m
    d.mkdir()
    (d/'native.sv').write_text(source)
    recipe='read_verilog -formal -sv -nosynthesis native.sv\n'
    if params: recipe+='chparam '+' '.join('-set '+k+' '+str(v) for k,v in params.items())+' '+top+'\n'
    recipe+='\n'.join(['hierarchy -check -top '+top,'rename -top '+top,'proc','opt_clean','flatten','async2sync','opt_clean','dffunmap','memory_collect',
        'select -assert-none t:$assert t:$assume t:$anyconst t:$anyseq','check -assert','write_json native.json','write_smt2 -wires native.smt2'])+'\n'
    (d/'compile.ys').write_text(recipe)
    with(d/'compile.log').open('w')as f:
        cp=subprocess.run(['yosys','-Q','compile.ys'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    if cp.returncode:raise ValueError('Compile failed: '+label)
    if re.search(r'implicitly declared|out of bounds|no driver',(d/'compile.log').read_text(),re.I):raise ValueError('Unsupported native model')
    manifest=dict(sources=rows,top=top,parameters=params,source_sha256=sha(source.encode()),native_smt_sha256=sha((d/'native.smt2').read_bytes()),
        internal_cuts=[],HDL_observer_additions=[],source_policy='exact-native-module-bodies',controls=controls(selection))
    write_json(HERE/(label+'-SOURCES.json'),manifest)
    return d,manifest


def finish(label,top,defs,inv,zero,next_expr,goals,manifest,extra_declarations=None,initial_configuration=False,native_label=None,additional_bodies=None,preserved_parts=None):
    d=HERE/label; S='|'+top+'_s|'
    native_label=native_label or label
    d.mkdir(exist_ok=True)
    n=lambda x,s='a':f'(|{top}_n {x}| {s})'
    h=lambda s:f'(|{top}_h| {s})'
    t=f'(|{top}_t| a an)'
    reset=n('reset_n')
    init=[f'(|{top}_i| a)']if initial_configuration else []
    # The history equation is functional/total: no premise may constrain a
    # circuit input or choose history values after seeing the desired result.
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const h {label.title()}History)',f'(declare-const hn {label.title()}History)']+(extra_declarations or [])
    rules={
        'reset-base':dict(assumptions=init+[h('a'),h('an'),t,'(not '+reset+')'],conclusion=f'({inv} an {zero})'),
        'preserved':dict(assumptions=[h('a'),h('an'),t,f'({inv} a h)',f'(= hn {next_expr})'],conclusion=f'({inv} an hn)'),
        'consequence':dict(assumptions=[h('a'),f'({inv} a h)',reset],conclusion=conj(goals)),
        'reset-context':dict(assumptions=init+[h('a'),h('an'),t,'(not '+reset+')',n('reset_n','an')],conclusion='false',expected='sat'),
    }
    if preserved_parts:
        common=rules['preserved']['assumptions']
        rules={'reset-base':rules['reset-base'],
            **{'preserved-'+str(i):dict(assumptions=common,conclusion=part)for i,part in enumerate(preserved_parts)},
            'parts-join':dict(assumptions=preserved_parts,conclusion=f'({inv} an hn)'),
            'consequence':rules['consequence'],'reset-context':rules['reset-context']}
    (d/'history.smt2').write_text(defs)
    bodyfiles=[native_label+'/native.smt2']+(additional_bodies or [])+[label+'/history.smt2']
    sourcefiles=[native_label+'/'+name for name in manifest['files']]if manifest.get('kind')=='restored-native-projection-parent'else[native_label+'/native.sv']
    write_json(HERE/(label+'-PLAN.json'),dict(schema='Typed-native-history-induction-v1',bodies=bodyfiles,source_manifest=native_label+'-SOURCES.json',native_sources=sourcefiles,native_source=sourcefiles[0],checks_file=label+'-CHECKS.json',
        inputs={x:sha((HERE/x).read_bytes())for x in [native_label+'-SOURCES.json',*sourcefiles,native_label+'/compile.ys',*bodyfiles]},
        declarations=declarations,rules=rules,order=list(rules),induction=dict(top=top,invariant=inv,zero=zero,next=next_expr,history_sort=label.title()+'History',
            root_goals=goals,external_assumptions=[],reset='reset_n',compiler_initial_configuration=initial_configuration,preserved_parts=preserved_parts,claim='Every native execution after common reset has these accepted-history ownership/packing consequences'),
        whole_Q_consumption_proved=False,whole_machine_theorem=False,observations=[n('reset_n'),n('reset_n','an')]))


def owner():
    top='board1_fixed_private_ddr_arbiter';label='owner'
    d,m=compile_native(label,top,{ARBITER:[top]},dict(ADDR_W=19,MODEL_WORDS=227062,OWNER_DEPTH=16))
    S='|'+top+'_s|';n=lambda x,s='a':f'(|{top}_n {x}| {s})'
    eq=lambda a,b:f'(= {a} {b})'
    push=n('request_transfer'); pop=conj([n('response_transfer'),'(distinct (o-count h) #b00000)'])
    mask='(bvshl #x0001 ((_ zero_extend 12) (o-wr h)))'
    bits=f'(ite {push} (bvor (bvand (o-bits h) (bvnot {mask})) (ite {n("layer_req_valid_i")} {mask} #x0000)) (o-bits h))'
    count=f'(bvsub (bvadd (o-count h) (ite {push} #b00001 #b00000)) (ite {pop} #b00001 #b00000))'
    nxt=f'(owner-next a h)'
    invs=[eq(n('owner_count_q'),'(o-count h)'),eq(n('owner_write_pointer_q'),'(o-wr h)'),eq(n('owner_read_pointer_q'),'(o-rd h)'),
        eq(n('owner_fifo_q'),'(o-bits h)'),'(bvule (o-count h) #b10000)',eq('(o-wr h)','(bvadd (o-rd h) ((_ extract 3 0) (o-count h)))')]
    defs='(declare-datatypes () ((OwnerHistory (owner-history (o-bits (_ BitVec 16)) (o-wr (_ BitVec 4)) (o-rd (_ BitVec 4)) (o-count (_ BitVec 5))))))\n'
    defs+='(define-fun owner-zero () OwnerHistory (owner-history #x0000 #x0 #x0 #b00000))\n'
    defs+=f'(define-fun owner-next ((a {S}) (h OwnerHistory)) OwnerHistory (ite (not {n("reset_n")}) owner-zero (owner-history {bits} (bvadd (o-wr h) (ite {push} #x1 #x0)) (bvadd (o-rd h) (ite {pop} #x1 #x0)) {count})))\n'
    defs+=f'(define-fun owner-inv ((a {S}) (h OwnerHistory)) Bool (=> {n("reset_n")} {conj(invs)}))\n'
    head='(= ((_ extract 0 0) (bvlshr (o-bits h) ((_ zero_extend 12) (o-rd h)))) #b1)'
    layer=n('layer_rsp_valid_o');shell=n('shell_rsp_valid_o')
    goals=[f'(=> {layer} {conj(["(bvugt (o-count h) #b00000)",head,eq(n("layer_rsp_data_o"),n("private_rsp_data_i")),"(not "+shell+")"])})',
        f'(=> {shell} {conj(["(bvugt (o-count h) #b00000)","(not "+head+")",eq(n("shell_rsp_data_o"),n("private_rsp_data_i")),"(not "+layer+")"])})',
        f'(=> {n("terminal_now")} (and (not {layer}) (not {shell}) (not {n("private_req_valid_o")})))',
        f'(=> {n("request_transfer")} {conj(["(xor "+n("shell_req_valid_i")+" "+n("layer_req_valid_i")+")",eq(n("private_req_index_o"),"(ite "+n("layer_req_valid_i")+" "+n("layer_req_index_i")+" "+n("shell_req_index_i")+")")])})']
    finish(label,top,defs,'owner-inv','owner-zero',nxt,goals,m)
    # Universal module instantiation: real common reset and parameters, CLEAR
    # is absent. These source facts are not a theorem about the child peers.
    corepath=PREFIX+'context2048_token_machine2/rtl/board1_context2048_token_machine_core.sv'
    core=(PUBLIC/corepath).read_text()
    start=core.index('    board1_fixed_private_ddr_arbiter #(');end=core.index('\n    );',start)+7
    instance=core[start:end]
    for exact in ['.ADDR_W(ADDR_W), .MODEL_WORDS(MODEL_WORDS), .OWNER_DEPTH(16)', '.clk(clk), .reset_n(reset_n)', '.layer_req_valid_i(layer_queued_req_valid && !clear_i)', '.shell_req_valid_i(shell_queued_req_valid && !clear_i)']:
        if exact not in instance:raise ValueError('Actual arbiter specialization changed')
    if 'clear_i' in json.loads((d/'native.json').read_text())['modules'][top]['ports']:raise ValueError('Unexpected arbiter CLEAR')
    write_json(HERE/'OWNER-BINDING.json',dict(actual_parent=corepath,parent_sha256=sha(core.encode()),instance=instance,
        reset='common reset_n, not child_reset_n',clear='absent from arbiter; gates parent request offers only',
        proof_rule='Universal native module instantiation at exact clock/reset/parameters; unrestricted child inputs',
        local_queues_and_semantic_window_proved=False,whole_Q_consumption_proved=False))


def packer():
    top='board1_private_ddr256_to_w640';label='packer'
    d,m=compile_native(label,top,{PACKER:[top]}, {})
    S='|'+top+'_s|'; n=lambda x:f'(|{top}_n {x}| a)'
    # p-index counts accepted input words modulo five. Past accepted word
    # values are history, not native register observations.
    index='(p-index h)';data=n('ddr_word_data');accept=n('input_transfer')
    defs='(declare-datatypes () ((PackerHistory (packer-history (p-index (_ BitVec 3)) (p-w0 (_ BitVec 256)) (p-w1 (_ BitVec 256)) (p-w2 (_ BitVec 256)) (p-w3 (_ BitVec 256))))))\n'
    defs+='(define-fun packer-zero () PackerHistory (packer-history #b000 '+ ' '.join([bv(0,256)]*4)+'))\n'
    fields=[f'(ite (= {index} {bv(i,3)}) {data} (p-w{i} h))' for i in range(4)]
    defs+=f'(define-fun packer-next ((a {S}) (h PackerHistory)) PackerHistory (ite (not {n("reset_n")}) packer-zero (ite {accept} (packer-history (ite (= {index} #b100) #b000 (bvadd {index} #b001)) '+ ' '.join(fields)+') h)))\n'
    invs=[f'(bvule {index} #b100)',f'(= {n("phase")} {index})',
        f'(=> (or (= {index} #b001) (= {index} #b010)) (= {n("low_word")} (p-w0 h)))',
        f'(=> (= {index} #b010) (= {n("middle_word")} (p-w1 h)))',
        f'(=> (or (= {index} #b011) (= {index} #b100)) (= {n("shared_half_word")} ((_ extract 255 128) (p-w2 h))))',
        f'(=> (= {index} #b100) (= {n("middle_word")} (p-w3 h)))']
    defs+=f'(define-fun packer-inv ((a {S}) (h PackerHistory)) Bool (=> {n("reset_n")} {conj(invs)}))\n'
    even=f'(concat ((_ extract 127 0) {data}) (concat (p-w1 h) (p-w0 h)))'
    odd=f'(concat {data} (concat (p-w3 h) ((_ extract 255 128) (p-w2 h))))'
    goals=[f'(=> {n("weight_valid")} (or (= {index} #b010) (= {index} #b100)))',
        f'(=> {n("weight_valid")} (= {n("weight_data")} (ite (= {index} #b010) {even} {odd})))',
        f'(=> (and {n("weight_valid")} {n("weight_ready")}) {accept})',
        f'(=> (and {n("weight_valid")} (not {n("weight_ready")})) (not {accept}))',
        f'(= {n("pair_boundary")} (= {index} #b000))']
    finish(label,top,defs,'packer-inv','packer-zero','(packer-next a h)',goals,m)


def fifo(width):
    top='board1_ddr_request_fifo2';label='fifo'+str(width);sort=label.title()+'History';size=257+width
    d,m=compile_native(label,top,{FIFO:[top]},dict(ADDR_W=width))
    S='|'+top+'_s|';n=lambda x:f'(|{top}_n {x}| a)'
    # The configured frontend lowers these two-entry arrays to individual
    # registers. Use the actual generated names/types, with no RAM rewrite.
    word=lambda x: '(ite '+n(x)+' #b1 #b0)' if x.startswith('write_q') or (width==1 and x.startswith('addr_q')) else n(x)
    mem=lambda x,k:f'(ite (= {k} #b1) {word(x+"[1]")} {word(x+"[0]")})'
    rd=n('rd_ptr_q');at=lambda k:f'(concat {mem("write_q",k)} (concat {mem("addr_q",k)} {mem("data_q",k)}))'
    inaddr=f'(ite {n("in_addr_i")} #b1 #b0)' if width==1 else n('in_addr_i')
    outaddr=f'(ite {n("out_addr_o")} #b1 #b0)' if width==1 else n('out_addr_o')
    packed=f'(concat (ite {n("in_write_i")} #b1 #b0) (concat {inaddr} {n("in_data_i")}))'
    push=n('push');pop=n('pop');count='(f-count h)'
    next_count=f'(bvsub (bvadd {count} (ite {push} #b01 #b00)) (ite {pop} #b01 #b00))'
    head=f'(ite {pop} (ite {push} {packed} (f-tail h)) (ite (and {push} (= {count} #b00)) {packed} (f-head h)))'
    tail=f'(ite (and {push} (= {count} #b01) (not {pop})) {packed} (f-tail h))'
    defs=f'(declare-datatypes () (({sort} ({label}-history (f-count (_ BitVec 2)) (f-head (_ BitVec {size})) (f-tail (_ BitVec {size}))))))\n'
    defs+=f'(define-fun {label}-zero () {sort} ({label}-history #b00 {bv(0,size)} {bv(0,size)}))\n'
    defs+=f'(define-fun {label}-next ((a {S}) (h {sort})) {sort} (ite (or (not {n("reset_n")}) {n("abort_i")}) {label}-zero ({label}-history {next_count} {head} {tail})))\n'
    invs=[f'(= {n("count_q")} {count})',f'(bvule {count} #b10)',
        f'(= {n("wr_ptr_q")} (xor {rd} (= ((_ extract 0 0) {count}) #b1)))',
        f'(=> (distinct {count} #b00) (= {at("(ite "+rd+" #b1 #b0)")} (f-head h)))',
        f'(=> (= {count} #b10) (= {at("(ite "+rd+" #b0 #b1)")} (f-tail h)))']
    defs+=f'(define-fun {label}-inv ((a {S}) (h {sort})) Bool (=> {n("reset_n")} {conj(invs)}))\n'
    output=f'(concat (ite {n("out_write_o")} #b1 #b0) (concat {outaddr} {n("out_data_o")}))'
    goals=[f'(=> {n("out_valid_o")} (and (distinct {count} #b00) (= {output} (f-head h))))',
        f'(=> {n("abort_i")} (and (not {n("in_ready_o")}) (not {n("out_valid_o")})))',
        f'(=> (and {n("out_valid_o")} (not {n("out_ready_i")})) (not {pop}))']
    finish(label,top,defs,label+'-inv',label+'-zero','('+label+'-next a h)',goals,m)


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--fifos':fifo(19);fifo(1)
    else:owner();packer()
    print('Exact native models and frozen induction obligations prepared; no solver queries run.')

"""Check the actual induction rule, not just an ordered list of provider IDs.

This first supported rule is a native reset/history induction. Arbitrary extra
private-data or health assumptions are forbidden. The checker does not yet
accept the composed Q theorem: that needs a separate explicit application rule
joining the published memory theorem and actual downstream instances.
"""
import argparse
import copy
import json
from pathlib import Path
import re
import sys

from source_policy import HERE, require_exact, sha, write_json
sys.path.insert(0,str(HERE.parent))
from staged_induction import validate, query, conjunction


def shape(plan):
    if plan['schema']=='Typed-current-Q-operand-composition-v1':
        from build_q_composition import specification,body_files,PROVIDERS
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=PROVIDERS or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'words-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed literal Q theorem/provider application')
        return rules
    if plan['schema']=='Typed-native-Q-MAC-model-v1':
        from build_mac_model import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=['api','reader','words','parentcapture']or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed MAC model/activation induction or provider/state substitution')
        return rules
    if plan['schema']=='Typed-parent-native-capture-induction-v1':
        from build_parent_capture import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=[]or plan.get('external_facts')or plan['root_external_assumptions']!=[]):
            raise ValueError('Changed actual-parent capture induction')
        return rules
    if plan['schema']=='Typed-native-Q-tile-metadata-v1':
        from build_tile_metadata import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=['api','reader','words','header','parentcapture']or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed native tile metadata induction or provider/state substitution')
        return rules
    if plan['schema']=='Typed-native-Q-metadata-header-v1':
        from build_header import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=dict(invariant='api',reader='reader')or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed metadata header induction/provider substitution or unclosed word premise')
        return rules
    if plan['schema']=='Typed-native-Q-word-packing-v1':
        from build_words import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=dict(invariant='api',reader='reader')or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed word-packing induction/provider substitution or unclosed word premise')
        return rules
    if plan['schema']=='Typed-native-reader-refinement-v1':
        from build_reader import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=dict(invariant='api',word='payload')or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'payload-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed reader induction/provider substitution or unclosed private-word premise')
        return rules
    if plan['schema']=='Typed-native-payload-refinement-v1':
        from build_payload import specification,body_files
        rules,declarations=specification()
        if (plan['rules']!=rules or plan['order']!=list(rules)or plan['declarations']!=declarations or plan['bodies']!=body_files()or
                plan['providers']!=dict(invariant='api',word='interface')or plan.get('external_facts')or
                plan['root_external_assumptions']!=json.loads((HERE/'interface-PLAN.json').read_text())['root_external_assumptions']):
            raise ValueError('Changed payload induction/provider substitution or unclosed word premise')
        return rules
    if plan['schema']=='Typed-cache-parent-interface-application-v1':
        from build_interface import specification,body_files,provider
        rules,declarations=specification();descriptor,_=provider()
        if (plan['rules']!=rules or plan['order']!=list(rules) or plan['declarations']!=declarations or
                plan['bodies']!=body_files() or plan['providers']!=dict(parent='api',cache_order='cacheorder',memory='interface/PROVIDER.json') or
                plan['root_external_assumptions']!=descriptor['boundaries'] or plan.get('external_facts')):
            raise ValueError('Changed literal source/history/provider substitution or an unclosed interface premise')
        return rules
    if plan['schema'] != 'Typed-native-history-induction-v1':
        raise ValueError('Unsupported proof rule')
    d=plan['induction'];top=d['top']
    if d['external_assumptions']:
        raise ValueError('This induction rule permits no unclosed external/data premise')
    # These are the literal formulas consumed and produced by the rule.
    n=lambda s:f'(|{top}_n {d["reset"]}| {s})'
    h=lambda s:f'(|{top}_h| {s})'
    t=f'(|{top}_t| a an)';inv=d['invariant']
    init=[f'(|{top}_i| a)']if d.get('compiler_initial_configuration')else []
    expected={
        'reset-base':dict(assumptions=init+[h('a'),h('an'),t,'(not '+n('a')+')'],conclusion=f'({inv} an {d["zero"]})'),
        'preserved':dict(assumptions=[h('a'),h('an'),t,f'({inv} a h)',f'(= hn {d["next"]})'],conclusion=f'({inv} an hn)'),
        'consequence':dict(assumptions=[h('a'),f'({inv} a h)',n('a')],conclusion=conjunction(d['root_goals'])),
        'reset-context':dict(assumptions=init+[h('a'),h('an'),t,'(not '+n('a')+')',n('an')],conclusion='false',expected='sat'),
    }
    parts=d.get('preserved_parts')
    if parts:
        if len(set(parts))!=len(parts):raise ValueError('Duplicate induction part')
        common=expected['preserved']['assumptions']
        expected={'reset-base':expected['reset-base'],
            **{'preserved-'+str(i):dict(assumptions=common,conclusion=part)for i,part in enumerate(parts)},
            'parts-join':dict(assumptions=parts,conclusion=f'({inv} an hn)'),
            'consequence':expected['consequence'],'reset-context':expected['reset-context']}
    if plan['rules'] != expected or plan['order'] != list(expected):
        raise ValueError('Literal induction premise/provider/state substitution is missing or changed')
    for r in plan['rules'].values():
        if r.get('dependencies'):
            raise ValueError('No implicit theorem imports in this rule')
    if plan.get('external_facts'):
        raise ValueError('No untyped theorem imports in this rule')
    return expected


def controls(plan):
    result={}
    cases={}
    if plan['schema']=='Typed-current-Q-operand-composition-v1':
        missing=copy.deepcopy(plan);missing['providers'].remove('macmodel');cases['missing-MAC-provider']=missing
        oracle=copy.deepcopy(plan);oracle['rules']['joined-theorem']['assumptions'].append('(= private_reply desired_word)');cases['unclosed-private-word-premise']=oracle
        wrong=copy.deepcopy(plan);wrong['rules']['joined-theorem']['conclusion']='(Q-operands-theorem an h w ch model)';cases['wrong-theorem-state']=wrong
        omitted=copy.deepcopy(plan);omitted['rules']['joined-theorem']['assumptions'].pop();cases['omitted-metadata-provider-application']=omitted
        for name,candidate in cases.items():
            try:shape(candidate)
            except (KeyError,ValueError):result[name]=dict(rejected=True,candidate_sha256=sha((json.dumps(candidate,sort_keys=True)+'\n').encode()),integrity_refreshed=True)
            else:raise ValueError('Accepted invalid Q composition: '+name)
        return result
    if plan['schema']=='Typed-cache-parent-interface-application-v1':
        from build_interface import specification
        missing=copy.deepcopy(plan);del missing['providers']['memory'];cases['missing-memory-provider']=missing
        wrong=copy.deepcopy(plan);wrong['rules']['value-to-layer']['assumptions'][-1]='(fixed-model-return c (c-service ch) slot u model)';cases['wrong-provider-selector']=wrong
        oracle=copy.deepcopy(plan);oracle['rules']['value-to-layer']['assumptions'].append('(= private_reply desired_word)');cases['unclosed-private-word-premise']=oracle
        omission=copy.deepcopy(plan);omission['rules']['common-step']['assumptions'].pop();cases['missing-history-equality']=omission
        result={}
        for name,candidate in cases.items():
            identity=sha((json.dumps(candidate,sort_keys=True)+'\n').encode())
            try:shape(candidate)
            except (ValueError,KeyError):result[name]=dict(rejected=True,candidate_sha256=identity,integrity_refreshed=True)
            else:raise ValueError('Accepted invalid interface application '+name)
        return result
    preservation=next(k for k in plan['rules']if k=='preserved'or k.startswith('preserved-'))
    missing=copy.deepcopy(plan);del missing['rules'][preservation];missing['order'].remove(preservation);cases['missing-induction-provider']=missing
    wrong=copy.deepcopy(plan);wrong['rules']['consequence']['assumptions'][1]=wrong['rules']['consequence']['assumptions'][1].replace(' a h)',' an h)').replace(' a ch)',' an ch)');cases['wrong-provider-state']=wrong
    oracle=copy.deepcopy(plan);oracle['rules']['consequence']['assumptions'].append('(= private_reply desired_word)');cases['unclosed-private-word-premise']=oracle
    if plan.get('induction',{}).get('preserved_parts'):
        omitted=copy.deepcopy(plan);omitted['rules']['parts-join']['assumptions']=omitted['rules']['parts-join']['assumptions'][1:];cases['omitted-part-from-join']=omitted
        badpart=copy.deepcopy(plan);badpart['rules'][preservation]['conclusion']='true';cases['changed-preservation-part']=badpart
    if plan['schema']=='Typed-native-payload-refinement-v1':
        missingword=copy.deepcopy(plan);del missingword['providers']['word'];cases['missing-word-provider']=missingword
        wrongword=copy.deepcopy(plan);wrongword['rules']['preserved']['assumptions'][-1]='(interface-word-to-layer an h model)';cases['wrong-word-provider-state']=wrongword
    if plan['schema']=='Typed-native-reader-refinement-v1':
        missingword=copy.deepcopy(plan);del missingword['providers']['word'];cases['missing-word-provider']=missingword
        wrongword=copy.deepcopy(plan);wrongword['rules']['consequence']['assumptions'][-1]='(reader-job-service an h model)';cases['wrong-word-provider-state']=wrongword
    if plan['schema']in['Typed-native-Q-word-packing-v1','Typed-native-Q-metadata-header-v1']:
        missingword=copy.deepcopy(plan);del missingword['providers']['reader'];cases['missing-reader-provider']=missingword
        wrongword=copy.deepcopy(plan);prefix='header'if plan['schema']=='Typed-native-Q-metadata-header-v1'else'words'
        wrongword['rules'][preservation]['assumptions'][5]=f'({prefix}-reader-service an h model)';cases['wrong-word-provider-state']=wrongword
        omitted=copy.deepcopy(plan);omitted['rules']['parts-join']['assumptions']=omitted['rules']['parts-join']['assumptions'][1:];cases['omitted-part-from-join']=omitted
    if plan['schema']=='Typed-native-Q-tile-metadata-v1':
        missing=copy.deepcopy(plan);missing['providers'].remove('header');cases['missing-header-provider']=missing
        wrong=copy.deepcopy(plan);wrong['rules'][preservation]['assumptions'][5]='(header-inv an h model)';cases['wrong-header-provider-state']=wrong
        omitted=copy.deepcopy(plan);omitted['rules']['parts-join']['assumptions'].pop();cases['omitted-part-from-join']=omitted
    # Each candidate has its ordinary JSON hash recomputed. No stale-integrity
    # rejection supplies these controls; shape() must reject the logical rule.
    for name,candidate in cases.items():
        candidate_hash=sha((json.dumps(candidate,sort_keys=True)+'\n').encode())
        try:shape(candidate)
        except ValueError:result[name]=dict(rejected=True,candidate_sha256=candidate_hash,integrity_refreshed=True)
        else:raise ValueError('Accepted invalid derivation '+name)
    return result


def check(label,recorded=False):
    filename=label+'-PLAN.json';plan=validate(HERE,filename);shape(plan)
    fullbody='\n'.join((HERE/n).read_text()for n in plan['bodies'])
    known=set(re.findall(r'\((?:define-fun|declare-fun|declare-sort)\s+(\|[^|]+\|)',fullbody))
    referenced=set(re.findall(r'\((\|[^|]+\|)',fullbody+'\n'+json.dumps(plan['rules'])+'\n'+'\n'.join(plan.get('observations',[]))))
    if referenced-known:raise ValueError('Unbound native SMT function(s): '+str(sorted(referenced-known)))
    source=json.loads((HERE/plan['source_manifest']).read_text())
    interface=plan['schema']=='Typed-cache-parent-interface-application-v1'
    payload=plan['schema']=='Typed-native-payload-refinement-v1'
    reader=plan['schema']=='Typed-native-reader-refinement-v1'
    words=plan['schema']=='Typed-native-Q-word-packing-v1'
    header=plan['schema']=='Typed-native-Q-metadata-header-v1'
    tilemeta=plan['schema']=='Typed-native-Q-tile-metadata-v1'
    parentcapture=plan['schema']=='Typed-parent-native-capture-induction-v1'
    macmodel=plan['schema']=='Typed-native-Q-MAC-model-v1'
    composition=plan['schema']=='Typed-current-Q-operand-composition-v1'
    if composition:
        from build_q_composition import definitions,conclusions,PROVIDERS
        if (HERE/'qcomposition/history.smt2').read_text()!=definitions()or(HERE/'qcomposition/conclusions.smt2').read_text()!=conclusions():raise ValueError('Changed joined Q theorem')
        for provider in PROVIDERS:check(provider,recorded)
    if macmodel:
        from operand_step import verify
        verify()
        from build_mac_model import definitions
        if (HERE/'macmodel/history.smt2').read_text()!=definitions()[0]:raise ValueError('Changed MAC model/activation invariant')
        for provider in ['api','reader','words','parentcapture']:check(provider,recorded)
    if parentcapture:
        from operand_step import verify
        verify()
        from build_parent_capture import definitions
        if (HERE/'parentcapture/history.smt2').read_text()!=definitions():raise ValueError('Changed actual-parent capture substitution')
    if tilemeta:
        from operand_step import verify
        verify()
        from build_tile_metadata import definitions
        if (HERE/'tilemeta/history.smt2').read_text()!=definitions()[0]:raise ValueError('Changed tile metadata invariant')
        from freeze_metadata_targets import definitions as targets
        if (HERE/'METADATA-TARGETS.smt2').read_text()!=targets()[0]:raise ValueError('Changed tile metadata target')
        # Targets are separately frozen and pinned; provider theorems retain
        # their own exact native reset/step/consequence engine receipts.
        for provider in ['api','reader','words','header','parentcapture']:check(provider,recorded)
    if header:
        from operand_step import verify
        verify()
        from build_header import definitions
        if (HERE/'header/history.smt2').read_text()!=definitions()[0]:raise ValueError('Changed metadata header property or reader theorem substitution')
        check('api',recorded);check('reader',recorded)
    if words:
        from operand_step import verify
        verify()
        from build_words import definitions
        if (HERE/'words/history.smt2').read_text()!=definitions()[0]:raise ValueError('Changed word-packing property or reader theorem substitution')
        check('api',recorded);check('reader',recorded)
    if reader:
        from build_reader import definitions
        if (HERE/'reader/history.smt2').read_text()!=definitions()[0]:raise ValueError('Changed reader properties or imported job-service conclusion')
        check('api',recorded);check('payload',recorded)
    if payload:
        from build_payload import definitions,imported_word
        if (HERE/'payload/history.smt2').read_text()!=definitions()or (HERE/'payload/imported-word.smt2').read_text()!=imported_word():raise ValueError('Changed payload property or imported proved word predicate')
        check('api',recorded);check('interface',recorded)
    if interface:
        from build_interface import provider,binding_source,definitions
        from build_cache_order import cache_source
        descriptor,valuebody=provider()
        if ((HERE/'interface/published-value.smt2').read_text()!=valuebody or
                json.loads((HERE/'interface/PROVIDER.json').read_text())!=descriptor or
                json.loads((HERE/'interface/BINDINGS.json').read_text())!=binding_source() or
                (HERE/'interface/history.smt2').read_text()!=definitions()):raise ValueError('Interface definition/provider binding changed')
        if cache_source()!=json.loads((HERE/'cache-SOURCES.json').read_text()):raise ValueError('Changed interface cache source')
        # Require complete native reset/step certificates, in their own exact
        # native contexts. These invariants are trace theorems, not free data
        # assumptions at an internal reply port.
        check('api',recorded);check('cacheorder',recorded)
    if source.get('kind')=='qualified-control-overapproximation':
        from build_semantic_window import verify_source
        if verify_source()!=source:raise ValueError('Changed source-bound control projection')
    elif source.get('kind')=='restored-native-projection-parent':
        from build_connected_parent import reconstruct
        files,expected=reconstruct()
        if any(source[k]!=v for k,v in expected.items()):raise ValueError('Changed actual parent/producer reconstruction')
        for name,data in files.items():
            if (HERE/'connected'/name).read_bytes()!=data or source['files'][name]!=sha(data):raise ValueError('Restored parent source changed')
        if sha((HERE/'connected/native.smt2').read_bytes())!=source['native_smt_sha256']:raise ValueError('Restored model changed')
    elif source.get('kind')=='native-cache-reuse':
        from build_cache_order import cache_source
        if cache_source()!=source:raise ValueError('Changed qualified native cache or readonly histories')
    else:
        selection={p:r['modules']for p,r in source['sources'].items()}
        require_exact((HERE/plan.get('native_source',label+'/native.sv')).read_text(),selection)
    # History files contain definitions only, not a second driving circuit or
    # hidden assert/assume command. The native RTL contains no formal cells.
    history=(HERE/label/'history.smt2').read_text()
    if re.search(r'\((?:assert|check-sat|push|pop|declare-const|declare-fun)\b',history):
        raise ValueError('History may contain only total datatype/function definitions')
    depth=0
    for c in re.sub(r'\|[^|]*\|','symbol',history):
        depth+=(c=='(')-(c==')')
        if depth<0:raise ValueError('Malformed history syntax')
    if depth:raise ValueError('Malformed history syntax')
    result=dict(passed=True,structural_rule_valid=True,recorded_engines_checked=False,
        root_external_assumptions=plan.get('root_external_assumptions',[]),rule='Native serializer, resetless tile memory and valid-tag provenance induction'if tilemeta else'Native accepted-prefix induction in resetless metadata row memories'if header else'Native word/beat history induction using closed reader-value trace theorem'if words else'Native reader ownership/address induction using closed API/job-service trace theorems'if reader else'Native payload induction using closed API/word trace theorems'if payload else'Common-event history induction and literal qualified trace-theorem application'if interface else'Common-reset initialization plus unrestricted native transition/history induction, then consequence',
        scoped_claim='All Q metadata rows at tile capture/read and postscale coefficient ports'if tilemeta else'All 64 published Q metadata header rows have their current model values'if header else'Actual Q held coefficient beat and all tile-capture coefficient inputs have their model values'if words else'Actual Q packer and metadata response consumes carry their fixed-model words'if reader else'Actual projection-job model reply equals its corresponding accepted request model word'if payload else'Published fixed-model word at the actual layer-response FIFO input, with exact accepted-address history'if interface else 'Q operand theorem'if composition else 'Q MAC model provenance'if macmodel else 'Native parent capture'if parentcapture else plan['induction']['claim'],whole_Q_consumption_proved=False,whole_machine_theorem=False,
        logical_controls=controls(plan))
    if recorded:
        checks=json.loads((HERE/plan['checks_file']).read_text())
        if checks['plan_sha256']!=sha((HERE/filename).read_bytes()):raise ValueError('Stale engine evidence')
        body=fullbody
        for name,r in plan['rules'].items():
            evidence=checks['rules'][name];receipt=HERE/evidence['receipt'];engine=receipt.parent/'query.smt2';log=receipt.parent/evidence.get('engine_log','z3.log')
            expected=r.get('expected','unsat');exact=query(plan,name,body).encode()
            if not evidence['passed']or engine.read_bytes()!=exact or log.read_text().strip()!=expected or sha(exact)!=evidence['query_sha256']or sha(log.read_bytes())!=evidence['log_sha256']:
                raise ValueError('Missing/changed exact engine result: '+name)
            actual=engine
            if evidence.get('solver')=='cvc5':
                from smtlib import standard_datatypes
                translated=standard_datatypes(exact.decode()).encode();actual=receipt.parent/'query.cvc5.smt2'
                if evidence.get('normalization')!='standard-zero-parameter-datatypes-v1'or actual.read_bytes()!=translated or evidence.get('engine_query_sha256')!=sha(translated):raise ValueError('Changed standardized cvc5 query')
            if Path(evidence['command'][-1]).resolve()!=actual.resolve():raise ValueError('Solver command did not name its exact recorded query')
        result['recorded_engines_checked']=True
        if interface:result['cache_value_import_logically_closed']=True
        if payload:result['projection_job_value_service_proved']=True
        if reader:result['Q_reader_model_words_proved']=True
        if words:result['Q_word_to_tile_capture_model_values_proved']=True
        if header:result['Q_metadata_header_model_values_proved']=True
        if tilemeta:result['Q_metadata_tile_capture_read_postscale_proved']=True
        if macmodel:result['Q_fixed_model_and_activation_at_MAC_use_proved']=True
        if composition:result['Q_operand_provenance_theorem_proved']=True
    if parentcapture:
        result.update(rule='Fresh native-parent reset/history induction after literal reviewed property substitution',scoped_claim='Current accepted activation and coefficient capture at all 64 actual MAC input ports')
    if macmodel:
        result.update(rule='Native registered-operand provenance induction with all 640 bits and complete slice join',scoped_claim='Fixed Q model coefficients and matching current accepted activation at every actual MAC multiplication input')
    if composition:
        result.update(rule='Literal closed-provider application at the common native state and accepted histories',scoped_claim='Baseline Q operand provenance: model coefficients, current accepted activations and metadata at actual use')
    write_json(HERE/(label+'-DERIVATION.json'),result)
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('label',choices=['owner','packer','fifo19','fifo1','job','window','capture','group','caller','transport','ordered','metadata','cacheorder','api','interface','payload','reader','words','header','tilemeta','parentcapture','macmodel','qcomposition']);ap.add_argument('--recorded',action='store_true');a=ap.parse_args()
    print(json.dumps(check(a.label,a.recorded),indent=2))

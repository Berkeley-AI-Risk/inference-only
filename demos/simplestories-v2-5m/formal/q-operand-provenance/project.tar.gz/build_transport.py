"""Candidate ordered-address conservation through the actual parent queues.

This first version proves ownership only. It imports no cache-data premise and
does not establish fixed-model values. All histories are total SMT functions;
the restored parent still contains the full native projection consumer.
"""
import json
from source_policy import HERE, write_json
from build_initial import finish, conj, bv

TOP='core_workflow_control'; S='|'+TOP+'_s|'
A='u_native.u_private_ddr_arbiter.'
R='u_native.u_layer_model_request_queue.'
B='u_native.u_layer_model_response_queue.'
D='u_native.u_six_layers.u_datapath.'
J=D+'u_projection.'
n=lambda x:f'(|{TOP}_n {x}| a)'
ADDR='(_ BitVec 19)'; AS='(Seq '+ADDR+')'; CS='(Seq CacheRecord)'
empty=lambda typ:'(as seq.empty '+typ+')'
tail=lambda x:f'(ite (> (seq.len {x}) 0) (seq.extract {x} 1 (- (seq.len {x}) 1)) {x})'
pop=lambda x,event:f'(ite {event} {tail(x)} {x})'
push=lambda x,event,item:f'(ite {event} (seq.++ {x} (seq.unit {item})) {x})'
integer=lambda x:f'(bv2int {x})'


def main():
    cache='(t-cache h)';layer='(t-layer h)';proj='(t-proj h)'
    cp=n(A+'request_transfer');cr=n(A+'response_transfer')
    rp=n(R+'push');br=n(B+'pop')
    jp=f'(and {n(J+"private_word_req_valid_o")} {n(J+"private_word_req_ready_i")})'
    jr=f'(and {n(J+"private_word_rsp_valid_i")} {n(J+"private_word_rsp_ready_o")})'
    child=n('u_native.child_reset_n')
    chead=f'(seq.nth {cache} 0)'
    nextcache=push(pop(cache,cr),cp,f'(cache-record {n(A+"layer_req_valid_i")} {n(A+"private_req_index_o")})')
    nextlayer=push(pop(layer,br),rp,n(R+'in_addr_i'))
    nextproj=push(pop(proj,jr),jp,n(J+'private_word_req_index_o'))
    slots=[f'(ite (and {child} {n(B+"push")} (= {n(B+"wr_ptr_q")} {str(bool(i)).lower()})) (cache-address {chead}) (t-rsp{i} h))'for i in range(2)]
    defs='(declare-datatypes () ((CacheRecord (cache-record (cache-layer Bool) (cache-address '+ADDR+')))))\n'
    defs+='(declare-datatypes () ((TransportHistory (transport-history (t-cache '+CS+') (t-layer '+AS+') (t-proj '+AS+') (t-rsp0 '+ADDR+') (t-rsp1 '+ADDR+')))))\n'
    defs+=f'(define-fun transport-zero () TransportHistory (transport-history {empty(CS)} {empty(AS)} {empty(AS)} {bv(0,19)} {bv(0,19)}))\n'
    defs+=f'(define-fun transport-next ((a {S}) (h TransportHistory)) TransportHistory (ite (not {n("reset_n")}) transport-zero (transport-history {nextcache} (ite {child} {nextlayer} {empty(AS)}) (ite {child} {nextproj} {empty(AS)}) '+ ' '.join(slots)+')))\n'
    # Native two-entry queues are preserved, including simultaneous push/pop.
    def queue(prefix,slot):
        count=n(prefix+'count_q');rd=n(prefix+'rd_ptr_q')
        head=f'(ite {rd} {slot(1)} {slot(0)})';second=f'(ite {rd} {slot(0)} {slot(1)})'
        return f'(ite (= {count} #b00) {empty(AS)} (ite (= {count} #b01) (seq.unit {head}) (seq.++ (seq.unit {head}) (seq.unit {second}))))'
    req=queue(R,lambda i:n(R+f'addr_q[{i}]'))
    rsp=queue(B,lambda i:f'(t-rsp{i} h)')
    filtered='(seq.++ '+' '.join(f'(ite (and (< {i} (seq.len {cache})) (cache-layer (seq.nth {cache} {i}))) (seq.unit (cache-address (seq.nth {cache} {i}))) {empty(AS)})'for i in range(16))+')'
    defs+=f'(define-fun transport-layer-cache ((h TransportHistory)) {AS} {filtered})\n'
    alive=f'(not {n(A+"fail_q")})'
    clauses={}
    clauses['cache-count']=f'(= (seq.len {cache}) {integer(n(A+"owner_count_q"))})'
    clauses['cache-bound']=f'(<= (seq.len {cache}) 16)'
    clauses['cache-pointers']=f'(= {n(A+"owner_write_pointer_q")} (bvadd {n(A+"owner_read_pointer_q")} ((_ extract 3 0) {n(A+"owner_count_q")})))'
    for i in range(16):
        at=f'(bvadd {n(A+"owner_read_pointer_q")} {bv(i,4)})'
        bit=f'(= ((_ extract 0 0) (bvlshr {n(A+"owner_fifo_q")} ((_ zero_extend 12) {at}))) #b1)'
        clauses[f'owner-{i}']=f'(=> (< {i} (seq.len {cache})) (= {bit} (cache-layer (seq.nth {cache} {i}))))'
    release=n('u_native.machine_release_q')
    clauses['release-domain']=f'(or (= {release} #b00) (= {release} #b01) (= {release} #b11))'
    clauses['release-lock-seen']=f'(=> (distinct {release} #b00) {n(A+"lock_seen_q")})'
    local=[]
    for prefix in [R,B]:
        count=n(prefix+'count_q');rd=n(prefix+'rd_ptr_q');wr=n(prefix+'wr_ptr_q')
        local+=[f'(bvule {count} #b10)',f'(= {wr} (xor {rd} (= ((_ extract 0 0) {count}) #b1)))']
    pending=n(D+'ddr_pending_q');owner=n(D+'ddr_owner_q')
    local += [f'(bvule {pending} #x8)',f'(= (= {owner} #b00) (= {pending} #x0))',f'(distinct {owner} #b11)',f'(=> (= {owner} #b10) (= {pending} #x1))']
    local += [f'(= (seq.len {layer}) {integer(pending)})',f'(= {layer} (seq.++ {rsp} (transport-layer-cache h) {req}))',
              f'(ite (= {owner} #b01) (= {proj} {layer}) (= {proj} {empty(AS)}))']
    clauses['local']=f'(=> (and {alive} {child}) {conj(local)})'
    clauses['child-reset-empty']=f'(=> (and {alive} (not {child})) (and (= {n(R+"count_q")} #b00) (= {n(B+"count_q")} #b00) (= {layer} {empty(AS)}) (= {proj} {empty(AS)}) (= (transport-layer-cache h) {empty(AS)})))'
    for prefix in [R,B]:
        if prefix==B:
            for i in range(2):
                # Position is live iff queue count includes the corresponding
                # physical slot; no claim is made about retired payloads.
                active=f'(or (= {n(B+"count_q")} #b10) (and (= {n(B+"count_q")} #b01) (= {n(B+"rd_ptr_q")} {str(bool(i)).lower()})))'
                clauses[f'fault-free-{i}']=f'(=> (and {alive} {child} {active}) (not {n(B+f"write_q[{i}]")}))'
    defs+='\n'.join(f'(define-fun transport-clause-{i} ((a {S}) (h TransportHistory)) Bool {value})'for i,value in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun transport-inv ((a {S}) (h TransportHistory)) Bool (and (|{TOP}_i| a) (=> {n("reset_n")} '+conj([f'(transport-clause-{i} a h)'for i in range(len(clauses))])+')))\n'
    goals=[f'(=> (and {alive} {child} {jr}) (and (> (seq.len {proj}) 0) (not {n(J+"private_word_rsp_fault_i")})))']
    m=json.loads((HERE/'connected-SOURCES.json').read_text())
    finish('transport',TOP,defs,'transport-inv','transport-zero','(transport-next a h)',goals,m,initial_configuration=True,native_label='connected')
    plan=json.loads((HERE/'transport-PLAN.json').read_text())
    plan['observations']=[n(k)for k in ['reset_n','u_native.child_reset_n','u_native.machine_release_q',A+'fail_q',A+'terminal_now',A+'lock_seen_q',A+'request_transfer',A+'response_transfer',A+'owner_count_q',R+'push',R+'pop',R+'count_q',B+'push',B+'pop',B+'count_q',D+'ddr_pending_q',D+'ddr_owner_q']]+['h','hn']+[f'(transport-clause-{i} an hn)'for i in range(len(clauses))]
    write_json(HERE/'transport-PLAN.json',plan);write_json(HERE/'transport/CLAUSES.json',dict(enumerate(clauses)))
    print('Frozen actual-parent ordered-address conservation candidate; no fixed-model data premise or theorem claim.')


if __name__=='__main__':main()

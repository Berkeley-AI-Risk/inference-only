"""Reprove the complete activation/MAC history in the actual parent instance.

This is a literal accessor/type substitution of the already reviewed native job
properties, followed by fresh reset/step/consequence queries in the parent RTL.
No correspondence between two unconstrained state sorts is assumed.
"""
import json,re
from source_policy import HERE,sha,write_json
from build_initial import conj
from build_ordered import TOP,S,J,n

OLD='board1_fixed_group_projection_scale_job'


def translate(text):
    text=text.replace('|'+OLD+'_s|',S)
    text=re.sub(r'\|'+OLD+r'_(n|m) ([^|]+)\|',lambda m:'|'+TOP+'_'+m[1]+' '+J+m[2]+'|',text)
    for suffix in ['i','h','t']:text=text.replace('|'+OLD+'_'+suffix+'|','|'+TOP+'_'+suffix+'|')
    if OLD in text:raise ValueError('Unmapped standalone job symbol')
    return text


def definitions():
    return translate((HERE/'job/history.smt2').read_text()+'\n'+(HERE/'capture/history.smt2').read_text())


def specification():
    old=json.loads((HERE/'capture-PLAN.json').read_text())
    h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    rules={'native-step-weakening':dict(assumptions=[h('a'),h('an'),t],conclusion='(operand-native-step a an)'),
        'reset-base':dict(assumptions=initial,conclusion='(capture-inv an (capture-zero an))'),
        'preserved':dict(assumptions=[h('a'),h('an'),'(operand-native-step a an)','(capture-inv a ch)','(= chn (capture-next a ch))'],conclusion='(capture-inv an chn)'),
        'consequence':dict(assumptions=[h('a'),'(capture-inv a ch)',n('reset_n')],conclusion=translate(conj(old['induction']['root_goals'])).replace(' h)',' ch)')),
        'reset-context':dict(assumptions=initial+[n('reset_n').replace(' a)',' an)')],conclusion='false',expected='sat')}
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)']
    return rules,declarations


def body_files():return ['connected/native.smt2','operand-step.smt2','parentcapture/history.smt2']


def main():
    d=HERE/'parentcapture';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(definitions())
    rules,declarations=specification();bodies=body_files();files=[*bodies,'connected-SOURCES.json','OPERAND-STEP.json','job/history.smt2','capture/history.smt2','capture-PLAN.json']
    write_json(HERE/'parentcapture-PLAN.json',dict(schema='Typed-parent-native-capture-induction-v1',source_manifest='connected-SOURCES.json',inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),checks_file='parentcapture-CHECKS.json',providers=[],root_external_assumptions=[],whole_Q_consumption_proved=False,whole_machine_theorem=False,
        observations=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',J+'reset_n',J+'state_q',J+'job_q',J+'integrated_fail']]))
    print('Frozen fresh native-parent activation and MAC capture induction.')


if __name__=='__main__':main()

"""A literal weakening of native T for operand/storage properties.

Only numerical MAC primitive register-update conjuncts are omitted. Their
current/next arithmetic values become less constrained; all native source,
operand payload/tag updates, routing, control and RAM equations remain. Each
using plan also proves native T implies this weaker premise. Thus this is not
an arithmetic correctness theorem or a substituted correct-output promise.
"""
from source_policy import HERE,sha,write_json
from build_ordered import TOP,S


def definition():
    source=(HERE/'connected/native.smt2').read_text()
    start=source.index('(define-fun |'+TOP+'_t|')
    end=source.index(')) ; end of module '+TOP,start)+2
    native=source[start:end]
    if not native.endswith('))'):raise ValueError('Unsupported native T layout')
    lines=native.splitlines();kept=[];omitted=[]
    for line in lines[1:]:
        # Yosys writes each flat register transition on one balanced line,
        # followed by its source register path. Restrict the omission to the
        # multiplier/accumulator primitive, never tile inputs or valid tags.
        comment=line.split(';',1)[1].strip()if';'in line else''
        if '.u_projection.u_shared_engine.u_engine.g_tile['in comment and'.g_lane['in comment and'.u_mac.'in comment:
            formula=line.split(';',1)[0].strip()
            if not formula.startswith('(= ')or formula.count('(')!=formula.count(')'):raise ValueError('Unsupported arithmetic update layout')
            omitted.append(line)
        else:kept.append(line)
    if len(omitted)!=128:raise ValueError('Native 64-MAC primitive recurrence inventory changed')
    first=lines[0].replace('|'+TOP+'_t|','operand-native-step')
    result='\n'.join([first,*kept])+'\n'
    return result,dict(native_transition_sha256=sha(native.encode()),omitted_conjuncts=omitted,
        omitted_count=len(omitted),retained_tile_payload_and_tag_updates=True,rule='Literal conjunction weakening, independently checked as native-T implication')


def install():
    text,manifest=definition();(HERE/'operand-step.smt2').write_text(text);write_json(HERE/'OPERAND-STEP.json',manifest)


def verify():
    text,manifest=definition()
    import json
    if (HERE/'operand-step.smt2').read_text()!=text or json.loads((HERE/'OPERAND-STEP.json').read_text())!=manifest:raise ValueError('Operand transition weakening changed')


if __name__=='__main__':install()

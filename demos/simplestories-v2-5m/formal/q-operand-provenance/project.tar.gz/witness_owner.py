"""Native owner-routing witness and actual-only cross-owner defect control."""
import argparse,subprocess
from source_policy import HERE,sha,write_json

BENCH=r'''
module tb;
 reg clk=0;always #5 clk=~clk;
 reg reset_n=0;integer cycle=0,admitted=0,retired=0;
 wire layer=(admitted%3!=1),offer=admitted<64 && cycle%4!=1;
 wire sv,lv,sr,lr,req,ready,fail;wire[255:0]sd,ld;
 wire response=retired<admitted && cycle>20 && cycle%3!=1;
 wire [255:0]payload=256'(retired+12345);
 board1_fixed_private_ddr_arbiter #(.ADDR_W(19),.MODEL_WORDS(227062),.OWNER_DEPTH(16)) dut(
 .clk(clk),.reset_n(reset_n),.model_locked_i(1'b1),.upstream_fail_closed_i(1'b0),.endpoint_fail_closed_i(1'b0),
 .shell_req_valid_i(offer&&!layer),.shell_req_ready_o(sr),.shell_req_index_i(19'(admitted)),
 .layer_req_valid_i(offer&&layer),.layer_req_ready_o(lr),.layer_req_index_i(19'(admitted)),
 .shell_rsp_valid_o(sv),.shell_rsp_ready_i(1'b1),.shell_rsp_data_o(sd),.shell_rsp_fault_o(),
 .layer_rsp_valid_o(lv),.layer_rsp_ready_i(1'b1),.layer_rsp_data_o(ld),.layer_rsp_fault_o(),
 .private_req_valid_o(req),.private_req_ready_i(cycle%5!=0),.private_req_index_o(),
 .private_rsp_valid_i(response),.private_rsp_ready_o(ready),.private_rsp_data_i(payload),.private_rsp_fault_i(1'b0),.busy_o(),.fail_closed_o(fail));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(reset_n)begin
   if(req && cycle%5!=0)admitted<=admitted+1;
   if(response && ready)begin
    if((lv!==(retired%3!=1)) || (sv!==(retired%3==1)) ||
       (lv&&ld!==payload) || (sv&&sd!==payload))$fatal(1,"cross-owner response");
    retired<=retired+1;
   end
   if(fail)$fatal(1,"unexpected owner fault");
   if(retired==64)begin $display("PASS: 64 mixed-owner requests, wraparound, stalls and simultaneous admission/retirement");$finish;end
  end
  if(cycle>2000)$fatal(1,"owner timeout");
 end
 initial begin repeat(3)@(negedge clk);reset_n=1;end
endmodule
'''


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--defect',action='store_true');args=ap.parse_args()
    d=HERE/'owner-controls'/('cross-owner'if args.defect else'operating');d.mkdir(parents=True,exist_ok=False)
    source=(HERE/'owner/native.sv').read_text()
    if args.defect:
        before='owner_fifo_q[owner_write_pointer_q] <= layer_req_valid_i ?';after='owner_fifo_q[owner_write_pointer_q] <= !layer_req_valid_i ?'
        if source.count(before)!=1:raise ValueError('Changed actual defect site')
        source=source.replace(before,after,1)
    (d/'native.sv').write_text(source);(d/'tb.sv').write_text(BENCH)
    with (d/'compile.log').open('w')as log:p=subprocess.run(['iverilog','-g2012','-s','tb','-o','sim','native.sv','tb.sv'],cwd=d,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    if p.returncode:raise ValueError('Owner fixture compile failed')
    with (d/'simulation.log').open('w')as log:p=subprocess.run(['vvp','sim'],cwd=d,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    raw=(d/'simulation.log').read_text();passed=p.returncode!=0 and'cross-owner response'in raw if args.defect else p.returncode==0 and'PASS:'in raw
    write_json(d/'RESULT.json',dict(passed=passed,finite_operating_evidence=True,actual_only_defect=args.defect,native_sha256=sha(source.encode()),bench_sha256=sha(BENCH.encode()),log_sha256=sha(raw.encode()),exit_code=p.returncode))
    print(raw.strip())
    if not passed:raise SystemExit(1)


if __name__=='__main__':main()

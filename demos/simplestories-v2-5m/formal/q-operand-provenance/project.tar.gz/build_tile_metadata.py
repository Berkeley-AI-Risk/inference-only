"""Current Q metadata through native serializer, tile RAM and postscale ports.

All memories and pipeline registers are the frozen production instances. The
invariant qualifies resetless payload by its actual owning phase/valid tag.
"""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,J,n
from build_reader import G
from freeze_metadata_targets import E

D=J+'u_shared_engine.'


def definitions():
    model='(Array (_ BitVec 18) (_ BitVec 256))'
    state=lambda p,vs:'(or '+' '.join(f'(= {n(p+"state_q")} {bv(v,3)})'for v in vs)+')'
    normal=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),'(not '+n(J+'integrated_fail')+')'])
    q=f'(= {n(J+"job_q")} {bv(0,4)})'
    active=state(E,[1,2,3,4,5]);meta=state(E,[1]);complete=state(E,[2,3,4,5]);emit=state(E,[4])
    base=f'(bvadd {bv(211920,19)} (bvadd (bvmul ((_ zero_extend 16) {n(J+"layer_q")}) {bv(304,19)}) (bvmul ((_ zero_extend 13) {n(J+"group_q")}) {bv(8,19)})))'
    rec=lambda lane:f'(model-Q-metadata-record model {base} {lane})'
    exp=lambda r:f'(bvsub (bvadd ((_ sign_extend 3) {n(J+"activation_exponent_q")}) ((_ sign_extend 3) ((_ extract 7 0) {r}))) {bv(15,11)})'
    metadata=n(E+'metadata_count_q')
    tag=lambda i:f'(= ((_ extract {i} {i}) {n(E+"scale_valid_q")}) #b1)'
    helpers={
        'engine-parent':f'(=> {active} '+conj([state(J,[3]),state(D,[1,2,3]),f'(= {n(E+"group_q")} {n(J+"group_q")})',f'(= {n(E+"activation_exponent_q")} {n(J+"activation_exponent_q")})'])+')',
        'adapter-parent':f'(=> {state(D,[1,2,3])} '+conj([state(J,[3]),*[f'(= {n(D+k+"_q")} {n(J+k+"_q")})'for k in ['layer','job','group','activation_exponent']]])+')',
        'metadata-phase':f'(=> {meta} '+conj([state(D,[1]),state(G,[3]),f'(= ((_ zero_extend 1) {n(D+"metadata_lane_q")}) {metadata})'])+')',
        'complete-phase':f'(=> {complete} {state(D,[2,3])})',
        'engine-retired':f'(=> {n(J+"engine_done_seen_q")} {state(E,[0])})',
        'q-geometry':f'(=> (and {q} {active}) '+conj([f'(= {n(E+"valid_lanes_q")} {bv(64,7)})',f'(= {n(E+"columns_q")} {bv(256,10)})',f'(bvule {metadata} {bv(63,7)})'])+')',
        'q-issue-bound':f'(=> (and {q} {active}) (bvule {n(E+"issue_count_q")} {bv(64,7)}))',
        'preemit-tags':f'(=> {state(E,[1,2,3])} (= {n(E+"scale_valid_q")} #x0))',
    }
    clauses=dict(helpers)
    for i in range(64):
        T=E+f'g_tile[{i//16}].u_tile.';slot=bv(i%16,4);r=rec(bv(i,6));ex=exp(r)
        owned=conj([q,active,f'(or {complete} (bvult {bv(i,7)} {metadata}))'])
        values=[f'(= (select (|{TOP}_m {T}multiplier_q| a) {slot}) ((_ extract 23 8) {r}))',f'(= (select (|{TOP}_m {T}exponent_q| a) {slot}) ((_ extract 7 0) {ex}))',f'(bvsge {ex} {bv(1920,11)})',f'(bvsle {ex} {bv(127,11)})']
        clauses[f'owned-row-{i}']=f'(=> {owned} {conj(values)})'
    row0=n(E+'row_pipe_q[0]');row1=n(E+'row_pipe_q[1]')
    readvalues=[f'(= {n(E+"selected_tile_q")} ((_ extract 5 4) {row0}))']
    for tile in range(4):
        T=E+f'g_tile[{tile}].u_tile.';r=rec(f'(concat {bv(tile,2)} ((_ extract 3 0) {row0}))')
        readvalues +=[f'(= {n(T+"multiplier_o")} ((_ extract 23 8) {r}))',f'(= {n(T+"exponent_o")} ((_ extract 7 0) {exp(r)}))']
    clauses['read-pipeline']=f'(=> (and {q} {emit} {tag(0)}) {conj(readvalues)})'
    r=rec(row1)
    clauses['scale-pipeline']=f'(=> (and {q} {emit} {tag(1)}) '+conj([f'(= {n(E+"scale_operand_q")} ((_ zero_extend 2) ((_ extract 23 8) {r})))',f'(= {n(E+"exponent_pipe_q[1]")} ((_ extract 7 0) {exp(r)}))'])+')'
    defs='\n'.join(f'(define-fun tilemeta-clause-{i} ((a {S}) (model {model})) Bool {v})'for i,v in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun tilemeta-inv ((a {S}) (model {model})) Bool (=> {normal} '+conj([f'(tilemeta-clause-{i} a model)'for i in range(len(clauses))])+'))\n'
    return defs,clauses,normal


def specification():
    _,clauses,normal=definitions();h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    imports=['(api-inv a h)','(reader-inv a h)','(header-inv a h model)','(words-inv a h w model)','(capture-inv a ch)']
    step=[h('a'),h('an'),'(operand-native-step a an)',*imports,'(tilemeta-inv a model)']
    parts=[f'(=> {normal.replace(" a)"," an)")} (tilemeta-clause-{i} an model))'for i in range(len(clauses))]
    readindex=list(clauses).index('read-pipeline')
    readslot=f'((_ extract 3 0) {n(E+"row_pipe_q[0]").replace(" a)"," an)")})'
    readcases=[f'(=> (= {readslot} {bv(i,4)}) {parts[readindex]})'for i in range(16)]
    goals=[f'({name} a model)'for name in ['metadata-at-tile-capture','metadata-at-tile-read','metadata-at-postscale-input']]
    rules={'native-step-weakening':dict(assumptions=[h('a'),h('an'),t],conclusion='(operand-native-step a an)'),
        'reset-base':dict(assumptions=initial,conclusion='(tilemeta-inv an model)'),
        **{'read-slot-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(readcases)},
        **{'preserved-'+str(i):dict(assumptions=readcases if i==readindex else step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(tilemeta-inv an model)'),
        'consequence':dict(assumptions=[h('a'),*imports,'(tilemeta-inv a model)',n('reset_n')],conclusion=conj(goals)),
        'reset-context':dict(assumptions=initial+[n('reset_n').replace(' a)',' an)')],conclusion='false',expected='sat')}
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ApiHistory)','(declare-const w WordsHistory)','(declare-const ch CaptureHistory)','(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():return ['connected/native.smt2','operand-step.smt2','ordered/history.smt2','api/history.smt2','reader/history.smt2','words/history.smt2','header/history.smt2','parentcapture/history.smt2','METADATA-TARGETS.smt2','tilemeta/history.smt2']


def main():
    from freeze_metadata_targets import main as targets
    targets()
    defs,clauses,_=definitions();d=HERE/'tilemeta';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    rules,declarations=specification();bodies=body_files();files=[*bodies,'OPERAND-STEP.json','connected-SOURCES.json',*[x+'-PLAN.json'for x in ['api','reader','words','header','parentcapture']],'METADATA-TARGETS.json']
    bounds=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']
    write_json(HERE/'tilemeta-PLAN.json',dict(schema='Typed-native-Q-tile-metadata-v1',source_manifest='connected-SOURCES.json',inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),checks_file='tilemeta-CHECKS.json',providers=['api','reader','words','header','parentcapture'],root_external_assumptions=bounds,whole_Q_consumption_proved=False,whole_machine_theorem=False,
        observations=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',A+'fail_q',J+'integrated_fail',J+'state_q',J+'job_q',J+'group_q',J+'clear_i',J+'engine_done_seen_q',J+'stream_done_seen_q',G+'state_q',G+'group_valid_o',D+'state_q',D+'metadata_lane_q',E+'state_q',E+'metadata_count_q',E+'metadata_fire',E+'metadata_error',E+'issue_count_q',E+'scale_valid_q']]+[f'(tilemeta-clause-{i} an model)'for i in range(len(clauses))]))
    write_json(d/'CLAUSES.json',dict(enumerate(clauses)));print('Frozen native serializer/tile metadata candidate:',len(clauses),'parts')


if __name__=='__main__':main()

"""Joint native parent/API accepted-address history, without a data premise.

The old parent relation is included in this new invariant and proved again in
the larger history context. No unproved next-state invariant is assumed. The
canonical 128-ticket API argument history can then be compared with the cache's
identical accepted-event history at the actual common clock/reset boundary.
"""
import json
from source_policy import HERE,write_json
from build_initial import finish,conj,bv
from build_ordered import TOP,S,A,B,n


def main():
    parent='(a-parent h)';admit='(a-admit h)';retire='(a-retire h)';args='(a-arguments h)'
    request=n(A+'request_transfer');response=n(A+'response_transfer')
    increment=lambda x,e:f'(bvadd {x} (ite {e} {bv(1,7)} {bv(0,7)}))'
    defs='(declare-datatypes () ((ApiHistory (api-history (a-parent OrderedHistory) (a-admit (_ BitVec 7)) (a-retire (_ BitVec 7)) (a-arguments (Array (_ BitVec 7) (_ BitVec 18)))))))\n'
    defs+='(define-fun api-zero () ApiHistory (api-history ordered-zero '+bv(0,7)+' '+bv(0,7)+' ((as const (Array (_ BitVec 7) (_ BitVec 18))) '+bv(0,18)+')))\n'
    nextargs=f'(ite {request} (store {args} {admit} ((_ extract 17 0) {n(A+"private_req_index_o")})) {args})'
    defs+=f'(define-fun api-next ((a {S}) (h ApiHistory)) ApiHistory (ite (not {n("reset_n")}) api-zero (api-history (ordered-next a {parent}) {increment(admit,request)} {increment(retire,response)} {nextargs})))\n'
    count=n(A+'owner_count_q');rd=n(A+'owner_read_pointer_q');wr=n(A+'owner_write_pointer_q')
    clauses={
        'global-live-interval':f'(= ((_ zero_extend 2) {count}) (bvsub {admit} {retire}))',
        'global-write-ticket':f'(= {wr} ((_ extract 3 0) {admit}))',
        'global-read-ticket':f'(= {rd} ((_ extract 3 0) {retire}))',
    }
    for i in range(16):
        address=f'(select {args} (bvadd {retire} {bv(i,7)}))'
        slot=f'(bvadd {rd} {bv(i,4)})'
        clauses[f'accepted-address-{i}']=f'(=> (bvult {bv(i,5)} {count}) '+conj([f'(= (select (o-cache-address {parent}) {slot}) ((_ zero_extend 1) {address}))',f'(bvult {address} {bv(227062,18)})'])+')'
    alive=f'(not {n(A+"fail_q")})'
    defs+='\n'.join(f'(define-fun api-clause-{i} ((a {S}) (h ApiHistory)) Bool (=> {alive} {v}))'for i,v in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun api-inv ((a {S}) (h ApiHistory)) Bool (and (ordered-inv a {parent}) (=> {n("reset_n")} '+conj([f'(api-clause-{i} a h)'for i in range(len(clauses))])+')))\n'
    child=n('u_native.child_reset_n')
    head=f'(select {args} {retire})'
    layer=f'(select (o-address {parent}) (o-receive {parent}))'
    goals=[f'(=> (and {alive} {child} {n(B+"push")}) '+conj([f'(= (select (o-cache-address {parent}) {rd}) ((_ zero_extend 1) {head}))',
        f'(= {head} ((_ extract 17 0) {layer}))',f'(bvult {head} {bv(227062,18)})'])+')']
    oldcount=len(json.loads((HERE/'ordered/CLAUSES.json').read_text()))
    parts=[f'(|{TOP}_i| an)']+[f'(=> (|{TOP}_n reset_n| an) (ordered-clause-{i} an (a-parent hn)))'for i in range(oldcount)]
    parts +=[f'(=> (|{TOP}_n reset_n| an) (api-clause-{i} an hn))'for i in range(len(clauses))]
    manifest=json.loads((HERE/'connected-SOURCES.json').read_text())
    finish('api',TOP,defs,'api-inv','api-zero','(api-next a h)',goals,manifest,initial_configuration=True,native_label='connected',additional_bodies=['ordered/history.smt2'],preserved_parts=parts)
    plan=json.loads((HERE/'api-PLAN.json').read_text())
    plan['observations']=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',A+'fail_q',A+'terminal_now',A+'request_transfer',A+'response_transfer',A+'owner_count_q',A+'owner_read_pointer_q',A+'owner_write_pointer_q']]+['(a-admit h)','(a-retire h)','(a-admit hn)','(a-retire hn)']+[f'(api-clause-{i} an hn)'for i in range(len(clauses))]
    write_json(HERE/'api-PLAN.json',plan);write_json(HERE/'api/CLAUSES.json',dict(enumerate(clauses)))
    print('Frozen joint parent/API argument-history induction; fixed model data and cross-model history lifting still open.')


if __name__=='__main__':main()

"""Exact actual-wire/history/value joins at the cache/parent interface.

This is a trace-contract application of the qualified memory theorem, not a new
private-word oracle. Native invariants, common-event history equality and the
published conclusion must all be supplied at their literal state/selector
substitutions. Qualification remains false until all providers and joins pass.
"""
import json
import sys
from source_policy import HERE,PUBLIC,native_source,sha,write_json
from build_initial import conj
from build_ordered import TOP as ROOT,A,B,D,n
from build_cache_order import TOP as CACHE,OLD,cache_source
from freeze_bindings import CORE
sys.path.insert(0,str(HERE.parent))
from prepare_port_composition import ports

RS='|'+ROOT+'_s|';CS='|'+CACHE+'_s|'
cn=lambda x:f'(|{CACHE}_n {x}| c)'


def provider():
    import gzip
    context=json.loads((HERE/'PORTABLE-CONTEXT.json').read_text());upstream=PUBLIC.parents[1]/'formal/upstream-model-values'
    if sha((upstream/'PACKAGE.json').read_bytes())!=context['upstream_package_sha256']:raise ValueError('Published upstream packet changed')
    if sha(gzip.decompress((upstream/'models/model-service/native.smt2.gz').read_bytes()))!=context['model_sha256']:raise ValueError('Different published cache model')
    for name,path in context['history_files'].items():
        if (upstream/path).read_bytes()!=(HERE/'cache'/name).read_bytes():raise ValueError('Different published accepted-event history')
    body=(HERE/'interface/published-value.smt2').read_text()
    if sum(body in f.read_text()for f in (upstream/'properties').glob('*.smt2'))!=1:raise ValueError('Published fixed-model conclusion changed')
    return context['provider'],body


def binding_source():
    shared='shared_token_probe.sv'
    _,rows=native_source({shared:[],CORE:[]})
    source=(PUBLIC/shared).read_text();core=(PUBLIC/CORE).read_text()
    cache=ports(source,'u_auth');machine=ports(source,'u_machine');arb=ports(core,'u_private_ddr_arbiter')
    pairs=[('request_valid_i','private_runtime_req_valid_o','private_req_valid_o'),
        ('request_ready_o','private_runtime_req_ready_i','private_req_ready_i'),
        ('request_word_i','private_runtime_req_word_index_o','private_req_index_o'),
        ('response_valid_o','private_runtime_rsp_valid_i','private_rsp_valid_i'),
        ('response_ready_i','private_runtime_rsp_ready_o','private_rsp_ready_o'),
        ('response_data_o','private_runtime_rsp_data_i','private_rsp_data_i')]
    for cp,mp,ap in pairs:
        if cache[cp]!=machine[mp]or arb[ap]!=mp:raise ValueError('Actual API wire changed: '+cp)
    for field in ['clk','reset_n','model_locked_i']:
        if cache[field]!=machine[field]or arb[field]!=field:raise ValueError('Actual common clock/reset/lock changed')
    if cache['cancel_i']!="1'b0":raise ValueError('Actual cache caller cancels model reads')
    if 'assign model_rsp_fault=auth_fault;'not in source or cache['fault_o']!='auth_fault'or machine['private_runtime_rsp_fault_i']!='model_rsp_fault'or arb['private_rsp_fault_i']!='private_runtime_rsp_fault_i':raise ValueError('Cache error forwarding changed')
    return dict(sources=rows,cache_instance=cache,machine_instance=machine,arbiter_instance=arb,
        direct_pairs=[list(x)for x in pairs],clock=cache['clk'],reset=cache['reset_n'],cancel=cache['cancel_i'],
        hard_reset_is_shared=True,CLEAR_resets_neither_cache_nor_owner=True)


def definitions():
    bindings=[f'(= {cn(cp)} {n(A+ap)})'for cp,mp,ap in binding_source()['direct_pairs']]
    bindings +=[f'(= {cn(x)} {n(A+x)})'for x in ['clk','reset_n','model_locked_i']]
    bindings +=[f'(not {cn("cancel_i")})',f'(= {cn("fault_o")} {n(A+"private_rsp_fault_i")})']
    defs=f'(define-fun interface-bindings ((a {RS}) (c {CS})) Bool {conj(bindings)})\n'
    equal=conj(['(= (a-admit h) (q-admitted (c-requests ch)))','(= (a-retire h) (c-retired ch))',
        '(= (a-arguments h) (q-arguments (c-requests ch)))'])
    defs+=f'(define-fun interface-history-equal ((h ApiHistory) (ch CacheorderHistory)) Bool {equal})\n'
    live=conj(['(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),n(B+'push')])
    address='((_ extract 17 0) (select (o-address (a-parent h)) (o-receive (a-parent h))))'
    good=f'(=> {live} (= {n(B+"in_data_i")} (select model {address})))'
    defs+=f'(define-fun interface-word-to-layer ((a {RS}) (h ApiHistory) (model (Array (_ BitVec 18) (_ BitVec 256)))) Bool {good})\n'
    return defs


def specification():
    rh=f'(|{ROOT}_h| a)';ch=f'(|{CACHE}_h| c)';binding='(interface-bindings a c)'
    hist='(interface-history-equal h ch)'
    context=[rh,ch,binding,'(api-inv a h)','(cacheorder-inv c ch)',hist,n('reset_n'),
        f'(= (c-slot ch) {cn("response_read_q")})','(= u (select (a-arguments h) (a-retire h)))',
        '(fixed-model-return c (c-service ch) (c-slot ch) u model)']
    rules={
        'accepted-events':dict(assumptions=[rh,ch,binding],conclusion=conj([f'(= {n(A+"request_transfer")} {cn("request_fire")})',f'(= {n(A+"response_transfer")} {cn("response_fire")})'])),
        'common-zero':dict(assumptions=[],conclusion='(interface-history-equal api-zero (cacheorder-zero slot))'),
        'common-step':dict(assumptions=[rh,ch,binding,hist],conclusion='(interface-history-equal (api-next a h) (cacheorder-next c ch))'),
        'value-to-layer':dict(assumptions=context,conclusion='(interface-word-to-layer a h model)'),
        'joined-context':dict(assumptions=context+['(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),n(B+'push')],conclusion='false',expected='sat'),
    }
    declarations=[f'(declare-const a {RS})',f'(declare-const c {CS})','(declare-const h ApiHistory)',
        '(declare-const ch CacheorderHistory)','(declare-const slot (_ BitVec 5))','(declare-const u (_ BitVec 18))',
        '(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():
    return ['connected/native.smt2','ordered/history.smt2','api/history.smt2','cache/native.smt2','cache/service-origin.smt2',
        'cache/request-origin.smt2','cacheorder/history.smt2','interface/published-value.smt2','interface/history.smt2']


def main():
    descriptor,body=provider();bindings=binding_source();d=HERE/'interface';d.mkdir(exist_ok=True)
    (d/'published-value.smt2').write_text(body);(d/'history.smt2').write_text(definitions())
    write_json(d/'PROVIDER.json',descriptor);write_json(d/'BINDINGS.json',bindings)
    bodies=body_files()
    rules,declarations=specification()
    files=[*bodies,'interface/PROVIDER.json','interface/BINDINGS.json','connected-SOURCES.json','cache-SOURCES.json',
        'api-PLAN.json','cacheorder-PLAN.json']
    write_json(HERE/'interface-PLAN.json',dict(schema='Typed-cache-parent-interface-application-v1',source_manifest='connected-SOURCES.json',
        inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),
        checks_file='interface-CHECKS.json',providers=dict(parent='api',cache_order='cacheorder',memory='interface/PROVIDER.json'),
        root_external_assumptions=descriptor['boundaries'],cache_value_import_logically_closed=False,
        whole_Q_consumption_proved=False,whole_machine_theorem=False,observations=[n(B+'push'),'h','ch','u']))
    print('Frozen literal shared-event/history/value application; provider and engine completion still required.')


if __name__=='__main__':main()

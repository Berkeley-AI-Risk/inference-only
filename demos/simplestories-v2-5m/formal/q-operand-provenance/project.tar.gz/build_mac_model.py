"""Fixed-model coefficient and current activation at actual native MAC use."""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,J,n
from freeze_metadata_targets import E


def definitions():
    model='(Array (_ BitVec 18) (_ BitVec 256))'
    live=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),'(not '+n(J+'integrated_fail')+')',f'(= {n(J+"job_q")} {bv(0,4)})'])
    base=f'(bvadd (bvmul ((_ zero_extend 16) {n(J+"layer_q")}) {bv(28580,19)}) (bvmul ((_ zero_extend 13) {n(J+"group_q")}) {bv(640,19)}))'
    expected=f'(model-Q-beat model {base} (c-mac-column ch))'
    owned=f'(and {live} (c-mac-valid ch))'
    clauses=[f'(=> {owned} (= (c-mac-W ch) {expected}))',f'(=> {owned} (= (c-mac-A ch) (select (j-memory (c-base ch)) (c-mac-column ch))))',
        f'(=> {owned} '+conj([f'(= {n(J+"state_q")} {bv(3,3)})',f'(= (j-cols (c-base ch)) {bv(256,10)})',f'(bvult (c-mac-column ch) {bv(256,10)})',f'(bvult {n(J+"layer_q")} {bv(6,3)})',f'(bvult {n(J+"group_q")} {bv(4,6)})'])+')']
    defs='\n'.join(f'(define-fun macmodel-clause-{i} ((a {S}) (ch CaptureHistory) (model {model})) Bool {clause})'for i,clause in enumerate(clauses))+'\n'
    defs+=f'(define-fun macmodel-inv ((a {S}) (ch CaptureHistory) (model {model})) Bool '+conj([f'(macmodel-clause-{i} a ch model)'for i in range(len(clauses))])+')\n'
    imported=json.loads((HERE/'words-PLAN.json').read_text())['rules']['consequence']['conclusion']
    defs+=f'(define-fun macmodel-capture-service ((a {S}) (h ApiHistory) (w WordsHistory) (model {model})) Bool {imported})\n'
    goals=[]
    for lane in range(64):
        T=E+f'g_tile[{lane//16}].u_tile.';M=T+f'g_lane[{lane%16}].u_mac.'
        gate=conj([live,n(M+'multiply_i'),'(not '+n(E+'kill')+')','(not '+n(T+'begin_i')+')'])
        goals.append(f'(=> {gate} '+conj(['(c-mac-valid ch)',f'(= {n(M+"weight_i")} ((_ extract {lane*10+9} {lane*10}) {expected}))',f'(= {n(M+"activation_i")} (select (j-memory (c-base ch)) (c-mac-column ch)))',f'(= {n(T+"op_first_q")} (= (c-mac-column ch) {bv(0,10)}))',f'(= {n(T+"op_last_q")} (= (c-mac-column ch) {bv(255,10)}))'])+')')
    return defs,live,base,goals


def specification():
    _,live,base,goals=definitions();h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    imports=['(api-inv a h)','(reader-inv a h)','(words-inv a h w model)','(capture-inv a ch)','(macmodel-capture-service a h w model)']
    step=[h('a'),h('an'),'(operand-native-step a an)',*imports,'(macmodel-inv a ch model)','(= chn (capture-next a ch))']
    expected=f'(model-Q-beat model {base.replace(" a)"," an)")} (c-mac-column chn))'
    guard=f'(and {live.replace(" a)"," an)")} (c-mac-valid chn))'
    slices=[f'(=> {guard} (= ((_ extract {i*10+9} {i*10}) (c-mac-W chn)) ((_ extract {i*10+9} {i*10}) {expected})))'for i in range(64)]
    parts=[f'(macmodel-clause-{i} an chn model)'for i in range(3)]
    rules={'native-step-weakening':dict(assumptions=[h('a'),h('an'),t],conclusion='(operand-native-step a an)'),
        'reset-base':dict(assumptions=initial,conclusion='(macmodel-inv an (capture-zero an) model)'),
        **{'preserved-slice-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(slices)},
        'preserved-0':dict(assumptions=slices,conclusion=parts[0]),
        'preserved-1':dict(assumptions=step,conclusion=parts[1]),
        'preserved-2':dict(assumptions=step,conclusion=parts[2]),
        'parts-join':dict(assumptions=parts,conclusion='(macmodel-inv an chn model)'),
        'consequence':dict(assumptions=[h('a'),*imports,'(macmodel-inv a ch model)'],conclusion=conj(goals)),
        'reset-context':dict(assumptions=initial+[n('reset_n').replace(' a)',' an)')],conclusion='false',expected='sat')}
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ApiHistory)','(declare-const w WordsHistory)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)','(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():return ['connected/native.smt2','operand-step.smt2','ordered/history.smt2','api/history.smt2','reader/history.smt2','words/history.smt2','parentcapture/history.smt2','macmodel/history.smt2']


def main():
    defs,_,_,_=definitions();d=HERE/'macmodel';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    rules,declarations=specification();bodies=body_files();files=[*bodies,'OPERAND-STEP.json','connected-SOURCES.json',*[x+'-PLAN.json'for x in ['api','reader','words','parentcapture']]]
    bounds=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']
    write_json(HERE/'macmodel-PLAN.json',dict(schema='Typed-native-Q-MAC-model-v1',source_manifest='connected-SOURCES.json',inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),checks_file='macmodel-CHECKS.json',providers=['api','reader','words','parentcapture'],root_external_assumptions=bounds,whole_Q_consumption_proved=False,whole_machine_theorem=False,
        observations=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',J+'integrated_fail',J+'state_q',J+'group_q',J+'column_q',J+'weight_transfer']]+['(c-mac-valid ch)','(c-mac-valid chn)','(c-mac-column ch)','(c-mac-column chn)']))
    print('Frozen all-64-MAC model/activation provenance at registered use.')


if __name__=='__main__':main()

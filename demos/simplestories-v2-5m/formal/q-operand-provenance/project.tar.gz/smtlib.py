"""Standardize Z3's zero-parameter datatype declaration shorthand.

Only the declaration syntax changes. Sort names/arity, constructor order,
selector names and all field sorts are preserved. No assertion, function body,
native transition or query is otherwise rewritten. Original and standardized
engine inputs are saved and independently reconstructed by the checker.
"""
import re


def standard_datatypes(source):
    rows=[]
    for line in source.splitlines(keepends=True):
        if not line.lstrip().startswith('(declare-datatypes () '):
            rows.append(line);continue
        tokens=re.findall(r'\|[^|]*\||[()]|[^\s()]+',line)
        def parse(index):
            if index>=len(tokens):raise ValueError('Truncated datatype')
            if tokens[index]!='(':return tokens[index],index+1
            result=[];index+=1
            while index<len(tokens)and tokens[index]!=')':
                item,index=parse(index);result.append(item)
            if index==len(tokens):raise ValueError('Unclosed datatype')
            return result,index+1
        ast,end=parse(0)
        if end!=len(tokens)or ast[:2]!=['declare-datatypes',[]]or len(ast)!=3 or not ast[2]:raise ValueError('Unsupported datatype shorthand')
        sorts=[];constructors=[]
        for definition in ast[2]:
            if not isinstance(definition,list)or len(definition)<2 or not isinstance(definition[0],str):raise ValueError('Unsupported datatype declaration')
            sorts.append([definition[0],'0']);constructors.append(definition[1:])
        def emit(item):return '('+' '.join(emit(x)for x in item)+')'if isinstance(item,list)else item
        standardized=['declare-datatypes',sorts,constructors]
        # Inverting this one syntactic transformation recovers the declaration
        # AST exactly; no type/constructor content may be dropped or invented.
        restored=['declare-datatypes',[],[[s[0],*cs]for s,cs in zip(sorts,constructors)]]
        if restored!=ast:raise ValueError('Datatype syntax conversion changed its content')
        rows.append(emit(standardized)+('\n'if line.endswith('\n')else''))
    return ''.join(rows)

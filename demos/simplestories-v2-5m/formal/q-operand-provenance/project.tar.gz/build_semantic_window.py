"""Fresh native semantic-window induction in the qualified control projection.

The existing control model retains the actual parent/queues/arbiter and leaves
20 whole numerical leaves unrestricted. No old assertion or desired numerical
reply is imported. This lemma concerns its unchanged three-register window;
the separately compiled full projection job supplies its numerical consumer.
"""
import json
import os
from pathlib import Path
import sys
from source_policy import HERE, PUBLIC, native_source, sha, write_json
from build_initial import conj, bv, PREFIX

CAMPAIGN=HERE.parents[2]
NATIVE=HERE/'source-context/control'
CERT=HERE/'source-context/FINISHED.json'
CERT_SHA='e1f916cfce241d5ffa97aa466b2180afaa0024ed6099e5350ec281933e789cd3'
TOP='core_workflow_control';P='u_native.u_six_layers.u_datapath.'


def verify_source():
    if sha(CERT.read_bytes())!=CERT_SHA:raise ValueError('Qualified control source certificate changed')
    certificate=json.loads(CERT.read_text());inputs=json.loads((NATIVE/'INPUTS.json').read_text())
    if not certificate['passed']or inputs['assumption_cells']!=0:raise ValueError('Control projection not qualified/unrestricted')
    replay=Path(certificate['source_run'])if 'source_run'in certificate else None
    # The qualification re-elaborated this exact model. This imports source
    # correspondence, not any previous safety assertion as a premise.
    expected={Path(k).name:v for k,v in certificate['artifact_manifest'].items()if '/core-macro-workflow-qualification-r2/source-replay/'in k}
    if expected.get('design.smt2')!=sha((NATIVE/'design.smt2').read_bytes()):raise ValueError('Qualified model identity differs')
    for name in inputs['compile_sources']:
        if name not in expected or sha((NATIVE/name).read_bytes())!=expected[name]:raise ValueError('Qualified compile source changed: '+name)
    path=PREFIX+'context2048_token_machine0/rtl/board1_context2048_semantic_datapath.sv'
    _,sources=native_source({path:[]})
    raw=(PUBLIC/path).read_bytes()
    if raw!=(NATIVE/'production-datapath.sv').read_bytes():raise ValueError('Different actual semantic datapath')
    block=(HERE/'semantic-owner-window.txt').read_text()
    if raw.decode().count(block)!=1 or (NATIVE/'datapath.sv').read_text().count(block)!=1:raise ValueError('Native window block changed in control projection')
    return dict(sources=sources,top=TOP,kind='qualified-control-overapproximation',
        qualification=str(CERT),qualification_sha256=CERT_SHA,
        native_model=str(NATIVE/'design.smt2'),native_smt_sha256=sha((NATIVE/'design.smt2').read_bytes()),
        actual_parent_block_sha256=sha(block.encode()),new_HDL_observer_additions=[],
        unrestricted_whole_numerical_leaves=20,unrestricted_output_ports=137,
        numerical_producer_theorem=False,old_assertions_assumed=False)


def main():
    manifest=verify_source();write_json(HERE/'window-SOURCES.json',manifest)
    d=HERE/'window';d.mkdir(exist_ok=True)
    S='|'+TOP+'_s|';n=lambda x,s='a':f'(|{TOP}_n {P+x}| {s})'
    owner='(w-owner h)';pending='(w-pending h)';fault='(w-fault h)'
    push=n('ddr_request_fire');pop=n('ddr_response_fire')
    amount=f'(ite (xor {push} {pop}) (ite {push} (bvadd {pending} #x1) (bvsub {pending} #x1)) {pending})'
    nextowner=f'(ite (and {push} (not {pop}) (= {owner} #b00)) (ite {n("projection_word_req_valid")} #b01 #b10) (ite (and {pop} (not {push}) (= {pending} #x1)) #b00 {owner}))'
    faultterms=[fault,f'(and (= {owner} #b00) {n("private_word_rsp_valid_i")})',f'(and {n("projection_word_req_valid")} {n("lookup_word_req_valid")})',
        f'(xor (= {pending} #x0) (= {owner} #b00))',f'(bvugt {pending} #x8)',f'(and (= {owner} #b10) (distinct {pending} #x1))',f'(= {owner} #b11)']
    defs='(declare-datatypes () ((WindowHistory (window-history (w-owner (_ BitVec 2)) (w-pending (_ BitVec 4)) (w-fault Bool)))))\n'
    defs+='(define-fun window-zero () WindowHistory (window-history #b00 #x0 false))\n'
    defs+=f'(define-fun window-next ((a {S}) (h WindowHistory)) WindowHistory (ite (not {n("rst_n")}) window-zero (window-history {nextowner} {amount} (or '+ ' '.join(faultterms)+'))))\n'
    clauses=[f'(= {owner} {n("ddr_owner_q")})',f'(= {pending} {n("ddr_pending_q")})',f'(= {fault} {n("ddr_arbiter_fault_q")})',
        f'(bvule {pending} #x8)',f'(= (= {owner} #b00) (= {pending} #x0))',f'(distinct {owner} #b11)',f'(=> (= {owner} #b10) (= {pending} #x1))']
    defs+=f'(define-fun window-inv ((a {S}) (h WindowHistory)) Bool (=> {n("rst_n")} {conj(clauses)}))\n'
    (d/'history.smt2').write_text(defs)
    h=lambda s:f'(|{TOP}_h| {s})';t=f'(|{TOP}_t| a an)';reset=n('rst_n')
    # The old control abstraction optimizes away unused numerical child VALID
    # inputs. These predicates are their literal source branch definitions,
    # not unconstrained replacement inputs or new driving RTL.
    projection=conj([f'(= {n("ddr_owner_q")} #b01)',n('private_word_rsp_valid_i')])
    lookup=conj([f'(= {n("ddr_owner_q")} #b10)',n('private_word_rsp_valid_i')])
    goals=[f'(=> {projection} (and (= {owner} #b01) (bvugt {pending} #x0)))',
        f'(=> {lookup} (and (= {owner} #b10) (= {pending} #x1)))',
        f'(=> {fault} (not {n("private_word_req_valid_o")}))']
    rules={
        'reset-base':dict(assumptions=[h('a'),h('an'),t,'(not '+reset+')'],conclusion='(window-inv an window-zero)'),
        'preserved':dict(assumptions=[h('a'),h('an'),t,'(window-inv a h)','(= hn (window-next a h))'],conclusion='(window-inv an hn)'),
        'consequence':dict(assumptions=[h('a'),'(window-inv a h)',reset],conclusion=conj(goals)),
        'reset-context':dict(assumptions=[h('a'),h('an'),t,'(not '+reset+')',n('rst_n','an')],conclusion='false',expected='sat')}
    body=os.path.relpath(NATIVE/'design.smt2',HERE)
    files=['window-SOURCES.json','window/history.smt2',body]
    plan=dict(schema='Typed-native-history-induction-v1',bodies=[body,'window/history.smt2'],source_manifest='window-SOURCES.json',checks_file='window-CHECKS.json',
        inputs={f:sha((HERE/f).read_bytes())for f in files},declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h WindowHistory)','(declare-const hn WindowHistory)'],
        rules=rules,order=list(rules),induction=dict(top=TOP,invariant='window-inv',zero='window-zero',next='(window-next a h)',history_sort='WindowHistory',root_goals=goals,
            external_assumptions=[],reset=P+'rst_n',claim='Actual semantic projection/lookup pending owners follow accepted handshakes and survive CLEAR; no child numerical reply promise'),
        whole_Q_consumption_proved=False,whole_machine_theorem=False,observations=[n(x,s)for s in ['a','an']for x in ['rst_n','clear_i','ddr_owner_q','ddr_pending_q','ddr_arbiter_fault_q']]+['h','hn'])
    write_json(HERE/'window-PLAN.json',plan)
    print('Frozen native parent-window induction in the existing qualified control projection; no old assertions imported.')


if __name__=='__main__':main()

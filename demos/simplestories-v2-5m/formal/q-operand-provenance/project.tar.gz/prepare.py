import hashlib,json,os,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
PUBLIC=Path(os.environ['Q_PRODUCTION_MODEL'])/'hardware/project'
PROJECT=PUBLIC
BINDING=HERE/'source-context/BINDING.json'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write_json(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def modules(raw):return {m[1]:m[0]for m in re.finditer(r'^module\s+(\w+)\b[\s\S]*?^endmodule',raw,re.M)}

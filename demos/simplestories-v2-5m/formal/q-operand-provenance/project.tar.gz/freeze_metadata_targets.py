"""Freeze remaining metadata-at-use goals without claiming they are proved."""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,J,n

E=J+'u_shared_engine.u_engine.'


def definitions():
    model='(Array (_ BitVec 18) (_ BitVec 256))'
    live=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),'(not '+n(J+'integrated_fail')+')',f'(= {n(J+"job_q")} {bv(0,4)})'])
    base=f'(bvadd {bv(211920,19)} (bvadd (bvmul ((_ zero_extend 16) {n(J+"layer_q")}) {bv(304,19)}) (bvmul ((_ zero_extend 13) {n(J+"group_q")}) {bv(8,19)})))'
    record=lambda lane:f'(model-Q-metadata-record model {base} {lane})'
    exponent=lambda rec:f'(bvsub (bvadd ((_ sign_extend 3) {n(J+"activation_exponent_q")}) ((_ sign_extend 3) ((_ extract 7 0) {rec}))) {bv(15,11)})'
    capture=[]
    for lane in range(64):
        tile=lane//16;slot=lane%16;T=E+f'g_tile[{tile}].u_tile.';rec=record(bv(lane,6));exp=exponent(rec)
        capture +=[f'(= (select (|{TOP}_m {T}multiplier_q| a) {bv(slot,4)}) ((_ extract 23 8) {rec}))',
            f'(= (select (|{TOP}_m {T}exponent_q| a) {bv(slot,4)}) ((_ extract 7 0) {exp}))',
            f'(bvsge {exp} {bv(1920,11)})',f'(bvsle {exp} {bv(127,11)})']
    goals={}
    goals['metadata-at-tile-capture']=f'(=> (and {live} {n(J+"weight_transfer")}) {conj(capture)})'
    # All four tile memories synchronously read the low-four row bits. The
    # engine selects the matching tile on the following valid pipeline tag.
    issue=n(E+'issue_count_q');low=f'((_ extract 3 0) {issue})';readclaims=[]
    for tile in range(4):
        T=E+f'g_tile[{tile}].u_tile.';lane=f'(concat {bv(tile,2)} {low})';rec=record(lane);exp=exponent(rec)
        readclaims +=[n(T+'read_i'),f'(= {n(T+"read_lane_i")} {low})',
            f'(= (select (|{TOP}_m {T}multiplier_q| a) {low}) ((_ extract 23 8) {rec}))',
            f'(= (select (|{TOP}_m {T}exponent_q| a) {low}) ((_ extract 7 0) {exp}))']
    emit=f'(= {n(E+"state_q")} {bv(4,3)})'
    goals['metadata-at-tile-read']=f'(=> (and {live} {emit} {n(E+"issue")}) {conj(readclaims)})'
    row=n(E+'row_pipe_q[1]');rec=record(row);exp=exponent(rec)
    tag=f'(= ((_ extract 1 1) {n(E+"scale_valid_q")}) #b1)'
    claims=[f'(= {n(E+"scale_operand_q")} ((_ zero_extend 2) ((_ extract 23 8) {rec})))',
        f'(= {n(E+"exponent_pipe_q[1]")} ((_ extract 7 0) {exp}))']
    for primitive in ['u_scale_low.','u_scale_high.']:
        claims.append(f'(= {n(E+primitive+"b_i")} ((_ zero_extend 2) ((_ extract 23 8) {rec})))')
    goals['metadata-at-postscale-input']=f'(=> (and {live} {emit} {tag}) {conj(claims)})'
    definitions='\n'.join(f'(define-fun {name} ((a {S}) (model {model})) Bool {goal})'for name,goal in goals.items())+'\n'
    return definitions,goals


def main():
    definitions,goals=globals()['definitions']()
    path=HERE/'METADATA-TARGETS.smt2';path.write_text(definitions)
    # Check native function availability before any future query is scheduled.
    import re
    native=(HERE/'connected/native.smt2').read_text()
    known=set(re.findall(r'\((?:define-fun|declare-fun|declare-sort)\s+(\|[^|]+\|)',native))
    referenced=set(re.findall(r'\((\|[^|]+\|)',definitions))
    if referenced-known:raise ValueError('Unavailable native metadata target signal: '+str(referenced-known))
    write_json(HERE/'METADATA-TARGETS.json',dict(status='Frozen unproved remaining obligations',proved=False,
        goals=list(goals),property_file=path.name,property_sha256=sha(path.read_bytes()),
        native_smt_sha256=sha((HERE/'connected/native.smt2').read_bytes()),model_record_definition='header/history.smt2:model-Q-metadata-record',
        domains=dict(layers=6,groups=4,rows_per_group=64),
        meaning='Current model row multiplier and representable e_v + row_exponent - 15 at capture, synchronous tile read and actual postscale coefficient ports',
        unreset_memories='Only current owned metadata is claimed; no erasure or initialized stale payload assumption',
        arithmetic_result_theorem=False,whole_Q_consumption_proved=False,whole_machine_theorem=False))
    print('Frozen unproved all-row metadata capture/read/postscale goals; native signal inventory checked.')


if __name__=='__main__':main()

"""Restore the complete native projection producer in the actual parent model.

The qualified controller abstraction supplies unchanged actual controllers,
four local FIFOs and the owner arbiter. Only the u_projection output cuts are
removed and its original instance/subtree restored. Other numerical leaves
remain unrestricted, so this is not a whole-graph numerical model.
"""
from pathlib import Path
import json
import re
import subprocess
from source_policy import HERE,PUBLIC,PROJECT,BINDING,native_source,sha,write_json
from build_semantic_window import NATIVE,CERT,CERT_SHA,verify_source

TOP='core_workflow_control'


def reconstruct():
    verify_source()
    old=json.loads((NATIVE/'INPUTS.json').read_text());certificate=json.loads(CERT.read_text())
    expected={Path(k).name:v for k,v in certificate['artifact_manifest'].items()if '/core-macro-workflow-qualification-r2/source-replay/'in k}
    files={name:(NATIVE/name).read_bytes()for name in old['compile_sources']}
    if any(sha(data)!=expected[name]for name,data in files.items()):raise ValueError('Changed qualified controller source')
    raw=(NATIVE/'production-datapath.sv').read_text()
    instance=re.findall(r'^    board1_fixed_group_projection_scale_job\b[\s\S]*?^    \);',raw,re.M)
    if len(instance)!=1:raise ValueError('Unique actual projection instance required')
    cuts=[r for r in old['internal_cuts']if r['instance']=='u_projection']
    if len(cuts)!=13:raise ValueError('Projection cut inventory changed')
    assigns='\n'.join('    assign '+r['expression']+'='+r['replacement']+';'for r in cuts)
    data=files['datapath.sv'].decode()
    if data.count(assigns)!=1:raise ValueError('Exact prior projection substitution changed')
    restored=data.replace(assigns,instance[0],1)
    if restored.replace(instance[0],assigns,1)!=data:raise ValueError('Prior abstract source not recovered exactly')
    # All assignments from the old arbitrary projection outputs are gone.
    if re.search(r'assign\s+\w+\s*=\s*f_child_u_projection_',restored):raise ValueError('Projection output remains abstract')
    files['datapath.sv']=restored.encode()
    inventory=json.loads((HERE/'model-consumption-setup/SOURCES.json').read_text());selection={}
    for name,row in inventory['compiled_modules'].items():selection.setdefault(row['source'],[]).append(name)
    subtree,sources=native_source(dict(sorted(selection.items())))
    if subtree!=(HERE/'job/native.sv').read_text():raise ValueError('Different numerical subtree')
    files['projection-native.sv']=subtree.encode()
    # Bind original actual controller modules back to the distributed pins.
    pins=json.loads(BINDING.read_text())['binding']['native_join']['distributed_inputs']
    reverse={digest:name.removeprefix('project/')for name,digest in pins.items()if name.startswith('project/')}
    original={}
    for label in ['core','shell','sequence','layer','datapath','fifo','arbiter']:
        payload=(NATIVE/('production-'+label+'.sv')).read_bytes();path=reverse.get(sha(payload))
        if path is None or (PUBLIC/path).read_bytes()!=payload or (PROJECT/path).read_bytes()!=payload:
            raise ValueError('Different actual parent source: '+label)
        original[path]=[]
    _,parents=native_source(original);sources.update(parents)
    return files,dict(sources=sources,kind='restored-native-projection-parent',top=TOP,
        source_qualification='source-context/FINISHED.json',source_qualification_sha256=CERT_SHA,
        prior_model_sha256=sha((NATIVE/'design.smt2').read_bytes()),actual_restored_instance=instance[0],
        removed_projection_cuts=cuts,remaining_unrestricted_output_ports=len(old['internal_cuts'])-len(cuts),
        remaining_unrestricted_whole_numerical_leaves=19,numerical_projection_cuts=[],new_HDL_observers=[],
        whole_graph_numerical_model=False,cache_frontier='actual private_runtime request/response interface of the published cache theorem')


def main():
    files,manifest=reconstruct();d=HERE/'connected';d.mkdir(exist_ok=False)
    for name,data in files.items():(d/name).write_bytes(data)
    recipe='read_verilog -formal -sv -nosynthesis -D SYNTHESIS -defer '+' '.join(files)+'\n'
    projection='u_native.u_six_layers.u_datapath.u_projection.'
    recipe+='\n'.join(['hierarchy -check -top '+TOP,'proc','opt_clean','flatten',
        'setattr -set keep 1 w:'+projection+'* m:'+projection+'*',
        'chformal -remove','async2sync','opt_clean','dffunmap','memory_collect',
        'select -assert-none t:$assume t:$assert t:$cover t:$anyconst t:$anyseq','check -assert','write_json native.json','write_smt2 -wires native.smt2'])+'\n'
    (d/'compile.ys').write_text(recipe)
    with(d/'compile.log').open('w')as f:cp=subprocess.run(['yosys','-Q','compile.ys'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    if cp.returncode:raise ValueError('Restored parent failed to compile')
    graph=json.loads((d/'native.json').read_text())['modules'][TOP]
    memories={k:dict(WIDTH=int(v['parameters']['WIDTH'],2),SIZE=int(v['parameters']['SIZE'],2),WR_PORTS=int(v['parameters']['WR_PORTS'],2))for k,v in graph['cells'].items()if v['type']=='$mem_v2'}
    # Restoring a producer with otherwise unused arithmetic output must not
    # silently drop its numerical metadata RAMs at the abstract parent edge.
    child=json.loads((HERE/'job/native.json').read_text())['modules']['board1_fixed_group_projection_scale_job']
    for name,cell in child['cells'].items():
        if cell['type']!='$mem_v2'or int(cell['parameters']['WR_PORTS'],2)==0:continue
        expected={k:int(cell['parameters'][k],2)for k in ['WIDTH','SIZE','WR_PORTS']}
        if memories.get(projection+name)!=expected:raise ValueError('Native producer RAM not retained: '+name)
    smt=(d/'native.smt2').read_text()
    for t in range(4):
        for lane in range(16):
            suffix=f'u_shared_engine.u_engine.g_tile[{t}].u_tile.g_lane[{lane}].u_mac.weight_i'
            if '|'+TOP+'_n '+projection+suffix+'|'not in smt:raise ValueError('Native MAC input not retained')
    manifest.update(files={n:sha(b)for n,b in files.items()},script_sha256=sha(recipe.encode()),native_smt_sha256=sha((d/'native.smt2').read_bytes()),memories=memories)
    write_json(HERE/'connected-SOURCES.json',manifest)
    print('Compiled actual parent queues/arbiter and restored uncut native projection; 19 other numerical leaves remain unrestricted.')


if __name__=='__main__':main()

"""Candidate accepted-request/response order bridge for the qualified cache.

Reuse its exact compiled native model and total histories, without recompiling
or changing the published packet. This adds no data-value assumption. Its goal
is to identify the old value theorem's watched service address with the oldest
accepted API argument. Parent/history lifting remains a separate obligation.
"""
import argparse
import json
import shutil
from source_policy import HERE,native_source,sha,write_json
from build_initial import finish,conj,bv

OLD=HERE/'source-context/model-operands'
TOP='board1_verified_ddr_page_service';S='|'+TOP+'_s|'
n=lambda x:f'(|{TOP}_n {x}| a)'
MANIFEST_SHA='82d8668a7859163a0af9fb1d728cb5149701bb9757f9d6453dd08262e71e53a2'
MODEL_SHA='315317846d411305feb9873087b1d4ab2074239461cc4c281872de711964dab9'


def cache_source(install=False):
    # These two identities are recorded in the published qualification's
    # bound_inputs. This function rechecks actual source/module reconstruction
    # and every reused compiler input, rather than trusting a manifest alone.
    if sha((OLD/'SERVICE-SOURCES.json').read_bytes())!=MANIFEST_SHA:raise ValueError('Published cache manifest changed')
    old=json.loads((OLD/'SERVICE-SOURCES.json').read_text())
    selection={x:r['modules']for x,r in old['sources'].items()}
    # Original compilation concatenated bank, SHA, service, then inspected
    # top/UART sources. Preserve that exact order, with no added HDL observer.
    selection={k:selection[k]for k in ['bank.sv','sha.sv','service.sv','top.sv','uart_core.sv']}
    source,rows=native_source(selection);source=source.replace('`define SYNTHESIS\n','',1)
    if source!=(OLD/'service-project/native.sv').read_text():raise ValueError('Native cache reconstruction differs')
    if old['native_smt_sha256']!=MODEL_SHA or sha((OLD/'service-project/native.smt2').read_bytes())!=MODEL_SHA:raise ValueError('Published cache model changed')
    recipe=(OLD/'service-project/compile.ys').read_text()
    if '-D SYNTHESIS native.sv'not in recipe or 'chparam -set BANKS 4 -set ADDR_W 19 '+TOP not in recipe:raise ValueError('Cache compiler configuration changed')
    directory=HERE/'cache'
    if install:directory.mkdir(exist_ok=True)
    files={}
    for name in ['native.sv','native.smt2','native.json','compile.ys',*old['tables']]:
        original=OLD/'service-project'/name;data=original.read_bytes()
        if name in old['tables'] and sha(data)!=old['tables'][name]:raise ValueError('Cache ROM changed')
        if install and not(directory/name).exists():shutil.copyfile(original,directory/name)
        if (directory/name).read_bytes()!=data:raise ValueError('Reused cache artifact differs: '+name)
        files[name]=sha(data)
    for name in ['service-origin.smt2','request-origin.smt2']:
        data=(OLD/name).read_bytes()
        if install and not(directory/name).exists():(directory/name).write_bytes(data)
        if (directory/name).read_bytes()!=data:raise ValueError('Reused readonly history differs')
        files[name]=sha(data)
    return dict(kind='native-cache-reuse',sources=rows,top=TOP,parameters=old['production_parameters'],files=files,
        source_sha256=sha(source.encode()),native_smt_sha256=MODEL_SHA,qualified_manifest_sha256=MANIFEST_SHA,
        internal_cuts=[],HDL_observer_additions=[],source_policy='exact-native-module-bodies; original compiler macro; frozen qualified frontend reused')


def main(split=False):
    manifest=cache_source(True);write_json(HERE/'cache-SOURCES.json',manifest)
    q='(c-requests h)';s='(c-service h)';retired='(c-retired h)';slot='(c-slot h)'
    reset=f'(or (not {n("reset_n")}) {n("cancel_i")})'
    fields=['(c-requests RequestOrigin)','(c-service ServiceOrigin)','(c-retired (_ BitVec 7))','(c-slot (_ BitVec 5))']
    defs='(declare-datatypes () ((CacheorderHistory (cacheorder-history '+' '.join(fields)+'))))\n'
    defs+='(define-fun cacheorder-zero ((slot (_ BitVec 5))) CacheorderHistory (cacheorder-history request-zero service-zero '+bv(0,7)+' slot))\n'
    defs+=f'(define-fun cacheorder-next ((a {S}) (h CacheorderHistory)) CacheorderHistory (ite {reset} (cacheorder-zero {slot}) (cacheorder-history (request-next a {q}) (service-next a {s} {slot}) (bvadd {retired} (ite {n("response_fire")} {bv(1,7)} {bv(0,7)})) {slot})))\n'
    response=f'((_ zero_extend 1) {n("response_count_q")})'
    offset=f'((_ zero_extend 2) (bvsub {slot} {n("response_read_q")}))'
    ticket=f'(bvadd {retired} {offset})'
    live=f'(bvult {offset} {response})'
    clauses={
        'request-prefix':f'(request-inv a {q})',
        'response-bound':f'(bvule {response} {bv(32,7)})',
        'response-count':f'(= {response} (bvsub (q-dispatched {q}) {retired}))',
        'response-read-ticket':f'(= {n("response_read_q")} ((_ extract 4 0) {retired}))',
        'response-write-ticket':f'(= {n("response_write_q")} ((_ extract 4 0) (q-dispatched {q})))',
        'whole-live-interval':conj([f'(= (bvsub (q-admitted {q}) {retired}) (bvadd {n("request_count_q")} {response}))',f'(bvule (bvsub (q-admitted {q}) {retired}) {bv(96,7)})']),
        'watched-slot-live':f'(= (s-valid {s}) {live})',
        'watched-slot-address':f'(=> (s-valid {s}) (= (s-address {s}) (select (q-arguments {q}) {ticket})))',
    }
    healthy=f'(not {n("fault_o")})'
    defs+='\n'.join(f'(define-fun cacheorder-clause-{i} ((a {S}) (h CacheorderHistory)) Bool {v})'for i,v in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun cacheorder-inv ((a {S}) (h CacheorderHistory)) Bool (and (|{TOP}_i| a) (=> (and {n("reset_n")} {healthy}) '+conj([f'(cacheorder-clause-{i} a h)'for i in range(len(clauses))])+')))\n'
    goal=f'(=> (and {healthy} {n("response_valid_o")} (= {slot} {n("response_read_q")})) '+conj([f'(s-valid {s})',f'(= (s-address {s}) (select (q-arguments {q}) {retired}))'])+')'
    parts=[f'(|{TOP}_i| an)']+[f'(=> (and (|{TOP}_n reset_n| an) (not (|{TOP}_n fault_o| an))) (cacheorder-clause-{i} an hn))'for i in range(len(clauses))]if split else None
    finish('cacheorder',TOP,defs,'cacheorder-inv','(cacheorder-zero slot)','(cacheorder-next a h)',[goal],manifest,
        extra_declarations=['(declare-const slot (_ BitVec 5))'],initial_configuration=True,native_label='cache',
        additional_bodies=['cache/service-origin.smt2','cache/request-origin.smt2'],preserved_parts=parts)
    plan=json.loads((HERE/'cacheorder-PLAN.json').read_text())
    plan['inputs'].update({('cache/'+name):v for name,v in manifest['files'].items()})
    plan['observations']=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n','cancel_i','fault_o','request_fire','read_fire','response_fire','request_count_q','response_count_q','response_read_q','response_write_q','head_word']]+['h','hn']+[f'(cacheorder-clause-{i} an hn)'for i in range(len(clauses))]
    write_json(HERE/'cacheorder-PLAN.json',plan);write_json(HERE/'cacheorder/CLAUSES.json',dict(enumerate(clauses)))
    print('Frozen fresh accepted-request order bridge on the unchanged qualified native cache; no value premise imported.')


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--split',action='store_true');a=ap.parse_args();main(a.split)

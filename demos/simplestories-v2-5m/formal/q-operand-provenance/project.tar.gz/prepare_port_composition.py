"""Check actual port bindings and unconditional native admission/fault laws.

These all-state bridge checks assume no component assertion or data premise.
They deliberately do not claim the pending history/value-contract discharge.
"""
import json
from pathlib import Path
import re
from prepare import PUBLIC,sha,write_json

HERE=Path(__file__).resolve().parent
OUT=HERE/'port-composition'
TOPS={'t':'board1_thin_ddr_app_transport','p':'board1_private_booted_shared_ddr',
    's':'board1_private_shared_ddr_transaction_boundary','c':'board1_current_model_path'}
PROJECTS={'t':'upstream-memory-r2','p':'upstream-wrappers-r2','s':'shared-upstream-r3','c':'model-cdc-upstream-r4'}


def ports(source,instance):
    start=source.index(' '+instance+' (');end=source.index(');',start)+2
    return {name:re.sub(r'\s+','',expr)for name,expr in re.findall(r'\.(\w+)\(([^()]*)\)',source[start:end])}


def main():
    OUT.mkdir(exist_ok=False)
    top=(PUBLIC/'top.sv').read_text();shared=(PUBLIC/'shared_token_probe.sv').read_text();uart=(PUBLIC/'uart_core.sv').read_text()
    pm=ports(top,'u_memory');tm=ports(top,'u_transport');um=ports(top,'u_uart_core');sm=ports(shared,'u_shared');cm=ports(shared,'u_model_cdc');uartmachine=ports(uart,'u_machine')
    sources={}
    for project in PROJECTS.values():sources.update(json.loads((HERE/project/'SOURCES.json').read_text())['sources'])
    for name in ['top.sv','shared_token_probe.sv','uart_core.sv']:
        raw=(PUBLIC/name).read_bytes();sources[name]=dict(sha256=sha(raw),baseline=str(PUBLIC/name),public_export=str(PUBLIC/name))
    for field in ['private_endpoint_req_valid_o','private_endpoint_req_write_o','private_endpoint_req_word_address_o',
        'private_endpoint_req_write_data_o','private_endpoint_req_ready_i','private_endpoint_rsp_valid_i',
        'private_endpoint_rsp_error_i','private_endpoint_rsp_data_i']:
        if uartmachine[field]!=field:raise ValueError('UART runtime endpoint is no longer a direct wire')
    def n(k,name):return f'(|{TOPS[k]}_n {name}| {k})'
    def eq(a,b):return '(= '+a+' '+b+')'
    links=[];bindings=[]
    pairs=[('app_cmd_o','core_cmd_i'),('app_cmd_en_o','core_cmd_en_i'),('app_addr_o','core_addr_i'),
        ('app_wr_data_o','core_wr_data_i'),('app_wr_data_en_o','core_wr_en_i'),('app_wr_data_end_o','core_wr_end_i'),
        ('app_wr_data_mask_o','core_wr_mask_i'),('app_burst_o','core_burst_i'),('app_self_refresh_req_o','core_self_refresh_i'),
        ('app_refresh_req_o','core_refresh_i'),('app_cmd_ready_i','core_cmd_ready_o'),('app_wr_data_ready_i','core_wr_ready_o'),
        ('app_rd_data_i','core_rd_data_o'),('app_rd_data_valid_i','core_rd_valid_o'),('app_rd_data_end_i','core_rd_end_o'),
        ('controller_pll_lock_i','core_controller_good_o'),('controller_init_calib_complete_i','core_controller_good_o')]
    for p,t in pairs:
        if pm[p]!=tm[t]:raise ValueError('Actual parent/thin connection changed')
        links.append(eq(n('p',p),n('t',t)));bindings.append(dict(parent=p,thin=t,wire=pm[p]))
    endpoint=[('raw_req_valid_o','private_req_valid_i','private_endpoint_req_valid_o'),
        ('raw_req_write_o','private_req_write_i','private_endpoint_req_write_o'),
        ('raw_req_data_o','private_req_data_i','private_endpoint_req_write_data_o'),
        ('raw_req_ready_i','private_req_ready_o','private_endpoint_req_ready_i'),
        ('raw_rsp_valid_i','private_rsp_valid_o','private_endpoint_rsp_valid_i'),
        ('raw_rsp_error_i','private_rsp_error_o','private_endpoint_rsp_error_i'),
        ('raw_rsp_data_i','private_rsp_data_o','private_endpoint_rsp_data_i')]
    for s,p,u in endpoint:
        if sm[s]!=u or um[u]!=pm[p]:raise ValueError('Actual endpoint forwarding changed')
        links.append(eq(n('s',s),n('p',p)))
    if (sm['raw_req_word_o']!='shared_raw_word' or
        'assign private_endpoint_req_word_address_o=shared_raw_word[18:0];'not in re.sub(r'\s+',' ',shared)):
        # Check the exact assignment with whitespace removed, not an invented
        # extension/truncation policy.
        if 'assignprivate_endpoint_req_word_address_o=shared_raw_word[18:0];'not in re.sub(r'\s+','',shared):raise ValueError('Actual normalized address projection changed')
    if um['private_endpoint_req_word_address_o']!=pm['private_req_word_i']:raise ValueError('Endpoint address forwarding changed')
    links.append(eq('((_ extract 18 0) '+n('s','raw_req_word_o')+')',n('p','private_req_word_i')))
    for c,s in [('app_req_valid_o','model_req_valid_i'),('app_req_ready_i','model_req_ready_o'),
        ('app_req_word_o','model_req_word_i'),('app_rsp_valid_i','model_rsp_valid_o'),
        ('app_rsp_data_i','model_rsp_data_o'),('app_rsp_error_i','model_rsp_error_o')]:
        if cm[c]!=sm[s]:raise ValueError('Actual CDC/shared binding changed')
    # The CDC fixture includes precisely the original parent instance.
    for c,s in [('model_app_req_valid','model_req_valid_i'),('model_app_req_ready','model_req_ready_o'),
        ('model_app_req_word','model_req_word_i'),('model_app_rsp_valid','model_rsp_valid_o'),
        ('model_app_rsp_data','model_rsp_data_o'),('model_app_rsp_error','model_rsp_error_o')]:links.append(eq(n('c',c),n('s',s)))
    if cm['app_upstream_fault_i']!='private_endpoint_upstream_fault_i||shared_app_fault' or sm['upstream_fault_i']!='private_endpoint_upstream_fault_i||model_cdc_app_fault':raise ValueError('Actual fault feedback changed')
    if um['private_endpoint_upstream_fault_i']!=pm['private_fail_closed_o']:raise ValueError('Actual endpoint failure forwarding changed')
    links += [eq(n('c','shared_app_fault'),n('s','fault_o')),
        eq(n('c','private_endpoint_upstream_fault_i'),n('p','private_fail_closed_o')),
        eq(n('s','upstream_fault_i'),'(or '+n('p','private_fail_closed_o')+' '+n('c','model_cdc_app_fault')+')')]
    context=[f'(|{top}_h| {state})'for state,top in TOPS.items()]+links
    rules={
        'thin-good-excludes-transport-fault':dict(assumptions=context,
            conclusion='(=> '+n('t','core_controller_good_o')+' (not '+n('t','core_fault_o')+'))'),
        'runtime-command-is-native-thin-admission':dict(assumptions=context+[n('p','f_runtime')],
            conclusion=eq(n('t','enqueue'),'(and '+n('p','app_cmd_en_o')+' '+n('p','app_cmd_ready_i')+')')),
        'normalized-success-selects-successful-thin-return':dict(assumptions=context,
            conclusion='(=> (and '+n('p','private_rsp_valid_o')+' (not '+n('p','private_rsp_error_o')+')) (and '+n('t','core_rd_valid_o')+' (not '+n('t','core_fault_o')+')))'),
        'shared-address-truncation-loses-no-bits':dict(assumptions=context,
            conclusion='(= ((_ extract 24 19) '+n('s','raw_req_word_o')+') (_ bv0 6))'),
        'parent-failed-return-cannot-enter-shared-model-pipeline':dict(assumptions=context,
            conclusion='(=> (and '+n('p','private_fail_closed_o')+' '+n('s','raw_rsp_valid_i')+') (not '+n('s','backend_model_valid')+'))'),
        'application-fault-closes-new-model-captures':dict(assumptions=context,
            conclusion='(=> (or '+n('p','private_fail_closed_o')+' '+n('s','fault_o')+') (not '+n('c','u_model_cdc.legal_return')+'))'),
        'cdc-fault-closes-shared-raw-issue':dict(assumptions=context,
            conclusion='(=> '+n('c','model_cdc_app_fault')+' (not '+n('s','raw_req_valid_o')+'))'),
        'core-fault-closes-new-admission-and-publication':dict(assumptions=context,
            conclusion='(=> '+n('c','model_cdc_core_fault')+' (and (not '+n('c','private_raw_req_ready_i')+') (not '+n('c','private_raw_rsp_valid_i')+')))')}
    bodies=['../'+p+'/project/native.smt2'for p in PROJECTS.values()]
    write_json(OUT/'SOURCES.json',dict(sources=sources,actual_binding_audit=True,bindings=bindings,
        component_invariants_assumed=False,data_assumptions=0,history_alignment_proved=False,whole_machine_theorem=False))
    write_json(OUT/'PLAN.json',dict(schema='Actual-native-port-composition-laws-v1',bodies=bodies,
        inputs={name:sha((OUT/name).read_bytes())for name in bodies+['SOURCES.json']},
        declarations=[f'(declare-const {state} |{top}_s|)'for state,top in TOPS.items()],rules=rules,order=list(rules)))
    state=json.loads((HERE/'shared-upstream-r3/SETUP-STATE.json').read_text());assert not state['active_owned_jobs']
    state['solver_seconds_cap']-=400;write_json(HERE/'shared-upstream-r3/SETUP-STATE.json',state)
    state.update(solver_seconds=0,solver_seconds_cap=400,status='port_composition_prepared');write_json(OUT/'SETUP-STATE.json',state)
    print(len(rules),'all-state native port/fault checks; no component invariants or data assumptions')


if __name__=='__main__':main()

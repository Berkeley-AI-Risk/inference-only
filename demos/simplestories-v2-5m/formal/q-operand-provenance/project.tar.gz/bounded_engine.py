"""Bound one owned solver's memory and its explicitly allotted wall time."""
import argparse
import os
import resource
import shutil
import subprocess
import time

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--memory-mib',type=int,required=True)
ap.add_argument('--wall-seconds',type=int,required=True)
ap.add_argument('command',nargs=argparse.REMAINDER)
a=ap.parse_args();command=a.command[1:]if a.command and a.command[0]=='--'else a.command
if not command or min(a.memory_mib,a.wall_seconds)<=0:raise ValueError('Missing bounded solver command')
executable=shutil.which(command[0])
if not executable:raise ValueError('Solver unavailable')
limit=a.memory_mib*1024*1024
try:resource.setrlimit(resource.RLIMIT_AS,(limit,limit))
except (ValueError,OSError):
    proc=subprocess.Popen([executable,*command[1:]])
    started=time.monotonic()
    try:
        while proc.poll()is None:
            sample=subprocess.run(['ps','-p',str(proc.pid),'-o','rss='],capture_output=True,text=True)
            if proc.poll()is not None:break
            if sample.returncode or not sample.stdout.strip():raise RuntimeError('Cannot enforce owned solver RSS bound')
            if int(sample.stdout.strip())*1024>limit:raise RuntimeError('Owned solver exceeded RSS bound')
            if time.monotonic()-started>a.wall_seconds:raise RuntimeError('Owned solver exceeded allotted wall time')
            time.sleep(.25)
        raise SystemExit(proc.wait())
    except BaseException:
        if proc.poll()is None:proc.kill();proc.wait()
        raise
else:os.execv(executable,command)

"""Native parent address ownership using bounded modular accepted histories.

The capacities are the actual production capacities: 16 shared owners, two
entries per local queue, and an eight-request semantic window. Five-bit logical
tickets wrap; the live interval is proved at most eight. No queue is reduced,
no data reply is assumed correct, and no HDL observer is added.
"""
import argparse
import json
from source_policy import HERE, write_json
from build_initial import finish, conj, bv
from build_transport import TOP,S,A,R,B,D,J,n


def main(split=False):
    child=n('u_native.child_reset_n');alive=f'(not {n(A+"fail_q")})'
    one=bv(1,5);zero=bv(0,5)
    names=['admit','dispatch','receive','retire']
    counters=[f'(o-{k} h)'for k in names]
    admit,dispatch,receive,retire=counters
    events=[n(R+'push'),n(R+'pop'),n(B+'push'),n(B+'pop')]
    increment=lambda x,event:f'(bvadd {x} (ite {event} {one} {zero}))'
    nextc=[f'(ite {child} {increment(x,e)} {zero})'for x,e in zip(counters,events)]
    addresses='(o-address h)';tags='(o-projection h)';cache='(o-cache-address h)'
    nextaddr=f'(ite (and {child} {events[0]}) (store {addresses} {admit} {n(R+"in_addr_i")}) {addresses})'
    nexttag=f'(ite (and {child} {events[0]}) (store {tags} {admit} {n(D+"projection_word_req_valid")}) {tags})'
    nextcache=f'(ite {n(A+"request_transfer")} (store {cache} {n(A+"owner_write_pointer_q")} {n(A+"private_req_index_o")}) {cache})'
    defs='(declare-datatypes () ((OrderedHistory (ordered-history '+ ' '.join(f'(o-{k} (_ BitVec 5))'for k in names)+' (o-address (Array (_ BitVec 5) (_ BitVec 19))) (o-projection (Array (_ BitVec 5) Bool)) (o-cache-address (Array (_ BitVec 4) (_ BitVec 19)))))))\n'
    zeros=[zero]*4+['((as const (Array (_ BitVec 5) (_ BitVec 19))) '+bv(0,19)+')','((as const (Array (_ BitVec 5) Bool)) false)','((as const (Array (_ BitVec 4) (_ BitVec 19))) '+bv(0,19)+')']
    defs+='(define-fun ordered-zero () OrderedHistory (ordered-history '+' '.join(zeros)+'))\n'
    defs+=f'(define-fun ordered-next ((a {S}) (h OrderedHistory)) OrderedHistory (ite (not {n("reset_n")}) ordered-zero (ordered-history '+ ' '.join(nextc+[nextaddr,nexttag,nextcache])+')))\n'
    eq=lambda a,b:f'(= {a} {b})'
    ext=lambda x,width:f'((_ zero_extend {5-width}) {x})'
    sub=lambda a,b:f'(bvsub {a} {b})'
    clauses={}
    count=n(A+'owner_count_q');rd=n(A+'owner_read_pointer_q');wr=n(A+'owner_write_pointer_q')
    clauses['owner-count-bound']=f'(bvule {count} {bv(16,5)})'
    clauses['owner-pointers']=eq(wr,f'(bvadd {rd} ((_ extract 3 0) {count}))')
    release=n('u_native.machine_release_q')
    clauses['release-domain']=f'(or (= {release} #b00) (= {release} #b01) (= {release} #b11))'
    clauses['release-lock-seen']=f'(=> (distinct {release} #b00) {n(A+"lock_seen_q")})'
    local={}
    pending=ext(n(D+'ddr_pending_q'),4);owner=n(D+'ddr_owner_q')
    rq=ext(n(R+'count_q'),2);bq=ext(n(B+'count_q'),2)
    local['pending']=conj([eq(pending,sub(admit,retire)),f'(bvule {pending} {bv(8,5)})',
        f'(= (= {owner} #b00) (= {pending} {zero}))',f'(distinct {owner} #b11)',f'(=> (= {owner} #b10) (= {pending} {one}))'])
    local['request-count']=conj([eq(rq,sub(admit,dispatch)),f'(bvule {rq} {bv(2,5)})'])
    local['response-count']=conj([eq(bq,sub(receive,retire)),f'(bvule {bq} {bv(2,5)})'])
    local['ordered-intervals']=conj([f'(bvule {sub(dispatch,receive)} {pending})',
        eq(pending,f'(bvadd {rq} (bvadd {sub(dispatch,receive)} {bq}))'),
        f'(bvule {rq} {pending})',f'(bvule {bq} {pending})'])
    ptrs=[]
    for prefix,ww,rr in [(R,admit,dispatch),(B,receive,retire)]:
        ptrs +=[eq(n(prefix+'wr_ptr_q'),f'(= ((_ extract 0 0) {ww}) #b1)'),eq(n(prefix+'rd_ptr_q'),f'(= ((_ extract 0 0) {rr}) #b1)')]
    local['queue-ticket-pointers']=conj(ptrs)
    for i in range(2):
        at=f'(bvadd {dispatch} {bv(i,5)})'
        slot=f'(= ((_ extract 0 0) {at}) #b1)'
        native=f'(ite {slot} {n(R+"addr_q[1]")} {n(R+"addr_q[0]")})'
        local[f'request-address-{i}']=f'(=> (bvult {bv(i,5)} {rq}) (= {native} (select {addresses} {at})))'
        bat=f'(bvadd {retire} {bv(i,5)})';bslot=f'(= ((_ extract 0 0) {bat}) #b1)'
        fault=f'(ite {bslot} {n(B+"write_q[1]")} {n(B+"write_q[0]")})'
        local[f'response-fault-{i}']=f'(=> (bvult {bv(i,5)} {bq}) (not {fault}))'
    # The rank counts earlier layer owners in the actual shared owner FIFO.
    # Shell owners occupy real slots but do not advance the layer ticket.
    rank=zero
    for i in range(16):
        at=f'(bvadd {rd} {bv(i,4)})'
        live=f'(bvult {bv(i,5)} {count})'
        layer=f'(= ((_ extract 0 0) (bvlshr {n(A+"owner_fifo_q")} ((_ zero_extend 12) {at}))) #b1)'
        owned=f'(and {live} {layer})'
        local[f'cache-address-{i}']=f'(=> {owned} (= (select {cache} {at}) (select {addresses} (bvadd {receive} {rank}))))'
        # Defining each prefix avoids textual exponential growth.
        defs+=f'(define-fun ordered-rank-{i} ((a {S})) (_ BitVec 5) {rank})\n'if i==0 else ''
        nextrank=f'(bvadd {rank} (ite {owned} {one} {zero}))'
        defs+=f'(define-fun ordered-rank-{i+1} ((a {S})) (_ BitVec 5) {nextrank})\n'
        rank=f'(ordered-rank-{i+1} a)'
    local['cache-layer-count']=eq(rank,sub(dispatch,receive))
    for i in range(8):
        at=f'(bvadd {retire} {bv(i,5)})'
        local[f'window-role-{i}']=f'(=> (bvult {bv(i,5)} {pending}) (= (select {tags} {at}) (= {owner} #b01)))'
    for key,value in local.items():clauses[key]=f'(=> (and {alive} {child}) {value})'
    clauses['child-reset-empty']=f'(=> (and {alive} (not {child})) '+conj([eq(n(R+'count_q'),'#b00'),eq(n(B+'count_q'),'#b00'),eq('(ordered-rank-16 a)',zero),*[eq(x,zero)for x in counters]])+')'
    defs+='\n'.join(f'(define-fun ordered-clause-{i} ((a {S}) (h OrderedHistory)) Bool {value})'for i,value in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun ordered-inv ((a {S}) (h OrderedHistory)) Bool (and (|{TOP}_i| a) (=> {n("reset_n")} '+conj([f'(ordered-clause-{i} a h)'for i in range(len(clauses))])+')))\n'
    jr=conj([n(J+'private_word_rsp_valid_i'),n(J+'private_word_rsp_ready_o')])
    goals=[f'(=> (and {alive} {child} {jr}) '+conj([f'(bvugt {pending} {zero})',f'(select {tags} {retire})','(not '+n(J+'private_word_rsp_fault_i')+')'])+')']
    m=json.loads((HERE/'connected-SOURCES.json').read_text())
    parts=[f'(|{TOP}_i| an)']+[f'(=> (|{TOP}_n reset_n| an) (ordered-clause-{i} an hn))'for i in range(len(clauses))]if split else None
    finish('ordered',TOP,defs,'ordered-inv','ordered-zero','(ordered-next a h)',goals,m,initial_configuration=True,native_label='connected',preserved_parts=parts)
    plan=json.loads((HERE/'ordered-PLAN.json').read_text())
    plan['observations']=[n(k)for k in ['reset_n','u_native.child_reset_n','u_native.machine_release_q',A+'fail_q',A+'terminal_now',A+'lock_seen_q',A+'request_transfer',A+'response_transfer',A+'owner_count_q',R+'push',R+'pop',R+'count_q',B+'push',B+'pop',B+'count_q',D+'ddr_pending_q',D+'ddr_owner_q']]+counters+[x.replace(' h)',' hn)')for x in counters]+[f'(ordered-clause-{i} an hn)'for i in range(len(clauses))]
    write_json(HERE/'ordered-PLAN.json',plan);write_json(HERE/'ordered/CLAUSES.json',dict(enumerate(clauses)))
    print('Frozen production-width modular ordered-address candidate; model values remain open.')


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--split',action='store_true');args=ap.parse_args();main(args.split)

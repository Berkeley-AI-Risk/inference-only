"""Finite operating/actual-defect controls of the full native Q consumer.

The model-word responder is a test provider, not a proved memory composition.
Monitors only read the actual metadata, tile capture and registered MAC inputs.
"""
from pathlib import Path
import argparse
import json
import subprocess
from source_policy import HERE, PUBLIC, sha, write_json

BENCH=r'''
module tb;
 reg clk=0;always #5 clk=~clk;
 reg reset_n=0,clear_i=0,start=0,av=0,last=0;
 reg[2:0]layer=0;reg signed[15:0]activation=0;
 wire sr,ar,req,rr,done,fail;wire[18:0]address;wire[255:0]data;
 reg[255:0]model[0:227061];reg[18:0]pending[0:4095];
 integer head=0,tail=0,debt=0,cycle=0,requests=0,responses=0;
 wire reqready=debt<64 && cycle%7!=2;
 wire rspvalid=debt!=0 && cycle%3!=1;
 assign data=model[pending[head]];
 wire push=req&&reqready,pop=rspvalid&&rr;
 board1_fixed_group_projection_scale_job #(.ADDR_W(19)) dut(
  .clk(clk),.reset_n(reset_n),.clear_i(clear_i),.model_locked_i(1'b1),.upstream_fail_closed_i(1'b0),
  .start_valid_i(start),.start_ready_o(sr),.fixed_layer_i(layer),.fixed_job_i(4'd0),.activation_exponent_i(-8'sd10),
  .activation_valid_i(av),.activation_ready_o(ar),.activation_i(activation),.activation_last_i(last),
  .private_word_req_valid_o(req),.private_word_req_ready_i(reqready),.private_word_req_index_o(address),
  .private_word_rsp_valid_i(rspvalid),.private_word_rsp_ready_o(rr),.private_word_rsp_data_i(data),.private_word_rsp_fault_i(1'b0),
  .result_valid_o(),.result_ready_i(cycle%5!=0),.result_row_index_o(),.result_scaled_raw_o(),.result_source_exponent_o(),.result_last_o(),
  .done_valid_o(done),.done_ready_i(1'b1),.busy_o(),.fail_closed_o(fail));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(!reset_n)begin head<=0;tail<=0;debt<=0;end
  else begin
   if(push)begin
    if(address>=227062)$fatal(1,"address out of model");
    pending[tail]<=address;tail<=(tail+1)%4096;requests<=requests+1;
   end
   if(pop)begin head<=(head+1)%4096;responses<=responses+1;end
   case({push,pop})2'b10:debt<=debt+1;2'b01:debt<=debt-1;endcase
   if(fail)$fatal(1,"unexpected native failure cycle=%0d",cycle);
  end
  if(cycle>150000)$fatal(1,"operating timeout");
 end
 function automatic signed[15:0]argument(input integer c,input integer generation);
  argument=((c*7+generation*5)%63)-31;
 endfunction
 function automatic[9:0]coefficient(input integer L,g,c,l);
  integer bit_at,word_at,offset;reg[511:0]pair;
  begin
   bit_at=L*914560*8+10*((g*256+c)*64+l);word_at=bit_at/256;offset=bit_at%256;
   pair={model[word_at+1],model[word_at]};coefficient=(pair>>offset);
  end
 endfunction
 function automatic[31:0]metadata(input integer L,g,l);
  integer at;begin at=211920+304*L+8*g+l/8;metadata=model[at]>>((l%8)*32);end
 endfunction
 reg active=0,expect_mac=0,expect_read=0;
 integer generation=0,current_layer=0,captures=0,groups=0,current_group=0,meta_count=0;
 integer full_runs=0,mac_pairs=0,metadata_records=0;
 reg[639:0]expected_weights;
 reg signed[15:0]expected_activation;
 reg[15:0]expected_mult[0:3];reg signed[7:0]expected_exp[0:3];
 integer k,t;reg[31:0]record;integer exp_sum;
 wire capture=dut.u_shared_engine.u_engine.weight_fire;
 wire meta_fire=dut.u_shared_engine.u_engine.metadata_fire;
 wire issue=dut.u_shared_engine.u_engine.issue;
 always @(posedge clk)begin
  if(!reset_n||clear_i)begin expect_mac<=0;expect_read<=0;end
  else begin
   expect_mac<=active&&capture;
   expect_read<=active&&issue;
   if(active&&dut.stream_start_transfer)begin
    if(dut.group_q!=groups)$fatal(1,"group order");
    current_group=groups;groups=groups+1;meta_count=0;
   end
   if(active&&meta_fire)begin
    record=metadata(current_layer,current_group,meta_count);
    if(dut.u_shared_engine.u_engine.metadata_row_index_i!=64*current_group+meta_count ||
       dut.u_shared_engine.u_engine.metadata_multiplier_i!=record[23:8] ||
       dut.u_shared_engine.u_engine.metadata_exponent_i!=record[7:0] ||
       dut.u_shared_engine.u_engine.metadata_last_i!=(meta_count==63))$fatal(1,"metadata record");
    meta_count=meta_count+1;metadata_records=metadata_records+1;
   end
   if(active&&capture)begin
    if(!dut.u_shared_engine.u_engine.weight_ready_o)$fatal(1,"capture readiness");
    if(dut.activation_q!==argument(captures%256,generation))$fatal(1,"activation capture L=%0d c=%0d",current_layer,captures%256);
    if(current_group!=captures/256)$fatal(1,"capture group");
    for(k=0;k<64;k=k+1)begin
     if(dut.stream_weight_data[k*10+:10]!==coefficient(current_layer,captures/256,captures%256,k))
      $fatal(1,"weight capture L=%0d g=%0d c=%0d lane=%0d",current_layer,captures/256,captures%256,k);
     expected_weights[k*10+:10]<=coefficient(current_layer,captures/256,captures%256,k);
    end
    expected_activation<=argument(captures%256,generation);captures=captures+1;
   end
   if(active&&issue)begin
    for(t=0;t<4;t=t+1)begin
     record=metadata(current_layer,current_group,t*16+dut.u_shared_engine.u_engine.issue_count_q[3:0]);
     exp_sum=-10+$signed(record[7:0])-15;
     expected_mult[t]<=record[23:8];expected_exp[t]<=exp_sum;
    end
   end
   if(active&&dut.u_shared_engine.u_engine.state_q==4 && dut.u_shared_engine.u_engine.scale_valid_q[1])begin
    record=metadata(current_layer,current_group,dut.u_shared_engine.u_engine.row_pipe_q[1]);
    exp_sum=-10+$signed(record[7:0])-15;
    if(dut.u_shared_engine.u_engine.scale_operand_q!=={2'b00,record[23:8]} ||
       dut.u_shared_engine.u_engine.u_scale_low.b_i!=={2'b00,record[23:8]} ||
       dut.u_shared_engine.u_engine.u_scale_high.b_i!=={2'b00,record[23:8]} ||
       dut.u_shared_engine.u_engine.exponent_pipe_q[1]!==exp_sum[7:0])$fatal(1,"postscale metadata coefficient");
   end
  end
 end
 genvar tile,lane;
 generate for(tile=0;tile<4;tile=tile+1)begin:monitor_tile
  always @(posedge clk)if(reset_n&&!clear_i&&active&&expect_read)begin
   if(dut.u_shared_engine.u_engine.g_tile[tile].u_tile.multiplier_o!==expected_mult[tile] ||
      dut.u_shared_engine.u_engine.g_tile[tile].u_tile.exponent_o!==expected_exp[tile])$fatal(1,"retained metadata tile=%0d",tile);
  end
  for(lane=0;lane<16;lane=lane+1)begin:monitor_lane
   always @(posedge clk)if(reset_n&&!clear_i&&active&&expect_mac&&!dut.u_shared_engine.u_engine.kill)begin
    if(!dut.u_shared_engine.u_engine.g_tile[tile].u_tile.g_lane[lane].u_mac.multiply_i ||
       dut.u_shared_engine.u_engine.g_tile[tile].u_tile.g_lane[lane].u_mac.activation_i!==expected_activation ||
       dut.u_shared_engine.u_engine.g_tile[tile].u_tile.g_lane[lane].u_mac.weight_i!==expected_weights[(tile*16+lane)*10+:10])
      $fatal(1,"MAC use tile=%0d lane=%0d",tile,lane);
   end
  end
 end endgenerate
 task automatic begin_job(input integer L,input integer gen);
  integer c;
  begin
   while(!sr)@(negedge clk);
   @(negedge clk);current_layer=L;generation=gen;layer=L;captures=0;groups=0;meta_count=0;active=1;start=1;
   @(negedge clk);start=0;
   for(c=0;c<256;c=c+1)begin
    activation=argument(c,gen);last=c==255;av=1;
    @(posedge clk);while(!ar)@(posedge clk);
    @(negedge clk);av=0;
    if(c%11==0)@(negedge clk);
   end
  end
 endtask
 integer L;
 initial begin
  $readmemh("model256.memh",model);
  repeat(3)@(negedge clk);reset_n=1;
  begin_job(0,1);wait(captures>=3);
  @(negedge clk);clear_i=1;active=0;
  if(debt==0)$fatal(1,"CLEAR control needs old outstanding words");
  repeat(2)@(negedge clk);clear_i=0;
  while(!sr)@(negedge clk);
  if(debt!=0)$fatal(1,"old words not drained at fresh admission");
  for(L=0;L<6;L=L+1)begin
   begin_job(L,L+3);
   while(!done)@(negedge clk);
   if(captures!=1024||groups!=4||meta_count!=64)$fatal(1,"incomplete Q invocation");
   full_runs=full_runs+1;
   @(negedge clk);active=0;
  end
  $display("PASS: six full Q layers, 393216 coefficient/capture pairs, 1536 current metadata records, registered MAC operands, stalls and CLEAR/drain. requests=%0d responses=%0d",requests,responses);
  $finish;
 end
endmodule
'''


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--case',choices=['operating','wrong-halfword','wrong-activation','wrong-layer','wrong-group','swapped-metadata'],default='operating');ap.add_argument('--out',type=Path);a=ap.parse_args()
    root=a.out or HERE/'operating';root.mkdir(exist_ok=True);d=root/a.case;d.mkdir(exist_ok=False)
    image=PUBLIC.parents[1]/'assets/board1-real-semantic-image2048.bin'
    raw=image.read_bytes()
    if sha(raw)!='cad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0':raise ValueError('Wrong test model')
    memfile=root/'model256.memh'
    if not memfile.exists():memfile.write_text(''.join(f'{int.from_bytes(raw[i:i+32],"little"):064x}\n'for i in range(0,len(raw),32)))
    (d/'model256.memh').symlink_to('../model256.memh')
    source=(HERE/'job/native.sv').read_text()
    edits={'wrong-halfword':('shared_half_word <= ddr_word_data[255:128];','shared_half_word <= ddr_word_data[127:0];'),
           'wrong-activation':("(column_q + 10'd1) : 10'd0;","(column_q + 10'd2) : 10'd0;")}
    if a.case in edits:
        before,after=edits[a.case]
        if source.count(before)!=1:raise ValueError('Actual-only defect site changed')
        source=source.replace(before,after,1)
    extra={
        'wrong-layer':('board1_fixed_group_projection_scale_job', 'layer_q <= fixed_layer_i;', "layer_q <= fixed_layer_i ^ 3'd1;"),
        'wrong-group':('board1_fixed_group_projection_scale_job', '.fixed_group_i(group_q),', ".fixed_group_i(group_q ^ 6'd1),"),
        'swapped-metadata':('board1_fixed_group_ddr_stream','row_multiplier_q[metadata_count_q[5:0]] <= meta_multiplier;',"row_multiplier_q[metadata_count_q[5:0] ^ 6'd1] <= meta_multiplier;")}
    if a.case in extra:
        module,before,after=extra[a.case];prefix,marker,tail=source.partition('module '+module+' ')
        body,end,suffix=tail.partition('endmodule')
        if not marker or body.count(before)!=1:raise ValueError('Actual-only defect site changed: '+a.case)
        source=prefix+marker+body.replace(before,after,1)+end+suffix
    (d/'native.sv').write_text(source);(d/'tb.sv').write_text(BENCH)
    with(d/'compile.log').open('w')as log:cp=subprocess.run(['iverilog','-g2012','-s','tb','-o','sim','native.sv','tb.sv'],cwd=d,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    if cp.returncode:raise ValueError('Operating fixture compile failed')
    with(d/'simulation.log').open('w')as log:cp=subprocess.run(['vvp','sim'],cwd=d,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    log=(d/'simulation.log').read_text()
    expected={'wrong-halfword':'weight capture','wrong-activation':'activation capture','wrong-layer':'metadata record','wrong-group':'metadata record','swapped-metadata':'metadata record'}
    passed=(cp.returncode==0 and 'PASS:'in log)if a.case=='operating'else(cp.returncode!=0 and expected[a.case]in log)
    r=dict(passed=passed,finite_operating_evidence=True,case=a.case,exit_code=cp.returncode,native_sha256=sha(source.encode()),bench_sha256=sha(BENCH.encode()),model_image_sha256=sha(raw),log_sha256=sha(log.encode()),
        memory_responder='test provider, not a proved composition',whole_Q_consumption_proved=False,whole_machine_theorem=False)
    write_json(d/'RESULT.json',r);print(log.strip());print(json.dumps(r))
    if not passed:raise SystemExit(1)


if __name__=='__main__':main()

"""Carry the proved cache word through actual response FIFO payload storage.

Only the API invariant and the already-proved cache-to-layer word predicate are
used as trace facts. No desired reply at the projection job is assumed.
"""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,B,J,n


def definitions():
    parent='(a-parent h)';retired='(o-retire '+parent+')'
    clauses=[]
    for i in range(2):
        ticket=f'(bvadd {retired} {bv(i,5)})'
        slot=f'(= ((_ extract 0 0) {ticket}) #b1)'
        data=f'(ite {slot} {n(B+"data_q[1]")} {n(B+"data_q[0]")})'
        address=f'((_ extract 17 0) (select (o-address {parent}) {ticket}))'
        clauses.append(f'(=> (bvult {bv(i,2)} {n(B+"count_q")}) (= {data} (select model {address})))')
    guard=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n')])
    return f'(define-fun payload-inv ((a {S}) (h ApiHistory) (model (Array (_ BitVec 18) (_ BitVec 256)))) Bool (=> {guard} {conj(clauses)}))\n'


def specification():
    h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    step=[h('a'),h('an'),t,'(api-inv a h)','(payload-inv a h model)','(= hn (api-next a h))','(interface-word-to-layer a h model)']
    live=conj(['(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),n(J+'private_word_rsp_valid_i')])
    parent='(a-parent h)';ticket='(o-retire '+parent+')';argument=f'(select (o-address {parent}) {ticket})'
    goal=f'(=> {live} '+conj([f'(= {n(J+"private_word_rsp_data_i")} (select model ((_ extract 17 0) {argument})))',
        '(not '+n(J+'private_word_rsp_fault_i')+')',f'(select (o-projection {parent}) {ticket})'])+')'
    rules={
        'reset-base':dict(assumptions=initial,conclusion='(payload-inv an api-zero model)'),
        'preserved':dict(assumptions=step,conclusion='(payload-inv an hn model)'),
        'consequence':dict(assumptions=[h('a'),'(api-inv a h)','(payload-inv a h model)',n('reset_n')],conclusion=goal),
        'reset-context':dict(assumptions=initial+[n('reset_n').replace(' a)',' an)')],conclusion='false',expected='sat'),
        'published-job-context':dict(assumptions=[h('a'),'(api-inv a h)','(payload-inv a h model)',n('reset_n'),live],conclusion='false',expected='sat'),
    }
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ApiHistory)','(declare-const hn ApiHistory)',
        '(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():
    return ['connected/native.smt2','ordered/history.smt2','api/history.smt2','payload/imported-word.smt2','payload/history.smt2']


def imported_word():
    line=next(x for x in (HERE/'interface/history.smt2').read_text().splitlines()if x.startswith('(define-fun interface-word-to-layer '))
    return line+'\n'


def main():
    d=HERE/'payload';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(definitions());(d/'imported-word.smt2').write_text(imported_word())
    rules,declarations=specification();bodies=body_files()
    bounds=json.loads((HERE/'interface-PLAN.json').read_text())['root_external_assumptions']
    files=[*bodies,'connected-SOURCES.json','api-PLAN.json','interface-PLAN.json']
    write_json(HERE/'payload-PLAN.json',dict(schema='Typed-native-payload-refinement-v1',source_manifest='connected-SOURCES.json',
        inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),
        checks_file='payload-CHECKS.json',providers=dict(invariant='api',word='interface'),root_external_assumptions=bounds,
        whole_Q_consumption_proved=False,whole_machine_theorem=False,observations=[n(x)for x in ['reset_n',A+'fail_q',B+'push',B+'pop',B+'count_q',B+'rd_ptr_q',B+'wr_ptr_q']]+['h','hn']))
    print('Frozen native response FIFO value refinement and actual projection-job word-service consequence.')


if __name__=='__main__':main()

"""Candidate fixed-model Q metadata records and complete immutable header.

The 64 row memories are resetless. Only the accepted current-group prefix is
claimed; stale unpublished rows receive no convenient reset-value assumption.
"""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,n
from build_reader import G,M


def definitions():
    model='(Array (_ BitVec 18) (_ BitVec 256))'
    word=f'(select model ((_ extract 17 0) (bvadd base ((_ zero_extend 16) ((_ extract 5 3) lane)))))'
    shift=f'(bvshl ((_ zero_extend 253) ((_ extract 2 0) lane)) {bv(5,256)})'
    defs=f'(define-fun model-Q-metadata-record ((model {model}) (base (_ BitVec 19)) (lane (_ BitVec 6))) (_ BitVec 24) ((_ extract 23 0) (bvlshr {word} {shift})))\n'
    state=lambda prefix,values:'(or '+' '.join(f'(= {n(prefix+"state_q")} {bv(i,3)})'for i in values)+')'
    normal=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),'(not '+n(G+'fail_closed_o')+')',f'(= {n(G+"job_q")} {bv(0,4)})',state(G,[1,2,3,4,5])])
    base=f'(bvadd {bv(211920,19)} (bvadd (bvmul ((_ zero_extend 16) {n(G+"layer_q")}) {bv(304,19)}) (bvmul ((_ zero_extend 13) {n(G+"group_q")}) {bv(8,19)})))'
    count=n(G+'metadata_count_q');lane=f'(concat {n(M+"word_in_group_q")} {n(M+"record_in_word_q")})'
    currentword=f'(select model ((_ extract 17 0) (bvadd {base} ((_ zero_extend 16) {n(M+"word_in_group_q")}))))'
    clauses={
        'lanes':f'(= {n(G+"valid_lanes_q")} {bv(64,7)})',
        'count-bound':f'(bvule {count} {bv(64,7)})',
        'start-count':f'(=> {state(G,[1])} (= {count} {bv(0,7)}))',
        'complete-count':f'(=> {state(G,[3,4,5])} (= {count} {bv(64,7)}))',
        'reader-record-position':f'(=> {state(M,[1,2,3])} '+conj([f'(= {count} ((_ zero_extend 1) {lane}))',f'(bvult {count} {bv(64,7)})'])+')',
        'reader-request-position':f'(=> {state(M,[1,2])} (= {n(M+"record_in_word_q")} #b000))',
        'reader-word-model':f'(=> {state(M,[3])} (= {n(M+"response_word_q")} {currentword}))',
        'reader-complete-count':f'(=> {state(M,[4])} (= {count} {bv(64,7)}))',
    }
    exponents=[];multipliers=[]
    for i in range(64):
        record=f'(model-Q-metadata-record model {base} {bv(i,6)})'
        exponent=f'((_ extract 7 0) {record})';multiplier=f'((_ extract 23 8) {record})'
        exponents.append(exponent);multipliers.append(multiplier)
        clauses[f'current-row-{i}']=f'(=> (bvult {bv(i,7)} {count}) '+conj([f'(= (select (|{TOP}_m {G}row_exponent_q| a) {bv(i,6)}) {exponent})',f'(= (select (|{TOP}_m {G}row_multiplier_q| a) {bv(i,6)}) {multiplier})'])+')'
    defs+='\n'.join(f'(define-fun header-clause-{i} ((a {S}) (h ApiHistory) (model {model})) Bool {v})'for i,v in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun header-inv ((a {S}) (h ApiHistory) (model {model})) Bool (=> {normal} '+conj([f'(header-clause-{i} a h model)'for i in range(len(clauses))])+'))\n'
    service=json.loads((HERE/'reader-PLAN.json').read_text())['rules']['consequence']['conclusion']
    defs+=f'(define-fun header-reader-service ((a {S}) (h ApiHistory) (model {model})) Bool {service})\n'
    def packed(xs):
        value=xs[0]
        for x in xs[1:]:value=f'(concat {x} {value})'
        return value
    live=conj([normal,n(G+'group_valid_o')])
    goals=[f'(=> {live} '+conj([f'(= {n(G+"group_row_exponent_o")} {packed(exponents)})',f'(= {n(G+"group_row_multiplier_o")} {packed(multipliers)})'])+')']
    return defs,clauses,normal,goals


def specification():
    _,clauses,normal,goals=definitions();h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    step=[h('a'),h('an'),'(operand-native-step a an)','(api-inv a h)','(reader-inv a h)','(header-reader-service a h model)','(header-inv a h model)','(= hn (api-next a h))']
    nextnormal=normal.replace(' a)',' an)')
    parts=[f'(=> {nextnormal} (header-clause-{i} an hn model))'for i in range(len(clauses))]
    rules={'native-step-weakening':dict(assumptions=[h('a'),h('an'),t],conclusion='(operand-native-step a an)'),
        'reset-base':dict(assumptions=initial,conclusion='(header-inv an api-zero model)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(header-inv an hn model)'),
        'consequence':dict(assumptions=[h('a'),'(api-inv a h)','(reader-inv a h)','(header-inv a h model)',n('reset_n')],conclusion=conj(goals)),
        'reset-context':dict(assumptions=initial+[n('reset_n').replace(' a)',' an)')],conclusion='false',expected='sat')}
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ApiHistory)','(declare-const hn ApiHistory)',
        '(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():return ['connected/native.smt2','operand-step.smt2','ordered/history.smt2','api/history.smt2','reader/history.smt2','header/history.smt2']


def main():
    from operand_step import install
    install()
    defs,clauses,_,_=definitions();d=HERE/'header';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    rules,declarations=specification();bodies=body_files();files=[*bodies,'OPERAND-STEP.json','connected-SOURCES.json','api-PLAN.json','reader-PLAN.json']
    bounds=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']
    write_json(HERE/'header-PLAN.json',dict(schema='Typed-native-Q-metadata-header-v1',source_manifest='connected-SOURCES.json',
        inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),
        checks_file='header-CHECKS.json',providers=dict(invariant='api',reader='reader'),root_external_assumptions=bounds,
        whole_Q_consumption_proved=False,whole_machine_theorem=False,
        observations=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',A+'fail_q',G+'state_q',G+'job_q',G+'fail_closed_o',G+'metadata_count_q',G+'metadata_transfer',M+'state_q',M+'word_in_group_q',M+'record_in_word_q',M+'response_transfer',M+'clear_i']]+[f'(header-clause-{i} an hn model)'for i in range(len(clauses))]))
    write_json(d/'CLAUSES.json',dict(enumerate(clauses)));print('Frozen all-64-row current metadata prefix and published-header model identities; tile retention remains open.')


if __name__=='__main__':main()

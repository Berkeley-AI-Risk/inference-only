"""Candidate ordered job-request addresses at actual weight/metadata consumes.

Ownership/debt and pending-address induction uses no model values. Its word
consequence applies the closed projection-job service theorem at the literal
same current state/history, rather than assuming a desired private response.
"""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,D,J,n

G=J+'u_group_stream.';M=G+'u_metadata_reader.';P=G+'u_width_adapter.'


def definitions():
    state=lambda prefix,values:'(or '+' '.join(f'(= {n(prefix+"state_q")} {bv(i,3)})'for i in values)+')'
    owner=n(G+'owner_q');ghealthy='(not '+n(G+'fail_closed_o')+')'
    live=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n'),ghealthy])
    parent='(a-parent h)';pending=n(D+'ddr_pending_q');window=n(D+'ddr_owner_q')
    proj=f'(= {window} #b01)';mr=n(M+'request_outstanding_q');gw=n(G+'outstanding_words_q')
    debt=f'(bvadd {gw} (ite {mr} {bv(1,12)} {bv(0,12)}))'
    issued=n(G+'issued_words_q');consumed=n(G+'consumed_words_q')
    q=f'(= {n(G+"job_q")} {bv(0,4)})';active=state(G,[1,2,3,4,5])
    qbase=f'(bvadd (bvmul ((_ zero_extend 16) {n(G+"layer_q")}) {bv(28580,19)}) (bvmul ((_ zero_extend 13) {n(G+"group_q")}) {bv(640,19)}))'
    mbase=f'(bvadd {bv(211920,19)} (bvadd (bvmul ((_ zero_extend 16) {n(G+"layer_q")}) {bv(304,19)}) (bvmul ((_ zero_extend 13) {n(G+"group_q")}) {bv(8,19)})))'
    clauses={
        'metadata-healthy-states':state(M,[0,1,2,3,4,5]),
        'metadata-active-owner':f'(=> {state(M,[1,2,3,4,5])} (= {owner} #b01))',
        'all-job-word-geometry':f'(=> {active} (= {n(G+"group_words_q")} (ite (= {n(G+"job_q")} {bv(6,4)}) {bv(1705,11)} {bv(640,11)})))',
        'group-owner-phase':conj([f'(=> {state(G,[0,3,5])} (= {owner} #b00))',f'(=> {state(G,[1,2])} (= {owner} #b01))',f'(=> {state(G,[4])} (= {owner} #b10))']),
        'metadata-active-phase':f'(=> {state(M,[1,2,3,4])} {state(G,[2,6])})',
        'metadata-drain-phase':f'(=> {state(M,[5])} {state(G,[6])})',
        'metadata-pending-phase':conj([f'(=> {state(M,[0,1,3,4])} (not {mr}))',f'(=> {state(M,[2,5])} {mr})']),
        'weight-owner-debt':f'(=> (distinct {owner} #b10) (= {gw} {bv(0,12)}))',
        'metadata-owner-debt':f'(=> (distinct {owner} #b01) (not {mr}))',
        'projection-window-debt':f'(= {debt} (ite {proj} ((_ zero_extend 8) {pending}) {bv(0,12)}))',
        'weight-prefix-counters':f'(=> {state(G,[4])} '+conj([f'(= {gw} (bvsub ((_ zero_extend 1) {issued}) ((_ zero_extend 1) {consumed})))',
            f'(bvule {consumed} {issued})',f'(bvule {issued} {n(G+"group_words_q")})',
            f'(= {n(G+"group_words_q")} (ite (= {n(G+"job_q")} {bv(6,4)}) {bv(1705,11)} {bv(640,11)}))'])+')',
        'Q-geometry':f'(=> (and {q} {active}) '+conj([f'(bvult {n(G+"layer_q")} {bv(6,3)})',f'(bvult {n(G+"group_q")} {bv(4,6)})',
            f'(= {n(G+"weight_base_word_q")} {qbase})',f'(= {n(G+"group_words_q")} {bv(640,11)})',f'(= {n(G+"group_beats_q")} {bv(256,10)})'])+')',
        'Q-metadata-descriptor':f'(=> (and {q} (= {owner} #b01) {state(M,[1,2,3,4])}) '+conj([f'(= {n(M+"group_base_word_q")} {mbase})',f'(= {n(M+"group_q")} {n(G+"group_q")})',f'(= {n(M+"valid_lanes_q")} {bv(64,7)})'])+')',
    }
    for i in range(8):
        argument=f'(select (o-address {parent}) (bvadd (o-retire {parent}) {bv(i,5)}))'
        expected=f'(bvadd {n(G+"weight_base_word_q")} (bvadd ((_ zero_extend 8) {consumed}) {bv(i,19)}))'
        guard=conj([proj,f'(= {owner} #b10)',state(G,[4]),f'(bvult {bv(i,4)} {pending})'])
        clauses[f'weight-pending-address-{i}']=f'(=> {guard} (= {argument} {expected}))'
    head=f'(select (o-address {parent}) (o-retire {parent}))'
    metaaddress=f'(bvadd {n(M+"group_base_word_q")} ((_ zero_extend 16) {n(M+"word_in_group_q")}))'
    clauses['metadata-pending-address']=f'(=> (and {proj} (= {owner} #b01) {mr} {state(M,[2])}) (= {head} {metaaddress}))'
    defs='\n'.join(f'(define-fun reader-clause-{i} ((a {S}) (h ApiHistory)) Bool {value})'for i,value in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun reader-inv ((a {S}) (h ApiHistory)) Bool (=> {live} '+conj([f'(reader-clause-{i} a h)'for i in range(len(clauses))])+'))\n'
    # The exact already-proved service conclusion is projected as a definition.
    service=json.loads((HERE/'payload-PLAN.json').read_text())['rules']['consequence']['conclusion']
    defs+=f'(define-fun reader-job-service ((a {S}) (h ApiHistory) (model (Array (_ BitVec 18) (_ BitVec 256)))) Bool {service})\n'
    weightguard=conj([live,q,n(P+'input_transfer')])
    weightaddr=f'(bvadd {qbase} ((_ zero_extend 8) {consumed}))'
    metaGuard=conj([live,q,n(M+'response_transfer'),state(M,[2])])
    metaword=f'(bvadd {mbase} ((_ zero_extend 16) {n(M+"word_in_group_q")}))'
    goals=[f'(=> {weightguard} (= {n(P+"ddr_word_data")} (select model ((_ extract 17 0) {weightaddr}))))',
        f'(=> {metaGuard} (= {n(M+"private_word_rsp_data_i")} (select model ((_ extract 17 0) {metaword}))))']
    return defs,clauses,goals


def specification():
    _,clauses,goals=definitions();h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    step=[h('a'),h('an'),t,'(api-inv a h)','(reader-inv a h)','(= hn (api-next a h))']
    # A checked parts-join retains the complete induction obligation.
    resetnext=n('reset_n').replace(' a)',' an)')
    liveNext=conj([resetnext,'(not '+n(A+'fail_q').replace(' a)',' an)')+')',n('u_native.child_reset_n').replace(' a)',' an)'),'(not '+n(G+'fail_closed_o').replace(' a)',' an)')+')'])
    parts=[f'(=> {liveNext} (reader-clause-{i} an hn))'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=initial,conclusion='(reader-inv an api-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(reader-inv an hn)'),
        'consequence':dict(assumptions=[h('a'),'(api-inv a h)','(reader-inv a h)',n('reset_n'),'(reader-job-service a h model)'],conclusion=conj(goals)),
        'reset-context':dict(assumptions=initial+[resetnext],conclusion='false',expected='sat')}
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ApiHistory)','(declare-const hn ApiHistory)',
        '(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():return ['connected/native.smt2','ordered/history.smt2','api/history.smt2','reader/history.smt2']


def main():
    defs,clauses,_=definitions();d=HERE/'reader';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    rules,declarations=specification();bodies=body_files();files=[*bodies,'connected-SOURCES.json','api-PLAN.json','payload-PLAN.json']
    bounds=json.loads((HERE/'payload-PLAN.json').read_text())['root_external_assumptions']
    write_json(HERE/'reader-PLAN.json',dict(schema='Typed-native-reader-refinement-v1',source_manifest='connected-SOURCES.json',
        inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),
        checks_file='reader-CHECKS.json',providers=dict(invariant='api',word='payload'),root_external_assumptions=bounds,
        whole_Q_consumption_proved=False,whole_machine_theorem=False,
        observations=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',A+'fail_q',D+'ddr_owner_q',D+'ddr_pending_q',G+'state_q',G+'owner_q',G+'fail_closed_o',G+'outstanding_words_q',G+'issued_words_q',G+'consumed_words_q',M+'state_q',M+'request_outstanding_q',G+'clear_i']]+[f'(reader-clause-{i} an hn)'for i in range(len(clauses))]))
    write_json(d/'CLAUSES.json',dict(enumerate(clauses)));print('Frozen no-value ownership/address induction at actual Q packer and metadata response consumes.')


if __name__=='__main__':main()

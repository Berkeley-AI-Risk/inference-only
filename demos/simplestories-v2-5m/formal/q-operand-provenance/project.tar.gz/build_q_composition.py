"""Literal current-state application of the four completed Q operand results."""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj
from build_ordered import TOP,S,n

PROVIDERS=['words','parentcapture','macmodel','tilemeta']
NAMES=['Q-model-beats-at-tile-capture','Q-current-activation-and-native-registers','Q-model-coefficients-at-MAC-use','Q-row-metadata-at-postscale']
ARGS=f'((a {S}) (h ApiHistory) (w WordsHistory) (ch CaptureHistory) (model (Array (_ BitVec 18) (_ BitVec 256))))'


def definitions():
    return '; Main Q operand-provenance postcondition.\n; Native source-bound induction and literal provider application are in\n; qcomposition-PLAN.json; the four expanded predicates are in conclusions.smt2.\n'+f'(define-fun Q-operands-theorem {ARGS} Bool '+conj([f'({name} a h w ch model)'for name in NAMES])+')\n'


def conclusions():
    conclusions=[json.loads((HERE/(p+'-PLAN.json')).read_text())['rules']['consequence']['conclusion']for p in PROVIDERS]
    return '\n'.join(f'(define-fun {name} {ARGS} Bool {goal})'for name,goal in zip(NAMES,conclusions))+'\n'


def specification():
    declarations=[];facts=[];imports=[]
    for label in PROVIDERS:
        p=json.loads((HERE/(label+'-PLAN.json')).read_text());rule=p['rules']['consequence']
        declarations.extend(d for d in p['declarations']if d not in declarations)
        facts.extend(f for f in rule['assumptions']if f not in facts)
        imports.append('(=> '+conj(rule['assumptions'])+' '+rule['conclusion']+')')
    return {'joined-theorem':dict(assumptions=facts+imports,conclusion='(Q-operands-theorem a h w ch model)')},declarations


def body_files():
    bodies=[]
    for label in PROVIDERS:
        p=json.loads((HERE/(label+'-PLAN.json')).read_text())
        bodies.extend(b for b in p['bodies']if b not in bodies)
    return bodies+['qcomposition/conclusions.smt2','qcomposition/history.smt2']


def main():
    d=HERE/'qcomposition';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(definitions());(d/'conclusions.smt2').write_text(conclusions())
    rules,declarations=specification();bodies=body_files();files=[*bodies,'connected-SOURCES.json',*[p+'-PLAN.json'for p in PROVIDERS]]
    write_json(HERE/'qcomposition-PLAN.json',dict(schema='Typed-current-Q-operand-composition-v1',source_manifest='connected-SOURCES.json',inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),checks_file='qcomposition-CHECKS.json',providers=PROVIDERS,root_external_assumptions=json.loads((HERE/'words-PLAN.json').read_text())['root_external_assumptions'],whole_Q_consumption_proved=False,whole_machine_theorem=False,observations=[]))
    print('Frozen literal all-lane Q operand theorem application.')


if __name__=='__main__':main()

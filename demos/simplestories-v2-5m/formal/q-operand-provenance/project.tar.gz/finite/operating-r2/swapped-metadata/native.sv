`undef FORMAL
`define SYNTHESIS
`default_nettype none
module board1_shared_projection_scale_group_adapter (
    input  wire                     clk,
    input  wire                     reset_n,
    input  wire                     clear_i,
    input  wire                     model_locked_i,
    input  wire                     upstream_fail_closed_i,

    input  wire                     group_valid_i,
    output logic                    group_ready_o,
    input  wire [2:0]               group_layer_i,
    input  wire [3:0]               group_job_i,
    input  wire [5:0]               group_index_i,
    input  wire [6:0]               group_valid_lanes_i,
    input  wire [64*8-1:0]          group_row_exponent_i,
    input  wire [64*16-1:0]         group_row_multiplier_i,
    input  wire signed [7:0]        activation_exponent_i,

    input  wire                     weight_valid_i,
    output logic                    weight_ready_o,
    input  wire signed [15:0]       activation_i,
    input  wire [64*10-1:0]         weight_data_i,
    input  wire                     weight_last_i,

    output logic                    result_valid_o,
    input  wire                     result_ready_i,
    output logic [12:0]             result_row_index_o,
    output logic signed [49:0]      result_scaled_raw_o,
    output logic signed [7:0]       result_source_exponent_o,
    output logic                    result_last_o,

    output logic                    done_valid_o,
    input  wire                     done_ready_i,
    output logic                    busy_o,
    output logic                    fail_closed_o
);
    typedef enum logic [2:0] {
        AD_IDLE    = 3'd0,
        AD_META    = 3'd1,
        AD_WEIGHTS = 3'd2,
        AD_WAIT    = 3'd3,
        AD_FAIL    = 3'd4
    } adapter_state_t;

    adapter_state_t state_q;
    logic [2:0] layer_q;
    logic [3:0] job_q;
    logic [5:0] group_q;
    logic [6:0] valid_lanes_q;
    logic signed [7:0] activation_exponent_q;
    logic [5:0] metadata_lane_q;
    logic fail_q;

    function automatic [6:0] groups_for_job(input logic [3:0] job);
        case (job)
            4'd0, 4'd3, 4'd6: groups_for_job = 7'd4;
            4'd1, 4'd2:       groups_for_job = 7'd2;
            4'd4, 4'd5:       groups_for_job = 7'd11;
            4'd7:             groups_for_job = 7'd63;
            default:          groups_for_job = 7'd0;
        endcase
    endfunction

    function automatic [6:0] last_group_lanes(input logic [3:0] job);
        case (job)
            4'd4, 4'd5: last_group_lanes = 7'd42;
            4'd7:       last_group_lanes = 7'd51;
            4'd0, 4'd1, 4'd2, 4'd3, 4'd6:
                         last_group_lanes = 7'd64;
            default:    last_group_lanes = 7'd0;
        endcase
    endfunction

    function automatic source_exponent_valid(
        input logic signed [7:0] activation_exponent,
        input logic [7:0] row_exponent
    );
        logic signed [10:0] sum;
        begin
            sum = $signed({{3{activation_exponent[7]}},
                           activation_exponent}) +
                  $signed({{3{row_exponent[7]}}, row_exponent}) -
                  11'sd15;
            source_exponent_valid = (sum >= -11'sd128) &&
                                    (sum <= 11'sd127);
        end
    endfunction

    logic [6:0] descriptor_groups;
    logic [6:0] descriptor_valid_lanes;
    logic descriptor_valid;
    logic header_protocol_error;
    integer check_lane;
    always @* begin
        descriptor_groups = groups_for_job(group_job_i);
        descriptor_valid_lanes =
            ({1'b0, group_index_i} == descriptor_groups - 7'd1) ?
            last_group_lanes(group_job_i) : 7'd64;
        descriptor_valid = (descriptor_groups != 7'd0) &&
            ({1'b0, group_index_i} < descriptor_groups) &&
            (((group_job_i == 4'd7) && (group_layer_i == 3'd7)) ||
             ((group_job_i < 4'd7) && (group_layer_i < 3'd6)));
        header_protocol_error = !descriptor_valid ||
            (group_valid_lanes_i != descriptor_valid_lanes);
        for (check_lane = 0; check_lane < 64;
             check_lane = check_lane + 1) begin
            if (check_lane < descriptor_valid_lanes) begin
                if ((group_row_multiplier_i[check_lane*16 +: 16] ==
                     16'd0) ||
                    group_row_multiplier_i[check_lane*16 + 15] ||
                    !source_exponent_valid(
                        activation_exponent_i,
                        group_row_exponent_i[check_lane*8 +: 8]))
                    header_protocol_error = 1'b1;
            end else if ((group_row_exponent_i[check_lane*8 +: 8] !=
                          8'd0) ||
                         (group_row_multiplier_i[
                              check_lane*16 +: 16] != 16'd0)) begin
                header_protocol_error = 1'b1;
            end
        end
    end

    logic engine_start_valid;
    wire engine_start_ready;
    logic engine_metadata_valid;
    wire engine_metadata_ready;
    logic engine_weight_valid;
    wire engine_weight_ready;
    wire engine_result_valid;
    wire [12:0] engine_result_row;
    wire signed [49:0] engine_result_scaled;
    wire signed [7:0] engine_result_exponent;
    wire engine_result_last;
    wire engine_done_valid;
    wire engine_busy;
    wire engine_fail;

    wire engine_start_transfer = engine_start_valid && engine_start_ready;
    wire engine_metadata_transfer = engine_metadata_valid &&
                                    engine_metadata_ready;
    wire weight_transfer = weight_valid_i && weight_ready_o;
    wire done_transfer = done_valid_o && done_ready_i;
    wire metadata_is_last =
        ({1'b0, metadata_lane_q} == valid_lanes_q - 7'd1);
    wire [12:0] metadata_row =
        {1'b0, group_q, 6'b000000} +
        {{7{1'b0}}, metadata_lane_q};
    wire signed [7:0] selected_metadata_exponent =
        group_row_exponent_i[metadata_lane_q*8 +: 8];

    always @* begin
        engine_start_valid = (state_q == AD_IDLE) && group_valid_i &&
                             !header_protocol_error &&
                             model_locked_i &&
                             !upstream_fail_closed_i && !fail_q &&
                             !clear_i;
        engine_metadata_valid = (state_q == AD_META) && group_valid_i &&
                                model_locked_i &&
                                !upstream_fail_closed_i && !fail_q &&
                                !clear_i;
        engine_weight_valid = (state_q == AD_WEIGHTS) && weight_valid_i &&
                              model_locked_i &&
                              !upstream_fail_closed_i && !fail_q &&
                              !clear_i;

        // The packed header is accepted on the same edge as its final scalar
        // metadata row.  Until then the producer must hold it immutable.
        group_ready_o = engine_metadata_valid && engine_metadata_ready &&
                        metadata_is_last;
        weight_ready_o = (state_q == AD_WEIGHTS) ? engine_weight_ready :
                         1'b0;

        result_valid_o = engine_result_valid;
        result_row_index_o = engine_result_row;
        result_scaled_raw_o = engine_result_scaled;
        result_source_exponent_o = engine_result_exponent;
        result_last_o = engine_result_last;
        done_valid_o = engine_done_valid;
        busy_o = ((state_q != AD_IDLE) && (state_q != AD_FAIL)) ||
                 engine_busy;
        fail_closed_o = fail_q || engine_fail ||
                        upstream_fail_closed_i;
    end

`ifndef SYNTHESIS
    logic simulation_x_fault;
    always @* begin
        simulation_x_fault = $isunknown(clear_i) ||
            $isunknown(model_locked_i) ||
            $isunknown(upstream_fail_closed_i) ||
            $isunknown(group_valid_i) || $isunknown(weight_valid_i);
        if (group_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(group_layer_i) || $isunknown(group_job_i) ||
                $isunknown(group_index_i) ||
                $isunknown(group_valid_lanes_i) ||
                $isunknown(group_row_exponent_i) ||
                $isunknown(group_row_multiplier_i) ||
                $isunknown(activation_exponent_i);
        if (weight_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(activation_i) || $isunknown(weight_data_i) ||
                $isunknown(weight_last_i);
        if (result_valid_o === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(result_ready_i);
        if (done_valid_o === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(done_ready_i);
    end
`endif

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state_q <= AD_IDLE;
            layer_q <= 3'd0;
            job_q <= 4'd0;
            group_q <= 6'd0;
            valid_lanes_q <= 7'd0;
            activation_exponent_q <= 8'sd0;
            metadata_lane_q <= 6'd0;
            fail_q <= 1'b0;
        end else if (clear_i === 1'b1) begin
            state_q <= AD_IDLE;
            layer_q <= 3'd0;
            job_q <= 4'd0;
            group_q <= 6'd0;
            valid_lanes_q <= 7'd0;
            activation_exponent_q <= 8'sd0;
            metadata_lane_q <= 6'd0;
            fail_q <= 1'b0;
        end else if (upstream_fail_closed_i || engine_fail ||
                     (((state_q != AD_IDLE) && (state_q != AD_FAIL)) &&
                      !model_locked_i) ||
                     ((state_q == AD_IDLE) && group_valid_i &&
                      header_protocol_error) ||
                     ((state_q == AD_META) &&
                      (!group_valid_i ||
                       (group_layer_i != layer_q) ||
                       (group_job_i != job_q) ||
                       (group_index_i != group_q) ||
                       (group_valid_lanes_i != valid_lanes_q) ||
                       (activation_exponent_i != activation_exponent_q) ||
                       header_protocol_error)) ||
                     ((state_q != AD_META) &&
                      (state_q != AD_IDLE) && group_valid_i) ||
                     ((state_q != AD_WEIGHTS) && weight_valid_i)) begin
            state_q <= AD_FAIL;
            fail_q <= 1'b1;
`ifndef SYNTHESIS
        end else if (simulation_x_fault) begin
            state_q <= AD_FAIL;
            fail_q <= 1'b1;
`endif
        end else begin
            case (state_q)
                AD_IDLE: begin
                    if (engine_start_transfer) begin
                        layer_q <= group_layer_i;
                        job_q <= group_job_i;
                        group_q <= group_index_i;
                        valid_lanes_q <= group_valid_lanes_i;
                        activation_exponent_q <= activation_exponent_i;
                        metadata_lane_q <= 6'd0;
                        state_q <= AD_META;
                    end
                end

                AD_META: begin
                    if (engine_metadata_transfer) begin
                        if (metadata_is_last) begin
                            metadata_lane_q <= 6'd0;
                            state_q <= AD_WEIGHTS;
                        end else begin
                            metadata_lane_q <= metadata_lane_q + 6'd1;
                        end
                    end
                end

                AD_WEIGHTS: begin
                    if (weight_transfer && weight_last_i)
                        state_q <= AD_WAIT;
                end

                AD_WAIT: begin
                    if (done_transfer)
                        state_q <= AD_IDLE;
                end

                default: begin
                    state_q <= AD_FAIL;
                    fail_q <= 1'b1;
                end
            endcase
        end
    end

    board1_clustered_projection_scale2 u_engine (
        .clk(clk), .reset_n(reset_n), .clear_i(clear_i),
        .model_locked_i(model_locked_i),
        .upstream_fail_closed_i(upstream_fail_closed_i || fail_q),
        .start_valid_i(engine_start_valid),
        .start_ready_o(engine_start_ready),
        .fixed_layer_i((state_q == AD_IDLE) ? group_layer_i : layer_q),
        .fixed_job_i((state_q == AD_IDLE) ? group_job_i : job_q),
        .fixed_group_i((state_q == AD_IDLE) ? group_index_i : group_q),
        .activation_exponent_i((state_q == AD_IDLE) ?
            activation_exponent_i : activation_exponent_q),
        .metadata_valid_i(engine_metadata_valid),
        .metadata_ready_o(engine_metadata_ready),
        .metadata_exponent_i(selected_metadata_exponent),
        .metadata_multiplier_i(group_row_multiplier_i[
            metadata_lane_q*16 +: 16]),
        .metadata_row_index_i(metadata_row),
        .metadata_last_i(metadata_is_last),
        .weight_valid_i(engine_weight_valid),
        .weight_ready_o(engine_weight_ready),
        .activation_i(activation_i), .weight_data_i(weight_data_i),
        .weight_last_i(weight_last_i),
        .result_valid_o(engine_result_valid),
        .result_ready_i(result_ready_i),
        .result_row_index_o(engine_result_row),
        .result_scaled_raw_o(engine_result_scaled),
        .result_source_exponent_o(engine_result_exponent),
        .result_last_o(engine_result_last),
        .done_valid_o(engine_done_valid), .done_ready_i(done_ready_i),
        .busy_o(engine_busy), .fail_closed_o(engine_fail)
    );

`ifdef FORMAL
    logic formal_past_valid;
    initial formal_past_valid = 1'b0;
    always_ff @(posedge clk) begin
        formal_past_valid <= 1'b1;
        assert(!(group_ready_o && weight_ready_o));
        if (group_ready_o)
            assert(metadata_is_last && (state_q == AD_META));
        if (state_q == AD_META)
            assert({1'b0, metadata_lane_q} < valid_lanes_q);
        if (formal_past_valid && reset_n && $past(reset_n)) begin
            if ($past(clear_i)) begin
                assert(state_q == AD_IDLE);
                assert(!fail_q);
            end
            if ($past(fail_q) && !$past(clear_i))
                assert(fail_q);
        end
    end
`endif
endmodule

module board1_clustered_projection_scale2 (
    input wire clk, reset_n, clear_i, model_locked_i, upstream_fail_closed_i,
    input wire start_valid_i,
    output wire start_ready_o,
    input wire [2:0] fixed_layer_i,
    input wire [3:0] fixed_job_i,
    input wire [5:0] fixed_group_i,
    input wire signed [7:0] activation_exponent_i,
    input wire metadata_valid_i,
    output wire metadata_ready_o,
    input wire signed [7:0] metadata_exponent_i,
    input wire [15:0] metadata_multiplier_i,
    input wire [12:0] metadata_row_index_i,
    input wire metadata_last_i,
    input wire weight_valid_i,
    output wire weight_ready_o,
    input wire signed [15:0] activation_i,
    input wire [639:0] weight_data_i,
    input wire weight_last_i,
    output wire result_valid_o,
    input wire result_ready_i,
    output wire [12:0] result_row_index_o,
    output wire signed [49:0] result_scaled_raw_o,
    output wire signed [7:0] result_source_exponent_o,
    output wire result_last_o,
    output wire done_valid_o,
    input wire done_ready_i,
    output wire busy_o, fail_closed_o
);
    localparam [2:0] IDLE=0, META=1, WEIGHTS=2, DRAIN=3, EMIT=4, DONE=5, FAIL=7;
    logic [2:0] state_q;
    logic fail_q;
    logic [5:0] group_q;
    logic [6:0] valid_lanes_q, metadata_count_q, issue_count_q;
    logic [9:0] columns_q, column_q;
    logic signed [7:0] activation_exponent_q;
    logic [6:0] descriptor_groups, descriptor_lanes;
    logic [9:0] descriptor_columns;
    // always_comb also evaluates the fixed job-0/group-0 descriptor at time
    // zero; it must not depend on those initially-zero inputs changing first.
    always_comb begin
        descriptor_groups = 0;
        case (fixed_job_i)
            0,3,6: descriptor_groups = 4;
            1,2: descriptor_groups = 2;
            4,5: descriptor_groups = 11;
            7: descriptor_groups = 63;
            default: descriptor_groups = 0;
        endcase
        descriptor_columns = (fixed_job_i == 6) ? 10'd682 : 10'd256;
        descriptor_lanes = 64;
        if ({1'b0,fixed_group_i} == descriptor_groups-7'd1) begin
            if (fixed_job_i == 4 || fixed_job_i == 5) descriptor_lanes = 42;
            if (fixed_job_i == 7) descriptor_lanes = 51;
        end
    end
    wire descriptor_ok = descriptor_groups != 0 &&
        {1'b0,fixed_group_i} < descriptor_groups &&
        ((fixed_job_i == 7 && fixed_layer_i == 7) ||
         (fixed_job_i < 7 && fixed_layer_i < 6));
    wire [12:0] row_base = {1'b0,group_q,6'b0};
    wire signed [10:0] exponent_sum =
        $signed({{3{activation_exponent_q[7]}},activation_exponent_q}) +
        $signed({{3{metadata_exponent_i[7]}},metadata_exponent_i}) - 11'sd15;
    wire metadata_error =
        metadata_row_index_i != row_base + {6'b0,metadata_count_q} ||
        metadata_last_i != (metadata_count_q == valid_lanes_q-7'd1) ||
        metadata_multiplier_i == 0 || metadata_multiplier_i[15] ||
        exponent_sum < -11'sd128 || exponent_sum > 11'sd127;
    wire [3:0] tile_fault, tile_done;
    wire live = model_locked_i && !clear_i && !upstream_fail_closed_i &&
                !fail_q && !(|tile_fault);
    assign start_ready_o = state_q == IDLE && live;
    assign metadata_ready_o = state_q == META && live;
    assign weight_ready_o = state_q == WEIGHTS && live;
    assign busy_o = state_q != IDLE && state_q != FAIL;
    assign fail_closed_o = fail_q || upstream_fail_closed_i || (|tile_fault);
    wire start_fire = start_valid_i && start_ready_o;
    wire metadata_fire = metadata_valid_i && metadata_ready_o;
    wire weight_fire = weight_valid_i && weight_ready_o;
    wire kill = clear_i || fail_q || upstream_fail_closed_i || !model_locked_i;

    wire signed [34:0] tile_dot [0:3];
    wire [15:0] tile_multiplier [0:3];
    wire signed [7:0] tile_exponent [0:3];
    logic [3:0] scale_valid_q;
    logic [1:0] selected_tile_q;
    logic [5:0] row_pipe_q [0:3];
    logic signed [7:0] exponent_pipe_q [1:3];
    logic signed [26:0] low_operand_q, high_operand_q;
    logic signed [17:0] scale_operand_q;
    wire signed [47:0] low_product, high_product;
    logic signed [47:0] low_product_q, high_product_q;
    logic signed [49:0] result_q;
    wire advance = !scale_valid_q[3] || result_ready_i;
    wire issue = state_q == EMIT && issue_count_q < valid_lanes_q && advance && live;

    genvar tile;
    generate for (tile=0; tile<4; tile=tile+1) begin : g_tile
        wire [4:0] tile_lanes = (descriptor_lanes >= (tile+1)*16) ? 5'd16 :
            (descriptor_lanes <= tile*16) ? 5'd0 : 5'(descriptor_lanes-tile*16);
        board1_projection_tile16 u_tile (
            .clk(clk), .reset_n(reset_n), .kill_i(kill),
            .begin_i(start_fire && descriptor_ok), .valid_lanes_i(tile_lanes),
            .accept_i(weight_fire), .first_i(column_q == 0),
            .last_i(column_q == columns_q-10'd1), .activation_i(activation_i),
            .weights_i(weight_data_i[tile*160 +: 160]),
            .metadata_write_i(metadata_fire && !metadata_error && metadata_count_q[5:4] == tile),
            .metadata_lane_i(metadata_count_q[3:0]),
            .metadata_multiplier_i(metadata_multiplier_i),
            .metadata_exponent_i(exponent_sum[7:0]),
            .read_i(issue), .read_lane_i(issue_count_q[3:0]),
            .dot_o(tile_dot[tile]), .multiplier_o(tile_multiplier[tile]),
            .exponent_o(tile_exponent[tile]), .done_o(tile_done[tile]),
            .fault_o(tile_fault[tile]));
    end endgenerate

    board1_projection_postscale_mul u_scale_low (
        .a_i(low_operand_q), .b_i(scale_operand_q), .product_o(low_product));
    board1_projection_postscale_mul u_scale_high (
        .a_i(high_operand_q), .b_i(scale_operand_q), .product_o(high_product));

    // Read tiles -> select/register operands -> multiply/register -> add.
    // One global advance freezes all data and tags together on backpressure.
    // No payload reset: each valid tag is created only by its matching write.
    always_ff @(posedge clk) begin
        if (advance) begin
            if (issue) begin
                selected_tile_q <= issue_count_q[5:4];
                row_pipe_q[0] <= issue_count_q[5:0];
            end
            if (scale_valid_q[0]) begin
                low_operand_q <= {2'b00,tile_dot[selected_tile_q][24:0]};
                high_operand_q <= {{17{tile_dot[selected_tile_q][34]}},tile_dot[selected_tile_q][34:25]};
                scale_operand_q <= {2'b00,tile_multiplier[selected_tile_q]};
                row_pipe_q[1] <= row_pipe_q[0];
                exponent_pipe_q[1] <= tile_exponent[selected_tile_q];
            end
            if (scale_valid_q[1]) begin
                low_product_q <= low_product;
                high_product_q <= high_product;
                row_pipe_q[2] <= row_pipe_q[1];
                exponent_pipe_q[2] <= exponent_pipe_q[1];
            end
            if (scale_valid_q[2]) begin
                result_q <= $signed({2'b00,low_product_q}) +
                    ($signed({{2{high_product_q[47]}},high_product_q}) <<< 25);
                row_pipe_q[3] <= row_pipe_q[2];
                exponent_pipe_q[3] <= exponent_pipe_q[2];
            end
        end
    end
    assign result_valid_o = state_q == EMIT && scale_valid_q[3] && live;
    // Private metadata is meaningful only with result_valid_o.
    // Keep the fault/CLEAR gates on VALID and every accepted transfer.
    assign result_row_index_o = row_base + {7'b0,row_pipe_q[3]};
    assign result_scaled_raw_o = result_valid_o ? result_q : 50'sd0;
    assign result_source_exponent_o = result_valid_o ? exponent_pipe_q[3] : 8'sd0;
    assign result_last_o = {1'b0,row_pipe_q[3]} == valid_lanes_q-7'd1;
    assign done_valid_o = state_q == DONE && live;

    wire control_error = upstream_fail_closed_i || (|tile_fault) ||
        ((state_q != IDLE && state_q != FAIL) && !model_locked_i) ||
        (start_valid_i && !start_ready_o) ||
        (metadata_valid_i && state_q != META) ||
        (weight_valid_i && state_q != WEIGHTS) ||
        ((|tile_done) && !(&tile_done));
`ifndef SYNTHESIS
    logic x_error;
    always @* begin
        // Individual operands avoid an Icarus $isunknown(concatenation)
        // temporary-value bug; the checked bits are unchanged.
        x_error = $isunknown(clear_i) || $isunknown(model_locked_i) ||
            $isunknown(upstream_fail_closed_i) || $isunknown(start_valid_i) ||
            $isunknown(metadata_valid_i) || $isunknown(weight_valid_i);
        if (start_valid_i) x_error = x_error || $isunknown(fixed_layer_i) ||
            $isunknown(fixed_job_i) || $isunknown(fixed_group_i) || $isunknown(activation_exponent_i);
        if (metadata_valid_i) x_error = x_error || $isunknown(metadata_exponent_i) ||
            $isunknown(metadata_multiplier_i) || $isunknown(metadata_row_index_i) || $isunknown(metadata_last_i);
        if (weight_valid_i) x_error = x_error || $isunknown(activation_i) ||
            $isunknown(weight_data_i) || $isunknown(weight_last_i);
        if (result_valid_o) x_error = x_error || $isunknown(result_ready_i);
        if (done_valid_o) x_error = x_error || $isunknown(done_ready_i);
    end
`endif
    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state_q <= IDLE; fail_q <= 0; group_q <= 0;
            valid_lanes_q <= 0; metadata_count_q <= 0; issue_count_q <= 0;
            columns_q <= 0; column_q <= 0; activation_exponent_q <= 0;
            scale_valid_q <= 0;
        end else if (clear_i === 1'b1) begin
            state_q <= IDLE; fail_q <= 0;
            metadata_count_q <= 0; issue_count_q <= 0; column_q <= 0;
            scale_valid_q <= 0;
        end else if (control_error
`ifndef SYNTHESIS
            || x_error
`endif
        ) begin
            state_q <= FAIL; fail_q <= 1; scale_valid_q <= 0;
        end else begin
            if (advance) scale_valid_q <= {scale_valid_q[2:0],issue};
            case (state_q)
                IDLE: if (start_fire) begin
                    if (!descriptor_ok) begin state_q <= FAIL; fail_q <= 1; end
                    else begin
                        group_q <= fixed_group_i; columns_q <= descriptor_columns;
                        valid_lanes_q <= descriptor_lanes;
                        activation_exponent_q <= activation_exponent_i;
                        metadata_count_q <= 0; column_q <= 0; issue_count_q <= 0;
                        scale_valid_q <= 0; state_q <= META;
                    end
                end
                META: if (metadata_fire) begin
                    if (metadata_error) begin state_q <= FAIL; fail_q <= 1; end
                    else if (metadata_count_q == valid_lanes_q-7'd1) state_q <= WEIGHTS;
                    else metadata_count_q <= metadata_count_q+7'd1;
                end
                WEIGHTS: if (weight_fire) begin
                    if (weight_last_i != (column_q == columns_q-10'd1)) begin
                        state_q <= FAIL; fail_q <= 1;
                    end else if (column_q == columns_q-10'd1) state_q <= DRAIN;
                    else column_q <= column_q+10'd1;
                end
                DRAIN: if (&tile_done) state_q <= EMIT;
                EMIT: begin
                    if (issue) issue_count_q <= issue_count_q+7'd1;
                    if (result_valid_o && result_ready_i && result_last_o) state_q <= DONE;
                end
                DONE: if (done_ready_i) state_q <= IDLE;
                default: begin state_q <= FAIL; fail_q <= 1; scale_valid_q <= 0; end
            endcase
        end
    end
endmodule

module board1_projection_dsp_accumulator(
    input wire clk,multiply_i,accumulate_i,first_i,
    input wire signed [15:0] activation_i,
    input wire signed [9:0] weight_i,
    output wire signed [47:0] accumulator_o
);
    wire signed [26:0] weight_operand={{17{weight_i[9]}},weight_i};
    wire signed [17:0] activation_operand={{2{activation_i[15]}},activation_i};
`ifdef BOARD1_PROJECTION_MAC_NATIVE
    MULTALU27X18 #(
        .AREG_CLK("BYPASS"), .BREG_CLK("BYPASS"),
        .DREG_CLK("BYPASS"), .C_IREG_CLK("BYPASS"),
        .PSEL_IREG_CLK("BYPASS"), .PADDSUB_IREG_CLK("BYPASS"),
        .ADDSUB0_IREG_CLK("BYPASS"), .ADDSUB1_IREG_CLK("BYPASS"),
        .CSEL_IREG_CLK("BYPASS"), .CASISEL_IREG_CLK("BYPASS"),
        .ACCSEL_IREG_CLK("BYPASS"), .PREG_CLK("CLK0"), .PREG_CE("CE0"),
        .ADDSUB0_PREG_CLK("BYPASS"), .ADDSUB1_PREG_CLK("BYPASS"),
        .CSEL_PREG_CLK("BYPASS"), .CASISEL_PREG_CLK("BYPASS"),
        .ACCSEL_PREG_CLK("BYPASS"), .C_PREG_CLK("BYPASS"),
        .OREG_CLK("CLK0"), .OREG_CE("CE1"), .FB_PREG_EN("FALSE"),
        .SOA_PREG_EN("FALSE"), .PRE_LOAD(48'd0),
        .DYN_P_SEL("FALSE"), .P_SEL(1'b0),
        .DYN_P_ADDSUB("FALSE"), .P_ADDSUB(1'b0),
        .DYN_A_SEL("FALSE"), .A_SEL(1'b0),
        .DYN_ADD_SUB_0("FALSE"), .ADD_SUB_0(1'b0),
        .DYN_ADD_SUB_1("FALSE"), .ADD_SUB_1(1'b0),
        .DYN_C_SEL("FALSE"), .C_SEL(1'b0),
        .DYN_CASI_SEL("FALSE"), .CASI_SEL(1'b0),
        .DYN_ACC_SEL("TRUE"), .ACC_SEL(1'b0),
        .MULT12X12_EN("FALSE")
    ) u_signed_product (
        .DOUT(accumulator_o), .CASO(), .SOA(),
        .A(weight_operand), .SIA(27'd0), .B(activation_operand),
        .C(48'd0), .D(26'd0), .CASI(48'd0),
        .ACCSEL(!first_i), .PSEL(1'b0), .ASEL(1'b0),
        .PADDSUB(1'b0), .CSEL(1'b0), .CASISEL(1'b0),
        .ADDSUB(2'b00),
        .CLK({1'b0,clk}), .CE({accumulate_i,multiply_i}), .RESET(2'b00)
    );
`else
    reg signed [25:0] product_q;
    reg signed [47:0] accumulator_q;
    always @(posedge clk)begin
        if(multiply_i)product_q<=activation_i*weight_i;
        if(accumulate_i)accumulator_q<=(first_i ? 48'sd0 : accumulator_q)+
            {{22{product_q[25]}},product_q};
    end
    assign accumulator_o=accumulator_q;
`endif
endmodule

module board1_projection_postscale_mul (
    input wire signed [26:0] a_i,
    input wire signed [17:0] b_i,
    output wire signed [47:0] product_o
);
`ifdef BOARD1_GW5_DSP
    MULTALU27X18 #(
        .AREG_CLK("BYPASS"), .BREG_CLK("BYPASS"), .DREG_CLK("BYPASS"),
        .C_IREG_CLK("BYPASS"), .PSEL_IREG_CLK("BYPASS"),
        .PADDSUB_IREG_CLK("BYPASS"), .ADDSUB0_IREG_CLK("BYPASS"),
        .ADDSUB1_IREG_CLK("BYPASS"), .CSEL_IREG_CLK("BYPASS"),
        .CASISEL_IREG_CLK("BYPASS"), .ACCSEL_IREG_CLK("BYPASS"),
        .PREG_CLK("BYPASS"), .ADDSUB0_PREG_CLK("BYPASS"),
        .ADDSUB1_PREG_CLK("BYPASS"), .CSEL_PREG_CLK("BYPASS"),
        .CASISEL_PREG_CLK("BYPASS"), .ACCSEL_PREG_CLK("BYPASS"),
        .C_PREG_CLK("BYPASS"), .OREG_CLK("BYPASS"),
        .FB_PREG_EN("FALSE"), .SOA_PREG_EN("FALSE"), .PRE_LOAD(48'd0),
        .DYN_P_SEL("FALSE"), .P_SEL(1'b0), .DYN_P_ADDSUB("FALSE"),
        .P_ADDSUB(1'b0), .DYN_A_SEL("FALSE"), .A_SEL(1'b0),
        .DYN_ADD_SUB_0("FALSE"), .ADD_SUB_0(1'b0),
        .DYN_ADD_SUB_1("FALSE"), .ADD_SUB_1(1'b0),
        .DYN_C_SEL("FALSE"), .C_SEL(1'b0), .DYN_CASI_SEL("FALSE"),
        .CASI_SEL(1'b0), .DYN_ACC_SEL("FALSE"), .ACC_SEL(1'b0),
        .MULT12X12_EN("FALSE")
    ) u_mul (
        .DOUT(product_o), .CASO(), .SOA(), .A(a_i), .B(b_i),
        .SIA(27'd0), .C(48'd0), .D(26'd0), .CASI(48'd0),
        .ACCSEL(1'b0), .PSEL(1'b0), .ASEL(1'b0), .PADDSUB(1'b0),
        .CSEL(1'b0), .CASISEL(1'b0), .ADDSUB(2'b00),
        .CLK(2'b00), .CE(2'b00), .RESET(2'b00));
`else
    assign product_o = a_i * b_i;
`endif
endmodule

module board1_projection_tile16 (
    input wire clk, reset_n, kill_i, begin_i,
    input wire [4:0] valid_lanes_i,
    input wire accept_i, first_i, last_i,
    input wire signed [15:0] activation_i,
    input wire [159:0] weights_i,
    input wire metadata_write_i,
    input wire [3:0] metadata_lane_i,
    input wire [15:0] metadata_multiplier_i,
    input wire signed [7:0] metadata_exponent_i,
    input wire read_i,
    input wire [3:0] read_lane_i,
    output logic signed [34:0] dot_o,
    output logic [15:0] multiplier_o,
    output logic signed [7:0] exponent_o,
    output logic done_o, fault_o
);
    logic op_valid_q, product_valid_q;
    logic op_first_q, op_last_q, product_first_q, product_last_q;
    logic [4:0] valid_lanes_q;
    logic signed [15:0] activation_q;
    logic signed [9:0] weight_q [0:15];
    wire signed [34:0] accumulator_q [0:15];
    logic [15:0] multiplier_q [0:15];
    logic signed [7:0] exponent_q [0:15];
    wire [15:0] bad_weight, overflow;
    logic acc_result_valid_q, fault_q;
    // New accumulator bits appear on the old accumulation edge. Report that
    // edge's overflow immediately, then retain it in the sticky fault state.
    assign fault_o=fault_q || (acc_result_valid_q && (|overflow));

    genvar lane;
    generate for (lane=0; lane<16; lane=lane+1) begin : g_lane
        wire signed [47:0] accumulated;
        board1_projection_dsp_accumulator u_mac(
            .clk(clk),.multiply_i(op_valid_q),.accumulate_i(product_valid_q),
            .first_i(product_first_q),.activation_i(activation_q),
            .weight_i(weight_q[lane]),.accumulator_o(accumulated));
        assign accumulator_q[lane]=accumulated[34:0];
        assign overflow[lane]=accumulated[35]!=accumulated[34];
        assign bad_weight[lane] = (weights_i[lane*10 +: 10] == 10'h200) ||
            ((lane >= valid_lanes_q) && (weights_i[lane*10 +: 10] != 10'd0));
        always_ff @(posedge clk) begin
            if (accept_i) weight_q[lane] <= weights_i[lane*10 +: 10];
        end
    end endgenerate

    always_ff @(posedge clk) begin
        if (accept_i) activation_q <= activation_i;
        if (metadata_write_i) begin
            multiplier_q[metadata_lane_i] <= metadata_multiplier_i;
            exponent_q[metadata_lane_i] <= metadata_exponent_i;
        end
        if (read_i) begin
            dot_o <= accumulator_q[read_lane_i];
            multiplier_o <= multiplier_q[read_lane_i];
            exponent_o <= exponent_q[read_lane_i];
        end
    end

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            op_valid_q <= 0; product_valid_q <= 0; acc_result_valid_q <= 0;
            op_first_q <= 0; op_last_q <= 0;
            product_first_q <= 0; product_last_q <= 0;
            valid_lanes_q <= 0; done_o <= 0; fault_q <= 0;
        end else if (kill_i || begin_i) begin
            op_valid_q <= 0; product_valid_q <= 0; acc_result_valid_q <= 0;
            op_first_q <= 0; op_last_q <= 0;
            product_first_q <= 0; product_last_q <= 0;
            done_o <= 0; fault_q <= 0;
            if (begin_i) valid_lanes_q <= valid_lanes_i;
        end else begin
            op_valid_q <= accept_i;
            product_valid_q <= op_valid_q;
            acc_result_valid_q <= product_valid_q;
            op_first_q <= first_i; op_last_q <= last_i;
            product_first_q <= op_first_q; product_last_q <= op_last_q;
            done_o <= product_valid_q && product_last_q;
            if ((accept_i && ((|bad_weight) || (activation_i == -16'sd32768))) ||
                (acc_result_valid_q && (|overflow))) fault_q <= 1;
        end
    end
endmodule

module board1_private_ddr256_to_w640 (
    input  wire         clk,
    input  wire         reset_n,

    input  wire         ddr_word_valid,
    output logic        ddr_word_ready,
    input  wire [255:0] ddr_word_data,

    output logic        weight_valid,
    input  wire         weight_ready,
    output logic [639:0] weight_data,

    // Private diagnostic/status bit.  A fixed image region may begin only at
    // this five-word boundary.  It is not a reset or public control input.
    output wire         pair_boundary
);
    localparam logic [2:0] P_EVEN_WORD0 = 3'd0;
    localparam logic [2:0] P_EVEN_WORD1 = 3'd1;
    localparam logic [2:0] P_EVEN_WORD2 = 3'd2;
    localparam logic [2:0] P_ODD_WORD1  = 3'd3;
    localparam logic [2:0] P_ODD_WORD2  = 3'd4;

    logic [2:0] phase;
    logic [255:0] low_word;
    logic [255:0] middle_word;
    logic [127:0] shared_half_word;

    wire input_transfer = ddr_word_valid && ddr_word_ready;

    assign pair_boundary = (phase == P_EVEN_WORD0);

    always_comb begin
        ddr_word_ready = 1'b0;
        weight_valid = 1'b0;
        weight_data = {640{1'b0}};

        case (phase)
            P_EVEN_WORD0,
            P_EVEN_WORD1,
            P_ODD_WORD1: begin
                ddr_word_ready = 1'b1;
            end

            P_EVEN_WORD2: begin
                // Earliest stream bit remains bit zero of the engine beat.
                weight_data = {ddr_word_data[127:0], middle_word, low_word};
                weight_valid = ddr_word_valid;
                ddr_word_ready = weight_ready;
            end

            P_ODD_WORD2: begin
                weight_data = {ddr_word_data, middle_word, shared_half_word};
                weight_valid = ddr_word_valid;
                ddr_word_ready = weight_ready;
            end

            default: begin
            end
        endcase
    end

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            phase <= P_EVEN_WORD0;
            low_word <= {256{1'b0}};
            middle_word <= {256{1'b0}};
            shared_half_word <= {128{1'b0}};
        end else if (input_transfer) begin
            case (phase)
                P_EVEN_WORD0: begin
                    low_word <= ddr_word_data;
                    phase <= P_EVEN_WORD1;
                end
                P_EVEN_WORD1: begin
                    middle_word <= ddr_word_data;
                    phase <= P_EVEN_WORD2;
                end
                P_EVEN_WORD2: begin
                    shared_half_word <= ddr_word_data[255:128];
                    phase <= P_ODD_WORD1;
                end
                P_ODD_WORD1: begin
                    middle_word <= ddr_word_data;
                    phase <= P_ODD_WORD2;
                end
                P_ODD_WORD2: begin
                    phase <= P_EVEN_WORD0;
                end
                default: begin
                    phase <= P_EVEN_WORD0;
                end
            endcase
        end
    end

`ifdef FORMAL
    always_ff @(posedge clk) begin
        if (reset_n) begin
            assert (phase <= P_ODD_WORD2);
            if (weight_valid)
                assert ((phase == P_EVEN_WORD2) || (phase == P_ODD_WORD2));
            if (weight_valid && !weight_ready) begin
                assert (!ddr_word_ready);
                assert (!input_transfer);
            end
        end
    end
`endif
endmodule

module board1_fixed_group_ddr_stream #(
    parameter integer ADDR_W = 25,
    parameter integer METADATA_BASE_WORD = 211920
) (
    input  wire                    clk,
    input  wire                    reset_n,
    input  wire                    clear_i,
    input  wire                    model_locked_i,
    input  wire                    upstream_fail_closed_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,
    input  wire [2:0]              fixed_layer_i,
    input  wire [3:0]              fixed_job_i,
    input  wire [5:0]              fixed_group_i,

    output logic                   private_word_req_valid_o,
    input  wire                    private_word_req_ready_i,
    output logic [ADDR_W-1:0]      private_word_req_index_o,
    input  wire                    private_word_rsp_valid_i,
    output logic                   private_word_rsp_ready_o,
    input  wire [255:0]            private_word_rsp_data_i,
    input  wire                    private_word_rsp_fault_i,

    // One immutable header precedes every group's weight stream.
    output logic                   group_valid_o,
    input  wire                    group_ready_i,
    output logic [2:0]             group_layer_o,
    output logic [3:0]             group_job_o,
    output logic [5:0]             group_index_o,
    output logic [6:0]             group_valid_lanes_o,
    output wire [64*8-1:0]         group_row_exponent_o,
    output wire [64*16-1:0]        group_row_multiplier_o,

    output wire [639:0]            weight_data_o,
    output logic                   weight_valid_o,
    input  wire                    weight_ready_i,
    output logic                   weight_last_o,

    output logic                   done_valid_o,
    input  wire                    done_ready_i,
    output logic                   busy_o,
    output logic                   fail_closed_o
);
    localparam logic [2:0] ST_IDLE       = 3'd0;
    localparam logic [2:0] ST_META_START = 3'd1;
    localparam logic [2:0] ST_META_RUN   = 3'd2;
    localparam logic [2:0] ST_HEADER     = 3'd3;
    localparam logic [2:0] ST_WEIGHT     = 3'd4;
    localparam logic [2:0] ST_DONE       = 3'd5;
    localparam logic [2:0] ST_DRAIN      = 3'd6;
    localparam logic [2:0] ST_FAIL       = 3'd7;

    localparam logic [1:0] OWNER_NONE   = 2'd0;
    localparam logic [1:0] OWNER_META   = 2'd1;
    localparam logic [1:0] OWNER_WEIGHT = 2'd2;

    logic [2:0] state_q;
    logic [1:0] owner_q;
    logic [2:0] layer_q;
    logic [3:0] job_q;
    logic [5:0] group_q;
    logic [6:0] valid_lanes_q;
    logic [9:0] group_beats_q;
    logic [10:0] group_words_q;
    logic [ADDR_W-1:0] weight_base_word_q;
    logic [10:0] issued_words_q;
    logic [10:0] consumed_words_q;
    logic [11:0] outstanding_words_q;
    logic [9:0] accepted_beats_q;
    logic [6:0] metadata_count_q;
    logic fail_closed_q;

    logic signed [7:0] row_exponent_q [0:63];
    logic [15:0] row_multiplier_q [0:63];

    logic descriptor_valid;
    logic [6:0] descriptor_groups;
    logic [6:0] descriptor_valid_lanes;
    logic [9:0] descriptor_columns;
    logic [17:0] descriptor_beat_base;
    logic [17:0] descriptor_half_beat_base;
    logic [20:0] descriptor_word_base_wide;

    logic meta_start_valid;
    logic meta_start_ready;
    logic meta_req_valid;
    logic meta_req_ready;
    logic [ADDR_W-1:0] meta_req_index;
    logic meta_rsp_valid;
    logic meta_rsp_ready;
    logic meta_metadata_valid;
    logic meta_metadata_ready;
    logic signed [7:0] meta_exponent;
    logic [15:0] meta_multiplier;
    logic [12:0] meta_row_index;
    logic meta_last;
    logic meta_done_valid;
    logic meta_done_ready;
    logic meta_busy;
    logic meta_fail;

    logic adapter_word_ready;
    logic adapter_weight_valid;
    wire beat_buffer_ready;
    wire beat_buffer_valid;
    wire [639:0] beat_buffer_data;
    logic [639:0] adapter_weight_data;
    logic adapter_pair_boundary;
    wire adapter_reset_n = reset_n && !clear_i &&
                           (state_q == ST_WEIGHT);

    logic weight_request_accept;
    logic weight_response_accept;
    logic weight_accept;
    wire [11:0] outstanding_after_weight_transfers;
    wire outstanding_after_weight_empty;
    board1_private_outstanding_delta u_outstanding_delta (
        .count_i(outstanding_words_q),
        .request_i(weight_request_accept),
        .response_i(weight_response_accept),
        .next_o(outstanding_after_weight_transfers),
        .empty_o(outstanding_after_weight_empty)
    );
    logic metadata_transfer;
    logic meta_done_transfer;
    logic descriptor_transfer;
    logic header_transfer;
    logic done_transfer;

    function automatic [6:0] groups_for_job(input logic [3:0] job);
        case (job)
            4'd0, 4'd3, 4'd6: groups_for_job = 7'd4;
            4'd1, 4'd2:       groups_for_job = 7'd2;
            4'd4, 4'd5:       groups_for_job = 7'd11;
            4'd7:             groups_for_job = 7'd63;
            default:          groups_for_job = 7'd0;
        endcase
    endfunction

    function automatic [9:0] columns_for_job(input logic [3:0] job);
        case (job)
            4'd6: columns_for_job = 10'd682;
            4'd0, 4'd1, 4'd2, 4'd3, 4'd4, 4'd5, 4'd7:
                columns_for_job = 10'd256;
            default: columns_for_job = 10'd0;
        endcase
    endfunction

    function automatic [6:0] last_group_lanes(input logic [3:0] job);
        case (job)
            4'd4, 4'd5: last_group_lanes = 7'd42;
            4'd7:       last_group_lanes = 7'd51;
            4'd0, 4'd1, 4'd2, 4'd3, 4'd6:
                         last_group_lanes = 7'd64;
            default:    last_group_lanes = 7'd0;
        endcase
    endfunction

    function automatic [13:0] job_beat_offset(input logic [3:0] job);
        case (job)
            4'd0: job_beat_offset = 14'd0;
            4'd1: job_beat_offset = 14'd1024;
            4'd2: job_beat_offset = 14'd1536;
            4'd3: job_beat_offset = 14'd2048;
            4'd4: job_beat_offset = 14'd3072;
            4'd5: job_beat_offset = 14'd5888;
            4'd6: job_beat_offset = 14'd8704;
            default: job_beat_offset = 14'd0;
        endcase
    endfunction

    always_comb begin
        descriptor_groups = groups_for_job(fixed_job_i);
        descriptor_columns = columns_for_job(fixed_job_i);
        descriptor_valid = (descriptor_groups != 7'd0) &&
            ({1'b0, fixed_group_i} < descriptor_groups) &&
            (((fixed_job_i == 4'd7) && (fixed_layer_i == 3'd7)) ||
             ((fixed_job_i < 4'd7) && (fixed_layer_i < 3'd6)));
        descriptor_valid_lanes =
            ({1'b0, fixed_group_i} == (descriptor_groups - 7'd1)) ?
            last_group_lanes(fixed_job_i) : 7'd64;

        if (fixed_job_i == 4'd7) begin
            descriptor_beat_base = 18'd68592 +
                ({12'd0, fixed_group_i} << 8);
        end else begin
            descriptor_beat_base =
                ({15'd0, fixed_layer_i} * 18'd11432) +
                {4'd0, job_beat_offset(fixed_job_i)} +
                ({12'd0, fixed_group_i} *
                 {8'd0, descriptor_columns});
        end
        descriptor_half_beat_base = descriptor_beat_base >> 1;
        descriptor_word_base_wide =
            {3'd0, descriptor_half_beat_base} +
            ({3'd0, descriptor_half_beat_base} << 2);
    end

    genvar lane;
    generate
        for (lane = 0; lane < 64; lane = lane + 1) begin : g_metadata
            assign group_row_exponent_o[lane*8 +: 8] =
                (group_valid_o && (7'(lane) < valid_lanes_q)) ? row_exponent_q[lane] : 8'd0;
            assign group_row_multiplier_o[lane*16 +: 16] =
                (group_valid_o && (7'(lane) < valid_lanes_q)) ? row_multiplier_q[lane] : 16'd0;
        end
    endgenerate

    board1_fixed_projection_metadata_reader #(
        .ADDR_W(ADDR_W),
        .METADATA_BASE_WORD(METADATA_BASE_WORD)
    ) u_metadata_reader (
        .clk(clk), .reset_n(reset_n), .clear_i(clear_i),
        .model_locked_i(model_locked_i),
        .upstream_fail_closed_i(upstream_fail_closed_i || fail_closed_q),
        .start_valid_i(meta_start_valid), .start_ready_o(meta_start_ready),
        .fixed_layer_i(layer_q), .fixed_job_i(job_q),
        .fixed_group_i(group_q),
        .private_word_req_valid_o(meta_req_valid),
        .private_word_req_ready_i(meta_req_ready),
        .private_word_req_index_o(meta_req_index),
        .private_word_rsp_valid_i(meta_rsp_valid),
        .private_word_rsp_ready_o(meta_rsp_ready),
        .private_word_rsp_data_i(private_word_rsp_data_i),
        .private_word_rsp_fault_i(private_word_rsp_fault_i),
        .metadata_valid_o(meta_metadata_valid),
        .metadata_ready_i(meta_metadata_ready),
        .metadata_exponent_o(meta_exponent),
        .metadata_multiplier_o(meta_multiplier),
        .metadata_row_index_o(meta_row_index),
        .metadata_last_o(meta_last),
        .done_valid_o(meta_done_valid), .done_ready_i(meta_done_ready),
        .busy_o(meta_busy), .fail_closed_o(meta_fail)
    );

    board1_private_ddr256_to_w640 u_width_adapter (
        .clk(clk), .reset_n(adapter_reset_n),
        .ddr_word_valid(private_word_rsp_valid_i &&
                        (owner_q == OWNER_WEIGHT) &&
                        (state_q == ST_WEIGHT) && !fail_closed_q &&
                        !upstream_fail_closed_i && !clear_i &&
                        !private_word_rsp_fault_i),
        .ddr_word_ready(adapter_word_ready),
        .ddr_word_data(private_word_rsp_data_i),
        .weight_valid(adapter_weight_valid),
        .weight_ready(beat_buffer_ready && (state_q == ST_WEIGHT) &&
                      !fail_closed_q && !upstream_fail_closed_i),
        .weight_data(adapter_weight_data),
        .pair_boundary(adapter_pair_boundary)
    );

    board1_private_weight_beat_register u_weight_beat_register (
        .clk(clk), .reset_n(adapter_reset_n),
        .in_valid_i(adapter_weight_valid && (state_q == ST_WEIGHT) &&
                    !fail_closed_o && !clear_i),
        .in_ready_o(beat_buffer_ready), .in_data_i(adapter_weight_data),
        .out_valid_o(beat_buffer_valid), .out_ready_i(weight_accept),
        .out_data_o(beat_buffer_data)
    );
    assign weight_data_o = weight_valid_o ? beat_buffer_data : 640'd0;

    always_comb begin
        start_ready_o = (state_q == ST_IDLE) && model_locked_i &&
                        !upstream_fail_closed_i && !fail_closed_q &&
                        !meta_fail && !clear_i;
        busy_o = (state_q != ST_IDLE) && (state_q != ST_FAIL);
        fail_closed_o = fail_closed_q || meta_fail ||
                        upstream_fail_closed_i;

        meta_start_valid = (state_q == ST_META_START) &&
                           (owner_q == OWNER_META) && !fail_closed_o &&
                           !clear_i;
        meta_metadata_ready = (state_q == ST_META_RUN) &&
                              (owner_q == OWNER_META) && !fail_closed_o &&
                              !clear_i;
        meta_done_ready = (state_q == ST_META_RUN) &&
                          (metadata_count_q == valid_lanes_q) &&
                          !fail_closed_o && !clear_i;

        private_word_req_valid_o = 1'b0;
        private_word_req_index_o = {ADDR_W{1'b0}};
        meta_req_ready = 1'b0;
        if ((owner_q == OWNER_META) &&
            ((state_q == ST_META_START) || (state_q == ST_META_RUN))) begin
            private_word_req_valid_o = meta_req_valid;
            private_word_req_index_o = meta_req_index;
            meta_req_ready = private_word_req_ready_i;
        end else if ((owner_q == OWNER_WEIGHT) &&
                     (state_q == ST_WEIGHT) &&
                     (issued_words_q < group_words_q) &&
                     !fail_closed_o && !clear_i) begin
            private_word_req_valid_o = 1'b1;
            private_word_req_index_o = weight_base_word_q +
                                       ADDR_W'(issued_words_q);
        end

        meta_rsp_valid = private_word_rsp_valid_i &&
                         (owner_q == OWNER_META);
        private_word_rsp_ready_o = 1'b0;
        if (owner_q == OWNER_META) begin
            private_word_rsp_ready_o = meta_rsp_ready;
        end else if (owner_q == OWNER_WEIGHT) begin
            if (clear_i || (state_q == ST_DRAIN) ||
                (state_q == ST_FAIL) || private_word_rsp_fault_i)
                private_word_rsp_ready_o = 1'b1;
            else if (state_q == ST_WEIGHT)
                private_word_rsp_ready_o = adapter_word_ready;
        end

        group_valid_o = (state_q == ST_HEADER) && !fail_closed_o &&
                        !clear_i;
        group_layer_o = group_valid_o ? layer_q : 3'd0;
        group_job_o = group_valid_o ? job_q : 4'd0;
        group_index_o = group_valid_o ? group_q : 6'd0;
        group_valid_lanes_o = group_valid_o ? valid_lanes_q : 7'd0;

        weight_valid_o = (state_q == ST_WEIGHT) &&
                         beat_buffer_valid && !fail_closed_o && !clear_i;
        weight_last_o = weight_valid_o &&
                        (accepted_beats_q == (group_beats_q - 10'd1));
        done_valid_o = (state_q == ST_DONE) && !fail_closed_o && !clear_i;

        descriptor_transfer = start_valid_i && start_ready_o;
        metadata_transfer = meta_metadata_valid && meta_metadata_ready;
        meta_done_transfer = meta_done_valid && meta_done_ready;
        header_transfer = group_valid_o && group_ready_i;
        weight_request_accept = private_word_req_valid_o &&
                                private_word_req_ready_i &&
                                (owner_q == OWNER_WEIGHT);
        weight_response_accept = private_word_rsp_valid_i &&
                                 private_word_rsp_ready_o &&
                                 (owner_q == OWNER_WEIGHT);
        weight_accept = weight_valid_o && weight_ready_i;
        done_transfer = done_valid_o && done_ready_i;
    end

`ifndef SYNTHESIS
    logic simulation_x_fault;
    always_comb begin
        simulation_x_fault = $isunknown(clear_i) ||
            $isunknown(model_locked_i) ||
            $isunknown(upstream_fail_closed_i) ||
            $isunknown(start_valid_i) ||
            $isunknown(private_word_req_ready_i) ||
            $isunknown(private_word_rsp_valid_i) ||
            $isunknown(private_word_rsp_fault_i) ||
            $isunknown(group_ready_i) || $isunknown(weight_ready_i) ||
            $isunknown(done_ready_i);
        if (start_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(fixed_layer_i) || $isunknown(fixed_job_i) ||
                $isunknown(fixed_group_i);
        if (private_word_rsp_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(private_word_rsp_data_i);
    end
`endif

    // Resetless unpublished metadata. The control/count/validation
    // state still resets and clears exactly as before. Writes on a
    // subsequently rejected record cannot publish a header.
    always_ff @(posedge clk) begin
        if (reset_n && metadata_transfer) begin
            row_exponent_q[metadata_count_q[5:0]] <= meta_exponent;
            row_multiplier_q[metadata_count_q[5:0] ^ 6'd1] <= meta_multiplier;
        end
    end

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state_q <= ST_IDLE;
            owner_q <= OWNER_NONE;
            layer_q <= 3'd0;
            job_q <= 4'd0;
            group_q <= 6'd0;
            valid_lanes_q <= 7'd0;
            group_beats_q <= 10'd0;
            group_words_q <= 11'd0;
            weight_base_word_q <= {ADDR_W{1'b0}};
            issued_words_q <= 11'd0;
            consumed_words_q <= 11'd0;
            outstanding_words_q <= 12'd0;
            accepted_beats_q <= 10'd0;
            metadata_count_q <= 7'd0;
            fail_closed_q <= 1'b0;
        end else begin
`ifndef SYNTHESIS
            if (simulation_x_fault) begin
                state_q <= ST_FAIL;
                fail_closed_q <= 1'b1;
            end else
`endif
            if ((state_q == ST_FAIL) || fail_closed_q || meta_fail ||
                upstream_fail_closed_i) begin
                state_q <= ST_FAIL;
                fail_closed_q <= 1'b1;
                if ((owner_q == OWNER_WEIGHT) && weight_response_accept)
                    outstanding_words_q <=
                        outstanding_words_q - 12'd1;
            end else if ((private_word_rsp_valid_i &&
                          (owner_q == OWNER_NONE)) ||
                         ((owner_q == OWNER_WEIGHT) &&
                          private_word_rsp_valid_i &&
                          (outstanding_words_q == 12'd0)) ||
                         (weight_response_accept &&
                          private_word_rsp_fault_i)) begin
                state_q <= ST_FAIL;
                fail_closed_q <= 1'b1;
            end else if (clear_i) begin
                issued_words_q <= 11'd0;
                consumed_words_q <= 11'd0;
                accepted_beats_q <= 10'd0;
                metadata_count_q <= 7'd0;
                if ((owner_q == OWNER_WEIGHT) &&
                    !outstanding_after_weight_empty) begin
                    outstanding_words_q <=
                        outstanding_after_weight_transfers;
                    state_q <= ST_DRAIN;
                end else if ((owner_q == OWNER_META) && meta_busy) begin
                    outstanding_words_q <= 12'd0;
                    state_q <= ST_DRAIN;
                end else begin
                    outstanding_words_q <= 12'd0;
                    owner_q <= OWNER_NONE;
                    state_q <= ST_IDLE;
                end
            end else begin
                case (state_q)
                    ST_IDLE: begin
                        owner_q <= OWNER_NONE;
                        issued_words_q <= 11'd0;
                        consumed_words_q <= 11'd0;
                        outstanding_words_q <= 12'd0;
                        accepted_beats_q <= 10'd0;
                        metadata_count_q <= 7'd0;
                        if (descriptor_transfer) begin
                            if (!descriptor_valid ||
                                descriptor_beat_base[0] ||
                                (descriptor_word_base_wide >= 21'd211800) ||
                                ((fixed_job_i == 4'd6) &&
                                 (descriptor_columns != 10'd682)) ||
                                ((fixed_job_i != 4'd6) &&
                                 (descriptor_columns != 10'd256))) begin
                                state_q <= ST_FAIL;
                                fail_closed_q <= 1'b1;
                            end else begin
                                layer_q <= fixed_layer_i;
                                job_q <= fixed_job_i;
                                group_q <= fixed_group_i;
                                valid_lanes_q <= descriptor_valid_lanes;
                                group_beats_q <= descriptor_columns;
                                group_words_q <=
                                    (descriptor_columns == 10'd682) ?
                                    11'd1705 : 11'd640;
                                weight_base_word_q <=
                                    ADDR_W'(descriptor_word_base_wide);
                                owner_q <= OWNER_META;
                                state_q <= ST_META_START;
                            end
                        end
                    end

                    ST_META_START: begin
                        if (meta_start_valid && meta_start_ready)
                            state_q <= ST_META_RUN;
                    end

                    ST_META_RUN: begin
                        if (metadata_transfer) begin
                            if ((metadata_count_q >= valid_lanes_q) ||
                                (meta_row_index !=
                                 (({7'd0, group_q} << 6) +
                                  {6'd0, metadata_count_q})) ||
                                (meta_last !=
                                 (metadata_count_q ==
                                  (valid_lanes_q - 7'd1))) ||
                                (meta_multiplier == 16'd0) ||
                                meta_multiplier[15]) begin
                                state_q <= ST_FAIL;
                                fail_closed_q <= 1'b1;
                            end else begin
                                metadata_count_q <= metadata_count_q + 7'd1;
                            end
                        end
                        if (meta_done_transfer) begin
                            if (metadata_count_q != valid_lanes_q) begin
                                state_q <= ST_FAIL;
                                fail_closed_q <= 1'b1;
                            end else begin
                                owner_q <= OWNER_NONE;
                                state_q <= ST_HEADER;
                            end
                        end
                    end

                    ST_HEADER: begin
                        if (header_transfer) begin
                            issued_words_q <= 11'd0;
                            consumed_words_q <= 11'd0;
                            outstanding_words_q <= 12'd0;
                            accepted_beats_q <= 10'd0;
                            owner_q <= OWNER_WEIGHT;
                            state_q <= ST_WEIGHT;
                        end
                    end

                    ST_WEIGHT: begin
                        outstanding_words_q <=
                            outstanding_after_weight_transfers;
                        if (weight_request_accept)
                            issued_words_q <= issued_words_q + 11'd1;
                        if (weight_response_accept)
                            consumed_words_q <= consumed_words_q + 11'd1;
                        if (weight_accept) begin
                            if (accepted_beats_q ==
                                (group_beats_q - 10'd1)) begin
                                if (!weight_last_o ||
                                    (issued_words_q != group_words_q) ||
                                    // The last external word was accepted
                                    // before this registered beat appears.
                                    (consumed_words_q != group_words_q) ||
                                    weight_response_accept ||
                                    !outstanding_after_weight_empty) begin
                                    state_q <= ST_FAIL;
                                    fail_closed_q <= 1'b1;
                                end else begin
                                    accepted_beats_q <=
                                        accepted_beats_q + 10'd1;
                                    owner_q <= OWNER_NONE;
                                    state_q <= ST_DONE;
                                end
                            end else begin
                                accepted_beats_q <=
                                    accepted_beats_q + 10'd1;
                            end
                        end
                    end

                    ST_DONE: begin
                        if ((accepted_beats_q != group_beats_q) ||
                            (issued_words_q != group_words_q) ||
                            (consumed_words_q != group_words_q) ||
                            (outstanding_words_q != 12'd0) ||
                            !adapter_pair_boundary) begin
                            state_q <= ST_FAIL;
                            fail_closed_q <= 1'b1;
                        end else if (done_transfer) begin
                            metadata_count_q <= 7'd0;
                            state_q <= ST_IDLE;
                        end
                    end

                    ST_DRAIN: begin
                        if (owner_q == OWNER_WEIGHT) begin
                            outstanding_words_q <=
                                outstanding_after_weight_transfers;
                            if (weight_response_accept &&
                                outstanding_after_weight_empty) begin
                                owner_q <= OWNER_NONE;
                                state_q <= ST_IDLE;
                            end
                        end else if ((owner_q == OWNER_META) &&
                                     !meta_busy && meta_start_ready) begin
                            owner_q <= OWNER_NONE;
                            state_q <= ST_IDLE;
                        end else if (owner_q == OWNER_NONE) begin
                            state_q <= ST_IDLE;
                        end
                    end

                    default: begin
                        state_q <= ST_FAIL;
                        fail_closed_q <= 1'b1;
                    end
                endcase
            end
        end
    end

`ifdef FORMAL
    logic formal_past_valid;
    initial formal_past_valid = 1'b0;
    always_ff @(posedge clk) begin
        formal_past_valid <= 1'b1;
        if (reset_n) begin
            if (private_word_req_valid_o) begin
                assert(model_locked_i && !fail_closed_o && !clear_i);
                assert((private_word_req_index_o < ADDR_W'(211800)) ||
                       ((private_word_req_index_o >=
                         ADDR_W'(METADATA_BASE_WORD)) &&
                        (private_word_req_index_o <
                         ADDR_W'(METADATA_BASE_WORD + 2328))));
            end
            assert(!(group_valid_o && weight_valid_o));
            if (weight_valid_o)
                assert(owner_q == OWNER_WEIGHT && state_q == ST_WEIGHT);
            if (group_valid_o)
                assert(metadata_count_q == valid_lanes_q);
            if (state_q == ST_DRAIN)
                assert(!private_word_req_valid_o);
            if (formal_past_valid && $past(fail_closed_q))
                assert(fail_closed_q);
        end
    end
`endif
endmodule

module board1_private_outstanding_delta (
    input wire [11:0] count_i,
    input wire request_i,
    input wire response_i,
    output logic [11:0] next_o,
    output logic empty_o
);
    (* syn_keep = 1 *) wire [11:0] incremented = count_i + 12'd1;
    (* syn_keep = 1 *) wire [11:0] decremented = count_i - 12'd1;
    wire was_zero = count_i == 12'd0;
    wire was_one = count_i == 12'd1;
    wire was_maximum = count_i == 12'hfff;

    always_comb begin
        case ({request_i, response_i})
            2'b00, 2'b11: begin
                next_o = count_i;
                empty_o = was_zero;
            end
            2'b10: begin
                next_o = incremented;
                empty_o = was_maximum;
            end
            2'b01: begin
                next_o = decremented;
                empty_o = was_one;
            end
            default: begin
                next_o = 12'bx;
                empty_o = 1'bx;
            end
        endcase
        // Preserve the original four-state arithmetic semantics even for a
        // partially unknown old count. This applies in both ordinary and
        // -DSYNTHESIS simulation; it is not a physical unknown-bit detector.
        // synthesis translate_off
        if ($isunknown(count_i) || $isunknown(request_i) ||
            $isunknown(response_i)) begin
            next_o = count_i + {11'd0, request_i} - {11'd0, response_i};
            empty_o = next_o == 12'd0;
        end
        // synthesis translate_on
    end
endmodule

module board1_private_weight_beat_register (
    input wire clk,
    input wire reset_n,
    input wire in_valid_i,
    output wire in_ready_o,
    input wire [639:0] in_data_i,
    output wire out_valid_o,
    input wire out_ready_i,
    output wire [639:0] out_data_o
);
    logic valid_q;
    logic [639:0] data_q;
    wire push = in_valid_i && in_ready_o;
    wire pop = out_valid_o && out_ready_i;
    assign in_ready_o = !valid_q;
    assign out_valid_o = valid_q;
    assign out_data_o = data_q;
    always_ff @(posedge clk) begin
        if (reset_n && push) data_q <= in_data_i;
    end
    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) valid_q <= 1'b0;
        else if (push) valid_q <= 1'b1;
        else if (pop) valid_q <= 1'b0;
    end
endmodule

module board1_fixed_group_projection_scale_job #(
    parameter integer ADDR_W = 25,
    parameter integer METADATA_BASE_WORD = 211920
) (
    input  wire                     clk,
    input  wire                     reset_n,
    input  wire                     clear_i,
    input  wire                     model_locked_i,
    input  wire                     upstream_fail_closed_i,

    input  wire                     start_valid_i,
    output logic                    start_ready_o,
    input  wire [2:0]               fixed_layer_i,
    input  wire [3:0]               fixed_job_i,
    input  wire signed [7:0]        activation_exponent_i,

    input  wire                     activation_valid_i,
    output logic                    activation_ready_o,
    input  wire signed [15:0]       activation_i,
    input  wire                     activation_last_i,

    output wire                     private_word_req_valid_o,
    input  wire                     private_word_req_ready_i,
    output wire [ADDR_W-1:0]        private_word_req_index_o,
    input  wire                     private_word_rsp_valid_i,
    output wire                     private_word_rsp_ready_o,
    input  wire [255:0]             private_word_rsp_data_i,
    input  wire                     private_word_rsp_fault_i,

    output logic                    result_valid_o,
    input  wire                     result_ready_i,
    output logic [12:0]             result_row_index_o,
    output logic signed [49:0]      result_scaled_raw_o,
    output logic signed [7:0]       result_source_exponent_o,
    output logic                    result_last_o,

    output logic                    done_valid_o,
    input  wire                     done_ready_i,
    output logic                    busy_o,
    output logic                    fail_closed_o
);
    localparam integer MAX_COLUMNS = 682;

    typedef enum logic [2:0] {
        JOB_IDLE        = 3'd0,
        JOB_LOAD        = 3'd1,
        JOB_GROUP_START = 3'd2,
        JOB_GROUP_RUN   = 3'd3,
        JOB_DONE        = 3'd4,
        JOB_DRAIN       = 3'd5,
        JOB_FAIL        = 3'd7
    } job_state_t;

    job_state_t state_q;
    logic [2:0] layer_q;
    logic [3:0] job_q;
    logic signed [7:0] activation_exponent_q;
    logic [12:0] rows_q;
    logic [9:0] columns_q;
    logic [6:0] groups_q;
    logic [9:0] activation_count_q;
    logic [5:0] group_q;
    logic [9:0] column_q;
    logic [12:0] expected_row_q;
    logic stream_done_seen_q;
    logic engine_done_seen_q;
    logic fail_q;
    logic signed [15:0] activation_q;

    // Canonical synchronous 1R1W memory.  The write port is reachable only
    // while loading the fixed-length private activation stream.  The read
    // address is generated solely by the hardwired projection column counter.
    (* ram_style = "block" *) logic signed [15:0]
        activation_memory_q [0:MAX_COLUMNS-1];

    function automatic [12:0] rows_for_job(input logic [3:0] job);
        case (job)
            4'd0: rows_for_job = 13'd256;
            4'd1: rows_for_job = 13'd128;
            4'd2: rows_for_job = 13'd128;
            4'd3: rows_for_job = 13'd256;
            4'd4: rows_for_job = 13'd682;
            4'd5: rows_for_job = 13'd682;
            4'd6: rows_for_job = 13'd256;
            4'd7: rows_for_job = 13'd4019;
            default: rows_for_job = 13'd0;
        endcase
    endfunction

    function automatic [9:0] columns_for_job(input logic [3:0] job);
        case (job)
            4'd6: columns_for_job = 10'd682;
            4'd0, 4'd1, 4'd2, 4'd3, 4'd4, 4'd5, 4'd7:
                columns_for_job = 10'd256;
            default: columns_for_job = 10'd0;
        endcase
    endfunction

    function automatic [6:0] groups_for_job(input logic [3:0] job);
        case (job)
            4'd0, 4'd3, 4'd6: groups_for_job = 7'd4;
            4'd1, 4'd2:       groups_for_job = 7'd2;
            4'd4, 4'd5:       groups_for_job = 7'd11;
            4'd7:             groups_for_job = 7'd63;
            default:          groups_for_job = 7'd0;
        endcase
    endfunction

    logic [12:0] incoming_rows;
    logic [9:0] incoming_columns;
    logic [6:0] incoming_groups;
    logic incoming_descriptor_valid;
    always @* begin
        incoming_rows = rows_for_job(fixed_job_i);
        incoming_columns = columns_for_job(fixed_job_i);
        incoming_groups = groups_for_job(fixed_job_i);
        incoming_descriptor_valid = (incoming_rows != 13'd0) &&
            (incoming_columns != 10'd0) && (incoming_groups != 7'd0) &&
            (((fixed_job_i == 4'd7) && (fixed_layer_i == 3'd7)) ||
             ((fixed_job_i < 4'd7) && (fixed_layer_i < 3'd6)));
    end

    wire activation_expected_last =
        (activation_count_q == columns_q - 10'd1);
    wire start_transfer = start_valid_i && start_ready_o;
    wire activation_transfer = activation_valid_i && activation_ready_o;
    wire activation_protocol_error = activation_transfer &&
        ((activation_last_i != activation_expected_last) ||
         (activation_i == -16'sd32768));

    // Fixed-group DDR stream wires.
    logic stream_start_valid;
    wire stream_start_ready;
    wire stream_group_valid;
    wire stream_group_ready;
    wire [2:0] stream_group_layer;
    wire [3:0] stream_group_job;
    wire [5:0] stream_group_index;
    wire [6:0] stream_group_valid_lanes;
    wire [64*8-1:0] stream_group_row_exponent;
    wire [64*16-1:0] stream_group_row_multiplier;
    wire [639:0] stream_weight_data;
    wire stream_weight_valid;
    wire stream_weight_ready;
    wire stream_weight_last;
    wire stream_done_valid;
    logic stream_done_ready;
    wire stream_busy;
    wire stream_fail;

    // Shared engine adapter wires.
    wire engine_result_valid;
    logic engine_result_ready;
    wire [12:0] engine_result_row;
    wire signed [49:0] engine_result_scaled;
    wire signed [7:0] engine_result_exponent;
    wire engine_result_group_last;
    wire engine_done_valid;
    logic engine_done_ready;
    wire engine_busy;
    wire engine_fail;

    wire child_upstream_fail = upstream_fail_closed_i || fail_q;
    wire integrated_fail = fail_q || stream_fail || engine_fail ||
                           upstream_fail_closed_i;
    wire stream_start_transfer = stream_start_valid && stream_start_ready;
    wire weight_transfer = stream_weight_valid && stream_weight_ready;
    wire stream_done_transfer = stream_done_valid && stream_done_ready;
    wire engine_done_transfer = engine_done_valid && engine_done_ready;

    wire [12:0] group_row_base = {1'b0, group_q, 6'b000000};
    wire [13:0] full_group_end_plus_one =
        {1'b0, group_row_base} + 14'd64;
    wire [12:0] group_end_plus_one =
        (full_group_end_plus_one >= {1'b0, rows_q}) ?
        rows_q : full_group_end_plus_one[12:0];
    wire [12:0] group_last_row = group_end_plus_one - 13'd1;
    wire expected_engine_group_last =
        (engine_result_row == group_last_row);

    wire result_protocol_error = engine_result_valid &&
        ((state_q != JOB_GROUP_RUN) ||
         (engine_result_row != expected_row_q) ||
         (engine_result_row >= rows_q) ||
         (engine_result_group_last != expected_engine_group_last));
    wire weight_protocol_error = weight_transfer &&
        (stream_weight_last != (column_q == columns_q - 10'd1));
    wire group_retiring =
        (stream_done_seen_q || stream_done_transfer) &&
        (engine_done_seen_q || engine_done_transfer);
    wire group_retire_protocol_error = group_retiring &&
        ((expected_row_q != group_end_plus_one) ||
         (column_q != 10'd0));

    // One memory read is primed on the last activation write.  Each accepted
    // W10 beat then advances the synchronous read address.  Holding either
    // side of the weight ready/valid seam also holds activation_q, so the
    // scalar activation and all 64 weights cannot become misaligned.
    wire activation_store_write = activation_transfer &&
                                   !activation_protocol_error;
    wire activation_store_read =
        (activation_store_write && activation_expected_last) ||
        (weight_transfer && !weight_protocol_error &&
         ((column_q != columns_q - 10'd1) ||
          ({1'b0, group_q} != groups_q - 7'd1)));
    wire [9:0] activation_store_read_address =
        (weight_transfer && (column_q != columns_q - 10'd1)) ?
        (column_q + 10'd1) : 10'd0;

    always_ff @(posedge clk) begin
        if (activation_store_write)
            activation_memory_q[activation_count_q] <= activation_i;
        if (activation_store_read)
            activation_q <=
                activation_memory_q[activation_store_read_address];
    end

    always @* begin
        start_ready_o = (state_q == JOB_IDLE) && model_locked_i &&
                        !upstream_fail_closed_i && !integrated_fail &&
                        !clear_i;
        activation_ready_o = (state_q == JOB_LOAD) && model_locked_i &&
                             !upstream_fail_closed_i && !integrated_fail &&
                             !clear_i;
        busy_o = (state_q != JOB_IDLE) && (state_q != JOB_FAIL);
        fail_closed_o = integrated_fail;

        stream_start_valid = (state_q == JOB_GROUP_START) &&
                             !integrated_fail && !clear_i;
        stream_done_ready = (state_q == JOB_GROUP_RUN) &&
                            !stream_done_seen_q && !integrated_fail &&
                            !clear_i;
        engine_done_ready = (state_q == JOB_GROUP_RUN) &&
                            !engine_done_seen_q && !integrated_fail &&
                            !clear_i;

        engine_result_ready = result_ready_i &&
                              (state_q == JOB_GROUP_RUN) &&
                              !result_protocol_error &&
                              !integrated_fail && !clear_i;
        result_valid_o = engine_result_valid &&
                         (state_q == JOB_GROUP_RUN) &&
                         !result_protocol_error &&
                         !integrated_fail && !clear_i;
        // Private invalid metadata is not a public output. Consumers
        // must qualify it with VALID; all fault gates remain intact.
        result_row_index_o = engine_result_row;
        result_scaled_raw_o = result_valid_o ?
                              engine_result_scaled : 50'sd0;
        result_source_exponent_o = result_valid_o ?
                                   engine_result_exponent : 8'sd0;
        result_last_o = (engine_result_row == rows_q - 13'd1);
        done_valid_o = (state_q == JOB_DONE) && !integrated_fail && !clear_i;
    end

`ifndef SYNTHESIS
    logic simulation_x_fault;
    always @* begin
        simulation_x_fault = $isunknown(clear_i) ||
            $isunknown(model_locked_i) ||
            $isunknown(upstream_fail_closed_i) ||
            $isunknown(start_valid_i) ||
            $isunknown(activation_valid_i) ||
            $isunknown(private_word_req_ready_i) ||
            $isunknown(private_word_rsp_valid_i) ||
            $isunknown(private_word_rsp_fault_i);
        if (start_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(fixed_layer_i) || $isunknown(fixed_job_i) ||
                $isunknown(activation_exponent_i);
        if (activation_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(activation_i) || $isunknown(activation_last_i);
        if (private_word_rsp_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(private_word_rsp_data_i);
        if (result_valid_o === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(result_ready_i);
        if (done_valid_o === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(done_ready_i);
    end
`endif

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state_q <= JOB_IDLE;
            layer_q <= 3'd0;
            job_q <= 4'd0;
            activation_exponent_q <= 8'sd0;
            rows_q <= 13'd0;
            columns_q <= 10'd0;
            groups_q <= 7'd0;
            activation_count_q <= 10'd0;
            group_q <= 6'd0;
            column_q <= 10'd0;
            expected_row_q <= 13'd0;
            stream_done_seen_q <= 1'b0;
            engine_done_seen_q <= 1'b0;
            fail_q <= 1'b0;
        end else if (upstream_fail_closed_i || fail_q || stream_fail ||
                     engine_fail) begin
            state_q <= JOB_FAIL;
            fail_q <= 1'b1;
        end else if (clear_i === 1'b1) begin
            state_q <= JOB_DRAIN;
            activation_count_q <= 10'd0;
            group_q <= 6'd0;
            column_q <= 10'd0;
            expected_row_q <= 13'd0;
            stream_done_seen_q <= 1'b0;
            engine_done_seen_q <= 1'b0;
`ifndef SYNTHESIS
        end else if (simulation_x_fault) begin
            state_q <= JOB_FAIL;
            fail_q <= 1'b1;
`endif
        end else if (((state_q != JOB_IDLE) && start_valid_i) ||
                     ((state_q != JOB_LOAD) && activation_valid_i) ||
                     (((state_q != JOB_IDLE) &&
                       (state_q != JOB_DRAIN) &&
                       (state_q != JOB_FAIL)) && !model_locked_i) ||
                     activation_protocol_error || weight_protocol_error ||
                     result_protocol_error ||
                     group_retire_protocol_error ||
                     ((state_q != JOB_GROUP_RUN) &&
                      (stream_done_valid || engine_done_valid))) begin
            state_q <= JOB_FAIL;
            fail_q <= 1'b1;
        end else begin
            case (state_q)
                JOB_IDLE: begin
                    if (start_transfer) begin
                        if (!incoming_descriptor_valid) begin
                            state_q <= JOB_FAIL;
                            fail_q <= 1'b1;
                        end else begin
                            layer_q <= fixed_layer_i;
                            job_q <= fixed_job_i;
                            activation_exponent_q <= activation_exponent_i;
                            rows_q <= incoming_rows;
                            columns_q <= incoming_columns;
                            groups_q <= incoming_groups;
                            activation_count_q <= 10'd0;
                            group_q <= 6'd0;
                            column_q <= 10'd0;
                            expected_row_q <= 13'd0;
                            stream_done_seen_q <= 1'b0;
                            engine_done_seen_q <= 1'b0;
                            state_q <= JOB_LOAD;
                        end
                    end
                end

                JOB_LOAD: begin
                    if (activation_transfer) begin
                        if (activation_expected_last) begin
                            activation_count_q <= 10'd0;
                            group_q <= 6'd0;
                            column_q <= 10'd0;
                            expected_row_q <= 13'd0;
                            stream_done_seen_q <= 1'b0;
                            engine_done_seen_q <= 1'b0;
                            state_q <= JOB_GROUP_START;
                        end else begin
                            activation_count_q <= activation_count_q + 10'd1;
                        end
                    end
                end

                JOB_GROUP_START: begin
                    if (stream_start_transfer) begin
                        column_q <= 10'd0;
                        stream_done_seen_q <= 1'b0;
                        engine_done_seen_q <= 1'b0;
                        state_q <= JOB_GROUP_RUN;
                    end
                end

                JOB_GROUP_RUN: begin
                    if (weight_transfer) begin
                        if (column_q == columns_q - 10'd1)
                            column_q <= 10'd0;
                        else
                            column_q <= column_q + 10'd1;
                    end
                    if (result_valid_o && result_ready_i)
                        expected_row_q <= expected_row_q + 13'd1;
                    if (stream_done_transfer)
                        stream_done_seen_q <= 1'b1;
                    if (engine_done_transfer)
                        engine_done_seen_q <= 1'b1;
                    if (group_retiring) begin
                        stream_done_seen_q <= 1'b0;
                        engine_done_seen_q <= 1'b0;
                        if ({1'b0, group_q} == groups_q - 7'd1) begin
                            state_q <= JOB_DONE;
                        end else begin
                            group_q <= group_q + 6'd1;
                            state_q <= JOB_GROUP_START;
                        end
                    end
                end

                JOB_DONE: begin
                    if (done_valid_o && done_ready_i) begin
                        activation_count_q <= 10'd0;
                        group_q <= 6'd0;
                        column_q <= 10'd0;
                        expected_row_q <= 13'd0;
                        state_q <= JOB_IDLE;
                    end
                end

                JOB_DRAIN: begin
                    if (!stream_busy && !engine_busy &&
                        !stream_fail && !engine_fail)
                        state_q <= JOB_IDLE;
                end

                default: begin
                    state_q <= JOB_FAIL;
                    fail_q <= 1'b1;
                end
            endcase
        end
    end

    board1_fixed_group_ddr_stream #(
        .ADDR_W(ADDR_W), .METADATA_BASE_WORD(METADATA_BASE_WORD)
    ) u_group_stream (
        .clk(clk), .reset_n(reset_n), .clear_i(clear_i),
        .model_locked_i(model_locked_i),
        .upstream_fail_closed_i(child_upstream_fail),
        .start_valid_i(stream_start_valid),
        .start_ready_o(stream_start_ready),
        .fixed_layer_i(layer_q), .fixed_job_i(job_q),
        .fixed_group_i(group_q),
        .private_word_req_valid_o(private_word_req_valid_o),
        .private_word_req_ready_i(private_word_req_ready_i),
        .private_word_req_index_o(private_word_req_index_o),
        .private_word_rsp_valid_i(private_word_rsp_valid_i),
        .private_word_rsp_ready_o(private_word_rsp_ready_o),
        .private_word_rsp_data_i(private_word_rsp_data_i),
        .private_word_rsp_fault_i(private_word_rsp_fault_i),
        .group_valid_o(stream_group_valid),
        .group_ready_i(stream_group_ready),
        .group_layer_o(stream_group_layer),
        .group_job_o(stream_group_job),
        .group_index_o(stream_group_index),
        .group_valid_lanes_o(stream_group_valid_lanes),
        .group_row_exponent_o(stream_group_row_exponent),
        .group_row_multiplier_o(stream_group_row_multiplier),
        .weight_data_o(stream_weight_data),
        .weight_valid_o(stream_weight_valid),
        .weight_ready_i(stream_weight_ready),
        .weight_last_o(stream_weight_last),
        .done_valid_o(stream_done_valid),
        .done_ready_i(stream_done_ready),
        .busy_o(stream_busy), .fail_closed_o(stream_fail)
    );

    board1_shared_projection_scale_group_adapter u_shared_engine (
        .clk(clk), .reset_n(reset_n), .clear_i(clear_i),
        .model_locked_i(model_locked_i),
        .upstream_fail_closed_i(child_upstream_fail),
        .group_valid_i(stream_group_valid),
        .group_ready_o(stream_group_ready),
        .group_layer_i(stream_group_layer),
        .group_job_i(stream_group_job),
        .group_index_i(stream_group_index),
        .group_valid_lanes_i(stream_group_valid_lanes),
        .group_row_exponent_i(stream_group_row_exponent),
        .group_row_multiplier_i(stream_group_row_multiplier),
        .activation_exponent_i(activation_exponent_q),
        .weight_valid_i(stream_weight_valid),
        .weight_ready_o(stream_weight_ready),
        .activation_i(activation_q),
        .weight_data_i(stream_weight_data),
        .weight_last_i(stream_weight_last),
        .result_valid_o(engine_result_valid),
        .result_ready_i(engine_result_ready),
        .result_row_index_o(engine_result_row),
        .result_scaled_raw_o(engine_result_scaled),
        .result_source_exponent_o(engine_result_exponent),
        .result_last_o(engine_result_group_last),
        .done_valid_o(engine_done_valid),
        .done_ready_i(engine_done_ready),
        .busy_o(engine_busy), .fail_closed_o(engine_fail)
    );

`ifdef FORMAL
    logic formal_past_valid;
    initial formal_past_valid = 1'b0;
    always_ff @(posedge clk) begin
        formal_past_valid <= 1'b1;
        if (reset_n) begin
            assert(group_q < 6'd63);
            assert(column_q < 10'd682);
            assert(expected_row_q <= rows_q);
            if (stream_start_valid)
                assert(state_q == JOB_GROUP_START && group_q < groups_q);
            if (weight_transfer)
                assert(state_q == JOB_GROUP_RUN);
            if (result_valid_o)
                assert(result_row_index_o == expected_row_q);
            if (done_valid_o)
                assert(expected_row_q == rows_q);
            if (state_q == JOB_FAIL) begin
                assert(fail_closed_o);
                assert(!result_valid_o && !done_valid_o);
            end
            if (formal_past_valid && $past(reset_n)) begin
                if ($past(result_valid_o) && !$past(result_ready_i) &&
                    !$past(clear_i)) begin
                    assert(result_valid_o);
                    assert(result_row_index_o ==
                           $past(result_row_index_o));
                    assert(result_scaled_raw_o ==
                           $past(result_scaled_raw_o));
                    assert(result_source_exponent_o ==
                           $past(result_source_exponent_o));
                end
                if ($past(fail_q))
                    assert(fail_q);
            end
        end
    end
`endif
endmodule

module board1_fixed_projection_metadata_reader #(
    parameter integer ADDR_W = 25,
    parameter integer METADATA_BASE_WORD = 211920
) (
    input  wire                   clk,
    input  wire                   reset_n,
    input  wire                   clear_i,
    input  wire                   model_locked_i,
    input  wire                   upstream_fail_closed_i,

    input  wire                   start_valid_i,
    output logic                  start_ready_o,
    input  wire [2:0]             fixed_layer_i,
    input  wire [3:0]             fixed_job_i,
    input  wire [5:0]             fixed_group_i,

    output logic                  private_word_req_valid_o,
    input  wire                   private_word_req_ready_i,
    output logic [ADDR_W-1:0]     private_word_req_index_o,
    input  wire                   private_word_rsp_valid_i,
    output logic                  private_word_rsp_ready_o,
    input  wire [255:0]           private_word_rsp_data_i,
    input  wire                   private_word_rsp_fault_i,

    output logic                  metadata_valid_o,
    input  wire                   metadata_ready_i,
    output logic signed [7:0]     metadata_exponent_o,
    output logic [15:0]           metadata_multiplier_o,
    output logic [12:0]           metadata_row_index_o,
    output logic                  metadata_last_o,

    output logic                  done_valid_o,
    input  wire                   done_ready_i,
    output logic                  busy_o,
    output logic                  fail_closed_o
);
    localparam logic [2:0] ST_IDLE    = 3'd0;
    localparam logic [2:0] ST_REQUEST = 3'd1;
    localparam logic [2:0] ST_WAIT    = 3'd2;
    localparam logic [2:0] ST_EMIT    = 3'd3;
    localparam logic [2:0] ST_DONE    = 3'd4;
    localparam logic [2:0] ST_DRAIN   = 3'd5;
    localparam logic [2:0] ST_FAIL    = 3'd7;

    logic [2:0] state_q;
    logic [ADDR_W-1:0] group_base_word_q;
    logic [2:0] word_in_group_q;
    logic [2:0] record_in_word_q;
    logic [6:0] valid_lanes_q;
    logic [5:0] group_q;
    logic [3:0] job_q;
    logic [2:0] layer_q;
    logic [255:0] response_word_q;
    logic request_outstanding_q;
    logic fail_closed_q;

    logic descriptor_valid;
    logic [6:0] descriptor_groups;
    logic [6:0] descriptor_valid_lanes;
    logic [ADDR_W-1:0] descriptor_base_word;
    logic [10:0] job_word_offset;

    logic [31:0] current_record;
    logic [5:0] current_lane;
    logic current_lane_is_real;
    logic current_real_record_is_legal;
    logic current_ragged_record_is_legal;
    logic response_transfer;
    logic request_transfer;
    logic metadata_transfer;
    logic done_transfer;

`ifndef SYNTHESIS
    logic simulation_x_fault;
`endif

    function automatic [6:0] groups_for_job(input logic [3:0] job);
        case (job)
            4'd0, 4'd3, 4'd6: groups_for_job = 7'd4;
            4'd1, 4'd2:       groups_for_job = 7'd2;
            4'd4, 4'd5:       groups_for_job = 7'd11;
            4'd7:             groups_for_job = 7'd63;
            default:          groups_for_job = 7'd0;
        endcase
    endfunction

    function automatic [6:0] last_group_lanes(input logic [3:0] job);
        case (job)
            4'd4, 4'd5: last_group_lanes = 7'd42;
            4'd7:       last_group_lanes = 7'd51;
            4'd0, 4'd1, 4'd2, 4'd3, 4'd6:
                         last_group_lanes = 7'd64;
            default:    last_group_lanes = 7'd0;
        endcase
    endfunction

    function automatic [10:0] word_offset_for_job(input logic [3:0] job);
        case (job)
            4'd0: word_offset_for_job = 11'd0;
            4'd1: word_offset_for_job = 11'd32;
            4'd2: word_offset_for_job = 11'd48;
            4'd3: word_offset_for_job = 11'd64;
            4'd4: word_offset_for_job = 11'd96;
            4'd5: word_offset_for_job = 11'd184;
            4'd6: word_offset_for_job = 11'd272;
            4'd7: word_offset_for_job = 11'd1824;
            default: word_offset_for_job = 11'd0;
        endcase
    endfunction

    always @* begin
        descriptor_groups = groups_for_job(fixed_job_i);
        job_word_offset = word_offset_for_job(fixed_job_i);
        descriptor_valid = (descriptor_groups != 7'd0) &&
            ({1'b0, fixed_group_i} < descriptor_groups) &&
            (((fixed_job_i == 4'd7) && (fixed_layer_i == 3'd7)) ||
             ((fixed_job_i < 4'd7) && (fixed_layer_i < 3'd6)));
        descriptor_valid_lanes =
            ({1'b0, fixed_group_i} == (descriptor_groups - 7'd1)) ?
            last_group_lanes(fixed_job_i) : 7'd64;
        if (fixed_job_i == 4'd7) begin
            descriptor_base_word = ADDR_W'(METADATA_BASE_WORD) +
                                   ADDR_W'(11'd1824) +
                                   ADDR_W'({fixed_group_i, 3'b000});
        end else begin
            descriptor_base_word = ADDR_W'(METADATA_BASE_WORD) +
                                   ADDR_W'(fixed_layer_i * 12'd304) +
                                   ADDR_W'(job_word_offset) +
                                   ADDR_W'({fixed_group_i, 3'b000});
        end
    end

    always @* begin
        current_lane = {word_in_group_q, record_in_word_q};
        current_record =
            response_word_q[record_in_word_q * 32 +: 32];
        current_lane_is_real = ({1'b0, current_lane} < valid_lanes_q);
        current_real_record_is_legal =
            (current_record[31:24] == 8'd0) &&
            (current_record[23:8] != 16'd0) &&
            !current_record[23];
        current_ragged_record_is_legal = (current_record == 32'd0);

        start_ready_o = (state_q == ST_IDLE) && model_locked_i &&
                        !upstream_fail_closed_i && !fail_closed_q &&
                        !clear_i;
        private_word_req_valid_o = (state_q == ST_REQUEST) &&
                                   model_locked_i &&
                                   !upstream_fail_closed_i &&
                                   !fail_closed_q && !clear_i;
        private_word_req_index_o = group_base_word_q +
                                   ADDR_W'(word_in_group_q);
        private_word_rsp_ready_o = request_outstanding_q &&
            ((state_q == ST_WAIT) || (state_q == ST_DRAIN) ||
             (state_q == ST_FAIL));

        metadata_valid_o = (state_q == ST_EMIT) &&
                           current_lane_is_real &&
                           current_real_record_is_legal &&
                           !upstream_fail_closed_i && !fail_closed_q &&
                           model_locked_i && !clear_i;
        metadata_exponent_o = metadata_valid_o ?
                              $signed(current_record[7:0]) : 8'sd0;
        metadata_multiplier_o = metadata_valid_o ?
                                current_record[23:8] : 16'd0;
        metadata_row_index_o = metadata_valid_o ?
            ({7'd0, group_q} << 6) + {7'd0, current_lane} : 13'd0;
        metadata_last_o = metadata_valid_o &&
                          ({1'b0, current_lane} ==
                           (valid_lanes_q - 7'd1));

        done_valid_o = (state_q == ST_DONE) && !fail_closed_q &&
                       !upstream_fail_closed_i && model_locked_i &&
                       !clear_i;
        busy_o = (state_q != ST_IDLE) && (state_q != ST_FAIL);
        fail_closed_o = fail_closed_q || upstream_fail_closed_i;

        request_transfer = private_word_req_valid_o &&
                           private_word_req_ready_i;
        response_transfer = private_word_rsp_valid_i &&
                            private_word_rsp_ready_o;
        metadata_transfer = metadata_valid_o && metadata_ready_i;
        done_transfer = done_valid_o && done_ready_i;
    end

`ifndef SYNTHESIS
    always @* begin
        simulation_x_fault = $isunknown(clear_i) ||
            $isunknown(model_locked_i) ||
            $isunknown(upstream_fail_closed_i) ||
            $isunknown(start_valid_i) ||
            $isunknown(private_word_req_ready_i) ||
            $isunknown(private_word_rsp_valid_i) ||
            $isunknown(private_word_rsp_fault_i);
        if (start_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                $isunknown(fixed_layer_i) || $isunknown(fixed_job_i) ||
                $isunknown(fixed_group_i);
        if (private_word_rsp_valid_i === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(private_word_rsp_data_i);
        if (metadata_valid_o === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(metadata_ready_i);
        if (done_valid_o === 1'b1)
            simulation_x_fault = simulation_x_fault ||
                                 $isunknown(done_ready_i);
    end
`endif

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state_q <= ST_IDLE;
            group_base_word_q <= '0;
            word_in_group_q <= 3'd0;
            record_in_word_q <= 3'd0;
            valid_lanes_q <= 7'd0;
            group_q <= 6'd0;
            job_q <= 4'd0;
            layer_q <= 3'd0;
            response_word_q <= 256'd0;
            request_outstanding_q <= 1'b0;
            fail_closed_q <= 1'b0;
        end else if (upstream_fail_closed_i ||
                     ((state_q != ST_IDLE) &&
                      (state_q != ST_FAIL) && !model_locked_i) ||
                     (private_word_rsp_valid_i &&
                      !request_outstanding_q) ||
                     (private_word_rsp_fault_i && response_transfer) ||
                     (start_valid_i && !start_ready_o && !clear_i)) begin
            state_q <= ST_FAIL;
            if (response_transfer)
                request_outstanding_q <= 1'b0;
            fail_closed_q <= 1'b1;
`ifndef SYNTHESIS
        end else if (simulation_x_fault) begin
            state_q <= ST_FAIL;
            fail_closed_q <= 1'b1;
`endif
        end else if (clear_i) begin
            if (request_outstanding_q && !response_transfer)
                state_q <= ST_DRAIN;
            else
                state_q <= ST_IDLE;
            if (response_transfer)
                request_outstanding_q <= 1'b0;
            word_in_group_q <= 3'd0;
            record_in_word_q <= 3'd0;
            response_word_q <= 256'd0;
        end else begin
            case (state_q)
                ST_IDLE: begin
                    if (start_valid_i && start_ready_o) begin
                        if (!descriptor_valid ||
                            (descriptor_valid_lanes == 7'd0)) begin
                            state_q <= ST_FAIL;
                            fail_closed_q <= 1'b1;
                        end else begin
                            group_base_word_q <= descriptor_base_word;
                            valid_lanes_q <= descriptor_valid_lanes;
                            group_q <= fixed_group_i;
                            job_q <= fixed_job_i;
                            layer_q <= fixed_layer_i;
                            word_in_group_q <= 3'd0;
                            record_in_word_q <= 3'd0;
                            state_q <= ST_REQUEST;
                        end
                    end
                end

                ST_REQUEST: begin
                    if (request_transfer) begin
                        request_outstanding_q <= 1'b1;
                        state_q <= ST_WAIT;
                    end
                end

                ST_WAIT: begin
                    if (response_transfer) begin
                        request_outstanding_q <= 1'b0;
                        response_word_q <= private_word_rsp_data_i;
                        record_in_word_q <= 3'd0;
                        state_q <= ST_EMIT;
                    end
                end

                ST_EMIT: begin
                    if (current_lane_is_real) begin
                        if (!current_real_record_is_legal) begin
                            state_q <= ST_FAIL;
                            fail_closed_q <= 1'b1;
                        end else if (metadata_transfer) begin
                            if (record_in_word_q == 3'd7) begin
                                record_in_word_q <= 3'd0;
                                if (word_in_group_q == 3'd7) begin
                                    state_q <= ST_DONE;
                                end else begin
                                    word_in_group_q <=
                                        word_in_group_q + 3'd1;
                                    state_q <= ST_REQUEST;
                                end
                            end else begin
                                record_in_word_q <=
                                    record_in_word_q + 3'd1;
                            end
                        end
                    end else begin
                        if (!current_ragged_record_is_legal) begin
                            state_q <= ST_FAIL;
                            fail_closed_q <= 1'b1;
                        end else if (record_in_word_q == 3'd7) begin
                            record_in_word_q <= 3'd0;
                            if (word_in_group_q == 3'd7) begin
                                state_q <= ST_DONE;
                            end else begin
                                word_in_group_q <= word_in_group_q + 3'd1;
                                state_q <= ST_REQUEST;
                            end
                        end else begin
                            record_in_word_q <= record_in_word_q + 3'd1;
                        end
                    end
                end

                ST_DONE: begin
                    if (done_transfer)
                        state_q <= ST_IDLE;
                end

                ST_DRAIN: begin
                    if (response_transfer) begin
                        request_outstanding_q <= 1'b0;
                        state_q <= ST_IDLE;
                    end
                end

                default: begin
                    if (response_transfer)
                        request_outstanding_q <= 1'b0;
                    state_q <= ST_FAIL;
                    fail_closed_q <= 1'b1;
                end
            endcase
        end
    end

    // These registers are retained as explicit fixed-controller witnesses.
    // They are intentionally not outputs and cannot select any new address.
    wire _unused_descriptor_witness = ^{job_q, layer_q};

`ifdef FORMAL
    logic formal_past_valid_q;
    always_ff @(posedge clk) begin
        formal_past_valid_q <= 1'b1;
        if (formal_past_valid_q && reset_n) begin
            if (private_word_req_valid_o) begin
                assert(state_q == ST_REQUEST);
                assert(model_locked_i && !fail_closed_o && !clear_i);
                assert(private_word_req_index_o >=
                       ADDR_W'(METADATA_BASE_WORD));
                assert(private_word_req_index_o <
                       ADDR_W'(METADATA_BASE_WORD + 2328));
            end
            if (metadata_valid_o) begin
                assert(state_q == ST_EMIT);
                assert(current_lane_is_real);
                assert(current_real_record_is_legal);
            end
            if (state_q == ST_DRAIN)
                assert(!private_word_req_valid_o);
            if (state_q == ST_DONE)
                assert(!request_outstanding_q);
            if ($past(fail_closed_q))
                assert(fail_closed_q);
            if ($past(state_q == ST_DRAIN && !response_transfer &&
                      !clear_i))
                assert(state_q == ST_DRAIN || fail_closed_q);
        end
    end
`endif
endmodule


module tb;
 reg clk=0;always #5 clk=~clk;
 reg reset_n=0;integer cycle=0,admitted=0,retired=0;
 wire layer=(admitted%3!=1),offer=admitted<64 && cycle%4!=1;
 wire sv,lv,sr,lr,req,ready,fail;wire[255:0]sd,ld;
 wire response=retired<admitted && cycle>20 && cycle%3!=1;
 wire [255:0]payload=256'(retired+12345);
 board1_fixed_private_ddr_arbiter #(.ADDR_W(19),.MODEL_WORDS(227062),.OWNER_DEPTH(16)) dut(
 .clk(clk),.reset_n(reset_n),.model_locked_i(1'b1),.upstream_fail_closed_i(1'b0),.endpoint_fail_closed_i(1'b0),
 .shell_req_valid_i(offer&&!layer),.shell_req_ready_o(sr),.shell_req_index_i(19'(admitted)),
 .layer_req_valid_i(offer&&layer),.layer_req_ready_o(lr),.layer_req_index_i(19'(admitted)),
 .shell_rsp_valid_o(sv),.shell_rsp_ready_i(1'b1),.shell_rsp_data_o(sd),.shell_rsp_fault_o(),
 .layer_rsp_valid_o(lv),.layer_rsp_ready_i(1'b1),.layer_rsp_data_o(ld),.layer_rsp_fault_o(),
 .private_req_valid_o(req),.private_req_ready_i(cycle%5!=0),.private_req_index_o(),
 .private_rsp_valid_i(response),.private_rsp_ready_o(ready),.private_rsp_data_i(payload),.private_rsp_fault_i(1'b0),.busy_o(),.fail_closed_o(fail));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(reset_n)begin
   if(req && cycle%5!=0)admitted<=admitted+1;
   if(response && ready)begin
    if((lv!==(retired%3!=1)) || (sv!==(retired%3==1)) ||
       (lv&&ld!==payload) || (sv&&sd!==payload))$fatal(1,"cross-owner response");
    retired<=retired+1;
   end
   if(fail)$fatal(1,"unexpected owner fault");
   if(retired==64)begin $display("PASS: 64 mixed-owner requests, wraparound, stalls and simultaneous admission/retirement");$finish;end
  end
  if(cycle>2000)$fatal(1,"owner timeout");
 end
 initial begin repeat(3)@(negedge clk);reset_n=1;end
endmodule

"""Freeze actual downstream instances/parameters/resets for universal lemmas.

Port identity is a source-specialization rule, not a value theorem for peers.
The semantic owner-window recurrence and composed Q root remain open.
"""
import json
import re
import sys
from source_policy import HERE, PUBLIC, native_source, sha, write_json
sys.path.insert(0,str(HERE.parent))
from prepare_port_composition import ports
from build_initial import PREFIX, ARBITER, FIFO

CORE=PREFIX+'context2048_token_machine2/rtl/board1_context2048_token_machine_core.sv'
LAYER=PREFIX+'context2048_token_machine0/rtl/board1_context2048_semantic_layer.sv'
DATA=PREFIX+'context2048_token_machine0/rtl/board1_context2048_semantic_datapath.sv'


def main():
    _,sources=native_source({p:[]for p in ['shared_token_probe.sv',CORE,LAYER,DATA,ARBITER,FIFO]})
    core=(PUBLIC/CORE).read_text();shared=(PUBLIC/'shared_token_probe.sv').read_text()
    aq=ports(shared,'u_auth');machine=ports(shared,'u_machine');arb=ports(core,'u_private_ddr_arbiter')
    bindings=[]
    for a,b in [('request_valid_i','private_runtime_req_valid_o'),('request_ready_o','private_runtime_req_ready_i'),
                ('request_word_i','private_runtime_req_word_index_o'),('response_valid_o','private_runtime_rsp_valid_i'),
                ('response_ready_i','private_runtime_rsp_ready_o'),('response_data_o','private_runtime_rsp_data_i')]:
        if aq[a]!=machine[b]:raise ValueError('Actual cache/machine connection differs')
        bindings.append(dict(cache=a,machine=b,wire=aq[a]))
    for c in ['clk','reset_n','model_locked_i']:
        if aq[c]!=machine[c]:raise ValueError('Cache and machine clock/reset/lock differ')
    if 'assign model_rsp_fault=auth_fault;'not in shared or aq['fault_o']!='auth_fault' or machine['private_runtime_rsp_fault_i']!='model_rsp_fault':
        raise ValueError('Actual cache fault forwarding changed')
    if arb['reset_n']!='reset_n' or arb['clk']!='clk' or '.OWNER_DEPTH(16)'not in core or '.MODEL_WORDS(227062)'not in shared or '.ADDR_W(19)'not in shared:
        raise ValueError('Actual owner specialization changed')
    queues={}
    for client in ['shell','layer']:
        for direction in ['request','response']:
            name='u_'+client+'_model_'+direction+'_queue';p=ports(core,name)
            if p['reset_n']!='child_reset_n'or p['abort_i']!="1'b0":raise ValueError('Local queue reset/abort differs')
            if direction=='request':
                want=dict(in_valid_i=client+'_ddr_req_valid',in_ready_o=client+'_ddr_req_ready',in_addr_i=client+'_ddr_req_index',
                    out_valid_o=client+'_queued_req_valid',out_ready_i=client+'_queued_req_ready&&!clear_i',out_addr_o=client+'_queued_req_index')
                if arb[client+'_req_valid_i']!=client+'_queued_req_valid&&!clear_i'or arb[client+'_req_index_i']!=client+'_queued_req_index':
                    raise ValueError('Queued request owner binding differs')
            else:
                want=dict(in_valid_i=client+'_queued_rsp_valid',in_ready_o=client+'_queued_rsp_ready',in_write_i=client+'_queued_rsp_fault',in_data_i=client+'_queued_rsp_data',
                    out_valid_o=client+'_ddr_rsp_valid',out_ready_i=client+'_ddr_rsp_ready',out_write_o=client+'_ddr_rsp_fault',out_data_o=client+'_ddr_rsp_data')
                for field in ['valid','ready','data','fault']:
                    port=client+'_rsp_'+field+('_i'if field=='ready'else'_o')
                    if arb[port]!=client+'_queued_rsp_'+field:raise ValueError('Queued response owner binding differs')
            if any(p[k]!=v for k,v in want.items()):raise ValueError('Actual queue port changed')
            queues[name]=dict(parameters=dict(ADDR_W=19 if direction=='request'else 1),ports=p,
                lemma='fifo'+('19'if direction=='request'else'1'),CLEAR_aborts=False)
    child='wire child_reset_n = reset_n && machine_active;'
    if child not in core:raise ValueError('Actual child reset changed')
    data=(PUBLIC/DATA).read_text();layer=(PUBLIC/LAYER).read_text();dp=ports(layer,'u_datapath');proj=ports(data,'u_projection')
    for suffix in ['req_valid_o','req_ready_i','req_index_o','rsp_valid_i','rsp_ready_o','rsp_data_i','rsp_fault_i']:
        p='private_word_'+suffix
        if dp[p]!=p:raise ValueError('Semantic layer forwarding differs')
    start=data.index('    // Private bounded projection-read window.')
    end=data.index('    // Stage controller and private vector writes.',start)
    block=data[start:end]
    (HERE/'semantic-owner-window.txt').write_text(block)
    write_json(HERE/'ACTUAL-BINDINGS.json',dict(sources=sources,cache_machine_wires=bindings,
        queue_instances=queues,arbiter_ports=arb,projection_ports=proj,semantic_layer_ports=dp,
        common_cache_machine_clock=aq['clk'],common_cache_machine_reset=aq['reset_n'],actual_child_reset=child,
        specialization_rule='Universal proved module behavior under identical actual parameters, clock/reset and source port substitution',
        semantic_owner_window_sha256=sha(block.encode()),semantic_owner_window_proved=False,
        cache_value_import_logically_closed=False,whole_Q_consumption_proved=False,whole_machine_theorem=False))
    print('Pinned cache-to-owner/queue and semantic projection instance connections. Semantic window and Q-value composition remain open.')


if __name__=='__main__':main()

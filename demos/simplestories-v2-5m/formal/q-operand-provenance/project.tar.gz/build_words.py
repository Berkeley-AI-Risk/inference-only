"""Fixed-model 256-to-640 packing and actual Q tile-capture candidate.

Reference words come from the closed reader theorem. This retains the actual
packer, beat register and tile wires in the restored native parent model.
"""
import json
from source_policy import HERE,sha,write_json
from build_initial import conj,bv
from build_ordered import TOP,S,A,J,n
from build_reader import G,P

B=G+'u_weight_beat_register.';E=J+'u_shared_engine.u_engine.'


def definitions():
    model='(Array (_ BitVec 18) (_ BitVec 256))'
    at=lambda off:f'(select model ((_ extract 17 0) (bvadd base {off})))'
    offset=f'(bvmul ((_ zero_extend 9) (bvlshr ordinal {bv(1,10)})) {bv(5,19)})'
    words=[at(f'(bvadd {offset} {bv(i,19)})')for i in range(5)]
    even=f'(concat ((_ extract 127 0) {words[2]}) (concat {words[1]} {words[0]}))'
    odd=f'(concat {words[4]} (concat {words[3]} ((_ extract 255 128) {words[2]})))'
    defs=f'(define-fun model-Q-beat ((model {model}) (base (_ BitVec 19)) (ordinal (_ BitVec 10))) (_ BitVec 640) (ite (= ((_ extract 0 0) ordinal) #b0) {even} {odd}))\n'
    fields=['(w-position (_ BitVec 3))','(w-block (_ BitVec 8))','(w-produced (_ BitVec 10))','(w-consumed (_ BitVec 10))','(w-buffer-ordinal (_ BitVec 10))']
    defs+='(declare-datatypes () ((WordsHistory (words-history '+' '.join(fields)+'))))\n'
    defs+='(define-fun words-zero () WordsHistory (words-history '+ ' '.join([bv(0,3),bv(0,8),bv(0,10),bv(0,10),bv(0,10)])+'))\n'
    wi=n(P+'input_transfer');push=n(B+'push');pop=n(G+'weight_accept');pos='(w-position w)';block='(w-block w)';produced='(w-produced w)';consumed='(w-consumed w)'
    nextpos=f'(ite {wi} (ite (= {pos} #b100) #b000 (bvadd {pos} #b001)) {pos})'
    nextblock=f'(bvadd {block} (ite (and {wi} (= {pos} #b100)) {bv(1,8)} {bv(0,8)}))'
    increment=lambda x,e:f'(bvadd {x} (ite {e} {bv(1,10)} {bv(0,10)}))'
    defs+=f'(define-fun words-next ((a {S}) (w WordsHistory)) WordsHistory (ite (not {n(P+"reset_n")}) words-zero (words-history {nextpos} {nextblock} {increment(produced,push)} {increment(consumed,pop)} (ite {push} {produced} (w-buffer-ordinal w)))))\n'
    state=lambda prefix,values:'(or '+' '.join(f'(= {n(prefix+"state_q")} {bv(i,3)})'for i in values)+')'
    root=conj([n('reset_n'),'(not '+n(A+'fail_q')+')',n('u_native.child_reset_n')])
    jobhealthy='(not '+n(J+'integrated_fail')+')'
    normal=conj([root,jobhealthy])
    q=f'(= {n(G+"job_q")} {bv(0,4)})';local=conj([n(P+'reset_n'),q])
    base=n(G+'weight_base_word_q');wordbase=f'(bvmul ((_ zero_extend 11) {block}) {bv(5,19)})'
    mword=lambda i:f'(select model ((_ extract 17 0) (bvadd {base} (bvadd {wordbase} {bv(i,19)}))))'
    phase=lambda values:'(or '+' '.join(f'(= {pos} {bv(v,3)})'for v in values)+')'
    wordcount=f'(bvadd (bvmul ((_ zero_extend 5) {block}) {bv(5,13)}) ((_ zero_extend 10) {pos}))'
    beats=f'(bvadd (bvshl ((_ zero_extend 3) {block}) {bv(1,11)}) (ite {phase([3,4])} {bv(1,11)} {bv(0,11)}))'
    half=f'((_ zero_extend 9) (bvlshr {produced} {bv(1,10)}))'
    indexlaw=conj([f'(=> (= ((_ zero_extend 1) {produced}) {beats}) '+conj([f'(= {half} ((_ zero_extend 11) {block}))',
        f'(= (= ((_ extract 0 0) {produced}) #b1) {phase([3,4])})'])+')',
        f'(=> (= ((_ zero_extend 2) {n(G+"consumed_words_q")}) {wordcount}) (= ((_ zero_extend 8) {n(G+"consumed_words_q")}) (bvadd {wordbase} ((_ zero_extend 16) {pos}))))'])
    defs+=f'(define-fun words-index-law ((a {S}) (w WordsHistory)) Bool {indexlaw})\n'
    pair_even=f'(concat ((_ extract 127 0) {mword(2)}) (concat {mword(1)} {mword(0)}))'
    pair_odd=f'(concat {mword(4)} (concat {mword(3)} ((_ extract 255 128) {mword(2)})))'
    pairlaw=f'(=> (and (= ((_ zero_extend 1) {produced}) {beats}) {phase([2,4])}) (= (model-Q-beat model {base} {produced}) (ite {phase([2])} {pair_even} {pair_odd})))'
    defs+=f'(define-fun words-model-pair-law ((a {S}) (w WordsHistory) (model {model})) Bool {pairlaw})\n'
    helpers={
        'active-group-parent':f'(=> {state(G,[1,2,3,4,5])} '+conj([state(J,[3]),f'(= {n(G+"job_q")} {n(J+"job_q")})',f'(= {n(G+"layer_q")} {n(J+"layer_q")})',f'(= {n(G+"group_q")} {n(J+"group_q")})'])+')',
        'stream-done-seen':f'(=> {n(J+"stream_done_seen_q")} {state(G,[0])})',
        'preweight-column':f'(=> {state(G,[1,2,3])} (= {n(J+"column_q")} {bv(0,10)}))',
    }
    partial={
        'position':conj([f'(bvule {pos} #b100)',f'(= {pos} {n(P+"phase")})']),
        'block-bound':f'(bvule {block} {bv(128,8)})',
        'word-count':f'(= ((_ zero_extend 2) {n(G+"consumed_words_q")}) {wordcount})',
        'produced-position':f'(= ((_ zero_extend 1) {produced}) {beats})',
        'output-count':conj([f'(= {consumed} {n(G+"accepted_beats_q")})',f'(bvult {consumed} {bv(256,10)})',f'(bvule {produced} {bv(256,10)})',f'(bvule {consumed} {produced})']),
        'buffer-debt':f'(= ((_ zero_extend 1) {produced}) (bvadd ((_ zero_extend 1) {consumed}) (ite {n(B+"valid_q")} {bv(1,11)} {bv(0,11)})))',
        'buffer-ordinal':f'(=> {n(B+"valid_q")} (= (w-buffer-ordinal w) {consumed}))',
        'buffer-model':f'(=> {n(B+"valid_q")} (= {n(B+"data_q")} (model-Q-beat model {base} (w-buffer-ordinal w))))',
        'activation-column':f'(= {n(J+"column_q")} {consumed})',
        'low-word':f'(=> {phase([1,2])} (= {n(P+"low_word")} {mword(0)}))',
        'middle-even':f'(=> {phase([2])} (= {n(P+"middle_word")} {mword(1)}))',
        'shared-half':f'(=> {phase([3,4])} (= {n(P+"shared_half_word")} ((_ extract 255 128) {mword(2)})))',
        'middle-odd':f'(=> {phase([4])} (= {n(P+"middle_word")} {mword(3)}))',
    }
    data_scope=conj([local,'(not '+n(G+'fail_closed_o')+')'])
    clauses={**{k:f'(=> {jobhealthy} {v})'for k,v in helpers.items()},
        **{k:f'(=> {conj([data_scope,jobhealthy])if k=="activation-column"else data_scope} {v})'for k,v in partial.items()}}
    defs+='\n'.join(f'(define-fun words-clause-{i} ((a {S}) (h ApiHistory) (w WordsHistory) (model {model})) Bool {v})'for i,v in enumerate(clauses.values()))+'\n'
    defs+=f'(define-fun words-inv ((a {S}) (h ApiHistory) (w WordsHistory) (model {model})) Bool (=> {root} '+conj([f'(words-clause-{i} a h w model)'for i in range(len(clauses))])+'))\n'
    service=json.loads((HERE/'reader-PLAN.json').read_text())['rules']['consequence']['conclusion']
    defs+=f'(define-fun words-reader-service ((a {S}) (h ApiHistory) (model {model})) Bool {service})\n'
    output=conj([normal,q,n(G+'weight_valid_o')]);capture=conj([normal,f'(= {n(J+"job_q")} {bv(0,4)})',n(J+'weight_transfer')])
    expected=f'(model-Q-beat model {base} {n(J+"column_q")})'
    capture_claims=[f'(= {n(J+"stream_weight_data")} {expected})']
    for tile in range(4):
        T=E+f'g_tile[{tile}].u_tile.'
        capture_claims +=[n(T+'accept_i'),f'(= {n(T+"weights_i")} ((_ extract {tile*160+159} {tile*160}) {expected}))']
    goals=[f'(=> {output} (= {n(G+"weight_data_o")} (model-Q-beat model {base} {n(G+"accepted_beats_q")})))',f'(=> {capture} {conj(capture_claims)})']
    return defs,clauses,root,goals


def specification():
    _,clauses,normal,goals=definitions();h=lambda st:f'(|{TOP}_h| {st})';t=f'(|{TOP}_t| a an)'
    initial=[f'(|{TOP}_i| a)',h('a'),h('an'),t,'(not '+n('reset_n')+')']
    step=[h('a'),h('an'),'(operand-native-step a an)','(api-inv a h)','(reader-inv a h)','(words-reader-service a h model)','(words-inv a h w model)',
        '(= hn (api-next a h))','(= wn (words-next a w))']
    nextnormal=normal.replace(' a)',' an)')
    parts=[f'(=> {nextnormal} (words-clause-{i} an hn wn model))'for i in range(len(clauses))]
    # Prove every constant coefficient slice, then check the full 640-bit join.
    # The original invariant and its entire native state remain unchanged.
    _,_,root,_=definitions()
    q=f'(= {n(G+"job_q")} {bv(0,4)})'
    guard=conj([root,conj([n(P+'reset_n'),q]),'(not '+n(G+'fail_closed_o')+')',n(B+'valid_q')]).replace(' a)',' an)')
    actual=n(B+'data_q').replace(' a)',' an)')
    expected=f'(model-Q-beat model {n(G+"weight_base_word_q").replace(" a)"," an)")} (w-buffer-ordinal wn))'
    slices=[f'(=> {guard} (= ((_ extract {10*i+9} {10*i}) {actual}) ((_ extract {10*i+9} {10*i}) {expected})))'for i in range(64)]
    rules={'native-step-weakening':dict(assumptions=[h('a'),h('an'),t],conclusion='(operand-native-step a an)'),
        'packing-index-law':dict(assumptions=[],conclusion='(words-index-law a w)'),
        'packing-model-law':dict(assumptions=[],conclusion='(words-model-pair-law a w model)',dependencies=['packing-index-law']),
        'reset-base':dict(assumptions=initial,conclusion='(words-inv an api-zero words-zero model)'),
        **{'held-slice-'+str(i):dict(assumptions=step,conclusion=part,dependencies=['packing-index-law','packing-model-law'])for i,part in enumerate(slices)},
        **{'preserved-'+str(i):dict(assumptions=slices if i==10 else step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(words-inv an hn wn model)'),
        'consequence':dict(assumptions=[h('a'),'(api-inv a h)','(reader-inv a h)','(words-inv a h w model)',n('reset_n')],conclusion=conj(goals)),
        'reset-context':dict(assumptions=initial+[n('reset_n').replace(' a)',' an)')],conclusion='false',expected='sat')}
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ApiHistory)','(declare-const hn ApiHistory)',
        '(declare-const w WordsHistory)','(declare-const wn WordsHistory)','(declare-const model (Array (_ BitVec 18) (_ BitVec 256)))']
    return rules,declarations


def body_files():return ['connected/native.smt2','operand-step.smt2','ordered/history.smt2','api/history.smt2','reader/history.smt2','words/history.smt2']


def main():
    from operand_step import install
    install()
    defs,clauses,_,_=definitions();d=HERE/'words';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    rules,declarations=specification();bodies=body_files();files=[*bodies,'OPERAND-STEP.json','connected-SOURCES.json','api-PLAN.json','reader-PLAN.json']
    bounds=json.loads((HERE/'reader-PLAN.json').read_text())['root_external_assumptions']
    write_json(HERE/'words-PLAN.json',dict(schema='Typed-native-Q-word-packing-v1',source_manifest='connected-SOURCES.json',
        inputs={name:sha((HERE/name).read_bytes())for name in files},bodies=bodies,declarations=declarations,rules=rules,order=list(rules),
        checks_file='words-CHECKS.json',providers=dict(invariant='api',reader='reader'),root_external_assumptions=bounds,
        whole_Q_consumption_proved=False,whole_machine_theorem=False,
        observations=[n(x).replace(' a)',f' {st})')for st in ['a','an']for x in ['reset_n',A+'fail_q',J+'integrated_fail',J+'state_q',J+'column_q',J+'stream_done_seen_q',G+'state_q',G+'job_q',G+'accepted_beats_q',G+'consumed_words_q',P+'reset_n',P+'phase',P+'input_transfer',B+'push',B+'valid_q']]+['w','wn']+[f'(words-clause-{i} an hn wn model)'for i in range(len(clauses))]))
    write_json(d/'CLAUSES.json',dict(enumerate(clauses)));print('Frozen actual Q word packing, held beat and tile-capture model identities.')


if __name__=='__main__':main()

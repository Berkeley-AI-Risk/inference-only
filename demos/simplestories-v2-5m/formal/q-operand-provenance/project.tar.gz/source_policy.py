"""Conservative source gate for the new pilot: no added HDL observers.

Accepted-event histories are total SMT functions outside the circuit. Exact
native module reconstruction is the noninterference argument, not the old
assignment-target regexp. Unsupported instrumentation is rejected wholesale.
"""
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from prepare import PROJECT, PUBLIC, BINDING, modules, sha, write_json

PREFIX = '`undef FORMAL\n`define SYNTHESIS\n`default_nettype none\n'


def native_source(selection):
    pins = json.loads(BINDING.read_text())['binding']['native_join']['distributed_inputs']
    rows, pieces = {}, []
    for path, names in selection.items():
        raw = (PUBLIC/path).read_bytes()
        if raw != (PROJECT/path).read_bytes() or sha(raw) != pins['project/'+path]:
            raise ValueError('Changed native source: '+path)
        defs = modules(raw.decode())
        rows[path] = dict(sha256=sha(raw), baseline="production:"+path, public_export="production:"+path,
                          modules=names, module_sha256={n:sha(defs[n].encode()) for n in names})
        pieces.extend(defs[n] for n in names)
    return PREFIX+'\n\n'.join(pieces)+'\n', rows


def require_exact(candidate, selection):
    expected, rows = native_source(selection)
    if candidate != expected:
        raise ValueError('Added, removed or modified HDL is forbidden in this pilot; use total readonly SMT history')
    return rows


def controls(selection):
    source, _ = native_source(selection)
    # All three are actual source edits, independent of any integrity manifest.
    cases = {
        'scalar-native-write': "always @(posedge clk) owner_count_q <= 0;",
        'concat-native-write': "always @(posedge clk) {owner_count_q,owner_read_pointer_q} <= 0;",
        'alias-native-write': "wire f_alias = model_locked_i; assign f_alias = 1'b0;",
    }
    result = {}
    require_exact(source, selection)
    for label, edit in cases.items():
        changed = source.replace('\nendmodule', '\n'+edit+'\nendmodule', 1)
        try:
            require_exact(changed, selection)
        except ValueError:
            result[label] = 'rejected'
        else:
            raise ValueError('Source gate accepted native-driving instrumentation: '+label)
    return result

# Comparison with the public proof evidence

Compared against immutable public commit
[`ac68f5a0ebf5203e0928a7349224f7accc785ebe`](https://github.com/Berkeley-AI-Risk/inference-only/commit/ac68f5a0ebf5203e0928a7349224f7accc785ebe),
tree `0986ebeceb64cc2d5fbd12d01e10125001dde1da`.

| Evidence | What it establishes | Boundary relevant to this export |
| --- | --- | --- |
| [RMSNorm-to-Q segment](https://github.com/Berkeley-AI-Risk/inference-only/tree/ac68f5a0ebf5203e0928a7349224f7accc785ebe/demos/simplestories-v2-5m/formal/rms-q-segment) | Independent baseline RMS arithmetic, actual workspace and Q capture, complete Q operator, retained query RAM and readback | Starts at that segment's admitted hidden vector; it does not supply output-head row 12's original history or final score. |
| [Q operand provenance and Q operator](https://github.com/Berkeley-AI-Risk/inference-only/tree/ac68f5a0ebf5203e0928a7349224f7accc785ebe/demos/simplestories-v2-5m/formal/q-operator) | Actual Q operand/metadata pin interpretation and complete qualified Q arithmetic | Stage-entry and fixed-image contracts remain; this is a different operator/source profile. |
| [Selector WINNER](https://github.com/Berkeley-AI-Risk/inference-only/tree/ac68f5a0ebf5203e0928a7349224f7accc785ebe/demos/simplestories-v2-5m/formal/selector-winner) | From an actual accepted START, a healthy WINNER is the least-ID maximum of the 4,019 admitted rows | The model-logit producer and parent STEP/start/WINNER/reply join are outside that theorem. |
| [Public STEP/CLEAR reply ownership](https://github.com/Berkeley-AI-Risk/inference-only/tree/ac68f5a0ebf5203e0928a7349224f7accc785ebe/demos/simplestories-v2-5m/formal/public-control-ownership) | Accepted STEP owns candidate commit, bridge capture and the five-byte reply; CLEAR cancels uncaptured committed work | The candidate's numerical value is an unconstrained boundary. |
| This `c070` recorded row-12 component | Original saved RMS record, full 256-word row snapshot, original STEP/RMS/UID/episode ordering and actual engine activation exponent | Conditional on its accepted producer/history exports; later read/model-metadata/postscale/selector joins and upstream numerical composition are open in this checkpoint. |

The public formal workflow freshly reproves selected production obligations and
the baseline selector, while this command **reconstructs recorded results** for
the separate frozen output-head source profile. Neither form of evidence alone
proves the whole machine's numerical or security theorem.

There is no `main-proof` / `head-row12` package at the compared public commit. The
nine connected SV files, compilation script and `c070` native SMT in this export
have **no exact Git blob matches** in that public tree. The package therefore
carries its own exact frozen project sources. It does not assert that those
sources are identical to the current public design, or that publishing this
package automatically transfers its theorem to public main. A later source
equivalence or new source-bound proof is a separate integration decision.

The precise machine-readable and human-readable scopes in the public packages
remain authoritative for those packages. See the public
[formal index](https://github.com/Berkeley-AI-Risk/inference-only/blob/ac68f5a0ebf5203e0928a7349224f7accc785ebe/demos/simplestories-v2-5m/formal/README.md)
and [formal argument](https://github.com/Berkeley-AI-Risk/inference-only/blob/ac68f5a0ebf5203e0928a7349224f7accc785ebe/docs/FORMAL-ARGUMENT.md).

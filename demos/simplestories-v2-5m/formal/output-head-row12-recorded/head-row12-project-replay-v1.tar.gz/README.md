# Replay the original RMS record through output row 12

This package checks the closed `c070` SimpleStories output-head component. It
reconstructs **513 checked deductions** and validates **16 recorded native UNSAT
results**. It binds the complete 256-word saved input snapshot and the actual
row-engine activation exponent to the **same original RMS-API record**, retaining
that record's original STEP, RMS launch, row identity and ordering. A completed
row's previously qualified signed 48-bit / narrowed signed 35-bit dot result is
retained as an inherited qualified dependency.

It does not establish the upstream RMS arithmetic or decoder input, the later
registered read's complete model-dot application, fixed-model scale metadata,
postscale score, selector admission, token correctness, or a whole-device theorem.
The 16-leaf / 513-deduction checkpoint is the advertised scope. Later private
registered-dot work is not included in this replay.

## One replay command

Provision the project export and the separately licensed historical-tool-data
archive together at **`/proof`** on Linux, with **CPython 3.12.12** available as
`python3.12`. The tool-data archive supplies one exact historical Z3 file; it is
not executed. This fixed mount is an explicit input-layout contract;
the checker rejects another location. No Python packages, solver, compiler,
model download, network access, credentials or vendor software are needed.

```sh
python3.12 -I -S -B /proof/replay.py
```

The command writes only its JSON result to stdout. A successful result has
`passed=true`, `recorded_native_leaves=16`, `proof_nodes_reconstructed=513`,
`reconstructed_result_byte_identical=true` and `new_solver_jobs=0`. The export can
be mounted read-only. Allow roughly two minutes and up to 3 GiB of memory; elapsed
time is a replay-host measurement, not hardware performance.

The qualification record identifies the actual Linux image and Python binary
used for the clean replay. The local image identifier is evidence of that run;
it is not a remotely published container distribution. An outside verifier can
provision the stated CPython version independently.

## The statement, in hardware terms

For the qualified finite source trace `0..N`, consider physical output row 12 at
observation `n`, and let `j` be that row's original first-column snapshot event.
The saved RMS record is `R0 = endpoint-saved-NF(j) = NF(k)`. The original effective
STEP `p` and RMS launch `r` satisfy `1 <= p < r < k < j < n <= N`.

* All 256 words of the saved `ROWFRAME(n)` snapshot equal the corresponding words
  of `R0`, including coordinates that the row has not consumed yet. This does not
  say that arbitrary unconsumed physical operand registers equal those words.
* The actual row-engine activation exponent during the qualified physical row
  phases equals `R0.exp` as an exact 8-bit value. The parent datapath/projection
  exponent at the original snapshot is tied to that same record.
* The inherited completed-row result uses this saved snapshot and the fixed model
  under its existing producer and history contracts. The current NF record is
  never substituted for the original saved record.

The detailed source statement is [THEOREM.md](r-repository/inference-only/tang-greedy-speed/session-isolation/main-proof/head-row12-score-r1/engine-row-component-r1/THEOREM.md).
Fault, CLEAR, reset priority and historical-index bounds remain in the checked
formulas. No successful future or healthy next state is silently added.

## Six inherited assumptions

These are assumptions about the system being modeled, not six properties freshly
proved by this command:

1. **Actual composed source:** the run is an execution of the exact frozen `c070`
   digital source, including its clock/reset/profile and composition interfaces.
2. **First reset anchor:** the common reset input is sampled low at source sample
   0. This establishes the original reset-founded history.
3. **Second reset anchor:** the common reset input is also sampled low at source
   sample 1. The recorded induction uses this original second anchor; replay does
   not choose a convenient new reset later in the trace.
4. **Runtime-entry image and lifetime:** the model image supplied at the qualified
   runtime boundary is the named fixed image and remains valid for the relevant
   lifetime. This package does not attest a physical device's loaded image.
5. **Static metadata/model binding:** static descriptors and metadata have their
   qualified relationship to that fixed model. The row's later scale-metadata
   and selector join remain outside this component.
6. **Vendor storage contract:** modeled storage obeys the stated memory/interface
   contract. This is not vendor IP implementation, CDC, timing or board assurance.

The package also retains the accepted producer/history exports it imports. Their
exact bytes are pinned; it does not rerun every older parent proof. In particular,
the numerical meaning of RMS and its upstream decoder state belong to separate
composition work. The reset/source/image/storage assumptions cannot be replaced
by a successful replay log.

## Recorded receipts versus fresh solving

The command rebuilds the exact 16 source queries, checks recorded UNSAT protocol,
query/source/tool/log pins, resource journals and waited/reaped child receipts,
then runs the accepted deduction constructors and type checks. It compares full
reconstructed JSON and typing bytes, not only counts or a selected summary. The
read-only audit rejects file mutations, subprocesses, network and process control.

It **does not run Z3**, regenerate RTL-to-SMT, or independently verify an UNSAT
proof certificate. Solver correctness and the authenticity of the pinned recorded
run remain part of this evidence boundary. A fresh solver campaign is a distinct
operation. The historical macOS Z3 4.14.1 executable is supplied separately as read-only data
solely to preserve the original binary-hash checks. It is never executed on Linux;
no Linux binary is represented as identical to it. Its MIT license is included.

## Relocation and identities

Original closed seal:
`8b2cd9877fe5b494624c1de01c2a5c224235084a973bc249acf8ca14a7ac5252`.
Original recovery archive:
`ab8b7dd6d5b29ad0b902404d28fd6823380e26a0235c8a669fee1dac04e58b10`.
Connected native SMT:
`c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54`.
Historical Z3 binary:
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`.

`RELOCATION.json` maps each included file's original digest to its portable digest.
Neutral provisioned roots replace workstation paths; dependent hash references
and matching file-byte-length pins are propagated through the acyclic integrity
graph. Sorted JSON is recanonicalized
and the inherited recovery tar is deterministically repacked. All 36 SMT files,
the nine RTL files and the RTL compilation script remain byte-identical. No
integrity assertion is disabled. Consequently the portable result has its own
digest; it is not falsely presented as the original byte sequence or seal.

The manifest also identifies exact compact-JSON subobjects whose derived hashes
change with relocated provenance (including the six-premise context). Those
identity preimages are independently checked. Mathematical formulas are unchanged.

The export is a private release candidate. Publication goes through the existing
serialized integration review; this replay does not publish or change the source.

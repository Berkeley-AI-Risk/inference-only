# Close the original-RMS-to-actual-row-engine exponent component

Private packaging plan, no new numerical theorem or engine. Wait for independent
acceptance of the132-node original-row consequence before running this closure.
Keep the active actual selector-score assignment; this checkpoint does not
replace downstream dot/read/metadata/scale/authority work.

Prepare a read-only main checker under engine-row-component-r1. It imports and
replays the already closed original component literally (12 recorded source
leaves/227 deductions, seal574e3c37 and canonical CHECK-COMPONENT bytes). It then
reconstructs the exact four new G/B query preparations and recorded protocols/
resource receipts, using only the accepted recorded_run helper. No runner,
guard execute, new probe, old giant proof, source compile or simulation.

Replay the four new ordinary/consequence drivers,31+104+19+132=286 nodes,
comparing complete saved JSON and typing bytes and accepted result-review pins.
Total closure16 recorded native leaves/513 reconstructed deduction nodes,
with unchanged old STEP/RMS/dot provenance. Check every actual read/helper
against one frozen absolute-pin envelope; strong write/process/network/ctypes
audit and namespace restoration on success/failure. Preload ordinary standard
library modules before enabling that audit. Freeze/review exact checker,
theorem/replay prose and complete input closure before any checker execution.

After success, independently review and genuinely replay its complete canonical
result. Create a recovery archive, check every member/hash and external-pin
index, then seal the accepted component and send the authorized concise private
Senior architect handoff. Preserve old seals, stopped R1 and preparation notes.
Do not call this public or whole-device qualification, and do not publish/Git.

The readable theorem should state that during later active physical row work,
the actual E exponent and all256 ROWFRAME snapshot words reference the same
original saved RMS record at the row's first accepted column j. State original
UID/episode and p/r/k/j/n ordering and boundaries. Distinguish this functional
operand-lineage result from the complete inference-only restriction. The two
local read leaves inside the old12 remain local conditional source facts;
their presence in the inventory grants no current model-dot/read/score claim.

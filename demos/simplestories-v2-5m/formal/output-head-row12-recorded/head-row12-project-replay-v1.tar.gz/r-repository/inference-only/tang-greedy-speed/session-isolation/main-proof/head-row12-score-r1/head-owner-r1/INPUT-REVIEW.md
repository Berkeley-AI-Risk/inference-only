# Independent input review: original head-exponent owner

**Decision: LAUNCH GO for this exact three-query batch, after the coordinator
creates the hash-specific freeze/acceptance and passes pure preflight.** No
native run or freeze was performed by this reviewer. Query construction and
typing are not solver results, and passing leaves would still require the
ordinary typed finite-prefix application and exact saved-R0 join.

The additive budget clarification is accepted as the coordinating architect's
stated instruction: eight entries described the earlier reviewed batch, not
a global attempt cap. This batch authorizes exactly three first attempts,
not a diagnostic or retry. An unexpected outcome still stops its affected
chain; any changed query or later useful batch requires exact independent
review. No new user approval is required merely because another reviewed
batch follows. Older plans, reviews and frozen bytes retain their provenance.

## Exact input identities

| Input | SHA256 |
| --- | --- |
| PLAN.md | `f0b1bb68115d9df0f18f4f00af26e240a2140448b233582618cceb7d02e0f783` |
| prepare_owner.py | `a75351f775b4764ab59be3509744738bc8f20c71305f292e4500a074046cf421` |
| run_owner.py | `46f52725b7443484543d444d6808af4953759423d12f2b9d4aa5b5a1344017ef` |
| SOURCE-BINDING.json | `f04f87258bf3573477f9bdcc7c1678b0280d3c99789c4783b5bc8b1521db5cd8` |
| QUERY-PLAN.json | `9926067c81855ea46f4a4657fffd7f635922d6c10ab19a4bfe70f9f6253297aa` |
| TYPE-CHECK.json | `09a867fc28417e558b7bca60d2805b6bb9c0e32f6864a1697e4dbc54e6ba7fff` |
| READ-PINS.json | `cd478cbca7f520439a9859197b58e1ea865d3ab25982776148b62c4fe187a741` |
| EXTERNAL-PINS.json | `6260528b06deba9f981c7a304d78564e9a8af2c910588b95953cbbae128999c4` |
| TOOL-PIN.json | `f823eb9803a67ff0a59d4f876b947b7b1d4ca7383c0112bf953861f6718f95f9` |
| head-owner-base.smt2 | `60428203764fc98fdce92dae289d8f66e6186b404ef964198a2e807bb0af80b9` |
| head-owner-preserve.smt2 | `ee58bc9ccaea0aa898e0aa1394308d9221445e967e549fae4785d3db4607b2a8` |
| head-owner-origin.smt2 | `93868121de83dcfe9e6cd5f47e220772bd9968b8d039c925cdf592e05450d6ce` |

The runner requires exactly these twelve existing local inputs plus this
review, thirteen local freeze entries. All 45 external pins currently match
regular nonsymlink files; all seven actual preparation reads are covered by
external pins plus the locally pinned preparer. The envelope includes the
original exponent-leaf result/review/freeze/acceptance, parent plan/review,
budget clarification, certificate helper definitions, actual source/compile
record, accepted guard/probes and actual tool binary.

## One compound invariant and source priority

`HeadExponentHistory` is one nondriving record with validity, original Int
observation and the full original NF snapshot. Zero has validity false with
arbitrary payload. Actual next first revokes validity on D reset-low or CLEAR,
then captures current NF at the effective D head-start, stamping
`nf-t(NF)+1`; otherwise it holds the whole record. No word or dynamic stamp
chooses a different record. A fault need not erase historical payload, and no
historical payload fact grants current use.

The single four-clause `hs-I` is an explicit joint owner/control invariant:

1. Valid history has the originally accepted completed NF fields. This is the
   literal accepted-NF helper, not a new numerical RMS interpretation.
2. With D reset-high/no-CLEAR and valid history, the physical retained D
   exponent equals the original snapshot exponent, including fault-held data.
3. Live D E_HEAD has valid history and the exact six protected fields equal
   to current NF: data, exponent, RMS UID, RMS parent, STEP ID and prefix.
   Its shell phase17..21 constraint is conditional on shell-live. A shell-fault
   bubble therefore does not require a live-shell assertion. Clock, activity,
   STEP validity and count are deliberately excluded from this equality.
4. Live J with stored job7 in LOAD1/GROUP_START2/GROUP_RUN3/DONE4 implies
   D E_HEAD, valid history and physical J exponent equal to the snapshot.
   This control/exponent relation is part of the invariant being proved,
   not an assumed job birth or an application of the old LOAD-only leaf.

Thus this batch explicitly targets pre-J-birth and shell-fault preservation
that the old protected-NF LOAD lemma did not cover. It introduces no second
owner record or separate unreviewed control induction. The six-field helper
is the literal pinned certificate definition; it does not equate whole
NormFrame values at different clocks.

All four source event helpers and all four NF helpers match the accepted
parent binding literally. Effective D capture retains its reset/CLEAR/old-
fault/E_IDLE/native-head-handshake conditions, including H's actual caller
gates. J effective descriptor capture retains all earlier fault, CLEAR and
protocol priorities; its all-job version is unchanged. D CLEAR zeroing and
J CLEAR retention are not conflated. Native getters retain their actual
asynchronous-reset masks; successor reset-low can leave a historical capture
while suppressing current live/phase authority. No successor-health guard or
successful-future promise is added to the invariant or queries.

## Base, preservation and fixed origin

Base uses native H and root reset-low to establish hs-I on the literal zero
history with arbitrary NF. Its live D/J antecedents are masked at reset;
it does not assume initialized payload. Later application must retain the
original startup and A0/A1/reset convention of the qualified NF prefix.

Preservation contains H at both endpoints, the complete unchanged 452-clause
T, current hs-I, current nf-I and successor nf-I on the literal nf-next.
The successor NF provider is independently qualified and acyclic. It is not
an assumed healthy successor or the desired owner conclusion. At typed
application, the provider must be specialized on its real defined-edge domain,
with actual recurrences; passing this conditional leaf alone does not apply
that provider to an arbitrary historical index.

Origin has two fixed unary functions, `hs-event-at : Int -> Bool` and
`hs-record-at : Int -> NormFrame`. Its valid-history invariant gives
`1<=hs-at<observation`, the event at that same saved stamp and exact snapshot
equality to the record function at that stamp. Generic next gives revoke
priority over capture. Capture uses the current observation and NF together;
hold retains the identical old stamp/event/record supplied by the induction
hypothesis. No function is chosen after inspecting a stamp or coordinate.

The origin query proves generic zero/step and the literal actual/generic-next
identity. It does not bind the two functions to actual source history. The
later application must fix them uniformly to the original prefix event and
NF functions, supply NF clock=observation-1 and both recurrences, and derive
historical bounds before unfolding event/source lookups. In particular strict
past plus the current upper bound must establish the actual capture-edge
domain; no historical INDEX or future lookup exception is licensed. Preserve
the validity-scoped finite-prefix ledger used by the earlier origin result.

## Independent reconstruction and runner

After static inspection I ran only `prepare_owner.assemble()` in fresh pinned
Python3.12 with `-I -S -B`, under an audit hook denying filesystem writes,
children, network and filesystem mutation. It finished exit0 in 3.24 seconds;
the complete tool result is retained. All three query byte strings and all
four generated JSON byte strings are identical to the saved files. The actual
assembly read set is exactly the seven recorded paths. Fresh type checking
reports 12,100 symbols, one assertion and one check per query. No forbidden
operation was attempted, and no Proof initializer/old constructor ran.

I also independently parsed each saved query: all retain the exact
4,336,780-byte c070 native prefix and its 452 T conjuncts. Their tails are
exactly the pinned helpers, declarations, single negated goal, single check
and exit. All sixteen recorded getters match native definitions. The nine
compiled source files and compile script match connected-SOURCES
`8d0d406f494439ba7318d996389c6a5b830a8c30d2ee3dfc96aac9f66b25278c`.
The original source, macro/parameter profile and actual instance connections
remain unchanged; no native circuit was built or simplified for this review.

The runner differs from the accepted exponent runner only in packet paths,
scope/names, required input set and three-job accounting. It enforces the
exact thirteen-local/45-external freeze and hash-specific review acceptance,
reassembles all inputs at preflight, refuses prior intent/results/runs,
creates intent before the runs parent, checks all pins around each job and
stops at the first mismatch. Stored receipt/monitor comparison canonicalizes
JSON key types. A guard exception preserves evidence and records uncertain
owned-child status rather than claiming cleanup or success.

The pinned Z3 is
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`.
Execution remains one owned sequential worker, 4 GiB sampled RSS/footprint,
internal memory4096 and actual normal Darwin pressure, with the accepted
unchanged guard/probe closure. There is no wall/CPU/token kill, fixed RAM
floor, new resource probe, compiler, simulator slot, board or public action.
Only exact clean UNSAT plus the accepted statistics protocol can pass a job.

This is launch acceptance for the three leaves only. Raw result/resource
review, typed induction/origin application, original saved-R0/frame/row epoch
connection and closed replay remain required. Actual metadata, synchronous
dot read, postscale, restored-selector admission, upstream numerical RMS and
whole-device claims remain open. No sealed or frozen artifact was changed.

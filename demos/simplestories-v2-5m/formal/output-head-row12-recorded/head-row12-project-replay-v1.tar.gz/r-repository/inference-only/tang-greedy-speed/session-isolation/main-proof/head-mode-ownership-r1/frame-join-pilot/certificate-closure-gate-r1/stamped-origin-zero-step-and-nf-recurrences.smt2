; Stamped NF origins: generic zero/step, literal NF recurrence projections, index ordering.
; PREPARATION ONLY. No engine answer or actual source application is claimed.
(declare-datatypes
  ()
  ((StampedPayload (stampedUnit) (stampedRmsStart (sp-parent Int) (sp-prefix (_ BitVec 12))))))

(declare-datatypes () ((StampedEvent (mkStampedEvent (se-event Bool) (se-payload StampedPayload)))))

(declare-datatypes
  ()
  ((StampedHistory
      (mkStampedHistory (so-t Int) (so-valid Bool) (so-uid Int) (so-payload StampedPayload)))))

(declare-fun stamped-event-at (Int) StampedEvent)

(define-fun stamped-zero ((initial-payload StampedPayload)) StampedHistory
  (mkStampedHistory 0 false 0 initial-payload))

(define-fun stamped-next ((history StampedHistory) (event Bool) (event-payload StampedPayload) (next-valid Bool)) StampedHistory
  (mkStampedHistory
    (+ (so-t history) 1)
    next-valid
    (ite event (so-t history) (so-uid history))
    (ite event event-payload (so-payload history))))

(define-fun stamped-origin-I ((history StampedHistory) (observation Int)) Bool
  (and
    (= (so-t history) (- observation 1))
    (=>
      (so-valid history)
      (and
        (<= 1 (+ (so-uid history) 1))
        (< (+ (so-uid history) 1) observation)
        (se-event (stamped-event-at (+ (so-uid history) 1)))
        (= (se-payload (stamped-event-at (+ (so-uid history) 1))) (so-payload history))))))

(declare-sort |core_workflow_control_s| 0)

(declare-fun |core_workflow_control_n reset_n| (|core_workflow_control_s|) Bool)

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.append_transfer|
  (|core_workflow_control_s|)
  Bool)

(declare-fun |core_workflow_control_n u_native.u_token_shell.clear_i| (|core_workflow_control_s|) Bool)

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.committed_count_q|
  (|core_workflow_control_s|)
  (_ BitVec 12))

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.fail_closed_o|
  (|core_workflow_control_s|)
  Bool)

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.generated_commit|
  (|core_workflow_control_s|)
  Bool)

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.legal_rms_result_retire|
  (|core_workflow_control_s|)
  Bool)

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.rms_result_exponent|
  (|core_workflow_control_s|)
  (_ BitVec 8))

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.rms_result_mantissa|
  (|core_workflow_control_s|)
  (_ BitVec 16))

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.rms_start_transfer|
  (|core_workflow_control_s|)
  Bool)

(declare-fun |core_workflow_control_n u_native.u_token_shell.rst_n| (|core_workflow_control_s|) Bool)

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.state_q|
  (|core_workflow_control_s|)
  (_ BitVec 5))

(declare-fun
  |core_workflow_control_n u_native.u_token_shell.step_transfer|
  (|core_workflow_control_s|)
  Bool)

(declare-datatypes
  ()
  ((NormFrame
      (mkNormFrame
        (nf-t Int)
        (nf-sv Bool)
        (nf-sid Int)
        (nf-active Bool)
        (nf-uid Int)
        (nf-sparent Int)
        (nf-prefix (_ BitVec 12))
        (nf-count (_ BitVec 9))
        (nf-exp (_ BitVec 8))
        (nf-data (Array (_ BitVec 8) (_ BitVec 16)))))))

(define-fun nf-zero ((empty (Array (_ BitVec 8) (_ BitVec 16)))) NormFrame
  (mkNormFrame 0 false 0 false 0 0 (_ bv0 12) (_ bv0 9) (_ bv0 8) empty))

(define-fun nf-next ((s |core_workflow_control_s|) (h NormFrame) (empty (Array (_ BitVec 8) (_ BitVec 16)))) NormFrame
  (mkNormFrame
    (+ (nf-t h) 1)
    (ite
      (not
        (and
          (|core_workflow_control_n reset_n| s)
          (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
          (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
          (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s))))
      false
      (ite
        (and
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
          (or (= (|core_workflow_control_n u_native.u_token_shell.state_q| s) (_ bv0 5)))
          (not (|core_workflow_control_n u_native.u_token_shell.append_transfer| s))
          (|core_workflow_control_n u_native.u_token_shell.step_transfer| s))
        true
        (nf-sv h)))
    (ite
      (and
        (and
          (|core_workflow_control_n reset_n| s)
          (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
          (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
          (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
        (or (= (|core_workflow_control_n u_native.u_token_shell.state_q| s) (_ bv0 5)))
        (not (|core_workflow_control_n u_native.u_token_shell.append_transfer| s))
        (|core_workflow_control_n u_native.u_token_shell.step_transfer| s))
      (nf-t h)
      (nf-sid h))
    (ite
      (or
        (not
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s))))
        (and
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
          (or (= (|core_workflow_control_n u_native.u_token_shell.state_q| s) (_ bv0 5)))
          (not (|core_workflow_control_n u_native.u_token_shell.append_transfer| s))
          (|core_workflow_control_n u_native.u_token_shell.step_transfer| s))
        (|core_workflow_control_n u_native.u_token_shell.generated_commit| s))
      false
      (ite
        (and
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
          (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s))
        true
        (nf-active h)))
    (ite
      (and
        (and
          (|core_workflow_control_n reset_n| s)
          (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
          (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
          (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
        (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s))
      (nf-t h)
      (nf-uid h))
    (ite
      (and
        (and
          (|core_workflow_control_n reset_n| s)
          (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
          (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
          (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
        (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s))
      (nf-sid h)
      (nf-sparent h))
    (ite
      (and
        (and
          (|core_workflow_control_n reset_n| s)
          (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
          (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
          (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
        (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s))
      (|core_workflow_control_n u_native.u_token_shell.committed_count_q| s)
      (nf-prefix h))
    (ite
      (or
        (not
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s))))
        (and
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
          (or (= (|core_workflow_control_n u_native.u_token_shell.state_q| s) (_ bv0 5)))
          (not (|core_workflow_control_n u_native.u_token_shell.append_transfer| s))
          (|core_workflow_control_n u_native.u_token_shell.step_transfer| s))
        (|core_workflow_control_n u_native.u_token_shell.generated_commit| s))
      (_ bv0 9)
      (ite
        (and
          (and
            (|core_workflow_control_n reset_n| s)
            (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
            (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
            (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
          (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s))
        (_ bv0 9)
        (ite
          (and
            (and
              (and
                (|core_workflow_control_n reset_n| s)
                (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
                (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
                (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
              (|core_workflow_control_n u_native.u_token_shell.legal_rms_result_retire| s))
            (nf-active h))
          (bvadd (nf-count h) (_ bv1 9))
          (nf-count h))))
    (ite
      (and
        (and
          (and
            (and
              (|core_workflow_control_n reset_n| s)
              (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
              (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
              (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
            (|core_workflow_control_n u_native.u_token_shell.legal_rms_result_retire| s))
          (nf-active h))
        (= (nf-count h) (_ bv0 9)))
      (|core_workflow_control_n u_native.u_token_shell.rms_result_exponent| s)
      (nf-exp h))
    (ite
      (and
        (and
          (|core_workflow_control_n reset_n| s)
          (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
          (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
          (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
        (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s))
      empty
      (ite
        (and
          (and
            (and
              (|core_workflow_control_n reset_n| s)
              (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
              (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
              (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
            (|core_workflow_control_n u_native.u_token_shell.legal_rms_result_retire| s))
          (nf-active h))
        (store
          (nf-data h)
          ((_ extract 7 0) (nf-count h))
          (|core_workflow_control_n u_native.u_token_shell.rms_result_mantissa| s))
        (nf-data h)))))

(define-fun nf-effective-step-event ((s |core_workflow_control_s|)) Bool
  (and
    (and
      (|core_workflow_control_n reset_n| s)
      (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
      (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
      (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
    (or (= (|core_workflow_control_n u_native.u_token_shell.state_q| s) (_ bv0 5)))
    (not (|core_workflow_control_n u_native.u_token_shell.append_transfer| s))
    (|core_workflow_control_n u_native.u_token_shell.step_transfer| s)))

(define-fun nf-effective-rms-start-event ((s |core_workflow_control_s|)) Bool
  (and
    (and
      (|core_workflow_control_n reset_n| s)
      (|core_workflow_control_n u_native.u_token_shell.rst_n| s)
      (not (|core_workflow_control_n u_native.u_token_shell.clear_i| s))
      (not (|core_workflow_control_n u_native.u_token_shell.fail_closed_o| s)))
    (|core_workflow_control_n u_native.u_token_shell.rms_start_transfer| s)))

(define-fun nf-step-origin-observer ((h NormFrame)) StampedHistory
  (mkStampedHistory (nf-t h) (nf-sv h) (nf-sid h) stampedUnit))

(define-fun nf-rms-origin-observer ((h NormFrame)) StampedHistory
  (mkStampedHistory (nf-t h) (nf-active h) (nf-uid h) (stampedRmsStart (nf-sparent h) (nf-prefix h))))

(define-fun nf-rms-start-payload ((s |core_workflow_control_s|) (h NormFrame)) StampedPayload
  (stampedRmsStart (nf-sid h) (|core_workflow_control_n u_native.u_token_shell.committed_count_q| s)))

(define-fun nf-origin-time-I ((h NormFrame)) Bool
  (and
    (<= 0 (nf-t h))
    (=> (nf-sv h) (and (<= 0 (nf-sid h)) (< (nf-sid h) (nf-t h))))
    (=>
      (nf-active h)
      (and (nf-sv h) (= (nf-sparent h) (nf-sid h)) (< (nf-sid h) (nf-uid h)) (< (nf-uid h) (nf-t h))))))

(declare-const history StampedHistory)

(declare-const event Bool)

(declare-const event-payload StampedPayload)

(declare-const next-valid Bool)

(declare-const observation Int)

(declare-const initial-payload StampedPayload)

(declare-const s |core_workflow_control_s|)

(declare-const h NormFrame)

(declare-const empty-nf (Array (_ BitVec 8) (_ BitVec 16)))

(assert
  (not
    (and
      (stamped-origin-I (stamped-zero initial-payload) 1)
      (=>
        (and
          (<= 1 observation)
          (stamped-origin-I history observation)
          (=> next-valid (or event (so-valid history)))
          (= (stamped-event-at observation) (mkStampedEvent event event-payload)))
        (stamped-origin-I (stamped-next history event event-payload next-valid) (+ observation 1)))
      (= (nf-step-origin-observer (nf-zero empty-nf)) (stamped-zero stampedUnit))
      (= (nf-rms-origin-observer (nf-zero empty-nf)) (stamped-zero (stampedRmsStart 0 (_ bv0 12))))
      (=
        (nf-step-origin-observer (nf-next s h empty-nf))
        (stamped-next
          (nf-step-origin-observer h)
          (nf-effective-step-event s)
          stampedUnit
          (nf-sv (nf-next s h empty-nf))))
      (=> (nf-sv (nf-next s h empty-nf)) (or (nf-effective-step-event s) (nf-sv h)))
      (=
        (nf-rms-origin-observer (nf-next s h empty-nf))
        (stamped-next
          (nf-rms-origin-observer h)
          (nf-effective-rms-start-event s)
          (nf-rms-start-payload s h)
          (nf-active (nf-next s h empty-nf))))
      (=> (nf-active (nf-next s h empty-nf)) (or (nf-effective-rms-start-event s) (nf-active h)))
      (=>
        (and (<= 1 observation) (nf-origin-time-I h) (nf-active h) (= (nf-t h) (- observation 1)))
        (and
          (<= 1 (+ (nf-sid h) 1))
          (< (+ (nf-sid h) 1) (+ (nf-uid h) 1))
          (< (+ (nf-uid h) 1) observation))))))

(check-sat-using (then simplify propagate-values solve-eqs simplify smt))

(exit)

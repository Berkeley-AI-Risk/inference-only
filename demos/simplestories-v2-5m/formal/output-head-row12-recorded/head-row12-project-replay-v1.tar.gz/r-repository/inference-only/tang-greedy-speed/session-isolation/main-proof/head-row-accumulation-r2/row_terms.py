if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
S='|core_workflow_control_s|'
J='u_native.u_six_layers.u_datapath.u_projection.';G=J+'u_group_stream.';A=J+'u_shared_engine.';E=A+'u_engine.';P=E+'g_tile[0].u_tile.';M=P+'g_lane[12].u_mac.'
def c(k,*args):return [k,*args]
def n(k,s):return c('|core_workflow_control_n '+k+'|',s)
def bv(v,w):return ['_','bv'+str(v%(1<<w)),str(w)]
def eq(a,b):return ['=',a,b]
def AND(*xs):return ['and',*xs]
def OR(*xs):return ['or',*xs]
def NOT(x):return ['not',x]
def IMP(a,b):return ['=>',a,b]
def ITE(p,a,b):return ['ite',p,a,b]
def EXT(h,l,x):return [['_','extract',str(h),str(l)],x]
def SEXT(k,x):return [['_','sign_extend',str(k)],x]
def FN(k,args,t,body):return ['define-fun',k,args,t,body]
def SUB(x,mapping):return mapping.get(x,x) if isinstance(x,str) else [SUB(y,mapping) for y in x]
def signed(x,w):return ITE(eq(EXT(w-1,w-1,x),'#b1'),['-',c('bv2int',x),str(1<<w)],c('bv2int',x))
def product(a,w):return ['bvmul',SEXT(10,a),SEXT(16,w)]

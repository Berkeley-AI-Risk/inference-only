"""Closed recorded-UNSAT and deduction replay for original-row E/RMS lineage."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import contextlib
import copy
import datetime
import hashlib
import json
import math
import os
import re
import symtable
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
M = C.parent
L = M / 'head-mode-ownership-r1/frame-join-pilot/certificate-trace-application-r2'
SCOPE = 'c070-original-row-actual-E-exponent-and-same-saved-RMS-snapshot'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
canonical = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
APPLICATIONS = [
    ('engine-exponent-r1/application-r1', 'run_application.py', 'APPLICATION-R1', 31, '53d976e38586098499151d51bf25556503cf106b75ca809602e820b914c6a688'),
    ('engine-exponent-r1/current-r0-r2', 'run_consequence.py', 'CONSEQUENCE-R1', 104, '10e0eee19a57800e0029cc900c04c34c32e32f355ce789756c70bc84f2e1d566'),
    ('row-exponent-continuity-r1/application-r1', 'run_application.py', 'APPLICATION-R1', 19, 'e79032ff1f3ce0c242c66098f89996a133175873d3b4b8ea5d5b1724e317513a'),
    ('original-row-exponent-r1', 'run_consequence.py', 'CONSEQUENCE-R1', 132, '28b1ddbfe3a5629e055f6e946625c0688c56f2c0e8a9001f1fa063e4bacbc2a9')]


def load(name, path, pins):
    raw = path.read_bytes()
    assert pins[path] == digest(raw), str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def check():
    assert sys.version_info[:2] == (3, 12) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    audit = None
    try:
        audit_path = L / 'check_nf_component.py'
        raw = audit_path.read_bytes()
        assert digest(raw) == '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33'
        audit = types.ModuleType('_engine_row_closed_audit')
        audit.__file__ = str(audit_path)
        exec(compile(raw, str(audit_path), 'exec'), audit.__dict__)
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'FROZEN-COMPONENT.json'
        env = json.loads(env_path.read_bytes())
        assert env['accepted'] is True and env['scope'] == SCOPE
        pins = {Path(p): value for p, value in env['files'].items()}
        assert all(p.is_absolute() and not p.is_symlink() and digest(p.read_bytes()) == value for p, value in pins.items())
        assert pins[Path(__file__).resolve()] == env['checker_sha256']
        for field, name in [('review_sha256', 'INPUT-REVIEW.md'), ('theorem_sha256', 'THEOREM.md'), ('replay_sha256', 'REPLAY.md')]:
            assert env[field] == pins[HERE / name]
        old_seal_path = M / 'HEAD-ROW12-SAVED-RMS-EXPONENT-R1-SEALED.json'
        assert pins[old_seal_path] == '33c28d7d23908b2c11340e2d88a9dc13d8df4f06f3e7081fa63a80a8fd184946'
        old_seal = json.loads(old_seal_path.read_bytes())
        for relative, value in old_seal['files'].items():
            assert pins[C / relative] == value
        for path, value in old_seal['external_pins'].items():
            assert pins[Path(path)] == value
        assert old_seal['component_check_sha256'] == digest((C / 'CHECK-COMPONENT.json').read_bytes())
        base = load('_engine_row_prior_component', C / 'check_component.py', pins).check()
        assert base['passed'] and base['native_leaves'] == 12 and base['new_proof_nodes_reconstructed'] == 227
        assert base['new_native_jobs'] == base['writes'] == 0
        assert canonical(base) == (C / 'CHECK-COMPONENT.json').read_bytes()
        extra = load('_engine_row_extra_native', HERE / 'extra_native.py', pins).check(pins)
        assert extra['passed'] and extra['native_leaves'] == 4 and extra['new_native_jobs'] == extra['writes'] == 0
        reconstructed = []
        final_result = None
        for relative, driver, result_name, count, review in APPLICATIONS:
            h = C / relative
            assert digest((h / 'RESULT-REVIEW.md').read_bytes()) == review
            module = load('_engine_row_application_' + str(count), h / driver, pins)
            fresh, typing = module.construct()
            stored = (h / (result_name + '.json')).read_bytes()
            assert canonical(fresh) == stored and fresh == json.loads(stored)
            assert typing == (h / (result_name + '-TYPING-ONLY.smt2')).read_bytes()
            assert len(fresh['application']['nodes']) == count
            assert fresh['new_native_jobs'] == fresh['old_parent_proof_reconstructions_called'] == 0
            for key in ['actual_read_pins', 'executed_helper_pins']:
                assert all(pins[Path(p)] == value for p, value in fresh[key].items())
            reconstructed.append({'directory': relative, 'nodes': count, 'result_sha256': digest(stored),
                'typing_sha256': digest(typing), 'byte_identical': True})
            final_result = fresh
        assert sum(row['nodes'] for row in reconstructed) == 286
        assert final_result['application']['all_snapshot_words_not_unconsumed_row_operands'] is True
        assert final_result['application']['current_NF_substituted'] is False
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        assert set(audit.READS) | audit.HELPERS <= set(pins) | {env_path}
        for path, value in list(audit.READS.items()):
            assert digest(path.read_bytes()) == value
        return {'passed': True, 'scope': SCOPE, 'recorded_native_leaves': 16, 'proof_nodes_reconstructed': 513,
            'prior_component_result_sha256': digest((C / 'CHECK-COMPONENT.json').read_bytes()),
            'additional_native': extra, 'additional_applications': reconstructed,
            'proof_and_typing_byte_identical': True, 'all_actual_reads_helpers_frozen': True,
            'new_native_jobs': 0, 'writes': 0, 'old_parent_proof_reconstructions_called': 0,
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'original_row_actual_E_exponent_and_all256_snapshot_words_same_R0': True,
            'current_read_dot_metadata_postscale_selector_join_proved': False, 'whole_device_theorem': False}
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    result = check()
    print(json.dumps({k: result[k] for k in ['passed', 'scope', 'recorded_native_leaves', 'proof_nodes_reconstructed',
        'proof_and_typing_byte_identical', 'new_native_jobs', 'writes', 'whole_device_theorem']}))

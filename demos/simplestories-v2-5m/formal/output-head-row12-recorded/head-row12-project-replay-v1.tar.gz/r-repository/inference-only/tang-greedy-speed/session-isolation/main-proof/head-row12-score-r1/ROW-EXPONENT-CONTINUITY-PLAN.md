# Same original row: physical engine-exponent continuity

Proposal only; no query, preparer, solver or proof initializer for this step has
run. The current E/R0 consequence is a separate preceding gate. This plan keeps
the active same-c070-row12 selector-score assignment and all its remaining
metadata/read/arithmetic/authority obligations.

The existing selected-row observer and FRAMEORIGIN already identify the actual
first accepted column of the original row. Prefer a small continuity invariant
over a new saved exponent/certificate history or an assumed equality of current
and past NF records. Source inventory shows E captures its exponent only at an
accepted IDLE start with a valid descriptor, the same effective event that
asserts every tile's begin_i. That event resets the existing selected-row count
to0. E otherwise holds its exponent through META/WEIGHTS/DRAIN/EMIT/DONE.
Common reset exposes IDLE; CLEAR, failure and a later new start retain their
literal source priorities. This inventory is a motivation, not a proof.

Proposed one invariant, with a fixed unary function EXP_AT:

```text
E.state(s) in {META,WEIGHTS,DRAIN,EMIT,DONE}
  and rr-physical(row) and rr-n(row)>0
  implies E.activation_exponent_q(s) = EXP_AT(origin).
```

The original-prefix instance uses row=ROW(n), origin=FRAMEORIGIN(n) and fixes
EXP_AT(t) to the actual getter E.activation_exponent_q(A(t)). It claims physical
continuity, without granting current output authority. There is no J-live or
future-health filter in this proposed invariant. Any attempted source check
that needs stronger premises must stop and be reviewed additively.

Two proposed first native checks, both using the unchanged full c070 model:

1. Both the actual H and common reset-low at the current observation imply the
   invariant for arbitrary row/origin. The actual reset-masked E state must make
   the antecedent false; no assumed zero exponent or desired saved record.
2. Both H and all452 T, the current invariant, and the single current-point
   identity EXP_AT(observation)=actual E exponent at a imply the invariant at b.
   Its row argument is the literal accepted selected-row-next of the actual
   row-source-view at a; its origin argument is the literal accepted
   row-frame-origin-index-next with the same observation and current row.
   Empty arrays can be the current row arrays, uniformly chosen, since they do
   not affect the scalar physical/count projection. No current/successor
   control provider, numerical/model oracle or desired historical value is
   proposed as an extra premise.

The current-point identity in check2 is only the uniform function-instance
bridge. In the ordinary prefix application it must be derived by the literal
definition of the fixed actual EXP_AT function and equality reflexivity at n.
It is not a root assumption about a historical or desired RMS exponent. At a
new row capture, new origin=n and the bridge supplies that point; on retained
work the IH supplies the unchanged old origin. The solver must establish all
source cases, including start/begin, descriptor rejection, reset masking, fault
and CLEAR, without suppressing any edge.

Before preparing/executing queries: independently review this decomposition;
pin the old completed-dot source/typing/seal and actual selected-row/origin
definitions and source getter/port/priority cone. Extract ASTs directly from
accepted artifacts, never run old builders, simulation or compilation. Then
independently review/freeze the exact prepared inputs and source obligations.

Resource budget: two first native attempts, one owned worker, 4GiB RSS and
physical footprint, actual normal Darwin pressure, Z3 memory4096 and accepted
guard/probe reuse. No wall/CPU/token kill, new resource probe or free-RAM floor.
Unexpected SAT/unknown/error/resource stop preserves query/receipt and stops
that version; any diagnostic or strengthening needs an additive exact review.
Further batches are not authorized by silently treating this as a broad limit.

After accepted leaves, separately review a single ordinary induction, budget96
deduction nodes/zero engines. Import the existing total selected-row and
FRAMEORIGIN definitions with their accepted source anchors; do not turn their
bounded edge results into unbounded state axioms. Retain the full original
six-root context for ordinary construction and the same41af bounded prefix.
Base only uses observations0/1; step only n/n+1 on1<=n<N. The fixed EXP_AT
realization is chosen once before observation indices or word choices. Keep
its historical calls opaque during induction; derive original-j bounds before
unfolding an actual past A(j). Metadata0 before one construction, a restricted
deduction/prefix audit and independent byte-identical JSON/typing replay remain
mandatory.

Then separately review the read/current-row application, budget192 nodes and
zero engines. At a qualified physical row with count>0, use original saved-row
and row-frame-origin state invariants to derive srf-valid and1<=j<n<=N, where
j=FRAMEORIGIN(n). The original row-frame-origin theorem provides the actual
capture event at j and original UID/episode/snapshot identity. Apply the already
accepted source row-capture guard at that defined historical point to derive
actual J-live/head and E WEIGHTS. Apply the current E/R0 consequence at j, then
rewrite this continuity equality to the original endpoint-saved-NF(j).exp.
Never substitute current NF or identify different certificates just because
their exponent bits, UID or word values match.

This would give the missing original-row exponent association at a later actual
read. It does not yet prove pending MAC absence/current accumulator equivalence,
global row12/group0 read/tag ownership, model metadata consumption/exponent
representability, postscale arithmetic/stall behavior, first-fault classification
or legal selector admission. No whole-device, other-release, board/public or
Lean claim is part of this proposal.

"""Closed read-only replay of the twelve independently reviewed native leaves."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import contextlib
import datetime
import hashlib
import json
import math
import os
import re
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
M = HERE.parent
P = M / 'head-mode-ownership-r1'
L = P / 'frame-join-pilot/certificate-trace-application-r2'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
rd = lambda path: json.loads(path.read_bytes())
SCOPE = 'twelve-c070-exponent-owner-frame-link-and-read-native-leaves'
GATES = [('', 'prepare_exponent.py', 'EXPONENT-LEAVES-RESULT-REVIEW.md', '7a493165cdc622bb389703ec595da5f7c4eee793ca6011e7d504a6541494b28e', 4),
    ('head-owner-r1', 'prepare_owner.py', 'RESULT-REVIEW.md', 'bef909a7afed26ebd312f255f3465e936114666e4b23d294cf9a1f8de45a7127', 3),
    ('frame-owner-join-r1', 'prepare_frame_owner.py', 'RESULT-REVIEW.md', '9b404e56c95c876bae0051707693186b32a8e4654bbbb7e3d216ef2948b854ca', 3),
    ('native-read-r1', 'prepare_read.py', 'RESULT-REVIEW.md', 'bee42b4b84c39b93dc3e26b83281e617b15213dd25314ddd57d2dcba45f0a682', 2)]


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def check():
    assert sys.version_info[:2] == (3, 12) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    audit = None
    try:
        audit_path = L / 'check_nf_component.py'
        audit = load('_native_leaves_readonly_audit', audit_path, '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33')
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'FROZEN-NATIVE-LEAVES.json'
        env = rd(env_path)
        assert env['accepted'] is True and env['scope'] == SCOPE
        pins = {Path(p): v for p, v in env['files'].items()}
        assert all(p.is_absolute() and not p.is_symlink() and digest(p.read_bytes()) == v for p, v in pins.items())
        assert pins[Path(__file__).resolve()] == env['checker_sha256']
        review_path = HERE / 'NATIVE-LEAVES-REPLAY-REVIEW.md'
        assert env['review_sha256'] == pins[review_path] == digest(review_path.read_bytes())
        recorded = load('_native_leaf_resource_records', P / 'check_mode.py', 'c8b997cde90d89035bd73d23a99fe52f562ffffd7024ff8d132402e7a6ba307f')
        parser = load('_native_leaf_parser', P / 'support.py', '898af07523f801c69d9806fe878cc5863552edb78e288e616778de1de729d130')
        protocol = load('_native_leaf_protocol', P / 'output_check.py', '17cfd5f03fea5f537aaf26740fa253f87ed3faa815139159ee6af45010eb3897')
        connected = M / 'rmsnorm-pilot/model-consumption/connected'
        source = rd(connected.parent / 'connected-SOURCES.json')
        assert source['native_smt_sha256'] == 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
        assert digest((connected / 'native.smt2').read_bytes()) == source['native_smt_sha256']
        for name, value in source['files'].items():
            assert digest((connected / name).read_bytes()) == value
        assert digest((connected / 'compile.ys').read_bytes()) == source['script_sha256']
        checked = []
        for relative, preparer, review, review_sha, count in GATES:
            h = HERE / relative
            assert digest((h / review).read_bytes()) == review_sha
            frozen, accepted = rd(h / 'FROZEN-INPUTS.json'), rd(h / 'REVIEW-ACCEPTED.json')
            assert accepted['accepted'] and accepted['scope'] == frozen['scope']
            assert accepted['max_native_jobs'] == count and accepted['frozen_sha256'] == digest((h / 'FROZEN-INPUTS.json').read_bytes())
            assert accepted['review_sha256'] == digest((h / 'INPUT-REVIEW.md').read_bytes())
            for n, value in frozen['files'].items():
                assert pins[(h / n).resolve()] == value and digest((h / n).read_bytes()) == value
            for p, value in rd(h / 'EXTERNAL-PINS.json').items():
                assert pins[Path(p)] == value and digest(Path(p).read_bytes()) == value
            module = load('_native_leaf_prepare_' + str(len(checked)), h / preparer, frozen['files'][preparer])
            queries, binding, plan, typing, reads = module.assemble()
            assert binding == rd(h / 'SOURCE-BINDING.json') and plan == rd(h / 'QUERY-PLAN.json')
            assert typing == rd(h / 'TYPE-CHECK.json') and reads == rd(h / 'READ-PINS.json')
            intent, result, tool = rd(h / 'RUN-INTENT.json'), rd(h / 'RESULTS.json'), rd(h / 'TOOL-PIN.json')
            assert intent['scope'] == frozen['scope'] and intent['query_order'] == plan['order']
            assert intent['max_native_jobs_this_gate'] == count
            assert intent['workers'] == 1 and intent['RSS_and_physical_footprint_cap_bytes'] == 4 * (1 << 30)
            assert intent['time_or_CPU_kill_enabled'] is False
            assert tool['sha256'] == 'ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102'
            assert intent['tool'] == tool and digest(Path(tool['path']).read_bytes()) == tool['sha256']
            assert result['all_expected_results_matched'] and result['active_owned_native_job'] is None
            assert result['native_jobs'] == len(result['results']) == len(plan['order']) == count
            expected_runs = {name for name in plan['order']} | {name + '-observations.jsonl' for name in plan['order']}
            assert {p.name for p in (h / 'runs').iterdir()} == expected_runs
            previous_end = None
            for name, row in zip(plan['order'], result['results']):
                q = h / (name + '.smt2')
                assert queries[name] == q.read_bytes() and digest(queries[name]) == plan['queries'][name]['sha256']
                assert row['name'] == name and row['expected'] == row['answer'] == 'unsat' and row['matched']
                assert row['query_sha256'] == digest(queries[name]) and row['binary_sha256'] == tool['sha256']
                folder = h / 'runs' / name
                assert {p.name for p in folder.iterdir()} == {'STARTED.json', 'FINISHED.json', 'MONITOR-BINDING.json', 'NATIVE.log', 'CHECKED-RESULT.json'}
                assert rd(folder / 'CHECKED-RESULT.json') == row
                argv = [tool['path'], '-smt2', '-st', '-memory:4096', str(q)]
                start, finish, monitor = recorded.recorded_run(folder, h / 'runs' / (name + '-observations.jsonl'), argv)
                assert row['receipt'] == finish and row['monitor_binding'] == monitor
                assert start['cwd'] == str(h) and finish['cwd'] == str(h)
                assert start['environment_changes'] == {} and start['single_process_required'] is True
                if previous_end is not None:
                    assert previous_end <= recorded.dt(start['started_utc'])
                previous_end = recorded.dt(finish['finished_utc'])
                log = (folder / 'NATIVE.log').read_bytes()
                forms = [f for f, _, _ in parser.parse_spans(log)]
                assert protocol.accept(forms, 'unsat', []) and row['raw_log_sha256'] == digest(log)
                checked.append({'gate': relative or '.', 'name': name, 'query_sha256': digest(queries[name]),
                    'raw_log_sha256': digest(log), 'native_waited_and_reaped': True, 'wall_seconds': finish['wall_seconds']})
        assert len(checked) == 12
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        assert set(audit.READS) | audit.HELPERS <= set(pins) | {env_path}
        for p, value in list(audit.READS.items()):
            assert digest(p.read_bytes()) == value
        return {'passed': True, 'scope': SCOPE, 'results': checked, 'native_leaves': 12,
            'all_query_preparations_byte_identical': True, 'all_reads_helpers_frozen': True,
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'new_native_jobs': 0, 'writes': 0, 'historical_saved_R0_or_scaled_score_claimed_by_this_checker': False,
            'whole_device_theorem': False}
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)

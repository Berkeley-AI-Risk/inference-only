# Independent current-FRAME endpoint application result review

**Decision: PASS. Accept the exact 55-node bounded-source endpoint application
and its literal uniform-word export.** One fixed saved NF/RMS-API record is
identified with actual `NF(k)` on the original prefix, and every BV8 word of
the complete live head FRAME equals that same record. This is transport and
provenance, not numerical RMS/model correspondence, original STEP/RMS event
identification, historical row12 composition, scaling or a whole-device result.

## Accepted artifacts and independent replay

| Artifact | SHA256 |
| --- | --- |
| `ENDPOINT-PROJECTION-INPUTS-R1.json` | `2be9e8ad8f771778fbccf4dbd3420d3517d7e39ab43ccfbf9a95ac8b0910e90e` |
| `ENDPOINT-PROJECTION-METADATA-R1.json` | `bb3212535c5d9d60d9a3df90b343d1fb61fa41b1f512f9986007f0e3e28e0352` |
| `ENDPOINT-PROJECTION-APPLICATION-R1.json` | `b38af031a06073c6c8b16099e8f93c87f18066e4406bb567875eaa551ff7e9aa` |
| `ENDPOINT-PROJECTION-APPLICATION-R1-TYPING-ONLY.smt2` | `21ebea26cb493729b7f338f7fd0f6c7cbbb38a14e18b36ad59906f8785010d70` |

The ten-entry accepted input envelope matches the reviewed driver `54613f91...`,
application code `99738305...`, plan/code/driver reviews and closed projection
provider. The provider's 55-file replay freeze is `afa9ab71...`, acceptance is
`b776e5dd...`, checker is `d67c3380...`, and accepted raw-result review is
`d0edb123...`. The saved closed provider check passes and its 57 actual read
pins equal the provider embedded in the source application.

I ran the pinned driver's `construct()` once in a fresh Python3.12 process
with `-I -S -B`, an additional read-only/process/network guard and the reviewed
internal auditor. The complete reconstructed JSON serialized byte for byte
to the saved application, and the typing bytes matched exactly. There are 55
nodes, global node54, 108 actual read pins, 21 executed helper pins and 57
provider read pins. Every recorded file hash matches; every helper and provider
read is covered by the application's read map. No solver, simulation,
guard/probe execution, old parent-proof reconstruction or artifact overwrite
occurred. Only this review was written.

The earlier metadata-only artifact has the same input envelope, 108 matching
read pins and 21 helper pins, and reports zero initializers and zero nodes.
Inspection of the reviewed path confirms it returns before the proof
initializer; compiling the existing class/definition ASTs is not invoking a
constructor. The full replay independently traversed the same preparation
boundary before constructing the endpoint.

## Exact source, bounds and record identity

The actual root context is exactly the accepted bounded six-root context,
digest `b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383`.
It retains the original source/reset/storage/image/metadata conditions and
the existing fixed histories. The only natural-index scope is current i;
there is no historical INDEX, IH premise, source-H/T projection, past-provider
call, new induction or edge leaving N.

Node0 imports the exact sealed bounded CERT consequence under `N>=1`.
Nodes8/9 specialize it at current i and BV8 zero, with the literal
`1<=i<=N` antecedent applied to the actual lower and upper parents. The
scalar gate supplies validity, `1<=k<i`, capture-record identity, accepted
saved NF, FRAME owner and width256. Nodes21--23 apply the separately accepted
integer-order implication to actual `k<i` and `i<=N` parents, deriving `k<=N`.
No bound is asserted as a new source/root premise.

Only after those bounds do nodes24--29 instantiate the two actual record
definitions. Both bounds are retained in their used lookup-equality parents.
The exposed accesses are precisely `A(k)`, `COLUMNS(k)`, `FRAME(k)` and `NF(k)`
on that derived prefix observation. Record rewriting and the exact accepted
constructor/NF-selector clause yield node36:

```text
frc-nf(CERT(i)) = NF(frc-at(CERT(i))).
```

This is equality to the actual fixed NF history, not a historical NF invariant
instance or a delegated desired value. The fixed K/R0 definition instances
are nodes37/38. The folded scalar/range/access report retains the actual
K-definition parent and exact folded lower/upper parents42/43, so `NF(K(i))`
is supported through checked alias substitution rather than an allowed-index
exception.

## Uniform word and support closure

The one K(i) and R0(i) are fixed functions of `CERT(i)`. All scalar formulas
through node44 are independent of the fresh word. The typing specimen places
both helper definitions before its WATCH declaration. Nodes45/46 apply the
same bounded CI at current i and arbitrary BV8 w, with the same current-domain
parents; nodes47--51 give the complete-word identity with that same R0.
No origin, record or history depends on w.

I independently checked the formula/parent relationship of every actual node:
exact conjunction introduction/elimination, MP, literal definition instances,
equality-context replacements, complete accepted query-goal substitutions and
their clause projections, the two fixed bounded forall eliminations, case
implication and final generalization. This supplements the byte-identical
constructor replay. The three projection instances match the entire accepted
gate goal and provider provenance; the order instance matches the accepted
separate query. All support ancestry/discharge equations match.

Node53 discharges exactly the endpoint case; node54 uses the existing checked
globalization rule and discharges exactly the current-index domain. Its final
support is exactly the six original source roots. The literal export is:

```text
forall w:BV8, i:Int.
  1<=i =>
    (N>=1 && i<=N && live-head-active-complete(i) =>
      valid(CERT(i)) && 1<=K(i)<i && K(i)<=N
      && CERT(i)=record-at(K(i)) && accepted-NF(R0(i))
      && CERT(i).juid=FRAME(i).uid && FRAME(i).cols=256
      && R0(i)=NF(K(i))
      && FRAME(i).data[zero_extend(w,2)]=R0(i).data[w]).
```

The artifact keeps this actual `forall(w,i)` form; this review does not invent
an inner-forall proof node. The fixed helpers before w supply the required
one-record-for-all-256-coordinates meaning. Addresses256--1023 are outside
the claim. The typechecker reports 55 assertions and 15,160 symbols with the
expected typing hash; it supplies sorts, while the accepted implications and
checked applications above supply proof.

## Controls, limits and closure

The unmodified later-NF replacement query remains `1c6ebc38...`, bound to its
original SAT receipt/review and read as such by the application. It refutes
replacing the saved record with later current same-prefix NF at the generic
certificate cut. It is not a reset-reachable source counterexample or a new
operating witness. No control was strengthened or rerun, and the endpoint
does not assume current NF equals the saved record.

FrameHistory still has no exponent field. Whole-record identity retains NF
exponent/owner/prefix metadata but establishes no actual consumer/output
exponent or scaling law. Original STEP/RMS event observations, historical
selected-row12 substitution, numerical RMS/model-vector correspondence and
whole-device/configuration claims remain open. All corresponding producer
flags remain false and the frozen independent-review-pending flag is preserved;
this later review supplies result acceptance without rewriting those records.

The reviewed application stays within the 96-node budget and adds zero engines,
simulations, controls, inductions or old parent replays. Final closed component
entry, pin/recovery packaging and its independent closeout may now preserve
this accepted result. No STEP/RMS or row successor is automatically authorized
by this result review.

"""Pure assembly of two actual c070 row12 synchronous-read source leaves."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
ROOT = C.parent
P = ROOT / 'head-mode-ownership-r1'
S = '|core_workflow_control_s|'
E = 'u_native.u_six_layers.u_datapath.u_projection.u_shared_engine.u_engine.'
TILE = E + 'g_tile[0].u_tile.'
ORDER = ['row12-tile0-synchronous-read', 'row12-stage1-capture-and-pipeline-stall']
READS = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
c = lambda name, *args: [name, *args]
AND = lambda *args: c('and', *args)
EQ = lambda x, y: c('=', x, y)
NOT = lambda x: c('not', x)
IMP = lambda x, y: c('=>', x, y)
BV = lambda n, w: ['_', 'bv' + str(n), str(w)]
extract = lambda hi, lo, v: [['_', 'extract', str(hi), str(lo)], v]
extend = lambda kind, count, v: [['_', kind + '_extend', str(count)], v]


def read(path, expected=None):
    path = Path(path).resolve()
    raw = path.read_bytes()
    value = digest(raw)
    assert expected is None or value == expected
    assert READS.setdefault(str(path), value) == value
    return raw


def assemble():
    READS.clear()
    path = C / 'prepare_exponent.py'
    prep = types.ModuleType('_read_fixed_exponent_helpers')
    prep.__file__ = str(path)
    exec(compile(read(path, '7eb5e7b8917d57e3d5e14a78620d922276901e6d6623a913630e4c80a7ba6cc4'), str(path), 'exec'), prep.__dict__)
    with prep.checked_helpers() as (parser, typing):
        raw = read(ROOT / 'rmsnorm-pilot/model-consumption/connected/native.smt2', prep.NATIVE_SHA)
        native = [f for f, _, _ in parser.parse_spans(raw)]
        defs = {f[1]: f for f in native if f[0] == 'define-fun'}
        assert len(defs['|core_workflow_control_t|'][4]) - 1 == 452
        observations = {}
        def getter(path, state='a', memory=False):
            name = '|core_workflow_control_' + ('m ' if memory else 'n ') + path + '|'
            assert defs[name][2] == [['state', S]]
            observations[name] = {'literal_getter_definition': defs[name], 'sort': defs[name][3]}
            return c(name, state)
        e = lambda path, state='a': getter(E + path, state)
        t = lambda path, state='a': getter(TILE + path, state)
        ha, hb, transition = c('|core_workflow_control_h|', 'a'), c('|core_workflow_control_h|', 'b'), c('|core_workflow_control_t|', 'a', 'b')
        edge = AND(ha, hb, transition)
        issue12 = AND(e('issue'), EQ(e('issue_count_q'), BV(12, 7)))
        read_cone = AND(*[getter(E + 'g_tile[' + str(i) + '].u_tile.read_i') for i in range(4)],
            EQ(t('read_lane_i'), BV(12, 4)), e('advance'))
        old_mult = c('select', getter(TILE + 'multiplier_q', memory=True), BV(12, 4))
        old_exp = c('select', getter(TILE + 'exponent_q', memory=True), BV(12, 4))
        read_tuple = AND(EQ(t('dot_o', 'b'), t('accumulator_q[12]')),
            EQ(t('multiplier_o', 'b'), old_mult), EQ(t('exponent_o', 'b'), old_exp),
            EQ(e('selected_tile_q', 'b'), BV(0, 2)), EQ(e('row_pipe_q[0]', 'b'), BV(12, 6)))
        read_hold = IMP(NOT(t('read_i')), AND(*[EQ(t(field, 'b'), t(field))
            for field in ['dot_o', 'multiplier_o', 'exponent_o']]))
        read_goal = AND(IMP(AND(ha, issue12), read_cone), IMP(edge, AND(IMP(issue12, read_tuple), read_hold)))
        stage1 = AND(e('advance'), EQ(extract(0, 0, e('scale_valid_q')), '#b1'),
            EQ(e('selected_tile_q'), BV(0, 2)), EQ(e('row_pipe_q[0]'), BV(12, 6)))
        captured = AND(EQ(e('low_operand_q', 'b'), extend('zero', 2, extract(24, 0, t('dot_o')))),
            EQ(e('high_operand_q', 'b'), extend('sign', 17, extract(34, 25, t('dot_o')))),
            EQ(e('scale_operand_q', 'b'), extend('zero', 2, t('multiplier_o'))),
            EQ(e('row_pipe_q[1]', 'b'), BV(12, 6)), EQ(e('exponent_pipe_q[1]', 'b'), t('exponent_o')))
        held_fields = ['selected_tile_q', 'low_operand_q', 'high_operand_q', 'scale_operand_q',
            'low_product_q', 'high_product_q', 'result_q',
            *['row_pipe_q[' + str(i) + ']' for i in range(4)],
            *['exponent_pipe_q[' + str(i) + ']' for i in range(1, 4)]]
        stall = IMP(NOT(e('advance')), AND(*[EQ(e(field, 'b'), e(field)) for field in held_fields]))
        stage_goal = IMP(edge, AND(IMP(stage1, captured), stall))
        goals = dict(zip(ORDER, [read_goal, stage_goal]))
        declarations = [['declare-const', name, S] for name in ['a', 'b']]
        queries, reports = {}, {}
        for name in ORDER:
            additions = [*declarations, ['assert', NOT(goals[name])],
                ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            query = raw + ('\n' + '\n'.join(map(parser.smt, additions)) + '\n').encode()
            assert [f for f, _, _ in parser.parse_spans(query) if f[0] == 'assert'] == [['assert', NOT(goals[name])]]
            reports[name] = typing.check(query)
            queries[name] = query
        READS.update(prep.READS)
        read(HERE / 'prepare_read.py')
        binding = {'native_sha256': prep.NATIVE_SHA, 'native_T_conjuncts': 452,
            'entire_native_prefix_retained': True, 'native_getter_bindings': observations,
            'declarations': declarations, 'goals': goals, 'actual_issue12': issue12,
            'actual_stage1_row12': stage1, 'stall_payload_fields': held_fields,
            'read_before_same_edge_memory_write': True, 'stage1_uses_pre_edge_tile_outputs': True,
            'future_reset_CLEAR_or_health_filter': False,
            'original_UID_completed_dot_or_fixed_metadata_application_proved': False,
            'postscale_or_selector_score_proved': False, 'new_native_jobs': 0}
        plan = {'scope': 'two-c070-row12-synchronous-read-and-stage1-leaves', 'order': ORDER,
            'queries': {name: {'sha256': digest(queries[name]), 'expected': 'unsat'} for name in ORDER},
            'maximum_native_jobs_this_gate': 2, 'diagnostic_launch_authorized_by_this_gate': False,
            'workers': 1, 'memory_cap_bytes': 4 * (1 << 30), 'new_native_jobs': 0,
            'time_or_CPU_kill_enabled': False, 'unexpected_result_stops_dependents': True}
        return queries, binding, plan, reports, dict(READS)


if __name__ == '__main__':
    queries, binding, plan, types, pins = assemble()
    for name, raw in queries.items():
        with (HERE / (name + '.smt2')).open('xb') as output:
            output.write(raw)
    for name, value in [('SOURCE-BINDING.json', binding), ('QUERY-PLAN.json', plan),
                        ('TYPE-CHECK.json', types), ('READ-PINS.json', pins)]:
        with (HERE / name).open('x') as output:
            output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_queries': list(queries), 'new_native_jobs': 0}))

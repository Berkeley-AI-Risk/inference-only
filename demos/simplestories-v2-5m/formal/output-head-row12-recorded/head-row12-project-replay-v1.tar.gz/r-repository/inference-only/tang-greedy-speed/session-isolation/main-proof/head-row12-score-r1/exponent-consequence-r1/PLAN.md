# Apply the saved RMS exponent at the original frame and row snapshot

Unrun preparation. The independently accepted96-node owner/link application
is32682edf..., review814a8503. It supplies two original finite-prefix invariants;
this next step applies their native saved-exponent consequence, without new
induction, engine or source assumption. Budget256 typed deduction nodes.

At any actual live/head/active/complete FRAME i, derive the actual D and J
retained physical exponent registers equal endpoint-saved-NF(i).exp. Supply
native H from the exact bounded source clause, actual frame-I, and the new HS/HF
bounded invariants with proved1<=i<=N and original1<=N. Original endpoint gives
CERTvalid and R0=NF(k), original k/UID/STEP parent/prefix. The saved helper is
literally CERT(i).nf. There is no current-NF replacement after completion.

Then at a selected physical completed row12 observation n, retain the qualified
original STEP/RMS/dot theorem unchanged. It derives j=FRAMEORIGIN(n),1<=j<n<=N,
the actual row capture and completed FRAME there. Use only bounded STATE control
and FRAME theorems plus the accepted native capture-guard query to establish
the actual live/head/active guard at j. This repeats the small already checked
guard derivation, not the old large proof. Apply the new current consequence
at j with derived bounds. Export the existing all-word/dot/origin theorem plus
D/J exponent at A(j)=original R0(j).exp. Word choice occurs after scalar/witness
derivations. Keep literal D(S,M,256), original UID/episode and cancellation
authority. Do not claim the later E/postscale/selector has already consumed eA.

Reuse only the pinned accepted FixedApplication bounded/definition/helper
methods and existing Proof/ValueProof APIs. No old constructor/driver.check or
engine/compiler/writer may run. Explicit function-realization specialization
of the generic record UF remains tied to the qualified actual record function.
Historical source lookup requires both derived bounds; never INDEX(j), an edge
at j, stateN+1, infinite extension, or future-health success filter.

Review exact code, driver, mappings/parents, old/new component pin closure and
bound-contexts before an initializer. Metadata-only first, zero proof nodes;
then one frozen constructor and standalone typing, independent full DAG/formula/
parent/support/boundary review and byte-identical read-only replay. Save any
first failure's exact formula, partial DAG, active scopes and read/helper pins;
stop that chain. Changes require additive reviewed versions. No time/token kill.

After qualification, seal/report this useful exponent component to the
authorized coordinator and continue registered read, fixed-image metadata,
postscale/held tuple and actual legal greedy-selector admission. Upstream RMS
and decoder math are separate assignments; no Lean, public, board, build,
other-row or whole-device claim is made here.

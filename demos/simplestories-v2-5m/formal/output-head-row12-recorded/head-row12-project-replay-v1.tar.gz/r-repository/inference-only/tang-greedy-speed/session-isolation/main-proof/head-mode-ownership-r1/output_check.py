if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
import math


def statistics(node):
    if not isinstance(node,list) or not node or len(node)%2:return False
    keys=node[::2]
    if any(not isinstance(k,str) or not k.startswith(':') for k in keys) or len(set(keys))!=len(keys):return False
    try:return all(math.isfinite(float(v)) and float(v)>=0 for v in node[1::2])
    except (ValueError,TypeError):return False


def value(node,sort):
    if sort=='Bool':
        assert node in ['true','false'];return node=='true'
    if sort=='Int':
        def numeral(x):
            return isinstance(x,str) and x.isascii() and x.isdigit() and (x=='0' or x[0]!='0')
        if isinstance(node,str):
            assert numeral(node);return int(node)
        assert isinstance(node,list) and len(node)==2 and node[0]=='-' and numeral(node[1])
        return -int(node[1])
    assert sort[:2]==['_','BitVec'];width=int(sort[2])
    if isinstance(node,str) and node.startswith('#x'):
        assert len(node[2:])*4==width;n=int(node[2:],16)
    elif isinstance(node,str) and node.startswith('#b'):
        assert len(node[2:])==width and set(node[2:])<={'0','1'};n=int(node[2:],2)
    else:
        assert isinstance(node,list) and len(node)==3 and node[0]=='_' and isinstance(node[1],str) and node[1].startswith('bv')
        assert node[1][2:].isdigit() and node[2]==str(width);n=int(node[1][2:])
    assert 0<=n<1<<width;return n


def observed(forms,observations):
    assert len(forms)==3 and forms[0]=='sat' and statistics(forms[2])
    rows=forms[1];assert isinstance(rows,list) and len(rows)==len(observations)
    out={}
    for pair,expected in zip(rows,observations):
        assert isinstance(pair,list) and len(pair)==2 and pair[0]==expected['alias']
        assert expected['label'] not in out
        out[expected['label']]=value(pair[1],expected['sort'])
    return out


def accept(forms,expected,observations):
    try:
        if expected=='unsat':return len(forms)==2 and forms[0]=='unsat' and statistics(forms[1])
        assert expected=='sat'
        values=observed(forms,observations)
        return all(values[o['label']]==o['expected'] for o in observations)
    except (ValueError,TypeError,AssertionError,IndexError):return False

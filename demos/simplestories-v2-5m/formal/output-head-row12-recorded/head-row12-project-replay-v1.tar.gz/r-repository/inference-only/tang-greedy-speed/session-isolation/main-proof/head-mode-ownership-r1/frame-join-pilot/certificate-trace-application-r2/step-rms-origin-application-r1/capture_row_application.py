"""Fixed bounded applications: saved NF origins and original completed row12.

Unrun preparation. No I/O, constructors, engine or source assumption at import.
The driver must bind accepted first-stage result/review and all raw parents.
"""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json

CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
I = 'i_capture_origin'
J = 'n_row_origin'
W = 'capture-origin-watch'
RW = 'row-origin-watch'
PSTEP = 'original-STEP-observation'
PRMS = 'original-RMS-observation'
CAPTURE_FAMILY = 'live-frame-actual-STEP-RMS-origins'
ROW_FAMILY = 'completed-row12-actual-STEP-RMS-origins'
canon = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def helper_definitions():
    return [['define-fun', name, [['frame-observation', 'Int']], 'Int',
        ['+', [selector, ['endpoint-saved-NF', 'frame-observation']], '1']]
        for name, selector in [(PSTEP, 'nf-sid'), (PRMS, 'nf-uid')]]


class FixedApplication:
    def __init__(self, proof, language, exports, raw_data, origin_result, prepared, steps):
        self.proof, self.language, self.api = proof, language, exports['apis']
        self.data, self.origins, self.prepared, self.steps = raw_data, origin_result, prepared, steps
        self.c, self.EQ, self.SUB = self.api['c'], self.api['eq'], self.api['SUB']
        self.context = deepcopy(proof.root_context)
        assert digest(canon(self.context)) == CONTEXT_SHA
        assert not proof.nodes and not proof.active_indices and not proof.global_nodes
        assert origin_result['application']['query_sha256'] == prepared['query_sha256']
        assert origin_result['type_check']['assertions'] == 48
        assert len(origin_result['application']['nodes']) == 46
        assert origin_result['prefix']['bounded_source_context'] == self.context
        assert raw_data['nf_prefix']['prefix']['inherited_prefix_source_context'] == self.context
        assert raw_data['endpoint_application']['application']['bounded_source_context'] == self.context
        assert raw_data['dot_prefix']['inherited_continuity_prefix']['inherited_prefix_source_context'] == self.context
        self.imports, self.lookup_ledger = {}, []

    def part(self, parent, position):
        return self.steps.part(self.proof, parent, position)

    def define(self, name, args, bounds=()):
        return self.steps.definition(self.proof, self.language, self.api, name, args, bounds)

    def unfold(self, node, name, args, bounds=()):
        d = self.define(name, args, bounds)
        eq = self.proof.nodes[d]['formula']
        return self.proof.rewrite(node, d, eq[1], eq[2])

    def import_fixed(self, name, formula, support, provenance):
        assert name not in self.imports
        node = self.proof.add('checked-fixed-component-context-application', deepcopy(formula),
            support=sorted(support), component=name, accepted_provenance=deepcopy(provenance),
            exact_bounded_source_context_sha256=CONTEXT_SHA)
        self.imports[name] = node
        return node

    def instantiate(self, parent, mapping, bounds=()):
        f = self.proof.nodes[parent]['formula']
        assert f[0] == 'forall' and set(mapping) == {v[0] for v in f[1]}
        # Every use keeps the entire domain/guard. Range is discharged by MP,
        # not by registering a historical term as an INDEX or deleting a bound.
        value = self.SUB(f[2], mapping)
        return self.proof.add('fixed-typed-forall-elimination-preserving-domain', value,
            [parent, *bounds], original_quantified_formula=deepcopy(f), uniform_mapping=deepcopy(mapping))

    def bounded_instance(self, parent, index, lower, upper, parameters=None):
        f = self.proof.nodes[parent]['formula']
        assert f[0] == 'forall'
        parameters = parameters or {}
        binder = f[1][-1][0]
        mapping = {binder: index, **parameters}
        rule = self.instantiate(parent, mapping, [lower, upper])
        assert self.proof.nodes[lower]['formula'] == ['<=', '1', index]
        assert self.proof.nodes[upper]['formula'] == ['<=', index, 'N']
        antecedent = self.proof.conjunction([lower, upper])
        assert self.proof.nodes[rule]['formula'][1] == self.proof.nodes[antecedent]['formula']
        return self.proof.mp(rule, antecedent)

    def upper_from_strict(self, past, current, strict, upper):
        binding = self.data['math_binding']
        assert self.proof.nodes[strict]['formula'] == ['<', past, current]
        assert self.proof.nodes[upper]['formula'] == ['<=', current, 'N']
        mapping = {'past': past, 'current': current, 'bound': 'N'}
        rule = self.proof.add('qualified-source-schema-uniform-instance',
            self.SUB(binding['goal'], mapping), original_query_goal=deepcopy(binding['goal']),
            uniform_mapping=mapping,
            original_query_sha256='c7f7abeaf6645e15351877c73c5dfc419e33e7cb1742af514306391074c56a84',
            accepted_math_seal_sha256='4cfab125330467e05d22190f10af0c8033ec6bcedb559ae3f36b810f24dc9954')
        return self.proof.mp(rule, self.proof.conjunction([strict, upper]))

    def whole_order_rule(self, at, lower, upper):
        c, h, s = self.c, self.c('NF', at), self.c('A', at)
        payload = c('nf-rms-start-payload', s, h)
        # The order clause is independent of this arbitrary empty array; use
        # the already defined current NF data, not a future empty-array lookup.
        empty = c('nf-data', h)
        mapping = {'history': c('nf-rms-origin-observer', h),
            'event': c('nf-effective-rms-start-event', s), 'event-payload': payload,
            'next-valid': c('nf-active', c('nf-next', s, h, empty)),
            'observation': at, 'initial-payload': c('stampedRmsStart', '0', ['_', 'bv0', '12']),
            's': s, 'h': h, 'empty-nf': empty,
            'stamped-origin-I': 'actual-RMS-origin-I', 'stamped-event-at': 'actual-RMS-event-at'}
        whole = self.proof.add('qualified-source-schema-uniform-instance',
            self.SUB(self.prepared['goal'], mapping), [lower, upper],
            original_query_goal=deepcopy(self.prepared['goal']), uniform_mapping=mapping,
            original_query_sha256=self.prepared['query_sha256'],
            accepted_result_review_sha256=self.prepared['result_review_sha256'],
            actual_event_function_definition=self.prepared['events']['RMS'],
            actual_origin_definition=self.prepared['invariants']['RMS'])
        return self.part(whole, 9)

    def install_capture_parents(self, provenance):
        p, c = self.proof, self.c
        ep = self.data['endpoint_application']['application']
        self.endpoint = self.import_fixed('sealed-current-frame-endpoint', ep['literal_global_formula'],
            self.context, provenance['endpoint'])
        nf = self.data['nf_prefix']['prefix']
        nfi = self.import_fixed('sealed-bounded-NF-invariant',
            ['=>', ['<=', '1', 'N'], nf['bounded_formula']], nf['root_support'], provenance['NF'])
        self.nfi = nfi
        self.origin_imports = {}
        for which in ['STEP', 'RMS']:
            family = self.origins['prefix']['families'][which]
            self.origin_imports[which] = self.import_fixed('checked-original-' + which + '-origin',
                ['=>', ['<=', '1', 'N'], family['bounded_formula']], family['root_support'], provenance['origins'])

    def endpoint_at(self, at, word, lower, case):
        rule = self.instantiate(self.endpoint, {'endpoint-watch': word, 'i_endpoint': at}, [lower, case])
        rule = self.proof.mp(rule, lower)
        return self.proof.mp(rule, case)

    def construct_capture(self):
        p, c = self.proof, self.c
        lower_i = p.open_index(CAPTURE_FAMILY, I)
        view = c('fj-source-view', c('A', I), c('COLUMNS', I))
        guard = ['and', c('fv-live', view), c('fv-head', view),
                 c('f-active', c('FRAME', I)), c('f-complete', c('FRAME', I))]
        case = p.assumption('CASE:live-frame-original-events', ['and', ['<=', '1', 'N'], ['<=', I, 'N'], guard])
        n_domain, upper_i = self.part(case, 1), self.part(case, 2)
        point = self.endpoint_at(I, ['_', 'bv0', '8'], lower_i, case)
        scalar = self.part(point, 1)
        facts = [self.part(scalar, x) for x in range(1, 10)]
        lower_k, strict_k_i, upper_k, identity = facts[1], facts[2], facts[7], facts[8]
        k, saved = c('endpoint-capture-index', I), c('endpoint-saved-NF', I)
        assert p.nodes[identity]['formula'] == ['=', saved, c('NF', k)]
        assert p.nodes[lower_k]['formula'] == ['<=', '1', k]
        assert p.nodes[upper_k]['formula'] == ['<=', k, 'N']
        accepted = p.rewrite(facts[4], identity, saved, c('NF', k))
        accepted = self.unfold(accepted, 'fj-accepted-nf', [c('NF', k)], [lower_k, upper_k])
        active, step_valid, retained_parent = (self.part(accepted, x) for x in [1, 2, 4])
        stamp_facts, clocks = {}, {}
        for which, valid in [('STEP', step_valid), ('RMS', active)]:
            global_origin = p.mp(self.origin_imports[which], n_domain)
            origin = self.bounded_instance(global_origin, k, lower_k, upper_k)
            observer = c('nf-' + which.lower() + '-origin-observer', c('NF', k))
            origin = self.unfold(origin, 'actual-' + which + '-origin-I', [observer, k], [lower_k, upper_k])
            origin = self.unfold(origin, 'nf-' + which.lower() + '-origin-observer', [c('NF', k)], [lower_k, upper_k])
            origin = self.steps.normalize_selectors(p, self.language, origin)
            clocks[which] = self.part(origin, 1)
            guarded = self.part(origin, 2)
            actual = p.mp(guarded, valid)
            stamp_facts[which] = [self.part(actual, x) for x in range(1, 5)]
        raw_p = c('+', c('nf-sid', c('NF', k)), '1')
        raw_r = c('+', c('nf-uid', c('NF', k)), '1')
        lp, p_before_k, step_event, _ = stamp_facts['STEP']
        lr, r_before_k, rms_event, rms_payload = stamp_facts['RMS']
        assert p.nodes[lp]['formula'] == ['<=', '1', raw_p]
        assert p.nodes[lr]['formula'] == ['<=', '1', raw_r]
        up = self.upper_from_strict(raw_p, k, p_before_k, upper_k)
        ur = self.upper_from_strict(raw_r, k, r_before_k, upper_k)
        # Only now expose the actual historical source event functions.
        actual_step = self.unfold(step_event, 'actual-STEP-event-at', [raw_p], [lp, up])
        actual_step = self.steps.normalize_selectors(p, self.language, actual_step)
        actual_rms = self.unfold(rms_event, 'actual-RMS-event-at', [raw_r], [lr, ur])
        actual_rms = self.steps.normalize_selectors(p, self.language, actual_rms)
        actual_payload = self.unfold(rms_payload, 'actual-RMS-event-at', [raw_r], [lr, ur])
        actual_payload = self.steps.normalize_selectors(p, self.language, actual_payload)
        actual_payload = self.unfold(actual_payload, 'nf-rms-start-payload',
            [c('A', raw_r), c('NF', raw_r)], [lr, ur])
        assert p.nodes[actual_payload]['formula'][1][0] == 'stampedRmsStart'
        assert p.nodes[actual_payload]['formula'][2][0] == 'stampedRmsStart'
        # Both sides are the declared RMS constructor, never stampedUnit.
        selected_payload = []
        for selector in ['sp-parent', 'sp-prefix']:
            eq = p.nodes[actual_payload]['formula']
            lhs = self.steps.selector(p, self.language, [selector, eq[1]])
            lhs = p.rewrite(lhs, actual_payload, eq[1], eq[2])
            rhs = self.steps.selector(p, self.language, [selector, eq[2]])
            lhs = p.rewrite(lhs, rhs, p.nodes[rhs]['formula'][1], p.nodes[rhs]['formula'][2])
            # lhs is value_at_r = retained_value at k (selector symmetry).
            value = p.nodes[lhs]['formula']
            lhs = p.add('typed-equality-symmetry', ['=', value[2], value[1]], [lhs])
            selected_payload.append(lhs)
        nfi_global = p.mp(self.nfi, n_domain)
        nf_I = self.bounded_instance(nfi_global, k, lower_k, upper_k, {'nf-watch': ['_', 'bv0', '8']})
        nf_I = self.unfold(nf_I, 'nf-I', [c('A', k), c('NF', k), ['_', 'bv0', '8']], [lower_k, upper_k])
        time = self.part(nf_I, 1)
        time_def = self.define('nf-origin-time-I', [c('NF', k)], [lower_k, upper_k])
        time = p.rewrite(time, time_def, p.nodes[time_def]['formula'][2], p.nodes[time_def]['formula'][1])
        order_rule = self.whole_order_rule(k, lower_k, upper_k)
        order = p.mp(order_rule, p.conjunction([lower_k, time, active, clocks['STEP']]))
        p_before_r = self.part(order, 2)
        assert p.nodes[p_before_r]['formula'] == ['<', raw_p, raw_r]
        expanded_step = self.unfold(actual_step, 'nf-effective-step-event', [c('A', raw_p)], [lp, up])
        expanded_rms = self.unfold(actual_rms, 'nf-effective-rms-start-event', [c('A', raw_r)], [lr, ur])
        origin_scalar = p.conjunction([lp, lr, p_before_r, r_before_k, up, ur,
            actual_step, actual_rms, retained_parent, *selected_payload, expanded_step, expanded_rms])
        # NF(k) is rewritten to the single already bound saved record, then
        # the two word-independent observation helpers are folded.
        origin_scalar = p.rewrite(origin_scalar, identity, c('NF', k), saved)
        p_def, r_def = self.define(PSTEP, [I]), self.define(PRMS, [I])
        for d in [p_def, r_def]:
            eq = p.nodes[d]['formula']
            origin_scalar = p.rewrite(origin_scalar, d, eq[2], eq[1])
        folded_lp, folded_lr, folded_up, folded_ur = [self.part(origin_scalar, n) for n in [1, 2, 5, 6]]
        step_alias = p.rewrite(p_def, identity, saved, c('NF', k))
        rms_alias = p.rewrite(r_def, identity, saved, c('NF', k))
        assert p.nodes[step_alias]['formula'] == ['=', c(PSTEP, I), raw_p]
        assert p.nodes[rms_alias]['formula'] == ['=', c(PRMS, I), raw_r]
        scalar_end = len(p.nodes) - 1
        self.lookup_ledger += [
            {'kind': 'saved-NF', 'index': k, 'lower_parent': lower_k, 'upper_parent': upper_k,
             'accesses': [c('A', k), c('NF', k)], 'source_edge_requested': False},
            {'kind': 'STEP-event', 'index': raw_p, 'lower_parent': lp, 'upper_parent': up,
             'accesses': [c('A', raw_p)], 'source_edge_requested': False,
             'folded_alias': {'term': c(PSTEP, I), 'equality_parent': step_alias,
                 'lower_parent': folded_lp, 'upper_parent': folded_up,
                 'accesses': [c('A', c(PSTEP, I))]}},
            {'kind': 'RMS-event-and-payload', 'index': raw_r, 'lower_parent': lr, 'upper_parent': ur,
             'accesses': [c('A', raw_r), c('NF', raw_r)], 'source_edge_requested': False,
             'folded_alias': {'term': c(PRMS, I), 'equality_parent': rms_alias,
                 'lower_parent': folded_lr, 'upper_parent': folded_ur,
                 'accesses': [c('A', c(PRMS, I)), c('NF', c(PRMS, I))]}}]
        self.language.decls[W] = ['declare-const', W, ['_', 'BitVec', '8']]
        all_words = self.endpoint_at(I, W, lower_i, case)
        word = self.part(all_words, 2)
        result = p.conjunction([scalar, origin_scalar, word])
        result = p.implication(case, result)
        template = self.SUB(p.nodes[result]['formula'], {I: '@index'})
        final = p.globalize(CAPTURE_FAMILY, template, result, I, [[W, ['_', 'BitVec', '8']]])
        self.capture_global = final
        return {'global_node': final, 'literal_global_formula': p.nodes[final]['formula'],
            'scalar_nodes_end_before_word': scalar_end, 'word_parameter': W,
            'fixed_observation_helpers': helper_definitions(),
            'lookup_ledger': deepcopy(self.lookup_ledger),
            'current_endpoint_frame_guard': guard, 'source_context_sha256': CONTEXT_SHA}

    def or_intro(self, parent, clauses):
        assert self.proof.nodes[parent]['formula'] in clauses
        return self.proof.add('disjunction-introduction', ['or', *deepcopy(clauses)], [parent],
                              selected_disjunct=clauses.index(self.proof.nodes[parent]['formula']) + 1)

    def source_H_at(self, at, lower, upper):
        p = self.proof
        assert p.nodes[lower]['formula'] == ['<=', '1', at]
        assert p.nodes[upper]['formula'] == ['<=', at, 'N']
        # A literal threshold weakening (0 <= 1), then universal elimination
        # of the exact 0..N point clause from the inherited bounded context.
        lower_zero = p.add('literal-integer-threshold-weakening', ['<=', '0', at], [lower],
                           weaker_threshold='0', stronger_threshold='1', checked_numerals=[0, 1])
        assert 0 <= 1
        source = self.context['Gamma:actual-composed-source']['formal_native_consequences'][2]
        assert source[0] == 'forall' and source[1] == [['n_source', 'Int']]
        imported = p.add('actual-bounded-source-context-consequence', deepcopy(source),
            support=['Gamma:actual-composed-source'], exact_bounded_context_sha256=CONTEXT_SHA,
            literal_context_field='formal_native_consequences[2]')
        instance = self.instantiate(imported, {'n_source': at}, [lower_zero, upper])
        actual = p.mp(instance, p.conjunction([lower_zero, upper]))
        return self.part(actual, 1)

    def view_field_alias(self, at, field, lower, upper):
        definition = self.define('fj-source-view', [self.c('A', at), self.c('COLUMNS', at)], [lower, upper])
        eq = self.proof.nodes[definition]['formula']
        selected = self.steps.selector(self.proof, self.language, ['fv-' + field, eq[2]])
        return self.proof.rewrite(selected, definition, eq[2], eq[1])

    def construct_row(self, provenance):
        p, c = self.proof, self.c
        domain = ['<=', '1', 'N']
        dot_prefix = self.data['dot_prefix']
        dot = self.import_fixed('sealed-completed-saved-frame-model-dot',
            ['=>', domain, dot_prefix['bounded_consequences']['completed-saved-frame-model-dot']],
            self.context, provenance['dot'])
        control = self.import_fixed('sealed-bounded-control-for-original-row',
            ['=>', domain, dot_prefix['earlier_bounded_consequences']['control']], self.context, provenance['dot'])
        frame = self.import_fixed('sealed-bounded-frame-for-original-row',
            ['=>', domain, dot_prefix['earlier_bounded_consequences']['actual-frame']], self.context, provenance['dot'])
        lower_n = p.open_index(ROW_FAMILY, J)
        dot_guard = self.SUB(dot_prefix['completed_row_conclusion'][2][2][1], {'n_prefix': J})
        case = p.assumption('CASE:completed-row12-original-events', ['and', domain, ['<=', J, 'N'], dot_guard])
        n_domain, upper_n, actual_done = [self.part(case, i) for i in [1, 2, 3]]
        dot_at = self.bounded_instance(p.mp(dot, n_domain), J, lower_n, upper_n)
        completed = p.mp(dot_at, actual_done)
        historical = self.part(completed, 3)
        lower_j, j_before_n = self.part(historical, 1), self.part(historical, 2)
        j = c('FRAMEORIGIN', J)
        upper_j = self.upper_from_strict(j, J, j_before_n, upper_n)
        historical = self.unfold(historical, 'row-frame-origin-record-at', [j], [lower_j, upper_j])
        source_args = [c('row-source-view', c('A', j), c('COLUMNS', j)), c('ROW', j), c('FRAME', j)]
        historical = self.unfold(historical, 'row-frame-origin-view-record', source_args, [lower_j, upper_j])
        historical = self.steps.normalize_selectors(p, self.language, historical)
        capture, complete_frame = self.part(historical, 3), self.part(historical, 4)
        snapshot_array = self.part(historical, 9)
        assert p.nodes[snapshot_array]['formula'] == ['=', c('srf-data', c('ROWFRAME', J)), c('f-data', c('FRAME', j))]
        source_H = self.source_H_at(j, lower_j, upper_j)
        control_at = self.bounded_instance(p.mp(control, n_domain), j, lower_j, upper_j, {'watch': '0'})
        phase = self.part(control_at, 8)
        binding = self.data['row_guard_binding']
        mapping = {'a': c('A', j), 'columns': c('COLUMNS', j), 'row': c('ROW', j), 'header': c('HEADER', j)}
        whole_guard = p.add('qualified-source-schema-uniform-instance', self.SUB(binding['combined_goal'], mapping),
            [lower_j, upper_j], original_query_goal=deepcopy(binding['combined_goal']), uniform_mapping=mapping,
            original_query_sha256='6c28a54981eefd6e1746f6be37b96d7debdd8a99e7ca4bf5ad66687c6c97ccde',
            accepted_row_guard_seal_sha256='32e903f208b30e96fe30de610b89ecc5d54473645c3a0946fe7fc1b67ac02154',
            accepted_raw_result_adjudication=self.data['row_guard_result'])
        guard_rule = self.part(whole_guard, 3)
        guard = p.mp(guard_rule, p.conjunction([source_H, phase, capture]))
        live, engine_state, head_job = [self.part(guard, i) for i in [1, 2, 3]]
        # Use only bounded STATE providers at j; the old accepted-row-frame
        # consequence is an edge family and is deliberately not instantiated.
        phase_body = self.unfold(phase, 'selected-row-phase-I',
            [c('A', j), c('COLUMNS', j), c('ROW', j), c('HEADER', j)], [lower_j, upper_j])
        active_engine = self.part(phase_body, 3)
        engine_choices = p.nodes[active_engine]['formula'][1][2]
        assert engine_choices[0] == 'or'
        engine_active = self.or_intro(engine_state, engine_choices[1:])
        projection_active = p.mp(active_engine, p.conjunction([live, engine_active]))
        projection_state = self.part(projection_active, 1)
        frame_at = self.bounded_instance(p.mp(frame, n_domain), j, lower_j, upper_j,
                                         {'frame-watch': ['_', 'bv0', '10']})
        frame_at = self.unfold(frame_at, 'frame-I',
            [c('A', j), c('COLUMNS', j), c('c-base', c('CAPTURE', j)), c('FRAME', j), ['_', 'bv0', '10']],
            [lower_j, upper_j])
        frame_live = p.mp(self.part(frame_at, 2), live)
        frame_active_equality = self.part(frame_live, 1)
        choices = p.nodes[frame_active_equality]['formula'][2]
        assert choices[0] == 'or'
        active = self.or_intro(projection_state, choices[1:])
        active = p.rewrite(active, frame_active_equality, choices, c('f-active', c('FRAME', j)))
        view_live = self.view_field_alias(j, 'live', lower_j, upper_j)
        view_head = self.view_field_alias(j, 'head', lower_j, upper_j)
        live_view = p.rewrite(live, view_live, p.nodes[view_live]['formula'][2], p.nodes[view_live]['formula'][1])
        head_view = p.rewrite(head_job, view_head, p.nodes[view_head]['formula'][2], p.nodes[view_head]['formula'][1])
        actual_frame_guard = p.conjunction([live_view, head_view, active, complete_frame])
        capture_case = p.conjunction([n_domain, upper_j, actual_frame_guard])
        def capture_at(word):
            rule = self.instantiate(self.capture_global, {W: word, I: j}, [lower_j, upper_j])
            return p.mp(p.mp(rule, lower_j), capture_case)
        fixed_capture = capture_at(['_', 'bv0', '8'])
        endpoint_scalar, origin_scalar = self.part(fixed_capture, 1), self.part(fixed_capture, 2)
        k_lower, k_upper = self.part(endpoint_scalar, 2), self.part(endpoint_scalar, 8)
        p_lower, r_lower, p_upper, r_upper = [self.part(origin_scalar, x) for x in [1, 2, 5, 6]]
        self.lookup_ledger.append({'kind': 'original-row-bounded-capture-component-instance',
            'source_component_parent': self.capture_global, 'actual_instance_parent': fixed_capture,
            'frame_observation': j, 'frame_lower_parent': lower_j, 'frame_upper_parent': upper_j,
            'derived_witness_ranges': [
                {'term': c('endpoint-capture-index', j), 'lower_parent': k_lower, 'upper_parent': k_upper},
                {'term': c(PSTEP, j), 'lower_parent': p_lower, 'upper_parent': p_upper},
                {'term': c(PRMS, j), 'lower_parent': r_lower, 'upper_parent': r_upper}],
            'source_edge_requested': False, 'new_historical_INDEX': False})
        scalar_end = len(p.nodes) - 1
        self.language.decls[RW] = ['declare-const', RW, ['_', 'BitVec', '8']]
        words = capture_at(RW)
        word = self.part(words, 3)
        word = p.rewrite(word, snapshot_array, p.nodes[snapshot_array]['formula'][2], p.nodes[snapshot_array]['formula'][1])
        claim = p.conjunction([completed, historical, endpoint_scalar, origin_scalar, word])
        claim = p.implication(case, claim)
        template = self.SUB(p.nodes[claim]['formula'], {J: '@index'})
        final = p.globalize(ROW_FAMILY, template, claim, J, [[RW, ['_', 'BitVec', '8']]])
        self.lookup_ledger.append({'kind': 'original-row-capture', 'index': j,
            'lower_parent': lower_j, 'upper_parent': upper_j, 'strict_past_parent': j_before_n,
            'accesses': [c(symbol, j) for symbol in ['A', 'C', 'COLUMNS', 'ROW', 'HEADER',
                'GROUP', 'LAYOUT', 'CAPTURE', 'FRAME']],
            'source_edge_requested': False, 'old_edge_family_instantiated': False})
        return {'global_node': final, 'literal_global_formula': p.nodes[final]['formula'],
            'scalar_nodes_end_before_word': scalar_end, 'word_parameter': RW,
            'one_original_row_capture': j, 'canonical_sum_kept_literal': True,
            'new_array_lifting_rule_used': False, 'lookup_ledger': deepcopy(self.lookup_ledger)}


def construct_composition(proof, language, exports, data, origins, prepared, steps, provenance):
    app = FixedApplication(proof, language, exports, data, origins, prepared, steps)
    language.add(helper_definitions())
    app.install_capture_parents(provenance)
    capture = app.construct_capture()
    row = app.construct_row(provenance)
    assert not proof.active_indices and proof.root_context == app.context
    assert len(proof.nodes) + 46 <= 768
    for i, node in enumerate(proof.nodes):
        assert node['id'] == i
        support = set(node['introduced_support'])
        for parent in node['parents']:
            assert 0 <= parent < i
            support.update(proof.nodes[parent]['support'])
        assert support - set(node.get('discharged_support', [])) == set(node['support'])
    return deepcopy({'kind': 'same-c070-original-STEP-RMS-to-completed-row12-composition',
        'nodes': proof.nodes, 'global_nodes': proof.global_nodes, 'root_context': app.context,
        'capture_application': capture, 'row_application': row, 'new_native_jobs': 0,
        'new_inductions_in_composition': 0, 'current_and_historical_lookup_bounds_derived': True,
        'original_STEP_RMS_events_and_row12_join_constructed': True,
        'numerical_RMS_proved': False, 'exponent_scaling_proved': False,
        'whole_device_theorem': False})

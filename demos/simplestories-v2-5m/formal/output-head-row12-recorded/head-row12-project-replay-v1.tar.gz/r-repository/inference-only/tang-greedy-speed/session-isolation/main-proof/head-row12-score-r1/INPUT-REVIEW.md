# Independent input review: four native exponent leaves

**Decision: ACCEPTED for exact input freezing, pure preflight and then the four
listed native jobs under the reviewed runner.** This review grants no solver
result, source-proof application, head-owner invariant, saved-R0 join or score/
selector theorem. No constructor, repository preparation/check function,
engine, build, probe, simulation or additional agent ran during this review.

## Exact reviewed inputs

- `prepare_exponent.py`: `7eb5e7b8917d57e3d5e14a78620d922276901e6d6623a913630e4c80a7ba6cc4`
- `run_exponent.py`: `d6628e5dcd5f28ec2215ead5b6eadb900ccfc45ae81817b03298c2a6e741164e`
- `SOURCE-BINDING.json`: `15a555d4e391e2d9c4d90f790321d6bf1fcd495ed5f622043b270ee7489c11b5`
- `QUERY-PLAN.json`: `41f9750af14f50e97c0f3de6f70a4552e691a8afd1c4c9483017ceb7daa56bc8`
- `TYPE-CHECK.json`: `28648c34eaa994c23eff4f6c80190e72f632f6d7b54640f4df9d7d900e8da337`
- `READ-PINS.json`: `3a35739aed1ee16e13f4c1cd32f6d181ecd244567416211ae8a64e4109492190`
- `EXTERNAL-PINS.json`: `9ae0e9f065a04544f8700f183b1994fe2cdfb02e0df0125db6823d951626fbf3`
- `TOOL-PIN.json`: `f823eb9803a67ff0a59d4f876b947b7b1d4ca7383c0112bf953861f6718f95f9`

The unchanged plan/review are `cde11165039612eb5d842dc4d347dfef867308934edcecd4c533fbc74ca34443`
and `9dc208ea6431d74aaf4e5c828766b3bafd3b545b4e9e7e69a6ba82d5f5b15125`.
The required local freeze has exactly 15 entries, including this review and
the four queries. All 36 external pins currently match actual regular,
nonsymlink files. The 31 preparation reads are covered by those external pins
plus the locally pinned preparer. The runner requires a hash-specific accepted
freeze before either preflight or native execution.

| Native job, in order | Exact query SHA256 |
| --- | --- |
| head-start-current-RMS-exponent | `1a0d92d7434b279caf80ada1b99e098aca904994784c8b9f42cb47515c8c0008` |
| head-start-register-capture | `8a09dfc027bf1840be1affc1cf180377882eb3e5112d3f98e775fc47a12cde24` |
| job7-admission-exponent-cone | `5d6c69b3ebce28bc35a75dc43fb8320e4a6c4763defdc39b4c5fa2ebe56311df` |
| head-and-job-exponent-hold | `cf0424bf6b2582936d0f6b75acebc572b1b6cdbe995c4ed16137344b222cec05` |

## Native source and formula inspection

I independently parsed the saved query bytes without calling repository
functions. Every query retains the exact 4,336,780-byte native prefix at
`c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54`,
including all 452 T conjuncts. Its complete tail is literally the four NF
helpers, four event helpers, declarations, one negated binding goal, the stated
single check tactic and exit. No source assertion, health promise, desired
numerical answer or additional solver command is hidden in that tail.

All 35 recorded getters match the native definitions. All four NF helpers also
match the accepted R3 NF typing theory at
`130e514543eadb5ef3137989ca85b918c69463fd15bac808872fafb1b150340d`
literally. The saved type records bind each exact query to one assertion, one
check and 12,087 symbols. I inspected the pinned parser/typechecker and the
preparer's helper-load restoration; this independent review did not invoke
their functions or treat typing as validity.

The compile record is `connected-SOURCES.json` at
`8d0d406f494439ba7318d996389c6a5b830a8c30d2ee3dfc96aac9f66b25278c`.
Its nine source files, c070 output and `compile.ys` all match their pins. The
source profile explicitly defines SYNTHESIS, removes formal instrumentation,
and uses the original flatten/async2sync/dffunmap/memory_collect flow. Thus the
simulation-only X-priority branch is not silently omitted from this profile.
No source or native circuit was recompiled or modified.

The actual core shell-to-layer exponent wire, layer sequence/collision/stage
head-start gating and datapath-to-J exponent mux remain native H equations.
The instance retains the source ADDR_W, clock, reset, CLEAR, model-lock and
upstream-fault connections. No standalone child state is identified with this
parent state and no free private exponent replaces its source producer.

The four goals match the intended narrow obligations:

1. Actual effective D capture is reset high, no D CLEAR, old D fault absent,
   E_IDLE and the native `head_start_accept`. H supplies the complete actual
   ready/valid/caller gates. With the original nf-I premise, the conclusion
   derives live shell ST_HEAD_START=16, active/accepted NF with count256 and
   STEP-parent agreement, shell exponent=NF.exp and D input exponent=NF.exp.
   These facts are conclusions, not assumed correct private inputs.
2. D capture retains H at both endpoints and complete T. Its next visible
   exponent is successor-D-reset ? pre-edge NF.exp : zero. Native getter
   #1359 is literally reset #202 ? raw DFF #24 : zero, and T updates that raw
   target. A trailing newly detected fault may override D phase without
   undoing this exponent write; no future-health condition excludes it.
3. Effective job7 admission uses the actual incoming descriptor and all
   earlier reset/fault/CLEAR/protocol priorities. IDLE0, LOAD1, GROUP_RUN3,
   DRAIN5 and FAIL7 match the source. The combinational conclusion derives
   D E_HEAD, incoming layer7 and J input exponent=D retained exponent. The
   separate full-T conclusion gives successor-J-reset ? old D exponent : zero.
   Getter #2005 has the same #202 reset mask over raw DFF #161. Neither
   `start_transfer` alone nor a retained stored job7 is used as birth.
4. D hold excludes its actual capture and current reset/CLEAR updates. J hold
   excludes every effective valid descriptor capture, including nonhead jobs;
   the helper is the exact job-capture condition with only the job7 test
   removed. J CLEAR/fault can retain exponent payload, whereas D CLEAR zeros
   it. Both hold conclusions preserve successor reset masks and arbitrary
   current faults. They establish physical data retention, not live use or
   publication authority.

The NF constant is arbitrary under its literal invariant premise. A later
typed application must substitute the independently qualified actual NF at
the same observation/domain. These conditional leaves do not themselves prove
reset-founded NF ownership, a historical head-start occurrence, equality to
saved R0, or the missing pre-J-birth/protected-field history argument.

## Runner and launch boundary

The runner requires isolated Python3.12 with site and bytecode disabled,
the exact 15-file local freeze, this review's hash-specific acceptance, all
external/read pins and the complete compiled-source record. Its pure preflight
reassembles and compares complete query bytes and structured binding/plan/type/
read-pin records before any native run. The preparer has no import-time
construction or engine call;
its file-writing main branch is not used by preflight.

The binary is the pinned Z3 at
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`,
also matching the existing tool record. The runner uses one locked worker,
four serial calls to the unchanged accepted mode guard, internal
`-memory:4096`, 4 GiB sampled owned RSS/physical footprint and actual normal
Darwin pressure. The guard disables elapsed/CPU kills and fixed disk/free-RAM
floors. Original guard/probe hashes and successful cleanup receipts are pinned;
no new probe or simulation reservation is claimed.

Intent is saved before the new runs parent is created. Existing intent,
results or runs cause refusal, and each run directory is single-use. All pins
are checked before and after each job. A match requires native exit0, no
resource stop or monitor errors, and the exact UNSAT-plus-one-statistics
protocol; extra/missing/error/SAT/unknown output is rejected. Raw logs,
receipts and monitor records remain available. The stored monitor/receipt
comparison canonicalizes JSON key types, avoiding the prior unrelated PID-key
wrapper mismatch. A guard exception records uncertain owned-child state
without claiming cleanup or success.

The first mismatch stops subsequent jobs. This four-leaf gate authorizes no
SAT diagnostic, retry, repair, new owner induction or continuation job. Its
four attempts count against the eight-job Phase A total. Result acceptance
still requires independent raw protocol/resource/pin review, then source-bound
typed application and closed replay for whatever component is actually
delivered. Head owner/NF(k), read/metadata/postscale, actual selector admission,
upstream numerical RMS and whole-device claims remain false/unproved here.

"""Read-only ordinary original ROW/E exponent prefix application."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
B = HERE.parent
C = B.parent
M = C.parent
P = M / 'head-mode-ownership-r1'
L = P / 'frame-join-pilot/certificate-trace-application-r2'
SCOPE = 'original-prefix-physical-row-E-exponent-continuity'
INPUTS = {'run_application.py', 'row_application.py', 'row_prefix.py', 'PLAN.md', 'INPUT-REVIEW.md', 'RAW-INPUTS.json'}
RAW = {'binding', 'plan', 'results', 'review', 'dot_seal', 'dot_application', 'dot_prefix', 'dot_typing'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
FAILURE = None


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def construct(metadata_only=False):
    global FAILURE
    FAILURE = None
    proof, audit = None, None
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        assert type(metadata_only) is bool and sys.version_info[:2] == (3, 12)
        assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
        audit_path = L / 'check_nf_component.py'
        audit = load('_row_exp_readonly_audit', audit_path, '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33')
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'ACCEPTED-INPUTS.json'
        env = json.loads(env_path.read_bytes())
        assert env['accepted'] is True and env['scope'] == SCOPE and set(env['files']) == INPUTS
        for name, value in env['files'].items():
            path = HERE / name
            assert path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == value
        manifest = json.loads((HERE / 'RAW-INPUTS.json').read_bytes())
        assert set(manifest) == {'paths_relative_to_main_proof', 'pins', 'steps_relative_to_main_proof', 'steps_sha256'}
        assert set(manifest['paths_relative_to_main_proof']) == set(manifest['pins']) == RAW
        assert manifest['pins']['review'] == '48f708e451b26593482ddb9c16c2355583f5b2e0b5e2f889e40c77aeddb2e161'
        raw = {}
        for name, relative in manifest['paths_relative_to_main_proof'].items():
            path = (M / relative).resolve()
            assert path.is_relative_to(M) and not path.is_symlink()
            raw[name] = path.read_bytes()
            assert digest(raw[name]) == manifest['pins'][name]
        data = {name: json.loads(value) for name, value in raw.items() if name not in {'review', 'dot_typing'}}
        exports = load('_row_exp_exports', L / 'accepted_exports_r3.py', '2bc78867ebf370b0cf6f32c6ddf7e15e1f129f49db1764a7b88acc7b1d9bb082').load_parent_exports()
        api = exports['apis']
        module = load('_row_exp_application', HERE / 'row_application.py', env['files']['row_application.py'])
        checker = load('_row_exp_prefix', HERE / 'row_prefix.py', env['files']['row_prefix.py'])
        steps = load('_row_exp_steps', M / manifest['steps_relative_to_main_proof'], manifest['steps_sha256'])
        heads = {'declare-sort', 'declare-fun', 'declare-datatypes', 'declare-datatype', 'declare-const', 'define-fun'}
        forms = [f for f, _, _ in api['parse_spans'](raw['dot_typing']) if f[0] in heads]
        names = {f[1] for f in forms if f[0] in {'declare-fun', 'define-fun', 'declare-const'}}
        for key in ['future_fixed_actual_function_definition', 'future_actual_invariant']:
            definition = data['binding'][key]
            assert definition[1] not in names
            forms.append(definition)
            names.add(definition[1])
        if 'N' not in names:
            forms.append(['declare-const', 'N', 'Int'])
        prepared = module.prepare_metadata(exports, data, manifest['pins'], forms)
        if metadata_only:
            audit.HELPERS.update({Path(__file__).resolve(), audit_path})
            assert audit.HELPERS <= set(audit.READS)
            for path, value in list(audit.READS.items()):
                assert digest(path.read_bytes()) == value
            return {'metadata_only_passed': True, 'proof_initializers_called': 0, 'proof_nodes': 0,
                'input_envelope_sha256': digest(env_path.read_bytes()), 'new_native_jobs': 0,
                'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
                'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)}}, None
        proof = api['ValueProof'].__new__(api['ValueProof'])
        api['Proof'].__init__(proof, {})
        for name, original in proof.root_context.items():
            assert all(exports['context'][name][key] == value for key, value in original.items())
        proof.root_context = copy.deepcopy(exports['context'])
        language = api['SourceLanguage']()
        language.add(forms)
        for f in forms:
            if f[0] == 'declare-const':
                assert f[1] not in language.defs and f[1] not in language.decls
                language.decls[f[1]] = copy.deepcopy(f)
        assert module.INDEX not in language.defs and module.INDEX not in language.decls
        index_decl = ['declare-const', module.INDEX, 'Int']
        language.decls[module.INDEX] = index_decl
        app = module.construct(proof, language, exports, prepared, steps)
        prefix = checker.validate(app, exports, prepared, module)
        typing_forms = [*forms, index_decl, *[['assert', n['formula']] for n in proof.nodes], ['assert', prefix['bounded_formula']],
            ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
        typing = ('\n'.join(map(api['smt'], typing_forms)) + '\n').encode()
        path = P / 'source_typecheck.py'
        type_raw = path.read_bytes()
        assert digest(type_raw) == '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809'
        functions = [f for f in ast.parse(type_raw).body if isinstance(f, ast.FunctionDef) and f.name in ['sort', 'check']]
        namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), 'exec'), namespace)
        typed = namespace['check'](typing)
        assert typed['assertions'] == len(proof.nodes) + 1
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        for path, value in list(audit.READS.items()):
            assert digest(path.read_bytes()) == value
        return {'application': app, 'prefix': prefix, 'type_check': typed, 'typing_sha256': digest(typing),
            'input_envelope_sha256': digest(env_path.read_bytes()), 'new_native_jobs': 0, 'old_parent_proof_reconstructions_called': 0,
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'independent_result_review_pending': True, 'actual_historical_E_exponent_unfolded': False,
            'original_R0_at_read_proved': False, 'read_metadata_postscale_selector_join_proved': False,
            'whole_device_theorem': False}, typing
    except BaseException as error:
        FAILURE = {'error': repr(error), 'partial_nodes': copy.deepcopy(proof.nodes) if proof is not None else [],
            'active_indices': copy.deepcopy(proof.active_indices) if proof is not None else {},
            'scope_labels': sorted(proof.scope_labels) if proof is not None else [],
            'index_bindings': copy.deepcopy(proof.index_bindings) if proof is not None else {},
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())} if audit is not None else {},
            'executed_helper_pins': {str(k): audit.READS.get(k) for k in sorted(audit.HELPERS)} if audit is not None else {},
            'new_native_jobs': 0, 'result_qualified': False}
        raise
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--metadata-only'])
    name = 'METADATA-R1' if sys.argv[1:] else 'APPLICATION-R1'
    assert not any((HERE / (name + suffix)).exists() for suffix in ['.json', '-STOPPED.json', '-TYPING-ONLY.smt2'])
    def save(suffix, raw):
        with (HERE / (name + suffix)).open('xb') as output:
            output.write(raw)
    try:
        result, typing = construct(bool(sys.argv[1:]))
    except BaseException:
        save('-STOPPED.json', (json.dumps(FAILURE, indent=2, sort_keys=True) + '\n').encode())
        raise
    save('.json', (json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    if typing is not None:
        save('-TYPING-ONLY.smt2', typing)
    print(json.dumps({'metadata_only': bool(sys.argv[1:]), 'new_nodes': len(result.get('application', {}).get('nodes', [])), 'new_native_jobs': 0}))

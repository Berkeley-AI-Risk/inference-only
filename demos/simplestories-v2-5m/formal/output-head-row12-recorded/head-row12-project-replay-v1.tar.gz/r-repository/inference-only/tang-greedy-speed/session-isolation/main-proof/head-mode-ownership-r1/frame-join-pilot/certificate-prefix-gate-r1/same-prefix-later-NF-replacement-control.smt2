; Expected SAT sensitivity: completed snapshot cannot be replaced by later same-prefix NF
; PREPARATION ONLY: no engine result exists.
(declare-datatypes
  ()
  ((NormFrame
      (mkNormFrame
        (nf-t Int)
        (nf-sv Bool)
        (nf-sid Int)
        (nf-active Bool)
        (nf-uid Int)
        (nf-sparent Int)
        (nf-prefix (_ BitVec 12))
        (nf-count (_ BitVec 9))
        (nf-exp (_ BitVec 8))
        (nf-data (Array (_ BitVec 8) (_ BitVec 16)))))))

(define-fun nf-zero ((empty (Array (_ BitVec 8) (_ BitVec 16)))) NormFrame
  (mkNormFrame 0 false 0 false 0 0 (_ bv0 12) (_ bv0 9) (_ bv0 8) empty))

(declare-datatypes
  ()
  ((FrameHistory
      (mkFrame
        (f-uid Int)
        (f-active Bool)
        (f-n (_ BitVec 10))
        (f-cols (_ BitVec 10))
        (f-complete Bool)
        (f-data (Array (_ BitVec 10) (_ BitVec 16)))))))

(define-fun frame-zero ((empty (Array (_ BitVec 10) (_ BitVec 16)))) FrameHistory
  (mkFrame 0 false (_ bv0 10) (_ bv0 10) false empty))

(declare-datatypes
  ()
  ((FrameJoinView
      (mkFrameJoinView
        (fv-drop Bool)
        (fv-begin Bool)
        (fv-write Bool)
        (fv-live Bool)
        (fv-head Bool)
        (fv-word (_ BitVec 16))
        (fv-new-uid Int)
        (fv-incoming-cols (_ BitVec 10))))))

(declare-datatypes
  ()
  ((FrameRmsCertificate (mkFRC (frc-valid Bool) (frc-juid Int) (frc-at Int) (frc-nf NormFrame)))))

(define-fun fj-frame-next ((view FrameJoinView) (frame FrameHistory) (empty (Array (_ BitVec 10) (_ BitVec 16)))) FrameHistory
  (ite
    (fv-drop view)
    (mkFrame (f-uid frame) false (_ bv0 10) (f-cols frame) false (f-data frame))
    (ite
      (fv-begin view)
      (mkFrame (fv-new-uid view) true (_ bv0 10) (fv-incoming-cols view) false empty)
      (mkFrame
        (f-uid frame)
        (f-active frame)
        (ite
          (fv-write view)
          (ite
            (= (f-n frame) (bvsub (f-cols frame) (_ bv1 10)))
            (_ bv0 10)
            (bvadd (f-n frame) (_ bv1 10)))
          (f-n frame))
        (f-cols frame)
        (or
          (f-complete frame)
          (and (fv-write view) (= (f-n frame) (bvsub (f-cols frame) (_ bv1 10)))))
        (ite (fv-write view) (store (f-data frame) (f-n frame) (fv-word view)) (f-data frame))))))

(define-fun fj-effective-head-write ((view FrameJoinView)) Bool
  (and (not (fv-drop view)) (not (fv-begin view)) (fv-live view) (fv-head view) (fv-write view)))

(define-fun fj-first ((view FrameJoinView) (frame FrameHistory)) Bool
  (and (fj-effective-head-write view) (not (f-complete frame)) (= (f-n frame) (_ bv0 10))))

(define-fun frc-zero ((empty-nf (Array (_ BitVec 8) (_ BitVec 16)))) FrameRmsCertificate
  (mkFRC false 0 0 (nf-zero empty-nf)))

(define-fun frc-next ((view FrameJoinView) (frame FrameHistory) (nf NormFrame) (certificate FrameRmsCertificate) (observation Int)) FrameRmsCertificate
  (ite
    (or (fv-drop view) (fv-begin view))
    (mkFRC false (frc-juid certificate) (frc-at certificate) (frc-nf certificate))
    (ite (fj-first view frame) (mkFRC true (f-uid frame) observation nf) certificate)))

(define-fun fj-accepted-nf ((nf NormFrame)) Bool
  (and (nf-active nf) (nf-sv nf) (= (nf-count nf) (_ bv256 9)) (= (nf-sparent nf) (nf-sid nf))))

(define-fun fj-protected-equal ((left NormFrame) (right NormFrame)) Bool
  (and
    (= (nf-data left) (nf-data right))
    (= (nf-exp left) (nf-exp right))
    (= (nf-uid left) (nf-uid right))
    (= (nf-sparent left) (nf-sparent right))
    (= (nf-sid left) (nf-sid right))
    (= (nf-prefix left) (nf-prefix right))))

(declare-fun fj-capture-record-at (Int) FrameRmsCertificate)

(define-fun fj-current-record ((view FrameJoinView) (frame FrameHistory) (nf NormFrame) (observation Int)) FrameRmsCertificate
  (mkFRC (fj-first view frame) (f-uid frame) observation nf))

(define-fun frc-I ((view FrameJoinView) (frame FrameHistory) (nf NormFrame) (certificate FrameRmsCertificate) (observation Int) (watch (_ BitVec 8))) Bool
  (and
    (=>
      (frc-valid certificate)
      (and
        (f-active frame)
        (= (frc-juid certificate) (f-uid frame))
        (and
          (<= 1 (frc-at certificate))
          (< (frc-at certificate) observation)
          (= certificate (fj-capture-record-at (frc-at certificate)))
          (fj-accepted-nf (frc-nf certificate)))
        (= (f-cols frame) (_ bv256 10))
        (or
          (f-complete frame)
          (and (bvult (_ bv0 10) (f-n frame)) (bvult (f-n frame) (_ bv256 10))))))
    (=> (and (frc-valid certificate) (fv-live view)) (fv-head view))
    (=>
      (and (frc-valid certificate) (not (f-complete frame)))
      (fj-protected-equal nf (frc-nf certificate)))
    (=>
      (and
        (frc-valid certificate)
        (or (f-complete frame) (bvult ((_ zero_extend 2) watch) (f-n frame))))
      (=
        (select (f-data frame) ((_ zero_extend 2) watch))
        (select (nf-data (frc-nf certificate)) watch)))
    (=>
      (and
        (fv-live view)
        (f-active frame)
        (fv-head view)
        (or (f-complete frame) (not (= (f-n frame) (_ bv0 10)))))
      (frc-valid certificate))))

(define-fun control-original-nf () NormFrame
  (mkNormFrame
    20
    true
    7
    true
    10
    7
    (_ bv2 12)
    (_ bv256 9)
    (_ bv0 8)
    (store ((as const (Array (_ BitVec 8) (_ BitVec 16))) (_ bv0 16)) (_ bv13 8) (_ bv7 16))))

(define-fun control-later-nf () NormFrame
  (mkNormFrame
    40
    true
    27
    true
    30
    27
    (_ bv2 12)
    (_ bv256 9)
    (_ bv0 8)
    (store ((as const (Array (_ BitVec 8) (_ BitVec 16))) (_ bv0 16)) (_ bv13 8) (_ bv11 16))))

(define-fun control-frame () FrameHistory
  (mkFrame
    15
    true
    (_ bv0 10)
    (_ bv256 10)
    true
    (store ((as const (Array (_ BitVec 10) (_ BitVec 16))) (_ bv0 16)) (_ bv13 10) (_ bv7 16))))

(define-fun control-certificate () FrameRmsCertificate (mkFRC true 15 21 control-original-nf))

(define-fun control-view () FrameJoinView
  (mkFrameJoinView false false false true true (_ bv0 16) 0 (_ bv256 10)))

(assert
  (and
    (= (fj-capture-record-at 21) control-certificate)
    (forall
      ((control-watch (_ BitVec 8)))
      (frc-I control-view control-frame control-later-nf control-certificate 50 control-watch))
    (= (nf-prefix control-original-nf) (nf-prefix control-later-nf))
    (not (= (nf-uid control-original-nf) (nf-uid control-later-nf)))
    (not (= (nf-sid control-original-nf) (nf-sid control-later-nf)))
    (=
      (select (f-data control-frame) (_ bv13 10))
      (select (nf-data (frc-nf control-certificate)) (_ bv13 8)))
    (not
      (= (select (f-data control-frame) (_ bv13 10)) (select (nf-data control-later-nf) (_ bv13 8))))))

(check-sat-using (then simplify propagate-values solve-eqs simplify smt))

(exit)

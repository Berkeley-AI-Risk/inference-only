"""Read-only original-row/saved-RMS consequence; no native engines."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
M = C.parent
P = M / 'head-mode-ownership-r1'
L = P / 'frame-join-pilot/certificate-trace-application-r2'
SCOPE = 'physical-original-row-E-exponent-and-same-saved-RMS-snapshot'
INPUTS = {'run_consequence.py', 'original_row.py', 'consequence_audit.py', 'PLAN.md', 'INPUT-REVIEW.md', 'RAW-INPUTS.json'}
RAW = {'continuity_binding', 'continuity_application', 'continuity_typing', 'continuity_review',
    'engine_application', 'engine_typing', 'engine_review', 'capture_application', 'capture_typing', 'capture_review', 'capture_seal',
    'dot_application', 'dot_prefix', 'dot_seal', 'row_guard_binding', 'row_guard_query', 'row_guard_result', 'row_guard_seal',
    'math_binding', 'math_check', 'math_query', 'math_seal'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
FAILURE = None


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def construct(metadata_only=False):
    global FAILURE
    FAILURE = None
    proof, audit = None, None
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        assert type(metadata_only) is bool and sys.version_info[:2] == (3, 12)
        assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
        audit_path = L / 'check_nf_component.py'
        audit = load('_original_row_readonly_audit', audit_path, '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33')
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'ACCEPTED-INPUTS.json'
        env = json.loads(env_path.read_bytes())
        assert env['accepted'] is True and env['scope'] == SCOPE and set(env['files']) == INPUTS
        for name, expected in env['files'].items():
            path = HERE / name
            assert path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == expected
        manifest = json.loads((HERE / 'RAW-INPUTS.json').read_bytes())
        assert set(manifest) == {'paths_relative_to_main_proof', 'pins', 'helper_paths_relative_to_main_proof', 'helper_pins'}
        assert set(manifest['paths_relative_to_main_proof']) == set(manifest['pins']) == RAW
        assert set(manifest['helper_paths_relative_to_main_proof']) == set(manifest['helper_pins']) == {'fixed', 'steps'}
        raw = {}
        for name, relative in manifest['paths_relative_to_main_proof'].items():
            path = (M / relative).resolve()
            assert path.is_relative_to(M) and not path.is_symlink()
            raw[name] = path.read_bytes()
            assert digest(raw[name]) == manifest['pins'][name]
        data = {name: json.loads(value) for name, value in raw.items() if manifest['paths_relative_to_main_proof'][name].endswith('.json')}
        for family in ['continuity', 'engine', 'capture']:
            assert data[family + '_application']['typing_sha256'] == digest(raw[family + '_typing'])
        cap_key = 'frame-join-pilot/certificate-trace-application-r2/step-rms-origin-application-r1/CAPTURE-ROW-APPLICATION-R1-TYPING-ONLY.smt2'
        assert data['capture_seal']['files'][cap_key] == digest(raw['capture_typing'])
        exports = load('_original_row_exports', L / 'accepted_exports_r3.py', '2bc78867ebf370b0cf6f32c6ddf7e15e1f129f49db1764a7b88acc7b1d9bb082').load_parent_exports()
        api = exports['apis']
        def helper(name):
            return load('_original_row_' + name, M / manifest['helper_paths_relative_to_main_proof'][name], manifest['helper_pins'][name])
        fixed, steps = [helper(name) for name in ['fixed', 'steps']]
        module = load('_original_row_application', HERE / 'original_row.py', env['files']['original_row.py'])
        checker = load('_original_row_deduction_audit', HERE / 'consequence_audit.py', env['files']['consequence_audit.py'])
        heads = {'declare-sort', 'declare-fun', 'declare-datatypes', 'declare-datatype', 'declare-const', 'define-fun'}
        forms = [f for f, _, _ in api['parse_spans'](raw['engine_typing']) if f[0] in heads]
        definitions = {f[1]: f for f in forms if f[0] == 'define-fun'}
        capture_defs = {f[1]: f for f, _, _ in api['parse_spans'](raw['capture_typing']) if f[0] == 'define-fun'}
        assert all(name in definitions and definitions[name] == value for name, value in capture_defs.items())
        for key in ['future_fixed_actual_function_definition', 'future_actual_invariant']:
            definition = data['continuity_binding'][key]
            assert definition[1] not in definitions
            forms.append(definition)
            definitions[definition[1]] = definition
        for family, key in [('row_guard', 'combined_goal'), ('math', 'goal')]:
            assertions = [f for f, _, _ in api['parse_spans'](raw[family + '_query']) if f[0] == 'assert']
            assert assertions == [['assert', ['not', data[family + '_binding'][key]]]]
        prepared = module.prepare_metadata(exports, data, manifest['pins'], forms)
        if metadata_only:
            audit.HELPERS.update({Path(__file__).resolve(), audit_path})
            assert audit.HELPERS <= set(audit.READS)
            for path, expected in list(audit.READS.items()):
                assert digest(path.read_bytes()) == expected
            return {'metadata_only_passed': True, 'proof_initializers_called': 0, 'proof_nodes': 0,
                'input_envelope_sha256': digest(env_path.read_bytes()), 'new_native_jobs': 0,
                'old_capture_definitions_literal': len(capture_defs),
                'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
                'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)}}, None
        proof = api['ValueProof'].__new__(api['ValueProof'])
        api['Proof'].__init__(proof, {})
        for name, original in proof.root_context.items():
            assert all(exports['context'][name][key] == value for key, value in original.items())
        proof.root_context = copy.deepcopy(prepared['context'])
        language = api['SourceLanguage']()
        language.add(forms)
        for f in forms:
            if f[0] == 'declare-const':
                assert f[1] not in language.defs and f[1] not in language.decls
                language.decls[f[1]] = copy.deepcopy(f)
        assert all(name not in language.defs and name not in language.decls for name in [module.N, module.W])
        index_decl = ['declare-const', module.N, 'Int']
        language.decls[module.N] = index_decl
        app = module.construct(proof, language, exports, data, prepared, steps, fixed)
        deduction = checker.validate(app, exports, data, prepared, forms, module)
        typing_forms = [*forms, index_decl, language.decls[module.W], *[['assert', n['formula']] for n in proof.nodes],
            ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
        typing = ('\n'.join(map(api['smt'], typing_forms)) + '\n').encode()
        path = P / 'source_typecheck.py'
        type_raw = path.read_bytes()
        assert digest(type_raw) == '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809'
        functions = [f for f in ast.parse(type_raw).body if isinstance(f, ast.FunctionDef) and f.name in ['sort', 'check']]
        namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), 'exec'), namespace)
        typed = namespace['check'](typing)
        assert typed['assertions'] == len(proof.nodes)
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        for path, expected in list(audit.READS.items()):
            assert digest(path.read_bytes()) == expected
        return {'application': app, 'deduction_check': deduction, 'type_check': typed, 'typing_sha256': digest(typing),
            'input_envelope_sha256': digest(env_path.read_bytes()), 'new_native_jobs': 0,
            'old_parent_proof_reconstructions_called': 0, 'old_capture_definitions_literal': len(capture_defs),
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'independent_result_review_pending': True, 'read_dot_metadata_postscale_selector_join_proved': False,
            'whole_device_theorem': False}, typing
    except BaseException as error:
        FAILURE = {'error': repr(error), 'partial_nodes': copy.deepcopy(proof.nodes) if proof is not None else [],
            'active_indices': copy.deepcopy(proof.active_indices) if proof is not None else {},
            'scope_labels': sorted(proof.scope_labels) if proof is not None else [],
            'index_bindings': copy.deepcopy(proof.index_bindings) if proof is not None else {},
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())} if audit is not None else {},
            'executed_helper_pins': {str(k): audit.READS.get(k) for k in sorted(audit.HELPERS)} if audit is not None else {},
            'new_native_jobs': 0, 'result_qualified': False}
        raise
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--metadata-only'])
    name = 'METADATA-R1' if sys.argv[1:] else 'CONSEQUENCE-R1'
    assert not any((HERE / (name + suffix)).exists() for suffix in ['.json', '-STOPPED.json', '-TYPING-ONLY.smt2'])
    def save(suffix, raw):
        with (HERE / (name + suffix)).open('xb') as output:
            output.write(raw)
    try:
        result, typing = construct(bool(sys.argv[1:]))
    except BaseException:
        save('-STOPPED.json', (json.dumps(FAILURE, indent=2, sort_keys=True) + '\n').encode())
        raise
    save('.json', (json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    if typing is not None:
        save('-TYPING-ONLY.smt2', typing)
    print(json.dumps({'metadata_only': bool(sys.argv[1:]), 'new_nodes': len(result.get('application', {}).get('nodes', [])), 'new_native_jobs': 0}))

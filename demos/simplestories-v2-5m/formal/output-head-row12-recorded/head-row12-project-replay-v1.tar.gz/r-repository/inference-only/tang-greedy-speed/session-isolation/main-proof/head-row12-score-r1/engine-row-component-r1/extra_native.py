"""Read-only four additional E/row exponent source receipts; no runner calls."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import hashlib
import json
import types
HERE = Path(__file__).resolve().parent
C = HERE.parent
M = C.parent
P = M / 'head-mode-ownership-r1'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
rd = lambda path: json.loads(path.read_bytes())
GATES = [
    ('engine-exponent-r1', 'prepare_engine_exponent.py', '6c3284f72255cd76358ee53ff7d76016917739f2c5c6e4c87405fe7b2a51cf87'),
    ('row-exponent-continuity-r1', 'prepare_continuity.py', '48f708e451b26593482ddb9c16c2355583f5b2e0b5e2f889e40c77aeddb2e161')]


def load(name, path, pins):
    raw = path.read_bytes()
    assert pins[path] == digest(raw), str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def check(pins):
    records = load('_engine_row_recorded_resources', P / 'check_mode.py', pins)
    parser = load('_engine_row_native_parser', P / 'support.py', pins)
    protocol = load('_engine_row_native_protocol', P / 'output_check.py', pins)
    checked = []
    for relative, preparer, review in GATES:
        h = C / relative
        assert digest((h / 'RESULT-REVIEW.md').read_bytes()) == review
        frozen, accepted = rd(h / 'FROZEN-INPUTS.json'), rd(h / 'REVIEW-ACCEPTED.json')
        assert accepted['accepted'] and accepted['scope'] == frozen['scope'] and accepted['max_native_jobs'] == 2
        assert accepted['frozen_sha256'] == digest((h / 'FROZEN-INPUTS.json').read_bytes())
        assert accepted['review_sha256'] == digest((h / 'INPUT-REVIEW.md').read_bytes())
        for name, value in frozen['files'].items():
            assert pins[h / name] == value and digest((h / name).read_bytes()) == value
        for name, value in rd(h / 'EXTERNAL-PINS.json').items():
            assert pins[Path(name)] == value and digest(Path(name).read_bytes()) == value
        module = load('_engine_row_prepare_' + str(len(checked)), h / preparer, pins)
        queries, binding, plan, typing, reads = module.assemble()
        assert binding == rd(h / 'SOURCE-BINDING.json') and plan == rd(h / 'QUERY-PLAN.json')
        assert binding['native_sha256'] == 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
        assert binding['native_T_conjuncts'] == 452 and typing == rd(h / 'TYPE-CHECK.json') and reads == rd(h / 'READ-PINS.json')
        intent, result, tool = rd(h / 'RUN-INTENT.json'), rd(h / 'RESULTS.json'), rd(h / 'TOOL-PIN.json')
        assert intent['scope'] == frozen['scope'] and intent['query_order'] == plan['order']
        assert intent['max_native_jobs_this_gate'] == 2 and intent['workers'] == 1
        assert intent['RSS_and_physical_footprint_cap_bytes'] == 4 * (1 << 30) and intent['time_or_CPU_kill_enabled'] is False
        assert tool['sha256'] == 'ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102'
        assert intent['tool'] == tool and pins[Path(tool['path'])] == tool['sha256']
        assert result['all_expected_results_matched'] and result['active_owned_native_job'] is None
        assert result['native_jobs'] == len(result['results']) == len(plan['order']) == 2
        assert {p.name for p in (h / 'runs').iterdir()} == set(plan['order']) | {n + '-observations.jsonl' for n in plan['order']}
        previous_end = None
        for name, row in zip(plan['order'], result['results']):
            query = h / (name + '.smt2')
            assert queries[name] == query.read_bytes() and digest(queries[name]) == plan['queries'][name]['sha256']
            assert row['name'] == name and row['expected'] == row['answer'] == 'unsat' and row['matched']
            assert row['query_sha256'] == digest(queries[name]) and row['binary_sha256'] == tool['sha256']
            folder = h / 'runs' / name
            assert {p.name for p in folder.iterdir()} == {'STARTED.json', 'FINISHED.json', 'MONITOR-BINDING.json', 'NATIVE.log', 'CHECKED-RESULT.json'}
            assert rd(folder / 'CHECKED-RESULT.json') == row
            argv = [tool['path'], '-smt2', '-st', '-memory:4096', str(query)]
            start, finish, monitor = records.recorded_run(folder, h / 'runs' / (name + '-observations.jsonl'), argv)
            assert row['receipt'] == finish and row['monitor_binding'] == monitor
            assert start['cwd'] == finish['cwd'] == str(h) and start['environment_changes'] == {} and start['single_process_required']
            if previous_end is not None:
                assert previous_end <= records.dt(start['started_utc'])
            previous_end = records.dt(finish['finished_utc'])
            log = (folder / 'NATIVE.log').read_bytes()
            assert protocol.accept([f for f, _, _ in parser.parse_spans(log)], 'unsat', [])
            assert row['raw_log_sha256'] == digest(log)
            checked.append({'gate': relative, 'name': name, 'query_sha256': digest(queries[name]),
                'raw_log_sha256': digest(log), 'native_waited_and_reaped': True, 'wall_seconds': finish['wall_seconds']})
    assert len(checked) == 4
    return {'passed': True, 'native_leaves': 4, 'results': checked, 'new_native_jobs': 0, 'writes': 0}

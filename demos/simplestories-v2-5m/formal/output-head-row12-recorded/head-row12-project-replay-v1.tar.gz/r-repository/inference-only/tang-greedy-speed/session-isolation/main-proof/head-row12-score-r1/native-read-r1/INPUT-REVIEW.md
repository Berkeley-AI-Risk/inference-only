# Independent native synchronous-read input review

**Decision: LAUNCH GO for these two exact conditional source queries after
the coordinator's hash-specific freeze/acceptance and pure preflight.** No
native runner, freeze or engine was invoked by this reviewer. The leaves
have no solver credit yet and grant no model-dot, metadata, UID or score
qualification.

## Exact inputs

| Input | SHA256 |
| --- | --- |
| PLAN.md | `549cf6a8b35a5a27fb02368d56c43155fed2724dfbb6bdba80052129619e0054` |
| prepare_read.py | `0c607011e3b5847848bbae019511499126fc1bdf881aa79502d515df867c25a3` |
| run_read.py | `876b89a397f55576264c92e0fa80bc35dfcaff533f008dfd3a4f4cbb17cd7ead` |
| SOURCE-BINDING.json | `ef83d647f463f40c60c9db8de64f157df5a647fda8388ed294078a1ee5eb79f4` |
| QUERY-PLAN.json | `372481d4cc961c58097b7dc2018f6cd07cbece3ea65e60473a2a68fdc6a27a11` |
| TYPE-CHECK.json | `4daabbe3fadb2284906b4edecac6185c097ec142430dad16777a17b9f1d0bc16` |
| READ-PINS.json | `75635791453b8e92feafbb2ebabbc5be84a5ba3bbc1320556b2f250b3223e968` |
| EXTERNAL-PINS.json | `d576ca8b27ff12a43be9e021cad0a5ee7ed014b7e6908ed0f3b16b3665d14ce1` |
| TOOL-PIN.json | `f823eb9803a67ff0a59d4f876b947b7b1d4ca7383c0112bf953861f6718f95f9` |
| row12-tile0-synchronous-read.smt2 | `0755876138cbfbfd8adbaa81a2eec2a688fc5678c5d4a275174732b1e57248e0` |
| row12-stage1-capture-and-pipeline-stall.smt2 | `b19c318ff1f9dfbf713e47be7403c5c45b259c30b9b65ababb75976ad8fca720` |

The required freeze has twelve local entries: these eleven files and this
review. All38 external pins match actual regular nonsymlink files; all five
preparation reads are covered by external pins plus the local preparer.
The complete nine-file source compile record, original compile script/profile,
accepted parser/typechecker/guard/probes and actual tool binary are pinned.

## Actual source and tuple timing

Both queries retain the exact 4,336,780-byte c070 native prefix, including
all452 T conjuncts. Their tails contain only the two actual source-state
declarations, one negated recorded goal, one check and exit. I independently
compared all29 recorded getter definitions and the exact tails with the
native model/binding. There is no child-state-sort identification, forgotten
transition conjunct, desired numerical value or future-health assertion.

The first leaf's combinational implication uses actual H and issue with local
count12. It derives all four native tile read enables, tile0 lane12 and global
advance. Its sequential implication retains both H endpoints/full T and
identifies successor tile0 dot/multiplier/exponent with the pre-edge
accumulator12 and metadata memories12. Selection becomes tile0 and local
row tag0 becomes12. It also proves the physical tuple holds if read is absent.
No convenient later accumulator or post-write metadata cell is substituted.

This agrees with the actual source: metadata writes and tile reads are
nonblocking assignments in a resetless clocked block. A same-edge metadata
write therefore does not replace the value captured by that edge's read.
The accumulator observation is the literal signed35 low-bit source wire;
there is no new signed-integer or completed-dot interpretation in this leaf.

The second leaf uses actual advance, old stage0 validity, selected tile0 and
old local row tag12. The next operands are exactly old tile0 dot[24:0]
zero-extended by2, dot[34:25] sign-extended by17, and the old16-bit multiplier
zero-extended by2, with the old exponent and row tag transferred. These are
the source's exact 27/27/18-bit operand constructions, not a new product or
sum formula. They consume the pre-edge registered tile tuple even if the same
edge issues a new read, including the adjacent row13 read.

When advance is false, all fourteen listed physical selection/operand/product/
result/row-tag/exponent-tag fields hold. They match the whole resetless payload
clocked block. The control-valid tags are deliberately not claimed to survive
reset, CLEAR or failure. Physical writes can occur while those controls revoke
authority; neither query filters the successor with reset/CLEAR/health or
grants such payload successful-use permission.

Count12 and tag12 are local to the current engine group. These leaves do not
fix group0 and therefore do not alone establish global vocabulary row12.
The later same-row application must derive group/row/UID/episode ownership,
completed original dot provenance and actual metadata provenance. An old
valid tag or a supplied numerical tuple is not a substitute for those joins.
The original row12/13 engine-interface fixture remains sensitivity evidence
only; none of its oracle numbers is a premise here.

## Pure reconstruction and execution gate

After static source/runner inspection I called only `prepare_read.assemble()`
in fresh Python3.12 with `-I -S -B`, under a deny-write/process/network/
filesystem-mutation audit. Its pinned parent preparer supplies only reviewed
pure parser/typechecker helpers; no old proof constructor or compiler runs.
The call exited0 in1.84 seconds. Both entire query byte strings and all four
JSON byte strings matched the saved inputs. Its actual read set equals the
five recorded paths, and no forbidden event was attempted. Fresh type reports
are12,069 symbols, one assertion and one check per query. The complete tool
result is retained. Typing is not a validity proof.

The runner is the accepted single-worker native runner with exact read-packet
names, scope and two-job accounting. It requires the twelve-local/38-external
freeze and review acceptance, rebuilds/compares all inputs in pure preflight,
refuses existing intent/results/runs, checks every pin around each job,
canonicalizes stored receipt/monitor keys and stops at the first mismatch.
Guard exceptions preserve evidence with uncertain child-cleanup status rather
than claiming success. This gate authorizes no retry or diagnostic.

Use only Z3 `ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`,
two first attempts in the listed order, one owned sequential worker, 4GiB
sampled RSS/physical footprint, internal memory4096 and actual normal Darwin
pressure under the unchanged accepted guard/probe closure. There is no wall/
CPU/token kill, fixed RAM floor, new probe, build, simulator slot, board or
public action. Unexpected SAT/error/unknown/resource stop halts dependents;
any changed query requires a new reviewed additive gate.

Even clean UNSAT results require independent raw-result review and actual
source-bound application. The original saved-R0/row exponent consequence,
same-epoch completed dot through this read, fixed-image metadata through its
memories, postscale/held score and actual selector admission remain separate
work. No numerical RMS, other-row or whole-device claim follows here, and
no frozen parent was modified.

# The original saved RMS exponent reaches the row's projection job

This private component extends the already qualified original STEP/RMS-to-row12
dot theorem. It identifies the source of the activation exponent used by the
actual datapath and projection job at that row's original input snapshot.
It does not yet establish the scaled score or its admission to the selector.
Final closure/replay acceptance is recorded separately from this statement.

Fix the named c070 SimpleStories greedy digital source, one model M and one
actual prefix0..N, N>=1, with the original common reset samples0 and1 low.
Retain the six inherited premises: actual composed source, both reset anchors,
runtime-entry image, static metadata and vendor storage. Use the original fixed
NF, FRAME, CERT, ROW and ROWFRAME histories. No new reset, command occurrence,
correct private exponent or successful future is assumed.

At a selected physical row12 completion n, the prior theorem fixes, before a
word coordinate:

```text
j  = FRAMEORIGIN(n)                 original row input snapshot
k  = endpoint-capture-index(j)      original saved RMS-API record capture
R0 = endpoint-saved-NF(j) = NF(k)
p  = R0.sid + 1                    original effective STEP
r  = R0.uid + 1                    original final-RMS launch
S  = ROWFRAME(n).data
1 <= p < r < k < j < n <= N.
```

The added result is an exact8-bit equality of actual native registers:

```text
D.head_activation_exponent_q(A(j)) = R0.exp
J.activation_exponent_q(A(j))      = R0.exp.
```

Here D is u_native.u_six_layers.u_datapath and J is its u_projection child.
The same equality holds at any live/head/active/complete FRAME observation i
with1<=i<=N, using that FRAME's exact original endpoint-saved-NF(i). It does
not replace the completed FRAME's saved record with the current NF record.

The original theorem is retained literally, including the actual effective
STEP/RMS events, RMS STEP parent and pre-edge committed prefix, original row
UID/episode, all256 saved input-word equalities and completed signed48/signed35
dot D(S,M,256). With the exponent result, the saved argument is a vector and
shared exponent from the same RMS-API record. Numerical meaning of that RMS
operator and its decoder input belongs to the separate upstream composition.

```mermaid
flowchart LR
    STEP["Original STEP p"] --> RMS["Final-RMS launch r"]
    RMS --> OUT["Actual captured RMS-API words and exponent"]
    OUT --> R0["Original saved RMS record NF(k)
256 words and one exponent"]
    R0 --> FRAME["Original row snapshot j
saved words S"]
    FRAME --> DOT["Completed row12 dot n
unchanged qualified sum"]
    OUT --> SHELL["Actual shell exponent"]
    SHELL --> D["Actual D head-start register"]
    D --> J["Actual J exponent at snapshot j
equals R0.exp"]
    R0 ---|"same exponent"| J
    DOT -. "read/metadata/scale join remains" .-> SCORE["Scaled tuple and selector admission
not established by this component"]
    J -.-> SCORE
```

The proof first establishes a reset-founded head-start history, captured from
actual NF at the effective source capture. Its validity/protected-field
invariant covers the interval before J starts and shell-fault intervals. A
second relation ties this history to the original FRAME certificate through
completion. Full native source checks retain actual reset/CLEAR/fault priorities
and explicit successor reset masking. Physical payload can remain true after
fault or cancellation; that does not give canceled work permission to publish.

The two ordinary inductions have96 checked deduction nodes. A further131-node
application supplies their bounded premises, the original current endpoint and
the historical row snapshot. It derives j's lower/upper bounds before new source
or theorem applications. Only bounded state providers are used there; no edge
family is silently treated as a state theorem, no INDEX(j) is assumed and no
source state or edge beyond N is used. Generic record functions are explicitly
specialized to the one qualified actual source function.

Twelve separately reviewed native leaves also include two physical read facts:
an actual local issue12 captures the pre-edge tile0 dot/metadata, and stage1
uses the pre-edge registered tuple even if a new read is issued on that edge.
All14 physical scale-pipeline fields hold under backpressure. These read leaves
alone do not fix group0, identify global vocabulary row12, certify the fixed
image's metadata, or connect the original completed dot to the later read.

Remaining work is to carry the original UID/episode/dot and shared exponent
through the actual registered read, fixed-model metadata, postscale and held
tuple, then prove actual legal greedy-selector admission. The restored selector
has a separate state sort and needs its actual source/port/clock/reset/parameter
application. First-fault-edge admissions must retain their real boundaries.
No numerical RMS, whole-head/token, other-release, physical-board or whole-device
inference-only theorem follows from this component alone.

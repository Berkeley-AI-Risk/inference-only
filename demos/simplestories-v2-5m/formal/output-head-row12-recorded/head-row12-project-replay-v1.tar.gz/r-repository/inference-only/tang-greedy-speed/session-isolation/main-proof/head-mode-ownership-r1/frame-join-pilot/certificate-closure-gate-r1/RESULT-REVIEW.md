# Independent review of the two recorded closure-gate results

Decision: **ACCEPT both recorded expected-UNSAT results.** The evidence closes
the exact conditional one-edge source/interface bridge and the generic
stamped-origin zero/step, NF recurrence identities and index-ordering lemma.
It does not close the actual whole-trace induction, historical ROWFRAME
application, NF qualification, numerical RMS or whole-device theorem.

This review read the frozen inputs, actual raw logs, checked results,
STARTED/FINISHED/monitor receipts and resource journals. Independent read-only
parsing and consistency checks reproduced their recorded conclusions. No
solver, guard, probe, campaign, build, simulation or process inspection/control
ran. Only this new review file was written.

## Frozen input and raw-answer binding

The accepted 12-file launch freeze is
`338ad771e6344fb5463ac314e3b26aae1f049ed72465bdc28f1e040832bf2b0d`.
It binds input review
`da81141fc95320ffcaeba0369fcab1feb4e9d9650414820e9bf9adb6f84fcbf8`
and runner
`562278d5a2857f1184a587d356a29465efc4a74103cf19b3b6d3707fe99cb52b`.
The review acceptance has the correct scope, freeze/review hashes and maximum
of two native jobs. All 12 frozen files, 72 external pins and 53 preparation
dependencies still match. Dependency coverage agrees with the external map.
The actual Z3 binary matches
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`
without being invoked during this review.

| Recorded query | SHA-256 | Raw result | Statistics/checks |
| --- | --- | --- | --- |
| `actual-source-to-certificate-interface` | `b2c516b5169e86d7598b8377ef445b5fa66d0299f9d5e2e9bc4d9f87939dfada` | UNSAT | 33 fields; num-checks=1 |
| `stamped-origin-zero-step-and-nf-recurrences` | `0546fed421cf268742c0d1126646381518e7a1c242c21204951b4ce1d22d786a` | UNSAT | 34 fields; num-checks=1 |

Each combined native log parses as exactly two forms: UNSAT and one valid
finite statistics form. There is no extra error, warning, answer or value
form. The executed source query contains the reviewed six assertions and one
solver check; the stamped query contains its reviewed one assertion and one
solver check. Their bytes match the launch freeze, query plan and checked
result hashes.

Each command is exactly the pinned Z3 path followed by
`-smt2 -st -memory:4096` and that query's absolute path. STARTED and FINISHED
agree on the command, packet cwd, original start time, PID and PGID. The
per-job CHECKED-RESULT embeds its actual FINISHED and MONITOR-BINDING exactly;
RESULTS embeds those two checked results in the reviewed order. RUN-INTENT
agrees with the plan, one worker, two-job cap, tool and resource settings.

The runs directory contains exactly the two expected job folders and two
observation journals. Each job folder contains exactly its raw log,
STARTED, FINISHED, monitor binding and checked result. There is no additional
job, diagnostic or retry record. RESULTS records two native jobs, matched=true
for both, all_expected_results_matched=true, no active owned job and no guard
cleanup uncertainty. No failure/exception path was needed.

## Resource, serial ownership and reaping evidence

Both native exits and raw wait statuses are zero. Both resource-stop reasons
are null and monitor-error lists are empty. STARTED confirms one process,
4,294,967,296-byte memory cap, no kernel/stage CPU cap, no maximum/stage elapsed
cap, disk floor zero and no changed environment entries. The monitor records
no shared simulator reservation and no time/CPU kill.

| Recorded measurement | Source bridge | Stamped origin |
| --- | ---: | ---: |
| Wall seconds | 0.7732298374176025 | 0.009692192077636719 |
| User + system CPU seconds | 0.766772 | 0.006859 |
| PID = PGID | 8364 | 8366 |
| Stable process start identity | 43285431096172 | 43285450364827 |
| Normal pressure samples | 16 | 3 |
| Live loop samples | 14 | 1 |
| Group samples including terminal check | 15 | 2 |
| Sampled peak group/process RSS, bytes | 255,328,256 | 262,144 |
| Sampled peak physical footprint, bytes | 250,921,584 | 245,952 |
| Kernel `wait4` maximum RSS, bytes | 262,668,288 | 27,426,816 |

Each journal has exactly one admission, with pressure 1 and the correct
command/cap/single-process setting; all pressure observations remain at normal
level 1. Only the known admission/pressure/owned-group record kinds occur.
Journal times are monotonic. Every live group row names the same sole process
and positive start identity for its job. Group totals equal member sums; all
four FINISHED peak fields recompute exactly. Group counts equal loop counts
plus the terminal descendant check. Every sampled value and both kernel RSS
high-water marks are below 4 GiB. The kernel high-water mark being higher than
the samples, especially for the short stamped job, is consistent with sampling.

The source bridge finishes at `2026-11-12T03:33:42.556222+00:00`; the stamped
job starts later at `2026-11-12T03:33:42.585810+00:00`. Their PIDs and start
identities are distinct, confirming the recorded serial ownership.

The final owned-group samples are empty at
`2026-11-12T03:33:42.556062+00:00` and
`2026-11-12T03:33:42.595361+00:00`, before their respective FINISHED records.
The unchanged pinned native guard checks descendants while the leader is
unreaped, calls `wait4`, flushes the log and only then emits FINISHED. The
terminal empty groups, clean raw wait statuses and matching receipts support
successful recorded reaping without a surviving observed helper. This is an
audit of recorded cleanup evidence, not a new survey of live processes.

## Accepted logical scope

The first UNSAT result establishes the exact one-edge source-premise closure
under its explicit original providers, current induction hypothesis, native
H/T context and five fixed checked implication imports. It does not establish
the providers' actual same-trace construction or assume away their scope.

The second establishes the exact generic zero/step origin recurrence, six
literal NF projection/support identities and the pure stamp/index ordering.
Its universally abstract accessor declarations serve definitional identities;
they do not assert new universal source behavior. Applying the result to the
fixed original STEP/RMS record functions and the one actual NF trace remains
separate work.

The original A0/A1 reset anchor, `n-1` observer clock map, saved first-write
record, coordinate quantifier scope and independent arrays must be retained
in the future ordinary-induction application. Historical ROWFRAME must use
its original past index. Neither result makes that application automatically.
Original NF independent qualification remains pending. Numerical RMS, decoder/
model meaning, whole-frame/ROWFRAME and whole-device claims remain open. The
false broader flags in every result are correct; the original
independent_result_review_pending flag describes the pre-review record and
was not edited here.

## Evidence SHA-256 pins

Paths are relative to this packet. `S` denotes
`runs/actual-source-to-certificate-interface`; `O` denotes
`runs/stamped-origin-zero-step-and-nf-recurrences`.

| Evidence | SHA-256 |
| --- | --- |
| `FROZEN-INPUTS.json` | `338ad771e6344fb5463ac314e3b26aae1f049ed72465bdc28f1e040832bf2b0d` |
| `REVIEW-ACCEPTED.json` | `e6f8a7e5e9ba3a1dfea195516a671dffc286f1b705113887a9b7b1ba8000d67f` |
| `RUN-INTENT.json` | `7e4686b47818d39d17da1270247b7b58c4d4d3ecaa4329b86b49be053d207e8b` |
| `RESULTS.json` | `7482cf9462b26c2b6511fe22f6888739eeae16946a3cddff3ee42f364a4ec822` |
| `S/STARTED.json` | `3aeb6bd4c170284dac2f59cd6bcc35071481676ddb0104f3c4c29e43a8a8ef23` |
| `S/NATIVE.log` | `514aafbd5553cfaca88ca42b2cd6713b802a32e88232b83398ee54fe7e94f94f` |
| `S/FINISHED.json` | `6f7fc9c56d5707bb767478500065ffe2f5618ff05470e3e88bdc2ad270ad7e38` |
| `S/MONITOR-BINDING.json` | `bc73532283cbdbc4bd18892af7343187ebd87461b44aca68e8a2819c11b98d9e` |
| `S/CHECKED-RESULT.json` | `cb5dfea00523be8dd0db58314b829b2877953ed0022f9555d1cba0f787caa7b2` |
| `runs/actual-source-to-certificate-interface-observations.jsonl` | `d891731d5f4e030aa8b09a08a9c2c2bf8233951292a4809e2f3b04fba9fb050e` |
| `O/STARTED.json` | `5726a792b4478b213d1c5f66ad136e3b271bb611d94479e0b68d6d4fd24b4309` |
| `O/NATIVE.log` | `3b43c9af6d69ef4f42dd403a41c436c75137112371f36d07f4593d99723b1c9f` |
| `O/FINISHED.json` | `5c04ae532c2ab1e5800e734c2feb9d27c321d123104c34263146e1591dde8254` |
| `O/MONITOR-BINDING.json` | `17ab2b29afda9bc45fcd87e70a0cd4718752a8861f5965f4d8482732bc276393` |
| `O/CHECKED-RESULT.json` | `65912108e8d549fcb76a9c0eca2f123542774a9b69835e8c93476902d44d72dd` |
| `runs/stamped-origin-zero-step-and-nf-recurrences-observations.jsonl` | `7b2b025b8f766fb24859d6e32c752c4f371615a1bb62ffa5f303d2f6b7549ba5` |

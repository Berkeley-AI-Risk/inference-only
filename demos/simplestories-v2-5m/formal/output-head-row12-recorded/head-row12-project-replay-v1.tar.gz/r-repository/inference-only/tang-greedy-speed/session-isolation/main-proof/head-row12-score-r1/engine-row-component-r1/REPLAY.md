# Private component replay

Candidate entry point, unrun until exact independent input review and frozen
envelope are present:

```sh
/proof/z-historical-host/bin/python3.12 -I -S -B check_component.py
```

Run in this directory. The checker validates recorded source-query/protocol/
resource receipts and replays checked deduction construction. It compares full
JSON and typing bytes, not only selected summaries. It starts no solver,
compiler, simulator or board job and has no write capability inside check().
It is a replay of the exact independently accepted native results, not a fresh
solver run or proof of a changed source version.

FROZEN-COMPONENT.json must bind every actual read and executed helper, the old
closed component/envelope/seal, new four leaves and four applications, reviews
and this checker/theorem/replay text. The existing strong audit rejects writes,
process/network/ctypes use; standard library modules are loaded before that
audit. All namespace changes are restored on success/failure. No old giant
parent proof or one-shot native recorder is called.

A successful scoped replay establishes only THEOREM.md under its original
boundaries. Whole-device/actual score claims stay false. Result acceptance still
requires independent full replay/review and checked recovery/seal packaging.

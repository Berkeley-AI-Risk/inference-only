if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True;sys.setrecursionlimit(30000)
import support as c
import hashlib
sha=lambda b:hashlib.sha256(b).hexdigest()
HERE=Path(__file__).resolve().parent
def sort(s):return tuple(map(sort,s)) if isinstance(s,list) else s


def check(raw):
    symbols={};constants={};assertions=0;checks=0
    BV=lambda w:('_','BitVec',w)
    def infer(n,env):
        if isinstance(n,str):
            if n in env:return env[n]
            if n in constants:return constants[n]
            if n in symbols and symbols[n][0]==():return symbols[n][1]
            if n in ['true','false']:return 'Bool'
            if n.isdigit():return 'Int'
            if n.startswith('#b'):return BV(str(len(n)-2))
            if n.startswith('#x'):return BV(str(4*(len(n)-2)))
            raise ValueError(('unbound atom',n))
        op=n[0]
        if op in ['forall','exists']:
            assert len(n)==3 and isinstance(n[1],list) and n[1]
            names=[x[0] for x in n[1]]
            assert len(set(names))==len(names) and all(len(x)==2 for x in n[1])
            inner=dict(env);inner.update({x[0]:sort(x[1]) for x in n[1]})
            assert infer(n[2],inner)=='Bool'
            return 'Bool'
        if op=='_':
            assert n[1].startswith('bv') and int(n[2])>0
            return BV(n[2])
        if isinstance(op,list):
            if op[:2]==['as','const']:
                assert len(op)==3 and len(n)==2
                t=sort(op[2]);assert len(t)==3 and t[0]=='Array'
                assert infer(n[1],env)==t[2]
                return t
            if op[:2]==['_','int2bv']:
                assert len(op)==3 and len(n)==2 and int(op[2])>0 and infer(n[1],env)=='Int'
                return BV(op[2])
            t=infer(n[1],env);assert t[:2]==('_','BitVec') and len(n)==2
            w=int(t[2])
            if op[1]=='extract':
                hi,lo=int(op[2]),int(op[3]);assert 0<=lo<=hi<w
                return BV(str(hi-lo+1))
            assert op[1] in ['zero_extend','sign_extend'] and int(op[2])>=0
            return BV(str(w+int(op[2])))
        ts=[infer(x,env) for x in n[1:]]
        if op=='select':
            assert len(ts)==2 and ts[0][0]=='Array' and ts[0][1]==ts[1],(op,ts)
            return ts[0][2]
        if op=='store':
            assert len(ts)==3 and ts[0][0]=='Array' and ts[0][1]==ts[1] and ts[0][2]==ts[2],(op,ts)
            return ts[0]
        if op=='bv2int':
            assert len(ts)==1 and ts[0][:2]==('_','BitVec')
            return 'Int'
        if op in ['+','-','*','div','mod','<','<=','>','>=']:
            assert ts and all(t=='Int' for t in ts)
            if op in ['div','mod']:assert len(ts)==2
            return 'Bool' if op in ['<','<=','>','>='] else 'Int'
        if op in symbols:
            signature,result=symbols[op];assert tuple(ts)==signature,(op,ts,signature)
            return result
        if op in ['and','or','not','=>']:
            assert all(t=='Bool' for t in ts)
            if op=='not':assert len(ts)==1
            if op=='=>':assert len(ts)==2
            return 'Bool'
        if op in ['=','distinct']:
            assert len(ts)>=2 and all(t==ts[0] for t in ts)
            return 'Bool'
        if op=='ite':
            assert len(ts)==3 and ts[0]=='Bool' and ts[1]==ts[2],ts
            return ts[1]
        if op=='concat':
            assert len(ts)>=2 and all(t[:2]==('_','BitVec') for t in ts)
            return BV(str(sum(int(t[2]) for t in ts)))
        if op in ['bvnot','bvneg','bvadd','bvsub','bvand','bvor','bvxor','bvmul','bvshl','bvlshr','bvashr']:
            assert ts and ts[0][:2]==('_','BitVec') and all(t==ts[0] for t in ts)
            assert len(ts)==(1 if op in ['bvnot','bvneg'] else 2)
            return ts[0]
        if op in ['bvult','bvule','bvugt','bvuge','bvslt','bvsle','bvsgt','bvsge']:
            assert len(ts)==2 and ts[0]==ts[1] and ts[0][:2]==('_','BitVec')
            return 'Bool'
        raise ValueError(('unknown operator',op))
    for n,_,_ in c.parse_spans(raw):
        kind=n[0]
        if kind=='declare-sort':assert n[2]=='0'
        elif kind=='declare-fun':
            assert n[1] not in symbols
            symbols[n[1]]=(tuple(sort(t) for t in n[2]),sort(n[3]))
        elif kind=='declare-const':constants[n[1]]=sort(n[2])
        elif kind in ['declare-datatypes','declare-datatype']:
            if kind=='declare-datatypes':
                assert n[1]==[]
                datatypes=n[2]
            else:datatypes=[[n[1]]+n[2]]
            for datatype in datatypes:
                name=datatype[0]
                for constructor in datatype[1:]:
                    symbols[constructor[0]]=(tuple(sort(f[1]) for f in constructor[1:]),name)
                    for field in constructor[1:]:symbols[field[0]]=((name,),sort(field[1]))
        elif kind=='define-fun':
            env={p[0]:sort(p[1]) for p in n[2]};result=sort(n[3])
            actual=infer(n[4],env);assert actual==result,(n[1],actual,result)
            assert n[1] not in symbols
            symbols[n[1]]=(tuple(sort(p[1]) for p in n[2]),result)
        elif kind=='assert':
            try:assert infer(n[1],{})=='Bool'
            except Exception as error:raise ValueError(('assertion',assertions,str(n[1])[:1200],repr(error))) from error
            assertions+=1
        elif kind=='check-sat-using':checks+=1
        elif kind=='get-value':
            assert n[1]
            for term in n[1]:infer(term,{})
        elif kind in ['exit','get-model']:pass
        else:raise ValueError(('unsupported command',kind))
    assert checks==1
    return {'symbols':len(symbols),'assertions':assertions,'check_sat_commands':checks,'passed':True,'query_sha256':sha(raw)}



if __name__=='__main__':
    plan=json.loads((HERE/'QUERY-PLAN.json').read_text())
    report={n:check((HERE/(n+'.smt2')).read_bytes()) for n in plan['order']}
    (HERE/'TYPE-CHECK.json').write_text(json.dumps({'queries':report,'solver_jobs':0},indent=2,sort_keys=True)+'\n')
    print(json.dumps(report))

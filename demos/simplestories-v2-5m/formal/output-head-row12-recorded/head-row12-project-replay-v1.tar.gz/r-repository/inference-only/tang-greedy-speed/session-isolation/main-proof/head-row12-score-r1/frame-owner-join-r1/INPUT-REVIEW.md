# Independent saved-FRAME/head-owner input review

**Decision: LAUNCH GO for these exact three first-attempt queries after the
coordinator's hash-specific freeze, acceptance and pure preflight.** No freeze,
runner or engine was invoked by this reviewer. This gate targets the missing
relation between existing records; it does not yet apply the resulting leaves
to the original bounded prefix, saved R0 or completed row12.

## Exact reviewed inputs

| Input | SHA256 |
| --- | --- |
| PLAN.md | `298c3bafa049785cc49f185e7169a17d9f9ecce0c3e78d7a3074bff557bec272` |
| prepare_frame_owner.py | `b3c77149ff92e3f5a12211bddc24f366c0454886388afc922a341e22e6b3934e` |
| run_frame_owner.py | `74bc2a7b5cda3757d382841e82bd3dfffa893e5f218006a8135b2661062a564f` |
| SOURCE-BINDING.json | `91dd0428ee1d52d4a392c60d04ecb02d7a59378ad8c1de820efe041584e11ca5` |
| QUERY-PLAN.json | `164f79b7bb0874092aab171446f420d3e91fe4248ab1c7a9ca1a491a0c6b8a4d` |
| TYPE-CHECK.json | `c7c7c79f4c800b31442dddc07a64670720f568bbf75c0ff023f963d0f25ed7ac` |
| READ-PINS.json | `987c1cc5af9f333f0ca5e7d56bcfb0ba4336aad5adad0b26ebdc13a6b06702c0` |
| EXTERNAL-PINS.json | `da41dfa4b70a4312f5348139ebcaa949da02e3085254a334c70a95045396266a` |
| TOOL-PIN.json | `f823eb9803a67ff0a59d4f876b947b7b1d4ca7383c0112bf953861f6718f95f9` |
| frame-head-owner-base.smt2 | `11294e2cd829a403c7e96819f776d6a92ed0297bd363a4a338987f62bb121a5e` |
| frame-head-owner-preserve.smt2 | `ac80b5e502b87ae7f8dfbb1010f9470155b2c839847f756d1185b30b2e872c78` |
| owner-clock-and-saved-exponent.smt2 | `6f1c423d78afa021a4a5c07c81e5ad6f0a2838178bfc703729562305811a636a` |

The required local freeze contains those twelve files plus this review,
thirteen entries. All sixty external pins match actual regular nonsymlink
files. The fourteen preparation reads are covered by external pins plus the
local preparer. The envelope includes the accepted owner result review
`bef909a7afed26ebd312f255f3465e936114666e4b23d294cf9a1f8de45a7127`,
the earlier exponent result and budget clarification, original provider/helper
inputs, compiled-source record, guard/probes and actual tool binary.

## Relation, updates and conditional providers

The new `hf-I` is exactly one relation on the existing HS, FRAME and CERT.
J reset-high/no-CLEAR/no-integrated-failure, stored job7, active FRAME and
valid CERT imply HS validity and six-field protected equality of HS.nf and
CERT.nf. It creates no observer, event, UID, guessed exponent or numerical
input. Data, exponent, RMS UID, RMS parent, STEP ID and prefix are compared;
the clock, validity/activity flags and count are excluded. No equality to a
later current NF is asserted at completion.

Base uses native H/reset-low and the original frame-zero/frc-zero. Both the
frame and certificate start inactive/invalid with arbitrary data, so no
initialized payload or convenient source occurrence is assumed.

Preservation contains both H endpoints and the complete unchanged 452-clause
native T. Its remaining premises are current and successor frame-I/current
and successor hs-I, original current frc-I and current hf-I. All successor
records use literal frame-next/frc-next/hs-next/nf-next. There is no assumed
successor frc-I, new desired protected equality or future-health predicate.
The successor columns and JobHistory are arbitrary arguments, not promised
values. Later they must be supplied by independently qualified providers on
the actual same prefix and defined-edge domain.

The source/observer cases are preserved literally: frame drop or a new begin
invalidates CERT; first effective head write captures the current original
NF; otherwise CERT retains its saved NF. A retained active head FRAME's phase
comes from frame-I and the actual source. Together with hs-I's live job7 phase
clause, this supplies the control restriction against an unrelated effective
D head-start overwriting HS while that same certificate remains active.
That restriction is an obligation of this preservation query, not an added
environment promise. The newly proved relation may retain the original pair
after completion without requiring current NF to be CERT.nf.

The actual source FrameJoinView keeps original reset/CLEAR/fault/done drop,
start/begin, accepted write, live/head and data fields. D/J captures, reset
masks and fault/CLEAR priorities remain those of the accepted owner theory.
The goal at the successor has the same current-authority guard as the
invariant, rather than an assumed healthy successor in its premises. Reset,
drop and fault cases cannot grant canceled work a new certificate or owner.
This local guarded relation does not claim to cover an actual selector fire
outside that guard; first-fault-edge admission divergence remains an explicit
downstream obligation and cannot later be filtered away with shell health.

The third query is a conjunction of two separate implications. The clock
part assumes only `nf-t=n-1`, derives `nf-t+1=n`, and identifies literal actual
hs-next with generic-next at n. It does not prove the clock premise or assume
it as a new trace fact; the original qualified NF clock theorem must supply
it later. The saved-exponent part uses H, frame-I, hs-I, hf-I and the actual
current FrameJoinView live/head/active/valid guard. Frame-I supplies the native
J phase; hs-I supplies D/J physical exponent ownership; hf-I transfers only
the protected exponent to CERT.nf. Neither desired register equality nor
current NF=CERT.nf is a premise. Completion and future successful use are not
required for this current consequence.

## Literal theory and later specialization boundary

The 36 theory forms retain all NF/source-event/protected/HS helpers literally
from the accepted owner binding and all FRAME/CERT helpers from the pinned
original definitions. All sixteen overlapping defined helpers match the
qualified current-CERT typing theory at
`457c6695744aab84db433a6a887981b1d173db30c45151873ff5a815393a3a19`.
The nine directly recorded getters match c070 native definitions. No helper
name is silently overwritten and no distinct source-state sort is renamed.

One intentional generic-to-actual boundary is not an identical definition:
the query declares `fj-capture-record-at : Int -> FrameRmsCertificate`, while
the qualified current trace defines it as the actual `fj-current-record` of
`A(t), COLUMNS(t), FRAME(t), NF(t), t`. The generic theorem must later receive
one uniform checked specialization to that actual fixed function before its
frc-I premise is applied. It cannot use a record function chosen per stamp,
word or desired saved NF. This is a later typed application requirement, not
new source reachability supplied by the query. Historical bounds, original
clock/reset conventions and valid-history locality remain required there.

## Reconstruction, runner and stop rule

After static inspection I ran only the reviewed pure assembler in fresh
Python3.12 with `-I -S -B`, under a deny-write/process/network/filesystem-
mutation audit. Its nested owner preparer only reconstructs the previously
pinned SMT inputs; it initializes no old proof graph and calls no engine or
compiler. The call exited0 in 6.22 seconds. All three query byte strings and
all four generated JSON byte strings equal the saved files. Its actual read
set is exactly the fourteen recorded paths, with no forbidden event attempted.
Fresh type checking reports 12,176 symbols, one assertion and one check for
each query. The complete tool result is retained.

Independent parsing confirms the exact 4,336,780-byte c070 prefix in every
query, with all 452 T conjuncts and precisely the recorded theory,
declarations, one negated goal, one check and exit. The nine compiled source
files, compile script, macros/parameters and native output remain bound by
connected-SOURCES `8d0d406f494439ba7318d996389c6a5b830a8c30d2ee3dfc96aac9f66b25278c`.
No source, parent freeze, native circuit or sealed packet was changed.

The runner is the accepted owner runner with packet/scope/helper names and
previous-job accounting changed. It enforces the exact thirteen-local/sixty-
external freeze and review acceptance, pure reassembly preflight, refusal of
existing intent/results/runs, pin checks around each job, canonical receipt/
monitor comparison and stopping at the first mismatch. Guard exceptions
preserve evidence and mark child cleanup uncertain rather than claim success.
No diagnostics or retries are authorized by this batch.

Use only the pinned Z3
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`,
one sequential owned worker, 4 GiB sampled RSS/physical footprint, internal
memory4096 and actual normal Darwin pressure under the unchanged accepted
guard/probe closure. No wall/CPU/token kill, fixed RAM floor, resource probe,
compiler, simulation, board or public action is authorized. Unexpected SAT,
error, unknown, resource stop or unsupported transfer halts the affected
chain with exact evidence; a changed query needs a new reviewed additive gate.

Raw result review and the typed prefix/saved-R0 application remain required
even if all three queries pass. Registered dot read, actual fixed-image
metadata, postscale, held score, restored-selector admission, numerical RMS
and whole-device qualification remain outside this gate.

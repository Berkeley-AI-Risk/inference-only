"""One fixed reviewed same-prefix STEP/RMS/capture/completed-row application."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
L = HERE.parent
M = L.parents[2]
P = M / 'head-mode-ownership-r1'
SCOPE = 'actual-STEP-RMS-through-saved-capture-to-completed-row12'
AUDIT_SHA = '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33'
LOADER_SHA = '2bc78867ebf370b0cf6f32c6ddf7e15e1f129f49db1764a7b88acc7b1d9bb082'
ORIGIN_RESULT_SHA = '4a284ea6becc70d15deeea069d17dabc5debac843b6e2a5b01daabf19dc23600'
ORIGIN_REVIEW_SHA = '41e66dfd7888c9fcdff748b8170cdfb773d96c54ead3b79e9dddf4a81191e725'
INPUTS = {'run_capture_row.py', 'capture_row_application.py', 'proof_steps.py',
    'origin_induction.py', 'RAW-INPUTS.json', 'COMPOSITION-SUPPLEMENTS.json',
    'PLAN.md', 'PLAN-REVIEW.md', 'ORIGIN-INPUTS-R1.json', 'ORIGIN-INPUT-REVIEW.md',
    'ORIGIN-APPLICATION-R1.json', 'ORIGIN-RESULT-REVIEW.md', 'CAPTURE-ROW-INPUT-REVIEW.md'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
FAILURE = None


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def merge_theory(api, sources):
    forms, symbols, datatypes = [], {}, {}
    for source in sources:
        for form in source:
            kind = form[0]
            if kind in {'assert', 'check-sat-using', 'exit'}:
                continue
            if kind in {'declare-sort', 'declare-fun', 'declare-const', 'define-fun'}:
                key = form[1]
                if key in symbols:
                    assert symbols[key] == form, ('Changed existing source definition', key)
                    continue
                symbols[key] = form
            elif kind == 'declare-datatypes':
                assert form[1] == [] and len(form[2]) == 1
                key = form[2][0][0]
                if key in datatypes:
                    assert datatypes[key] == form, ('Changed existing datatype', key)
                    continue
                datatypes[key] = form
            else:
                raise AssertionError(('Unexpected source-theory command', kind))
            forms.append(deepcopy_form(form))
    return forms


def deepcopy_form(form):
    return copy.deepcopy(form)


def construct(metadata_only=False):
    global FAILURE
    FAILURE = None
    proof, audit = None, None
    old_path, old_modules = sys.path[:], dict(sys.modules)
    try:
        assert type(metadata_only) is bool
        assert sys.version_info[:2] == (3, 12) and sys.flags.isolated and sys.flags.no_site
        assert sys.dont_write_bytecode
        audit_path = L / 'check_nf_component.py'
        audit = load('_capture_row_existing_audit', audit_path, AUDIT_SHA)
        audit.ACTIVE = True
        assert digest(audit_path.read_bytes()) == AUDIT_SHA
        envelope_path = HERE / 'CAPTURE-ROW-INPUTS-R1.json'
        envelope = json.loads(envelope_path.read_bytes())
        assert envelope['accepted'] is True and envelope['scope'] == SCOPE
        assert set(envelope['files']) == INPUTS
        for name, expected in envelope['files'].items():
            path = HERE / name
            assert path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == expected
        assert envelope['files']['ORIGIN-APPLICATION-R1.json'] == ORIGIN_RESULT_SHA
        assert envelope['files']['ORIGIN-RESULT-REVIEW.md'] == ORIGIN_REVIEW_SHA
        exports = load('_capture_row_accepted_exports', L / 'accepted_exports_r3.py', LOADER_SHA).load_parent_exports()
        origin_module = load('_capture_row_origin_metadata', HERE / 'origin_induction.py', envelope['files']['origin_induction.py'])
        steps = load('_capture_row_literal_steps', HERE / 'proof_steps.py', envelope['files']['proof_steps.py'])
        module = load('_capture_row_fixed_application', HERE / 'capture_row_application.py', envelope['files']['capture_row_application.py'])
        raw_manifest = json.loads((HERE / 'RAW-INPUTS.json').read_bytes())
        raw = {name: (M / path).read_bytes() for name, path in raw_manifest['paths_relative_to_main_proof'].items()}
        prepared = origin_module.prepare_metadata(exports, raw, raw_manifest)
        origin_result = json.loads((HERE / 'ORIGIN-APPLICATION-R1.json').read_bytes())
        assert digest((HERE / 'ORIGIN-RESULT-REVIEW.md').read_bytes()) == ORIGIN_REVIEW_SHA
        assert origin_result['input_envelope_sha256'] == digest((HERE / 'ORIGIN-INPUTS-R1.json').read_bytes())
        assert len(origin_result['application']['nodes']) == 46 and origin_result['type_check']['assertions'] == 48
        assert origin_result['prefix']['families']['STEP']['event_definition'] == prepared['events']['STEP']
        assert origin_result['prefix']['families']['RMS']['event_definition'] == prepared['events']['RMS']
        data = {name: json.loads(value) for name, value in raw.items()
            if raw_manifest['paths_relative_to_main_proof'][name].endswith('.json')}
        for seal, member, raw_key in [
            ('nf_seal', 'frame-join-pilot/certificate-trace-application-r2/NF-PREFIX-APPLICATION.json', 'nf_prefix'),
            ('endpoint_seal', 'frame-join-pilot/certificate-trace-application-r2/ENDPOINT-PROJECTION-APPLICATION-R1.json', 'endpoint_application'),
            ('dot_seal', 'COMPLETED-DOT-PREFIX-APPLICATION-DRAFT.json', 'dot_prefix'),
            ('row_guard_seal', 'frame-join-pilot/row-capture-guard-r1/ADJUDICATED-RESULT-R2.json', 'row_guard_result')]:
            assert data[seal]['files'][member] == digest(raw[raw_key])
        assert data['row_guard_result']['accepted'] is True
        assert data['row_guard_result']['original_wrapper_success_claimed'] is False
        assert data['row_guard_binding']['native_sha256'] == 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
        api = exports['apis']
        guard_forms = [f for f, _, _ in api['parse_spans'](raw['row_guard_query'])]
        assert [f[1] for f in guard_forms if f[0] == 'assert'] == [['not', data['row_guard_binding']['combined_goal']]]
        supplements = json.loads((HERE / 'COMPOSITION-SUPPLEMENTS.json').read_bytes())
        assert set(supplements['pins']) == set(supplements['paths_relative_to_main_proof']) == {'dot_typing'}
        dot_typing = (M / supplements['paths_relative_to_main_proof']['dot_typing']).read_bytes()
        assert digest(dot_typing) == supplements['pins']['dot_typing']
        assert data['dot_seal']['files']['COMPLETED-DOT-TYPING-ONLY.smt2'] == digest(dot_typing)
        dot_forms = [f for f, _, _ in api['parse_spans'](dot_typing)]
        endpoint_forms = [f for f, _, _ in api['parse_spans'](raw['endpoint_typing'])]
        forms = merge_theory(api, [dot_forms, endpoint_forms, prepared['theory'], module.helper_definitions()])
        context = data['nf_prefix']['prefix']['inherited_prefix_source_context']
        assert digest(json.dumps(context, sort_keys=True, separators=(',', ':')).encode()) == module.CONTEXT_SHA
        assert context == exports['prefix_artifact']['inherited_prefix_source_context']
        assert context == origin_result['prefix']['bounded_source_context']
        assert context == data['endpoint_application']['application']['bounded_source_context']
        assert context == data['dot_prefix']['inherited_continuity_prefix']['inherited_prefix_source_context']
        provenance = {
            'endpoint': {'seal_sha256': digest(raw['endpoint_seal']), 'application_sha256': digest(raw['endpoint_application']),
                         'review_sha256': digest(raw['endpoint_review'])},
            'NF': {'seal_sha256': digest(raw['nf_seal']), 'prefix_sha256': digest(raw['nf_prefix'])},
            'origins': {'application_sha256': ORIGIN_RESULT_SHA, 'review_sha256': ORIGIN_REVIEW_SHA,
                        'input_envelope_sha256': origin_result['input_envelope_sha256']},
            'dot': {'seal_sha256': digest(raw['dot_seal']), 'prefix_sha256': digest(raw['dot_prefix']),
                    'typing_sha256': digest(dot_typing)}}
        if metadata_only:
            audit.HELPERS.update({Path(__file__).resolve(), audit_path})
            assert audit.HELPERS <= set(audit.READS)
            for path, expected in list(audit.READS.items()):
                assert digest(path.read_bytes()) == expected
            return {'metadata_only_passed': True, 'proof_initializers_called': 0, 'proof_nodes_constructed': 0,
                'new_native_jobs': 0, 'input_envelope_sha256': digest(envelope_path.read_bytes()),
                'merged_theory_forms': len(forms), 'source_contexts_identical': True,
                'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
                'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)}}, None
        proof = api['ValueProof'].__new__(api['ValueProof'])
        api['Proof'].__init__(proof, {})
        for name, original in proof.root_context.items():
            assert all(exports['context'][name][key] == value for key, value in original.items())
        proof.root_context = copy.deepcopy(context)
        language = api['SourceLanguage']()
        language.add(forms)
        for form in forms:
            if form[0] == 'declare-const':
                assert form[1] not in language.defs and form[1] not in language.decls
                language.decls[form[1]] = copy.deepcopy(form)
        for variable in [module.I, module.J]:
            assert variable not in language.defs and variable not in language.decls
            language.decls[variable] = ['declare-const', variable, 'Int']
        result = module.construct_composition(proof, language, exports, data, origin_result, prepared, steps, provenance)
        typing_forms = forms + [language.decls[v] for v in [module.I, module.J, module.W, module.RW]]
        typing_forms += [['assert', node['formula']] for node in proof.nodes]
        typing_forms += [['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
        typing = ('\n'.join(map(api['smt'], typing_forms)) + '\n').encode()
        type_path = P / 'source_typecheck.py'
        type_raw = type_path.read_bytes()
        assert digest(type_raw) == '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809'
        fs = [n for n in ast.parse(type_raw).body if isinstance(n, ast.FunctionDef) and n.name in ['sort', 'check']]
        namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
        exec(compile(ast.Module(body=fs, type_ignores=[]), str(type_path), 'exec'), namespace)
        typed = namespace['check'](typing)
        assert typed['assertions'] == len(proof.nodes)
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        for path, expected in list(audit.READS.items()):
            assert digest(path.read_bytes()) == expected
        return {'application': result, 'type_check': typed, 'typing_sha256': digest(typing),
            'accepted_component_provenance': provenance, 'input_envelope_sha256': digest(envelope_path.read_bytes()),
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'new_native_jobs': 0, 'old_parent_proof_reconstructions_called': 0,
            'independent_result_review_pending': True, 'numerical_RMS_proved': False,
            'exponent_scaling_proved': False, 'whole_device_theorem': False}, typing
    except BaseException as error:
        FAILURE = {'error': repr(error), 'partial_nodes': copy.deepcopy(proof.nodes) if proof is not None else [],
            'active_indices': copy.deepcopy(proof.active_indices) if proof is not None else {},
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())} if audit is not None else {},
            'new_native_jobs': 0, 'result_qualified': False}
        raise
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = old_path
        for name in set(sys.modules) - set(old_modules):
            del sys.modules[name]
        sys.modules.update(old_modules)


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--metadata-only'])
    name = 'CAPTURE-ROW-METADATA-R1' if sys.argv[1:] else 'CAPTURE-ROW-APPLICATION-R1'
    assert not any((HERE / (name + suffix)).exists() for suffix in ['.json', '-STOPPED.json', '-TYPING-ONLY.smt2'])
    def save(suffix, raw):
        with (HERE / (name + suffix)).open('xb') as output:
            output.write(raw)
    try:
        result, typing = construct(bool(sys.argv[1:]))
    except BaseException:
        save('-STOPPED.json', (json.dumps(FAILURE, indent=2, sort_keys=True) + '\n').encode())
        raise
    save('.json', (json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    if typing is not None:
        save('-TYPING-ONLY.smt2', typing)
    print(json.dumps({'metadata_only': bool(sys.argv[1:]),
        'new_nodes': len(result.get('application', {}).get('nodes', [])), 'new_native_jobs': 0}))

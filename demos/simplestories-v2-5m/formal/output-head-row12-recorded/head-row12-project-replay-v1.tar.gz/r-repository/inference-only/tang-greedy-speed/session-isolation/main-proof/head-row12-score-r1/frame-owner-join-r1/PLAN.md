# Same original head owner and the saved FRAME RMS record

The three source owner checks passed first-attempt UNSAT. Their exact result
review is a dependency of this next batch's launch. This additive three-query
gate supplies the one demonstrated temporal gap: a completed FRAME certificate
retains its original NF record even when current NF later changes. Neither the
old LOAD-only stability leaf nor a current-NF substitution supplies that join.

Define one nondriving relation hf-I on the already fixed HS, FRAME and CERT:
live J, stored job7, active FRAME and valid CERT imply a valid HS and equality
of the six protected fields of HS.nf and CERT.nf. It introduces no new record,
UID, source event, numerical input or driving state. All original recurrences
and initial values are retained. It must be established by base/preservation,
not assumed at row completion. Correct physical payload after cancellation
does not grant publication authority.

Three exact queries are prepared in dependency order:

1. H/reset-low establishes hf-I for original frame-zero/frc-zero.
2. Both H endpoints/all452 T, independently qualified current/successor
   frame-I and hs-I, original current frc-I, and current hf-I establish the
   next hf-I through literal frame-next/frc-next/hs-next. The next columns and
   JobHistory are arbitrary arguments of independently qualified frame-I, so
   no convenient future control value or health filter is supplied. Native
   source and the existing FRAME phase relation must show that an active head
   FRAME cannot receive a new unrelated HS capture. A new job/drop invalidates
   the old certificate; first head write captures the current original NF.
3. A combined small consequence proves (a) clock nf-t=n-1 gives nf-t+1=n and
   identifies actual hs-next with generic-next at n, and (b) the actual current
   D/J physical exponent registers equal CERT.nf.exp when H, frame-I, hs-I,
   hf-I and the actual live/head/active/valid FRAME guard hold. The actual
   source FrameJoinView is used. This does not require successful future use.

No query assumes its desired saved exponent, current NF=CERT.nf after completion,
head occurrence, selector tuple or second state sort. The typed finite-prefix
application remains separate: bind the actual original HS recurrence, original
NF/FRAME/CERT providers, all bounds and the original saved R0 at k/j. The clock
comes from the already qualified original NF stamp proof, not an extra trace
assumption. Original snapshot/UID/STEP parent/prefix precede every word.

Exact independent input review must precede execution. Three first attempts,
one owned worker, 4 GiB sampled RSS/footprint/internal memory4096, actual normal
Darwin pressure, accepted guard/probe reuse. No new probes, simulation, build,
wall/CPU/token kill, RAM floor or simulator slot. Stop dependents and preserve
every failure, raw log, receipt and partial proof. Further useful revised
diagnostics or obligations require a new small reviewed additive batch under
the parent budget clarification, not an unrecorded retry or weakened guard.

The downstream registered read, matching fixed-image metadata, postscale,
held score and actual selector admission remain active work. Upstream numerical
RMS is separate. No Lean, public, board, other-row or whole-device claim follows.

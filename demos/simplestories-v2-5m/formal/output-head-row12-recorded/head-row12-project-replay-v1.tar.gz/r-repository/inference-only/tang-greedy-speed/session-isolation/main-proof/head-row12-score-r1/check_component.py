"""Closed read-only original-RMS exponent component replay. No engine capability."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import contextlib
import copy
import datetime
import hashlib
import json
import math
import os
import re
import symtable
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
M = HERE.parent
L = M / 'head-mode-ownership-r1/frame-join-pilot/certificate-trace-application-r2'
SCOPE = 'c070-original-saved-RMS-exponent-through-head-and-row12-snapshot'
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def check():
    assert sys.version_info[:2] == (3, 12) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    audit = None
    try:
        audit_path = L / 'check_nf_component.py'
        audit = load('_closed_head_exponent_audit', audit_path, '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33')
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'FROZEN-EXPONENT-COMPONENT.json'
        env = json.loads(env_path.read_bytes())
        assert env['accepted'] is True and env['scope'] == SCOPE
        pins = {Path(p): v for p, v in env['files'].items()}
        assert all(p.is_absolute() and not p.is_symlink() and digest(p.read_bytes()) == v for p, v in pins.items())
        assert pins[Path(__file__).resolve()] == env['checker_sha256']
        assert pins[HERE / 'COMPONENT-REPLAY-REVIEW.md'] == env['review_sha256']
        assert pins[HERE / 'THEOREM.md'] == env['theorem_sha256']
        native = load('_closed_head_exponent_native', HERE / 'check_native_leaves.py', pins[HERE / 'check_native_leaves.py']).check()
        assert native['passed'] and native['native_leaves'] == 12 and native['new_native_jobs'] == native['writes'] == 0
        assert (json.dumps(native, indent=2, sort_keys=True) + '\n').encode() == (HERE / 'CHECK-NATIVE-LEAVES.json').read_bytes()
        reconstructed = []
        for folder, driver, result, count, review in [
            ('exponent-application-r1', 'run_application.py', 'APPLICATION-R1', 96, 'be0b442731644ee005f7cf71058d9fbda3cd87095c5f7d8b9ee545fb1f366188'),
            ('exponent-consequence-r1', 'run_consequence.py', 'CONSEQUENCE-R1', 131, env['consequence_result_review_sha256'])]:
            h = HERE / folder
            assert digest((h / 'RESULT-REVIEW.md').read_bytes()) == review
            module = load('_closed_head_exponent_' + str(count), h / driver, pins[h / driver])
            fresh, typing = module.construct()
            saved_bytes = (h / (result + '.json')).read_bytes()
            assert (json.dumps(fresh, indent=2, sort_keys=True) + '\n').encode() == saved_bytes
            assert fresh == json.loads(saved_bytes) and typing == (h / (result + '-TYPING-ONLY.smt2')).read_bytes()
            assert len(fresh['application']['nodes']) == count
            assert fresh['new_native_jobs'] == fresh['old_parent_proof_reconstructions_called'] == 0
            for path, value in fresh['actual_read_pins'].items():
                assert pins[Path(path)] == value
            for path, value in fresh['executed_helper_pins'].items():
                assert pins[Path(path)] == value
            reconstructed.append({'nodes': count, 'result_sha256': digest((h / (result + '.json')).read_bytes()),
                'typing_sha256': digest(typing), 'byte_identical': True})
        assert sum(r['nodes'] for r in reconstructed) == 227
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        assert set(audit.READS) | audit.HELPERS <= set(pins) | {env_path}
        for p, value in list(audit.READS.items()):
            assert digest(p.read_bytes()) == value
        return {'passed': True, 'scope': SCOPE, 'native_leaves': 12, 'new_proof_nodes_reconstructed': 227,
            'proof_and_typing_byte_identical': True, 'applications': reconstructed,
            'all_reads_and_helpers_frozen': True, 'new_native_jobs': 0, 'writes': 0,
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'original_saved_RMS_exponent_at_row_snapshot': True,
            'postscale_or_selector_score_proved': False, 'whole_device_theorem': False}
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    result = check()
    print(json.dumps({k: result[k] for k in ['passed', 'scope', 'native_leaves', 'new_proof_nodes_reconstructed',
        'proof_and_typing_byte_identical', 'new_native_jobs', 'writes', 'postscale_or_selector_score_proved', 'whole_device_theorem']}))

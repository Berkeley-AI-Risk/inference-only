"""Cheap accepted export/schema loader. No constructors, replays or engines."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast, builtins, hashlib, json, symtable, sys
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
P=HERE.parents[1]; ROOT=P.parent; REPO=ROOT.parents[3]
ROW=ROOT/'head-completed-model-dot-r1'
PRIVATE=REPO/'inference-only/hwic-hnlpu/private-simplestories-final-rms-frame-20261109-v1'
NF_REVIEW=Path('/proof/a-architecture/work/architecture-readiness/NF-PROVIDER-REVIEW.md')
READS={}
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def read(path):
    path=Path(path).resolve(); raw=path.read_bytes(); READS[str(path)]=sha(raw); return raw

def rd(path):return json.loads(read(path))

def sub(term,mapping):
    return mapping.get(term,term) if isinstance(term,str) else [sub(x,mapping) for x in term]

def atoms(term):
    return {term} if isinstance(term,str) else set().union(*(atoms(x) for x in term)) if term else set()

def _family(nodes,registry,context,name):
    index=registry[name]; node=nodes[index]
    assert node['id']==index and node['kind']=='ordinary-induction'
    step_index=node['fresh_step_index']; template=node['property_template']
    base=nodes[node['base_parent']]; step=nodes[node['step_parent']]
    bound=nodes[node['bound_parent']]; ih=nodes[node['scoped_IH']]
    assert node['parents']==[base['id'],step['id']]
    assert base['formula']==sub(template,{'@index':'1'})
    assert step['formula']==sub(template,{'@index':['+',step_index,'1']})
    assert ih['formula']==sub(template,{'@index':step_index})
    assert ih['kind']=='scoped-induction-hypothesis' and ih['scope']==step_index
    assert bound['kind']=='scoped-natural-index-domain' and bound['formula']==['<=','1',step_index]
    assert ih['parents']==[bound['id']]
    labels=set(node['discharged_support'])
    assert len(labels)==2 and labels==set(ih['support'])
    assert all(label.startswith(('IH:','INDEX:')) for label in labels)
    assert set(base['support'])<=set(context)
    assert set(step['support'])<=set(context)|labels
    assert set(node['support'])==(set(base['support'])|set(step['support']))-labels
    assert set(node['support'])<=set(context)
    assert step_index not in atoms(template) and step_index not in atoms(base['formula'])
    assert node['formula']==['forall',[*node['quantified_parameters'],[step_index,'Int']],
        ['=>',['<=','1',step_index],sub(template,{'@index':step_index})]]
    native=context['Gamma:actual-composed-source']['formal_native_consequences']
    fixed=context['Gamma:actual-composed-source']['free_parameters']
    for parameter,_ in node['quantified_parameters']:
        assert parameter not in atoms(native) and parameter not in fixed
    return node

def load_parent_exports():
    """Return context/helper_theory/selectedglobals/observerdefs/provenance and NF/API preflight."""
    READS.clear()
    raw=read(ROOT/'HEAD-COMPLETED-MODEL-DOT-R1-SEALED.json')
    assert sha(raw)=='c5591f6f05aa192edc891e8a6888e43895cc1d9b00a11eb067a0995d4c23b99e'
    seal=json.loads(raw)
    def sealed(name):
        value=read(ROW/name); assert sha(value)==seal['files'][name],name; return value
    source_raw=sealed('CONTINUITY-SOURCE-APPLICATION-DRAFT.json')
    prefix_raw=sealed('CONTINUITY-PREFIX-APPLICATION-DRAFT.json')
    source=json.loads(source_raw); prefix=json.loads(prefix_raw)
    completed=json.loads(sealed('COMPLETED-DOT-APPLICATION-DRAFT.json'))
    checked=json.loads(sealed('CHECK-COMPLETED-DOT.json'))
    frozen=sealed('FROZEN-INPUTS.json'); acceptance=sealed('REVIEW-ACCEPTED.json')
    external=json.loads(sealed('EXTERNAL-PINS.json'))
    theory_raw=sealed('CONTINUITY-SOURCE-TYPING-ONLY.smt2')
    assert sha(source_raw)=='2fc7ab19a0936bae6ca50d2effe3d5d1c1e01ba6af480cfeb5a86a0808393e5f'
    assert sha(prefix_raw)=='17869f35160747f7b14013f4c4e43414171258321c14c275d29136559e336553'
    assert sha(frozen)=='918c9f3a1a0b126a924ffb37adbf51b97148dba9b355989ba741fedf111bccab'
    assert sha(acceptance)=='3d57314a5956b3c6ae85b6a439ab42569cabca3da13f6568ca30a9eaa6d34cb2'
    assert checked['passed'] and checked['bounded_selected_completed_model_dot_qualified']
    assert checked['frozen_closure_checked'] and checked['independent_reviews_bound']
    support_names=completed['binding']['source_supports']
    assert checked['source_supports']==support_names
    terms_path=ROOT/'head-row-accumulation-r2/row_terms.py'
    terms_raw=read(terms_path); assert sha(terms_raw)==external[str(terms_path.relative_to(ROOT))]
    terms=type(sys)('accepted_row_terms')
    exec(compile(terms_raw,str(terms_path),'exec'),terms.__dict__)
    scoped_path=ROOT/'head-model-weight-trace-certificate-r1/scoped_induction.py'
    scoped_raw=read(scoped_path); assert sha(scoped_raw)==external[str(scoped_path.relative_to(ROOT))]
    scoped_tree=ast.parse(scoped_raw)
    proof_ast=next(n for n in scoped_tree.body if isinstance(n,ast.ClassDef) and n.name=='Proof')
    init_ast=next(n for n in proof_ast.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
    root_assignment=next(n for n in init_ast.body if isinstance(n,ast.Assign) and
        any(isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id=='self' and t.attr=='root_context' for t in n.targets))
    # Evaluate only the original literal root-context expression; no Proof constructor.
    context=eval(compile(ast.Expression(root_assignment.value),str(scoped_path),'eval'),terms.__dict__)
    memory_path=ROOT/'head-model-weight-trace-certificate-r1/MEMORY-TRACE-CONTEXT-DRAFT.json'
    memory_raw=read(memory_path); assert sha(memory_raw)==external[str(memory_path.relative_to(ROOT))]
    memory=json.loads(memory_raw)
    original=context['Gamma:actual-composed-source']
    specialization=memory['declared_entry_and_source_domain']['projection']['restricted_actual_source_event_specialization']
    assert original['formal_native_consequences']==specialization['source_specialization_inference']['conclusion']
    original['published_memory_source_domain']=memory['boundaries']['Gamma:actual-composed-source']
    for name,value in memory['boundaries'].items():
        if name!='Gamma:actual-composed-source':context[name]=value
    assert set(context)==set(support_names)
    assert set(context)=={'Gamma:actual-composed-source','Gamma:entry-reset-low-at-0',
        'Gamma:entry-reset-low-at-1','Gamma:runtime-entry-image','Gamma:static-metadata','Gamma:vendor-storage'}
    nodes=source['nodes']; registry=source['global_nodes']; assert len(nodes)==1544
    for index,node in enumerate(nodes):
        assert node['id']==index and all(isinstance(p,int) and 0<=p<index for p in node['parents'])
        support=set(node['introduced_support'])
        for parent in node['parents']:support.update(nodes[parent]['support'])
        support-=set(node.get('discharged_support',[]))
        assert support==set(node['support']),(index,'support')
    selected={}
    for name,expected in [('control',779),('actual-capture',1051),('actual-frame',1232)]:
        assert registry[name]==expected
        node=_family(nodes,registry,context,name)
        bounded=(prefix['earlier_bounded_consequences'] if name=='control' else prefix['bounded_consequences'])[name]
        binder=bounded[1][-1]; assert binder[1]=='Int'
        assert bounded==['forall',[*node['quantified_parameters'],binder],['=>',
            ['and',['<=','1',binder[0]],['<=',binder[0],'N']],sub(node['property_template'],{'@index':binder[0]})]]
        selected[name]={'node_id':expected,'node':node,'bounded_formula':bounded}
    assert set(selected['control']['node']['support'])==set(context)
    assert set(selected['actual-frame']['node']['support'])==set(context)
    assert set(selected['actual-capture']['node']['support'])=={'Gamma:actual-composed-source','Gamma:entry-reset-low-at-0'}
    observerdefs={'columns':prefix['inherited_controller_definitions_on_prefix']['columns'],
        'additional':prefix['additional_same_trace_observer_definitions_on_prefix']}
    assert observerdefs['columns']['zero_at_1']==['=',['COLUMNS','1'],'columns-zero']
    assert observerdefs['additional'][0]==['=',['CAPTURE','1'],['capture-zero',['A','1']]]
    assert observerdefs['additional'][2]==['=',['FRAME','1'],['frame-zero','unused-frame']]
    parser_raw=read(P/'support.py')
    assert sha(parser_raw)=='898af07523f801c69d9806fe878cc5863552edb78e288e616778de1de729d130'
    parser=type(sys)('accepted_export_parser'); parser.__file__=str(P/'support.py')
    exec(compile(parser_raw,parser.__file__,'exec'),parser.__dict__)
    theory=[node for node,_,_ in parser.parse_spans(theory_raw)
        if node[0] in ['declare-sort','declare-fun','declare-datatypes','declare-datatype','define-fun']]
    helper_map={node[1]:node for node in theory if node[0] in ['define-fun','declare-fun']}
    frame_path=ROOT/'head-activation-frame-join-r1/SOURCE-BINDING.json'
    assert sha(read(frame_path))==external[str(frame_path.relative_to(ROOT))]
    frame=rd(frame_path)
    compared_helpers=[]; unused_helpers=[]
    for node in [*frame['prior_column_helpers'],*frame['prior_control_helpers'],*frame['capture_helpers'],*frame['frame_helpers']]:
        if node[0]=='define-fun':
            if node[1] in helper_map:
                assert helper_map[node[1]]==node,('helper',node[1]); compared_helpers.append(node[1])
            else:unused_helpers.append(node[1])
    assert {'columns-I','current-job-I','capture-inv','job-inv','frame-I','columns-next','capture-next','frame-next','capture-zero','frame-zero'}<=set(compared_helpers)
    api_specs={
        'head-model-weight-trace-certificate-r1/scoped_induction.py':('Proof',['__init__','add','source','open_index','rewrite','close_induction']),
        'head-model-weight-trace-certificate-r1/value_trace_application.py':('ValueProof',['mp','conjunction','trace_instance','globalize']),
        'head-model-weight-owner-trace-r1/owner_source.py':(None,['derive']),
        'head-completed-model-dot-r1/continuity_source.py':(None,['construct'])}
    api_metadata={}; api_trees={}
    for relative,(class_name,names) in api_specs.items():
        value=read(ROOT/relative)
        expected=seal['files'][relative.removeprefix(ROW.name+'/')] if relative.startswith(ROW.name+'/') else external[relative]
        assert sha(value)==expected,relative
        tree=ast.parse(value)
        scope=tree.body if class_name is None else next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==class_name).body
        functions={n.name:n for n in scope if isinstance(n,ast.FunctionDef)}
        assert set(names)<=set(functions)
        api_trees[relative]=tree
        api_metadata[relative]={'sha256':sha(value),'functions':{name:[a.arg for a in functions[name].args.args] for name in names}}
        if relative.endswith('continuity_source.py'):
            close=next(n for n in functions['construct'].body if isinstance(n,ast.FunctionDef) and n.name=='close')
            assert [a.arg for a in close.args.args]==['name','template','base','step','index','ih','parameters']
            api_metadata[relative]['parameterized_close_ast_sha256']=sha(ast.dump(close,include_attributes=False).encode())
    namespace=dict(terms.__dict__)
    namespace.update(atoms=parser.atoms,smt=parser.smt,parse_spans=parser.parse_spans)
    replace_ast=next(n for n in scoped_tree.body if isinstance(n,ast.FunctionDef) and n.name=='replace_exact')
    exec(compile(ast.Module(body=[replace_ast,proof_ast],type_ignores=[]),str(scoped_path),'exec'),namespace)
    proof_class=namespace['Proof']
    value_relative='head-model-weight-trace-certificate-r1/value_trace_application.py'
    value_ast=next(n for n in api_trees[value_relative].body if isinstance(n,ast.ClassDef) and n.name=='ValueProof')
    namespace['scoped_induction']=type('ExistingScopedModule',(),{'Proof':proof_class})
    exec(compile(ast.Module(body=[value_ast],type_ignores=[]),str(ROOT/value_relative),'exec'),namespace)
    owner_relative='head-model-weight-owner-trace-r1/owner_source.py'
    derive_ast=next(n for n in api_trees[owner_relative].body if isinstance(n,ast.FunctionDef) and n.name=='derive')
    exec(compile(ast.Module(body=[derive_ast],type_ignores=[]),str(ROOT/owner_relative),'exec'),namespace)
    continuity_relative='head-completed-model-dot-r1/continuity_source.py'
    construct_ast=next(n for n in api_trees[continuity_relative].body if isinstance(n,ast.FunctionDef) and n.name=='construct')
    close_ast=next(n for n in construct_ast.body if isinstance(n,ast.FunctionDef) and n.name=='close')
    def close_factory(proof):
        scoped_namespace=dict(namespace); scoped_namespace['proof']=proof
        exec(compile(ast.Module(body=[close_ast],type_ignores=[]),str(ROOT/continuity_relative),'exec'),scoped_namespace)
        return scoped_namespace['close']
    language_path=ROOT/'head-model-weight-source-join-r1/boolean_application.py'
    language_raw=read(language_path); assert sha(language_raw)==external[str(language_path.relative_to(ROOT))]
    language_tree=ast.parse(language_raw)
    alpha_ast=next(n for n in language_tree.body if isinstance(n,ast.FunctionDef) and n.name=='alpha')
    language_ast=next(n for n in language_tree.body if isinstance(n,ast.ClassDef) and n.name=='SourceLanguage')
    exec(compile(ast.Module(body=[alpha_ast,language_ast],type_ignores=[]),str(language_path),'exec'),namespace)
    typing_path=ROW/'source_typecheck.py'; typing_raw=sealed('source_typecheck.py')
    old_support=sys.modules.get('support'); sys.modules['support']=parser
    try:
        checker=type(sys)('accepted_export_typechecker'); checker.__file__=str(typing_path)
        exec(compile(typing_raw,str(typing_path),'exec'),checker.__dict__)
    finally:
        if old_support is None:sys.modules.pop('support',None)
        else:sys.modules['support']=old_support
    typing_build_path=ROW/'source_typing.py'; typing_build_raw=sealed('source_typing.py')
    typing_build_tree=ast.parse(typing_build_raw)
    typing_build_ast=next(n for n in typing_build_tree.body if isinstance(n,ast.FunctionDef) and n.name=='build')
    namespace['source_typecheck']=checker
    exec(compile(ast.Module(body=[typing_build_ast],type_ignores=[]),str(typing_build_path),'exec'),namespace)
    required_functions=[replace_ast,derive_ast,close_ast,typing_build_ast]
    required_functions += [n for n in proof_ast.body if isinstance(n,ast.FunctionDef) and n.name in
        ['__init__','source','add','index_support','index_parents','open_index','rewrite']]
    required_functions += [n for n in value_ast.body if isinstance(n,ast.FunctionDef) and n.name in ['mp','conjunction']]
    required_globals={}
    for function_ast in required_functions:
        table=symtable.symtable(ast.unparse(ast.Module(body=[function_ast],type_ignores=[])),str(scoped_path),'exec')
        found=set()
        def visit_scope(scope):
            for symbol in scope.get_symbols():
                if symbol.is_referenced() and symbol.is_global():found.add(symbol.get_name())
            for child in scope.get_children():visit_scope(child)
        visit_scope(table)
        available=dict(namespace); available['proof']=None
        assert all(name in available or hasattr(builtins,name) for name in found),(function_ast.name,sorted(found-set(available)))
        required_globals[function_ast.name]=sorted(found)
    api_metadata['selected_method_referenced_globals']=required_globals
    api_metadata['replace_exact_ast_sha256']=sha(ast.dump(replace_ast,include_attributes=False).encode())
    apis={name:namespace[name] for name in ['c','AND','NOT','eq','IMP','SUB','atoms','smt','parse_spans','replace_exact','derive','Proof','ValueProof','SourceLanguage']}
    apis['typing_build']=namespace['build']; apis['typecheck']=checker.check
    apis['close_factory']=close_factory
    assert sha(read(NF_REVIEW))=='91e612d5f9a328b4dcb1bf867e0d9b2263374d537ab6684df24d24b76d95840f'
    result_raw=read(PRIVATE/'RESULT.json')
    assert sha(result_raw)=='82eec2d2d15b7b27a86cf3658e4416a3cf341172bb8e395ae6944a4d971c5ddd'
    result=json.loads(result_raw)
    provider={'review_sha256':READS[str(NF_REVIEW.resolve())],'goals':{},'helpers':None,'records':{}}
    native=read(ROOT/'rmsnorm-pilot/model-consumption/connected/native.smt2')
    assert sha(native)=='c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
    assert external['rmsnorm-pilot/model-consumption/connected/native.smt2']==sha(native)
    native_forms=[node for node,_,_ in parser.parse_spans(native)]
    native_map={node[1]:node for node in native_forms if node[0] in ['declare-sort','declare-fun','define-fun']}
    theory_map={node[1]:node for node in theory if node[0] in ['declare-sort','declare-fun','define-fun']}
    # The sealed typing specimen is a dependency slice; add only the same pinned
    # complete native definitions when a getter was unused by the old row proof.
    for node in native_forms:
        assert node[0] in ['declare-sort','declare-fun','define-fun']
        if node[1] in theory_map:assert theory_map[node[1]]==node,('native theory',node[1])
        else:theory.append(node); theory_map[node[1]]=node
    for name in ['reset-base','preservation']:
        entry=result['proofs'][name]
        assert set(entry)=={'query','receipt','log','result','literal_native_T_conjuncts'}
        assert entry['result']=='unsat' and entry['literal_native_T_conjuncts']==452
        expected_queries={'reset-base':'8569d5bb3c5d8d9f8446cc611d09ae6fd8160e653a42414d0cc52943c6b290cb',
            'preservation':'5acb6e3dc012e2ec00e92eee9c46fa2f59e2528b4d495f2619b5ec7db0362fc3'}
        assert entry['query']['sha256']==expected_queries[name]
        blobs={}
        for field in ['query','receipt','log']:
            pin=entry[field]; value=read(pin['path'])
            assert len(value)==pin['bytes'] and sha(value)==pin['sha256']
            blobs[field]=value
        receipt=json.loads(blobs['receipt'])
        assert receipt['native_exit']==0 and receipt['resource_stop_reason'] is None and receipt['monitor_errors']==[]
        forms=[node for node,_,_ in parser.parse_spans(blobs['query'])]
        assertions=[node for node in forms if node[0]=='assert']
        assert len(assertions)==1 and assertions[0][1][0]=='not'
        provider['goals'][name]=assertions[0][1][1]
        for node in forms:
            if node[0] in ['declare-sort','declare-fun','define-fun'] and node[1].startswith('|core_workflow_control'):
                assert native_map[node[1]]==node and theory_map[node[1]]==node
        helpers=[node for node in forms if node[0]=='declare-datatypes' or node[0]=='define-fun' and node[1] in ['nf-zero','nf-next','nf-I']]
        if provider['helpers'] is None:provider['helpers']=helpers
        else:assert provider['helpers']==helpers
        assert [node for node,_,_ in parser.parse_spans(blobs['log'])][0]=='unsat'
        provider['records'][name]=entry
    provenance={'seal_sha256':sha(raw),'source_dag_sha256':sha(source_raw),'prefix_sha256':sha(prefix_raw),
        'final_check_sha256':READS[str((ROW/'CHECK-COMPLETED-DOT.json').resolve())],
        'frozen_sha256':sha(frozen),'acceptance_sha256':sha(acceptance),
        'all_six_source_roots_preserved':True,'no_constructor_or_replay_called':True,
        'compared_literal_helpers':compared_helpers,'unused_typing_slice_helpers':unused_helpers}
    return {'context':context,'helper_theory':theory,'selectedglobals':selected,'observerdefs':observerdefs,
        'provenance':provenance,'nf_provider':provider,'apis':apis,'api_metadata':api_metadata,'serialized_nodes':nodes,
        'serialized_global_registry':registry,'prefix_artifact':prefix,'read_pins':dict(READS)}

if __name__=='__main__':
    exports=load_parent_exports()
    report={k:exports[k] for k in ['context','selectedglobals','observerdefs','provenance','api_metadata']}
    report.update(NF_required_metadata_schema_preflight_passed=True,serialized_node_count=len(exports['serialized_nodes']),helper_theory_forms=len(exports['helper_theory']))
    (HERE/'ACCEPTED-EXPORT-PREFLIGHT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    pins=dict(exports['read_pins']); pins[str(Path(__file__).resolve())]=sha(Path(__file__).read_bytes())
    (HERE/'ACCEPTED-EXPORT-READ-PINS.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'selectedglobals':{n:v['node_id'] for n,v in exports['selectedglobals'].items()},
        'serialized_node_count':len(exports['serialized_nodes']),'NF_metadata_preflight':True,'constructors_or_replays_called':0}))

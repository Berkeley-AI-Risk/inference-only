"""Read-only fixed current/row exponent consequence driver; no engines."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
M = C.parent
P = M / 'head-mode-ownership-r1'
L = P / 'frame-join-pilot/certificate-trace-application-r2'
S = L / 'step-rms-origin-application-r1'
SCOPE = 'same-original-current-frame-and-row12-saved-RMS-exponent'
INPUTS = {'run_consequence.py', 'saved_exponent.py', 'consequence_audit.py', 'PLAN.md', 'INPUT-REVIEW.md', 'RAW-INPUTS.json'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
FAILURE = None


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def construct(metadata_only=False):
    global FAILURE
    FAILURE = None
    proof, audit = None, None
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        assert type(metadata_only) is bool
        assert sys.version_info[:2] == (3, 12) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
        audit_path = L / 'check_nf_component.py'
        audit = load('_saved_exp_readonly_audit', audit_path, '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33')
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'ACCEPTED-INPUTS.json'
        envelope = json.loads(env_path.read_bytes())
        assert envelope['accepted'] is True and envelope['scope'] == SCOPE and set(envelope['files']) == INPUTS
        for name, expected in envelope['files'].items():
            p = HERE / name
            assert p.is_file() and not p.is_symlink() and digest(p.read_bytes()) == expected
        raw_manifest = json.loads((HERE / 'RAW-INPUTS.json').read_bytes())
        assert set(raw_manifest) == {'paths_relative_to_main_proof', 'pins', 'helper_paths_relative_to_main_proof', 'helper_pins'}
        def read_inputs(paths, pins):
            assert set(paths) == set(pins)
            values = {}
            for name, relative in paths.items():
                p = (M / relative).resolve()
                assert p.is_relative_to(M) and not p.is_symlink()
                values[name] = p.read_bytes()
                assert digest(values[name]) == pins[name]
            return values
        raw = read_inputs(raw_manifest['paths_relative_to_main_proof'], raw_manifest['pins'])
        def helper(name):
            return load('_saved_exp_' + name, M / raw_manifest['helper_paths_relative_to_main_proof'][name], raw_manifest['helper_pins'][name])
        exports = load('_saved_exp_exports', L / 'accepted_exports_r3.py', '2bc78867ebf370b0cf6f32c6ddf7e15e1f129f49db1764a7b88acc7b1d9bb082').load_parent_exports()
        origin_module, fixed, old_driver, steps = [helper(name) for name in ['origins', 'fixed', 'old_driver', 'steps']]
        original_manifest_path = S / 'RAW-INPUTS.json'
        original_manifest_raw = original_manifest_path.read_bytes()
        assert digest(original_manifest_raw) == raw_manifest['pins']['old_raw_manifest']
        original_manifest = json.loads(original_manifest_raw)
        original_raw = read_inputs(original_manifest['paths_relative_to_main_proof'], original_manifest['pins'])
        origin_prepared = origin_module.prepare_metadata(exports, original_raw, original_manifest)
        data = {k: json.loads(v) for k, v in original_raw.items() if original_manifest['paths_relative_to_main_proof'][k].endswith('.json')}
        for name, value in raw.items():
            if raw_manifest['paths_relative_to_main_proof'][name].endswith('.json'):
                data[name] = json.loads(value)
        for seal, member, key in [
            ('endpoint_seal', 'frame-join-pilot/certificate-trace-application-r2/ENDPOINT-PROJECTION-APPLICATION-R1.json', 'endpoint_application'),
            ('dot_seal', 'COMPLETED-DOT-PREFIX-APPLICATION-DRAFT.json', 'dot_prefix'),
            ('row_guard_seal', 'frame-join-pilot/row-capture-guard-r1/ADJUDICATED-RESULT-R2.json', 'row_guard_result'),
            ('math_seal', 'frame-join-pilot/certificate-trace-application-r2/integer-order-gate-r1/INTEGER-ORDER-BINDING.json', 'math_binding')]:
            assert data[seal]['files'][member] == original_manifest['pins'][key]
        assert data['row_guard_result']['accepted'] and not data['row_guard_result']['original_wrapper_success_claimed']
        api = exports['apis']
        guard_forms = [f for f, _, _ in api['parse_spans'](original_raw['row_guard_query'])]
        assert [f[1] for f in guard_forms if f[0] == 'assert'] == [['not', data['row_guard_binding']['combined_goal']]]
        supplements_raw = (S / 'COMPOSITION-SUPPLEMENTS.json').read_bytes()
        assert digest(supplements_raw) == raw_manifest['pins']['old_supplements']
        supplements = json.loads(supplements_raw)
        dot_typing = read_inputs(supplements['paths_relative_to_main_proof'], supplements['pins'])['dot_typing']
        assert data['dot_seal']['files']['COMPLETED-DOT-TYPING-ONLY.smt2'] == digest(dot_typing)
        owner_forms = [f for f, _, _ in api['parse_spans'](raw['owner_typing'])]
        assert digest(raw['owner_typing']) == data['owner_application']['typing_sha256']
        forms = old_driver.merge_theory(api, [[f for f, _, _ in api['parse_spans'](dot_typing)],
            [f for f, _, _ in api['parse_spans'](original_raw['endpoint_typing'])],
            owner_forms, origin_prepared['theory'], fixed.helper_definitions()])
        context = data['owner_application']['prefix']['bounded_source_context']
        assert context == exports['prefix_artifact']['inherited_prefix_source_context']
        module = load('_saved_exp_application', HERE / 'saved_exponent.py', envelope['files']['saved_exponent.py'])
        checker = load('_saved_exp_deduction_audit', HERE / 'consequence_audit.py', envelope['files']['consequence_audit.py'])
        pins = {**original_manifest['pins'], **raw_manifest['pins']}
        prepared = module.prepare_metadata(exports, data, pins)
        if metadata_only:
            audit.HELPERS.update({Path(__file__).resolve(), audit_path})
            assert audit.HELPERS <= set(audit.READS)
            for p, expected in list(audit.READS.items()):
                assert digest(p.read_bytes()) == expected
            return {'metadata_only_passed': True, 'proof_initializers_called': 0, 'proof_nodes': 0, 'new_native_jobs': 0,
                'input_envelope_sha256': digest(env_path.read_bytes()), 'merged_theory_forms': len(forms),
                'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
                'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)}}, None
        proof = api['ValueProof'].__new__(api['ValueProof'])
        api['Proof'].__init__(proof, {})
        for name, original in proof.root_context.items():
            assert all(exports['context'][name][k] == v for k, v in original.items())
        proof.root_context = copy.deepcopy(context)
        language = api['SourceLanguage']()
        language.add(forms)
        for f in forms:
            if f[0] == 'declare-const':
                assert f[1] not in language.defs and f[1] not in language.decls
                language.decls[f[1]] = copy.deepcopy(f)
        for name in [module.I, module.N]:
            assert name not in language.defs and name not in language.decls
            language.decls[name] = ['declare-const', name, 'Int']
        application = module.construct(proof, language, exports, data, prepared, steps, fixed)
        deduction_check = checker.validate(application, data, prepared, forms, module)
        typing_forms = forms + [language.decls[v] for v in [module.I, module.N, module.W]]
        typing_forms += [['assert', n['formula']] for n in proof.nodes]
        typing_forms += [['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
        typing = ('\n'.join(map(api['smt'], typing_forms)) + '\n').encode()
        p = P / 'source_typecheck.py'
        type_raw = p.read_bytes()
        assert digest(type_raw) == '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809'
        fs = [f for f in ast.parse(type_raw).body if isinstance(f, ast.FunctionDef) and f.name in ['sort', 'check']]
        namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
        exec(compile(ast.Module(body=fs, type_ignores=[]), str(p), 'exec'), namespace)
        typed = namespace['check'](typing)
        assert typed['assertions'] == len(proof.nodes)
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        for p, expected in list(audit.READS.items()):
            assert digest(p.read_bytes()) == expected
        return {'application': application, 'deduction_check': deduction_check, 'type_check': typed,
            'typing_sha256': digest(typing), 'input_envelope_sha256': digest(env_path.read_bytes()),
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'new_native_jobs': 0, 'old_parent_proof_reconstructions_called': 0,
            'independent_result_review_pending': True, 'postscale_or_selector_score_proved': False,
            'whole_device_theorem': False}, typing
    except BaseException as error:
        FAILURE = {'error': repr(error), 'partial_nodes': copy.deepcopy(proof.nodes) if proof is not None else [],
            'active_indices': copy.deepcopy(proof.active_indices) if proof is not None else {},
            'scope_labels': sorted(proof.scope_labels) if proof is not None else [],
            'index_bindings': copy.deepcopy(proof.index_bindings) if proof is not None else {},
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())} if audit is not None else {},
            'executed_helper_pins': {str(k): audit.READS.get(k) for k in sorted(audit.HELPERS)} if audit is not None else {},
            'unread_executed_helper_paths': sorted(str(k) for k in audit.HELPERS - set(audit.READS)) if audit is not None else [],
            'new_native_jobs': 0, 'result_qualified': False}
        raise
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--metadata-only'])
    name = 'METADATA-R1' if sys.argv[1:] else 'CONSEQUENCE-R1'
    assert not any((HERE / (name + s)).exists() for s in ['.json', '-STOPPED.json', '-TYPING-ONLY.smt2'])
    def save(suffix, raw):
        with (HERE / (name + suffix)).open('xb') as output:
            output.write(raw)
    try:
        result, typing = construct(bool(sys.argv[1:]))
    except BaseException:
        save('-STOPPED.json', (json.dumps(FAILURE, indent=2, sort_keys=True) + '\n').encode())
        raise
    save('.json', (json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    if typing is not None:
        save('-TYPING-ONLY.smt2', typing)
    print(json.dumps({'metadata_only': bool(sys.argv[1:]), 'new_nodes': len(result.get('application', {}).get('nodes', [])), 'new_native_jobs': 0}))

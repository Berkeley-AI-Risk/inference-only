# Original saved RMS record through the actual row engine

This component verifies operand lineage for the c070 greedy head row12. During
later active physical row work, the actual scaling-engine exponent and all256
words of its retained input snapshot refer to the same original saved RMS
record. It supports the fixed-computation part of the inference-only argument;
it does not establish the complete inference-only restriction or an admitted
scaled score.

Consider one of the original qualified finite source prefixes0..N, N>=1. At a
defined observation1<=n<=N, suppose the selected row is physical, its admitted
count is positive, and actual E is in META/WEIGHTS/DRAIN/EMIT/DONE. Let
j=FRAMEORIGIN(n), the actual first-column snapshot event, and let
R0=endpoint-saved-NF(j), k=endpoint-capture-index(j). Then:

- 1<=j<n<=N; the retained ROWFRAME has the original row UID and episode.
- Actual E.activation_exponent_q at n equals R0.exp.
- For every BV8 word index w (all256 positions), ROWFRAME(n).data[zero_extend(w)]
  equals R0.data[w]. This concerns the saved complete input snapshot, including
  unconsumed positions; it does not equate arbitrary unconsumed rr-a entries.
- The original qualified STEP/RMS capture payload is preserved literally:
  R0=NF(k), with original STEP p and RMS r satisfying1<=p<r<k<j<n and their
  original event, retained-parent, prefix and UID conditions. No current NF is
  substituted after frame completion.

```mermaid
flowchart LR
  R["Original RMS output record R0 = NF(k)"]
  S["ROWFRAME snapshot captured at j"]
  E["Actual engine exponent at later n"]
  R -. "all256 word equalities" .-> S
  R -. "exponent equality" .-> E
  J["Original first-column observation j"] --> S
  J --> C["Fixed getter at j; physical continuity to n"] --> E
```

The dotted arrows denote proved value correspondences, not a proposed event
ordering or a later saved record causing an earlier register capture. The
proof first derives original j's bounds, then opens its actual source record
and qualified providers. EXP_AT is defined once as the actual E getter on the
same execution; it is not a supplied exponent oracle. Its past lookup is opened
only after1<=j<n<=N. Scalar identities are fixed before the arbitrary word.

The new portion has four accepted native source leaves and286 deduction nodes:
actual E/J capture-and-hold plus original-prefix induction31; complete current
head FRAME/R0 consequence104; existing ROW/origin exponent continuity19; and
original-row/R0/snapshot consequence132. The closed replay also reconstructs
the prior12-leaf/227-node component literally, for16 recorded native leaves and
513 deductions altogether. Its two inherited local read leaves remain local
source facts; no current model-dot/read application follows just from listing them.

All original source contracts and their named boundaries remain: the exact
c070 digital clock/reset/source profile, the two sampled-low entry conditions,
fixed runtime-entry model image/lifetime, static metadata/model and vendor
storage contracts, and the already qualified producer/history components.
This component identifies the actual saved RMS outputs; it does not newly prove
the upstream RMS numerical function, the remaining graph services, other rows
or another release. Snapshot provenance does not renew current output authority.

Current accumulator completion/read ownership, fixed-model metadata consumption
and signed exponent range, postscale arithmetic/held tuple, first-fault/CLEAR
classification and actual legal selector admission remain open. There is no
whole-device, board, public-release or Lean claim in this component.

# Actual E/J scalar exponent gate

Two exact source queries prepared under POSTSCALE-CONTINUATION-PLAN-R2 and
independent PLAN-REVIEW-R2 f1da2565. No engine or new Proof initializer has run.
One scalar invariant: actual J live and E phase META/WEIGHTS/DRAIN/EMIT/DONE
imply actual E.activation_exponent_q=J.activation_exponent_q.

Use the exact qualified control typing11ff55d9 bound by completed-dot seal
0752a099. Project selected-row-phase-I first8 of20 conjunctions, which depend
only on native state s. The original full qualified phase/control theorem must
supply that projection in the later ordinary application. Retain literal
current-job-I(a,columns) from the same qualified source, with actual history.
No desired E/J exponent, header, numerical output or successor control is
assumed. Every referenced old native getter is compared literally with c070.

Base uses H/current root reset-low. Preservation uses H(a),H(b),all452 T,
current qualified job/parent control and scalar IH only. The invariant's actual
J-live guard uses reset/no-CLEAR/no-integrated-failure; no arbiter-healthy or
Q-job guard is introduced, and no healthy successor filters a transfer claim.
Actual E reset/CLEAR/control_error/start/descriptor and J physical capture/hold
branches must discharge the query. The new invariant is control/data ownership,
not authority for retained canceled payload to publish.

Exact input review, freeze and pure preflight precede launch. Two first attempts,
one owned4GiB RSS/footprint/internal memory4096 worker, actual normal Darwin
pressure and pinned accepted guard/probe reuse. No new probes, wall/CPU/token
kill, fixed RAM floor, simulation, build, board, Lean or public action. An
unexpected answer saves its exact raw query/receipts and stops dependents;
diagnostic/revision requires another reviewed additive gate, never a blind retry.

Successful source leaves still need ordinary reset-founded finite-prefix
application with the qualified original providers, then the original current
R0/frame/UID relation. Read/model metadata/postscale/selector remain open.

"""Unrun single current-index CERT induction; no endpoint or past application.

Only the fixed genuine loader/API/light-proof caller reviewed for the import
and mode slice is supported. The caller owns raw reads, initialization, typing,
execution envelope and result review. No file/process/engine API is used here.
"""
if not __debug__:
    raise RuntimeError('Optimization forbidden')

from copy import deepcopy
from pathlib import Path
import ast
import hashlib
import json

PINS = {
    'Q': '0004bd2557a6cfa9cc6b331e649b3c9689ff81b961d3ad65e992b00a50213add',
    'S': '0cb68482a1c1b65d8d1267b350ef00624a32d249b408a5015fbe02d4241465e9',
    'Q_query': '77454c7dc5186b370bbe9516a702621e61bb6da61fda269dcd8d865ed1d85090',
    'S_query': 'b2c516b5169e86d7598b8377ef445b5fa66d0299f9d5e2e9bc4d9f87939dfada',
    'Q_results': '5cb10f219ce90d62c7579b2ef97d4d8a595623fa9268b1bd378683ef37bf1b5f',
    'Q_review': '61ea95d0da0657232681ec028ed17a5e5ef7241bda7ef8403582cf722fe33e67',
    'S_results': '7482cf9462b26c2b6511fe22f6888739eeae16946a3cddff3ee42f364a4ec822',
    'S_review': '1fe7a63c82e3ed5ce9f07cd2145bb3ed85555c2e8eacd082364c193295298f49',
    'frame_binding': '871878ab819c5dd6cac5c80ccf782261d3971faadad4ee81231f7f16855f21a2',
    'frame_seal': '1e696bea46432353bd56a20d183dc6a6f92a72206af4024c4e44d4057b861e84',
    'definition_source': 'afa3600de395fbccd72b0ed17db96a0972bd27a7b27aae50a5117fc4e4dd5258',
}
FAMILY = 'original-current-frame-RMS-certificate'
INDEX = 'n_current_frame'
WATCH = 'frc-watch'
MODE = 'original-current-head-mode'
GLOBALS = ('control', 'actual-capture', 'actual-frame', 'original-NF-provider', MODE)
PRIOR_NAMES = frozenset({'proved-native-retained-job', 'proved-protected-NF-leaf',
    'proved-pure-count-embedding', 'qualified-completed-frame-stability', 'sealed-accepted-word-event'})
Q_PARAMETERS = frozenset({'view', 'next-view', 'frame', 'nf', 'next-nf', 'certificate',
    'observation', 'watch', 'position', 'empty-frame', 'empty-nf'})
S_PARAMETERS = frozenset({'a', 'b', 'columns', 'capture', 'frame', 'nf', 'certificate',
    'observation', 'watch', 'nf-unused-frame', 'frame-unused'})
TOTAL_NODE_BUDGET = 256
RAW_PATHS = {
    'Q': 'head-mode-ownership-r1/frame-join-pilot/certificate-prefix-r1/CONSTRUCTION.json',
    'S': 'head-mode-ownership-r1/frame-join-pilot/certificate-source-application-r1/SOURCE-BINDING.json',
    'Q_query': 'head-mode-ownership-r1/frame-join-pilot/certificate-prefix-gate-r1/generic-certificate-zero-step.smt2',
    'S_query': 'head-mode-ownership-r1/frame-join-pilot/certificate-closure-gate-r1/actual-source-to-certificate-interface.smt2',
    'Q_results': 'head-mode-ownership-r1/frame-join-pilot/certificate-prefix-gate-r1/RESULTS.json',
    'Q_review': 'head-mode-ownership-r1/frame-join-pilot/certificate-prefix-gate-r1/RESULT-REVIEW.md',
    'S_results': 'head-mode-ownership-r1/frame-join-pilot/certificate-closure-gate-r1/RESULTS.json',
    'S_review': 'head-mode-ownership-r1/frame-join-pilot/certificate-closure-gate-r1/RESULT-REVIEW.md',
    'frame_binding': 'head-activation-frame-join-r1/SOURCE-BINDING.json',
    'frame_seal': 'HEAD-ACTIVATION-FRAME-JOIN-R1-SEALED.json',
    'definition_source': 'head-completed-model-dot-r1/proof_logic.py',
}


def api_contract():
    """Fixed driver requirements; this is not a proof or an input acceptance."""
    return deepcopy({'raw_paths_relative_to_main_proof': RAW_PATHS, 'raw_pins': PINS,
        'metadata_preflight': 'prepare_metadata(exports,raw_inputs) before Proof.__init__',
        'construction': 'construct_current_certificate(proof,language,exports,import_report,mode_application,raw_inputs)',
        'existing_callable_API_keys': ['c', 'eq', 'AND', 'IMP', 'NOT', 'SUB', 'atoms', 'derive', 'close_factory', 'parse_spans'],
        'existing_proof_methods': ['add', 'source', 'trace_instance', 'open_index', 'index_support', 'index_parents', 'mp', 'conjunction', 'rewrite'],
        'new_definition_helper': 'exact proof_logic.definition AST with globals c/eq/SUB only',
        'fixed_parameter_declarations': 'original pinned typing declare-consts, including model and unused-frame',
        'new_free_constants_for_typing': [[INDEX, 'Int'], [WATCH, ['_', 'BitVec', '8']]],
        'source_scope': 'full six-root original composed trace, one current CERT induction; no endpoint/past',
        'combined_node_cap': TOTAL_NODE_BUDGET, 'native_jobs': 0})


class CertificateApplicationGap(AssertionError):
    """Exact first missing rule/premise; caller saves it without retry/weakening."""
    def __init__(self, stage, target, detail):
        self.failure = {'stage': stage, 'target': deepcopy(target), 'detail': detail}
        super().__init__(self.failure)


def _canon(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def _definition_api(api, raw):
    # Compile only the unchanged existing function AST, not its importing module
    # or global derive initializer. Its globals are the exact accepted macros.
    tree = ast.parse(raw)
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'definition')
    namespace = {name: api[name] for name in ['c', 'eq', 'SUB']}
    filename = str(Path(__file__).parents[3] / RAW_PATHS['definition_source'])
    exec(compile(ast.Module(body=[function], type_ignores=[]), filename, 'exec'), namespace)
    return namespace['definition'], hashlib.sha256(ast.dump(function, include_attributes=False).encode()).hexdigest()


def prepare_metadata(exports, raw_inputs):
    """Pure metadata/API checks callable before even the lightweight initializer."""
    assert set(raw_inputs) == set(PINS)
    for name, expected in PINS.items():
        assert hashlib.sha256(raw_inputs[name]).hexdigest() == expected, name
    json_names = {'Q', 'S', 'Q_results', 'S_results', 'frame_binding', 'frame_seal'}
    data = {name: json.loads(raw_inputs[name]) for name in json_names}
    q, s = data['Q'], data['S']
    api = exports['apis']
    needed = {'c', 'eq', 'AND', 'IMP', 'NOT', 'SUB', 'atoms', 'derive', 'close_factory', 'parse_spans'}
    assert needed <= set(api) and all(callable(api[name]) for name in needed)
    assert data['frame_seal']['files']['SOURCE-BINDING.json'] == PINS['frame_binding']
    for key, name in [('Q', 'generic-certificate-zero-step'), ('S', 'actual-source-to-certificate-interface')]:
        receipt = next(row for row in data[key + '_results']['results'] if row['name'] == name)
        assert receipt['answer'] == 'unsat' and receipt['query_sha256'] == PINS[key + '_query']
    q_forms = [node for node, _, _ in api['parse_spans'](raw_inputs['Q_query'])]
    s_forms = [node for node, _, _ in api['parse_spans'](raw_inputs['S_query'])]
    assert [n[1] for n in q_forms if n[0] == 'assert'] == [['not', q['generic_goal']]]
    assert q['generic_goal'] == ['and', q['base'], q['pure_embedding_goal'], q['step']]
    assert {n[1] for n in q_forms if n[0] == 'declare-const'} == Q_PARAMETERS
    assert {n[1] for n in s_forms if n[0] == 'declare-const'} == S_PARAMETERS
    assert set(s['fixed_imported_implications']) == set(s['fixed_import_provenance']) == PRIOR_NAMES
    s_assertions = [n[1] for n in s_forms if n[0] == 'assert']
    expected = [*s['fixed_imported_implications'].values(), ['not', s['source_interface_goal']]]
    assert len(s_assertions) == 6 and sorted(map(_canon, s_assertions)) == sorted(map(_canon, expected))
    assert { _canon(x) for x in s['source_interface_goal'][1][1:] } == { _canon(x) for x in s['providers'].values() }
    assert q['source_view_definition_to_apply'] == s['generic_source_view_definition']
    for definition in q['definitions']:
        assert definition in q_forms and definition in s_forms
    assert s['generic_source_view_definition'] in s_forms
    assert WATCH not in exports['context']['Gamma:actual-composed-source']['free_parameters']
    assert WATCH not in api['atoms'](exports['context']['Gamma:actual-composed-source']['formal_native_consequences'])
    c = api['c']
    view = lambda i: c('fj-source-view', c('A', i), c('COLUMNS', i))
    record = ['define-fun', 'fj-capture-record-at', [['record-index', 'Int']], 'FrameRmsCertificate',
        c('fj-current-record', view('record-index'), c('FRAME', 'record-index'), c('NF', 'record-index'), 'record-index')]
    declaration = ['declare-fun', 'fj-capture-record-at', ['Int'], 'FrameRmsCertificate']
    assert q['definitions'].count(declaration) == 1 and WATCH not in api['atoms'](record)
    theory = []
    for definition in q['definitions']:
        if definition == declaration:
            continue
        theory.append(definition)
        if definition[0] == 'declare-datatypes' and definition[2][0][0] == 'FrameJoinView':
            theory.append(s['generic_source_view_definition'])
        if definition[:2] == ['define-fun', 'fj-current-record']:
            theory.append(record)
    names = [d[1] for d in theory if d[0] == 'define-fun']
    assert names.index('fj-source-view') < names.index('fj-current-record') < names.index('fj-capture-record-at') < names.index('frc-I')
    definition, definition_ast_sha = _definition_api(api, raw_inputs['definition_source'])
    return api, data, theory, record, definition, definition_ast_sha


def preflight(proof, language, exports, import_report, mode_application, raw_inputs):
    """Check current caller state too; no language/proof mutation before return."""
    prepared = prepare_metadata(exports, raw_inputs)
    api, data, theory, record, definition, definition_ast_sha = prepared
    assert all(callable(getattr(proof, name)) for name in ['add', 'source', 'trace_instance',
        'open_index', 'index_support', 'index_parents', 'mp', 'conjunction', 'rewrite'])
    assert proof.nodes == mode_application['nodes']
    assert proof.root_context == mode_application['root_context'] == exports['context'] == import_report['root_context']
    assert tuple(proof.global_nodes) == GLOBALS and proof.global_nodes[MODE] == mode_application['global_node']
    assert not proof.active_indices and set(proof.index_bindings) == {'n_current_mode'}
    assert proof.scope_labels == {'INDEX:' + MODE, 'IH:' + MODE}
    assert len(proof.nodes) < TOTAL_NODE_BUDGET
    for symbol in ['CERT', WATCH, 'fj-capture-record-at']:
        assert symbol not in language.decls and symbol not in language.defs, symbol
    assert INDEX not in proof.index_bindings
    assert language.decls['unused-frame'] == ['declare-const', 'unused-frame',
        ['Array', ['_', 'BitVec', '10'], ['_', 'BitVec', '16']]]
    # Existing caller inventory is genuine and complete; reject any nonliteral
    # overlap now, including conflicting names for a datatype to be introduced.
    for definition in theory:
        if definition[0] == 'define-fun' and definition[1] in language.defs:
            assert language.defs[definition[1]] == definition, definition[1]
        elif definition[0] == 'declare-datatypes':
            names_in_definition = {item[0] for item in definition[2]}
            for old in language.datatypes:
                if old[0] == 'declare-datatypes' and names_in_definition & {item[0] for item in old[2]}:
                    assert old == definition
    return prepared


def construct_current_certificate(proof, language, exports, import_report, mode_application, raw_inputs):
    api, data, theory, record, literal_definition, definition_ast_sha = preflight(
        proof, language, exports, import_report, mode_application, raw_inputs)
    q, s = data['Q'], data['S']
    c, EQ, AND, IMP, SUB = (api[k] for k in ['c', 'eq', 'AND', 'IMP', 'SUB'])
    before_roots = deepcopy(proof.root_context)
    start = len(proof.nodes)
    language.add(deepcopy(theory))
    language.decls['CERT'] = ['declare-fun', 'CERT', ['Int'], 'FrameRmsCertificate']
    # Histories and record function above are fixed before this arbitrary word.
    language.decls[WATCH] = ['declare-const', WATCH, ['_', 'BitVec', '8']]
    view = lambda i: c('fj-source-view', c('A', i), c('COLUMNS', i))
    template = c('frc-I', view('@index'), c('FRAME', '@index'), c('NF', '@index'),
                 c('CERT', '@index'), '@index', WATCH)
    observer_nodes = []
    def budget():
        if len(proof.nodes) > TOTAL_NODE_BUDGET:
            raise CertificateApplicationGap('combined-node-budget', TOTAL_NODE_BUDGET, len(proof.nodes))
    def derive(stage, target, parents):
        try:
            result = api['derive'](proof, target, parents)
        except AssertionError as error:
            raise CertificateApplicationGap(stage, target, repr(error)) from error
        budget()
        return result
    def observer(which, index, step=False):
        after = c('+', index, '1')
        specs = {
            'columns': (c('COLUMNS', '1'), 'columns-zero', c('COLUMNS', after), c('columns-next', c('A', index), c('COLUMNS', index))),
            'frame': (c('FRAME', '1'), c('frame-zero', 'unused-frame'), c('FRAME', after), c('frame-next', c('A', index), c('COLUMNS', index), c('FRAME', index), 'unused-frame')),
            'NF': (c('NF', '1'), c('nf-zero', c('NFEMPTY', '0')), c('NF', after), c('nf-next', c('A', index), c('NF', index), c('NFEMPTY', index))),
            'CERT': (c('CERT', '1'), c('frc-zero', c('NFEMPTY', '0')), c('CERT', after), c('frc-next', view(index), c('FRAME', index), c('NF', index), c('CERT', index), index)),
        }
        zero_lhs, zero_rhs, step_lhs, step_rhs = specs[which]
        formula = EQ(step_lhs, step_rhs) if step else EQ(zero_lhs, zero_rhs)
        anchor, index_mapping = None, {}
        if which != 'CERT':
            anchor = import_report['total_observer_definition_anchors'][which]['step' if step else 'zero']
            total = anchor['original_total_definition_node']
            assert total['id'] == anchor['source_node_id'] and total['step'] is step
            assert total['index'] == anchor['source_index']
            index_mapping = {anchor['source_index']: index} if step else {}
            # The original total nondriving definition supplies this equation.
            # Its only step domain is the original positive natural index.
            assert SUB(total['formula'], index_mapping) == formula
            if step:
                assert SUB(anchor['original_domain_parent']['formula'], index_mapping) == ['<=', '1', index]
            if which == 'columns':
                accepted = import_report['parent_observer_definitions']['columns']['next_on_prefix' if step else 'zero_at_1']
            elif which == 'frame':
                accepted = import_report['parent_observer_definitions']['additional'][3 if step else 2]
            else:
                accepted = import_report['NF_observer_definitions'][1 if step else 0]
            if step:
                assert accepted[0] == 'forall'
                accepted = SUB(accepted[2][2], {accepted[1][-1][0]: index})
            # Keep the separately accepted bounded body as a literal match;
            # this comparison does not eliminate or weaken its domain guard.
            assert accepted == formula
        parents = proof.index_parents(index) if step else []
        support = proof.index_support(index, True) if step else []
        node = proof.add('total-same-trace-nondriving-component-observer-definition', formula,
            parents, support=['Gamma:actual-composed-source', *support], registry=which,
            index=index, step=step, watched_index_not_an_observer_argument=True,
            original_total_definition_anchor=deepcopy(anchor),
            total_definition_uniform_index_mapping=deepcopy(index_mapping),
            accepted_history_definition_input_pins=deepcopy(import_report['input_pins']))
        observer_nodes.append(node)
        return node
    def fold(node, equation):
        eq = proof.nodes[equation]['formula']
        return proof.rewrite(node, equation, eq[2], eq[1])
    def generic(mapping):
        assert set(mapping) == Q_PARAMETERS
        return proof.add('qualified-source-schema-uniform-instance', SUB(q['generic_goal'], mapping),
            original_query_goal=deepcopy(q['generic_goal']), uniform_mapping=deepcopy(mapping),
            original_query_sha256=PINS['Q_query'], accepted_result_review_sha256=PINS['Q_review'],
            uniformly_arbitrary_record_function_declaration=['declare-fun', 'fj-capture-record-at', ['Int'], 'FrameRmsCertificate'],
            one_actual_record_function_definition=deepcopy(record), helper_theory_specialization=deepcopy(theory))
    def mapping(index, after):
        return {'view': view(index), 'next-view': view(after), 'frame': c('FRAME', index),
            'nf': c('NF', index), 'next-nf': c('NF', after), 'certificate': c('CERT', index),
            'observation': index, 'watch': WATCH, 'position': ['_', 'bv0', '10'],
            'empty-frame': 'unused-frame', 'empty-nf': c('NFEMPTY', '0')}

    base_map = mapping('1', '1')
    base_rule = generic(base_map)
    base = derive('generic-base-projection', SUB(q['base'], base_map), [base_rule])
    base = fold(base, observer('frame', '1'))
    base = fold(base, observer('CERT', '1'))
    assert proof.nodes[base]['formula'] == SUB(template, {'@index': '1'})
    budget()
    bound = proof.open_index(FAMILY, INDEX)
    ih = proof.add('scoped-induction-hypothesis', SUB(template, {'@index': INDEX}),
        [bound], support=['IH:' + FAMILY], scope=INDEX)
    after = c('+', INDEX, '1')
    source_map = {'a': c('A', INDEX), 'b': c('A', after), 'columns': c('COLUMNS', INDEX),
        'capture': c('CAPTURE', INDEX), 'frame': c('FRAME', INDEX), 'nf': c('NF', INDEX),
        'certificate': c('CERT', INDEX), 'observation': INDEX, 'watch': WATCH,
        'nf-unused-frame': c('NFEMPTY', INDEX), 'frame-unused': 'unused-frame'}
    assert set(source_map) == S_PARAMETERS
    step_map = mapping(INDEX, after)
    count = SUB(s['write_watch_total_expression'][1], source_map)
    step_map['position'] = count
    generic_step_rule = generic(step_map)
    prior_ids = []
    for name, original in s['fixed_imported_implications'].items():
        target = SUB(original, source_map)
        if name == 'proved-pure-count-embedding':
            node = derive('generic-count-embedding', target, [generic_step_rule])
        else:
            node = proof.add('qualified-source-schema-uniform-instance', target,
                original_query_goal=deepcopy(original), uniform_mapping=deepcopy(source_map),
                accepted_fixed_import_provenance=deepcopy(s['fixed_import_provenance'][name]),
                fixed_source_binding_sha256=PINS['S'], source_import_name=name,
                qualification_review_sha256=PINS['S_review'])
        prior_ids.append(node)
    bridge_conditional = IMP(AND(*s['fixed_imported_implications'].values()), s['source_interface_goal'])
    bridge_rule = proof.add('qualified-source-schema-uniform-instance', SUB(bridge_conditional, source_map),
        original_query_goal=deepcopy(bridge_conditional), uniform_mapping=deepcopy(source_map),
        exact_query_positive_assertions=deepcopy(list(s['fixed_imported_implications'].values())),
        exact_query_negated_goal=deepcopy(s['source_interface_goal']), original_query_sha256=PINS['S_query'],
        accepted_result_review_sha256=PINS['S_review'], one_actual_record_function_definition=deepcopy(record))
    bridge_rule = proof.mp(bridge_rule, derive('qualified-S-imports', proof.nodes[bridge_rule]['formula'][1], prior_ids))
    controller = proof.trace_instance('control', INDEX, {'watch': '0'})
    capture = proof.trace_instance('actual-capture', INDEX)
    projection_goal = data['frame_binding']['source_qualified_capture_projection_goal']
    projection_map = {'a': c('A', INDEX), 'capture': c('CAPTURE', INDEX)}
    projection = proof.add('qualified-accepted-frame-uniform-source-rule', SUB(projection_goal, projection_map),
        source_statement_name='source_qualified_capture_projection_goal', source_statement=deepcopy(projection_goal),
        uniform_mapping=deepcopy(projection_map), qualified_frame_seal_sha256=PINS['frame_seal'])
    job = derive('actual-capture-to-job-projection', SUB(s['providers']['actual-JobHistory-projection'], source_map), [projection, capture])
    write_watch = SUB(s['write_watch_total_expression'], source_map)
    zx = lambda w: [['_', 'zero_extend', '2'], w]
    providers = [controller, capture, job, ih,
        proof.source(c('|core_workflow_control_h|', c('A', INDEX))),
        proof.source(c('|core_workflow_control_h|', c('A', after))),
        proof.source(c('|core_workflow_control_t|', c('A', INDEX), c('A', after))),
        proof.trace_instance('actual-frame', INDEX, {'frame-watch': zx(WATCH)}),
        proof.trace_instance('actual-frame', INDEX, {'frame-watch': zx(write_watch)}),
        proof.trace_instance('original-NF-provider', INDEX, {'nf-watch': WATCH}),
        proof.trace_instance('original-NF-provider', INDEX, {'nf-watch': write_watch}),
        proof.trace_instance(MODE, INDEX)]
    source_facts = proof.mp(bridge_rule, derive('actual-source-bridge-provider-premises', proof.nodes[bridge_rule]['formula'][1], providers))
    source_facts = fold(source_facts, observer('columns', INDEX, True))
    source_facts = fold(source_facts, observer('NF', INDEX, True))
    record_definition = literal_definition(proof, language, 'fj-capture-record-at', [INDEX])
    generic_step = derive('generic-step-projection', SUB(q['step'], step_map), [generic_step_rule])
    premise = derive('generic-step-all-eight-premises', proof.nodes[generic_step]['formula'][1],
        [bound, ih, record_definition, source_facts])
    step = proof.mp(generic_step, premise)
    alias = derive('literal-FRAME-next-alias', SUB(s['targets']['literal-FRAME-next-alias'], source_map), [source_facts])
    equality = proof.nodes[alias]['formula']
    step = proof.rewrite(step, alias, equality[1], equality[2])
    step = fold(step, observer('frame', INDEX, True))
    step = fold(step, observer('CERT', INDEX, True))
    assert proof.nodes[step]['formula'] == SUB(template, {'@index': after})
    budget()
    result = api['close_factory'](proof)(FAMILY, template, base, step, INDEX, ih, [[WATCH, ['_', 'BitVec', '8']]])
    assert proof.root_context == before_roots and not proof.active_indices
    assert set(proof.nodes[result]['support']) == set(before_roots)
    assert tuple(proof.global_nodes) == (*GLOBALS, FAMILY)
    budget()
    for i, node in enumerate(proof.nodes):
        assert node['id'] == i
        support = set(node['introduced_support'])
        for parent in node['parents']:
            assert 0 <= parent < i
            support.update(proof.nodes[parent]['support'])
        assert support - set(node.get('discharged_support', [])) == set(node['support'])
    return deepcopy({'kind': 'one-original-current-frame-CERT-ordinary-induction',
        'nodes': proof.nodes, 'global_node': result, 'root_context': before_roots,
        'CERT_observer_definition_nodes': observer_nodes, 'fixed_record_function_definition': record,
        'definition_helper_source_sha256': PINS['definition_source'], 'definition_helper_AST_sha256': definition_ast_sha,
        'generic_base_mapping': base_map, 'generic_step_mapping': step_map, 'actual_source_mapping': source_map,
        'source_pins': PINS, 'new_CERT_proof_nodes': len(proof.nodes) - start,
        'combined_new_proof_nodes': len(proof.nodes), 'node_budget': TOTAL_NODE_BUDGET,
        'new_native_jobs': 0, 'finite_prefix_CERT_export_qualified': False,
        'current_FRAME_endpoint_proved': False, 'historical_STEP_RMS_or_ROW_application_proved': False,
        'numerical_RMS_proved': False})

# Minimal next E exponent invariant using existing actual parent control

Read-only inventory refined the first step of POSTSCALE-CONTINUATION-PLAN.md.
This additive plan leaves that recovery snapshot intact. No new query/proof/
engine has been prepared or run for this step. The same actual selector-score
target and all downstream read/metadata/scale/consumer boundaries remain active.

The existing qualified selected-row-phase-I already contains eight generic
controller clauses under actual J live, including active E owned by running J,
group/job/layer correspondence, preheader/header/weight phase pairs and retired
engine control. These clauses do not require root-arbiter health or Q job0.
They are present in the accepted control export, not merely a proposed builder.
Their exact bodies must be read from the sealed source typing and bound to the
qualified definition/theorem; do not execute construct_phase. The first eight
conjuncts depend only on native state s, not ColumnHistory/ROW/header arguments.

The qualified current-job-I also supplies the running-J parent of an active
group-stream header. These existing providers should remove the need to prove
another whole parent/control invariant. The proposed single new invariant is:

```text
J_live(s) && E.state(s) in {META,WEIGHTS,DRAIN,EMIT,DONE}
    => E.activation_exponent_q(s) = J.activation_exponent_q(s).
```

J_live is the literal actual reset-high/no-CLEAR/no-integrated-failure guard.
This is physical source ownership under current authority, not a future-health
filter. Its preservation must still cover the edge on which a new fault first
arises; no gate or source transition is changed.

Two native obligations, one compound scalar invariant:

1. H/reset-low gives its base by actual common reset masks.
2. Both H/all452 T, current qualified current-job-I(a,columns), the exact first
   eight qualified phase-control conjuncts at a, and current scalar IH give
   the scalar invariant at b. No successor provider or success premise is
   planned. During retained E work, the existing parent phase gives J GROUP_RUN,
   where the J exponent cannot be recaptured. At a genuine new E capture, the
   actual source adapter/start mux must supply J's exponent and the header
   parent must rule out a simultaneous unrelated J descriptor birth.

Preserve the source E register's own reset/CLEAR/control_error/start/descriptor
priorities and its actual successor reset visibility. Do not assume an abstract
start signal is the effective capture. The exact native query must discharge
these branches. Use all452 T clauses even if the dependency cone is small.

Before queries, review literal definitions, qualified component/result pins,
source/getter/port bindings, provider projection and exact premises. Extract
ASTs directly from accepted artifacts without old builders, compilers, giant
proof reconstruction, or state-sort renaming. The provider's full actual-source
context and original state/edge/reset domains remain unchanged. Project the
eight control conjuncts by checked definition/conjunction rules in the later
ordinary application, rather than asserting a desired parent relation.

Budget: two first-attempt native checks, one owned4GiB RSS/footprint/internal
memory4096 worker, actual normal Darwin pressure and accepted guard/probe reuse.
No wall/CPU/token kill, resource probe, simulation, RTL build/edit, board or
public action. An unexpected result stops this chain and preserves its exact
query/receipts. Any diagnostic or revised strength needs a new small reviewed
additive gate; this batch is not a global attempt allowance.

After accepted native leaves, apply one ordinary reset-founded scalar induction
on the original finite source prefix using the existing qualified control
providers and derived bounds. At actual current E activity for head job7,
derive complete active FRAME from qualified state FRAME/capture/control, then
apply the closed current saved-RMS exponent theorem. This should identify
actual E's exponent with the same current job's original R0. Connection to the
original row j still needs its same-UID/certificate argument before scaling.

Additional useful inventory: the sealed completed-dot prefix already exports
canonical-row-dot-prefix at every physical row observation, plus row-numeric
and saved-row-frame state invariants. The phase invariant supplies finished
count256 in DRAIN/EMIT/DONE. Prefer applying those at the actual read over a new
history that snapshots an arbitrary desired completed dot. Pending op/product
absence at the read and the original frame/UID/episode must be derived, not
assumed. A completed-dot theorem guarded by done_o cannot simply be applied
many cycles later when done_o is false.

Fixed-image metadata provenance, postscale arithmetic/tag/hold and actual
selector admission keep the previous plan's exact source/cancellation limits.
No Lean, additional model row or whole-device claim is part of this step.

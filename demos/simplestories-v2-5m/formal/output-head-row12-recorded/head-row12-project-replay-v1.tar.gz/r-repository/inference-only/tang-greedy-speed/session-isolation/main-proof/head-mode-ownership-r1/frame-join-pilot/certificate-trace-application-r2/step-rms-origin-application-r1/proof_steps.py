"""Literal definition and concrete datatype-selector equations only.

No event/range/RTL fact is created here. Each selector must be applied to its
declared concrete constructor; selectors on another payload constructor fail.
"""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy

ALLOWED_TYPES = {'StampedHistory', 'StampedEvent', 'StampedPayload', 'NormFrame',
                 'FrameJoinView', 'RowFrameOriginRecord', 'RowView'}


def part(proof, parent, position):
    f = proof.nodes[parent]['formula']
    assert f[0] == 'and' and 1 <= position < len(f)
    return proof.add('conjunction-elimination', f[position], [parent], position=position)


def definition(proof, language, api, name, args, bounds=()):
    source = language.defs[name]
    assert source[0] == 'define-fun' and len(source[2]) == len(args)
    mapping = dict(zip([x[0] for x in source[2]], args))
    call, body = [name, *deepcopy(args)], api['SUB'](source[4], mapping)
    result = proof.add('literal-function-definition-instance', ['=', call, body],
                       definition=deepcopy(source), uniform_mapping=mapping)
    if bounds:
        result = part(proof, proof.conjunction([result, *bounds]), 1)
    return result


def selector(proof, language, term):
    assert isinstance(term, list) and len(term) == 2
    assert isinstance(term[0], str) and isinstance(term[1], list)
    constructor = term[1]
    assert constructor and isinstance(constructor[0], str)
    candidates = []
    for datatype in language.datatypes:
        if datatype[0] != 'declare-datatypes' or datatype[1] != []:
            continue
        for typ in datatype[2]:
            if typ[0] not in ALLOWED_TYPES:
                continue
            for ctor in typ[1:]:
                if ctor[0] != constructor[0]:
                    continue
                assert len(ctor) == len(constructor)
                for position, field in enumerate(ctor[1:], 1):
                    if field[0] == term[0]:
                        candidates.append((datatype, typ[0], position))
    assert len(candidates) == 1, ('Not a concrete declared constructor selector', term)
    datatype, typ, position = candidates[0]
    return proof.add('literal-datatype-constructor-selector',
        ['=', deepcopy(term), deepcopy(constructor[position])],
        datatype=deepcopy(datatype), datatype_name=typ,
        constructor_name=constructor[0], selector_name=term[0], selector_position=position)


def observer_selector(proof, language, api, observer, record, field):
    """so-field(observer(record)) = literal corresponding NF selector."""
    assert observer in {'nf-step-origin-observer', 'nf-rms-origin-observer'}
    assert field in {'t', 'valid', 'uid', 'payload'}
    equation = definition(proof, language, api, observer, [record])
    eq = proof.nodes[equation]['formula']
    assert eq[2][0] == 'mkStampedHistory'
    selected = selector(proof, language, ['so-' + field, eq[2]])
    return proof.rewrite(selected, equation, eq[2], eq[1])


def normalize_selectors(proof, language, node):
    """Reduce only syntactically concrete constructor/selector redexes."""
    allowed = set()
    constructors = set()
    for datatype in language.datatypes:
        if datatype[0] == 'declare-datatypes' and datatype[1] == []:
            for typ in datatype[2]:
                if typ[0] in ALLOWED_TYPES:
                    for ctor in typ[1:]:
                        constructors.add(ctor[0])
                        allowed.update(field[0] for field in ctor[1:])
    def find(term):
        if not isinstance(term, list):
            return None
        for child in term:
            found = find(child)
            if found is not None:
                return found
        if len(term) == 2 and isinstance(term[0], str) and term[0] in allowed:
            arg = term[1]
            if isinstance(arg, list) and arg and isinstance(arg[0], str) and arg[0] in constructors:
                return term
        return None
    while True:
        term = find(proof.nodes[node]['formula'])
        if term is None:
            return node
        equation = selector(proof, language, term)
        node = proof.rewrite(node, equation, term, proof.nodes[equation]['formula'][2])

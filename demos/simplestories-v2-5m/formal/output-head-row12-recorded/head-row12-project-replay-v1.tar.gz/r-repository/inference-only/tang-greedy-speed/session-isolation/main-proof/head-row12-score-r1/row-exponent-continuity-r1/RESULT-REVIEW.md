# Physical selected-row exponent continuity — independent native result review

Accepted: both exact reviewed source leaves passed their first attempts with clean UNSAT and successful recorded native exit/reaping. This accepts conditional physical base/preservation evidence, not the later ordinary-prefix function realization or original saved-R0/read association.

| Binding | SHA-256 |
| --- | --- |
| `FROZEN-INPUTS.json` | `77b3515d50e3008ba9951e17bc7728dfb9c61284daab424ebbf80cd41041c6b6` |
| `REVIEW-ACCEPTED.json` | `28b6684bcf288e385c7bf2116e6cf86a77d36c309719a12e68dfb6ef72be547a` |
| `INPUT-REVIEW.md` | `36e8b0a3e99d0e4e46b968b07dda49e02ff8d226aa759e7817982075fc40cba4` |
| `RUN-INTENT.json` | `f7d591486fde796d67665afb0916ac290ee50907546b13111c839c28ac87b509` |
| `RESULTS.json` | `d39eacd1e46f3fe118e1aca52f1bddc588229b583ba90c764e412efec8c5ae9a` |

| First attempt | Query SHA-256 | Raw log SHA-256 | Wall seconds |
| --- | --- | --- | ---: |
| reset base | `e84007f24f5fdc90da76515ccf7f96156a82e60dac72519c1bef462112f889e4` | `1971d6ea016210ef2cc1aab4bae087916aa9d339cbe2adb276ff3b74c21d1229` | 0.3924989700 |
| preservation | `e801c453ab23f6dbf9fa0e92f65ec1ea1b7c195db93b4304dde81a9e13f58f66` | `248010efec18a06da99d6fdf50e1825904e97a5becb4e72dff45e9b739feef42` | 0.8628768921 |

All twelve local and 44 absolute external frozen pins still match regular-file bytes, without symlinks. The acceptance binds this exact 56-pin freeze, reviewed scope, input-review hash and two-job budget. The intent agrees with the exact prepared plan/order, one worker, actual tool, 4-GiB RSS/physical-footprint limit, no time/CPU kill and zero new probes/simulations. Actual Z3 remains `ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`; all source/compile/getter/helper/guard/probe pins remain the accepted input versions.

Independent parsing of each actual query confirms its only assertion is exactly the binding's negated goal and it contains one check. Each raw log contains only `unsat` and one statistics list with unique keys and finite nonnegative values. Base has five statistics and legitimately omits `:num-checks`; preservation has 35 statistics and `:num-checks 1`. There is no extra answer, model, error or parse failure. Each individual checked result exactly equals its aggregate row, query/tool/log hashes and embedded FINISHED/MONITOR records.

The runs directory has exactly the two named run folders and two observation journals. Each folder contains only STARTED, FINISHED, MONITOR-BINDING, NATIVE.log and CHECKED-RESULT. Both argv values use the pinned binary, `-smt2 -st -memory:4096`, and exact query path; cwd is this gate and environment changes are empty. Base PID/PGID 12783 runs from `13:33:57.261922Z` to `13:33:57.654426Z`. Preservation PID/PGID 12787 starts afterward at `13:33:57.699948Z` and finishes at `13:33:58.562829Z`. There is no recorded overlapping worker, extra attempt, retry, diagnostic or active owned job.

I independently checked every admission, pressure and owned-group journal record, monotone timestamps, exact journal hashes, group/PID/start-identity consistency, monitor counts and computed peaks. Base has eight group observations and nine pressure samples; preservation has sixteen groups and seventeen pressure samples. Every pressure value is the observed normal value 1. Each nonempty owned group contains only its leader, with stable positive start identity; both final group records are empty with zero RSS/footprint. Group counts equal receipt observation counts plus the final sample, and observed PID/identity maps match receipt/monitor records.

| Resource bytes | Base | Preservation |
| --- | ---: | ---: |
| maximum sampled RSS | 39,550,976 | 261,816,320 |
| maximum sampled physical footprint | 36,602,288 | 257,049,200 |
| wait4 maximum RSS | 41,893,888 | 262,520,832 |

All are positive and below 4,294,967,296 bytes; every receipt peak equals recomputation from its journal. Native exits/raw wait statuses are 0, monitor errors are empty and resource-stop reasons are null. Kernel/stage/maximum elapsed/CPU caps are absent, disk floor is zero and single-process is required. Actual wait4 receipts plus final empty owned groups support cleanup/reaping. Monitors bind unchanged guard source `5e5d67b1dafa0917a051599d963a4efb77e5f4b7489e193f1b0ff22e8545213c`, no time/CPU kill and no simulation reservation. Journal hashes are `bb81d6418772fd1102c3d318db0f665dd6af8e9ecbf66a1baa14ffed5506cc71` and `133aca4c534af4ca03aba44785f3c45d8258857caf8606b1a84b5be4afe01fb1`.

The source scope remains the exact physical predicate: active E phases 1–5 and physical selected row/count>0 imply E exponent equals the fixed unary function at the retained original row origin. Preservation has exactly H(a), H(b), all 452 T conjuncts, current IH and the current-point function bridge. Original row-next/source-view/origin-next definitions, arbitrary original-sort empty arrays and function signature remain literal. There is no J-live/successor-health filter, control provider, desired historical RMS value or numerical/model assumption. The native prefix is unchanged c070; canceled physical payload receives no output authority from this result.

The next ordinary stage must uniformly realize the one function as the actual E getter on A(t), derive the current bridge by literal definition, use original ROW and FRAMEORIGIN zero/step anchors and keep historical calls opaque until actual bounds. These native leaves do not by themselves establish that finite-prefix induction or connect a later physical row to original saved RMS. Original UID/episode, pending-MAC/current accumulator/read identity, head group0/global row12, fixed-image metadata/range, postscale/hold, first-fault authority and legal selector admission remain separate. Corresponding prefix/R0 and whole-device flags remain correctly false.

This review used only read-only standard-library query/log/JSON parsing, hashing and receipt/journal arithmetic. No preparer, native rerun, Proof constructor, old checker/writer, resource probe, compiler, simulator, process control or additional agent was invoked. The full inspection result was retained. All first-run producer pending-review fields remain unchanged; this additive file records native leaf acceptance.

if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
import sys,hashlib
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
from support import smt,atoms
from row_terms import SUB


def alpha(definition):
    if definition[0]!='define-fun':return definition
    params=definition[2];mapping={p[0]:'__arg'+str(i) for i,p in enumerate(params)}
    return [*definition[:2],[[mapping[p[0]],p[1]] for p in params],definition[3],SUB(definition[4],mapping)]


class SourceLanguage:
    def __init__(self):self.defs={};self.decls={};self.datatypes=[]

    def add(self,forms):
        for node in forms:
            kind=node[0]
            if kind=='define-fun':
                key=node[1]
                if key in self.defs:assert alpha(self.defs[key])==alpha(node),('conflicting function',key)
                else:self.defs[key]=node
            elif kind=='declare-fun':
                key=node[1]
                if key in self.decls:assert self.decls[key]==node
                else:self.decls[key]=node
            elif kind.startswith('declare-datatype'):
                if node not in self.datatypes:self.datatypes.append(node)

    def expanded(self,node,names):
        if not isinstance(node,list):return node
        op=node[0]
        if isinstance(op,str) and op in names:
            definition=self.defs[op];assert len(node)-1==len(definition[2])
            body=SUB(definition[4],{p[0]:v for p,v in zip(definition[2],node[1:])})
            return self.expanded(body,names)
        return [self.expanded(x,names) for x in node]

    def native_weakening(self,full,selected):
        original=self.defs[full];subset=self.defs[selected]
        assert len(original[2])==len(subset[2])==2
        assert original[3]==subset[3]=='Bool'
        assert [p[1] for p in original[2]]==[p[1] for p in subset[2]]
        body=SUB(original[4],{p[0]:q[0] for p,q in zip(original[2],subset[2])})
        assert body[0]==subset[4][0]=='and'
        assert all(x in body[1:] for x in subset[4][1:]),selected
        args=[p[0] for p in subset[2]]
        return ['=>',[full,*args],[selected,*args]]


class BooleanApplication:
    """Forget non-Boolean theory; UNSAT is an entailment strengthening only.

    Every learned input statement still needs its separately checked source
    proof/typed specialization. This abstraction supplies no theorem axiom.
    """
    def __init__(self,language,inline):
        self.language=language;self.inline=set(inline);self.atom_table={}

    def canonical(self,node):
        if not isinstance(node,list):return node
        op=node[0]
        # One literal native getter expansion, matching the existing guarded
        # source-congruence alias check. Do not recursively re-interpret cells.
        if isinstance(op,str) and op.startswith('|core_workflow_control_n '):
            definition=self.language.defs[op];assert len(definition[2])==1 and len(node)==2
            body=SUB(definition[4],{definition[2][0][0]:node[1]})
            return self.canonical_children(body)
        if isinstance(op,str) and op in self.inline:
            return self.canonical(self.language.expanded(node,{op}))
        return self.canonical_children(node)

    def canonical_children(self,node):
        if not isinstance(node,list):return node
        children=[self.canonical(x) for x in node]
        op=children[0]
        if op in ['and','or']:
            flattened=[]
            for child in children[1:]:
                if isinstance(child,list) and child and child[0]==op:flattened.extend(child[1:])
                else:flattened.append(child)
            return [op,*sorted({smt(x):x for x in flattened}.values(),key=smt)]
        # Equality symmetry is a primitive valid theory normalization. No
        # numeric/address inference or reversing equal model values occurs.
        if op=='=' and len(children)==3:return ['=',*sorted(children[1:],key=smt)]
        return children

    def formula(self,node):
        node=self.canonical(node)
        if node in ['true','false']:return node
        if isinstance(node,list) and isinstance(node[0],str) and node[0] in ['and','or','not','=>']:
            return [node[0],*[self.formula(x) for x in node[1:]]]
        key=smt(node);name='p_'+hashlib.sha256(key.encode()).hexdigest()
        if name in self.atom_table:assert self.atom_table[name]==node
        else:self.atom_table[name]=node
        return name

    def query(self,lemmas,guard,goal):
        assertions=[['assert',self.formula(x)] for x in lemmas]
        assertions.extend([['assert',self.formula(guard)],['assert',['not',self.formula(goal)]]])
        forms=[['declare-const',name,'Bool'] for name in sorted(self.atom_table)]
        forms.extend([*assertions,['check-sat-using',['then','simplify','propagate-values','solve-eqs','simplify','smt']],['exit']])
        return ('\n'.join(map(smt,forms))+'\n').encode()

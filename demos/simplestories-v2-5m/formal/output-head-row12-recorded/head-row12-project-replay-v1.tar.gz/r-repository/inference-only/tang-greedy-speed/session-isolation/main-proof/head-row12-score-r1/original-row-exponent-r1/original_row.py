"""Original row snapshot, physical E exponent and the same saved RMS record."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json
FAMILY = 'physical-original-row-E-saved-RMS-exponent-and-snapshot'
N = 'n_original_row_saved_exponent'
W = 'original-row-saved-exponent-watch'
CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
canon = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':')).encode()
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def prepare_metadata(exports, data, pins, forms):
    assert pins['continuity_application'] == '7fd994dd330051177aaf55af46541c536c5207a81660272e5d390b26b28d3d04'
    assert pins['continuity_review'] == 'e79032ff1f3ce0c242c66098f89996a133175873d3b4b8ea5d5b1724e317513a'
    assert pins['engine_application'] == '26090b6999121419a19392e4ffba46be31eb7d540ffbd0d50b90c481b8b7beba'
    assert pins['engine_review'] == '10e0eee19a57800e0029cc900c04c34c32e32f355ce789756c70bc84f2e1d566'
    assert pins['capture_application'] == '4e0901b6a2b91b421191ca24622093df340a24fa47d6c87b7fc0d5dbbeee6fb0'
    assert pins['capture_review'] == 'f438c1214a6994cfe9507af4d7d3295f8c6f41dca3b396142307a094ba73b168'
    assert pins['capture_seal'] == '1cb5e7e60c98e691218b7228a60e1237afc5d0484d37861db718b63f523bf5a0'
    assert pins['dot_seal'] == 'c5591f6f05aa192edc891e8a6888e43895cc1d9b00a11eb067a0995d4c23b99e'
    assert pins['math_seal'] == '4cfab125330467e05d22190f10af0c8033ec6bcedb559ae3f36b810f24dc9954'
    assert pins['row_guard_seal'] == '32e903f208b30e96fe30de610b89ecc5d54473645c3a0946fe7fc1b67ac02154'
    cap_dir = 'frame-join-pilot/certificate-trace-application-r2/step-rms-origin-application-r1/'
    for key, name in [('capture_application', 'CAPTURE-ROW-APPLICATION-R1.json'), ('capture_review', 'CAPTURE-ROW-RESULT-REVIEW.md')]:
        assert data['capture_seal']['files'][cap_dir + name] == pins[key]
    for key, name in [('dot_application', 'COMPLETED-DOT-APPLICATION-DRAFT.json'), ('dot_prefix', 'COMPLETED-DOT-PREFIX-APPLICATION-DRAFT.json')]:
        assert data['dot_seal']['files'][name] == pins[key]
    for key, name in [('math_binding', 'INTEGER-ORDER-BINDING.json'), ('math_check', 'CHECK-RECORDED.json'), ('math_query', 'strict-past-through-current-upper-bound.smt2')]:
        assert data['math_seal']['files']['frame-join-pilot/certificate-trace-application-r2/integer-order-gate-r1/' + name] == pins[key]
    for key, name in [('row_guard_binding', 'SOURCE-BINDING.json'), ('row_guard_result', 'ADJUDICATED-RESULT-R2.json'), ('row_guard_query', 'same-observation-row-capture-live-head.smt2')]:
        assert data['row_guard_seal']['files']['frame-join-pilot/row-capture-guard-r1/' + name] == pins[key]
    assert data['math_check']['passed'] and data['math_check']['source_free_integer_order_lemma_checked']
    assert data['row_guard_result']['accepted'] and not data['row_guard_result']['original_wrapper_success_claimed']
    context = exports['prefix_artifact']['inherited_prefix_source_context']
    assert digest(canon(context)) == CONTEXT_SHA
    assert data['continuity_application']['prefix']['bounded_source_context'] == context
    assert data['engine_application']['application']['root_context'] == context
    assert data['capture_application']['application']['root_context'] == context
    assert data['dot_prefix']['inherited_continuity_prefix']['inherited_prefix_source_context'] == context
    assert len(data['continuity_application']['application']['nodes']) == 19
    assert len(data['engine_application']['application']['nodes']) == 104
    capture = data['capture_application']['application']['capture_application']
    assert capture['global_node'] == 165 and capture['literal_global_formula'] == data['capture_application']['application']['nodes'][165]['formula']
    engine = data['engine_application']['application']['current']
    assert engine['global_node'] == 103 and engine['literal_global_formula'] == data['engine_application']['application']['nodes'][103]['formula']
    definitions = {f[1]: f for f in forms if f[0] == 'define-fun'}
    for key in ['future_fixed_actual_function_definition', 'future_actual_invariant']:
        value = data['continuity_binding'][key]
        assert definitions[value[1]] == value
    assert data['continuity_application']['prefix']['fixed_actual_function_definition'] == data['continuity_binding']['future_fixed_actual_function_definition']
    assert data['continuity_binding']['native_sha256'] == exports['context']['Gamma:actual-composed-source']['native_core_sha256']
    globals = {}
    for family, where in [('saved-row-frame', 'earlier_bounded_consequences'), ('historical-frame-origin', 'bounded_consequences')]:
        node = data['dot_application']['nodes'][data['dot_application']['global_nodes'][family]]
        assert node['kind'] == 'ordinary-induction'
        bounded = data['dot_prefix'][where][family]
        binder = bounded[1][-1][0]
        assert bounded == ['forall', [*node['quantified_parameters'], [binder, 'Int']],
            ['=>', ['and', ['<=', '1', binder], ['<=', binder, 'N']], exports['apis']['SUB'](node['property_template'], {'@index': binder})]]
        globals[family] = {'bounded': deepcopy(bounded), 'support': deepcopy(node['support'])}
    return deepcopy({'context': context, 'pins': pins, 'capture': capture, 'engine': engine, 'globals': globals})


def construct(proof, language, exports, data, prepared, steps, fixed):
    api = exports['apis']
    class Application(fixed.FixedApplication):
        def __init__(self):
            self.proof, self.language, self.api, self.data, self.steps = proof, language, api, data, steps
            self.c, self.EQ, self.SUB = (api[k] for k in ['c', 'eq', 'SUB'])
            self.context = deepcopy(prepared['context'])
            assert proof.root_context == self.context and not proof.nodes and not proof.active_indices
            self.imports, self.lookup_ledger = {}, []

        def run(self):
            p, c = self.proof, self.c
            domain = ['<=', '1', 'N']
            control = exports['selectedglobals']['control']
            control_i = self.import_fixed('qualified-bounded-original-control', ['=>', domain, control['bounded_formula']], control['node']['support'],
                {'seal': exports['provenance']['seal_sha256'], 'source': exports['provenance']['source_dag_sha256'], 'node': 779})
            state = {}
            for name in ['saved-row-frame', 'historical-frame-origin']:
                value = prepared['globals'][name]
                state[name] = self.import_fixed('qualified-bounded-' + name, ['=>', domain, value['bounded']], value['support'],
                    {k: prepared['pins'][k] for k in ['dot_seal', 'dot_application', 'dot_prefix']})
            continuity = self.import_fixed('qualified-bounded-physical-E-row-continuity',
                ['=>', domain, data['continuity_application']['prefix']['bounded_formula']], data['continuity_application']['prefix']['source_supports'],
                {k: prepared['pins'][k] for k in ['continuity_application', 'continuity_review']})
            engine = self.import_fixed('accepted-current-head-E-original-R0', prepared['engine']['literal_global_formula'], self.context,
                {k: prepared['pins'][k] for k in ['engine_application', 'engine_review']})
            capture_global = self.import_fixed('sealed-original-STEP-RMS-frame-capture', prepared['capture']['literal_global_formula'], self.context,
                {k: prepared['pins'][k] for k in ['capture_seal', 'capture_application', 'capture_review']})
            lower_n = p.open_index(FAMILY, N)
            guard = self.SUB(data['continuity_binding']['scalar_invariant'][4][1],
                {'s': c('A', N), 'r': c('ROW', N), 'origin': c('FRAMEORIGIN', N)})
            case = p.assumption('CASE:physical-original-row-active-engine', ['and', domain, ['<=', N, 'N'], guard])
            domain_p, upper_n, owned = [self.part(case, k) for k in [1, 2, 3]]
            e_active, physical, positive = [self.part(owned, k) for k in [1, 2, 3]]
            saved = self.bounded_instance(p.mp(state['saved-row-frame'], domain_p), N, lower_n, upper_n, {'watch': '0'})
            saved = self.unfold(saved, 'row-frame-I', [c('A', N), c('COLUMNS', N), c('ROW', N), c('FRAME', N), c('ROWFRAME', N), '0'], [lower_n, upper_n])
            ownership = p.mp(self.part(saved, 2), p.conjunction([physical, positive]))
            snapshot_valid = self.part(ownership, 1)
            history = self.bounded_instance(p.mp(state['historical-frame-origin'], domain_p), N, lower_n, upper_n)
            history = self.unfold(history, 'row-frame-origin-I', [c('ROWFRAME', N), c('FRAMEORIGIN', N), N], [lower_n, upper_n])
            history = p.mp(history, snapshot_valid)
            lower_j, strict_j = self.part(history, 1), self.part(history, 2)
            j = c('FRAMEORIGIN', N)
            upper_j = self.upper_from_strict(j, N, strict_j, upper_n)
            history = self.unfold(history, 'row-frame-origin-record-at', [j], [lower_j, upper_j])
            history = self.unfold(history, 'row-frame-origin-view-record',
                [c('row-source-view', c('A', j), c('COLUMNS', j)), c('ROW', j), c('FRAME', j)], [lower_j, upper_j])
            history = steps.normalize_selectors(p, language, history)
            capture, snapshot_array = self.part(history, 3), self.part(history, 9)
            assert p.nodes[snapshot_array]['formula'] == ['=', c('srf-data', c('ROWFRAME', N)), c('f-data', c('FRAME', j))]
            source_h = self.source_H_at(j, lower_j, upper_j)
            control_j = self.bounded_instance(p.mp(control_i, domain_p), j, lower_j, upper_j, {'watch': '0'})
            phase = self.part(control_j, 8)
            binding = data['row_guard_binding']
            mapping = {'a': c('A', j), 'columns': c('COLUMNS', j), 'row': c('ROW', j), 'header': c('HEADER', j)}
            whole = p.add('qualified-source-schema-uniform-instance', self.SUB(binding['combined_goal'], mapping), [lower_j, upper_j],
                original_query_goal=deepcopy(binding['combined_goal']), uniform_mapping=mapping,
                original_query_sha256=prepared['pins']['row_guard_query'], accepted_row_guard_seal_sha256=prepared['pins']['row_guard_seal'],
                accepted_raw_result_adjudication=deepcopy(data['row_guard_result']))
            actual = p.mp(self.part(whole, 3), p.conjunction([source_h, phase, capture]))
            live, e_weights, head = [self.part(actual, k) for k in [1, 2, 3]]
            engine_guard = self.SUB(prepared['engine']['guard'], {'i_active_head_engine_exponent': j})
            active_j = self.or_intro(e_weights, engine_guard[3][1:])
            actual_guard = p.conjunction([live, head, active_j])
            assert p.nodes[actual_guard]['formula'] == engine_guard
            engine_rule = self.instantiate(engine, {'i_active_head_engine_exponent': j}, [lower_j, upper_j])
            engine_j = p.mp(p.mp(engine_rule, lower_j), p.conjunction([domain_p, upper_j, actual_guard]))
            past_exponent = self.part(engine_j, 1)
            current_I = self.bounded_instance(p.mp(continuity, domain_p), N, lower_n, upper_n)
            current_I = self.unfold(current_I, 'actual-row-eexp-I', [c('A', N), c('ROW', N), j], [lower_n, upper_n])
            retained_exponent = p.mp(current_I, owned)
            historical_alias = self.define('actual-row-engine-exp-at', [j], [lower_j, upper_j])
            wrapper = p.nodes[historical_alias]
            assert wrapper['kind'] == 'conjunction-elimination' and wrapper['position'] == 1 and len(wrapper['parents']) == 1
            historical_bounds = wrapper['parents'][0]
            bound_chain = p.nodes[historical_bounds]
            assert bound_chain['kind'] == 'conjunction-introduction' and bound_chain['parents'][1:] == [lower_j, upper_j]
            historical_literal = bound_chain['parents'][0]
            assert p.nodes[historical_literal]['kind'] == 'literal-function-definition-instance'
            eq = p.nodes[historical_alias]['formula']
            retained_exponent = p.rewrite(retained_exponent, historical_alias, eq[1], eq[2])
            eq = p.nodes[past_exponent]['formula']
            original_exponent = p.rewrite(retained_exponent, past_exponent, eq[1], eq[2])
            active_frame, complete_frame = self.part(engine_j, 3), self.part(engine_j, 4)
            aliases = [self.view_field_alias(j, field, lower_j, upper_j) for field in ['live', 'head']]
            view_live, view_head = [p.rewrite(value, alias, p.nodes[alias]['formula'][2], p.nodes[alias]['formula'][1])
                for value, alias in zip([live, head], aliases)]
            frame_guard = p.conjunction([view_live, view_head, active_frame, complete_frame])
            capture_case = p.conjunction([domain_p, upper_j, frame_guard])
            def original_at(word):
                rule = self.instantiate(capture_global, {'capture-origin-watch': word, 'i_capture_origin': j}, [lower_j, upper_j])
                return p.mp(p.mp(rule, lower_j), capture_case)
            scalar_capture = original_at(['_', 'bv0', '8'])
            scalar, events = self.part(scalar_capture, 1), self.part(scalar_capture, 2)
            scalar_end = len(p.nodes) - 1
            language.decls[W] = ['declare-const', W, ['_', 'BitVec', '8']]
            word_capture = original_at(W)
            word = self.part(word_capture, 3)
            eq = p.nodes[snapshot_array]['formula']
            word = p.rewrite(word, snapshot_array, eq[2], eq[1])
            result = p.conjunction([ownership, history, original_exponent, scalar, events, word_capture, word])
            claim = p.implication(case, result)
            final = p.globalize(FAMILY, self.SUB(p.nodes[claim]['formula'], {N: '@index'}), claim, N, [[W, ['_', 'BitVec', '8']]])
            assert not p.active_indices and len(p.nodes) <= 192 and proof.root_context == self.context
            assert set(p.nodes[final]['support']) == set(self.context)
            self.lookup_ledger.append({'index': j, 'lower_parent': lower_j, 'strict_past_parent': strict_j, 'upper_parent': upper_j,
                'first_actual_record_unfold_parent': next(i for i, row in enumerate(p.nodes) if row['kind'] == 'literal-function-definition-instance' and row['definition'][1] == 'row-frame-origin-record-at'),
                'source_H_parent': source_h, 'control_instance_parent': control_j, 'past_engine_instance_parent': engine_j,
                'historical_EXP_definition_parent': historical_alias, 'historical_INDEX_added': False, 'source_edge_requested': False})
            self.lookup_ledger[-1].update({'historical_EXP_literal_definition_parent': historical_literal,
                'historical_EXP_bound_conjunction_parent': historical_bounds})
            return {'global_node': final, 'literal_global_formula': p.nodes[final]['formula'], 'guard': guard,
                'imports': deepcopy(self.imports), 'ownership_parent': ownership, 'history_parent': history,
                'snapshot_array_parent': snapshot_array, 'original_exponent_parent': original_exponent,
                'past_exponent_parent': past_exponent, 'retained_exponent_parent': retained_exponent,
                'scalar_capture_parent': scalar_capture, 'scalar_payload_parents': [scalar, events],
                'word_capture_parent': word_capture, 'snapshot_word_parent': word, 'result_parent': result,
                'scalar_nodes_end_before_word': scalar_end, 'word_parameter': W}
    app = Application()
    result = app.run()
    return deepcopy({'kind': 'physical-original-row-E-exponent-and-same-saved-RMS-snapshot', 'current': result,
        'nodes': proof.nodes, 'global_nodes': proof.global_nodes, 'root_context': proof.root_context,
        'lookup_ledger': app.lookup_ledger, 'new_native_jobs': 0, 'new_inductions': 0,
        'all_snapshot_words_not_unconsumed_row_operands': True, 'current_NF_substituted': False,
        'read_dot_metadata_postscale_selector_join_proved': False, 'whole_device_theorem': False})

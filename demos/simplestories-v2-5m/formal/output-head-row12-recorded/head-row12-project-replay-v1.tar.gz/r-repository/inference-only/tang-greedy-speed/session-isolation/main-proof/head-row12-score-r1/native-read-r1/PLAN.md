# Actual row12 synchronous-read and stage1 source leaves

Two source leaves in the unchanged c070 core, independently reviewed before
any native execution. These are useful read/cone facts while the exponent
prefix application is reviewed; they do not depend on an assumed exponent.

1. The actual engine issue at local count12 drives all four tile read enables
   and low4 lane12, with global advance. Under both H and all452 T, tile0's
   registered dot/multiplier/exponent at the successor equal its pre-edge
   accumulator12 and metadata memories12; selected_tile becomes0 and row tag0
   becomes12. If read is absent, the registered tuple holds. This is read-before-
   write even if metadata changes on that edge. No reset/CLEAR/health endpoint
   filter is introduced for this resetless physical payload.
2. On advance, valid stage0, selected tile0 and row tag12, the actual stage1
   operands and exponent/tag equal the PRE-edge registered tile0 tuple with
   their exact signed/unsigned extensions. They do not use the tile outputs at
   the successor, which can already be row13. When advance is false, all14
   physical payload/selection/tag registers hold, including product/result
   fields. Physical writes on a first-fault/CLEAR edge confer no valid authority.

No desired dot, metadata image bytes, UID, job, score or successful future is
assumed. These facts alone do not connect the original completed model dot to
the read, the fixed-image metadata to the memories, or that tuple to selector
admission. Those source/ownership/prefix applications remain explicit work.
The existing reset-founded row12/row13 fixture is sensitivity evidence only;
its oracle numbers are not new premises or a whole-caller reachability claim.

Two first attempts only after exact independent input review, freeze and pure
preflight. One owned worker,4GiB sampled RSS/footprint/internal memory4096,
actual normal Darwin pressure, pinned accepted guard/probes. No new probes,
simulator/build, wall/CPU/token kill or fixed free-RAM floor. Unexpected output
stops dependents and is preserved; diagnostics/revisions need a new small
reviewed additive gate. No public/board or whole-device/numerical RMS claim.

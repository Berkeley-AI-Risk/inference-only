# Pre-proof manifest path correction

The first one-off raw-manifest writer looked for
CAPTURE-ROW-TYPING-ONLY.smt2. The actual sealed filename is
CAPTURE-ROW-APPLICATION-R1-TYPING-ONLY.smt2. FileNotFoundError occurred while
hashing prospective inputs, before any manifest output, application function,
metadata gate, Proof initializer, solver or typecheck for this version ran.
The still-unfrozen driver seal member and manifest path were corrected before
independent input review. This is preparation provenance, not a failed theorem
or native attempt. The accepted earlier components are unchanged.

if not __debug__:raise RuntimeError('Optimization forbidden')
from pathlib import Path
import sys,json,hashlib,ctypes,errno
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import mode_guard

def cleanup_observations(binding):
    guard=mode_guard.load();rows=[]
    for pid,original_start in binding['observed_start_identities'].items():
        usage=guard.Usage();rc=guard.LIB.proc_pid_rusage(pid,0,ctypes.byref(usage))
        if rc:
            assert ctypes.get_errno()==errno.ESRCH,'Cannot verify post-stop owned PID'
            rows.append({'pid':pid,'original_start_abstime':original_start,'status':'absent',
                'live_original_process':False});continue
        same=usage.proc_start_abstime==original_start
        live=bool(same and (usage.resident_size or usage.phys_footprint))
        rows.append({'pid':pid,'original_start_abstime':original_start,
            'observed_start_abstime':usage.proc_start_abstime,
            'rss_bytes':usage.resident_size,'physical_footprint_bytes':usage.phys_footprint,
            'status':'same-identity-terminal' if same else 'identity-no-longer-owned',
            'live_original_process':live})
    assert rows and not any(r['live_original_process'] for r in rows)
    return rows

def main():
    assert sys.platform=='darwin' and sys.version_info[:2]==(3,12)
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    root=HERE/'guard-probes';root.mkdir(exist_ok=False)
    # Both tiny children have their own finite lifetime if the monitor fails.
    # No elapsed-time kill is imposed on a proof engine.
    memory=[sys.executable,'-I','-S','-B','-c',
        'import time; payload=bytearray(16<<20); time.sleep(0.75)']
    one,binding1=mode_guard.execute(memory,HERE,root/'memory',memory_cap=1<<20)
    assert one['native_exit']<0 and one['resource_stop_reason']
    assert not one['monitor_errors'] and one['observation_count']>0
    helper_code='import time; payload=bytearray(1<<20); time.sleep(0.75)'
    parent='import subprocess,sys; p=subprocess.Popen([sys.executable,"-I","-S","-B","-c",'+repr(helper_code)+']); p.wait()'
    two,binding2=mode_guard.execute([sys.executable,'-I','-S','-B','-c',parent],HERE,
        root/'helper',memory_cap=4*(1<<30),single_process=True)
    assert two['native_exit']<0 and two['resource_stop_reason']=='unexpected native helper process'
    assert not two['monitor_errors'] and len(two['observed_owned_pids'])>=2
    cleanup={'passed':True,'memory_probe':cleanup_observations(binding1),
        'helper_probe':cleanup_observations(binding2),'signals_sent_after_reaping':False}
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'passed':True,'purpose':'tiny actual RSS/physical-footprint/pressure/owned-group cleanup probes',
        'memory_probe':one,'helper_probe':two,'monitor_bindings':[binding1,binding2],
        'post_stop_cleanup':cleanup,'implementation':{
            'probe_guard_sha256':sha(HERE/'probe_guard.py'),
            'mode_guard_sha256':sha(HERE/'mode_guard.py'),
            'native_resource_guard_sha256':sha(mode_guard.SOURCE)},
        'Z3_jobs':0,'production_or_witness_jobs':0,'no_simulation_reservation_claimed':True}
    (HERE/'GUARD-PROBES.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'passed':True,'Z3_jobs':0,'memory_stop':one['resource_stop_reason'],
        'helper_stop':two['resource_stop_reason'],'helper_PIDs':two['observed_owned_pids']}))

if __name__=='__main__':main()

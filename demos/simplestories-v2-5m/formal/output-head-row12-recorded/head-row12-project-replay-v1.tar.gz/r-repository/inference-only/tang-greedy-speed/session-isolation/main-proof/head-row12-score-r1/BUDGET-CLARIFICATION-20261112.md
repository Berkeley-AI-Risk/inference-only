# Additive batch-budget clarification

The coordinating Senior architect clarified that the eight Phase A entries
are the contents of that independently reviewed batch, not a global attempt
allowance for the active same-row12 score assignment. Further useful local
obligations and diagnostics may proceed in another small batch after exact
independent review, under the existing one-worker, 4 GiB RSS/physical-footprint
and normal actual Darwin-pressure safeguards. A completed batch alone does
not require another architect or user approval.

An unexpected SAT, error, unknown, resource stop or unsupported source transfer
still stops its affected dependency chain. Preserve the exact query, raw result,
receipts, partial construction and status. Any changed formula is an additive
version with its own review; no blind retry, weakening or lost failure. There
is no wall, CPU or token kill. Old plans, reviews and frozen bytes remain intact.

The four exponent leaves used four native jobs, all first-attempt UNSAT; their
result review is EXPONENT-LEAVES-RESULT-REVIEW.md (008dc8a5...). The next intended
small gate is the single head-start history base/preservation and its fixed
origin recurrence, subject to concrete input review. This clarification grants
no numerical RMS, metadata, score or whole-device result. No public/board work.

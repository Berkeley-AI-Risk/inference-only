# Independent bounded certificate-prefix gate result review

Accepted for the three recorded bounded results: native retained-job classification UNSAT, conditional generic certificate zero/embedding/step UNSAT, and same-prefix replacement control SAT. No diagnostic was launched. These results do not establish the actual same-trace certificate application, a whole-frame/ROWFRAME theorem, independent NF qualification, numerical RMS or the whole-device theorem.

This review used read-only preflight/reconstruction and independent parsing of the recorded outputs, receipts and journals. No native job, probe, compiler, simulator or process-control operation ran; only this new review was written.

## Input and result binding

All 16 frozen local inputs match `FROZEN-INPUTS.json`, SHA256 `5fa0c1134741939ae484bb462058f2e9cf0ee9d79b728233526365cfc205917b`. The accepted review is unchanged at `05e38a87b0e4fff5ce34a4cab4e83ca1fde416a2b4f3a5f8a43eabd6c4768778`; `REVIEW-ACCEPTED.json` hashes to `5b33d256943ed6b96f3b8063b417f3dcc5997e746995e0e524efa539339cf78e` and binds that review, freeze, scope, four-attempt ceiling and conditional diagnostic permission. All 45 external pins and the actual Z3 binary match.

The reviewed runner's pure preflight succeeded under isolated, no-site, no-bytecode Python with writes/process/network operations blocked. It reconstructed all four exact queries, canonical JSON binding, typing and raw dependency records and checked 64 local/external/envelope/tool pins. Each recorded command is the pinned Z3 binary with `-smt2 -st -memory:4096` and the exact absolute query path, using this packet as cwd. The actual binary remains SHA256 `ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`.

| Query | Query SHA256 | Raw answer | Native wall seconds |
| --- | --- | --- | ---: |
| `source-retained-job-classification` | `f197ad90bd5700168ced1ffa04ac81b3872dd6fd428951ba54818e203769cfb4` | UNSAT | 0.7139368057 |
| `generic-certificate-zero-step` | `77454c7dc5186b370bbe9516a702621e61bb6da61fda269dcd8d865ed1d85090` | UNSAT | 0.0153820515 |
| `same-prefix-later-NF-replacement-control` | `1c6ebc3827cd38ddc64bb0c7a7b15694cde87a40dc3598505612cf22a6955cb9` | SAT | 0.0089652538 |

Each raw log parses as exactly the answer and one valid statistics form, with `:num-checks 1`; no extra output or value/model response is present. Each per-run checked result equals its entry in `RESULTS.json` and embeds the actual FINISHED and MONITOR-BINDING records exactly. Native exit and raw wait status are zero throughout; parse errors, guard errors, resource stop reasons and monitor errors are absent.

## Serial ownership, resources and reaping

The recorded order is exactly the three approved queries. Each previous finish precedes the next start. There are three attempt files, three run directories and three journals, with no diagnostic directory. The event journal contains alternating attempt/result entries and one successful terminal entry. `RESULTS.json` records three starts/attempts, no active owned job and stop reason `all-three-expected-results`.

| Query | PID/PGID | Stable start identity | Live / terminal group samples | Peak sampled RSS | Peak sampled footprint | Kernel wait4 max RSS |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Source | 94828 | 43252001488648 | 13 / 1 | 203,538,432 | 199,229,992 | 258,310,144 |
| Generic | 94844 | 43252019698436 | 1 / 1 | 2,048,000 | 1,671,576 | 28,344,320 |
| Control | 94846 | 43252021086631 | 1 / 1 | 1,753,088 | 1,442,104 | 27,131,904 |

Every group total equals the sum of its members; all live members belong to the sole recorded process and retain its original start identity. Every terminal group sample is empty and precedes FINISHED. Admission and all pressure observations are 1 (normal): 15 source, 3 generic and 3 control running/monitor pressure records, plus each admission. Sampled RSS/footprint and the independent kernel RSS high-water marks are below 4 GiB. The short generic/control jobs explain why their sampled peaks are lower than their kernel RSS maxima; the samples are not a continuous physical-footprint guarantee.

The receipts retain one-process enforcement, no elapsed/CPU limits, zero disk floor and no shared simulator reservation. The unchanged pinned native guard checks owned descendants before `wait4`, so empty terminal groups plus clean raw wait receipts support normal reaping without surviving observed helpers. This is recorded-evidence validation, not a new live-process survey. The existing guard probes remain unchanged and were not rerun.

## Exact meanings and remaining work

The source UNSAT establishes the reviewed one-edge implication under H(a), H(b), all native T conjuncts, literal !drop(a), literal !begin(a), and Jlive(b): named job7 classification at b equals classification at a. It adds no NF, ROM, numerical or certificate premise. Successor liveness handles the reset-masked named job value; this is not a new reset-reachability proof.

Generic UNSAT establishes the zero case, BV10-to-BV8 embedding fact under the stated bound, and one certificate-preservation step under its explicit current induction hypothesis and source-interface ledger. The certificate and historical capture-record function remain independent of the arbitrary watch coordinate. This discharges the generic lemma, not the still-required same-trace source substitutions and provider qualification.

The expected SAT confirms the reviewed generic completed-frame control: one fixed historical NF/certificate works for every watch while a later same-prefix NF has different STEP/RMS IDs and word13. It therefore distinguishes the saved historical origin from current same-prefix data. It is not a source-design failure or a reset-reachable counterexample. Source application, original NF qualification, historical FRAME/ROWFRAME composition, numerical meaning and the whole-device theorem correctly remain false/unproved in the records.

## Durable evidence hashes

| Evidence | SHA256 |
| --- | --- |
| `RUN-INTENT.json` | `88643e5a667ce2b70a57342f109b34f1652342e1cf4117706b234e8cfc1900bf` |
| `RUN-EVENTS.jsonl` | `77e4716f605805d622464ae9fd5808e15a0c4cd5ce0eaafe42edf6b0c913182e` |
| `RESULTS.json` | `5cb10f219ce90d62c7579b2ef97d4d8a595623fa9268b1bd378683ef37bf1b5f` |
| Source `NATIVE.log` | `dede6e10423808312c4d80fac48794fc548b208bc6bb8d6da65740fd1a016280` |
| Source `CHECKED-RESULT.json` | `723aa268e53f806691e4dd1df5e3846357823547107ed5252350948b72cb55d4` |
| Source journal | `420bbbb87ed69c96ffaaeaaed9b80b8754c63dd887d2e11bf173a96d85a638fa` |
| Generic `NATIVE.log` | `45de5fe5a26f9a65071594f5ba423ad7f26030fd24418634f32dae6b7dbe2d9f` |
| Generic `CHECKED-RESULT.json` | `28fbf79bc4389415e7fc9193eb365070660b2b775a1c01dd26485da03d3d5892` |
| Generic journal | `c8e17dd6163d4535a4281f7569d240cfe455e6e96e85b41a82181a473fe04d1b` |
| Control `NATIVE.log` | `36e185881386c0794486c54ebc37bbcd5ac01937fbb0d734f892ace283a8f6fc` |
| Control `CHECKED-RESULT.json` | `3adc21394ea173d4f0198b9ccb95f83ea001bf4807321c2dc7bb12325472d73f` |
| Control journal | `d82a1f4803e539b0036f744386b7a754d0195fc651290869a47afdc283e3a08a` |

The per-run checked-result hashes transitively bind the detailed receipts, monitor identities and raw-log/journal hashes reviewed above. No retry or additional diagnostic is warranted by these expected results.

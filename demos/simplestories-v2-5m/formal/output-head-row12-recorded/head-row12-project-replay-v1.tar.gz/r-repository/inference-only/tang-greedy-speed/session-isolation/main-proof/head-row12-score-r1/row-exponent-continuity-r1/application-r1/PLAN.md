# Original-prefix physical row/exponent continuity induction

Unrun ordinary application of the two reviewed native continuity leaves; no
new solver or observer. Fixed EXP_AT is realized once as the actual E exponent
getter on A(t), before any induction index. The native invariant is uniformly
realized as actual-row-eexp-I using that one function, with no supplied RMS or
historical value. The current-point bridge is its literal function definition.

Base: actual H/reset-low sample1 supplies the invariant for arbitrary ROW(1)
and FRAMEORIGIN(1). No desired initial exponent or payload is assumed. Step:
both H/all452 T/current IH/current-point bridge supply the native next-row and
next-origin conclusion. Qualified total original ROW and FRAMEORIGIN observer
definitions rewrite it to the actual functions at n+1. Empty arrays map to the
original fixed empty-a/w/prefix constants, without a different row recurrence.

The original completed-dot seal/typed source/DAG/prefix bind total ROW anchors
755/775 and FRAMEORIGIN1654/1701. Check original step domain/support, literal
source definitions and exact bounded prefix counterparts. Only step anchors are
needed in this induction; base follows from reset for arbitrary row/origin.
They are the original nondriving histories, not new assumptions about native
state. Preserve the full original context; the resulting scalar theorem may
use just actual-source and reset-at-1 roots, since it needs no model oracle.

Budget96 deduction nodes/zero engines. Exact static input review and six-file
freeze before metadata0, then one construction. Validate all rule/support and
ordinary-induction steps, fixed function realization, actual current-point
bridge and original recurrence ancestry. Finite-prefix base accesses0/1 only;
step accesses n/n+1 only on1<=n<N. Historical EXP_AT calls inside the guarded
invariant remain opaque: only a later separately reviewed consequence may
unfold actual A(j), after1<=j<n<=N is derived. Retain same41af bounded context.

Typecheck actual generated DAG/positive conclusions using the pinned pure
checker, no solver. Independently replay complete JSON/typing bytes. Stop and
save partial DAG/scopes/read/helper evidence on any unexpected assertion; any
revision uses additive reviewed files. Old proofs and native recorders are
never rerun. This result alone does not establish original R0 at a read,
metadata, scaled score, authority or legal selector admission.

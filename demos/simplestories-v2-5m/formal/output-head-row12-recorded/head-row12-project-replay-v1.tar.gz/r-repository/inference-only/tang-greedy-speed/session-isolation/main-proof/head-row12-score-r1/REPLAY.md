# Read-only exponent component replay

The intended closed entry is check_component.py in this directory, with the
absolute pinned inputs in FROZEN-EXPONENT-COMPONENT.json. Its closure/result
review must be complete before treating this as a closed verification packet.
THEOREM.md states the exact source claim and remaining score/selector boundary.

The entry performs only local reads and pure proof/query reconstruction:

- Reproduce the four gate preparations and validate all12 recorded native
  UNSAT protocols, tool/query/source bindings and monitored/reaped execution
  receipts through check_native_leaves.py. The old recorded_run helper is used;
  its writing/engine/check entry is never called. Statistics may legitimately
  omit num-checks when simplification discharges a single-check query.
- Reproduce the96-node original HS/origin/HF induction application and its
 98-assertion typing specimen, byte for byte.
- Reproduce the131-node current/historical original saved-RMS exponent
  application and its typing specimen, byte for byte. All original bounds,
  source schemas, function realizations and component supports remain explicit.
- Check every actual read/executed helper against the frozen envelope under
  a deny-write/process/network/ctypes audit and restore the caller namespace.

No solver, simulator, RTL compiler, board, resource probe or Lean process is
started. The SMT typing specimens contain the earlier standard single check
marker for the pure typechecker; they are not run as proof queries. The recorded
native .smt2 queries and their accepted raw answers supply the engine evidence.

After final closure, run from this directory:

```sh
/proof/z-historical-host/bin/python3.12 -I -S -B check_component.py
```

The command prints a short result and writes nothing. The12 native leaves are
conditional source facts. The combined theorem additionally supplies the
original finite-prefix/historical applications; it does not claim the later
metadata, scaled score, selector admission or whole-device theorem.

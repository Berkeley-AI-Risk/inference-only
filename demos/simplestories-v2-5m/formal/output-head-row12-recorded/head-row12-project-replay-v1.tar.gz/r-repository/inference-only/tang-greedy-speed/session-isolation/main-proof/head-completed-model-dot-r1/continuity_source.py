if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import parent_library,frame_library,prepare_continuity,continuity_receipts
from prepare_continuity import *


def construct():
    receipts=continuity_receipts.check()
    frame=frame_library.load()
    proof,language,r3,parent_binding,owner,parent_replay=parent_library.load()
    fb=frame['binding']
    operand_path=ROOT/'rmsnorm-pilot/model-consumption/operand-step.smt2'
    operand_raw=operand_path.read_bytes()
    assert sha(operand_raw)=='38dd4f69b6b7e2e8bce633f13af1787b73b7ea784bb547fffad690c8156df1ec'
    operand_helpers=[f for f,_,_ in parse_spans(operand_raw)]
    assert len(operand_helpers)==1 and operand_helpers[0][:2]==['define-fun','operand-native-step']
    assert frame['read_pins'][str(operand_path.relative_to(ROOT))]==sha(operand_raw)
    language.add(operand_helpers)
    language.add([*fb['capture_helpers'],*fb['frame_helpers'],*prepare_continuity.definitions()])
    for name,args,result in [('CAPTURE',['Int'],'CaptureHistory'),('FRAME',['Int'],'FrameHistory'),
                             ('ROWFRAME',['Int'],SN)]:
        assert name not in language.decls and name not in language.defs
        language.decls[name]=['declare-fun',name,args,result]
    def observer(which,index,step=False):
        state=c('A',index);cols=c('COLUMNS',index)
        current=lambda symbol:c(symbol,index)
        specs={
            'capture':('CAPTURE',c('capture-zero',c('A','1')),c('capture-next',state,current('CAPTURE'))),
            'frame':('FRAME',c('frame-zero','unused-frame'),
                c('frame-next',state,cols,current('FRAME'),'unused-frame')),
            'snapshot':('ROWFRAME',c('row-frame-zero','unused-frame'),
                c('row-frame-next',state,cols,current('ROW'),current('FRAME'),current('ROWFRAME'),'unused-frame'))}
        symbol,zero,nxt=specs[which]
        if step:
            support=proof.index_support(index,True)
            equation=eq(c(symbol,c('+',index,'1')),nxt);parents=proof.index_parents(index)
        else:
            assert index=='1';support=[];parents=[];equation=eq(c(symbol,'1'),zero)
        return proof.add('total-same-trace-nondriving-component-observer-definition',equation,parents,
            support=['Gamma:actual-composed-source',*support],registry=which,index=index,step=step,
            watched_index_not_an_observer_argument=True)
    def close(name,template,base,step,index,ih,parameters):
        assert proof.nodes[base]['formula']==SUB(template,{'@index':'1'})
        assert proof.nodes[ih]['formula']==SUB(template,{'@index':index})
        assert proof.nodes[step]['formula']==SUB(template,{'@index':c('+',index,'1')})
        labels=['IH:'+name,'INDEX:'+name]
        assert set(proof.nodes[base]['support'])<=set(proof.root_context)
        assert set(proof.nodes[step]['support'])<=set(proof.root_context)|set(labels)
        for parameter,_ in parameters:
            assert parameter not in atoms([v.get('formula',[]) for v in proof.root_context.values()])
            assert parameter not in atoms(proof.root_context['Gamma:actual-composed-source']['formal_native_consequences'])
        formula=['forall',[*parameters,[index,'Int']],IMP(c('<=','1',index),SUB(template,{'@index':index}))]
        node=proof.add('ordinary-induction',formula,[base,step],base_parent=base,step_parent=step,
            scoped_IH=ih,bound_parent=proof.active_indices[index]['node'],fresh_step_index=index,
            property_template=template,quantified_parameters=parameters,scoped_hypothesis_removed=True,
            discharged_support=labels)
        proof.nodes[node]['support']=sorted((set(proof.nodes[base]['support'])|set(proof.nodes[step]['support']))-set(labels))
        proof.global_nodes[name]=node;del proof.active_indices[index]
        return node
    def open_induction(name,index,template):
        bound=proof.open_index(name,index)
        return proof.add('scoped-induction-hypothesis',SUB(template,{'@index':index}),[bound],
                         support=['IH:'+name],scope=index)
    def qualified_capture(name,mapping):
        rule=fb['source_JobHistory_provider_rules'][name]
        parse=lambda text:[f for f,_,_ in parse_spans(text.encode())][0]
        assumptions=[SUB(parse(x),mapping) for x in rule['assumptions']]
        goal=SUB(parse(rule['conclusion']),mapping)
        return proof.add('qualified-source-capture-uniform-rule',IMP(AND(*assumptions),goal),
            qualified_frame_seal_sha256='1e696bea46432353bd56a20d183dc6a6f92a72206af4024c4e44d4057b861e84',
            source_rule_name=name,source_rule=rule,uniform_mapping=mapping)
    def qualified_frame(statement,mapping):
        assert statement in fb
        return proof.add('qualified-accepted-frame-uniform-source-rule',SUB(fb[statement],mapping),
            qualified_frame_seal_sha256='1e696bea46432353bd56a20d183dc6a6f92a72206af4024c4e44d4057b861e84',
            source_statement_name=statement,source_statement=fb[statement],uniform_mapping=mapping)
    def actual(index,next_index=None):
        result=[proof.source(c('|core_workflow_control_h|',c('A',index)))]
        if next_index is not None:result.extend([
            proof.source(c('|core_workflow_control_h|',c('A',next_index))),
            proof.source(c('|core_workflow_control_t|',c('A',index),c('A',next_index)))])
        return result
    def fold(node,kind,index,step=False):
        eqid=observer(kind,index,step);equation=proof.nodes[eqid]['formula']
        return proof.rewrite(node,eqid,equation[2],equation[1])
    def columns_fold(node,index,step=False):
        eqid=proof.control_definition('columns',index,step);equation=proof.nodes[eqid]['formula']
        return proof.rewrite(node,eqid,equation[2],equation[1])

    # Independent real capture history, anchored at the original A0 -> A1.
    theorem=qualified_capture('reset-base',{'a':c('A','0'),'an':c('A','1')})
    sources=[proof.source(c('|core_workflow_control_i|',c('A','0'))),
             *actual('0','1'),proof.source(NOT(n('reset_n',c('A','0'))))]
    base=proof.mp(theorem,owner.derive(proof,proof.nodes[theorem]['formula'][1],sources))
    base=fold(base,'capture','1')
    name='actual-capture';index='n_actual_capture'
    template=c('capture-inv',c('A','@index'),c('CAPTURE','@index'))
    ih=open_induction(name,index,template);after=c('+',index,'1')
    weak=qualified_capture('native-step-weakening',{'a':c('A',index),'an':c('A',after)})
    source=actual(index,after)
    native=proof.mp(weak,owner.derive(proof,proof.nodes[weak]['formula'][1],source))
    nxt=observer('capture',index,True)
    theorem=qualified_capture('preserved',{'a':c('A',index),'an':c('A',after),
        'ch':c('CAPTURE',index),'chn':c('CAPTURE',after)})
    step=proof.mp(theorem,owner.derive(proof,proof.nodes[theorem]['formula'][1],[*source,native,ih,nxt]))
    close(name,template,base,step,index,ih,[])

    # One deterministic accepted frame, uniform in the BV10 watched coordinate.
    watch='frame-watch'
    projection=qualified_frame('source_qualified_capture_projection_goal',{'a':c('A','1'),'capture':c('capture-zero',c('A','1'))})
    cap=proof.trace_instance('actual-capture','1')
    capzero=observer('capture','1');equation=proof.nodes[capzero]['formula']
    cap=proof.rewrite(cap,capzero,equation[1],equation[2])
    theorem=qualified_frame('shared_postreset_base_goal',{'a':c('A','0'),'b':c('A','1'),
        'empty':'unused-frame','watch':watch})
    base=proof.mp(theorem,owner.derive(proof,proof.nodes[theorem]['formula'][1],[*sources,cap]))
    wanted=c('frame-I',c('A','1'),'columns-zero',c('job-zero',c('A','1')),
             c('frame-zero','unused-frame'),watch)
    base=owner.derive(proof,wanted,[base])
    equality=owner.derive(proof,eq(c('c-base',c('capture-zero',c('A','1'))),c('job-zero',c('A','1'))),[projection])
    base=proof.rewrite(base,equality,proof.nodes[equality]['formula'][2],proof.nodes[equality]['formula'][1])
    base=fold(base,'capture','1');base=fold(base,'frame','1');base=columns_fold(base,'1')
    name='actual-frame';index='n_actual_frame'
    template=c('frame-I',c('A','@index'),c('COLUMNS','@index'),c('c-base',c('CAPTURE','@index')),
               c('FRAME','@index'),watch)
    ih=open_induction(name,index,template);after=c('+',index,'1')
    current=proof.trace_instance('actual-capture',index)
    following=proof.trace_instance('actual-capture',after)
    control=[proof.trace_instance('control',at,{'watch':'0'}) for at in [index,after]]
    projections=[qualified_frame('source_qualified_capture_projection_goal',
        {'a':c('A',at),'capture':c('CAPTURE',at)}) for at in [index,after]]
    theorem=qualified_frame('prefix_induction_goal',{'a':c('A',index),'b':c('A',after),
        'h':c('COLUMNS',index),'j':c('c-base',c('CAPTURE',index)),'f':c('FRAME',index),
        'empty':'unused-frame','watch':watch})
    transition=proof.source(c('|core_workflow_control_t|',c('A',index),c('A',after)))
    weak=language.native_weakening('|core_workflow_control_t|','current-job-native-step')
    weak=SUB(weak,dict(zip([v[0] for v in language.defs['current-job-native-step'][2]],
                         [c('A',index),c('A',after)])))
    weak=proof.add('literal-full-native-transition-weakening',weak,
        full_definition=language.defs['|core_workflow_control_t|'],
        subset_definition=language.defs['current-job-native-step'])
    transition=proof.mp(weak,transition)
    # Rewrite the already proved successor providers into their exact source
    # recurrences, not a desired successor or future-health assumption.
    premises=[current,following,*control,*projections,ih,*actual(index,after),transition]
    normalized=[]
    for node in premises:
        for kind in ['capture','frame']:
            definition=observer(kind,index,True);equation=proof.nodes[definition]['formula']
            node=proof.rewrite(node,definition,equation[1],equation[2])
        definition=proof.control_definition('columns',index,True);equation=proof.nodes[definition]['formula']
        node=proof.rewrite(node,definition,equation[1],equation[2])
        normalized.append(node)
    # The old frame step uses JobHistory-next. The qualified capture
    # projection identifies that exact next value on this same history.
    projection=qualified_frame('source_qualified_capture_projection_goal',
        {'a':c('A',index),'capture':c('CAPTURE',index)})
    eqjob=owner.derive(proof,eq(c('c-base',c('capture-next',c('A',index),c('CAPTURE',index))),
                              c('job-next',c('A',index),c('c-base',c('CAPTURE',index)))),[projection])
    normalized=[proof.rewrite(node,eqjob,proof.nodes[eqjob]['formula'][1],proof.nodes[eqjob]['formula'][2])
                for node in normalized]
    premise=owner.derive(proof,proof.nodes[theorem]['formula'][1],normalized)
    step=proof.mp(theorem,premise)
    # Fold the same commuting JobHistory projection back to CAPTURE(n+1).
    step=proof.rewrite(step,eqjob,proof.nodes[eqjob]['formula'][2],proof.nodes[eqjob]['formula'][1])
    step=fold(step,'capture',index,True);step=fold(step,'frame',index,True);step=columns_fold(step,index,True)
    close(name,template,base,step,index,ih,[[watch,B(10)]])

    # New source schema: establish the independent row-frame snapshot and all
    # admitted activation records on that one actual frame history.
    queries,binding,_=prepare_continuity.assemble()
    def schema(name,mapping):
        assert receipts['results'][name]['answer']=='unsat'
        assert sha(queries[name])==receipts['results'][name]['query_sha256']
        return proof.add('qualified-continuity-source-schema-uniform-instance',SUB(binding['goals'][name],mapping),
            source_goal=binding['goals'][name],uniform_mapping=mapping,
            qualified_engine_receipt=receipts['results'][name])
    theorem=schema('row-frame-zero-base',{'a':c('A','1'),'unused-frame':'unused-frame','watch':'watch'})
    base=theorem
    for kind in ['frame','snapshot']:base=fold(base,kind,'1')
    for kind in ['columns','row']:
        definition=proof.control_definition(kind,'1');equation=proof.nodes[definition]['formula']
        base=proof.rewrite(base,definition,equation[2],equation[1])
    name='saved-row-frame';index='n_saved_row_frame'
    template=c('row-frame-I',c('A','@index'),c('COLUMNS','@index'),c('ROW','@index'),
               c('FRAME','@index'),c('ROWFRAME','@index'),'watch')
    ih=open_induction(name,index,template);after=c('+',index,'1')
    mapping={'a':c('A',index),'b':c('A',after),'columns':c('COLUMNS',index),
        'capture':c('CAPTURE',index),'frame':c('FRAME',index),'row':c('ROW',index),
        'header':c('HEADER',index),'snapshot':c('ROWFRAME',index),'unused-frame':'unused-frame','watch':'watch'}
    facts=[ih,*actual(index,after)]
    for at_index in [index,after]:
        facts.extend([proof.trace_instance('control',at_index,{'watch':'0'}),
            proof.trace_instance('actual-capture',at_index),
            proof.trace_instance('actual-frame',at_index,{'frame-watch':ibv('watch')}),
            proof.trace_instance('actual-frame',at_index,{'frame-watch':n(E+'column_q',c('A',at_index))})])
    for statement in ['actual_consumption_goal','completed_frame_stability_goal']:
        fm={'a':c('A',index),'h':c('COLUMNS',index),'capture':c('CAPTURE',index),
            'j':c('c-base',c('CAPTURE',index)),'f':c('FRAME',index),
            'empty':'unused-frame','watch':ibv('watch')}
        facts.append(qualified_frame(statement,fm))
    facts.append(proof.add('qualified-R3-phase-consequence-uniform-instance',SUB(r3['phase']['actual_consequence'],mapping),
        source_statement=r3['phase']['actual_consequence'],uniform_mapping=mapping,
        qualified_R3_seal_sha256='fc55ead5aecaa9af9da29b2b228849e300624667e163e4d9432ee0f7c16a2d84'))
    normalized=[]
    for node in facts:
        for kind in ['capture','frame','snapshot']:
            definition=observer(kind,index,True);equation=proof.nodes[definition]['formula']
            node=proof.rewrite(node,definition,equation[1],equation[2])
        for kind in ['columns','row','header']:
            definition=proof.control_definition(kind,index,True);equation=proof.nodes[definition]['formula']
            node=proof.rewrite(node,definition,equation[1],equation[2])
        normalized.append(node)
    theorem=schema('same-frame-row-prefix-induction',mapping)
    premise=owner.derive(proof,proof.nodes[theorem]['formula'][1],normalized)
    step=proof.mp(theorem,premise)
    for kind in ['capture','frame','snapshot']:step=fold(step,kind,index,True)
    for kind in ['columns','row','header']:
        definition=proof.control_definition(kind,index,True);equation=proof.nodes[definition]['formula']
        step=proof.rewrite(step,definition,equation[2],equation[1])
    close(name,template,base,step,index,ih,[['watch','Int']])
    name='accepted-row-frame-origin';index='n_accepted_frame_origin'
    proof.open_index(name,index)
    mapping={'a':c('A',index),'columns':c('COLUMNS',index),'capture':c('CAPTURE',index),
        'frame':c('FRAME',index),'row':c('ROW',index),'header':c('HEADER',index),
        'snapshot':c('ROWFRAME',index),'unused-frame':'unused-frame','watch':'0'}
    facts=[*actual(index),proof.trace_instance('control',index,{'watch':'0'}),
        proof.trace_instance('actual-capture',index),
        proof.trace_instance('actual-frame',index,{'frame-watch':ibv('0')}),
        proof.trace_instance('actual-frame',index,{'frame-watch':n(E+'column_q',c('A',index))})]
    facts.append(qualified_frame('actual_consumption_goal',{'a':c('A',index),
        'h':c('COLUMNS',index),'capture':c('CAPTURE',index),'f':c('FRAME',index),'empty':'unused-frame'}))
    facts.append(proof.add('qualified-R3-phase-consequence-uniform-instance',SUB(r3['phase']['actual_consequence'],mapping),
        source_statement=r3['phase']['actual_consequence'],uniform_mapping=mapping,
        qualified_R3_seal_sha256='fc55ead5aecaa9af9da29b2b228849e300624667e163e4d9432ee0f7c16a2d84'))
    theorem=schema('actual-selected-admission-frame-owner',mapping)
    result=proof.mp(theorem,owner.derive(proof,proof.nodes[theorem]['formula'][1],facts))
    result=fold(result,'frame',index,True)
    proof.globalize(name,SUB(proof.nodes[result]['formula'],{index:'@index'}),result,index,[])
    assert not proof.active_indices
    for node in proof.nodes:
        expected=set(node['introduced_support'])
        for parent in node['parents']:
            assert parent<node['id'];expected.update(proof.nodes[parent]['support'])
        expected-=set(node.get('discharged_support',[]))
        assert expected==set(node['support']),(node['id'],'support')
    return proof,language,{'qualified_parent_replay':parent_replay,'qualified_frame_replay':frame,
        'continuity_receipts':receipts,'capture_schema':proof.nodes[proof.global_nodes['actual-capture']],
        'frame_schema':proof.nodes[proof.global_nodes['actual-frame']],
        'saved_frame_schema':proof.nodes[proof.global_nodes['saved-row-frame']],
        'accepted_origin_schema':proof.nodes[proof.global_nodes['accepted-row-frame-origin']],
        'qualified_capture_native_step_helper':{'file':str(operand_path.relative_to(ROOT)),
            'sha256':sha(operand_raw),'definition':operand_helpers[0]},
        'one_uniform_actual_F_definition':r3['app']['uniform_F_actual_definition'],
        'finite_prefix_export_still_required':True,'independent_source_application_review_pending':True,
        'completed_model_dot_qualified':False,'whole_device_theorem':False,'new_engine_jobs':0}


if __name__=='__main__':
    proof,language,binding=construct()
    (HERE/'CONTINUITY-SOURCE-APPLICATION-DRAFT.json').write_text(json.dumps({
        'nodes':proof.nodes,'global_nodes':proof.global_nodes,'binding':binding},indent=2,sort_keys=True)+'\n')
    print(json.dumps({'nodes':len(proof.nodes),'globals':list(proof.global_nodes),
                      'new_engines':0,'source_application_review_pending':True}))

# Actual E/J scalar exponent gate — independent native result review

Accepted: both exact reviewed native obligations passed their first attempts with clean UNSAT, successful native exit/wait status, recorded normal pressure, bounded RSS/footprint and reaped owned groups. This accepts only the conditional source base/preservation leaves. The original finite-prefix E invariant and E-to-original-R0 application are not yet proved by this packet.

| Binding | SHA-256 |
| --- | --- |
| `FROZEN-INPUTS.json` | `af6c20d25d38d0a65cc1e6ba166415f60eddf6a8889eff6f819ab27e02dd9742` |
| `REVIEW-ACCEPTED.json` | `5222c96fcb02180adf1ca5cbc20b1a96ce99bbead526d914f8e11f6c977984b3` |
| `INPUT-REVIEW.md` | `78e884b5dd8c464dcd398d3673f5d52acff69819f8d9d97dc42f21682435b649` |
| `RUN-INTENT.json` | `2f7574c3bbbba41e893232d8e17ccec2a7f3d96e9b5d59b47e3136c223d872af` |
| `RESULTS.json` | `796e9d150612fc8f3249218294b1d6c91cc25ed2c1b9a2627b4804ebd58f569f` |

| First attempt | Query SHA-256 | Raw log SHA-256 | Wall seconds |
| --- | --- | --- | ---: |
| reset base | `e28605ba8cf9b61fb8276d3d049adbf93931cda32d1c6b94531ba31694f52295` | `886db6d84f598f08b840178c1932f45bd09e19134f9d3e15fb4a9ede74e7c773` | 0.4201149940 |
| preservation | `bd429772ebfdbdadba4c643d1de2b4f239d21d87da4167c03254ac183f4df0da` | `ba2922f45299e2ea1009fbcffbea3e56cd383c91cfd8d8ba529fefe1be4b30c6` | 0.7120649815 |

All twelve frozen local files and 42 absolute external pins still match their reviewed regular-file bytes, without symlinks. The accepted-review record binds this exact freeze, input review, scope and two-job budget. The intent binds the reviewed query plan/order, actual pinned Z3 tool, one worker, 4-GiB RSS/physical-footprint limit, internal `-memory:4096`, zero new probes/simulations and no time/CPU kill. The actual binary remains `ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`. Source/query preparation, complete c070 prefix, all 452 T conjuncts, qualified original control typing/seal, and actual compiled-source manifest/SV/script pins are unchanged from the input review.

Independent raw parsing finds exactly `unsat` and one statistics list per log, with unique keys and finite nonnegative values. The simplified base has five statistics and no `:num-checks`; preservation has 26 statistics and `:num-checks 1`. Both actual query files contain exactly one check command. There is no extra answer/model/error or parse failure. Individual `CHECKED-RESULT.json` files equal the aggregate rows, including query/binary/raw-log hashes, FINISHED receipts and canonical monitor records.

The run inventory is exact: two named run folders and two corresponding journals, each folder containing only STARTED, FINISHED, MONITOR-BINDING, NATIVE.log and CHECKED-RESULT. Argv and cwd match the reviewed gate and actual query paths; environment changes are empty. The base starts at `12:40:35.584074Z` and finishes at `12:40:36.004194Z`; preservation starts afterward at `12:40:36.054547Z` and finishes at `12:40:36.766618Z`. These are sequential first attempts, with no retry, diagnostic, overlapping worker or active owned job reported.

I independently parsed all admission, pressure and owned-group journal rows, checked chronological order and journal/monitor hashes, recomputed receipt peaks, and verified each PID/PGID and stable start identity. Base PID/PGID 83955 has eight group observations and nine pressure samples; preservation PID/PGID 83960 has thirteen group observations and fourteen pressure samples. Every pressure value is the actual observed normal value 1. Every nonempty group contains only the owned leader; both final groups are empty with zero group RSS/footprint. Group observation counts equal receipt observation counts plus the final sample. Observed PID inventories and canonical identity maps agree with receipts/monitors.

| Resource bytes | Base | Preservation |
| --- | ---: | ---: |
| maximum sampled RSS | 39,567,360 | 256,901,120 |
| maximum sampled physical footprint | 36,635,080 | 252,379,736 |
| wait4 maximum RSS | 41,271,296 | 257,081,344 |

All are positive and below 4,294,967,296 bytes. Native exits and raw wait statuses are 0; monitor errors are empty and resource-stop reasons are null. Kernel/stage/maximum elapsed and CPU caps are absent, disk floor is zero, and monitor records bind the unchanged accepted guard source `5e5d67b1dafa0917a051599d963a4efb77e5f4b7489e193f1b0ff22e8545213c`. No canonical simulation reservation is claimed. The journals bind `a80affe63ad33c7761af39a4a66475a553078c1c8ee18c333b3089b38740fa2a` and `c227a8bec85b73e059b9468a0a9f424c0d545c1c84bbc5f5b83fdbf9664ca4b9` respectively. Successful wait4 receipts and final empty owned-group evidence support reaping, without any present-day process control.

The accepted formula scope remains exactly one scalar invariant: J actual reset-high/no-CLEAR/no-integrated-failure and E active phase META/WEIGHTS/DRAIN/EMIT/DONE imply equality of actual E/J activation-exponent getters. The base uses H/current root reset-low. Preservation uses both H, full T, current complete `current-job-I(a,columns)`, the exact first eight generic phase-control conjuncts and current scalar IH; no successor provider, Q guard, root-arbiter health, new history, private correct exponent or successful future is assumed. Reset/CLEAR/control-error/start/descriptor priorities and actual successor getter masking remain the literal native source behavior.

Later qualification must import the original bounded control provider, derive the eight-clause projection by checked definition/conjunction steps, perform one ordinary finite-prefix scalar induction with actual bounds, and prove current E/head FRAME and original same-UID/certificate/R0 linkage. These are not supplied by source-leaf UNSAT alone. The already sealed 227-node D/J/R0 milestone remains qualified separately and unchanged. The gate correctly keeps `engine_exponent_original_prefix_or_R0_application_qualified` and whole-device flags false; read/model metadata/scale/selector admission remains open, including actual first-fault and cancellation authority boundaries.

This review used only read-only standard-library parsing, hashing, inventory and arithmetic checks. No preparer, runner, recorded-check writer, Proof initializer, engine, probe, compiler, simulation, additional agent or native rerun was invoked. The complete inspection tool result was retained. Existing producer pending-review fields remain first-run provenance; this additive file records native result acceptance.

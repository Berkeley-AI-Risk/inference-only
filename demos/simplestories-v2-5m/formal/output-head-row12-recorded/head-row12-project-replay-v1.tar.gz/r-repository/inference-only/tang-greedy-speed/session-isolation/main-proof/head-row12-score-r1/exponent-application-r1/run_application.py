"""Fixed read-only constructor/typing driver; no engines or old proof rebuilds."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
M = C.parent
P = M / 'head-mode-ownership-r1'
L = P / 'frame-join-pilot/certificate-trace-application-r2'
S = L / 'step-rms-origin-application-r1'
SCOPE = 'original-head-exponent-owner-saved-frame-ordinary-inductions'
AUDIT_SHA = '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33'
LOADER_SHA = '2bc78867ebf370b0cf6f32c6ddf7e15e1f129f49db1764a7b88acc7b1d9bb082'
INPUTS = {'run_application.py', 'owner_application.py', 'owner_prefix.py', 'PLAN.md', 'INPUT-REVIEW.md', 'RAW-INPUTS.json'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
FAILURE = None


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def typing_theory(groups):
    """Exact ordered de-duplication; one disclosed UF-to-definition realization."""
    forms, positions = [], {}
    for group in groups:
        for f in group:
            kind = f[0]
            if kind in ['define-fun', 'declare-fun', 'declare-const']:
                key = ('function', f[1])
            elif kind == 'declare-datatypes':
                key = ('datatype', tuple(t[0] for t in f[2]))
            elif kind == 'declare-sort':
                key = ('sort', f[1])
            else:
                raise AssertionError(('Unexpected theory command', kind))
            if key in positions:
                old = forms[positions[key]]
                if old == f:
                    continue
                assert f[1] == 'fj-capture-record-at' and old[0] == 'declare-fun' and kind == 'define-fun'
                assert old[2:] == [['Int'], 'FrameRmsCertificate']
                forms[positions[key]] = None
            positions[key] = len(forms)
            forms.append(f)
    return [f for f in forms if f is not None]


def construct(metadata_only=False):
    global FAILURE
    FAILURE = None
    proof, audit = None, None
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        assert type(metadata_only) is bool
        assert sys.version_info[:2] == (3, 12) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
        audit_path = L / 'check_nf_component.py'
        audit = load('_head_exp_readonly_audit', audit_path, AUDIT_SHA)
        audit.ACTIVE = True
        assert digest(audit_path.read_bytes()) == AUDIT_SHA
        envelope_path = HERE / 'ACCEPTED-INPUTS.json'
        envelope = json.loads(envelope_path.read_bytes())
        assert envelope['accepted'] is True and envelope['scope'] == SCOPE and set(envelope['files']) == INPUTS
        for name, value in envelope['files'].items():
            path = HERE / name
            assert path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == value
        manifest = json.loads((HERE / 'RAW-INPUTS.json').read_bytes())
        assert set(manifest) == {'paths_relative_to_main_proof', 'pins', 'helper_paths_relative_to_main_proof', 'helper_pins'}
        assert set(manifest['paths_relative_to_main_proof']) == set(manifest['pins'])
        assert set(manifest['helper_paths_relative_to_main_proof']) == set(manifest['helper_pins'])
        def raw_inputs(paths, pins):
            values = {}
            for name, relative in paths.items():
                path = (M / relative).resolve()
                assert path.is_relative_to(M) and not path.is_symlink()
                values[name] = path.read_bytes()
                assert digest(values[name]) == pins[name]
            return values
        raw = raw_inputs(manifest['paths_relative_to_main_proof'], manifest['pins'])
        def helper(name):
            return load('_head_exp_' + name, M / manifest['helper_paths_relative_to_main_proof'][name], manifest['helper_pins'][name])
        exports = load('_head_exp_exports', L / 'accepted_exports_r3.py', LOADER_SHA).load_parent_exports()
        import_module = helper('imports')
        import_paths = {
            'parent_seal': 'HEAD-COMPLETED-MODEL-DOT-R1-SEALED.json',
            'parent_source': 'head-completed-model-dot-r1/CONTINUITY-SOURCE-APPLICATION-DRAFT.json',
            'parent_prefix': 'head-completed-model-dot-r1/CONTINUITY-PREFIX-APPLICATION-DRAFT.json',
            'NF_seal': 'HEAD-NF-SOURCE-TRACE-R1-SEALED.json',
            'NF_application': str((L / 'NF-APPLICATION-R3.json').relative_to(M)),
            'NF_prefix': str((L / 'NF-PREFIX-APPLICATION.json').relative_to(M))}
        import_raw = raw_inputs(import_paths, import_module.PINS)
        import_prepared = import_module.prepare_imports(exports, import_raw)
        origin_module, cert_module, steps = helper('origins'), helper('certificate'), helper('steps')
        origin_manifest = json.loads((S / 'RAW-INPUTS.json').read_bytes())
        origin_raw = raw_inputs(origin_manifest['paths_relative_to_main_proof'], origin_manifest['pins'])
        origin_prepared = origin_module.prepare_metadata(exports, origin_raw, origin_manifest)
        cert_raw = raw_inputs(cert_module.RAW_PATHS, cert_module.PINS)
        cert_prepared = cert_module.prepare_metadata(exports, cert_raw)
        module = load('_head_exp_application', HERE / 'owner_application.py', envelope['files']['owner_application.py'])
        prefix_module = load('_head_exp_prefix', HERE / 'owner_prefix.py', envelope['files']['owner_prefix.py'])
        data = {name: json.loads(value) for name, value in raw.items() if name not in {'owner_review', 'frame_review', 'origin_review', 'certificate_review'}}
        data['raw_pins'] = manifest['pins']
        prepared = module.prepare_metadata(exports, data, origin_prepared, cert_prepared)
        api = exports['apis']
        constants = [f for f, _, _ in api['parse_spans'](origin_raw['endpoint_typing'])
            if f[0] == 'declare-const' and f[1] in {'model', 'unused-frame'}]
        assert {f[1] for f in constants} == {'model', 'unused-frame'}
        if metadata_only:
            audit.HELPERS.update({Path(__file__).resolve(), audit_path})
            assert audit.HELPERS <= set(audit.READS)
            for p, expected in list(audit.READS.items()):
                assert digest(p.read_bytes()) == expected
            return {'metadata_only_passed': True, 'proof_initializers_called': 0, 'nodes': 0, 'native_jobs': 0,
                'input_envelope_sha256': digest(envelope_path.read_bytes()),
                'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
                'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)}}, None
        proof = api['ValueProof'].__new__(api['ValueProof'])
        api['Proof'].__init__(proof, {})
        for name, old in proof.root_context.items():
            assert all(exports['context'][name][k] == v for k, v in old.items())
        proof.root_context = copy.deepcopy(exports['context'])
        language = api['SourceLanguage']()
        language.add(exports['helper_theory'])
        for f in constants:
            language.decls[f[1]] = copy.deepcopy(f)
        imported = import_module.install_current_globals(proof, language, exports, import_raw)
        application = module.construct(proof, language, exports, imported, prepared, steps)
        prefix = prefix_module.validate(application, exports, imported, prepared)
        declarations = [['declare-fun', 'NF', ['Int'], 'NormFrame'],
            ['declare-fun', 'NFEMPTY', ['Int'], module.ARRAY],
            ['declare-fun', 'HS', ['Int'], 'HeadExponentHistory'], ['declare-fun', 'CERT', ['Int'], 'FrameRmsCertificate']]
        theory = typing_theory([exports['helper_theory'], constants, exports['nf_provider']['helpers'],
            declarations[:2], application['helper_theory'], declarations[2:]])
        theory += [['declare-const', x, 'Int'] for x in [module.HS_INDEX, module.HF_INDEX, 'N']]
        theory += [['assert', node['formula']] for node in proof.nodes]
        theory += [['assert', f['bounded_formula']] for f in prefix['families'].values()]
        # Match the accepted earlier typing-only specimen. This text is fed
        # only to the pure typechecker; the driver has no solver capability.
        theory += [['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
        typing = ('\n'.join(map(api['smt'], theory)) + '\n').encode()
        path = P / 'source_typecheck.py'
        type_raw = path.read_bytes()
        assert digest(type_raw) == '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809'
        functions = [f for f in ast.parse(type_raw).body if isinstance(f, ast.FunctionDef) and f.name in ['sort', 'check']]
        namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), 'exec'), namespace)
        typed = namespace['check'](typing)
        assert typed['assertions'] == len(proof.nodes) + 2
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        for p, expected in list(audit.READS.items()):
            assert digest(p.read_bytes()) == expected
        return {'application': application, 'prefix': prefix, 'type_check': typed, 'typing_sha256': digest(typing),
            'input_envelope_sha256': digest(envelope_path.read_bytes()),
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'new_native_jobs': 0, 'old_parent_proof_reconstructions_called': 0,
            'independent_result_review_pending': True, 'saved_R0_or_row_application_proved': False,
            'selector_score_proved': False, 'whole_device_theorem': False}, typing
    except BaseException as error:
        FAILURE = {'error': repr(error), 'partial_nodes': copy.deepcopy(proof.nodes) if proof is not None else [],
            'active_indices': copy.deepcopy(proof.active_indices) if proof is not None else {},
            'scope_labels': sorted(proof.scope_labels) if proof is not None else [],
            'index_bindings': copy.deepcopy(proof.index_bindings) if proof is not None else {},
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())} if audit is not None else {},
            'executed_helper_pins': {str(k): audit.READS.get(k) for k in sorted(audit.HELPERS)} if audit is not None else {},
            'unread_executed_helper_paths': sorted(str(k) for k in audit.HELPERS - set(audit.READS)) if audit is not None else [],
            'new_native_jobs': 0, 'result_qualified': False}
        raise
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--metadata-only'])
    name = 'METADATA-R1' if sys.argv[1:] else 'APPLICATION-R1'
    assert not any((HERE / (name + suffix)).exists() for suffix in ['.json', '-STOPPED.json', '-TYPING-ONLY.smt2'])
    def save(suffix, raw):
        with (HERE / (name + suffix)).open('xb') as output:
            output.write(raw)
    try:
        result, typing = construct(bool(sys.argv[1:]))
    except BaseException:
        save('-STOPPED.json', (json.dumps(FAILURE, indent=2, sort_keys=True) + '\n').encode())
        raise
    save('.json', (json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    if typing is not None:
        save('-TYPING-ONLY.smt2', typing)
    print(json.dumps({'metadata_only': bool(sys.argv[1:]), 'new_nodes': len(result.get('application', {}).get('nodes', [])), 'new_native_jobs': 0}))

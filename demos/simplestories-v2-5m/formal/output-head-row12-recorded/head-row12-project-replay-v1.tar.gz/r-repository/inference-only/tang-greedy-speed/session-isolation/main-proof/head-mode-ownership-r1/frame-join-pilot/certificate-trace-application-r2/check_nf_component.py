"""Read-only replay of the reviewed NF induction and finite-prefix application."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast, copy, hashlib, json, os, symtable, sys, types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
SCOPE = 'original-NF-invariant-on-finite-source-prefix'
ACTIVE = False
HASHING = False
READS = {}
HELPERS = set()
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def audit(event, args):
    global HASHING
    if not ACTIVE:
        return
    path = None
    if event == 'open':
        mode, flags = args[1:3]
        assert not (isinstance(mode, str) and any(char in mode for char in 'wax+'))
        assert not (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if not HASHING and isinstance(args[0], (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(args[0])).resolve()
    if event == 'exec' and not args[0].co_filename.startswith('<'):
        path = Path(args[0].co_filename).resolve()
        if path.is_file():
            HELPERS.add(path)
    if path is not None and path.is_file():
        HASHING = True
        try:
            value = digest(path.read_bytes())
        finally:
            HASHING = False
        assert READS.setdefault(path, value) == value, ('Changed input', str(path))
    assert not event.startswith(('subprocess.', 'socket.', 'ctypes.'))
    assert event not in {'os.system', 'os.fork', 'os.forkpty', 'os.exec', 'os.spawn',
        'os.posix_spawn', 'os.kill', 'os.killpg', 'os.chdir', 'os.chroot', 'os.mkdir',
        'os.remove', 'os.rmdir', 'os.rename', 'os.link', 'os.symlink', 'os.truncate',
        'os.chmod', 'os.chown', 'os.utime', 'os.setxattr', 'os.removexattr', 'resource.setrlimit'}, event


sys.addaudithook(audit)


def check():
    global ACTIVE
    assert not ACTIVE and sys.version_info[:2] == (3, 12)
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    READS.clear(); HELPERS.clear()
    ACTIVE = True
    try:
        manifest_path = HERE / 'FROZEN-NF-COMPONENT.json'
        manifest = json.loads(manifest_path.read_bytes())
        assert manifest['accepted'] is True and manifest['scope'] == SCOPE
        assert all(Path(name).is_absolute() for name in manifest['files'])
        pins = {Path(name).resolve(): value for name, value in manifest['files'].items()}
        assert len(pins) == len(manifest['files'])
        required = ['check_nf_component.py', 'NF-COMPONENT-REPLAY-REVIEW.md',
            'run_nf_application_r3.py', 'accepted_exports_r3.py', 'nf_induction.py',
            'NF-APPLICATION-INPUTS-R3.json', 'NF-APPLICATION-R3.json', 'NF-APPLICATION-R3-TYPING-ONLY.smt2',
            'NF-APPLICATION-RESULT-REVIEW-R3.md', 'nf_prefix.py', 'NF-PREFIX-INPUTS.json',
            'NF-PREFIX-APPLICATION.json', 'NF-PREFIX-TYPING-ONLY.smt2',
            'NF-PREFIX-CODE-REVIEW-R2.md', 'NF-PREFIX-RESULT-REVIEW.md']
        assert all((HERE / name).resolve() in pins for name in required)
        for path, value in pins.items():
            assert digest(path.read_bytes()) == value, str(path)
        assert manifest['checker_sha256'] == pins[Path(__file__).resolve()]
        assert manifest['review_sha256'] == pins[HERE / 'NF-COMPONENT-REPLAY-REVIEW.md']
        driver_path = HERE / 'run_nf_application_r3.py'
        driver = types.ModuleType('_closed_NF_driver'); driver.__file__ = str(driver_path)
        exec(compile(driver_path.read_bytes(), str(driver_path), 'exec'), driver.__dict__)
        saved = json.loads((HERE / 'NF-APPLICATION-R3.json').read_bytes())
        fresh, typing = driver.construct()
        assert fresh == saved and typing == (HERE / 'NF-APPLICATION-R3-TYPING-ONLY.smt2').read_bytes()
        assert len(fresh['application']['nodes']) == 30
        assert fresh['application']['global_node'] == 29 and fresh['type_check']['assertions'] == 30
        for name, value in fresh['actual_read_pins'].items():
            assert pins[Path(name)] == value
        for name, value in fresh['executed_helper_pins'].items():
            assert pins[Path(name)] == value
        prefix_saved = json.loads((HERE / 'NF-PREFIX-APPLICATION.json').read_bytes())
        assert prefix_saved['accepted_NF_result_review_sha256'] == pins[HERE / 'NF-APPLICATION-RESULT-REVIEW-R3.md']
        assert prefix_saved['prefix_code_review_sha256'] == pins[HERE / 'NF-PREFIX-CODE-REVIEW-R2.md']
        assert prefix_saved['input_envelope_sha256'] == pins[HERE / 'NF-PREFIX-INPUTS.json']
        assert prefix_saved['new_native_jobs'] == 0
        assert all(prefix_saved[key] is False for key in ['historical_NF_CERT_or_ROW_application_proved', 'numerical_RMS_proved', 'whole_device_theorem'])
        driver.ACTIVE = True
        try:
            exports = driver.load('_closed_NF_exports', HERE / 'accepted_exports_r3.py', pins[HERE / 'accepted_exports_r3.py']).load_parent_exports()
            prefix_module = driver.load('_closed_NF_prefix', HERE / 'nf_prefix.py', pins[HERE / 'nf_prefix.py'])
            prefix = prefix_module.validate_nf_prefix(fresh, exports)
            assert prefix == prefix_saved['prefix']
            api = exports['apis']
            forms = [form for form, _, _ in api['parse_spans'](typing) if form[0] not in ['check-sat-using', 'exit']]
            forms += [['declare-const', 'N', 'Int'], ['assert', prefix['bounded_formula']]]
            forms += [['assert', form] for form in prefix['observer_definitions']]
            forms += [['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            prefix_typing = ('\n'.join(map(api['smt'], forms)) + '\n').encode()
            assert prefix_typing == (HERE / 'NF-PREFIX-TYPING-ONLY.smt2').read_bytes()
            type_path = driver.P / 'source_typecheck.py'
            raw = type_path.read_bytes(); assert digest(raw) == driver.TYPECHECK_SHA
            functions = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef) and node.name in ['sort', 'check']]
            namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
            exec(compile(ast.Module(body=functions, type_ignores=[]), str(type_path), 'exec'), namespace)
            assert namespace['check'](prefix_typing) == prefix_saved['type_check']
        finally:
            driver.ACTIVE = False
        for name, value in prefix_saved['actual_read_pins'].items():
            assert pins[Path(name)] == value
        for name, value in prefix_saved['executed_helper_pins'].items():
            assert pins[Path(name)] == value
        HELPERS.add(Path(__file__).resolve())
        assert set(READS) | HELPERS <= set(pins) | {manifest_path}
        for path, value in list(READS.items()):
            assert digest(path.read_bytes()) == value
        return {'passed': True, 'scope': SCOPE, 'manifest_sha256': digest(manifest_path.read_bytes()),
            'NF_nodes_reconstructed': 30, 'NF_and_prefix_typing_byte_identical': True,
            'finite_prefix_state_conclusion_at_N_checked': True, 'all_reads_and_helpers_pinned': True,
            'actual_read_pins': {str(path): value for path, value in sorted(READS.items())},
            'executed_helper_pins': {str(path): READS[path] for path in sorted(HELPERS)},
            'new_native_jobs': 0, 'old_parent_proof_reconstructions_called': 0, 'writes': 0,
            'historical_NF_CERT_or_ROW_application_proved': False, 'numerical_RMS_proved': False,
            'whole_device_theorem': False}
    finally:
        ACTIVE = False


if __name__ == '__main__':
    assert sys.argv[1:] == []
    print(json.dumps(check(), indent=2, sort_keys=True))

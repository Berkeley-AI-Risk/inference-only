# Independent current/historical saved-exponent input review

**Decision: GO for exact metadata-only validation first. If that passes with
zero Proof initializers/nodes, GO for one construction under the same exact
six-file accepted envelope.** Any metadata, deduction, typing or bound failure
must stop with its checkpoint; a fix requires reviewed additive inputs. This
static review executes no module/driver function and grants no result credit.

## Exact final inputs and dependencies

| Input | SHA256 |
| --- | --- |
| PLAN.md | `13f9644ad7f2fb80cab72ada80e59c459fda9730e35463106eb077a250d0671b` |
| saved_exponent.py | `da686c2382492ede7419cec0c5a4c162b97636eb3ae19e1d0fee25c036b8141e` |
| consequence_audit.py | `ae0bbc84778a8e5ee6d495bfbd0364f84d89d451908c9eb1203ffdea924707e0` |
| run_consequence.py | `39fc03f8526ced7467aa1468364cab20cbad74a47036297302692531a648dbe3` |
| RAW-INPUTS.json | `c03441c8164f534e103fbfac989d7b45d34ab65f08e71ae0c57b730d8bcac5ed` |

The local accepted envelope must bind these five files and this review,
exactly six entries. All twelve raw and four helper pins match actual files.
The original S raw manifest and composition supplement are pinned, so their
additional raw dependencies/typing are not newly selected. The accepted
96-node owner/link application `32682edf...`, typing `56f35ce0...`, review
`814a8503...`, original283-node STEP/RMS/row application `713111bf...`, its
review `3d5c3c32...`, and frame-leaf review `b4f99e2c...` retain exact pins.
The original STEP/row seal binds the old row result and review.

I statically parsed all new code, inspected the actual pinned helpers/API and
rehashed every manifest dependency. No new driver/metadata function, Proof
initializer, old constructor/writer/compiler, engine or agent was invoked.
No frozen or sealed parent changed.

## Fixed API reuse and metadata boundary

The normal subclass overrides initialization and implements its own parents,
current and row paths. It does not invoke the old FixedApplication initializer,
capture/row/composition constructor or old driver construction. The reused
methods are only the reviewed literal definition/projection/alias, exact
bounded forall application, strict-bound weakening, source-H and OR-introduction
helpers; I checked their actual signatures and bodies. The old driver's
`merge_theory` is used only as its pure exact-definition merge.

The driver uses the genuine accepted cheap export loader and read-only
auditor. It verifies the six-file envelope, twelve raw pins, four helper pins,
original S raw manifest/supplement, original seals and accepted result reviews
before initialization. The actual dot typing is checked against the seal's
`11ff55d9...` member through the original supplement. Owner typing matches its
accepted application. Overlapping merged helpers/types/constants must be
literal matches. The metadata-only branch returns before ValueProof allocation
or Proof initialization and reports actual read/helper pins.

The constructor uses the existing lightweight Proof/ValueProof and the exact
bounded six-root context `41af6255...`, after checking compatibility with the
original source context. No source premise or operator interpretation is
changed. The raw-frame source remains c070; the read-leaf packet and any new
read/model/UID/scale claim are not imported here.

## Current completed-FRAME consequence

The current proof imports literal bounded HS/HF and original FRAME/control
theorems, the unchanged endpoint theorem and unchanged original row theorem.
Their complete domains and supports are retained. Owner/HF imports explicitly
require `1<=N`; no bound antecedent is deleted.

At current i it opens only the natural current index, with the original
completed-FRAME case `1<=N`, `i<=N`, live/head/active/complete. I independently
matched that exact case against the accepted endpoint formula and verified
its first scalar projection is CERT validity. The endpoint's original saved
record, capture-index bounds/identity and UID/parent/prefix facts remain in
the scalar conclusion.

Native H is obtained from the exact bounded state clause with both actual
range parents. Original FRAME-I and bounded HS/HF are specialized at the
same i. The native saved-exponent leaf receives H, FRAME-I, hs-I, hf-I and
the exact live/head/active/CERT-valid guard in its original order. Its whole
accepted combined formula is instantiated before selecting the saved-exponent
implication. Both state variables map to A(i), with current histories; no edge,
state i+1 or successful successor is requested.

The resulting D/J physical exponent equalities are rewritten through the
literal `endpoint-saved-NF(i)=CERT(i).nf` helper. This identifies the original
saved record, not later current NF. The current export conjoins that equality
pair, original endpoint scalars and the specialized HS origin predicate.
It does not claim a later engine/postscale/selector has consumed this value.

## Historical original-row application

The row guard is extracted from the actual accepted old global formula.
I independently matched its case and historical first four fields: original
`1<=j`, `j<n`, actual row capture and completed FRAME, with
`j=FRAMEORIGIN(n)`. A word0 instance supplies these scalar facts before any
new word parameter is declared. The accepted c7 integer rule derives `j<=N`
from the actual strict-past and current-upper parents.

Only then does the proof use H(A(j)), bounded state control and bounded
FRAME-I. It repeats the already checked small guard derivation: accepted
capture-guard schema plus actual source H/control/capture yields native
live/engine/head; the literal control phase gives GROUP_RUN; actual disjuncts
and FRAME's state identity yield active FRAME. Concrete FrameJoinView selector
equations provide the live/head aliases. The original complete-frame fact
supplies completion.

The new current theorem is specialized at that exact j with both derived
bounds and applied to the reconstructed guard. Its first consequence is the
physical D/J exponent at A(j) equal to original R0(j).exp. No historical
INDEX, edge at j, N+1 state, old edge-only origin family or future-health
condition is introduced.

After the scalar exponent is established, one fresh BV8 word parameter is
declared and the original row theorem is instantiated again. The final result
conjoins its unchanged word/dot/origin conclusion with the historical exponent
pair. Original signed arithmetic, literal `D(S,M,256)`, all-word S/R0 identity,
UID/episode/order and cancellation authority are retained by exact theorem
application; no array lift or new rescaling formula is asserted.

## Audit, stop rule and qualification limits

The consequence auditor checks every supported deduction kind, parent order,
support union/discharge, literal imported formulas/bounded context, exact
forall bodies and source-schema substitutions, function/selector equations,
actual bounded source clause and integer/OR rules. The generic record UF is
explicitly interpreted by the original actual capture-record definition from
the merged accepted theory. It is not selected for a desired saved value.

The historical ledger checks literal lower/strict/upper j formulas, the actual
current-theorem conclusion at j and exact reconstructed frame guard. The
auditor rejects unknown rule kinds and verifies fresh word choice occurs
after all scalar derivation. The actual result review must still inspect the
full produced DAG and bound-parent ancestry, with no inference merely from
typing or descriptive flags.

Metadata-only must pass first with zero initializers/nodes. The subsequent
single construction is capped at256 nodes, with no new induction or native
job. Typing text has the accepted parser-only check marker; no solver runs.
All actual read/helper pins must be covered. Success requires independent
formula/support/locality and whole-output byte-identical replay review.

Failure preserves partial nodes, active indices, scope labels, index bindings,
read/helper pins and unread-helper paths before stopping. Output files cannot
be overwritten. No time/CPU/token kill, engine, old proof rebuild, compiler,
simulation, Lean, board or public action is authorized by this input review.

Qualification, if the result passes review, will establish this original
current/historical saved exponent component. Registered read selection through
the original completed dot, actual fixed-image metadata, postscale/held score,
legal restored-selector admission, upstream RMS/decoder meaning, other rows
and whole-device conclusions remain separate work.

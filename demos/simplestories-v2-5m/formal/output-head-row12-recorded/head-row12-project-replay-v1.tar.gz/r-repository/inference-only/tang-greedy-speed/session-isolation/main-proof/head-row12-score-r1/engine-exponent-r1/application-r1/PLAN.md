# Original-prefix E/J scalar exponent induction

Unrun preparation. The two exact native leaves passed first-attempt UNSAT and
independent review834c7fa1. Apply them with the existing qualified original
control theorem, its current-job-I and the checked first8 phase-control
conjuncts. No new observer, numerical input, successor provider or source health
assumption is needed. The single ordinary invariant is eexp-I(A(n)).

Use actual reset sample1 for base and both H/full452 T only on defined n<N
edges. Instantiate the original qualified control at n, then project part7
current-job-I and part8 selected-row-phase-I, unfold its literal definition,
project first8 and fold the exact eexp-source-parent-control helper. Preserve
all original root supports and source macro/instance/getter definitions.

Budget64 deduction nodes, zero engines/builds/writes in the constructor.
Independently review exact code/driver/raw pins and source/provider projection
before Proof initialization. Metadata-only first; one frozen construction,
explicit finite-prefix locality/support/schema audit and typing; independent
byte-identical replay review. Stop/save full partial DAG/scopes/read/helper
pins on any unexpected assertion. Revised work needs additive reviewed files.

This gives only the original bounded E/J exponent invariant. Apply the closed
current-FRAME R0 theorem next with actual complete active head FRAME/UID/control
premises; do not infer that numerical/row/certificate connection from an equality
of current registers alone. Read/dot/metadata/postscale/selector remain active.

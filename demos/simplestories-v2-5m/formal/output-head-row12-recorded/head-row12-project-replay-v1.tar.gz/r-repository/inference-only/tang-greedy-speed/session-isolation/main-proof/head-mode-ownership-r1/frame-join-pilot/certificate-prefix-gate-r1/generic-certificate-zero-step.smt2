; Generic first-write certificate: zero, BV embedding and one step
; PREPARATION ONLY: no engine result exists.
(declare-datatypes
  ()
  ((NormFrame
      (mkNormFrame
        (nf-t Int)
        (nf-sv Bool)
        (nf-sid Int)
        (nf-active Bool)
        (nf-uid Int)
        (nf-sparent Int)
        (nf-prefix (_ BitVec 12))
        (nf-count (_ BitVec 9))
        (nf-exp (_ BitVec 8))
        (nf-data (Array (_ BitVec 8) (_ BitVec 16)))))))

(define-fun nf-zero ((empty (Array (_ BitVec 8) (_ BitVec 16)))) NormFrame
  (mkNormFrame 0 false 0 false 0 0 (_ bv0 12) (_ bv0 9) (_ bv0 8) empty))

(declare-datatypes
  ()
  ((FrameHistory
      (mkFrame
        (f-uid Int)
        (f-active Bool)
        (f-n (_ BitVec 10))
        (f-cols (_ BitVec 10))
        (f-complete Bool)
        (f-data (Array (_ BitVec 10) (_ BitVec 16)))))))

(define-fun frame-zero ((empty (Array (_ BitVec 10) (_ BitVec 16)))) FrameHistory
  (mkFrame 0 false (_ bv0 10) (_ bv0 10) false empty))

(declare-datatypes
  ()
  ((FrameJoinView
      (mkFrameJoinView
        (fv-drop Bool)
        (fv-begin Bool)
        (fv-write Bool)
        (fv-live Bool)
        (fv-head Bool)
        (fv-word (_ BitVec 16))
        (fv-new-uid Int)
        (fv-incoming-cols (_ BitVec 10))))))

(declare-datatypes
  ()
  ((FrameRmsCertificate (mkFRC (frc-valid Bool) (frc-juid Int) (frc-at Int) (frc-nf NormFrame)))))

(define-fun fj-frame-next ((view FrameJoinView) (frame FrameHistory) (empty (Array (_ BitVec 10) (_ BitVec 16)))) FrameHistory
  (ite
    (fv-drop view)
    (mkFrame (f-uid frame) false (_ bv0 10) (f-cols frame) false (f-data frame))
    (ite
      (fv-begin view)
      (mkFrame (fv-new-uid view) true (_ bv0 10) (fv-incoming-cols view) false empty)
      (mkFrame
        (f-uid frame)
        (f-active frame)
        (ite
          (fv-write view)
          (ite
            (= (f-n frame) (bvsub (f-cols frame) (_ bv1 10)))
            (_ bv0 10)
            (bvadd (f-n frame) (_ bv1 10)))
          (f-n frame))
        (f-cols frame)
        (or
          (f-complete frame)
          (and (fv-write view) (= (f-n frame) (bvsub (f-cols frame) (_ bv1 10)))))
        (ite (fv-write view) (store (f-data frame) (f-n frame) (fv-word view)) (f-data frame))))))

(define-fun fj-effective-head-write ((view FrameJoinView)) Bool
  (and (not (fv-drop view)) (not (fv-begin view)) (fv-live view) (fv-head view) (fv-write view)))

(define-fun fj-first ((view FrameJoinView) (frame FrameHistory)) Bool
  (and (fj-effective-head-write view) (not (f-complete frame)) (= (f-n frame) (_ bv0 10))))

(define-fun frc-zero ((empty-nf (Array (_ BitVec 8) (_ BitVec 16)))) FrameRmsCertificate
  (mkFRC false 0 0 (nf-zero empty-nf)))

(define-fun frc-next ((view FrameJoinView) (frame FrameHistory) (nf NormFrame) (certificate FrameRmsCertificate) (observation Int)) FrameRmsCertificate
  (ite
    (or (fv-drop view) (fv-begin view))
    (mkFRC false (frc-juid certificate) (frc-at certificate) (frc-nf certificate))
    (ite (fj-first view frame) (mkFRC true (f-uid frame) observation nf) certificate)))

(define-fun fj-accepted-nf ((nf NormFrame)) Bool
  (and (nf-active nf) (nf-sv nf) (= (nf-count nf) (_ bv256 9)) (= (nf-sparent nf) (nf-sid nf))))

(define-fun fj-protected-equal ((left NormFrame) (right NormFrame)) Bool
  (and
    (= (nf-data left) (nf-data right))
    (= (nf-exp left) (nf-exp right))
    (= (nf-uid left) (nf-uid right))
    (= (nf-sparent left) (nf-sparent right))
    (= (nf-sid left) (nf-sid right))
    (= (nf-prefix left) (nf-prefix right))))

(declare-fun fj-capture-record-at (Int) FrameRmsCertificate)

(define-fun fj-current-record ((view FrameJoinView) (frame FrameHistory) (nf NormFrame) (observation Int)) FrameRmsCertificate
  (mkFRC (fj-first view frame) (f-uid frame) observation nf))

(define-fun frc-I ((view FrameJoinView) (frame FrameHistory) (nf NormFrame) (certificate FrameRmsCertificate) (observation Int) (watch (_ BitVec 8))) Bool
  (and
    (=>
      (frc-valid certificate)
      (and
        (f-active frame)
        (= (frc-juid certificate) (f-uid frame))
        (and
          (<= 1 (frc-at certificate))
          (< (frc-at certificate) observation)
          (= certificate (fj-capture-record-at (frc-at certificate)))
          (fj-accepted-nf (frc-nf certificate)))
        (= (f-cols frame) (_ bv256 10))
        (or
          (f-complete frame)
          (and (bvult (_ bv0 10) (f-n frame)) (bvult (f-n frame) (_ bv256 10))))))
    (=> (and (frc-valid certificate) (fv-live view)) (fv-head view))
    (=>
      (and (frc-valid certificate) (not (f-complete frame)))
      (fj-protected-equal nf (frc-nf certificate)))
    (=>
      (and
        (frc-valid certificate)
        (or (f-complete frame) (bvult ((_ zero_extend 2) watch) (f-n frame))))
      (=
        (select (f-data frame) ((_ zero_extend 2) watch))
        (select (nf-data (frc-nf certificate)) watch)))
    (=>
      (and
        (fv-live view)
        (f-active frame)
        (fv-head view)
        (or (f-complete frame) (not (= (f-n frame) (_ bv0 10)))))
      (frc-valid certificate))))

(declare-const view FrameJoinView)

(declare-const next-view FrameJoinView)

(declare-const frame FrameHistory)

(declare-const nf NormFrame)

(declare-const next-nf NormFrame)

(declare-const certificate FrameRmsCertificate)

(declare-const observation Int)

(declare-const watch (_ BitVec 8))

(declare-const position (_ BitVec 10))

(declare-const empty-frame (Array (_ BitVec 10) (_ BitVec 16)))

(declare-const empty-nf (Array (_ BitVec 8) (_ BitVec 16)))

(assert
  (not
    (and
      (frc-I view (frame-zero empty-frame) nf (frc-zero empty-nf) 1 watch)
      (=> (bvult position (_ bv256 10)) (= ((_ zero_extend 2) ((_ extract 7 0) position)) position))
      (=>
        (and
          (<= 1 observation)
          (frc-I view frame nf certificate observation watch)
          (= (fj-capture-record-at observation) (fj-current-record view frame nf observation))
          (=> (not (fv-drop view)) (fv-live view))
          (=>
            (and (not (fv-drop view)) (not (fv-begin view)) (fv-live next-view))
            (= (fv-head next-view) (fv-head view)))
          (=>
            (fj-effective-head-write view)
            (and
              (f-active frame)
              (not (f-complete frame))
              (= (f-cols frame) (_ bv256 10))
              (bvult (f-n frame) (_ bv256 10))
              (fj-accepted-nf nf)
              (= (fv-word view) (select (nf-data nf) ((_ extract 7 0) (f-n frame))))))
          (=>
            (and
              (not (fv-drop view))
              (not (fv-begin view))
              (fv-live view)
              (fv-head view)
              (f-active frame)
              (not (f-complete frame)))
            (fj-protected-equal next-nf nf))
          (=>
            (and
              (not (fv-drop view))
              (not (fv-begin view))
              (fv-live view)
              (f-active frame)
              (f-complete frame))
            (not (fv-write view))))
        (frc-I
          next-view
          (fj-frame-next view frame empty-frame)
          next-nf
          (frc-next view frame nf certificate observation)
          (+ observation 1)
          watch)))))

(check-sat-using (then simplify propagate-values solve-eqs simplify smt))

(exit)

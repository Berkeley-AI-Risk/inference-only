# Independent result review: four native exponent leaves

**Decision: ACCEPTED. All four exact conditional source leaves returned clean
UNSAT on their first recorded attempts.** This accepts those formulas and
their recorded native execution. It does not yet qualify the reset-founded
head-start owner, historical NF(k)/saved-R0 relation, read/metadata/postscale or
actual greedy-selector score admission.

The exact reviewed freeze is
`6a0e035056c337ec8271958d45289965cb502581617c51a3048b9a3c0e230cd7`,
with acceptance record
`facb4793b8f82072e8343a078acc329ef7a4ef24923349a342d04b04626a1432`
and independent input review
`19edc5603486e134042c9af974805457158abb958b1f845d54872af52268b79a`.
The complete `RESULTS.json` is
`1db40e7ba27f894f0f992e2104570d75bb7606cff86ae2eb44d8c3ee24d0200c`;
intent is `b364c32550b68ff39f4af326d809dcf9409d616b975a50c72bf93ccd6bef4d64`.
All 15 frozen local files, 36 external pins and 31 preparation reads still
match actual bytes. No existing input, receipt, result, producer flag or
sealed packet was modified by this review.

## Raw answer and execution binding

I independently inspected all four native logs, STARTED/FINISHED receipts,
monitor records, observation journals and per-run checked results. Each
recorded result exactly matches its raw receipt/monitor and its copy in the
aggregate. Query order and hashes match the frozen plan, the intent and actual
native argv; the working directory is the reviewed packet. The pinned binary
is `ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`,
launched with `-smt2 -st -memory:4096` and the corresponding absolute query.
Every raw log's byte count/hash matches its receipt and result.

| Job, in recorded order | Native wall seconds | Raw-log SHA256 |
| --- | ---: | --- |
| head-start-current-RMS-exponent | 0.398875 | `4f7db509911c7efc64cff1734206d7a1be3e2df8e4b84a66be86bd587731f1a9` |
| head-start-register-capture | 0.509577 | `4000bdd4684804c6d1695f989a9946023abf3a00c5b93fa5ee9e98005b57c097` |
| job7-admission-exponent-cone | 0.665857 | `9cbbce1e89324a7a3c683e2339b53d60c05660ce9000c391880bc29267294a8c` |
| head-and-job-exponent-hold | 0.672850 | `e2089c56c56fd1e2f61744ca3158bdd75c938ea2abd5dc44f3f2ce0339657f95` |

Each complete raw protocol is exactly UNSAT followed by one nonempty statistics
list: no errors, additional answers, observations or trailing commands. All
statistics have unique keys and finite nonnegative values. The first log has
five statistics and no `:num-checks` key; no such statistic is invented. Its
frozen query contains exactly one check. The other logs have seven, 23 and 23
statistics respectively, each including `:num-checks 1`. All four query bytes
remain the reviewed exact native prefix plus their pinned single-goal tails.

The runs inventory is exactly four expected single-use directories and four
corresponding journals; every directory contains exactly its STARTED,
FINISHED, MONITOR-BINDING, CHECKED-RESULT and raw log. Recorded native start
times follow the previous finish time. There is no retry, diagnostic or fifth
native job in this gate.

## Resource and reaping receipts

All native exit codes and raw wait statuses are zero, with no monitor errors
or resource-stop reason. Every STARTED record states one process, 4 GiB,
no environment changes, no wall/CPU limits and zero disk floor. Each admission
and every actual pressure observation is normal Darwin pressure1. Monitor
journal hashes match their actual files.

The four journals contain eight, ten, thirteen and thirteen owned-group
observations. Their counts agree with the monitor and the guard's loop-count
plus final survivor observation. Every observed group has only its own leader,
with one stable start identity; aggregates equal their member RSS/footprint
sums. I independently recomputed every recorded peak. Maximum sampled owned
RSS is 261,357,568 bytes, maximum sampled footprint is 257,114,760 bytes and
maximum wait4 RSS is 264,339,456 bytes. All are below 4 GiB. The complete native
wall total is 2.247159 seconds.

Each final owned-group observation is empty. The accepted guard's recorded
normal completion includes wait4 reaping before FINISHED; these clean
receipts and final empty observations support recorded cleanup. This review
performed no live process inspection or process controls and makes no new
host-wide memory guarantee. No new resource probe, simulation, build, engine
or repository function was invoked during the independent read-only review.

## Accepted formula scope and remaining join

The source and query pins preserve c070, all 452 T clauses and the actual
compiled-source profile. Their effective captures and holds retain the exact
source priorities reviewed before execution:

- Current D head capture plus H and the original NF invariant yields the
  live HEAD_START shell, accepted complete NF and actual shell/D-input
  exponent equalities.
- D's full-T capture result uses successor reset ? pre-edge NF exponent :0.
  A newly detected fault can override phase without undoing the historical
  exponent capture; no successor-health assumption removes that case.
- Effective J job7 descriptor capture includes every earlier fault, CLEAR and
  protocol priority and derives the actual D-head/layer7 input cone. Its
  next exponent uses the actual successor reset mask.
- D/J physical hold follows their different update rules, and J hold excludes
  all legal descriptor captures, including nonhead jobs. Retained payload
  through a fault/CLEAR case is not successful-use or publication authority.

These are universal conditional leaves, with an arbitrary NF record under its
literal invariant premise. A later typed proof must supply the independently
qualified actual NF at the same observation/domain, derive historical ranges,
and preserve the original owner/protected fields to the exact saved R0. No
whole NormFrame equality across advancing clocks follows. No new operating
witness, upstream RMS numerical meaning, actual row read/metadata/scale tuple,
restored-selector state projection, publication or whole-device claim follows
from these four answers.

Phase A has used four of its eight native jobs. No diagnostics or retries were
used. The recorded pending-review/false broader-qualification flags remain
unchanged as provenance; this additive review accepts only the four source
leaves and their execution evidence. The single-owner stage, subject to its
own input review, remains the next obligation.

"""Ordinary source inductions for one original HS and its saved FRAME record.

Preparation only. No I/O, initializer, proof constructor or engine at import.
The caller supplies byte-pinned accepted components and the reviewed API.
"""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json

HS_FAMILY = 'original-head-exponent-owner-and-origin'
HF_FAMILY = 'original-head-exponent-saved-FRAME-link'
HS_INDEX = 'n_original_head_exponent'
HF_INDEX = 'n_original_head_frame_link'
ORIGIN_FAMILY = 'original-STEP-event-origin'
CERT_FAMILY = 'original-current-frame-RMS-certificate'
ARRAY = ['Array', ['_', 'BitVec', '8'], ['_', 'BitVec', '16']]
FRAME_ARRAY = ['Array', ['_', 'BitVec', '10'], ['_', 'BitVec', '16']]
FUNCTION_MAP = {'hs-event-at': 'actual-hs-event-at', 'hs-record-at': 'NF',
                'hs-origin-I': 'actual-hs-origin-I'}
canon = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':')).encode()
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def prepare_metadata(exports, data, origin_prepared, cert_prepared):
    api = exports['apis']
    hs, hf = data['owner_binding'], data['frame_binding']
    assert hs['native_sha256'] == hf['native_sha256'] == 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
    assert hs['native_T_conjuncts'] == hf['native_T_conjuncts'] == 452
    assert hs['NF_helpers'] == exports['nf_provider']['helpers']
    for which in ['owner', 'frame']:
        plan, result = data[which + '_plan'], data[which + '_results']
        assert result['all_expected_results_matched'] and result['active_owned_native_job'] is None
        assert len(result['results']) == 3
        assert [r['name'] for r in result['results']] == plan['order']
        for row in result['results']:
            assert row['matched'] and row['answer'] == row['expected'] == 'unsat'
            assert row['query_sha256'] == plan['queries'][row['name']]['sha256']
    assert digest(canon(exports['context'])) == '615f9eb7893c1a73f1ec036a87d9b33ff308aeec93827e38ae384fe7e6494dbc'
    origin = data['origin_application']['application']
    cert = data['certificate_application']['application']
    assert origin['root_context'] == cert['root_context'] == exports['context']
    assert origin['families']['STEP']['global_node'] == 22 and len(origin['nodes']) == 46
    assert cert['global_node'] == 134 and len(cert['nodes']) == 135
    step = origin['nodes'][22]
    certificate = cert['nodes'][134]
    assert step['kind'] == certificate['kind'] == 'ordinary-induction'
    assert step['property_template'] == ['actual-STEP-origin-I', ['nf-step-origin-observer', ['NF', '@index']], '@index']
    assert certificate['property_template'] == ['frc-I', ['fj-source-view', ['A', '@index'], ['COLUMNS', '@index']],
        ['FRAME', '@index'], ['NF', '@index'], ['CERT', '@index'], '@index', 'frc-watch']
    assert step['support'] == ['Gamma:actual-composed-source']
    # Bind original component seals and independently accepted result reviews.
    origin_dir = 'frame-join-pilot/certificate-trace-application-r2/step-rms-origin-application-r1/'
    assert data['step_row_seal']['files'][origin_dir + 'ORIGIN-APPLICATION-R1.json'] == data['raw_pins']['origin_application']
    assert data['step_row_seal']['files'][origin_dir + 'ORIGIN-RESULT-REVIEW.md'] == data['raw_pins']['origin_review']
    cert_member = 'frame-join-pilot/certificate-trace-application-r2/CURRENT-FRAME-APPLICATION-R1.json'
    assert data['certificate_seal']['files'][cert_member] == data['raw_pins']['certificate_application']
    cert_dir = 'frame-join-pilot/certificate-trace-application-r2/'
    for key, file in [('certificate_prefix', 'CURRENT-FRAME-PREFIX-APPLICATION-R1.json'),
                      ('certificate_review', 'CURRENT-FRAME-RESULT-REVIEW-R1.md')]:
        assert data['certificate_seal']['files'][cert_dir + file] == data['raw_pins'][key]
    assert data['certificate_prefix']['prefix']['inherited_prefix_source_context'] == exports['prefix_artifact']['inherited_prefix_source_context']
    assert data['origin_application']['prefix']['bounded_source_context'] == exports['prefix_artifact']['inherited_prefix_source_context']
    for node, bounded in [(step, data['origin_application']['prefix']['families']['STEP']['bounded_formula']),
        (certificate, data['certificate_prefix']['prefix']['new_bounded_consequences'][CERT_FAMILY])]:
        variable = bounded[1][-1][0]
        assert bounded == ['forall', [*node['quantified_parameters'], [variable, 'Int']],
            ['=>', ['and', ['<=', '1', variable], ['<=', variable, 'N']],
                api['SUB'](node['property_template'], {'@index': variable})]]
    assert data['certificate_prefix']['prefix']['fixed_record_function_definition_before_watch'] == cert_prepared[3]
    assert data['certificate_prefix']['prefix']['prefix_bound_domain'] == ['<=', '1', 'N']
    assert data['origin_application']['prefix']['prefix_bound_domain'] == ['<=', '1', 'N']
    n = 'head-origin-observation'
    actual_event = ['define-fun', 'actual-hs-event-at', [[n, 'Int']], 'Bool',
        ['head-exponent-effective-capture', ['A', n]]]
    origin_def = api['SUB'](next(f for f in hs['owner_helpers'] if f[:2] == ['define-fun', 'hs-origin-I']), FUNCTION_MAP)
    assert origin_def[2] == [['h', 'HeadExponentHistory'], ['observation', 'Int']]
    return {'data': data, 'origin_prepared': origin_prepared, 'cert_prepared': cert_prepared,
        'actual_event': actual_event, 'actual_origin': origin_def,
        'imported_origin_node': step, 'imported_certificate_node': certificate}


def construct(proof, language, exports, imported, prepared, steps):
    api, data = exports['apis'], prepared['data']
    c, EQ, SUB = (api[k] for k in ['c', 'eq', 'SUB'])
    assert len(proof.nodes) == 4 and proof.root_context == exports['context']
    before = deepcopy(proof.root_context)
    hs, hf = data['owner_binding'], data['frame_binding']
    helper_theory = [*prepared['origin_prepared']['theory'], *prepared['cert_prepared'][2]]
    helper_theory += hs['source_event_definitions'] + hs['protected_helpers']
    for f in hs['owner_helpers']:
        if f[0] == 'declare-fun' or f[:2] == ['define-fun', 'hs-origin-I']:
            continue
        helper_theory.append(f)
    helper_theory += [prepared['actual_event'], prepared['actual_origin'], hf['head_frame_owner_invariant']]
    language.add(helper_theory)
    for name, args, result in [('HS', ['Int'], 'HeadExponentHistory'), ('CERT', ['Int'], 'FrameRmsCertificate')]:
        decl = ['declare-fun', name, args, result]
        assert name not in language.decls or language.decls[name] == decl
        language.decls[name] = decl
    # Import the exact already checked global components, retaining their full
    # formulas, supports, bounded counterparts and fixed observer recurrences.
    def import_global(family, node, bounded, component, review):
        out = proof.add('qualified-published-trace-context-application', deepcopy(node['formula']),
            support=deepcopy(node['support']), property_template=deepcopy(node['property_template']),
            quantified_parameters=deepcopy(node['quantified_parameters']),
            original_global_node_id=node['id'], original_checked_kind=node['kind'],
            accepted_bounded_formula=deepcopy(bounded), accepted_component_sha256=component,
            accepted_result_review_sha256=review, exact_original_source_context=deepcopy(before))
        proof.global_nodes[family] = out
        return out
    origin_bounded = data['origin_application']['prefix']['families']['STEP']['bounded_formula']
    origin_id = import_global(ORIGIN_FAMILY, prepared['imported_origin_node'], origin_bounded,
        data['raw_pins']['step_row_seal'], data['raw_pins']['origin_review'])
    cert_bounded = data['certificate_prefix']['prefix']['new_bounded_consequences'][CERT_FAMILY]
    cert_id = import_global(CERT_FAMILY, prepared['imported_certificate_node'], cert_bounded,
        data['raw_pins']['certificate_seal'], data['raw_pins']['certificate_review'])
    observer_nodes, schema_nodes, reports = [], [], {}
    anchors = deepcopy(imported['total_observer_definition_anchors'])
    cert_nodes = data['certificate_application']['application']['nodes']
    anchors['CERT'] = {}
    for label, number, at in [('zero', 36, '1'), ('step', 132, 'n_current_frame')]:
        original = cert_nodes[number]
        anchors['CERT'][label] = {'source_artifact_sha256': data['raw_pins']['certificate_application'],
            'accepted_component_seal_sha256': data['raw_pins']['certificate_seal'],
            'source_node_id': number, 'source_index': at, 'original_total_definition_node': deepcopy(original),
            'original_domain_parent': deepcopy(cert_nodes[original['parents'][0]]) if label == 'step' else None}
    part = lambda parent, position: steps.part(proof, parent, position)

    def observer(which, index, step=False):
        after = c('+', index, '1')
        if which == 'HS':
            body = c('hs-next', c('A', index), c('NF', index), c('HS', index)) if step else c('hs-zero', c('NF', '1'))
            definition = language.defs['hs-next' if step else 'hs-zero']
        elif which == 'NF':
            body = c('nf-next', c('A', index), c('NF', index), c('NFEMPTY', index)) if step else c('nf-zero', c('NFEMPTY', '0'))
            definition = language.defs['nf-next' if step else 'nf-zero']
        elif which == 'FRAME':
            body = c('frame-next', c('A', index), c('COLUMNS', index), c('FRAME', index), 'unused-frame') if step else c('frame-zero', 'unused-frame')
            definition = language.defs['frame-next' if step else 'frame-zero']
        else:
            assert which == 'CERT'
            body = c('frc-next', c('fj-source-view', c('A', index), c('COLUMNS', index)),
                c('FRAME', index), c('NF', index), c('CERT', index), index) if step else c('frc-zero', c('NFEMPTY', '0'))
            definition = language.defs['frc-next' if step else 'frc-zero']
        if not step:
            assert index == '1'
        anchor = None if which == 'HS' else anchors['frame' if which == 'FRAME' else which]['step' if step else 'zero']
        out = proof.add('total-same-trace-nondriving-component-observer-definition',
            EQ(c(which, after if step else '1'), body), proof.index_parents(index) if step else [],
            support=['Gamma:actual-composed-source', *(proof.index_support(index, True) if step else [])],
            registry=which, index=index, step=step, exact_source_definition=deepcopy(definition),
            accepted_total_definition_anchor=deepcopy(anchor),
            total_definition_uniform_index_mapping={anchor['source_index']: index} if anchor is not None and step else {})
        observer_nodes.append(out)
        return out

    def rewrite_next(node, equations, direction=False):
        for equation in equations:
            f = proof.nodes[equation]['formula']
            node = proof.rewrite(node, equation, f[1] if direction else f[2], f[2] if direction else f[1])
        return node

    def schema(which, name, index, base=False):
        d = hs if which == 'owner' else hf
        original = d['goals'][name]
        if which == 'owner':
            mapping = {'a': c('A', index), 'b': c('A', c('+', index, '1')) if not base else c('A', '1'),
                'nf': c('NF', index), 'history': c('HS', index), 'initial': c('NF', index),
                'watch': ['_', 'bv0', '8'], 'empty': c('NFEMPTY', index if not base else '0'),
                'observation': index, 'revoke': ['or', ['not', c('|core_workflow_control_n u_native.u_six_layers.u_datapath.rst_n|', c('A', index))],
                    c('|core_workflow_control_n u_native.u_six_layers.u_datapath.clear_i|', c('A', index))],
                'capture': c('head-exponent-effective-capture', c('A', index)), **FUNCTION_MAP}
        else:
            after = c('+', index, '1') if not base else '1'
            mapping = {'a': c('A', index), 'b': c('A', after), 'nf': c('NF', index),
                'history': c('HS', index), 'columns': c('COLUMNS', index), 'next-columns': c('COLUMNS', after),
                'job': c('c-base', c('CAPTURE', index)), 'next-job': c('c-base', c('CAPTURE', after)),
                'frame': c('FRAME', index), 'certificate': c('CERT', index),
                'watch-frame': ['_', 'bv0', '10'], 'watch': ['_', 'bv0', '8'],
                'empty-frame': 'unused-frame', 'empty-nf': c('NFEMPTY', index if not base else '0'),
                'observation': index, **FUNCTION_MAP}
        plan = data[which + '_plan']
        realization = prepared['cert_prepared'][3]
        out = proof.add('qualified-source-schema-uniform-instance', SUB(original, mapping),
            original_query_goal=deepcopy(original), uniform_mapping=mapping,
            original_query_sha256=plan['queries'][name]['sha256'],
            accepted_result_review_sha256=data['raw_pins'][which + '_review'],
            fixed_function_realizations={'hs-event-at': prepared['actual_event'], 'hs-record-at': ['declare-fun', 'NF', ['Int'], 'NormFrame'],
                'hs-origin-I': prepared['actual_origin'], 'fj-capture-record-at': realization})
        schema_nodes.append(out)
        return out

    def original_clock(index):
        node = proof.trace_instance(ORIGIN_FAMILY, index)
        instance = node
        args = [c('nf-step-origin-observer', c('NF', index)), index]
        eq = steps.definition(proof, language, api, 'actual-STEP-origin-I', args)
        predicate_equation = eq
        node = proof.rewrite(node, eq, proof.nodes[eq]['formula'][1], proof.nodes[eq]['formula'][2])
        eq = steps.definition(proof, language, api, 'nf-step-origin-observer', [c('NF', index)])
        observer_equation = eq
        node = proof.rewrite(node, eq, proof.nodes[eq]['formula'][1], proof.nodes[eq]['formula'][2])
        node = steps.normalize_selectors(proof, language, node)
        normalized = node
        clock = part(node, 1)
        assert proof.nodes[clock]['formula'] == EQ(c('nf-t', c('NF', index)), c('-', index, '1'))
        return clock, {'accepted_global_parent': origin_id, 'current_global_instance': instance,
            'predicate_equation': predicate_equation, 'observer_equation': observer_equation,
            'normalized_predicate': normalized, 'clock_projection': clock}

    # HS/control and strict-past origin are established in one joint induction.
    template = ['and', c('hs-I', c('A', '@index'), c('NF', '@index'), c('HS', '@index')),
        c('actual-hs-origin-I', c('HS', '@index'), '@index')]
    base_rule = schema('owner', 'head-owner-base', '1', True)
    base_sources = [proof.source(c('|core_workflow_control_h|', c('A', '1'))),
        proof.source(['not', c('|core_workflow_control_n reset_n|', c('A', '1'))])]
    base_control = proof.mp(base_rule, proof.conjunction(base_sources))
    base_origin = part(schema('owner', 'head-owner-origin', '1', True), 1)
    zero_hs = observer('HS', '1')
    base = rewrite_next(proof.conjunction([base_control, base_origin]), [zero_hs])
    lower = proof.open_index(HS_FAMILY, HS_INDEX)
    ih = proof.add('scoped-induction-hypothesis', SUB(template, {'@index': HS_INDEX}),
        [lower], support=['IH:' + HS_FAMILY], scope=HS_INDEX)
    after = c('+', HS_INDEX, '1')
    nf_eq = observer('NF', HS_INDEX, True)
    hs_eq = observer('HS', HS_INDEX, True)
    nf_a = proof.trace_instance('original-NF-provider', HS_INDEX, {'nf-watch': ['_', 'bv0', '8']})
    nf_b = proof.trace_instance('original-NF-provider', after, {'nf-watch': ['_', 'bv0', '8']})
    nf_b = rewrite_next(nf_b, [nf_eq], True)
    rule = schema('owner', 'head-owner-preserve', HS_INDEX)
    source = [proof.source(c('|core_workflow_control_h|', c('A', HS_INDEX))),
        proof.source(c('|core_workflow_control_h|', c('A', after))),
        proof.source(c('|core_workflow_control_t|', c('A', HS_INDEX), c('A', after))),
        nf_a, nf_b, part(ih, 1)]
    control = proof.mp(rule, proof.conjunction(source))
    control = rewrite_next(control, [nf_eq, hs_eq])
    origin_rule = part(schema('owner', 'head-owner-origin', HS_INDEX), 2)
    event_eq = steps.definition(proof, language, api, 'actual-hs-event-at', [HS_INDEX])
    reflexive = proof.add('typed-equality-reflexivity', EQ(c('NF', HS_INDEX), c('NF', HS_INDEX)))
    origin_premise = proof.conjunction([lower, part(ih, 2), event_eq, reflexive])
    origin = proof.mp(origin_rule, origin_premise)
    applied_generic_origin = origin
    bridge_rule = part(schema('frame', 'owner-clock-and-saved-exponent', HS_INDEX), 1)
    clock_parent, clock_chain = original_clock(HS_INDEX)
    clock_application = proof.mp(bridge_rule, clock_parent)
    bridge = part(clock_application, 2)
    bridge_eq = proof.nodes[bridge]['formula']
    origin = proof.rewrite(origin, bridge, bridge_eq[2], bridge_eq[1])
    origin = rewrite_next(origin, [hs_eq])
    step = proof.conjunction([control, origin])
    hs_global = api['close_factory'](proof)(HS_FAMILY, template, base, step, HS_INDEX, ih, [])
    reports[HS_FAMILY] = {'global_node': hs_global, 'base_parent': base, 'step_parent': step,
        'base_HS_recurrence': zero_hs, 'step_HS_recurrence': hs_eq, 'step_NF_recurrence': nf_eq,
        'generic_origin_step': origin_rule, 'actual_event_definition': event_eq,
        'generic_origin_premise': origin_premise, 'applied_generic_origin': applied_generic_origin,
        'NF_record_reflexivity': reflexive, 'source_clock_specialization': bridge,
        'source_clock_parent': clock_parent, 'source_clock_application': clock_application,
        'source_clock_chain': clock_chain, 'IH_parent': ih}
    # One relation induction on the existing FRAME/CERT/HS histories.
    template = c('hf-I', c('A', '@index'), c('FRAME', '@index'), c('CERT', '@index'), c('HS', '@index'))
    rule = schema('frame', 'frame-head-owner-base', '1', True)
    base = proof.mp(rule, proof.conjunction([proof.source(c('|core_workflow_control_h|', c('A', '1'))),
        proof.source(['not', c('|core_workflow_control_n reset_n|', c('A', '1'))])]))
    base = rewrite_next(base, [observer('FRAME', '1'), observer('CERT', '1')])
    lower = proof.open_index(HF_FAMILY, HF_INDEX)
    ih = proof.add('scoped-induction-hypothesis', SUB(template, {'@index': HF_INDEX}),
        [lower], support=['IH:' + HF_FAMILY], scope=HF_INDEX)
    after = c('+', HF_INDEX, '1')
    nf_eq, hs_eq, frame_eq, cert_eq = [observer(k, HF_INDEX, True) for k in ['NF', 'HS', 'FRAME', 'CERT']]
    hs_a = part(proof.trace_instance(HS_FAMILY, HF_INDEX), 1)
    hs_b = rewrite_next(part(proof.trace_instance(HS_FAMILY, after), 1), [nf_eq, hs_eq], True)
    frame_a = proof.trace_instance('actual-frame', HF_INDEX, {'frame-watch': ['_', 'bv0', '10']})
    frame_b = rewrite_next(proof.trace_instance('actual-frame', after, {'frame-watch': ['_', 'bv0', '10']}), [frame_eq], True)
    cert_a = proof.trace_instance(CERT_FAMILY, HF_INDEX, {'frc-watch': ['_', 'bv0', '8']})
    rule = schema('frame', 'frame-head-owner-preserve', HF_INDEX)
    premise = proof.conjunction([proof.source(c('|core_workflow_control_h|', c('A', HF_INDEX))),
        proof.source(c('|core_workflow_control_h|', c('A', after))),
        proof.source(c('|core_workflow_control_t|', c('A', HF_INDEX), c('A', after))),
        frame_a, frame_b, hs_a, hs_b, cert_a, ih])
    step = rewrite_next(proof.mp(rule, premise), [frame_eq, cert_eq, hs_eq])
    hf_global = api['close_factory'](proof)(HF_FAMILY, template, base, step, HF_INDEX, ih, [])
    reports[HF_FAMILY] = {'global_node': hf_global, 'base_parent': base, 'step_parent': step, 'IH_parent': ih}
    assert not proof.active_indices and proof.root_context == before and len(proof.nodes) <= 192
    return deepcopy({'kind': 'original-head-exponent-and-saved-FRAME-ordinary-inductions',
        'nodes': proof.nodes, 'global_nodes': proof.global_nodes, 'families': reports, 'root_context': before,
        'helper_theory': helper_theory, 'HS_fixed_initial_recurrence': ['=', ['HS', '1'], ['hs-zero', ['NF', '1']]],
        'observer_nodes': observer_nodes, 'schema_nodes': schema_nodes,
        'accepted_total_definition_anchors': anchors,
        'accepted_import_ids': {'origin': origin_id, 'certificate': cert_id},
        'actual_event_definition': prepared['actual_event'], 'actual_origin_definition': prepared['actual_origin'],
        'native_jobs': 0, 'bounded_prefix_qualified': False, 'saved_R0_or_row_application_proved': False,
        'selector_score_proved': False, 'whole_device_theorem': False})

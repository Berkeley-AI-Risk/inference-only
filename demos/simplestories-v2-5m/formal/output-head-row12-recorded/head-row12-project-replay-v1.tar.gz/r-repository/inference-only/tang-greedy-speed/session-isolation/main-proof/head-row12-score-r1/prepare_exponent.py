"""Prepare four exact native exponent leaves. Import/assembly launches no engine."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
from contextlib import contextmanager
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
P = ROOT / 'head-mode-ownership-r1'
NATIVE_SHA = 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
S = '|core_workflow_control_s|'
SHELL = 'u_native.u_token_shell.'
D = 'u_native.u_six_layers.u_datapath.'
J = D + 'u_projection.'
ORDER = ['head-start-current-RMS-exponent', 'head-start-register-capture',
         'job7-admission-exponent-cone', 'head-and-job-exponent-hold']
READS = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
c = lambda name, *args: [name, *args]
AND = lambda *args: c('and', *args)
OR = lambda *args: c('or', *args)
EQ = lambda x, y: c('=', x, y)
NOT = lambda x: c('not', x)
IMP = lambda x, y: c('=>', x, y)
BV = lambda n, w: ['_', 'bv' + str(n), str(w)]
B = lambda w: ['_', 'BitVec', str(w)]
n = lambda path, state='a': c('|core_workflow_control_n ' + path + '|', state)


def read(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    assert READS.setdefault(str(path), digest(raw)) == digest(raw)
    return raw


@contextmanager
def checked_helpers():
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        modules = []
        for name, expected in [
            ('support', '898af07523f801c69d9806fe878cc5863552edb78e288e616778de1de729d130'),
            ('source_typecheck', '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809')]:
            path = P / (name + '.py')
            raw = read(path)
            assert digest(raw) == expected
            module = types.ModuleType(name)
            module.__file__ = str(path)
            sys.modules[name] = module
            exec(compile(raw, str(path), 'exec'), module.__dict__)
            modules.append(module)
        yield modules
    finally:
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


def assemble():
    READS.clear()
    with checked_helpers() as (parser, typing):
        raw = read(ROOT / 'rmsnorm-pilot/model-consumption/connected/native.smt2')
        assert digest(raw) == NATIVE_SHA
        native = [f for f, _, _ in parser.parse_spans(raw)]
        defs = {f[1]: f for f in native if f[0] == 'define-fun'}
        assert len(defs['|core_workflow_control_t|'][4]) - 1 == 452
        sources = {}
        for name in ['shell.sv', 'datapath.sv', 'projection-native.sv', 'layer.sv', 'core.sv', 'wrapper.sv', 'compile.ys']:
            path = ROOT / 'rmsnorm-pilot/model-consumption/connected' / name
            sources[name] = {'path': str(path), 'sha256': digest(read(path))}
        event_seal = json.loads(read(ROOT / 'HEAD-FINAL-RMS-FRAME-ORIGIN-R1-EVENT-SEALED.json'))
        event_path = ROOT / 'head-final-rms-frame-origin-r1/E_HEAD-accepted-RMS-to-frame-word.smt2'
        event_raw = read(event_path)
        assert digest(event_raw) == event_seal['files'][event_path.name]
        event_forms = [f for f, _, _ in parser.parse_spans(event_raw)]
        nf_type = next(f for f in event_forms if f[0] == 'declare-datatypes' and f[2][0][0] == 'NormFrame')
        event_defs = {f[1]: f for f in event_forms if f[0] == 'define-fun'}
        nf_helpers = [nf_type, *[event_defs[name] for name in ['nf-zero', 'nf-next', 'nf-I']]]
        nf_seal_raw = read(ROOT / 'HEAD-NF-SOURCE-TRACE-R1-SEALED.json')
        assert digest(nf_seal_raw) == '51f911c3f2329bd39e38770563917bdab4cd5920b6779a47088721f637c84932'
        row_seal_raw = read(ROOT / 'HEAD-STEP-RMS-ROW12-R1-SEALED.json')
        assert digest(row_seal_raw) == '1cb5e7e60c98e691218b7228a60e1237afc5d0484d37861db718b63f523bf5a0'
        observations = {}
        def getter(path, state='a'):
            name = '|core_workflow_control_n ' + path + '|'
            assert name in defs, ('Missing actual getter', path)
            d = defs[name]
            assert d[2] == [['state', S]], ('Getter signature', path)
            observations[path] = {'literal_getter_definition': d, 'sort': d[3]}
            return c(name, state)
        ds = lambda path, state='s': getter(D + path, state)
        js = lambda path, state='s': getter(J + path, state)
        ss = lambda path, state='a': getter(SHELL + path, state)
        head_capture = AND(ds('rst_n'), NOT(ds('clear_i')), NOT(ds('fault_q')),
            EQ(ds('engine_state_q'), BV(0, 4)), ds('head_start_accept'))
        j_state = js('state_q')
        priority_error = OR(
            AND(NOT(EQ(j_state, BV(0, 3))), js('start_valid_i')),
            AND(NOT(EQ(j_state, BV(1, 3))), js('activation_valid_i')),
            AND(NOT(EQ(j_state, BV(0, 3))), NOT(EQ(j_state, BV(5, 3))),
                NOT(EQ(j_state, BV(7, 3))), NOT(js('model_locked_i'))),
            js('activation_protocol_error'), js('weight_protocol_error'),
            js('result_protocol_error'), js('group_retire_protocol_error'),
            AND(NOT(EQ(j_state, BV(3, 3))), OR(js('stream_done_valid'), js('engine_done_valid'))))
        job_capture = AND(js('reset_n'), NOT(js('upstream_fail_closed_i')),
            NOT(js('fail_q')), NOT(js('stream_fail')), NOT(js('engine_fail')),
            NOT(js('clear_i')), NOT(c('job7-priority-error', 's')),
            EQ(j_state, BV(0, 3)), js('start_transfer'), js('incoming_descriptor_valid'),
            EQ(js('fixed_job_i'), BV(7, 4)))
        helpers = [
            ['define-fun', 'head-exponent-effective-capture', [['s', S]], 'Bool', head_capture],
            ['define-fun', 'job7-priority-error', [['s', S]], 'Bool', priority_error],
            ['define-fun', 'job7-exponent-effective-capture', [['s', S]], 'Bool', job_capture]]
        H = c('|core_workflow_control_h|', 'a')
        HB = c('|core_workflow_control_h|', 'b')
        T = c('|core_workflow_control_t|', 'a', 'b')
        I = c('nf-I', 'a', 'nf', 'watch')
        event = c('head-exponent-effective-capture', 'a')
        J_event = c('job7-exponent-effective-capture', 'a')
        root_reset = getter('reset_n')
        shell_live = AND(root_reset, ss('rst_n'), NOT(ss('clear_i')), NOT(ss('fail_closed_o')))
        accepted_nf = AND(c('nf-active', 'nf'), c('nf-sv', 'nf'),
            EQ(c('nf-count', 'nf'), BV(256, 9)), EQ(c('nf-sparent', 'nf'), c('nf-sid', 'nf')))
        birth = AND(shell_live, EQ(ss('state_q'), BV(16, 5)), accepted_nf,
            EQ(ss('final_norm_exponent_q'), c('nf-exp', 'nf')),
            EQ(ds('private_head_activation_exponent_i', 'a'), c('nf-exp', 'nf')))
        current_goal = IMP(AND(H, I, event), birth)
        reset_D = ds('rst_n', 'b')
        capture_goal = IMP(AND(H, HB, T, I, event),
            EQ(ds('head_activation_exponent_q', 'b'), ['ite', reset_D, c('nf-exp', 'nf'), BV(0, 8)]))
        D_head = EQ(ds('engine_state_q', 'a'), BV(8, 4))
        J_cone = AND(D_head, EQ(js('fixed_layer_i', 'a'), BV(7, 3)),
            EQ(js('activation_exponent_i', 'a'), ds('head_activation_exponent_q', 'a')))
        j_goal = AND(IMP(AND(H, J_event), J_cone),
            IMP(AND(H, HB, T, J_event), EQ(js('activation_exponent_q', 'b'),
                ['ite', js('reset_n', 'b'), ds('head_activation_exponent_q', 'a'), BV(0, 8)])))
        D_hold = AND(ds('rst_n', 'a'), NOT(ds('clear_i', 'a')), NOT(event))
        # Job exponent can also change for non-head jobs. The hold enable must
        # exclude every actual legal descriptor capture, not merely job7.
        any_job_capture = deepcopy_replace(job_capture, EQ(js('fixed_job_i'), BV(7, 4)), 'true')
        helpers.append(['define-fun', 'job-exponent-effective-capture', [['s', S]], 'Bool', any_job_capture])
        J_hold = AND(js('reset_n', 'a'), NOT(c('job-exponent-effective-capture', 'a')))
        holds_goal = IMP(AND(H, HB, T), AND(
            IMP(D_hold, EQ(ds('head_activation_exponent_q', 'b'),
                ['ite', reset_D, ds('head_activation_exponent_q', 'a'), BV(0, 8)])),
            IMP(J_hold, EQ(js('activation_exponent_q', 'b'),
                ['ite', js('reset_n', 'b'), js('activation_exponent_q', 'a'), BV(0, 8)]))))
        goals = dict(zip(ORDER, [current_goal, capture_goal, j_goal, holds_goal]))
        declarations = [['declare-const', name, sort] for name, sort in [
            ('a', S), ('b', S), ('nf', 'NormFrame'), ('watch', B(8))]]
        queries, types = {}, {}
        for name in ORDER:
            additions = [*nf_helpers, *helpers, *declarations, ['assert', NOT(goals[name])],
                ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            query = raw + ('\n' + '\n'.join(map(parser.smt, additions)) + '\n').encode()
            assert query[:len(raw)] == raw
            assert [f for f, _, _ in parser.parse_spans(query) if f[0] == 'assert'] == [['assert', NOT(goals[name])]]
            types[name] = typing.check(query)
            queries[name] = query
        binding = {'native_sha256': NATIVE_SHA, 'entire_native_prefix_retained': True,
            'native_T_conjuncts': 452, 'source_files': sources, 'native_getter_bindings': observations,
            'NF_helpers': nf_helpers, 'source_event_definitions': helpers, 'declarations': declarations,
            'goals': goals, 'head_birth_conclusion': birth, 'job7_capture_cone': J_cone,
            'successor_reset_masking_explicit': True, 'successor_health_assumed': False,
            'all_job_descriptor_captures_excluded_from_J_hold': True,
            'head_owner_induction_or_saved_R0_join_proved': False,
            'read_metadata_postscale_selector_join_proved': False,
            'numerical_RMS_proved': False, 'whole_device_theorem': False, 'new_native_jobs': 0}
        for name in ['mode_guard.py', 'GUARD-SOURCE.json', 'GUARD-PROBES.json', 'probe_guard.py', 'output_check.py']:
            read(P / name)
        guard_source = json.loads(read(P / 'GUARD-SOURCE.json'))
        assert digest(read(guard_source['path'])) == guard_source['sha256']
        for label in ['helper', 'memory']:
            for name in ['STARTED.json', 'FINISHED.json', 'MONITOR-BINDING.json', 'NATIVE.log']:
                read(P / 'guard-probes' / label / name)
            read(P / 'guard-probes' / (label + '-observations.jsonl'))
        read(HERE / 'prepare_exponent.py')
        plan = {'scope': 'first-four-native-head-start-and-job-exponent-leaves', 'order': ORDER,
            'queries': {name: {'sha256': digest(queries[name]), 'expected': 'unsat'} for name in ORDER},
            'maximum_native_jobs_this_gate': 4, 'phase_A_total_native_job_budget': 8,
            'workers': 1, 'memory_cap_bytes': 4 * (1 << 30), 'new_native_jobs': 0,
            'time_or_CPU_kill_enabled': False, 'unexpected_result_stops_dependents': True,
            'diagnostic_launch_authorized_by_this_gate': False}
        return queries, binding, plan, types, dict(READS)


def deepcopy_replace(term, old, new):
    if term == old:
        return new
    return [deepcopy_replace(t, old, new) for t in term] if isinstance(term, list) else term


if __name__ == '__main__':
    queries, binding, plan, types, pins = assemble()
    for name, raw in queries.items():
        with (HERE / (name + '.smt2')).open('xb') as output:
            output.write(raw)
    for name, value in [('SOURCE-BINDING.json', binding), ('QUERY-PLAN.json', plan),
                        ('TYPE-CHECK.json', types), ('READ-PINS.json', pins)]:
        with (HERE / name).open('x') as output:
            output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_queries': list(queries), 'new_native_jobs': 0}))

"""Fixed same-prefix deduction and locality audit for the two owner inductions."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json

HS = 'original-head-exponent-owner-and-origin'
HF = 'original-head-exponent-saved-FRAME-link'
CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
sub = lambda x, m: m.get(x, x) if isinstance(x, str) else [sub(t, m) for t in x]
digest = lambda v: hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def replace(x, old, new):
    if x == old:
        return deepcopy(new)
    return x if isinstance(x, str) else [replace(t, old, new) for t in x]


def validate(application, exports, imports, prepared):
    api, data = exports['apis'], prepared['data']
    nodes = application['nodes']
    assert application['root_context'] == exports['context'] == imports['root_context']
    context = deepcopy(exports['prefix_artifact']['inherited_prefix_source_context'])
    assert digest(context) == CONTEXT_SHA
    assert set(application['families']) == {HS, HF}
    assert application['HS_fixed_initial_recurrence'] == ['=', ['HS', '1'], ['hs-zero', ['NF', '1']]]
    assert digest(nodes[:4]) == imports['installed_nodes_sha256']
    assert data['origin_application']['prefix']['prefix_bound_domain'] == ['<=', '1', 'N']
    assert data['certificate_prefix']['prefix']['prefix_bound_domain'] == ['<=', '1', 'N']
    assert exports['prefix_artifact']['prefix_bound_domain'] == ['<=', '1', 'N']
    assert imports['inherited_prefix_source_context'] == context
    anchors = application['accepted_total_definition_anchors']
    assert {k: v for k, v in anchors.items() if k != 'CERT'} == imports['total_observer_definition_anchors']
    cert_nodes = data['certificate_application']['application']['nodes']
    for label, number, old_index in [('zero', 36, '1'), ('step', 132, 'n_current_frame')]:
        a = anchors['CERT'][label]
        assert a['source_artifact_sha256'] == data['raw_pins']['certificate_application']
        assert a['accepted_component_seal_sha256'] == data['raw_pins']['certificate_seal']
        assert a['source_node_id'] == number and a['source_index'] == old_index
        assert a['original_total_definition_node'] == cert_nodes[number]
        assert a['original_domain_parent'] == (cert_nodes[cert_nodes[number]['parents'][0]] if label == 'step' else None)
    schemas = {data[which + '_plan']['queries'][name]['sha256']: (which, name, binding['goals'][name])
        for which, binding in [('owner', data['owner_binding']), ('frame', data['frame_binding'])]
        for name in data[which + '_plan']['order']}
    assert len(schemas) == 6
    definitions = {f[1]: f for f in [*exports['helper_theory'], *exports['nf_provider']['helpers'],
        *application['helper_theory']] if f[0] == 'define-fun'}
    datatypes = [f for f in [*exports['helper_theory'], *exports['nf_provider']['helpers'],
        *application['helper_theory']] if f[0] == 'declare-datatypes']
    accepted_ids = {application['accepted_import_ids']['origin']: prepared['imported_origin_node'],
        application['accepted_import_ids']['certificate']: prepared['imported_certificate_node']}
    def expected_mapping(which, name, at):
        base = at == '1'
        allowed = {'head-owner-base': ['1'], 'head-owner-preserve': ['n_original_head_exponent'],
            'head-owner-origin': ['1', 'n_original_head_exponent'], 'frame-head-owner-base': ['1'],
            'frame-head-owner-preserve': ['n_original_head_frame_link'],
            'owner-clock-and-saved-exponent': ['n_original_head_exponent']}
        assert at in allowed[name]
        functions = {'hs-event-at': 'actual-hs-event-at', 'hs-record-at': 'NF', 'hs-origin-I': 'actual-hs-origin-I'}
        after = '1' if base else ['+', at, '1']
        if which == 'owner':
            return {'a': ['A', at], 'b': ['A', after], 'nf': ['NF', at], 'history': ['HS', at],
                'initial': ['NF', at], 'watch': ['_', 'bv0', '8'], 'empty': ['NFEMPTY', '0' if base else at],
                'observation': at, 'revoke': ['or', ['not', ['|core_workflow_control_n u_native.u_six_layers.u_datapath.rst_n|', ['A', at]]],
                    ['|core_workflow_control_n u_native.u_six_layers.u_datapath.clear_i|', ['A', at]]],
                'capture': ['head-exponent-effective-capture', ['A', at]], **functions}
        return {'a': ['A', at], 'b': ['A', after], 'nf': ['NF', at], 'history': ['HS', at],
            'columns': ['COLUMNS', at], 'next-columns': ['COLUMNS', after],
            'job': ['c-base', ['CAPTURE', at]], 'next-job': ['c-base', ['CAPTURE', after]],
            'frame': ['FRAME', at], 'certificate': ['CERT', at], 'watch-frame': ['_', 'bv0', '10'],
            'watch': ['_', 'bv0', '8'], 'empty-frame': 'unused-frame', 'empty-nf': ['NFEMPTY', '0' if base else at],
            'observation': at, **functions}
    for i, node in enumerate(nodes):
        assert node['id'] == i
        assert all(type(p) is int and 0 <= p < i for p in node['parents'])
        support = set(node['introduced_support'])
        for p in node['parents']:
            support.update(nodes[p]['support'])
        assert support - set(node.get('discharged_support', [])) == set(node['support'])
        f, kind, parents = node['formula'], node['kind'], node['parents']
        if kind == 'qualified-published-trace-context-application':
            assert not parents
            if i < 4:
                row = imports['families'][i]
                assert f == row['formula'] and node['support'] == row['support']
                for key in ['property_template', 'quantified_parameters', 'accepted_bounded_formula']:
                    assert node[key] == row[key]
            else:
                assert i in accepted_ids
                original = accepted_ids[i]
                for key in ['formula', 'property_template', 'quantified_parameters', 'support']:
                    assert node[key] == original[key]
                assert node['exact_original_source_context'] == exports['context']
                bounded = node['accepted_bounded_formula']
                at = bounded[1][-1][0]
                assert bounded == ['forall', [*node['quantified_parameters'], [at, 'Int']],
                    ['=>', ['and', ['<=', '1', at], ['<=', at, 'N']], sub(node['property_template'], {'@index': at})]]
        elif kind == 'qualified-source-schema-uniform-instance':
            which, name, goal = schemas[node['original_query_sha256']]
            assert node['original_query_goal'] == goal and f == sub(goal, node['uniform_mapping'])
            binding = data[which + '_binding']
            function_map = {'hs-event-at': 'actual-hs-event-at', 'hs-record-at': 'NF', 'hs-origin-I': 'actual-hs-origin-I'}
            assert set(node['uniform_mapping']) == {d[1] for d in binding['declarations']} | set(function_map)
            assert all(node['uniform_mapping'][k] == v for k, v in function_map.items())
            assert node['uniform_mapping'] == expected_mapping(which, name, node['uniform_mapping']['a'][1])
            assert node['accepted_result_review_sha256'] == data['raw_pins'][which + '_review']
            assert node['fixed_function_realizations'] == {
                'hs-event-at': prepared['actual_event'], 'hs-record-at': ['declare-fun', 'NF', ['Int'], 'NormFrame'],
                'hs-origin-I': prepared['actual_origin'], 'fj-capture-record-at': prepared['cert_prepared'][3]}
            assert not parents and node['introduced_support'] == []
        elif kind == 'conjunction-introduction':
            assert f == ['and', *[nodes[p]['formula'] for p in parents]]
        elif kind == 'conjunction-elimination':
            assert len(parents) == 1
            whole = nodes[parents[0]]['formula']
            assert whole[0] == 'and' and 1 <= node['position'] < len(whole)
            assert f == whole[node['position']]
        elif kind == 'implication-elimination':
            assert len(parents) == 2
            rule, argument = (nodes[p]['formula'] for p in parents)
            assert rule == ['=>', argument, f]
        elif kind == 'typed-equality-context-substitution':
            assert len(parents) == 2
            old, equation = (nodes[p]['formula'] for p in parents)
            assert equation[0] == '='
            assert f in [replace(old, equation[1], equation[2]), replace(old, equation[2], equation[1])]
        elif kind == 'typed-equality-reflexivity':
            assert not parents and f[0] == '=' and f[1] == f[2]
        elif kind == 'literal-function-definition-instance':
            definition = node['definition']
            assert definition == definitions[definition[1]]
            assert set(node['uniform_mapping']) == {a[0] for a in definition[2]}
            assert f == ['=', [definition[1], *[node['uniform_mapping'][a[0]] for a in definition[2]]],
                sub(definition[4], node['uniform_mapping'])]
            assert not parents
        elif kind == 'literal-datatype-constructor-selector':
            assert node['datatype'] in datatypes and not parents
            typ = next(t for t in node['datatype'][2] if t[0] == node['datatype_name'])
            ctor = next(t for t in typ[1:] if t[0] == node['constructor_name'])
            position = node['selector_position']
            assert 1 <= position < len(ctor)
            assert ctor[position][0] == node['selector_name']
            assert f[0] == '=' and f[1][0] == node['selector_name']
            assert f[1][1][0] == ctor[0] and len(f[1][1]) == len(ctor)
            assert f[2] == f[1][1][position]
        elif kind == 'actual-source-trace-projection':
            assert f[0] in ['|core_workflow_control_h|', '|core_workflow_control_t|']
            assert all(s[0] == 'A' for s in f[1:])
            if f[0].endswith('_t|'):
                assert f[2] == ['A', ['+', f[1][1], '1']]
            assert node['introduced_support'][0] == 'Gamma:actual-composed-source'
        elif kind == 'actual-common-reset-entry':
            assert f == ['not', ['|core_workflow_control_n reset_n|', ['A', '1']]]
            assert set(node['support']) == {'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-1'}
        elif kind == 'total-same-trace-nondriving-component-observer-definition':
            registry, at, step = node['registry'], node['index'], node['step']
            assert registry in {'HS', 'NF', 'FRAME', 'CERT'}
            if registry == 'HS':
                body = ['hs-next', ['A', at], ['NF', at], ['HS', at]] if step else ['hs-zero', ['NF', '1']]
                name = 'hs-next' if step else 'hs-zero'
            elif registry == 'NF':
                body = ['nf-next', ['A', at], ['NF', at], ['NFEMPTY', at]] if step else ['nf-zero', ['NFEMPTY', '0']]
                name = 'nf-next' if step else 'nf-zero'
            elif registry == 'FRAME':
                body = ['frame-next', ['A', at], ['COLUMNS', at], ['FRAME', at], 'unused-frame'] if step else ['frame-zero', 'unused-frame']
                name = 'frame-next' if step else 'frame-zero'
            else:
                body = ['frc-next', ['fj-source-view', ['A', at], ['COLUMNS', at]], ['FRAME', at], ['NF', at], ['CERT', at], at] if step else ['frc-zero', ['NFEMPTY', '0']]
                name = 'frc-next' if step else 'frc-zero'
            assert f == ['=', [registry, ['+', at, '1'] if step else '1'], body]
            assert node['exact_source_definition'] == definitions[name]
            assert step or at == '1'
            anchor = node['accepted_total_definition_anchor']
            if registry == 'HS':
                assert anchor is None and node['total_definition_uniform_index_mapping'] == {}
            else:
                fixed = anchors['frame' if registry == 'FRAME' else registry]['step' if step else 'zero']
                assert anchor == fixed
                original, old_index = anchor['original_total_definition_node'], anchor['source_index']
                old_family = {'NF': 'original-NF-provider', 'FRAME': 'actual-frame', 'CERT': 'original-current-frame-RMS-certificate'}[registry]
                old_registry = {'NF': 'original-NF', 'FRAME': 'frame', 'CERT': 'CERT'}[registry]
                assert original['kind'] == 'total-same-trace-nondriving-component-observer-definition'
                assert original['registry'] == old_registry and original['step'] is step and original['index'] == old_index
                assert original['id'] == anchor['source_node_id']
                expected_support = {'Gamma:actual-composed-source'} | ({'INDEX:' + old_family} if step else set())
                assert set(original['support']) == set(original['introduced_support']) == expected_support
                mapping = {old_index: at} if step else {}
                assert node['total_definition_uniform_index_mapping'] == mapping
                assert f == sub(original['formula'], mapping)
                if 'exact_source_definition' in original:
                    assert original['exact_source_definition'] == definitions[name]
                domain = anchor['original_domain_parent']
                if step:
                    assert domain['kind'] == 'scoped-natural-index-domain' and domain['formula'] == ['<=', '1', old_index]
                    assert domain['scope'] == old_family and domain['support'] == ['INDEX:' + old_family]
                    assert original['parents'] == [domain['id']]
                else:
                    assert original['parents'] == [] and domain is None
        elif kind == 'uniform-global-trace-instantiation':
            parent = nodes[parents[0]]
            assert parent['kind'] in ['ordinary-induction', 'qualified-published-trace-context-application']
            assert set(node['parameters']) == {x[0] for x in parent['quantified_parameters']}
            assert f == sub(parent['property_template'], {'@index': node['index'], **node['parameters']})
        elif kind == 'scoped-natural-index-domain':
            assert f[0:2] == ['<=', '1'] and not parents
            assert node['support'] == ['INDEX:' + node['scope']]
        elif kind == 'scoped-induction-hypothesis':
            assert len(parents) == 1 and nodes[parents[0]]['kind'] == 'scoped-natural-index-domain'
            bound = nodes[parents[0]]
            assert set(node['support']) == {'INDEX:' + bound['scope'], 'IH:' + bound['scope']}
            assert node['scope'] == bound['formula'][2]
        elif kind == 'ordinary-induction':
            index, template = node['fresh_step_index'], node['property_template']
            assert parents == [node['base_parent'], node['step_parent']]
            assert nodes[node['base_parent']]['formula'] == sub(template, {'@index': '1'})
            assert nodes[node['step_parent']]['formula'] == sub(template, {'@index': ['+', index, '1']})
            assert nodes[node['scoped_IH']]['formula'] == sub(template, {'@index': index})
            assert nodes[node['bound_parent']]['formula'] == ['<=', '1', index]
            assert f == ['forall', [[index, 'Int']], ['=>', ['<=', '1', index], sub(template, {'@index': index})]]
            assert node['quantified_parameters'] == []
            family = HS if index == 'n_original_head_exponent' else HF
            assert set(node['discharged_support']) == {'INDEX:' + family, 'IH:' + family}
        else:
            raise AssertionError(('Unreviewed deduction kind', i, kind))
    # Only current/next source/history accesses occur in new deduction nodes.
    # The qualified origin predicate's guarded historical functions are opaque
    # until the exact three-case boundary below; no arbitrary INDEX is granted.
    indexed = {'A', 'C', 'COLUMNS', 'CAPTURE', 'FRAME', 'CERT', 'HS', 'NF', 'NFEMPTY',
        'ROW', 'ROWFRAME', 'FRAMEORIGIN', 'HEADER', 'GROUP', 'LAYOUT'}
    def occurrences(x):
        out = []
        if isinstance(x, list):
            if x and isinstance(x[0], str) and x[0] in indexed:
                assert len(x) == 2
                out.append((x[0], x[1]))
            for t in x:
                out.extend(occurrences(t))
        return out
    imported_stops = set(range(6))
    validated = set()
    results = {}
    def ancestry(seed, allowed, stops):
        seen = set()
        def visit(i):
            if i in seen:
                return
            seen.add(i)
            if i in stops:
                return
            for symbol, at in occurrences(nodes[i]['formula']):
                assert at in allowed or symbol == 'NFEMPTY' and at == '0', (i, symbol, at, allowed)
            for p in nodes[i]['parents']:
                visit(p)
        visit(seed)
        return {'nodes': sorted(seen), 'allowed_indices': allowed, 'stopped_accepted_globals': sorted(seen & stops),
            'unconditional_historical_index_exceptions': []}
    for family in [HS, HF]:
        report = application['families'][family]
        node = nodes[report['global_node']]
        index = node['fresh_step_index']
        expected_index = 'n_original_head_exponent' if family == HS else 'n_original_head_frame_link'
        assert index == expected_index
        expected_template = ['and', ['hs-I', ['A', '@index'], ['NF', '@index'], ['HS', '@index']],
            ['actual-hs-origin-I', ['HS', '@index'], '@index']] if family == HS else [
            'hf-I', ['A', '@index'], ['FRAME', '@index'], ['CERT', '@index'], ['HS', '@index']]
        assert node['property_template'] == expected_template
        assert report['base_parent'] == node['base_parent'] and report['step_parent'] == node['step_parent']
        assert report['IH_parent'] == node['scoped_IH']
        bound = nodes[node['bound_parent']]
        ih = nodes[node['scoped_IH']]
        assert bound['scope'] == family and bound['formula'] == ['<=', '1', index]
        assert ih['parents'] == [bound['id']] and ih['scope'] == index
        assert ih['formula'] == sub(expected_template, {'@index': index})
        base = ancestry(node['base_parent'], ['0', '1'], imported_stops | validated)
        step = ancestry(node['step_parent'], [index, ['+', index, '1']], imported_stops | validated)
        n = 'n_head_exponent_prefix'
        bounded = ['forall', [[n, 'Int']], ['=>', ['and', ['<=', '1', n], ['<=', n, 'N']],
            sub(node['property_template'], {'@index': n})]]
        results[family] = {'bounded_formula': bounded, 'root_support': node['support'], 'base_locality': base, 'step_locality': step}
        validated.add(node['id'])
    # Validate the precise generic recurrence and guarded historical family.
    h = data['owner_binding']['owner_helpers']
    generic_next = next(f for f in h if f[:2] == ['define-fun', 'hs-generic-next'])
    generic_I = next(f for f in h if f[:2] == ['define-fun', 'hs-origin-I'])
    assert generic_next[4] == ['ite', 'revoke', ['mkHeadExponentHistory', 'false', ['hs-at', 'h'], ['hs-nf', 'h']],
        ['ite', 'capture', ['mkHeadExponentHistory', 'true', 'observation', 'nf'], 'h']]
    assert generic_I[4] == ['=>', ['hs-valid', 'h'], ['and', ['<=', '1', ['hs-at', 'h']],
        ['<', ['hs-at', 'h'], 'observation'], ['hs-event-at', ['hs-at', 'h']],
        ['=', ['hs-nf', 'h'], ['hs-record-at', ['hs-at', 'h']]]]]
    assert prepared['actual_origin'] == sub(generic_I, {'hs-event-at': 'actual-hs-event-at',
        'hs-record-at': 'NF', 'hs-origin-I': 'actual-hs-origin-I'})
    report = application['families'][HS]
    event = nodes[report['actual_event_definition']]
    assert event['definition'] == prepared['actual_event']
    assert report['generic_origin_step'] in results[HS]['step_locality']['nodes']
    assert report['actual_event_definition'] in results[HS]['step_locality']['nodes']
    assert report['source_clock_specialization'] in results[HS]['step_locality']['nodes']
    assert report['step_HS_recurrence'] in results[HS]['step_locality']['nodes']
    assert report['step_NF_recurrence'] in results[HS]['step_locality']['nodes']
    index = 'n_original_head_exponent'
    clock = nodes[report['source_clock_parent']]
    assert clock['formula'] == ['=', ['nf-t', ['NF', index]], ['-', index, '1']]
    origin_premise = nodes[report['generic_origin_premise']]
    generic_rule = nodes[report['generic_origin_step']]
    applied = nodes[report['applied_generic_origin']]
    assert generic_rule['formula'][0] == '=>'
    assert origin_premise['formula'] == generic_rule['formula'][1]
    assert applied['parents'] == [generic_rule['id'], origin_premise['id']]
    assert applied['formula'] == generic_rule['formula'][2]
    assert generic_rule['kind'] == 'conjunction-elimination' and generic_rule['position'] == 2
    generic_schema = nodes[generic_rule['parents'][0]]
    assert generic_schema['kind'] == 'qualified-source-schema-uniform-instance'
    assert generic_schema['original_query_sha256'] == data['owner_plan']['queries']['head-owner-origin']['sha256']
    head_global = nodes[report['global_node']]
    premise_parents = origin_premise['parents']
    assert len(premise_parents) == 4 and premise_parents[0] == head_global['bound_parent']
    ih_origin = nodes[premise_parents[1]]
    assert ih_origin['kind'] == 'conjunction-elimination' and ih_origin['parents'] == [report['IH_parent']] and ih_origin['position'] == 2
    assert premise_parents[2:] == [report['actual_event_definition'], report['NF_record_reflexivity']]
    chain = report['source_clock_chain']
    assert chain['accepted_global_parent'] == application['accepted_import_ids']['origin']
    instance = nodes[chain['current_global_instance']]
    assert instance['kind'] == 'uniform-global-trace-instantiation' and instance['parents'][0] == chain['accepted_global_parent']
    assert instance['index'] == index and instance['parameters'] == {}
    assert nodes[chain['predicate_equation']]['definition'] == prepared['origin_prepared']['invariants']['STEP']
    assert nodes[chain['observer_equation']]['definition'] == definitions['nf-step-origin-observer']
    assert chain['clock_projection'] == report['source_clock_parent']
    assert clock['parents'] == [chain['normalized_predicate']] and clock['position'] == 1
    clock_ancestry = ancestry(clock['id'], [index, ['+', index, '1']], imported_stops)
    assert {chain[k] for k in ['accepted_global_parent', 'current_global_instance', 'predicate_equation',
        'observer_equation', 'normalized_predicate']} <= set(clock_ancestry['nodes'])
    clock_application = nodes[report['source_clock_application']]
    assert clock_application['kind'] == 'implication-elimination'
    assert clock_application['parents'][1] == clock['id']
    clock_rule = nodes[clock_application['parents'][0]]
    assert clock_rule['kind'] == 'conjunction-elimination' and clock_rule['position'] == 1
    clock_schema = nodes[clock_rule['parents'][0]]
    assert clock_schema['kind'] == 'qualified-source-schema-uniform-instance'
    assert clock_schema['original_query_sha256'] == data['frame_plan']['queries']['owner-clock-and-saved-exponent']['sha256']
    bridge = nodes[report['source_clock_specialization']]
    assert bridge['kind'] == 'conjunction-elimination' and bridge['parents'] == [clock_application['id']] and bridge['position'] == 2
    assert nodes[report['NF_record_reflexivity']]['formula'] == ['=', ['NF', index], ['NF', index]]
    assert report['source_clock_parent'] in results[HS]['step_locality']['nodes']
    assert report['applied_generic_origin'] in results[HS]['step_locality']['nodes']
    return deepcopy({'kind': 'original-head-exponent-owners-finite-prefix', 'prefix_bound_domain': ['<=', '1', 'N'], 'bounded_source_context': context,
        'bounded_source_context_sha256': CONTEXT_SHA, 'families': results,
        'state_domain': ['and', ['<=', '1', 'n'], ['<=', 'n', 'N']],
        'step_domain': ['and', ['<=', '1', 'n'], ['<', 'n', 'N']],
        'fixed_HS_origin_boundary': {'cases': [
            {'guard': 'revoke', 'next_valid': 'false', 'historical_lookup_required': False},
            {'guard': ['and', ['not', 'revoke'], 'capture'], 'next_at': 'observation', 'next_nf': 'nf',
                'source_current_observation': index, 'record_parent': report['NF_record_reflexivity'],
                'event_parent': report['actual_event_definition'], 'clock_parent': report['source_clock_specialization'],
                'bounds_from_step_domain': ['and', ['<=', '1', index], ['<', index, 'N']]},
            {'guard': ['and', ['not', 'revoke'], ['not', 'capture']],
                'next_history': 'h', 'same_past_stamp': ['hs-at', 'h'], 'same_past_payload': ['hs-nf', 'h'],
                'same_past_event': ['actual-hs-event-at', ['hs-at', 'h']], 'same_past_record': ['NF', ['hs-at', 'h']],
                'past_bounds_from_valid_IH': ['and', ['<=', '1', ['hs-at', 'h']], ['<', ['hs-at', 'h'], 'observation']],
                'IH_parent': report['IH_parent'], 'historical_source_function_unfolded': False}],
            'generic_step_parent': report['generic_origin_step'], 'IH_parent': report['IH_parent'],
            'current_event_parent': report['actual_event_definition'], 'clock_specialization_parent': report['source_clock_specialization'],
            'HS_recurrence_parent': report['step_HS_recurrence'], 'NF_recurrence_parent': report['step_NF_recurrence'],
            'future_or_out_of_prefix_lookup_allowed': False},
        'function_realization': prepared['cert_prepared'][3], 'new_native_jobs': 0,
        'saved_R0_or_row_application_proved': False, 'selector_score_proved': False, 'whole_device_theorem': False})

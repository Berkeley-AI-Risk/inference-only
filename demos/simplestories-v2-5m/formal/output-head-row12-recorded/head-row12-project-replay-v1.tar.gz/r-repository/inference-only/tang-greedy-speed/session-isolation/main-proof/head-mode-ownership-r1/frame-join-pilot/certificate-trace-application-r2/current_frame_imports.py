"""Restricted imports of four immutable accepted state theorems.

No file reads, module loading, proof initialization, replay or engine calls.
The installer is unrun preparation and needs independent code/input review.
"""
if not __debug__:
    raise RuntimeError('Optimization forbidden')

from copy import deepcopy
import hashlib
import json

PINS = {
    'parent_seal': 'c5591f6f05aa192edc891e8a6888e43895cc1d9b00a11eb067a0995d4c23b99e',
    'parent_source': '2fc7ab19a0936bae6ca50d2effe3d5d1c1e01ba6af480cfeb5a86a0808393e5f',
    'parent_prefix': '17869f35160747f7b14013f4c4e43414171258321c14c275d29136559e336553',
    'NF_seal': '51f911c3f2329bd39e38770563917bdab4cd5920b6779a47088721f637c84932',
    'NF_application': '7bdcccfb334bdf758b9b2da2174a94fa3941d37efbb0be970c4975892eab9d5e',
    'NF_prefix': '1c67030668e8532a547569e7dc0d9185d4365d1389e8e94e2e35a4e00e676ca5',
}
FAMILIES = ('control', 'actual-capture', 'actual-frame', 'original-NF-provider')
CONTEXT_SHA = '615f9eb7893c1a73f1ec036a87d9b33ff308aeec93827e38ae384fe7e6494dbc'
PREFIX_CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
ROOTS = frozenset({'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-0',
    'Gamma:entry-reset-low-at-1', 'Gamma:runtime-entry-image',
    'Gamma:static-metadata', 'Gamma:vendor-storage'})
NF_ARRAY = ['Array', ['_', 'BitVec', '8'], ['_', 'BitVec', '16']]


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _sub(term, mapping):
    return mapping.get(term, term) if isinstance(term, str) else [_sub(t, mapping) for t in term]


def prepare_imports(exports, raw_inputs):
    """Check fixed accepted theorem identities before any language/proof mutation."""
    assert set(raw_inputs) == set(PINS)
    for name, expected in PINS.items():
        assert hashlib.sha256(raw_inputs[name]).hexdigest() == expected, name
    data = {name: json.loads(raw) for name, raw in raw_inputs.items()}
    parent, prefix = data['parent_source'], data['parent_prefix']
    nf_result = data['NF_application']
    nf_prefix = data['NF_prefix']['prefix']  # retain/check the pinned outer receipt above
    context = exports['context']
    assert digest(context) == CONTEXT_SHA and set(context) == ROOTS
    assert nf_result['application']['root_context'] == nf_prefix['root_context'] == context
    assert exports['provenance'] == nf_result['parent_export_provenance']
    assert exports['provenance']['seal_sha256'] == PINS['parent_seal']
    assert exports['provenance']['source_dag_sha256'] == PINS['parent_source']
    assert exports['provenance']['prefix_sha256'] == PINS['parent_prefix']
    assert exports['serialized_nodes'] == parent['nodes']
    assert exports['serialized_global_registry'] == parent['global_nodes']
    assert exports['prefix_artifact'] == prefix
    for name, member in [('parent_source', 'CONTINUITY-SOURCE-APPLICATION-DRAFT.json'),
                         ('parent_prefix', 'CONTINUITY-PREFIX-APPLICATION-DRAFT.json')]:
        assert data['parent_seal']['files'][member] == PINS[name]
    for name, member in [('NF_application', 'NF-APPLICATION-R3.json'),
                         ('NF_prefix', 'NF-PREFIX-APPLICATION.json')]:
        assert data['NF_seal']['files']['frame-join-pilot/certificate-trace-application-r2/' + member] == PINS[name]
    bounded_context = prefix['inherited_prefix_source_context']
    assert digest(bounded_context) == PREFIX_CONTEXT_SHA
    assert nf_prefix['inherited_prefix_source_context'] == bounded_context
    assert prefix['prefix_bound_domain'] == nf_prefix['prefix_bound_domain'] == ['<=', '1', 'N']
    # The accepted loader's helper/source reads must be the same immutable
    # reads bound by the closed NF application, not a newly selected theory.
    for path, expected in exports['read_pins'].items():
        assert nf_result['actual_read_pins'][path] == expected, path
    observerdefs = {'columns': prefix['inherited_controller_definitions_on_prefix']['columns'],
                    'additional': prefix['additional_same_trace_observer_definitions_on_prefix']}
    assert exports['observerdefs'] == observerdefs
    rows = []
    for name, original_id in [('control', 779), ('actual-capture', 1051), ('actual-frame', 1232)]:
        assert parent['global_nodes'][name] == original_id
        original = parent['nodes'][original_id]
        selected = exports['selectedglobals'][name]
        assert selected['node_id'] == original_id and selected['node'] == original
        bounded = (prefix['earlier_bounded_consequences'] if name == 'control' else prefix['bounded_consequences'])[name]
        assert selected['bounded_formula'] == bounded
        rows.append((name, original, bounded, PINS['parent_seal']))
    nf_nodes = nf_result['application']['nodes']
    assert len(nf_nodes) == 30 and nf_result['application']['global_node'] == 29
    nf_original = nf_nodes[29]
    assert nf_prefix['global_node_id'] == 29 and nf_prefix['global_formula'] == nf_original['formula']
    assert nf_prefix['NF_application_nodes_sha256'] == digest(nf_nodes)
    rows.append(('original-NF-provider', nf_original, nf_prefix['bounded_formula'], PINS['NF_seal']))
    # Total definitions in the original accepted DAGs license these observer
    # equations. Bounded-prefix equation bodies are additional matching data,
    # never a theorem whose i<N antecedent is removed.
    assert nf_result['application']['observer_definition_nodes'] == [13, 27]
    anchors = {}
    anchor_specs = [
        ('columns', parent['nodes'], (753, 773), ('1', 'n_control'),
         'total-controller-observer-definition', 'columns', 'control', 'parent_source', 'parent_seal'),
        ('frame', parent['nodes'], (1075, 1096), ('1', 'n_actual_frame'),
         'total-same-trace-nondriving-component-observer-definition', 'frame', 'actual-frame', 'parent_source', 'parent_seal'),
        ('NF', nf_nodes, tuple(nf_result['application']['observer_definition_nodes']), ('1', 'n_original_NF'),
         'total-same-trace-nondriving-component-observer-definition', 'original-NF', 'original-NF-provider', 'NF_application', 'NF_seal'),
    ]
    for family, original_nodes, ids, indices, kind, registry, scope, artifact, component in anchor_specs:
        anchors[family] = {}
        for step, node_id, source_index in zip((False, True), ids, indices):
            original = original_nodes[node_id]
            assert original['id'] == node_id and original['kind'] == kind
            assert original['registry'] == registry and original['step'] is step
            assert original['index'] == source_index
            expected_support = {'Gamma:actual-composed-source'} | ({'INDEX:' + scope} if step else set())
            assert set(original['introduced_support']) == set(original['support']) == expected_support
            bound = None
            if step:
                assert len(original['parents']) == 1
                bound = original_nodes[original['parents'][0]]
                assert bound['id'] == original['parents'][0] and bound['kind'] == 'scoped-natural-index-domain'
                assert bound['formula'] == ['<=', '1', source_index]
                assert set(bound['support']) == {'INDEX:' + scope}
            else:
                assert original['parents'] == []
            if family == 'columns':
                expected = ['=', ['COLUMNS', ['+', source_index, '1']],
                    ['columns-next', ['A', source_index], ['COLUMNS', source_index]]] if step else ['=', ['COLUMNS', '1'], 'columns-zero']
            elif family == 'frame':
                expected = ['=', ['FRAME', ['+', source_index, '1']],
                    ['frame-next', ['A', source_index], ['COLUMNS', source_index], ['FRAME', source_index], 'unused-frame']] if step else ['=', ['FRAME', '1'], ['frame-zero', 'unused-frame']]
            else:
                expected = ['=', ['NF', ['+', source_index, '1']],
                    ['nf-next', ['A', source_index], ['NF', source_index], ['NFEMPTY', source_index]]] if step else ['=', ['NF', '1'], ['nf-zero', ['NFEMPTY', '0']]]
                assert original['exact_source_definition'] == exports['nf_provider']['helpers'][2 if step else 1]
            assert original['formula'] == expected
            anchors[family]['step' if step else 'zero'] = {
                'source_node_id': node_id, 'source_index': source_index,
                'source_artifact_sha256': PINS[artifact], 'accepted_component_seal_sha256': PINS[component],
                'original_total_definition_node': original, 'original_domain_parent': bound}
    prepared = []
    for name, original, bounded, seal_sha in rows:
        assert original['kind'] == 'ordinary-induction'
        parameters, template = original['quantified_parameters'], original['property_template']
        i = original['fresh_step_index']
        assert original['formula'] == ['forall', [*parameters, [i, 'Int']],
            ['=>', ['<=', '1', i], _sub(template, {'@index': i})]]
        n = bounded[1][-1][0]
        assert bounded == ['forall', [*parameters, [n, 'Int']], ['=>',
            ['and', ['<=', '1', n], ['<=', n, 'N']], _sub(template, {'@index': n})]]
        expected_support = ROOTS if name in {'control', 'actual-frame'} else {
            'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-0'}
        assert set(original['support']) == expected_support
        prepared.append({'family': name, 'formula': original['formula'],
            'property_template': template, 'quantified_parameters': parameters,
            'support': sorted(original['support']), 'original_global_node_id': original['id'],
            'accepted_component_seal_sha256': seal_sha, 'accepted_bounded_formula': bounded})
    return deepcopy({'families': prepared, 'input_pins': PINS, 'root_context': context,
        'inherited_prefix_source_context': bounded_context,
        'prefix_source_context_sha256': PREFIX_CONTEXT_SHA,
        'parent_observer_definitions': observerdefs,
        'NF_observer_definitions': nf_prefix['observer_definitions'],
        'total_observer_definition_anchors': anchors,
        'parent_export_provenance': exports['provenance']})


def install_current_globals(proof, language, exports, raw_inputs):
    """Install only the four fixed qualified theorems, without copied ancestry.

    This uses the existing qualified theorem-import node kind accepted by
    ValueProof.trace_instance. Original global IDs are provenance, never parents.
    Complete accepted bounded exports remain explicit for later prefix locality.
    """
    prepared = prepare_imports(exports, raw_inputs)
    assert proof.root_context == prepared['root_context']
    assert not proof.nodes and not proof.global_nodes and not proof.active_indices
    assert not proof.scope_labels and not proof.index_bindings
    assert all(callable(getattr(proof, name)) for name in ['add', 'trace_instance'])
    # Literal helper identity, not merely matching names or inferred sorts.
    for definition in [*exports['helper_theory'], *exports['nf_provider']['helpers']]:
        kind = definition[0]
        if kind == 'define-fun':
            existing = language.defs.get(definition[1])
            if definition in exports['nf_provider']['helpers'] and existing is None:
                continue
            assert existing == definition, definition[1]
        elif kind == 'declare-fun':
            assert language.decls.get(definition[1]) == definition, definition[1]
        elif kind.startswith('declare-datatype'):
            if definition in exports['nf_provider']['helpers'] and definition not in language.datatypes:
                continue
            assert definition in language.datatypes
    declarations = [['declare-fun', 'NF', ['Int'], 'NormFrame'],
                    ['declare-fun', 'NFEMPTY', ['Int'], NF_ARRAY]]
    for declaration in declarations:
        assert declaration[1] not in language.defs
        assert declaration[1] not in language.decls or language.decls[declaration[1]] == declaration
    # Language setup only after every input/proof interface has passed.
    language.add(deepcopy(exports['nf_provider']['helpers']))
    language.add(deepcopy(declarations))
    installed = {}
    for row in prepared['families']:
        node = proof.add('qualified-published-trace-context-application', deepcopy(row['formula']),
            support=deepcopy(row['support']), property_template=deepcopy(row['property_template']),
            quantified_parameters=deepcopy(row['quantified_parameters']),
            accepted_component_seal_sha256=row['accepted_component_seal_sha256'],
            original_global_node_id=row['original_global_node_id'],
            original_checked_kind='ordinary-induction',
            accepted_bounded_formula=deepcopy(row['accepted_bounded_formula']),
            accepted_prefix_source_context_sha256=PREFIX_CONTEXT_SHA,
            fixed_same_trace_observer_definitions_sha256=digest({
                'parent': prepared['parent_observer_definitions'], 'NF': prepared['NF_observer_definitions']}),
            accepted_export_input_pins=deepcopy(PINS))
        assert proof.nodes[node]['parents'] == []
        proof.global_nodes[row['family']] = node
        installed[row['family']] = node
    assert tuple(proof.global_nodes) == FAMILIES and len(proof.nodes) == 4
    return deepcopy({**prepared, 'installed_global_nodes': installed,
        'installed_nodes_sha256': digest(proof.nodes), 'new_proof_nodes': 4,
        'ordinary_mode_or_CERT_induction_constructed': False, 'historical_instantiation_attempted': False,
        'new_native_jobs': 0})

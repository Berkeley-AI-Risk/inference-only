if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
import re

def parse_spans(raw):
    tokens=[m for m in re.finditer(rb';[^\n]*|\|[^|]*\||"(?:[^"]|"")*"|\(|\)|[^\s()]+',raw) if not m.group().startswith(b';')]
    pos=0
    def one():
        nonlocal pos
        token=tokens[pos].group().decode();pos+=1
        if token!='(':
            assert token!=')';return token
        out=[]
        while tokens[pos].group()!=b')':out.append(one())
        pos+=1;return out
    out=[]
    while pos<len(tokens):
        start=tokens[pos].start();node=one();out.append((node,start,tokens[pos-1].end()))
    return out

def smt(n):return '('+' '.join(map(smt,n))+')' if isinstance(n,list) else n

def atoms(n):return {n} if isinstance(n,str) else set().union(*(atoms(c) for c in n)) if n else set()

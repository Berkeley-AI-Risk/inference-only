"""One ordinary E/J scalar induction using the original qualified control."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json
FAMILY = 'original-active-engine-job-exponent'
INDEX = 'n_original_engine_exponent'
CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
digest = lambda v: hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def prepare_metadata(exports, data):
    binding, plan, results = (data[k] for k in ['binding', 'plan', 'results'])
    assert binding['native_sha256'] == exports['context']['Gamma:actual-composed-source']['native_core_sha256']
    assert binding['native_T_conjuncts'] == 452
    assert len(results['results']) == 2 and results['all_expected_results_matched']
    assert results['active_owned_native_job'] is None
    for name, row in zip(plan['order'], results['results']):
        assert row['name'] == name and row['answer'] == 'unsat' and row['matched']
        assert row['query_sha256'] == plan['queries'][name]['sha256']
    definitions = {f[1]: f for f in exports['helper_theory'] if f[0] == 'define-fun'}
    assert definitions['selected-row-phase-I'] == binding['original_phase_invariant']
    assert definitions['current-job-I'] == binding['original_current_job_invariant']
    selected = exports['selectedglobals']['control']
    assert selected['node_id'] == 779 and selected['node']['kind'] == 'ordinary-induction'
    assert selected['node']['property_template'][7] == ['current-job-I', ['A', '@index'], ['COLUMNS', '@index']]
    assert selected['node']['property_template'][8] == ['selected-row-phase-I', ['A', '@index'], ['COLUMNS', '@index'], ['ROW', '@index'], ['HEADER', '@index']]
    assert digest(exports['prefix_artifact']['inherited_prefix_source_context']) == CONTEXT_SHA
    assert exports['prefix_artifact']['prefix_bound_domain'] == ['<=', '1', 'N']
    return deepcopy({'data': data, 'control': selected})


def construct(proof, language, exports, prepared, steps):
    api, data = exports['apis'], prepared['data']
    c, SUB = api['c'], api['SUB']
    assert not proof.nodes and not proof.active_indices and not proof.global_nodes
    assert proof.root_context == exports['context']
    selected = prepared['control']
    old = selected['node']
    imported = proof.add('qualified-published-trace-context-application', deepcopy(old['formula']),
        support=deepcopy(old['support']), property_template=deepcopy(old['property_template']),
        quantified_parameters=deepcopy(old['quantified_parameters']), original_global_node_id=779,
        accepted_bounded_formula=deepcopy(selected['bounded_formula']),
        accepted_component_seal_sha256=exports['provenance']['seal_sha256'],
        accepted_source_application_sha256=exports['provenance']['source_dag_sha256'])
    proof.global_nodes['control'] = imported
    language.add([data['binding']['projected_control_definition'], data['binding']['scalar_invariant']])
    schema_ids = []
    def schema(name, at, base=False):
        mapping = {'a': c('A', at), 'b': c('A', '1' if base else c('+', at, '1')),
            'columns': c('COLUMNS', at)}
        original = data['binding']['goals'][name]
        out = proof.add('qualified-source-schema-uniform-instance', SUB(original, mapping),
            original_query_goal=deepcopy(original), uniform_mapping=mapping,
            original_query_sha256=data['plan']['queries'][name]['sha256'],
            accepted_result_review_sha256=data['raw_pins']['review'])
        schema_ids.append(out)
        return out
    base_rule = schema('engine-job-exponent-reset-base', '1', True)
    base = proof.mp(base_rule, proof.conjunction([
        proof.source(c('|core_workflow_control_h|', c('A', '1'))),
        proof.source(['not', c('|core_workflow_control_n reset_n|', c('A', '1'))])]))
    template = c('eexp-I', c('A', '@index'))
    bound = proof.open_index(FAMILY, INDEX)
    ih = proof.add('scoped-induction-hypothesis', SUB(template, {'@index': INDEX}),
        [bound], support=['IH:' + FAMILY], scope=INDEX)
    control = proof.trace_instance('control', INDEX, {'watch': '0'})
    job, phase = (steps.part(proof, control, k) for k in [7, 8])
    phase_eq = steps.definition(proof, language, api, 'selected-row-phase-I',
        [c('A', INDEX), c('COLUMNS', INDEX), c('ROW', INDEX), c('HEADER', INDEX)])
    equation = proof.nodes[phase_eq]['formula']
    phase_body = proof.rewrite(phase, phase_eq, equation[1], equation[2])
    eight = [steps.part(proof, phase_body, k) for k in range(1, 9)]
    joined = proof.conjunction(eight)
    parent_eq = steps.definition(proof, language, api, 'eexp-source-parent-control', [c('A', INDEX)])
    equation = proof.nodes[parent_eq]['formula']
    assert proof.nodes[joined]['formula'] == equation[2]
    parent = proof.rewrite(joined, parent_eq, equation[2], equation[1])
    rule = schema('engine-job-exponent-preserve', INDEX)
    after = c('+', INDEX, '1')
    premise = proof.conjunction([proof.source(c('|core_workflow_control_h|', c('A', INDEX))),
        proof.source(c('|core_workflow_control_h|', c('A', after))),
        proof.source(c('|core_workflow_control_t|', c('A', INDEX), c('A', after))), job, parent, ih])
    step = proof.mp(rule, premise)
    final = api['close_factory'](proof)(FAMILY, template, base, step, INDEX, ih, [])
    assert not proof.active_indices and len(proof.nodes) <= 64
    assert proof.root_context == exports['context'] and set(proof.nodes[final]['support']) == set(exports['context'])
    return deepcopy({'kind': 'ordinary-original-active-E-J-exponent-induction', 'nodes': proof.nodes,
        'global_nodes': proof.global_nodes, 'global_node': final, 'root_context': proof.root_context,
        'control_import': imported, 'control_instance': control, 'job_projection': job, 'phase_projection': phase,
        'phase_definition': phase_eq, 'unfolded_phase': phase_body, 'eight_projection_parents': eight,
        'eight_conjunction': joined, 'projected_control_definition': parent_eq, 'projected_control_parent': parent,
        'base_parent': base, 'step_parent': step, 'IH_parent': ih, 'schema_nodes': schema_ids,
        'new_native_jobs': 0, 'original_R0_or_UID_application_proved': False,
        'read_metadata_postscale_selector_join_proved': False, 'whole_device_theorem': False})

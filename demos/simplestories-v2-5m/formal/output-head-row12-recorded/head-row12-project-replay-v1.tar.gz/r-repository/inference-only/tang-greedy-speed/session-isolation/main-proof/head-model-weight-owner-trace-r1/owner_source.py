if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CANON=ROOT/'head-model-weight-canonical-trace-r1'
sys.path.insert(0,str(HERE))
import r3_library
sys.path.insert(0,str(CANON))
import edge_ledger_application
from row_terms import *
from support import atoms,smt,parse_spans
from boolean_application import SourceLanguage
sha=lambda b:hashlib.sha256(b).hexdigest()
rd=lambda p:json.loads(p.read_bytes())


def semantic(x):
    if isinstance(x,dict):return {k:semantic(v) for k,v in x.items() if k not in ['fresh_replay_read_pins','actual_pairing_read_pins']}
    return [semantic(v) for v in x] if isinstance(x,list) else x


def language(lib):
    result=SourceLanguage()
    result.add([f for f,_,_ in parse_spans((CANON/'EDGE-LEDGER-TYPING-ONLY.smt2').read_bytes())])
    native=(ROOT/'rmsnorm-pilot/model-consumption/connected/native.smt2').read_bytes()
    assert sha(native)=='c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
    result.add([f for f,_,_ in parse_spans(native)])
    f=lib['app']['uniform_F_actual_definition']
    expected=['declare-fun','admitted-product',[['_','BitVec','16'],['_','BitVec','10']],'Int']
    assert result.decls.pop('admitted-product')==expected
    assert 'admitted-product' not in result.defs
    # Every inherited formula/observer is interpreted in this ONE new theory.
    # No native function refers to the ghost F; all old UF theorems are uniform
    # and remain valid under this typed choice. Receipts stay unchanged.
    assert not any('admitted-product' in atoms(d[4]) for name,d in result.defs.items()
                   if name.startswith('|core_workflow_control'))
    result.add(lib['app']['reference_schema_definitions_match'])
    assert result.defs['admitted-product']==f
    result.add([lib['phase']['source_view'],lib['phase']['phase_invariant'],
                lib['phase']['literal_step'],lib['native']['literal_step']])
    return result


def derive(proof,target,parents):
    """Finite conjunction introduction/elimination and modus ponens only."""
    facts={};clauses=[]
    def register(i):
        f=proof.nodes[i]['formula'];key=smt(f)
        if key in facts:return
        facts[key]=i
        if isinstance(f,list) and f and f[0]=='and':
            for j,t in enumerate(f[1:],1):
                child=proof.add('conjunction-elimination',t,[i],conjunction_index=j)
                register(child)
        elif isinstance(f,list) and f and f[0]=='=>':clauses.append(i)
    for parent in parents:register(parent)
    def obtain(f):
        key=smt(f)
        if key in facts:return facts[key]
        if f=='true':
            i=proof.add('literal-Boolean-true','true');register(i);return i
        if isinstance(f,list) and f and f[0]=='and':
            children=[obtain(t) for t in f[1:]]
            if all(i is not None for i in children):
                i=proof.conjunction(children);register(i);return i
        return None
    while True:
        wanted=obtain(target)
        if wanted is not None:return wanted
        old=len(facts)
        for clause in list(clauses):
            f=proof.nodes[clause]['formula'];antecedent=obtain(f[1])
            if antecedent is not None:register(proof.mp(clause,antecedent))
        if len(facts)==old:raise AssertionError(('Undischarged source premise',target))


def construct():
    seal=ROOT/'HEAD-MODEL-WEIGHT-CANONICAL-TRACE-R1-SEALED.json'
    assert sha(seal.read_bytes())=='68fe78ba88ef79b29ffaeff7381bda57f7cee78845da09bc1db7e63196a48bbe'
    for file_name,digest in rd(seal)['files'].items():assert sha((CANON/file_name).read_bytes())==digest,file_name
    proof,parent_binding=edge_ledger_application.construct()
    parent=rd(CANON/'EDGE-LEDGER-APPLICATION-DRAFT.json')
    assert semantic(proof.nodes)==semantic(parent['nodes']) and proof.global_nodes==parent['global_nodes']
    lib=r3_library.load();lang=language(lib)
    ab,pb,nb,rb=lib['app'],lib['phase'],lib['native'],lib['reference']
    statements={'numeric-reset':ab['shared_common_reset_base'],'numeric-step':ab['actual_numeric_next'],
        'native-kernel':nb['native_goal'],'phase-consequence':ab['prior_engine_goal_instances'][1],
        'reference-induction':ab['prior_engine_goal_instances'][2]}
    statements.update({'word-'+str(i):row['goal'] for i,row in enumerate(ab['pure_word_instances'][:3])})
    def qualified(name,mapping):
        assert name in statements
        f=SUB(statements[name],mapping)
        return proof.add('qualified-R3-source-or-library-uniform-instance',f,
            qualified_R3_seal_sha256='fc55ead5aecaa9af9da29b2b228849e300624667e163e4d9432ee0f7c16a2d84',
            source_statement_name=name,source_statement=statements[name],uniform_mapping=mapping,
            reconstruction_adapter=lib['replay_adapter'])
    def source_step(index,invariant):
        nxt=c('+',index,'1')
        mapping={'a':c('A',index),'b':c('A',nxt),'columns':c('COLUMNS',index),
            'row':c('ROW',index),'header':c('HEADER',index)}
        controller=proof.trace_instance('control',index,{'watch':'0'})
        h=proof.source(c('|core_workflow_control_h|',c('A',index)))
        transition=proof.source(c('|core_workflow_control_t|',c('A',index),c('A',nxt)))
        weakening=lang.native_weakening('|core_workflow_control_t|','row-phase-native-step')
        weakening=SUB(weakening,dict(zip([x[0] for x in lang.defs['row-phase-native-step'][2]],
                                         [c('A',index),c('A',nxt)])))
        weak=proof.add('literal-full-native-transition-weakening',weakening,
            full_definition=lang.defs['|core_workflow_control_t|'],subset_definition=lang.defs['row-phase-native-step'])
        row_transition=proof.mp(weak,transition)
        imports=[qualified(name,mapping) for name in ['native-kernel','phase-consequence','reference-induction','word-0','word-1','word-2']]
        theorem=qualified('numeric-step',mapping)
        f=proof.nodes[theorem]['formula']
        premise=derive(proof,f[1],[controller,h,row_transition,invariant,*imports])
        result=proof.mp(theorem,premise)
        return result,{'mapping':mapping,'premise':premise,'source_result':result,'kernel_instance':imports[0]}

    base_map={'a':c('A','0'),'b':c('A','1')}
    controller=proof.trace_instance('control','1',{'watch':'0'})
    cz=proof.control_definition('columns','1');eqc=proof.nodes[cz]['formula']
    controller=proof.rewrite(controller,cz,eqc[1],eqc[2])
    theorem=qualified('numeric-reset',base_map)
    source=[proof.source(c('|core_workflow_control_i|',c('A','0'))),
        proof.source(c('|core_workflow_control_h|',c('A','0'))),
        proof.source(c('|core_workflow_control_h|',c('A','1'))),
        proof.source(c('|core_workflow_control_t|',c('A','0'),c('A','1'))),
        proof.source(NOT(n('reset_n',c('A','0')))),qualified('native-kernel',base_map),controller]
    premise=derive(proof,proof.nodes[theorem]['formula'][1],source)
    base=proof.mp(theorem,premise)
    rz=proof.control_definition('row','1');eqr=proof.nodes[rz]['formula']
    base=proof.rewrite(base,rz,eqr[2],eqr[1]);base=proof.rewrite(base,cz,eqc[2],eqc[1])
    name='row-numeric';index='n_row_numeric'
    template=c('selected-row-I',c('ROW','@index'),c('row-source-view',c('A','@index'),c('COLUMNS','@index')))
    bound=proof.open_index(name,index)
    ih=proof.add('scoped-induction-hypothesis',SUB(template,{'@index':index}),[bound],support=['IH:'+name],scope=index)
    step,step_binding=source_step(index,ih)
    target=SUB(template,{'@index':c('+',index,'1')})
    # R3's conclusion uses literal observer-next expressions. Fold only the
    # existing recurrences; do not zero or rebase any history.
    current=proof.nodes[step]['formula'][-1]
    row_next=proof.add('conjunction-elimination',current,[step],conjunction_index=len(proof.nodes[step]['formula'])-1)
    for which in ['row','columns']:
        definition=proof.control_definition(which,index,True);f=proof.nodes[definition]['formula']
        row_next=proof.rewrite(row_next,definition,f[2],f[1])
    assert proof.nodes[row_next]['formula']==target
    row_global=proof.close_induction(name,template,base,row_next,index,ih)
    del proof.active_indices[index]

    name='row-numeric-edge';index='n_row_edge'
    proof.open_index(name,index)
    current=proof.trace_instance('row-numeric',index)
    edge,edge_binding=source_step(index,current)
    # Keep all three outputs: input cut, actual integer word laws and next-I.
    # Later product/commit projections use the PRE-edge row and these laws.
    edge_template=SUB(proof.nodes[edge]['formula'],{index:'@index'})
    edge_global=proof.globalize(name,edge_template,edge,index,[])
    assert not proof.active_indices
    for i,node in enumerate(proof.nodes):
        inherited=set(node['introduced_support'])
        for parent in node['parents']:
            assert parent<i;inherited.update(proof.nodes[parent]['support'])
        inherited-=set(node.get('discharged_support',[]))
        assert inherited==set(node['support']),(i,'support')
    return proof,lang,lib,{'parent_application':parent_binding,
        'whole_theory_F_specialization':{'old_declaration':expected_F_declaration(),
            'chosen_total_definition':ab['uniform_F_actual_definition'],
            'all_inherited_schemas_interpreted_uniformly':True,
            'all_current_ROW_zero_next_prefix_owner_definitions_share_this_binding':True,
            'native_functions_independent_of_F':True,'new_environment_premise':False},
        'direct_A0_A1_base_node':base,'row_numeric_schema':proof.nodes[row_global],
        'induction_step_application':step_binding,'numeric_edge_application':edge_binding,
        'row_numeric_edge_schema':proof.nodes[edge_global],
        'finite_prefix_export_still_required':True,'valid_product_commit_projection_still_required':True,
        'source_theorem_qualified':False,'new_engine_jobs':0,'whole_device_theorem':False}


def expected_F_declaration():
    return ['declare-fun','admitted-product',[['_','BitVec','16'],['_','BitVec','10']],'Int']


def assemble():
    proof,lang,lib,binding=construct()
    import typed_source
    B=lambda n:['_','BitVec',str(n)]
    roots=[n['formula'][2] if n['formula'][0]=='forall' else n['formula'] for n in proof.nodes]
    variables=[('slot',B(5)),('u',B(18)),('watch','Int'),('initial-tape',['Array','Int',B(256)]),
        ('empty-a',['Array','Int',B(16)]),('empty-w',['Array','Int',B(10)]),('empty-prefix',['Array','Int','Int']),
        ('model',['Array',B(18),B(256)]),*[(n,'Int') for n in proof.index_bindings],('n_memory','Int')]
    specimen,typed=typed_source.build(lang,roots,variables,['|core_workflow_control_s|','|board1_verified_ddr_page_service_s|'])
    return {'nodes':proof.nodes,'global_nodes':proof.global_nodes,'binding':binding,
        'source_typing':typed,'typing_specimen':specimen.decode(),
        'qualified_R3_fresh_replay':lib['qualified_replay'],'qualified_R3_import_adapter':lib['replay_adapter'],
        'source_supports':proof.nodes[proof.global_nodes['row-numeric']]['support'],
        'new_engine_jobs':0,'source_theorem_qualified':False,'whole_device_theorem':False}


if __name__=='__main__':
    result=assemble();specimen=result.pop('typing_specimen')
    (HERE/'OWNER-SOURCE-TYPING-ONLY.smt2').write_text('; Typing only; not an engine result.\n'+specimen)
    (HERE/'OWNER-SOURCE-APPLICATION-DRAFT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'nodes':len(result['nodes']),'globals':list(result['global_nodes']),
        'typing':result['source_typing'],'source_qualified':False,'new_engines':0}))

# Independent saved-FRAME/head-owner result review

**Decision: ACCEPTED. All three exact queries returned clean UNSAT on their
first recorded attempts.** This accepts the relation's base/preservation and
the conditional clock/saved-exponent consequence, with their execution
evidence. The ordinary typed original-prefix application and exact saved-R0/
row application remain open. No score or selector admission is qualified.

The exact freeze is
`deae770873beabfee2d1de9f8cd33097160a370cedac8a0979178892603a6d69`,
acceptance record
`478de3617188bb5e1d5cb8be2e6ce85ce47e803b153f6af2f9e4cfd9f805421f`,
and input review
`2612d1dd2bcf4b0d78ecf83d83d0e9a2ba8928e3b518041e2635160be9b46e59`.
Complete `RESULTS.json` is
`1d0fd144e30c19630bd34130645b88f0a0c589efecf98d06fe7bd6c51af10307`;
intent is `2f8f472ac1acc1e27566fa698316cefa5f6cef7b03b530d6447977234bbad648`.
All thirteen local inputs, sixty external pins and fourteen preparation reads
still match actual bytes. No existing frozen or sealed input, result,
receipt, review or producer flag was changed by this review.

## Exact raw results and ordering

I independently inspected every raw log, STARTED/FINISHED receipt, monitor,
checked result and complete observation journal. Each per-run checked result
equals its aggregate row, and its receipt/monitor copies equal the actual
saved records. Query hashes, names, order, tool, intent, argv and cwd agree
with the accepted freeze and plan. All queries retain the reviewed c070
native prefix and exact single-goal tails, with all 452 T clauses unchanged.

| Job | Native wall seconds | Raw-log SHA256 |
| --- | ---: | --- |
| frame-head-owner-base | 0.403895 | `4819136fe5ea13123d443348944e79f5ac80ef5b544fd4105639eb49ea1db999` |
| frame-head-owner-preserve | 0.772842 | `89d5d41fea1eaa3b0da69b191ff37a10098021ba80aaa786dcdde56e236a7459` |
| owner-clock-and-saved-exponent | 0.407704 | `e2dd5e5c68421cdda50a22f8f739fa3638cfd5fc00c2f586dc51aad04497ff7c` |

Each complete raw protocol is UNSAT followed by exactly one nonempty
statistics list with unique keys and finite nonnegative values. No errors,
extra answers or observations occur. Base has five statistics and no
`:num-checks` field; its frozen query contains one check. Preservation has
34 statistics and the combined consequence has 25; both report
`:num-checks 1`. No missing statistic is invented. Actual log bytes, lengths
and hashes match their receipts and aggregate records.

The actual pinned binary remains
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`,
with `-smt2 -st -memory:4096` and the corresponding absolute query. The runs
inventory is exactly three single-use directories and three corresponding
journals; each directory has exactly STARTED, FINISHED, MONITOR-BINDING,
CHECKED-RESULT and NATIVE.log. Recorded start times follow the preceding
finish. No retry, diagnostic or fourth job occurs in this batch.

## Resource receipts and recorded cleanup

Every native exit and raw wait status is zero. No monitor error or resource
stop is recorded. STARTED records specify one process, 4 GiB, unchanged
environment, no wall/CPU limits and zero disk floor. Every admission and
actual pressure observation is normal Darwin pressure1. Journal hashes agree
with their actual files and monitor bindings.

There are eight, fourteen and eight group observations respectively, matching
each monitor count and the guard's loop count plus final survivor observation.
All observed group members are the corresponding single leader with a stable
start identity. I recomputed every member aggregate and recorded peak.
Maximum sampled RSS is 264,142,848 bytes; maximum sampled physical footprint
is 259,342,984 bytes; maximum wait4 RSS is 264,323,072 bytes. All are below
4 GiB. Total native wall time is 1.584441 seconds.

Each final group observation is empty. The accepted guard records FINISHED
after wait4; clean receipts and final empty observations support recorded
reaping/cleanup. I performed no live-process inspection or process controls
and make no host-wide memory guarantee. No engine, probe, simulation, build,
old checker/writer, proof constructor or additional agent ran during this
read-only review. Complete validation tool results were retained.

## Accepted formula scope and remaining application

The new hf-I remains one nondriving relation on existing HS, FRAME and CERT.
Under actual J-live/job7/FRAME-active/CERT-valid, it establishes valid HS and
six-field protected equality of HS.nf and CERT.nf. It adds no observer,
desired exponent or successful future. The base uses original frame-zero and
frc-zero under H/reset-low with arbitrary data.

Preservation uses both H endpoints, full native T, independently qualified
current/successor frame-I and hs-I, original current frc-I and current hf-I.
The next records are the literal source/observer recurrences. No successor
frc-I, desired protected equality or healthy-successor premise is inserted.
Next columns and JobHistory remain arbitrary provider arguments. The native
phase/control restriction against unrelated HS rebirth while the same head
FRAME remains active is proved under those premises. New begin/drop revokes
CERT; first effective head write captures NF; subsequent hold preserves the
original saved record, including after FRAME completion.

The saved-exponent consequence uses the actual current FrameJoinView guard,
frame phase identity, hs-I and hf-I to relate both physical D/J exponent
registers to CERT.nf.exp. It assumes neither desired register equality nor
current NF=CERT.nf after completion. The clock implication derives
`nf-t+1=n` and the actual/generic-next identity from `nf-t=n-1`; it does not
prove or introduce that premise as a new trace assumption.

The generic `fj-capture-record-at` declaration still requires one uniform
checked realization by the qualified actual source function before the
typed frc-I application. It cannot be chosen per word/stamp or desired NF.
The original independent NF clock, HS/FRAME/CERT providers, actual recurrences,
reset samples, state/edge domains and derived historical bounds must all be
supplied in the typed prefix. Protected-field equality excludes advancing
clock/count/activity/validity fields; whole-NF cross-time equality and later
current-NF replacement are not licensed substitutes for the original record.

The current guard describes this local component's authority. It does not
hide or qualify a physical selector admission outside that guard. First-fault
fire divergence, cancellation classification and retained output provenance
remain explicit downstream obligations. Upstream numerical RMS, registered
dot read, fixed-image metadata, postscale, held score and actual restored-
selector admission remain open.

Ten first-attempt native jobs are now recorded across the three reviewed
batches, without diagnostics or retries. The additive budget clarification
permits later exact reviewed batches; job counts are not theorem credit.
Recorded broader-qualification and pending-review flags retain their original
values. This review accepts only these three leaves and their execution,
without changing the whole-device or public qualification boundary.

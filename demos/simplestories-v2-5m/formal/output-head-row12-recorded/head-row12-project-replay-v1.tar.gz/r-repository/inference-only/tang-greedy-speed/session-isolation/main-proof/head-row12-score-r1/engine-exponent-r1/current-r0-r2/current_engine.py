"""Actual current E/head exponent from the original saved RMS record."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json
FAMILY = 'current-active-head-E-original-saved-RMS-exponent'
I = 'i_active_head_engine_exponent'
CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
digest = lambda value: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
J = 'u_native.u_six_layers.u_datapath.u_projection.'
E = J + 'u_shared_engine.u_engine.'


def prepare_metadata(exports, data, pins, forms):
    assert pins['saved_seal'] == '33c28d7d23908b2c11340e2d88a9dc13d8df4f06f3e7081fa63a80a8fd184946'
    for name, relative in [('saved_application', 'exponent-consequence-r1/CONSEQUENCE-R1.json'),
            ('saved_typing', 'exponent-consequence-r1/CONSEQUENCE-R1-TYPING-ONLY.smt2'),
            ('saved_review', 'exponent-consequence-r1/RESULT-REVIEW.md')]:
        assert data['saved_seal']['files'][relative] == pins[name]
    assert pins['saved_application'] == 'a48ed06117e4400a38d6d9e4dd047aeaef1203fc2098a7906565f25cd7db5671'
    assert pins['engine_application'] == 'fc1867e8449280cbc0b19ca7e7a4cea4d641f8041a7f4daf8cdbb905b868e2a3'
    assert pins['engine_review'] == '53d976e38586098499151d51bf25556503cf106b75ca809602e820b914c6a688'
    saved, engine = (data[k] for k in ['saved_application', 'engine_application'])
    context = exports['prefix_artifact']['inherited_prefix_source_context']
    assert digest(context) == CONTEXT_SHA
    assert saved['application']['root_context'] == engine['prefix']['bounded_source_context'] == context
    assert engine['prefix']['bounded_source_context_sha256'] == CONTEXT_SHA
    assert engine['prefix']['prefix_bound_domain'] == ['<=', '1', 'N']
    assert engine['prefix']['source_supports'] == engine['application']['nodes'][30]['support']
    assert len(engine['application']['nodes']) == 31 and engine['application']['global_node'] == 30
    assert engine['type_check']['assertions'] == 32
    assert saved['application']['current']['global_node'] == 50
    assert saved['application']['current']['literal_global_formula'] == saved['application']['nodes'][50]['formula']
    assert data['binding']['native_sha256'] == exports['context']['Gamma:actual-composed-source']['native_core_sha256']
    definitions = {f[1]: f for f in forms if f[0] == 'define-fun'}
    assert definitions['eexp-I'] == data['binding']['scalar_invariant']
    assert definitions['selected-row-phase-I'] == data['binding']['original_phase_invariant']
    assert definitions['current-job-I'] == data['binding']['original_current_job_invariant']
    assert set(exports['selectedglobals']) == {'control', 'actual-capture', 'actual-frame'}
    return deepcopy({'context': context, 'pins': pins})


def construct(proof, language, exports, data, prepared, steps, fixed):
    api = exports['apis']
    class Application(fixed.FixedApplication):
        def __init__(self):
            self.proof, self.language, self.api, self.steps = proof, language, api, steps
            self.c, self.EQ, self.SUB = (api[k] for k in ['c', 'eq', 'SUB'])
            self.context = deepcopy(prepared['context'])
            self.imports, self.lookup_ledger = {}, []
            assert proof.root_context == self.context and not proof.nodes and not proof.active_indices

        def run(self):
            p, c = self.proof, self.c
            domain = ['<=', '1', 'N']
            parents = {}
            for name in ['control', 'actual-capture', 'actual-frame']:
                selected = exports['selectedglobals'][name]
                parents[name] = self.import_fixed('qualified-original-' + name,
                    ['=>', domain, selected['bounded_formula']], selected['node']['support'],
                    {'seal': exports['provenance']['seal_sha256'], 'node': selected['node_id'],
                     'source_application': exports['provenance']['source_dag_sha256']})
            engine = self.import_fixed('qualified-original-bounded-E-J-exponent',
                ['=>', domain, data['engine_application']['prefix']['bounded_formula']],
                data['engine_application']['prefix']['source_supports'],
                {k: prepared['pins'][k] for k in ['engine_application', 'engine_review']})
            saved = self.import_fixed('closed-current-FRAME-original-saved-RMS-exponent',
                data['saved_application']['application']['current']['literal_global_formula'], self.context,
                {k: prepared['pins'][k] for k in ['saved_seal', 'saved_application', 'saved_review']})
            lower = p.open_index(FAMILY, I)
            s = c('A', I)
            native = lambda path: c('|core_workflow_control_n ' + path + '|', s)
            scalar_body = self.SUB(data['binding']['scalar_invariant'][4], {'s': s})
            live_formula, active_formula = scalar_body[1][1:]
            head_formula = ['=', native(J + 'job_q'), ['_', 'bv7', '4']]
            guard = ['and', live_formula, head_formula, active_formula]
            case = p.assumption('CASE:actual-active-head-engine', ['and', domain, ['<=', I, 'N'], guard])
            domain_p, upper, owned = [self.part(case, k) for k in [1, 2, 3]]
            live, head, active_e = [self.part(owned, k) for k in [1, 2, 3]]
            reset, no_fail = self.part(live, 1), self.part(live, 3)
            def at(name, parameters=None):
                return self.bounded_instance(p.mp(parents[name], domain_p), I, lower, upper, parameters)
            control = at('control', {'watch': '0'})
            phase = self.part(control, 8)
            phase = self.unfold(phase, 'selected-row-phase-I', [s, c('COLUMNS', I), c('ROW', I), c('HEADER', I)], [lower, upper])
            active_owner = p.mp(self.part(phase, 3), p.conjunction([live, active_e]))
            running = self.part(active_owner, 1)
            assert p.nodes[running]['formula'] == ['=', native(J + 'state_q'), ['_', 'bv3', '3']]
            frame = at('actual-frame', {'frame-watch': ['_', 'bv0', '10']})
            frame = self.unfold(frame, 'frame-I', [s, c('COLUMNS', I), c('c-base', c('CAPTURE', I)), c('FRAME', I), ['_', 'bv0', '10']], [lower, upper])
            frame_live = p.mp(self.part(frame, 2), live)
            active_eq = self.part(frame_live, 1)
            choices = p.nodes[active_eq]['formula'][2]
            frame_active = self.or_intro(running, choices[1:])
            frame_active = p.rewrite(frame_active, active_eq, choices, c('f-active', c('FRAME', I)))
            frame_properties = p.mp(self.part(frame_live, 2), frame_active)
            complete_eq = self.part(frame_properties, 7)
            capture = at('actual-capture')
            capture = self.unfold(capture, 'capture-inv', [s, c('CAPTURE', I)], [lower, upper])
            capture_payload = p.mp(self.part(capture, 2), reset)
            job = self.unfold(self.part(capture_payload, 1), 'capture-clause-0', [s, c('CAPTURE', I)], [lower, upper])
            job = self.unfold(job, 'job-inv', [s, c('c-base', c('CAPTURE', I))], [lower, upper])
            job_payload = p.mp(self.part(job, 2), reset)
            complete_rule = self.part(job_payload, 4)
            choices = p.nodes[complete_rule]['formula'][1][1]
            job_running = self.or_intro(running, choices[1:])
            job_complete = self.part(p.mp(complete_rule, p.conjunction([job_running, no_fail])), 2)
            equation = p.nodes[complete_eq]['formula']
            frame_complete = p.rewrite(job_complete, complete_eq, equation[2], equation[1])
            aliases = [self.view_field_alias(I, field, lower, upper) for field in ['live', 'head']]
            view_live, view_head = [p.rewrite(value, alias, p.nodes[alias]['formula'][2], p.nodes[alias]['formula'][1])
                for value, alias in zip([live, head], aliases)]
            saved_guard = p.conjunction([view_live, view_head, frame_active, frame_complete])
            saved_rule = self.instantiate(saved, {'i_saved_head_exponent': I}, [lower, upper])
            saved_result = p.mp(p.mp(saved_rule, lower), p.conjunction([domain_p, upper, saved_guard]))
            j_exponent = self.part(self.part(saved_result, 1), 2)
            engine_I = self.bounded_instance(p.mp(engine, domain_p), I, lower, upper)
            engine_body = self.unfold(engine_I, 'eexp-I', [s], [lower, upper])
            e_j = p.mp(engine_body, p.conjunction([live, active_e]))
            equation = p.nodes[j_exponent]['formula']
            e_original = p.rewrite(e_j, j_exponent, equation[1], equation[2])
            assert p.nodes[e_original]['formula'] == ['=', native(E + 'activation_exponent_q'), c('nf-exp', c('endpoint-saved-NF', I))]
            result = p.conjunction([e_original, saved_result, frame_active, frame_complete])
            claim = p.implication(case, result)
            final = p.globalize(FAMILY, self.SUB(p.nodes[claim]['formula'], {I: '@index'}), claim, I, [])
            assert not p.active_indices and len(p.nodes) <= 160
            assert set(p.nodes[final]['support']) == set(self.context)
            return {'global_node': final, 'literal_global_formula': p.nodes[final]['formula'], 'guard': guard,
                'imports': deepcopy(self.imports), 'case_parent': case, 'lower_parent': lower, 'upper_parent': upper,
                'control_instance': control, 'active_owner_parent': active_owner, 'running_parent': running,
                'frame_active_parent': frame_active, 'capture_instance': capture, 'job_complete_parent': job_complete,
                'frame_complete_parent': frame_complete, 'saved_guard_parent': saved_guard,
                'saved_result_parent': saved_result, 'J_original_exponent_parent': j_exponent,
                'E_J_exponent_parent': e_j, 'E_original_exponent_parent': e_original, 'result_parent': result}
    app = Application()
    result = app.run()
    return deepcopy({'kind': 'actual-current-active-head-E-original-saved-RMS-exponent', 'current': result,
        'nodes': proof.nodes, 'global_nodes': proof.global_nodes, 'root_context': proof.root_context,
        'new_native_jobs': 0, 'new_inductions': 0, 'source_edges_requested': False,
        'historical_selected_row_R0_identity_proved': False, 'read_metadata_postscale_selector_join_proved': False,
        'whole_device_theorem': False})

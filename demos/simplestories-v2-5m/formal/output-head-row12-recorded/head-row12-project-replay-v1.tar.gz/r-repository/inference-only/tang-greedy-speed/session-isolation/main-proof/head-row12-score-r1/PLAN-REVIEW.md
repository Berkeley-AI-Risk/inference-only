# Independent same-row12 score-path plan review

**Decision: GO for the bounded Phase A preparation, with the constraints below.
This is not an engine launch gate or a proved exponent/score theorem.** The
plan gives a useful first deliverable and keeps the subsequent read, metadata,
postscale and restored-selector application behind another concrete reviewed
plan. No larger numerical or selector campaign is approved by this review.

Reviewed `PLAN.md` SHA256:
`cde11165039612eb5d842dc4d347dfef867308934edcecd4c533fbc74ca34443`.
The preceding STEP/RMS-to-row12 seal remains
`1cb5e7e60c98e691218b7228a60e1237afc5d0484d37861db718b63f523bf5a0`;
the native model remains
`c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54`.
I read the plan, current objective/main statement, project scope critique,
actual connected shell/datapath/projection source, original NF invariant and
protected-payload leaf, scaling reuse inventory, old engine trace and native
selector control statement. No preparation function, proof constructor,
engine, old checker/writer, build, simulation or new agent was invoked. Only
this additive review is written.

## First useful statement and provenance

The useful early result is an actual head-start exponent theorem on the same
original finite prefix: an effective D head-start at an established historical
observation captures the exponent of that observation's accepted, completed NF
record; the effective job7 descriptor birth receives the retained D exponent;
and the owner/protected-field relation connects this record to the exact saved
`R0=NF(k)` already used by the completed row12 theorem. A source-input equality
alone, or a theorem conditional on an arbitrary correct private exponent, does
not deliver that provenance.

Keep the actual head-start observation, UID, STEP parent, prefix and exponent
fixed before any word coordinate. Match actual recurrence and observation
conventions, including the original A0/A1 reset samples. Derive the needed
historical lower/upper bounds and strict ordering from the actual event record
before any `A(h)`, `NF(h)` or other history access. A capture edge requires its
defined-edge domain; a state-only endpoint may include the last state. Do not
assume historical `INDEX` membership, a head-start occurrence, future progress
or a current record equal to the saved record.

The original `nf-I` clauses 9 and 18 (one-based numbering) are conditional:
shell-live plus NF-active/nonzero-count yields the shell exponent equality;
D-live plus shell-live plus E_HEAD yields the D exponent equality. They do not
retain a head-start owner after shell failure. The existing protected NF leaf
preserves exactly data, exponent, RMS UID, RMS STEP-parent, STEP ID and prefix;
it excludes the clock, STEP validity, active flag and count. Whole NormFrame
equality across observations is therefore wrong.

In particular, that leaf requires J-live, JOB_LOAD, stored job7 and D E_HEAD.
It cannot alone bridge head-start to the effective job7 birth while J is still
IDLE, or a shell-fault interval outside its premise. The single proposed owner
invariant must explicitly cover those cases, or derive the exact phase
restriction that removes them. Its preservation query must establish the
protected-field link from actual source/observer updates, not assume it as a
same-record promise. If doing so requires a second owner/operator induction,
stop and report the gap under the stated budget.

## Source guards, physical retention and authority

The proposed event distinctions match the source and must survive query
construction literally:

- D head-start is the actual ready/valid event inside the reset-high,
  no-CLEAR, old-fault-absent E_IDLE update branch. H must discharge shell state,
  caller wiring and the full native ready expression. The ready expression
  includes model lock, child fault, stage-done/stage-valid, DDR ownership and
  projection/lookup busy conditions; it is not a free event input.
- A trailing upstream/child/lock fault can override the next D phase after the
  exponent write. Such a capture can establish historical payload without
  establishing continuing current authority. For source-visible successor
  register values, branch explicitly on successor reset and its zero mask.
  Do not filter the conclusion through successor health.
- J exponent capture is inside a valid incoming descriptor admission after
  upstream/fail/stream/engine-fault, CLEAR and protocol-error priorities.
  `start_transfer` or a retained stored job7 does not establish this birth.
  Bind the incoming job/layer and exponent to the actual D port mux and
  effective register enable. At later application, discharge that enable from
  owned actual history rather than add it as an environment guarantee.
- D/J hold statements retain their different physical update rules. D CLEAR
  zeros its exponent; J CLEAR does not rewrite its exponent payload. Current
  fault can leave payload retained. Historical payload truth, current owner
  validity and successful-use/publication authority must remain separate.

The new observer is nondriving. Its base/update must follow actual storage
priority, handle capture plus newly detected fault, and revoke current use on
reset/CLEAR/cancellation without granting stale work a new identity. If an
E_HEAD owner implication needs a live-shell phase qualifier, expose it
literally and prove the qualifier at the relevant owned birth/capture. Such a
qualifier must not suppress a real first-fault-edge selector admission later.

Current source identities use H. Sequential leaves keep both endpoint H and
the complete unchanged 452-conjunct T. An independently qualified successor
NF invariant is a valid acyclic provider only on its actual domain; replacing
the source transition or adding successful-future health is not equivalent.
Concrete record/event/IH formulas and exact parent/support applications remain
mandatory review items before any launch.

## Direction of the later composition

The forward target is appropriate: actual saved activations and fixed model,
then original completed row12 dot, then its synchronous read and matching
metadata, postscale tags/hold, and actual selector admission. Do not work
backward from an assumed correct score or choose an independently supplied
engine frame. Keep one fixed M and the original UID/episode and cancellation
conditions throughout.

The tile read is registered. Operand capture consumes the previous tile read
and old selected-tile/tag state even on an edge issuing row13. Prove low4 lane,
high2 tile, valid/advance and metadata identity through stalls; the later
current dot is not the row12 operand. Preserve the actual positive multiplier
and signed exponent-range checks. State the arithmetic using signed-integer
interpretations of the actual 50-bit score and 8-bit exponent, deriving
representability rather than replacing it with modular equality.

The inventory at SHA256
`335190571891851cdcaf60cd73cdc99a29e7e70687099679091ad25fc6f9adde`
identifies reusable candidates, not their actual c070 applications. The old
split-multiply-recombine aggregate remains false. Only separately accepted
leaves/word derivations may be imported after literal instance, port, clock,
reset, macro, parameter and premise checks. Never invoke the old writing or
compiling check/verify entrypoints. The row12/13 reset-founded example remains
engine-interface sensitivity with supplied inputs; its known numbers are not
premises that the parent consumed those values.

The restored selector has a distinct state sort. A checked actual-instance
projection/total realization or independently qualified contract must bind its
actual valid, ready, score, exponent, index and LAST ports. Sort renaming or a
free child reply cannot do this. Handle actual selector fire separately from
shell `head_result_transfer`: on a first fault edge they can differ. A physical
admission must receive its retained tuple/owner proof or an explicit proved
cancellation/absence-of-current-authority classification. Conditioning away
that edge with shell health would leave the requested boundary uncovered.
The selector source contract is the next explicit prerequisite if it cannot be
transferred from the existing parent theorem. No production gate may change.

Retain the already exported literal `D(S,M,256)` plus all-word S/R0 identity
until an ordinary checked substitution/array-lift argument establishes another
formula. Neither readable expansion of the sum nor typed positive formulas
alone supply that proof. Upstream numerical final-RMS/layer5 meaning and the
remaining rows, winner/publication and whole-device theorem stay open.

## Budget, stop and project relevance

The eight-job bound is coherent only as four source capture/hold leaves, two
owner base/preservation jobs, at most one combined generic zero/step job if
needed, and one assertion-identical diagnostic for the first unexpected SAT.
No item is an expandable family of jobs. Maintain one owned sequential worker,
4 GiB sampled RSS/footprint, actual normal pressure and internal memory4096,
with the accepted guard/probe receipts. No new probes, time/CPU/token kill,
fixed RAM floor, compile, simulation, board or public action is authorized.

An unexpected SAT/error/unknown/resource stop halts the affected chain. The
single diagnostic may expose the same assertion's typed observations; it is
not a repair, retry or continuation credit. Any source-justified revision
requires new exact review and an additive version. Unsupported transfer,
reset/record mismatch, out-of-prefix access or another induction triggers the
same stop. Preserve raw evidence, partial scopes/DAG and actual read/helper
pins. Query count does not excuse weakening the theorem to fit the budget.

This direction addresses the project critique at a concrete producer-to-
consumer seam rather than adding isolated component credit: it links the
already checked row to the usable admitted score. The new owner record is
justified only by the demonstrated historical exponent gap and should use the
existing proof/replay framework. Seal/report a checked early exponent/read
result when available, with its exact source/application boundary, then
continue only under the promised concrete reviewed continuation plan. This
bounded step is not a baseline-confinement or main-theorem completion claim.

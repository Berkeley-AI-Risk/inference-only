if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,json
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import source_typecheck
from prepare_continuity import *


def build(language,roots,variables,sorts):
    definitions=language.defs;known=set(definitions)|set(language.decls)
    need=set().union(*(atoms(x) for x in roots))&known;todo=list(need)
    while todo:
        name=todo.pop()
        if name in definitions:
            more=(atoms(definitions[name][4])&known)-need;need|=more;todo+=list(more)
    emitted=set();ordered=[];active=set()
    def visit(name):
        if name not in definitions or name in emitted:return
        assert name not in active,('Recursive source definition',name)
        active.add(name)
        for child in sorted(atoms(definitions[name][4])&set(definitions)):visit(child)
        active.remove(name);emitted.add(name);ordered.append(definitions[name])
    for name in sorted(need):visit(name)
    assert len({name for name,_ in variables})==len(variables)
    forms=[*[['declare-sort',name,'0'] for name in sorts],*language.datatypes,
        *[value for name,value in language.decls.items() if name in need],*ordered,
        *[['declare-const',name,t] for name,t in variables],*[['assert',x] for x in roots],
        ['check-sat-using',['then','simplify','smt']],['exit']]
    raw=('\n'.join(map(smt,forms))+'\n').encode()
    return raw,source_typecheck.check(raw)


def variables(nodes):
    indices=set()
    for node in nodes:
        if node['kind']=='scoped-natural-index-domain':
            assert node['formula'][:2]==['<=','1'] and isinstance(node['formula'][2],str)
            indices.add(node['formula'][2])
    return [('slot',B(5)),('u',B(18)),('watch','Int'),('initial-tape',['Array','Int',B(256)]),
        ('empty-a',AA),('empty-w',WA),('empty-prefix',SA),('model',['Array',B(18),B(256)]),
        ('unused-frame',FA),('frame-watch',B(10)),('n_memory','Int'),('N','Int'),('n_prefix','Int'),
        *[(name,'Int') for name in sorted(indices)]]

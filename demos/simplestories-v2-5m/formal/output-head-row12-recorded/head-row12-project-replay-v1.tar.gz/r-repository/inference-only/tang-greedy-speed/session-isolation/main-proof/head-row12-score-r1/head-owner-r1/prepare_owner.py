"""Pure assembly of the single original head-exponent owner obligations."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
from contextlib import contextmanager
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
ROOT = C.parent
P = ROOT / 'head-mode-ownership-r1'
S = '|core_workflow_control_s|'
D = 'u_native.u_six_layers.u_datapath.'
J = D + 'u_projection.'
SH = 'u_native.u_token_shell.'
ORDER = ['head-owner-base', 'head-owner-preserve', 'head-owner-origin']
NATIVE_SHA = 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
READS = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
c = lambda name, *args: [name, *args]
AND = lambda *args: c('and', *args)
OR = lambda *args: c('or', *args)
EQ = lambda x, y: c('=', x, y)
NOT = lambda x: c('not', x)
IMP = lambda x, y: c('=>', x, y)
BV = lambda n, w: ['_', 'bv' + str(n), str(w)]
B = lambda w: ['_', 'BitVec', str(w)]


def read(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    assert READS.setdefault(str(path), digest(raw)) == digest(raw)
    return raw


@contextmanager
def helpers():
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        modules = []
        for name, expected in [
            ('support', '898af07523f801c69d9806fe878cc5863552edb78e288e616778de1de729d130'),
            ('source_typecheck', '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809')]:
            path = P / (name + '.py')
            raw = read(path)
            assert digest(raw) == expected
            module = types.ModuleType(name)
            module.__file__ = str(path)
            sys.modules[name] = module
            exec(compile(raw, str(path), 'exec'), module.__dict__)
            modules.append(module)
        yield modules
    finally:
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


def assemble():
    READS.clear()
    with helpers() as (parser, typing):
        raw = read(ROOT / 'rmsnorm-pilot/model-consumption/connected/native.smt2')
        assert digest(raw) == NATIVE_SHA
        native = [f for f, _, _ in parser.parse_spans(raw)]
        defs = {f[1]: f for f in native if f[0] == 'define-fun'}
        assert len(defs['|core_workflow_control_t|'][4]) - 1 == 452
        prior = read(C / 'SOURCE-BINDING.json')
        assert digest(prior) == '15a555d4e391e2d9c4d90f790321d6bf1fcd495ed5f622043b270ee7489c11b5'
        prior = json.loads(prior)
        nf_helpers = prior['NF_helpers']
        events = prior['source_event_definitions']
        assert [v[1] for v in events] == ['head-exponent-effective-capture',
            'job7-priority-error', 'job7-exponent-effective-capture', 'job-exponent-effective-capture']
        event_raw = read(ROOT / 'head-final-rms-frame-origin-r1/E_HEAD-accepted-RMS-to-frame-word.smt2')
        event_forms = [f for f, _, _ in parser.parse_spans(event_raw)]
        for f in nf_helpers:
            assert f in event_forms
        cert_path = P / 'frame-join-pilot/certificate-prefix-r1/CONSTRUCTION.json'
        cert_raw = read(cert_path)
        assert digest(cert_raw) == '0004bd2557a6cfa9cc6b331e649b3c9689ff81b961d3ad65e992b00a50213add'
        cert_defs = {f[1]: f for f in json.loads(cert_raw)['definitions'] if f[0] == 'define-fun'}
        protected = [cert_defs['fj-accepted-nf'], cert_defs['fj-protected-equal']]
        observations = {}
        def getter(path, state='s'):
            name = '|core_workflow_control_n ' + path + '|'
            assert name in defs and defs[name][2] == [['state', S]]
            observations[path] = {'literal_getter_definition': defs[name], 'sort': defs[name][3]}
            return c(name, state)
        ds = lambda path, state='s': getter(D + path, state)
        js = lambda path, state='s': getter(J + path, state)
        ss = lambda path, state='s': getter(SH + path, state)
        shell_live = AND(getter('reset_n'), ss('rst_n'), NOT(ss('clear_i')), NOT(ss('fail_closed_o')))
        d_live = AND(ds('rst_n'), NOT(ds('clear_i')), NOT(ds('range_fault_o')))
        j_live = AND(js('reset_n'), NOT(js('clear_i')), NOT(js('integrated_fail')))
        d_head = EQ(ds('engine_state_q'), BV(8, 4))
        head_phases = OR(*[EQ(ss('state_q'), BV(v, 5)) for v in range(17, 22)])
        j_head_active = AND(j_live, EQ(js('job_q'), BV(7, 4)),
            OR(*[EQ(js('state_q'), BV(v, 3)) for v in [1, 2, 3, 4]]))
        revoke = OR(NOT(ds('rst_n')), ds('clear_i'))
        owner_type = ['declare-datatypes', [], [['HeadExponentHistory',
            ['mkHeadExponentHistory', ['hs-valid', 'Bool'], ['hs-at', 'Int'], ['hs-nf', 'NormFrame']]]]]
        owner_zero = ['define-fun', 'hs-zero', [['empty', 'NormFrame']], 'HeadExponentHistory',
            c('mkHeadExponentHistory', 'false', '0', 'empty')]
        owner_next = ['define-fun', 'hs-next', [['s', S], ['nf', 'NormFrame'], ['h', 'HeadExponentHistory']],
            'HeadExponentHistory', ['ite', revoke,
                c('mkHeadExponentHistory', 'false', c('hs-at', 'h'), c('hs-nf', 'h')),
                ['ite', c('head-exponent-effective-capture', 's'),
                    c('mkHeadExponentHistory', 'true', c('+', c('nf-t', 'nf'), '1'), 'nf'), 'h']]]
        # All clauses form ONE nondriving owner/control invariant. Validity is
        # revoked by reset/CLEAR; fault-held payload is not new permission.
        clauses = [
            IMP(c('hs-valid', 'h'), c('fj-accepted-nf', c('hs-nf', 'h'))),
            IMP(AND(ds('rst_n'), NOT(ds('clear_i')), c('hs-valid', 'h')),
                EQ(ds('head_activation_exponent_q'), c('nf-exp', c('hs-nf', 'h')))),
            IMP(AND(d_live, d_head), AND(c('hs-valid', 'h'),
                c('fj-protected-equal', c('hs-nf', 'h'), 'nf'), IMP(shell_live, head_phases))),
            IMP(j_head_active, AND(d_head, c('hs-valid', 'h'),
                EQ(js('activation_exponent_q'), c('nf-exp', c('hs-nf', 'h')))))]
        owner_I = ['define-fun', 'hs-I', [['s', S], ['nf', 'NormFrame'], ['h', 'HeadExponentHistory']],
            'Bool', AND(*clauses)]
        # Generic finite-prefix origin. Two fixed unary functions are used
        # before any stamp/word choice; they will later be bound to the actual
        # capture event and actual same-prefix NF function.
        event_at = ['declare-fun', 'hs-event-at', ['Int'], 'Bool']
        record_at = ['declare-fun', 'hs-record-at', ['Int'], 'NormFrame']
        generic_next = ['define-fun', 'hs-generic-next', [['observation', 'Int'], ['nf', 'NormFrame'],
            ['h', 'HeadExponentHistory'], ['revoke', 'Bool'], ['capture', 'Bool']], 'HeadExponentHistory',
            ['ite', 'revoke', c('mkHeadExponentHistory', 'false', c('hs-at', 'h'), c('hs-nf', 'h')),
                ['ite', 'capture', c('mkHeadExponentHistory', 'true', 'observation', 'nf'), 'h']]]
        origin_body = IMP(c('hs-valid', 'h'), AND(c('<=', '1', c('hs-at', 'h')),
            c('<', c('hs-at', 'h'), 'observation'), c('hs-event-at', c('hs-at', 'h')),
            EQ(c('hs-nf', 'h'), c('hs-record-at', c('hs-at', 'h')))))
        origin_I = ['define-fun', 'hs-origin-I', [['h', 'HeadExponentHistory'], ['observation', 'Int']],
            'Bool', origin_body]
        owner_helpers = [owner_type, owner_zero, owner_next, owner_I,
            event_at, record_at, generic_next, origin_I]
        ha = c('|core_workflow_control_h|', 'a')
        hb = c('|core_workflow_control_h|', 'b')
        transition = c('|core_workflow_control_t|', 'a', 'b')
        nfb = c('nf-next', 'a', 'nf', 'empty')
        base = IMP(AND(ha, NOT(getter('reset_n', 'a'))), c('hs-I', 'a', 'nf', c('hs-zero', 'initial')))
        preserve = IMP(AND(ha, hb, transition, c('nf-I', 'a', 'nf', 'watch'),
            c('nf-I', 'b', nfb, 'watch'), c('hs-I', 'a', 'nf', 'history')),
            c('hs-I', 'b', nfb, c('hs-next', 'a', 'nf', 'history')))
        generic_origin_step = IMP(AND(c('<=', '1', 'observation'),
            c('hs-origin-I', 'history', 'observation'),
            EQ(c('hs-event-at', 'observation'), 'capture'), EQ(c('hs-record-at', 'observation'), 'nf')),
            c('hs-origin-I', c('hs-generic-next', 'observation', 'nf', 'history', 'revoke', 'capture'),
                c('+', 'observation', '1')))
        actual_revoke = OR(NOT(ds('rst_n', 'a')), ds('clear_i', 'a'))
        origin = AND(c('hs-origin-I', c('hs-zero', 'initial'), '1'), generic_origin_step,
            EQ(c('hs-next', 'a', 'nf', 'history'),
                c('hs-generic-next', c('+', c('nf-t', 'nf'), '1'), 'nf', 'history', actual_revoke,
                    c('head-exponent-effective-capture', 'a'))))
        goals = dict(zip(ORDER, [base, preserve, origin]))
        declarations = [['declare-const', name, sort] for name, sort in [
            ('a', S), ('b', S), ('nf', 'NormFrame'), ('history', 'HeadExponentHistory'),
            ('initial', 'NormFrame'), ('watch', B(8)), ('empty', ['Array', B(8), B(16)]),
            ('observation', 'Int'), ('revoke', 'Bool'), ('capture', 'Bool')]]
        queries, type_reports = {}, {}
        for name in ORDER:
            additions = [*nf_helpers, *events, *protected, *owner_helpers, *declarations,
                ['assert', NOT(goals[name])],
                ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            query = raw + ('\n' + '\n'.join(map(parser.smt, additions)) + '\n').encode()
            assert [f for f, _, _ in parser.parse_spans(query) if f[0] == 'assert'] == [['assert', NOT(goals[name])]]
            type_reports[name] = typing.check(query)
            queries[name] = query
        read(HERE / 'prepare_owner.py')
        binding = {'native_sha256': NATIVE_SHA, 'native_T_conjuncts': 452,
            'entire_native_prefix_retained': True, 'native_getter_bindings': observations,
            'NF_helpers': nf_helpers, 'source_event_definitions': events, 'protected_helpers': protected,
            'owner_helpers': owner_helpers, 'declarations': declarations, 'owner_clauses': clauses, 'goals': goals,
            'owner_reset_CLEAR_revoke': actual_revoke, 'successor_NF_is_independent_qualified_provider': True,
            'successor_health_assumed': False, 'owner_invariant_count': 1,
            'typed_prefix_application_or_saved_R0_join_proved': False,
            'metadata_postscale_selector_join_proved': False, 'new_native_jobs': 0}
        plan = {'scope': 'single-c070-head-exponent-owner-base-preserve-and-origin', 'order': ORDER,
            'queries': {name: {'sha256': digest(queries[name]), 'expected': 'unsat'} for name in ORDER},
            'maximum_native_jobs_this_gate': 3, 'diagnostic_launch_authorized_by_this_gate': False,
            'workers': 1, 'memory_cap_bytes': 4 * (1 << 30), 'new_native_jobs': 0,
            'time_or_CPU_kill_enabled': False, 'unexpected_result_stops_dependents': True}
        return queries, binding, plan, type_reports, dict(READS)


if __name__ == '__main__':
    queries, binding, plan, type_reports, pins = assemble()
    for name, raw in queries.items():
        with (HERE / (name + '.smt2')).open('xb') as output:
            output.write(raw)
    for name, value in [('SOURCE-BINDING.json', binding), ('QUERY-PLAN.json', plan),
                        ('TYPE-CHECK.json', type_reports), ('READ-PINS.json', pins)]:
        with (HERE / name).open('x') as output:
            output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_queries': list(queries), 'new_native_jobs': 0}))

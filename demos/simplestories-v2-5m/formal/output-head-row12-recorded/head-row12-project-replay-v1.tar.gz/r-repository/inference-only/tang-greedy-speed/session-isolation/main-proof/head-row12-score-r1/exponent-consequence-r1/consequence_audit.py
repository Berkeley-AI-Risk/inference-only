"""Restricted deduction/boundary audit for this saved-exponent application."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json
sub = lambda x, m: m.get(x, x) if isinstance(x, str) else [sub(t, m) for t in x]
digest = lambda v: hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def replace(x, a, b):
    return deepcopy(b) if x == a else x if isinstance(x, str) else [replace(t, a, b) for t in x]


def validate(application, data, prepared, forms, module):
    nodes, context = application['nodes'], application['root_context']
    assert digest(context) == module.CONTEXT_SHA
    assert application['new_native_jobs'] == application['new_inductions'] == 0
    assert len(nodes) <= 256
    domain = ['<=', '1', 'N']
    prefix = data['owner_application']['prefix']
    expected_imports = {
        'accepted-bounded-original-HS': (['=>', domain, prefix['families'][module.HS]['bounded_formula']], prefix['families'][module.HS]['root_support']),
        'accepted-bounded-original-HF': (['=>', domain, prefix['families'][module.HF]['bounded_formula']], prefix['families'][module.HF]['root_support']),
        'accepted-bounded-original-FRAME': (['=>', domain, data['dot_prefix']['earlier_bounded_consequences']['actual-frame']], context),
        'accepted-bounded-original-control': (['=>', domain, data['dot_prefix']['earlier_bounded_consequences']['control']], context),
        'accepted-current-FRAME-endpoint': (data['endpoint_application']['application']['literal_global_formula'], context),
        'accepted-original-STEP-RMS-row12': (prepared['old']['row_application']['literal_global_formula'], context)}
    defs = {f[1]: f for f in forms if f[0] == 'define-fun'}
    dtypes = [f for f in forms if f[0] == 'declare-datatypes']
    seen_imports = set()
    for i, n in enumerate(nodes):
        assert n['id'] == i and all(type(p) is int and 0 <= p < i for p in n['parents'])
        support = set(n['introduced_support'])
        for p in n['parents']:
            support.update(nodes[p]['support'])
        assert support - set(n.get('discharged_support', [])) == set(n['support'])
        f, k, ps = n['formula'], n['kind'], n['parents']
        if k == 'checked-fixed-component-context-application':
            expected, roots = expected_imports[n['component']]
            assert n['component'] not in seen_imports and not ps and f == expected
            assert set(n['support']) == set(roots) and n['exact_bounded_source_context_sha256'] == module.CONTEXT_SHA
            seen_imports.add(n['component'])
        elif k == 'conjunction-introduction':
            assert f == ['and', *[nodes[p]['formula'] for p in ps]]
        elif k == 'conjunction-elimination':
            assert len(ps) == 1
            whole = nodes[ps[0]]['formula']
            assert whole[0] == 'and' and 1 <= n['position'] < len(whole) and f == whole[n['position']]
        elif k == 'implication-elimination':
            assert len(ps) == 2 and nodes[ps[0]]['formula'] == ['=>', nodes[ps[1]]['formula'], f]
        elif k == 'typed-equality-context-substitution':
            assert len(ps) == 2
            source, eq = (nodes[p]['formula'] for p in ps)
            assert eq[0] == '=' and f in [replace(source, eq[1], eq[2]), replace(source, eq[2], eq[1])]
        elif k == 'literal-function-definition-instance':
            d = n['definition']
            assert not ps and d == defs[d[1]] and set(n['uniform_mapping']) == {a[0] for a in d[2]}
            assert f == ['=', [d[1], *[n['uniform_mapping'][a[0]] for a in d[2]]], sub(d[4], n['uniform_mapping'])]
        elif k == 'literal-datatype-constructor-selector':
            assert n['datatype'] in dtypes and not ps
            t = next(t for t in n['datatype'][2] if t[0] == n['datatype_name'])
            ctor = next(c for c in t[1:] if c[0] == n['constructor_name'])
            at = n['selector_position']
            assert 1 <= at < len(ctor) and ctor[at][0] == n['selector_name']
            assert f[0] == '=' and f[1][0] == n['selector_name'] and f[1][1][0] == ctor[0]
            assert len(f[1][1]) == len(ctor) and f[2] == f[1][1][at]
        elif k == 'fixed-typed-forall-elimination-preserving-domain':
            original = nodes[ps[0]]['formula']
            assert original == n['original_quantified_formula'] and original[0] == 'forall'
            assert set(n['uniform_mapping']) == {v[0] for v in original[1]}
            assert f == sub(original[2], n['uniform_mapping'])
        elif k == 'qualified-source-schema-uniform-instance':
            query = n['original_query_sha256']
            if query == data['frame_plan']['queries']['owner-clock-and-saved-exponent']['sha256']:
                goal = data['frame_binding']['goals']['owner-clock-and-saved-exponent']
                assert n['accepted_result_review_sha256'] == prepared['raw_pins']['frame_review']
                assert n['actual_record_function_definition'] == defs['fj-capture-record-at']
                assert n['original_record_function_declaration'] == ['declare-fun', 'fj-capture-record-at', ['Int'], 'FrameRmsCertificate']
                assert n['uniform_mapping']['a'] == ['A', module.I]
                assert n['uniform_mapping']['b'] == ['A', module.I]
                at = module.I
                expected_mapping = {'a': ['A', at], 'b': ['A', at], 'nf': ['NF', at], 'history': ['HS', at],
                    'columns': ['COLUMNS', at], 'next-columns': ['COLUMNS', at],
                    'job': ['c-base', ['CAPTURE', at]], 'next-job': ['c-base', ['CAPTURE', at]],
                    'frame': ['FRAME', at], 'certificate': ['CERT', at], 'watch-frame': ['_', 'bv0', '10'],
                    'watch': ['_', 'bv0', '8'], 'empty-frame': 'unused-frame', 'empty-nf': ['NFEMPTY', '0'],
                    'observation': at, 'hs-event-at': 'actual-hs-event-at', 'hs-record-at': 'NF', 'hs-origin-I': 'actual-hs-origin-I'}
                assert n['uniform_mapping'] == expected_mapping
            elif query == '6c28a54981eefd6e1746f6be37b96d7debdd8a99e7ca4bf5ad66687c6c97ccde':
                goal = data['row_guard_binding']['combined_goal']
                j = ['FRAMEORIGIN', module.N]
                assert n['uniform_mapping'] == {'a': ['A', j], 'columns': ['COLUMNS', j], 'row': ['ROW', j], 'header': ['HEADER', j]}
                assert n['accepted_raw_result_adjudication'] == data['row_guard_result']
                assert data['row_guard_result']['accepted'] and not data['row_guard_result']['original_wrapper_success_claimed']
            else:
                assert query == 'c7f7abeaf6645e15351877c73c5dfc419e33e7cb1742af514306391074c56a84'
                goal = data['math_binding']['goal']
                assert n['uniform_mapping'] == {'past': ['FRAMEORIGIN', module.N], 'current': module.N, 'bound': 'N'}
                assert n['accepted_math_seal_sha256'] == prepared['raw_pins']['math_seal']
            assert n['original_query_goal'] == goal and f == sub(goal, n['uniform_mapping'])
            assert n['introduced_support'] == []
        elif k == 'literal-integer-threshold-weakening':
            assert len(ps) == 1
            assert n['checked_numerals'] == [0, 1] and n['weaker_threshold'] == '0' and n['stronger_threshold'] == '1'
            assert f == ['<=', '0', nodes[ps[0]]['formula'][2]] and nodes[ps[0]]['formula'][0:2] == ['<=', '1']
        elif k == 'actual-bounded-source-context-consequence':
            assert not ps and f == context['Gamma:actual-composed-source']['formal_native_consequences'][2]
            assert n['support'] == ['Gamma:actual-composed-source']
            assert n['literal_context_field'] == 'formal_native_consequences[2]' and n['exact_bounded_context_sha256'] == module.CONTEXT_SHA
        elif k == 'disjunction-introduction':
            assert len(ps) == 1 and f[0] == 'or' and 1 <= n['selected_disjunct'] < len(f)
            assert f[n['selected_disjunct']] == nodes[ps[0]]['formula']
        elif k == 'scoped-natural-index-domain':
            family, at = (module.CURRENT, module.I) if n['scope'] == module.CURRENT else (module.ROW, module.N)
            assert n['scope'] == family and f == ['<=', '1', at] and not ps
            assert n['support'] == ['INDEX:' + family]
        elif k == 'scoped-case-assumption':
            assert not ps and n['support'] == [n['case_label']]
            assert f[0] == 'and' and f[1] == domain and f[2][0] == '<=' and f[2][2] == 'N'
        elif k == 'implication-introduction':
            assert len(ps) == 2 and nodes[ps[0]]['kind'] == 'scoped-case-assumption'
            assert f == ['=>', nodes[ps[0]]['formula'], nodes[ps[1]]['formula']]
            assert n['discharged_support'] == [nodes[ps[0]]['case_label']]
        elif k == 'uniform-trace-consequence':
            assert len(ps) == 2 and nodes[ps[1]]['kind'] == 'scoped-natural-index-domain'
            at = n['fresh_index']
            assert n['property_template'] == sub(nodes[ps[0]]['formula'], {at: '@index'})
            assert f == ['forall', [*n['quantified_parameters'], [at, 'Int']], ['=>', ['<=', '1', at], nodes[ps[0]]['formula']]]
            assert set(n['support']) <= set(context)
            assert n['discharged_support'] == nodes[ps[1]]['support']
        else:
            raise AssertionError(('Unreviewed consequence rule', i, k))
    assert seen_imports == set(expected_imports)
    current, row = application['current'], application['row']
    assert application['global_nodes'] == {module.CURRENT: current['global_node'], module.ROW: row['global_node']}
    assert current['literal_global_formula'] == nodes[current['global_node']]['formula']
    assert row['literal_global_formula'] == nodes[row['global_node']]['formula']
    assert nodes[current['global_node']]['fresh_index'] == module.I and nodes[current['global_node']]['quantified_parameters'] == []
    assert nodes[row['global_node']]['fresh_index'] == module.N and nodes[row['global_node']]['quantified_parameters'] == [[module.W, ['_', 'BitVec', '8']]]
    assert row['one_original_row_capture'] == ['FRAMEORIGIN', module.N]
    assert len(application['lookup_ledger']) == 1
    lookup = application['lookup_ledger'][0]
    j = ['FRAMEORIGIN', module.N]
    assert lookup['index'] == j and not lookup['source_edge_requested'] and not lookup['historical_INDEX_assumption']
    assert nodes[lookup['lower_parent']]['formula'] == ['<=', '1', j]
    assert nodes[lookup['strict_past_parent']]['formula'] == ['<', j, module.N]
    assert nodes[lookup['upper_parent']]['formula'] == ['<=', j, 'N']
    instantiated = nodes[lookup['current_exponent_instance_parent']]
    assert instantiated['kind'] == 'implication-elimination'
    current_conclusion = sub(current['literal_global_formula'][2][2][2], {module.I: j})
    assert instantiated['formula'] == current_conclusion
    assert nodes[lookup['actual_frame_guard_parent']]['formula'] == sub(current['guard'], {module.I: j})
    assert module.W not in api_atoms(nodes[:row['scalar_nodes_end_before_word'] + 1])
    return {'passed': True, 'bounded_source_context_sha256': module.CONTEXT_SHA,
        'prefix_bound_domain': domain, 'all_deduction_nodes_checked': len(nodes),
        'original_j_state_bounds_checked': True, 'new_historical_INDEX': False,
        'old_edge_family_used_as_state': False, 'all_word_choice_after_scalar_derivation': True,
        'new_native_jobs': 0, 'postscale_or_selector_score_proved': False}


def api_atoms(value):
    if isinstance(value, str):
        return {value}
    if isinstance(value, list):
        return set().union(*(api_atoms(x) for x in value)) if value else set()
    if isinstance(value, dict):
        return set().union(*(api_atoms(v) for v in value.values())) if value else set()
    return set()

if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,ast
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
from prepare_continuity import *


def logic():
    path=ROOT/'head-model-weight-owner-trace-r1/owner_source.py'
    assert sha(path.read_bytes())=='94d8666fb546dd84a181cdc71a22630965974322f889b422472d7882e3a05cd8'
    tree=ast.parse(path.read_bytes())
    function=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='derive')
    module=ast.Module(body=[function],type_ignores=[]);ast.fix_missing_locations(module)
    namespace={'smt':smt}
    exec(compile(module,str(path),'exec'),namespace)
    return namespace['derive']


derive=logic()


def definition(proof,language,name,args):
    source=language.defs[name];assert len(args)==len(source[2])
    mapping=dict(zip([x[0] for x in source[2]],args))
    call=c(name,*args);body=SUB(source[4],mapping)
    return proof.add('literal-function-definition-instance',eq(call,body),
        definition=source,uniform_mapping=mapping)


def unfold(proof,language,node,name,args):
    d=definition(proof,language,name,args);equal=proof.nodes[d]['formula']
    return proof.rewrite(node,d,equal[1],equal[2])


def view_alias(proof,language,field,index):
    datatype=next(d for d in language.datatypes if d[0]=='declare-datatypes'
                  and d[2][0][0]=='RowView')
    fields=datatype[2][0][1][1:];position=next(i for i,x in enumerate(fields,1) if x[0]=='rv-'+field)
    source=language.defs['row-source-view']
    args=[c('A',index),c('COLUMNS',index)]
    body=SUB(source[4],dict(zip([x[0] for x in source[2]],args)))
    assert body[0]=='mkRowView' and len(body)==len(fields)+1
    return proof.add('literal-RowView-source-constructor-selector',
        eq(V(field,c('row-source-view',*args)),body[position]),
        datatype=datatype,source_definition=source,actual_arguments=args,selector_position=position)


def observer(proof,kind,index,step=False):
    state=c('A',index);columns=c('COLUMNS',index);row=c('ROW',index)
    frame=c('FRAME',index);snapshot=c('ROWFRAME',index)
    spec={
        'snapshot':('ROWFRAME',c('row-frame-zero','unused-frame'),
            c('row-frame-next',state,columns,row,frame,snapshot,'unused-frame')),
        'origin':('FRAMEORIGIN','0',c('row-frame-origin-index-next',
            c('row-source-view',state,columns),row,index,c('FRAMEORIGIN',index)))}
    symbol,zero,nxt=spec[kind]
    if step:
        support=proof.index_support(index,True);parents=proof.index_parents(index)
        formula=eq(c(symbol,c('+',index,'1')),nxt)
    else:
        assert index=='1';support=[];parents=[];formula=eq(c(symbol,'1'),zero)
    return proof.add('total-same-trace-nondriving-component-observer-definition',formula,parents,
        support=['Gamma:actual-composed-source',*support],registry=kind,index=index,step=step,
        watched_index_not_an_observer_argument=True)


def fold_observer(proof,kind,node,index,step=False):
    d=observer(proof,kind,index,step);equal=proof.nodes[d]['formula']
    return proof.rewrite(node,d,equal[2],equal[1])

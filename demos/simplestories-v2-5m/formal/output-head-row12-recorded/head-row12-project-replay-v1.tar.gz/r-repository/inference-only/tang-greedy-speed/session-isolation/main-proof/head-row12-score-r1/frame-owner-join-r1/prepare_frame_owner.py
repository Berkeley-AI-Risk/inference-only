"""Pure three-query continuation: original HS owner to the saved FRAME NF."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
ROOT = C.parent
P = ROOT / 'head-mode-ownership-r1'
ORDER = ['frame-head-owner-base', 'frame-head-owner-preserve', 'owner-clock-and-saved-exponent']
READS = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
c = lambda name, *args: [name, *args]
AND = lambda *args: c('and', *args)
OR = lambda *args: c('or', *args)
EQ = lambda x, y: c('=', x, y)
NOT = lambda x: c('not', x)
IMP = lambda x, y: c('=>', x, y)
BV = lambda n, w: ['_', 'bv' + str(n), str(w)]
B = lambda w: ['_', 'BitVec', str(w)]
S = '|core_workflow_control_s|'
D = 'u_native.u_six_layers.u_datapath.'
J = D + 'u_projection.'


def read(path, expected=None):
    path = Path(path).resolve()
    raw = path.read_bytes()
    value = digest(raw)
    assert expected is None or value == expected, str(path)
    assert READS.setdefault(str(path), value) == value
    return raw


def assemble():
    READS.clear()
    path = C / 'head-owner-r1/prepare_owner.py'
    owner = types.ModuleType('_fixed_original_head_owner_prepare')
    owner.__file__ = str(path)
    exec(compile(read(path, 'a75351f775b4764ab59be3509744738bc8f20c71305f292e4500a074046cf421'), str(path), 'exec'), owner.__dict__)
    queries0, hs, plan0, types0, reads0 = owner.assemble()
    READS.update(reads0)
    assert hs == json.loads(read(C / 'head-owner-r1/SOURCE-BINDING.json',
        'f04f87258bf3573477f9bdcc7c1678b0280d3c99789c4783b5bc8b1521db5cd8'))
    for name in plan0['order']:
        assert queries0[name] == read(C / 'head-owner-r1' / (name + '.smt2'))
    frame = json.loads(read(ROOT / 'head-activation-frame-join-r1/SOURCE-BINDING.json',
        '871878ab819c5dd6cac5c80ccf782261d3971faadad4ee81231f7f16855f21a2'))
    q = json.loads(read(P / 'frame-join-pilot/certificate-prefix-r1/CONSTRUCTION.json',
        '0004bd2557a6cfa9cc6b331e649b3c9689ff81b961d3ad65e992b00a50213add'))
    src = json.loads(read(P / 'frame-join-pilot/certificate-source-application-r1/SOURCE-BINDING.json',
        '0cb68482a1c1b65d8d1267b350ef00624a32d249b408a5015fbe02d4241465e9'))
    with owner.helpers() as (parser, typing):
        raw = read(ROOT / 'rmsnorm-pilot/model-consumption/connected/native.smt2', owner.NATIVE_SHA)
        native = [f for f, _, _ in parser.parse_spans(raw)]
        defs = {f[1]: f for f in native if f[0] == 'define-fun'}
        observations = {}
        def getter(path, state='s'):
            name = '|core_workflow_control_n ' + path + '|'
            assert defs[name][2] == [['state', S]]
            observations[path] = {'literal_getter_definition': defs[name], 'sort': defs[name][3]}
            return c(name, state)
        js = lambda path, state='s': getter(J + path, state)
        ds = lambda path, state='s': getter(D + path, state)
        # No production source assumption or arbitrary future NF equality.
        j_live = AND(js('reset_n'), NOT(js('clear_i')), NOT(js('integrated_fail')))
        frame_guard = AND(j_live, EQ(js('job_q'), BV(7, 4)),
            c('f-active', 'frame'), c('frc-valid', 'certificate'))
        link_body = IMP(frame_guard, AND(c('hs-valid', 'history'),
            c('fj-protected-equal', c('hs-nf', 'history'), c('frc-nf', 'certificate'))))
        link_I = ['define-fun', 'hf-I', [['s', S], ['frame', 'FrameHistory'],
            ['certificate', 'FrameRmsCertificate'], ['history', 'HeadExponentHistory']], 'Bool', link_body]
        column_type = frame['prior_column_helpers'][0]
        job_type = frame['capture_helpers'][0]
        assert column_type[:2] == ['declare-datatypes', []] and column_type[2][0][0] == 'ColumnHistory'
        assert job_type[:2] == ['declare-datatypes', []] and job_type[2][0][0] == 'JobHistory'
        frame_helpers = frame['frame_helpers']
        assert [f[1] for f in frame_helpers[1:]] == ['frame-zero', 'frame-next', 'frame-I']
        assert frame_helpers[0] in q['definitions'] and frame_helpers[1] in q['definitions']
        # Keep the qualified certificate's literal record function declaration.
        # Later application uniformly identifies it with the already fixed
        # actual fj-capture-record-at; no desired saved record is supplied.
        theory = [*hs['NF_helpers'], *hs['source_event_definitions'], *hs['protected_helpers'],
            *hs['owner_helpers'], column_type, job_type, *frame_helpers]
        for f in q['definitions']:
            if f in theory:
                continue
            theory.append(f)
            if f[0] == 'declare-datatypes' and f[2][0][0] == 'FrameJoinView':
                theory.append(src['generic_source_view_definition'])
        theory.append(link_I)
        # Avoid any silent replacement of an existing native/helper name.
        names = [f[1] for f in theory if f[0] in ['declare-fun', 'define-fun']]
        assert len(set(names)) == len(names)
        view = c('fj-source-view', 'a', 'columns')
        next_nf = c('nf-next', 'a', 'nf', 'empty-nf')
        next_hs = c('hs-next', 'a', 'nf', 'history')
        next_frame = c('frame-next', 'a', 'columns', 'frame', 'empty-frame')
        next_cert = c('frc-next', view, 'frame', 'nf', 'certificate', 'observation')
        ha, hb, transition = (c(name, *args) for name, args in [
            ('|core_workflow_control_h|', ['a']), ('|core_workflow_control_h|', ['b']),
            ('|core_workflow_control_t|', ['a', 'b'])])
        frame_I = c('frame-I', 'a', 'columns', 'job', 'frame', 'watch-frame')
        frame_Ib = c('frame-I', 'b', 'next-columns', 'next-job', next_frame, 'watch-frame')
        hs_I = c('hs-I', 'a', 'nf', 'history')
        hs_Ib = c('hs-I', 'b', next_nf, next_hs)
        cert_I = c('frc-I', view, 'frame', 'nf', 'certificate', 'observation', 'watch')
        link = c('hf-I', 'a', 'frame', 'certificate', 'history')
        base = IMP(AND(ha, NOT(getter('reset_n', 'a'))),
            c('hf-I', 'a', c('frame-zero', 'empty-frame'), c('frc-zero', 'empty-nf'), 'history'))
        providers = [ha, hb, transition, frame_I, frame_Ib, hs_I, hs_Ib, cert_I, link]
        preserve = IMP(AND(*providers), c('hf-I', 'b', next_frame, next_cert, next_hs))
        clock = EQ(c('nf-t', 'nf'), c('-', 'observation', '1'))
        actual_revoke = OR(NOT(ds('rst_n', 'a')), ds('clear_i', 'a'))
        clock_bridge = IMP(clock, AND(EQ(c('+', c('nf-t', 'nf'), '1'), 'observation'),
            EQ(next_hs, c('hs-generic-next', 'observation', 'nf', 'history', actual_revoke,
                c('head-exponent-effective-capture', 'a')))))
        actual_guard = AND(c('fv-live', view), c('fv-head', view),
            c('f-active', 'frame'), c('frc-valid', 'certificate'))
        saved_exp = IMP(AND(ha, frame_I, hs_I, link, actual_guard), AND(
            EQ(ds('head_activation_exponent_q', 'a'), c('nf-exp', c('frc-nf', 'certificate'))),
            EQ(js('activation_exponent_q', 'a'), c('nf-exp', c('frc-nf', 'certificate')))))
        goals = dict(zip(ORDER, [base, preserve, AND(clock_bridge, saved_exp)]))
        declarations = [['declare-const', name, sort] for name, sort in [
            ('a', S), ('b', S), ('nf', 'NormFrame'), ('history', 'HeadExponentHistory'),
            ('columns', 'ColumnHistory'), ('next-columns', 'ColumnHistory'),
            ('job', 'JobHistory'), ('next-job', 'JobHistory'), ('frame', 'FrameHistory'),
            ('certificate', 'FrameRmsCertificate'), ('watch-frame', B(10)), ('watch', B(8)),
            ('empty-frame', ['Array', B(10), B(16)]), ('empty-nf', ['Array', B(8), B(16)]),
            ('observation', 'Int')]]
        queries, type_reports = {}, {}
        for name in ORDER:
            additions = [*theory, *declarations, ['assert', NOT(goals[name])],
                ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            query = raw + ('\n' + '\n'.join(map(parser.smt, additions)) + '\n').encode()
            assert [f for f, _, _ in parser.parse_spans(query) if f[0] == 'assert'] == [['assert', NOT(goals[name])]]
            type_reports[name] = typing.check(query)
            queries[name] = query
        READS.update(owner.READS)
        read(HERE / 'prepare_frame_owner.py')
        binding = {'native_sha256': owner.NATIVE_SHA, 'native_T_conjuncts': 452,
            'entire_native_prefix_retained': True, 'native_getter_bindings': observations,
            'theory': theory, 'declarations': declarations, 'goals': goals,
            'head_frame_owner_invariant': link_I, 'preservation_providers': providers,
            'current_saved_exponent_consequence': saved_exp, 'clock_specialization': clock_bridge,
            'actual_source_view': src['generic_source_view_definition'],
            'successor_frame_and_HS_are_independent_providers': True,
            'successor_health_assumed': False, 'new_owner_operator_invariant_count': 1,
            'typed_prefix_or_saved_R0_application_proved': False,
            'metadata_postscale_selector_join_proved': False, 'new_native_jobs': 0}
        plan = {'scope': 'c070-original-head-owner-saved-frame-NF-link-and-clock', 'order': ORDER,
            'queries': {name: {'sha256': digest(queries[name]), 'expected': 'unsat'} for name in ORDER},
            'maximum_native_jobs_this_gate': 3, 'diagnostic_launch_authorized_by_this_gate': False,
            'workers': 1, 'memory_cap_bytes': 4 * (1 << 30), 'new_native_jobs': 0,
            'time_or_CPU_kill_enabled': False, 'unexpected_result_stops_dependents': True}
        return queries, binding, plan, type_reports, dict(READS)


if __name__ == '__main__':
    queries, binding, plan, type_reports, pins = assemble()
    for name, raw in queries.items():
        with (HERE / (name + '.smt2')).open('xb') as output:
            output.write(raw)
    for name, value in [('SOURCE-BINDING.json', binding), ('QUERY-PLAN.json', plan),
                        ('TYPE-CHECK.json', type_reports), ('READ-PINS.json', pins)]:
        with (HERE / name).open('x') as output:
            output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_queries': list(queries), 'new_native_jobs': 0}))

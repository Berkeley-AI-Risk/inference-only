"""Restricted same-prefix deduction audit for the current E/R0 consequence."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
sub = lambda x, m: m.get(x, x) if isinstance(x, str) else [sub(t, m) for t in x]


def replace(x, a, b):
    return deepcopy(b) if x == a else x if isinstance(x, str) else [replace(t, a, b) for t in x]


def validate(application, exports, data, prepared, forms, module):
    ns, context = application['nodes'], application['root_context']
    assert context == prepared['context'] and module.digest(context) == module.CONTEXT_SHA
    assert len(ns) <= 160 and application['new_native_jobs'] == application['new_inductions'] == 0
    assert application['source_edges_requested'] is False
    domain = ['<=', '1', 'N']
    imports = {}
    for name in ['control', 'actual-capture', 'actual-frame']:
        selected = exports['selectedglobals'][name]
        imports['qualified-original-' + name] = (['=>', domain, selected['bounded_formula']], selected['node']['support'],
            {'seal': exports['provenance']['seal_sha256'], 'node': selected['node_id'],
             'source_application': exports['provenance']['source_dag_sha256']})
    imports['qualified-original-bounded-E-J-exponent'] = (
        ['=>', domain, data['engine_application']['prefix']['bounded_formula']],
        data['engine_application']['prefix']['source_supports'],
        {k: prepared['pins'][k] for k in ['engine_application', 'engine_review']})
    imports['closed-current-FRAME-original-saved-RMS-exponent'] = (
        data['saved_application']['application']['current']['literal_global_formula'], context,
        {k: prepared['pins'][k] for k in ['saved_seal', 'saved_application', 'saved_review']})
    defs = {f[1]: f for f in forms if f[0] == 'define-fun'}
    dtypes = [f for f in forms if f[0] == 'declare-datatypes']
    seen = {}
    for i, n in enumerate(ns):
        assert n['id'] == i and all(type(p) is int and 0 <= p < i for p in n['parents'])
        roots = set(n['introduced_support'])
        for p in n['parents']:
            roots.update(ns[p]['support'])
        assert roots - set(n.get('discharged_support', [])) == set(n['support'])
        f, k, ps = n['formula'], n['kind'], n['parents']
        if k == 'checked-fixed-component-context-application':
            name = n['component']
            assert name in imports and name not in seen and not ps
            expected, support, provenance = imports[name]
            assert f == expected and set(n['support']) == set(support)
            assert n['accepted_provenance'] == provenance and n['exact_bounded_source_context_sha256'] == module.CONTEXT_SHA
            seen[name] = i
        elif k == 'conjunction-introduction':
            assert f == ['and', *[ns[p]['formula'] for p in ps]]
        elif k == 'conjunction-elimination':
            assert len(ps) == 1 and ns[ps[0]]['formula'][0] == 'and'
            assert 1 <= n['position'] < len(ns[ps[0]]['formula']) and f == ns[ps[0]]['formula'][n['position']]
        elif k == 'implication-elimination':
            assert len(ps) == 2 and ns[ps[0]]['formula'] == ['=>', ns[ps[1]]['formula'], f]
        elif k == 'typed-equality-context-substitution':
            assert len(ps) == 2
            original, eq = (ns[p]['formula'] for p in ps)
            assert eq[0] == '=' and f in [replace(original, eq[1], eq[2]), replace(original, eq[2], eq[1])]
        elif k == 'literal-function-definition-instance':
            d = n['definition']
            assert d == defs[d[1]] and set(n['uniform_mapping']) == {v[0] for v in d[2]}
            assert f == ['=', [d[1], *[n['uniform_mapping'][v[0]] for v in d[2]]], sub(d[4], n['uniform_mapping'])]
            # Optional parents carry only already established bounds, never a new fact.
            assert all(ns[p]['formula'] in [['<=', '1', module.I], ['<=', module.I, 'N']] for p in ps)
        elif k == 'literal-datatype-constructor-selector':
            assert n['datatype'] in dtypes and not ps
            t = next(t for t in n['datatype'][2] if t[0] == n['datatype_name'])
            ctor = next(c for c in t[1:] if c[0] == n['constructor_name'])
            at = n['selector_position']
            assert 1 <= at < len(ctor) and ctor[at][0] == n['selector_name']
            assert f[0] == '=' and f[1][0] == n['selector_name'] and f[1][1][0] == ctor[0]
            assert len(f[1][1]) == len(ctor) and f[2] == f[1][1][at]
        elif k == 'fixed-typed-forall-elimination-preserving-domain':
            assert len(ps) >= 1
            original = ns[ps[0]]['formula']
            assert original == n['original_quantified_formula'] and original[0] == 'forall'
            assert set(n['uniform_mapping']) == {v[0] for v in original[1]}
            assert f == sub(original[2], n['uniform_mapping'])
            for value in n['uniform_mapping'].values():
                assert value in [module.I, '0', ['_', 'bv0', '10']]
            assert all(ns[p]['formula'] in [['<=', '1', module.I], ['<=', module.I, 'N']] for p in ps[1:])
        elif k == 'disjunction-introduction':
            assert len(ps) == 1 and f[0] == 'or'
            assert 1 <= n['selected_disjunct'] < len(f) and f[n['selected_disjunct']] == ns[ps[0]]['formula']
        elif k == 'scoped-natural-index-domain':
            assert not ps and f == ['<=', '1', module.I] and n['scope'] == module.FAMILY
            assert n['support'] == ['INDEX:' + module.FAMILY]
        elif k == 'scoped-case-assumption':
            assert not ps and n['case_label'] == 'CASE:actual-active-head-engine'
            assert f == ['and', domain, ['<=', module.I, 'N'], application['current']['guard']]
            assert n['support'] == [n['case_label']]
        elif k == 'implication-introduction':
            assert len(ps) == 2 and ns[ps[0]]['kind'] == 'scoped-case-assumption'
            assert f == ['=>', ns[ps[0]]['formula'], ns[ps[1]]['formula']]
            assert n['discharged_support'] == [ns[ps[0]]['case_label']]
        elif k == 'uniform-trace-consequence':
            assert i == application['current']['global_node'] and len(ps) == 2
            assert ns[ps[1]]['kind'] == 'scoped-natural-index-domain'
            assert n['fresh_index'] == module.I and n['quantified_parameters'] == []
            assert n['property_template'] == sub(ns[ps[0]]['formula'], {module.I: '@index'})
            assert f == ['forall', [[module.I, 'Int']], ['=>', ['<=', '1', module.I], ns[ps[0]]['formula']]]
            assert n['discharged_support'] == ns[ps[1]]['support'] and set(n['support']) == set(context)
        else:
            raise AssertionError(('Unreviewed current E/R0 rule', i, k))
    assert seen == application['current']['imports'] and set(seen) == set(imports)
    current = application['current']
    scalar = sub(data['binding']['scalar_invariant'][4], {'s': ['A', module.I]})
    head = ['=', ['|core_workflow_control_n ' + module.J + 'job_q|', ['A', module.I]], ['_', 'bv7', '4']]
    assert current['guard'] == ['and', scalar[1][1], head, scalar[1][2]]
    assert application['global_nodes'] == {module.FAMILY: current['global_node']}
    assert current['literal_global_formula'] == ns[current['global_node']]['formula']
    old = data['saved_application']['application']['current']['literal_global_formula']
    expected_saved = sub(old[2][2][2], {'i_saved_head_exponent': module.I})
    assert ns[current['saved_result_parent']]['formula'] == expected_saved
    assert ns[current['result_parent']]['parents'] == [current['E_original_exponent_parent'], current['saved_result_parent'], current['frame_active_parent'], current['frame_complete_parent']]
    e = ['|core_workflow_control_n ' + module.E + 'activation_exponent_q|', ['A', module.I]]
    j = ['|core_workflow_control_n ' + module.J + 'activation_exponent_q|', ['A', module.I]]
    r0 = ['nf-exp', ['endpoint-saved-NF', module.I]]
    assert ns[current['E_J_exponent_parent']]['formula'] == ['=', e, j]
    assert ns[current['J_original_exponent_parent']]['formula'] == ['=', j, r0]
    assert ns[current['E_original_exponent_parent']]['formula'] == ['=', e, r0]
    imported_ids = set(seen.values())
    # Domain elimination preserves each accepted bounded forall as a closed
    # theorem. Its bound index is not a free current-state access. Stop only
    # at this exact checked import->MP(domain) shape, never at arbitrary forall.
    closed_bounded = set()
    for i, n in enumerate(ns):
        ps = n['parents']
        if n['kind'] == 'implication-elimination' and len(ps) == 2 and ps[0] in imported_ids:
            original = ns[ps[0]]['formula']
            if original[0] == '=>' and original[1] == domain and original[2][0] == 'forall':
                assert ns[ps[1]]['formula'] == domain and n['formula'] == original[2]
                closed_bounded.add(i)
    assert len(closed_bounded) == 4
    indexed = {'A', 'C', 'COLUMNS', 'ROW', 'HEADER', 'CAPTURE', 'FRAME', 'CERT', 'HS', 'endpoint-saved-NF'}
    def local(x):
        if not isinstance(x, list):
            return
        if x and isinstance(x[0], str) and x[0] in indexed:
            assert len(x) == 2 and x[1] == module.I, x
        if x and x[0] == 'NF':
            # The closed saved theorem already carries this original NF lookup
            # and its capture bounds; it is preserved literally above.
            assert len(x) == 2 and x[1] in [module.I, ['endpoint-capture-index', module.I]], x
        for t in x:
            local(t)
    for i, n in enumerate(ns):
        if i not in imported_ids | closed_bounded:
            local(n['formula'])
    return {'passed': True, 'all_deduction_nodes_checked': len(ns), 'bounded_source_context_sha256': module.CONTEXT_SHA,
        'prefix_bound_domain': domain, 'only_current_defined_observation_used': True, 'closed_bounded_forall_nodes': sorted(closed_bounded),
        'source_edge_or_historical_INDEX_added': False, 'closed_saved_result_kept_literal': True,
        'historical_selected_row_R0_identity_proved': False, 'new_native_jobs': 0,
        'read_metadata_postscale_selector_join_proved': False}

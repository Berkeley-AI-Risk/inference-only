"""Restricted ordinary rules and original finite-prefix continuity audit."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
sub = lambda x, m: m.get(x, x) if isinstance(x, str) else [sub(t, m) for t in x]


def replace(x, a, b):
    return deepcopy(b) if x == a else x if isinstance(x, str) else [replace(t, a, b) for t in x]


def validate(application, exports, prepared, module):
    ns, data = application['nodes'], prepared['data']
    assert len(ns) <= 96 and application['root_context'] == exports['context']
    template = ['actual-row-eexp-I', ['A', '@index'], ['ROW', '@index'], ['FRAMEORIGIN', '@index']]
    source_support = {'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-1'}
    actual_function = data['binding']['future_fixed_actual_function_definition']
    for i, n in enumerate(ns):
        assert n['id'] == i and all(type(p) is int and 0 <= p < i for p in n['parents'])
        roots = set(n['introduced_support'])
        for p in n['parents']:
            roots.update(ns[p]['support'])
        assert roots - set(n.get('discharged_support', [])) == set(n['support'])
        f, k, ps = n['formula'], n['kind'], n['parents']
        if k == 'qualified-source-schema-uniform-instance':
            assert i in application['schema_nodes'] and not ps
            base = i == application['schema_nodes'][0]
            name = 'row-engine-exponent-reset-base' if base else 'row-engine-exponent-preserve'
            at = '1' if base else module.INDEX
            mapping = {'a': ['A', at], 'b': ['A', '1' if base else ['+', at, '1']],
                'columns': ['COLUMNS', at], 'row': ['ROW', at], 'old-origin': ['FRAMEORIGIN', at],
                'observation': at, 'empty-a': 'empty-a', 'empty-w': 'empty-w', 'empty-prefix': 'empty-prefix',
                **data['binding']['future_uniform_function_mapping']}
            assert n['uniform_mapping'] == mapping and n['original_query_goal'] == data['binding']['goals'][name]
            assert f == sub(n['original_query_goal'], mapping)
            assert n['original_query_sha256'] == data['plan']['queries'][name]['sha256']
            assert n['accepted_result_review_sha256'] == prepared['pins']['review']
            assert n['fixed_function_realizations'] == [actual_function, data['binding']['future_actual_invariant']]
        elif k == 'actual-source-trace-projection':
            assert f[0] in ['|core_workflow_control_h|', '|core_workflow_control_t|']
            assert all(a[0] == 'A' for a in f[1:])
            if f[0].endswith('_t|'):
                assert f[2] == ['A', ['+', f[1][1], '1']]
        elif k == 'actual-common-reset-entry':
            assert f == ['not', ['|core_workflow_control_n reset_n|', ['A', '1']]]
            assert set(n['support']) == source_support
        elif k == 'conjunction-introduction':
            assert f == ['and', *[ns[p]['formula'] for p in ps]]
        elif k == 'implication-elimination':
            assert len(ps) == 2 and ns[ps[0]]['formula'] == ['=>', ns[ps[1]]['formula'], f]
        elif k == 'literal-function-definition-instance':
            assert i == application['bridge_parent'] and not ps and n['definition'] == actual_function
            mapping = {'row-exp-observation': module.INDEX}
            assert n['uniform_mapping'] == mapping
            assert f == ['=', ['actual-row-engine-exp-at', module.INDEX], sub(actual_function[4], mapping)]
        elif k == 'qualified-total-same-trace-observer-definition-instance':
            family = n['registry']
            assert family in ['ROW', 'FRAMEORIGIN'] and i == application['observer_definition_nodes'][family]
            anchor = prepared['anchors'][family]
            assert n['source_anchor'] == anchor and n['index'] == module.INDEX
            assert n['uniform_index_mapping'] == {anchor['old_index']: module.INDEX}
            assert f == sub(anchor['step']['formula'], n['uniform_index_mapping'])
            assert len(ps) == 1 and ns[ps[0]]['kind'] == 'scoped-natural-index-domain'
            assert ns[ps[0]]['formula'] == ['<=', '1', module.INDEX]
            assert set(n['introduced_support']) == {'Gamma:actual-composed-source', 'INDEX:' + module.FAMILY}
            assert n['accepted_source_application_sha256'] == prepared['pins']['dot_application']
            assert n['accepted_seal_sha256'] == prepared['pins']['dot_seal']
        elif k == 'typed-equality-context-substitution':
            assert len(ps) == 2
            original, equation = (ns[p]['formula'] for p in ps)
            assert equation[0] == '=' and f in [replace(original, equation[1], equation[2]), replace(original, equation[2], equation[1])]
        elif k == 'scoped-natural-index-domain':
            assert not ps and f == ['<=', '1', module.INDEX] and n['scope'] == module.FAMILY
            assert n['support'] == ['INDEX:' + module.FAMILY]
        elif k == 'scoped-induction-hypothesis':
            assert i == application['IH_parent'] and len(ps) == 1 and ns[ps[0]]['kind'] == 'scoped-natural-index-domain'
            assert f == sub(template, {'@index': module.INDEX}) and n['scope'] == module.INDEX
            assert set(n['support']) == {'INDEX:' + module.FAMILY, 'IH:' + module.FAMILY}
        elif k == 'ordinary-induction':
            assert i == application['global_node'] and n['fresh_step_index'] == module.INDEX
            assert n['property_template'] == template and n['quantified_parameters'] == []
            assert ps == [application['base_parent'], application['step_parent']]
            assert n['scoped_IH'] == application['IH_parent']
            assert ns[n['bound_parent']]['formula'] == ['<=', '1', module.INDEX]
            assert ns[n['scoped_IH']]['parents'] == [n['bound_parent']]
            assert ns[n['base_parent']]['formula'] == sub(template, {'@index': '1'})
            assert ns[n['step_parent']]['formula'] == sub(template, {'@index': ['+', module.INDEX, '1']})
            assert f == ['forall', [[module.INDEX, 'Int']], ['=>', ['<=', '1', module.INDEX], sub(template, {'@index': module.INDEX})]]
            assert set(n['support']) == source_support
            assert set(n['discharged_support']) == {'INDEX:' + module.FAMILY, 'IH:' + module.FAMILY}
        else:
            raise AssertionError(('Unreviewed row exponent rule', i, k))
    final = ns[application['global_node']]
    assert application['global_nodes'] == {module.FAMILY: final['id']}
    assert application['fixed_actual_function_definition'] == actual_function
    assert set(application['observer_definition_nodes']) == {'ROW', 'FRAMEORIGIN'}
    assert len(application['schema_nodes']) == 2
    indexed = {'A', 'C', 'COLUMNS', 'ROW', 'FRAMEORIGIN', 'actual-row-engine-exp-at'}
    def local(x, allowed):
        if not isinstance(x, list):
            return
        if x and isinstance(x[0], str) and x[0] in indexed:
            assert len(x) == 2 and x[1] in allowed, (x, allowed)
        for t in x:
            local(t, allowed)
    def ancestry(seed, allowed):
        seen = set()
        def visit(i):
            if i in seen:
                return
            seen.add(i)
            local(ns[i]['formula'], allowed)
            for p in ns[i]['parents']:
                visit(p)
        visit(seed)
        return sorted(seen)
    base = ancestry(application['base_parent'], ['0', '1'])
    step = ancestry(application['step_parent'], [module.INDEX, ['+', module.INDEX, '1']])
    assert {application['bridge_parent'], application['IH_parent'], *application['observer_definition_nodes'].values()} <= set(step)
    n = 'n_row_exponent_prefix'
    return {'kind': 'same-original-prefix-physical-row-E-exponent-continuity', 'prefix_bound_domain': ['<=', '1', 'N'],
        'bounded_source_context': deepcopy(prepared['context']), 'bounded_source_context_sha256': module.CONTEXT_SHA,
        'bounded_formula': ['forall', [[n, 'Int']], ['=>', ['and', ['<=', '1', n], ['<=', n, 'N']], sub(template, {'@index': n})]],
        'source_supports': final['support'], 'base_locality_nodes': base, 'step_locality_nodes': step,
        'state_domain': ['and', ['<=', '1', n], ['<=', n, 'N']], 'edge_domain': ['and', ['<=', '1', n], ['<', n, 'N']],
        'qualified_original_bounded_recurrences': {family: deepcopy(a['bounded_step']) for family, a in prepared['anchors'].items()},
        'fixed_actual_function_definition': deepcopy(actual_function), 'historical_function_calls_unfolded': False,
        'new_native_jobs': 0, 'original_R0_at_read_proved': False, 'read_metadata_postscale_selector_join_proved': False}

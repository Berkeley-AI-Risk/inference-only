"""Pure actual E/J scalar exponent base/preservation with qualified control."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
ROOT = C.parent
P = ROOT / 'head-mode-ownership-r1'
S = '|core_workflow_control_s|'
J = 'u_native.u_six_layers.u_datapath.u_projection.'
E = J + 'u_shared_engine.u_engine.'
ORDER = ['engine-job-exponent-reset-base', 'engine-job-exponent-preserve']
READS = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
c = lambda name, *args: [name, *args]
AND = lambda *args: c('and', *args)
OR = lambda *args: c('or', *args)
EQ = lambda x, y: c('=', x, y)
NOT = lambda x: c('not', x)
IMP = lambda x, y: c('=>', x, y)
BV = lambda n, w: ['_', 'bv' + str(n), str(w)]


def read(path, expected=None):
    path = Path(path).resolve()
    raw = path.read_bytes()
    value = digest(raw)
    assert expected is None or value == expected, str(path)
    assert READS.setdefault(str(path), value) == value
    return raw


def assemble():
    READS.clear()
    path = C / 'prepare_exponent.py'
    prep = types.ModuleType('_engine_exponent_existing_helpers')
    prep.__file__ = str(path)
    exec(compile(read(path, '7eb5e7b8917d57e3d5e14a78620d922276901e6d6623a913630e4c80a7ba6cc4'), str(path), 'exec'), prep.__dict__)
    with prep.checked_helpers() as (parser, typing):
        raw = read(ROOT / 'rmsnorm-pilot/model-consumption/connected/native.smt2', prep.NATIVE_SHA)
        native = [f for f, _, _ in parser.parse_spans(raw)]
        defs = {f[1]: f for f in native if f[0] == 'define-fun'}
        assert len(defs['|core_workflow_control_t|'][4]) - 1 == 452
        old_raw = read(ROOT / 'head-completed-model-dot-r1/COMPLETED-DOT-TYPING-ONLY.smt2',
            '11ff55d9fbd14af2deba9ec517f9fd5e01ff44d45be89083afa7ae2ce26dbe8a')
        seal = json.loads(read(ROOT / 'HEAD-COMPLETED-MODEL-DOT-R1-SEALED.json',
            'c5591f6f05aa192edc891e8a6888e43895cc1d9b00a11eb067a0995d4c23b99e'))
        assert seal['files']['COMPLETED-DOT-TYPING-ONLY.smt2'] == digest(old_raw)
        old_forms = [f for f, _, _ in parser.parse_spans(old_raw)]
        old_defs = {f[1]: f for f in old_forms if f[0] == 'define-fun'}
        phase = old_defs['selected-row-phase-I']
        assert phase[2] == [['s', S], ['h', 'ColumnHistory'], ['r', 'SelectedRow'], ['ep', 'RowEpisodeHeader']]
        assert phase[4][0] == 'and' and len(phase[4]) == 21
        parent_body = AND(*phase[4][1:9])
        assert not ({'h', 'r', 'ep', 'model'} & parser.atoms(parent_body))
        parent = ['define-fun', 'eexp-source-parent-control', [['s', S]], 'Bool', parent_body]
        job = old_defs['current-job-I']
        assert job[2] == [['s', S], ['h', 'ColumnHistory']]
        columns = next(f for f in old_forms if f[0] == 'declare-datatypes' and f[2][0][0] == 'ColumnHistory')
        observations = {}
        def getter(path, state='s'):
            name = '|core_workflow_control_n ' + path + '|'
            assert defs[name][2] == [['state', S]]
            observations[path] = {'literal_getter_definition': defs[name], 'sort': defs[name][3]}
            return c(name, state)
        js = lambda path, state='s': getter(J + path, state)
        es = lambda path, state='s': getter(E + path, state)
        live = AND(js('reset_n'), NOT(js('clear_i')), NOT(js('integrated_fail')))
        active = OR(*[EQ(es('state_q'), BV(v, 3)) for v in [1, 2, 3, 4, 5]])
        invariant = ['define-fun', 'eexp-I', [['s', S]], 'Bool',
            IMP(AND(live, active), EQ(es('activation_exponent_q'), js('activation_exponent_q')))]
        # Every referenced getter is the exact current c070 definition, not
        # a translated standalone state sort or a free child response.
        native_names = parser.atoms([parent, job]) & set(defs)
        old_getters = {name: old_defs[name] for name in native_names if name.startswith('|core_workflow_control_n ')}
        assert old_getters and all(defs[name] == value for name, value in old_getters.items())
        ha, hb, transition = c('|core_workflow_control_h|', 'a'), c('|core_workflow_control_h|', 'b'), c('|core_workflow_control_t|', 'a', 'b')
        base = IMP(AND(ha, NOT(getter('reset_n', 'a'))), c('eexp-I', 'a'))
        providers = [ha, hb, transition, c('current-job-I', 'a', 'columns'),
            c('eexp-source-parent-control', 'a'), c('eexp-I', 'a')]
        preserve = IMP(AND(*providers), c('eexp-I', 'b'))
        goals = dict(zip(ORDER, [base, preserve]))
        helpers = [columns, job, parent, invariant]
        declarations = [['declare-const', name, sort] for name, sort in [('a', S), ('b', S), ('columns', 'ColumnHistory')]]
        queries, reports = {}, {}
        for name in ORDER:
            additions = [*helpers, *declarations, ['assert', NOT(goals[name])],
                ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            query = raw + ('\n' + '\n'.join(map(parser.smt, additions)) + '\n').encode()
            assert [f for f, _, _ in parser.parse_spans(query) if f[0] == 'assert'] == [['assert', NOT(goals[name])]]
            reports[name] = typing.check(query)
            queries[name] = query
        READS.update(prep.READS)
        read(HERE / 'prepare_engine_exponent.py')
        binding = {'native_sha256': prep.NATIVE_SHA, 'native_T_conjuncts': 452,
            'entire_native_prefix_retained': True, 'native_getter_bindings': observations,
            'qualified_control_getters_literal': old_getters,
            'original_phase_invariant': phase, 'projected_phase_positions': list(range(1, 9)),
            'projected_control_definition': parent, 'original_current_job_invariant': job,
            'scalar_invariant': invariant, 'helpers': helpers, 'declarations': declarations,
            'goals': goals, 'preservation_providers': providers,
            'root_arbiter_healthy_or_Q_job_guard_added': False, 'successor_provider_or_health_assumed': False,
            'new_control_or_operator_inductions': 1, 'new_driving_state': False,
            'ordinary_prefix_and_original_R0_application_proved': False,
            'read_model_metadata_scale_selector_join_proved': False, 'new_native_jobs': 0}
        plan = {'scope': 'two-c070-active-engine-job-exponent-scalar-leaves', 'order': ORDER,
            'queries': {name: {'sha256': digest(queries[name]), 'expected': 'unsat'} for name in ORDER},
            'maximum_native_jobs_this_gate': 2, 'diagnostic_launch_authorized_by_this_gate': False,
            'workers': 1, 'memory_cap_bytes': 4 * (1 << 30), 'new_native_jobs': 0,
            'time_or_CPU_kill_enabled': False, 'unexpected_result_stops_dependents': True}
        return queries, binding, plan, reports, dict(READS)


if __name__ == '__main__':
    queries, binding, plan, types, pins = assemble()
    for name, raw in queries.items():
        with (HERE / (name + '.smt2')).open('xb') as output:
            output.write(raw)
    for name, value in [('SOURCE-BINDING.json', binding), ('QUERY-PLAN.json', plan),
                        ('TYPE-CHECK.json', types), ('READ-PINS.json', pins)]:
        with (HERE / name).open('x') as output:
            output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_queries': list(queries), 'new_native_jobs': 0}))

# Independent original-prefix exponent application result review

**Decision: ACCEPTED. The actual 96-node ordinary application and both
finite-prefix exports pass independent formula/support/locality review and
complete byte-identical read-only reconstruction.** This qualifies the joint
HS/control-origin and saved-FRAME/HS relation on their named original prefix.
It does not yet export the current/historical saved-R0 or completed-row
exponent consequence, numerical RMS, a scaled score or selector admission.

Exact result identities:

- Accepted six-file envelope: `bef25d454826b28acefd16c33ec0c701bc804a15c9ac3060723a4be015cde7b9`
- Metadata-only result: `7f5f9bf63986feb81dc74e312acb16e3e2769bc975167abd16de483abbae38e9`
- Complete application JSON: `ea1aa06d27b8fd0c42e6db9272cfb450711256153591fbd31d203ad8effbaeec`
- Standalone typing: `56f35ce08b3e8d6c0960fb369962e3b0619f854706fd5704f5df7e47bab7e806`

The exact reviewed code/input set remains unchanged: application `920afca6...`,
prefix auditor `1b35cb71...`, driver `d188e720...`, raw manifest `49cd1bac...`
and input review `5c354819...`. All six envelope files, fifteen raw pins and
four helper pins still match actual bytes. No frozen/sealed parent or result
was changed by this additive review.

## Actual graph and source application

Metadata-only records zero Proof initializers/nodes/native jobs, with 89 reads
and 18 helpers. Its envelope matches the application envelope. The actual
application has 96 nodes and 98 typed assertions, below the192-node cap, with
90 reads and 20 executed helpers. Every current read/helper digest matches
its actual file, and every executed helper is covered by the read map.

I inspected all actual node formulas, parent order and inherited/discharged
supports. Six exact qualified globals are imported at0..5; seven complete
source-schema instances use the accepted owner/frame bindings, query hashes,
result reviews and full deterministic substitutions. No positive formula is
accepted merely because it types. Twenty equality rewrites, six exact MP
steps, seven conjunction introductions, nine projections, eight qualified
trace instances, three literal definition instances and four concrete
datatype-selector equations agree with their actual parents and definitions.

The nine observer equations use the fixed same-trace zero/next bodies. Reused
NF/FRAME equations carry their original accepted total-definition anchors;
CERT zero36/step132 carry the pinned135-node component's exact equation,
source index, support and domain parent. HS is the one new fixed observer.
There is no new INDEX for a saved/historical term or replacement of an
existing observer.

HS/control plus strict-past origin closes at global60 from base15 and step59.
Its support is exactly actual source plus original reset samples0/1. Base
uses H(A1), original reset-low1 and literal HS zero. The control step supplies
both actual H endpoints, full native T, qualified current/successor NF-I and
the control component of the same scoped IH. The actual successor NF and HS
recurrences rewrite the source leaf's result to the next property.

The origin premise37 has exactly parents `[16,36,34,35]`: current lower bound,
origin projection from IH17, actual current capture-event definition and
NF(n) reflexivity. MP38 applies the actual generic origin implication33.
The clock comes from imported original STEP global4 through instance41,
literal predicate/observer equations42/44, concrete selectors46/48/50/52,
normalized predicate53 and clock projection54. MP55 applies the accepted
clock rule40; equality projection56 rewrites generic-next to actual hs-next,
then HS recurrence19 supplies HS(n+1). No guessed clock or event premise is
introduced.

HF closes at global95 from base69 and step94, retaining all six original
roots. Its exact preservation premise90 has parents
`[87,88,89,82,84,77,81,85,71]`: H/T, current/successor qualified FRAME,
current/successor preceding HS, original current CERT and its own HF IH.
Rewrites use original NF/HS/FRAME/CERT equations. Both inductions discharge
exactly their own INDEX/IH scopes; no such support survives in either global.
No successor-health or successful-future condition is supplied.

## Finite prefix and fixed function meaning

The actual bounded exports preserve context `41af6255...`, explicit `1<=N`,
state conclusions1..N and step domain1<=n<N over the original source's
states0..N/defined edges0..N-1. The locality checks authorize only0/1 at base
and n/n+1 in each step. Qualified stops retain their accepted bounded
counterparts, and HS is a stop for HF only after its own locality closes.
NFEMPTY(0) is the original fixed initial parameter, not an arbitrary history
lookup exception.

The validity-scoped origin ledger matches the applied generic recurrence:
revoke gives invalid history; capture uses the actual current n/NF(n)/event;
retain carries the identical old stamp, payload, event and NF lookup under
the same IH lower/strict-past guard. No historical source function is unfolded
without derived bounds, and no future lookup or infinite-extension assumption
is granted.

All schema nodes record one fixed actual HS event function, NF record function
and origin predicate. The generic capture-record UF is uniformly realized by
the original actual function of A(t), COLUMNS(t), FRAME(t), NF(t), t. The
realization equals the accepted CERT prefix's fixed function definition.
Nothing is selected per stamp/word or from a desired saved exponent. The HS
snapshot and later NF are connected only through the protected six fields;
advancing clocks/count/activity/validity are not equated across observations.

## Independent read-only reconstruction and limits

I loaded the exact pinned driver once in fresh Python3.12 with `-I -S -B`
and called `construct()` under an additional audit denying writes, process
creation, network and filesystem mutation. The accepted read/helper auditor
also ran. The call finished exit0 in 6.16 seconds with no forbidden event.
Its entire returned application JSON, including every node, prefix report,
pin and helper record, serialized byte for byte to the saved result. Its
complete typing bytes also matched. No output file was overwritten, engine
or old parent-proof reconstruction ran, and no process control was used. The
complete tool result is retained with no pending session.

Independent direct checks of the saved graph also passed parent/support
accounting, actual rule equations, source-schema/result bindings, original
clock/generic-step/HF premise anchors, exact bounded formulas and all current
pin bytes. Standalone typing has 15,198 symbols and98 assertions; its parser-
only check marker grants no solver result.

The graph's saved unqualified/pending flags remain unchanged as checkpoint
provenance. This review accepts these two bounded owner/link invariants.
Applying the current saved-exponent leaf at original j/k and identifying the
endpoint R0 with its exact original CERT record remains a further checked
application. Registered read, fixed-image metadata, postscale/held score,
actual legal selector admission, upstream numerical RMS, other rows,
publication and whole-device qualification remain open. Closed component
replay/seal/archive remain separate closeout work.

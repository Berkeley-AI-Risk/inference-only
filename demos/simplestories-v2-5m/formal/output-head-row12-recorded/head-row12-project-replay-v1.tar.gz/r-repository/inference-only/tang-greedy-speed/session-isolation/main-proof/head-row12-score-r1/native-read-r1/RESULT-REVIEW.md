# Independent native read/stage1 result review

**Decision: ACCEPTED. Both exact conditional native source leaves returned
clean UNSAT on their first recorded attempts.** The result concerns local
lane12/pre-edge physical payload and stall behavior. It does not establish
group0/global row12, original completed-dot or metadata provenance, UID/epoch,
postscale, score or selector admission.

The exact freeze is
`af33ea6e3c36678d8cda93e82e6cc088f4c5b596f2af0f4d7d7ad08d08054705`,
acceptance record
`eebe87aa901d02741c8b2485eea3b700e1c1c17baf7d019c3698c0d02f7dffd8`,
and input review
`1e47304e37b1163428955646870c69db4ce6353b45b757c7ba1b47d0a589b286`.
Complete `RESULTS.json` is
`e4f3bcd3ed2a2fae0429a1b57a750574e20736d044062d603c34b05bd1599670`;
intent is `17535b9aa3152f9827317a221eccb11ae2379a80a90e34fd208dc2dee4c1fb5b`.
All twelve frozen local inputs, 38 external pins and five preparation reads
still match actual bytes. No frozen/sealed parent or recorded result was
modified by this additive review.

## Raw execution and pin binding

I independently inspected both complete raw logs, STARTED/FINISHED receipts,
monitors, checked results and observation journals. Each checked result
equals its aggregate row, and every stored receipt/monitor copy equals the
actual file. Names/order/query hashes, actual argv/cwd, intent and freeze
agree. The original c070 source, all 452 T conjuncts and exact reviewed query
tails remain unchanged.

| Job | Native wall seconds | Raw-log SHA256 |
| --- | ---: | --- |
| row12-tile0-synchronous-read | 1.236542 | `39d5c5689c86c4d50a9abc553bb7dd1fb3563705c29ed4edc9e4e82c48152a7f` |
| row12-stage1-capture-and-pipeline-stall | 1.903899 | `f1fe55e39080031f716f19762ad43c1cfe9f22dcfba71e1afb215ebe50c10fe2` |

Each whole raw protocol is exactly UNSAT followed by one 28-entry statistics
list with unique keys and finite nonnegative values, including
`:num-checks 1`. No error, additional answer or observation is present.
Log bytes/length/hash match each receipt and result. Actual binary
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`
is the pinned tool, with `-smt2 -st -memory:4096` and each exact absolute query.

The runs inventory is exactly two single-use directories and their two
journals; each directory contains exactly STARTED, FINISHED,
MONITOR-BINDING, CHECKED-RESULT and NATIVE.log. The second start follows the
first finish. There is no retry, diagnostic or third native job in this gate.

## Resource and recorded cleanup

Both native exits and raw wait statuses are zero, with no monitor errors or
resource-stop reason. STARTED records specify one process, 4 GiB, no environment
changes, no wall/CPU limits and zero disk floor. Every admission and actual
pressure observation is normal Darwin pressure1. Journal hashes match actual
files and monitor bindings.

There are 22 and 34 owned-group observations, matching monitor counts and the
guard's loop count plus final survivor observation. Each group contains at
most its own leader with one stable start identity. I independently
recomputed all member RSS/footprint sums and peaks. Maximum sampled RSS is
278,659,072 bytes; maximum sampled footprint is 274,006,664 bytes; maximum
wait4 RSS is 278,659,072 bytes. All are below 4 GiB. Total native wall time is
3.140441 seconds.

Each final group observation is empty. The accepted guard emits FINISHED
after wait4; these clean receipts and empty final observations support
recorded reaping/cleanup. This review used no live-process inspection/control
and makes no host-wide memory guarantee. No engine, rerun, probe, build,
simulation, old writer, proof constructor or new agent was invoked. Complete
read-only validation tool results were retained.

## Accepted conditional source meaning

Actual issue at local count12 drives the read cone and, under both H/full T,
captures pre-edge tile0 accumulator12 and metadata memories12 into its
registered tuple, selection0 and local tag12. Without read, the physical
tile tuple holds. Same-edge metadata writes do not replace the pre-edge
values captured by nonblocking reads.

Actual advance/stage0-valid/selected0/tag12 captures stage1 from the pre-edge
registered tile0 tuple with the exact zero/sign extensions. A concurrent
new read may already replace the successor tile outputs; it does not change
these old operands. With no advance, all fourteen listed physical selection,
operand, product, result, row-tag and exponent-tag fields hold. The payload is
resetless, so no successor reset/CLEAR/health filter is added to these physical
equalities. Valid/ownership authority is separate and can be revoked.

Local count/tag12 does not fix group0 or global vocabulary row12. The leaves
do not identify the value with the original saved frame/model dot, prove the
metadata image reader/ownership, provide a successful original UID/episode or
interpret the subsequent product/result as a scaled model score. Those exact
source-bound applications and the actual selector boundary remain open.
Fixture oracle numbers remain sensitivity evidence only.

Twelve first-attempt native jobs are recorded across the reviewed exponent,
owner, frame-link and read batches, without diagnostics/retries. This count
is not theorem credit. Broader-qualification and pending-review flags remain
unchanged as checkpoint provenance. Numerical RMS, other rows, publication,
board/physical and whole-device claims remain outside this result.

# Independent head-owner leaf result review

**Decision: ACCEPTED. The exact base, preservation and fixed-origin queries
all returned clean UNSAT on their first recorded attempts.** This accepts the
three conditional leaves and their execution evidence. The ordinary typed
finite-prefix construction and the exact historical FRC/saved-R0 relation
remain open; no metadata, read, postscale or selector admission is qualified.

The reviewed freeze is
`129222e4efd50a9fe34354f61e2c9687022f4e645606b231a4a2986f81681082`,
acceptance record
`6f74b8030bc8185f1fec29b7775f925cef638352c066d54c613d0435c6587211`,
and input review
`04b70cd29d8f0d107462c32e50bab66381ed83099ab398acebbfb9c274858e31`.
Complete `RESULTS.json` is
`b15441e6cf5256aab04bf4553d253404aec2112660ec8e53f1e3d1b2bc7867eb`;
intent is `860b8082a62a07cc070b3a2ff33e15a4b837b584d43945ae38c8e60cccf9ac4f`.
All thirteen frozen local inputs, 45 external pins and seven preparation
reads still match actual bytes. No old frozen/sealed input, result, receipt,
review or pending flag was changed.

## Raw protocol and source binding

I independently read each raw log, STARTED/FINISHED receipt, monitor binding,
observation journal and checked result. Each checked result equals its
aggregate row and contains the literal receipt/monitor saved in that run.
Query names, order, hashes, intent, argv and working directory agree with the
frozen plan. All query bytes remain the reviewed c070 prefix and exact
single-goal tails. The original 452-conjunct transition and source profile
remain unchanged.

| Job | Wall seconds | Raw-log SHA256 |
| --- | ---: | --- |
| head-owner-base | 0.389155 | `a4300d5994715e1350adb1614f9e311d3c6b5626282e88133187702389114023` |
| head-owner-preserve | 0.941351 | `a0717365e95cccb0803f0f3fc3948bc370f428f03748b5ea4a1c7c9c3d6219e3` |
| head-owner-origin | 0.388647 | `3a051f541b4148da031afddeaefdd28737b80bf391f1d7ced020ab4bd12eda6a` |

Each whole raw protocol is exactly UNSAT and one nonempty statistics list,
with unique keys and finite nonnegative values. There are no errors, extra
answers or trailing observations. Base has five statistics and no
`:num-checks` field; its frozen query has exactly one check. Preservation has
38 statistics and origin has 32, both reporting `:num-checks 1`. Missing
statistics are not invented. Every log byte count/hash agrees with its
receipt and aggregate record.

The actual binary remains
`ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102`,
with the exact absolute query path and `-smt2 -st -memory:4096` arguments.
All thirteen local and 45 external pins match the freeze accepted before
launch, including source/compile closure, guard/probes and parent results.
The runs inventory is exactly the three expected single-use directories and
three journals, with exactly the five expected files in each directory.
Recorded starts follow the preceding finish, so jobs are sequential. No
retry, diagnostic or fourth job appears in this batch.

## Resource and recorded cleanup

All native exits and raw wait statuses are zero, without monitor errors or a
resource-stop reason. STARTED records require one process, 4 GiB, no changed
environment, no wall/CPU limits and zero disk floor. Every admission and
actual pressure observation is normal Darwin pressure1; journal hashes match.

The journals contain eight, seventeen and eight owned-group observations.
Their counts match the guard's loop count plus final survivor observation.
Every group contains at most its own leader with one stable start identity.
I recomputed group RSS/footprint sums and all recorded peaks from the complete
journals. Maximum sampled RSS is 259,244,032 bytes; maximum sampled physical
footprint is 254,362,224 bytes; maximum wait4 RSS is 259,407,872 bytes. All
remain below 4 GiB. Total native wall time is 1.719153 seconds.

Every final group observation is empty. The accepted guard reaches FINISHED
after wait4; its clean receipts and empty final observations support recorded
reaping/cleanup. This review did not inspect or control live processes and
does not make a host-wide memory guarantee. No native engine, probe,
simulation, build, old checker/writer, constructor or additional agent was
invoked during this read-only result review. The complete validation tool
results were retained.

## What the accepted formulas establish

Base establishes the literal zero owner's compound invariant under H and
root reset-low with arbitrary NF/payload. It does not assume initialized
payload or replace the original source startup convention.

Preservation proves the one four-clause owner/control invariant through the
complete native T, H at both endpoints, current hs-I and the independently
qualified current/successor NF-invariant premises. A valid snapshot is an
accepted completed NF; D's retained exponent agrees under its physical
reset/CLEAR conditions; live D E_HEAD has the same six protected NF fields;
and live stored J job7 in LOAD/GROUP_START/GROUP_RUN/DONE has D E_HEAD and
the original snapshot exponent. The shell phase constraint remains
conditional on shell-live, so a shell-fault interval is not filtered out by
an assumed healthy shell. Pre-J birth is covered by the same invariant,
rather than by pretending the old JLOAD-only stability lemma covered it.

Actual reset masking, effective D capture and J fault/CLEAR/protocol
priorities are the reviewed source expressions. Successor NF-I is an
acyclic independently qualified provider, not future health. Historical
payload may remain after cancellation; none of these facts grants canceled
work new current authority. Only data/exponent/UID/parent/STEP-ID/prefix are
equated between the stored head snapshot and current NF. No whole-NF
cross-time equality follows.

Origin proves the generic zero/step law for fixed unary event and NF-record
functions, plus the literal actual/generic-next identity. Valid history has
an earlier positive observation, the event at that same saved observation
and its exact snapshot from the fixed record function. Revoke precedes
capture; hold uses the same historical record and event. These functions
are not selected after a stamp or word is known.

The generic origin law still needs its actual uniform source-history
specialization. The typed application must supply actual recurrences,
NF clock=observation-1, original reset samples, independently qualified NF
instances and the real state/edge domains. It must derive the historical
bounds before unfolding saved-event source lookups, without historical INDEX
assumptions or hidden future accesses. The exact saved FRC record must be
related to this original head snapshot through protected fields; replacing
it by a later current NF after completion is not licensed by these results.

There are now seven accepted first-attempt native jobs across the exponent
and owner batches, with no diagnostics or retries. The budget clarification
does not turn that count into theorem credit or waive subsequent exact
review. Recorded broader-qualification and pending-review flags are retained
unchanged; this additive review accepts only the three owner leaves and their
recorded execution. Typed prefix, saved-R0/row epoch connection, metadata,
synchronous dot read, postscale, actual restored-selector admission, upstream
numerical RMS and whole-device claims remain open.

"""Fixed deduction and finite-prefix audit for the one E/J scalar induction."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
sub = lambda x, m: m.get(x, x) if isinstance(x, str) else [sub(t, m) for t in x]


def replace(x, a, b):
    return deepcopy(b) if x == a else x if isinstance(x, str) else [replace(t, a, b) for t in x]


def validate(application, exports, prepared, module):
    ns, data = application['nodes'], prepared['data']
    selected = prepared['control']
    assert application['root_context'] == exports['context'] and len(ns) <= 64
    assert application['control_import'] == 0
    for i, n in enumerate(ns):
        assert n['id'] == i and all(type(p) is int and 0 <= p < i for p in n['parents'])
        roots = set(n['introduced_support'])
        for p in n['parents']:
            roots.update(ns[p]['support'])
        assert roots - set(n.get('discharged_support', [])) == set(n['support'])
        k, f, ps = n['kind'], n['formula'], n['parents']
        if k == 'qualified-published-trace-context-application':
            assert i == 0 and not ps
            for key in ['formula', 'property_template', 'quantified_parameters', 'support']:
                assert n[key] == selected['node'][key]
            assert n['accepted_bounded_formula'] == selected['bounded_formula']
            assert n['accepted_component_seal_sha256'] == exports['provenance']['seal_sha256']
            assert n['accepted_source_application_sha256'] == exports['provenance']['source_dag_sha256']
        elif k == 'qualified-source-schema-uniform-instance':
            name = 'engine-job-exponent-reset-base' if i == application['schema_nodes'][0] else 'engine-job-exponent-preserve'
            assert i in application['schema_nodes'] and not ps
            at = '1' if name.endswith('reset-base') else module.INDEX
            mapping = {'a': ['A', at], 'b': ['A', '1' if at == '1' else ['+', at, '1']], 'columns': ['COLUMNS', at]}
            assert n['uniform_mapping'] == mapping and n['original_query_goal'] == data['binding']['goals'][name]
            assert f == sub(n['original_query_goal'], mapping)
            assert n['original_query_sha256'] == data['plan']['queries'][name]['sha256']
            assert n['accepted_result_review_sha256'] == data['raw_pins']['review']
        elif k == 'actual-source-trace-projection':
            assert f[0] in ['|core_workflow_control_h|', '|core_workflow_control_t|']
            assert all(a[0] == 'A' for a in f[1:])
            if f[0].endswith('_t|'):
                assert f[2] == ['A', ['+', f[1][1], '1']]
        elif k == 'actual-common-reset-entry':
            assert f == ['not', ['|core_workflow_control_n reset_n|', ['A', '1']]]
            assert set(n['support']) == {'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-1'}
        elif k == 'conjunction-introduction':
            assert f == ['and', *[ns[p]['formula'] for p in ps]]
        elif k == 'conjunction-elimination':
            assert len(ps) == 1 and ns[ps[0]]['formula'][0] == 'and'
            assert 1 <= n['position'] < len(ns[ps[0]]['formula']) and f == ns[ps[0]]['formula'][n['position']]
        elif k == 'implication-elimination':
            assert len(ps) == 2 and ns[ps[0]]['formula'] == ['=>', ns[ps[1]]['formula'], f]
        elif k == 'literal-function-definition-instance':
            d = n['definition']
            assert d in [data['binding']['original_phase_invariant'], data['binding']['projected_control_definition']]
            assert set(n['uniform_mapping']) == {v[0] for v in d[2]}
            assert f == ['=', [d[1], *[n['uniform_mapping'][v[0]] for v in d[2]]], sub(d[4], n['uniform_mapping'])]
            assert not ps
        elif k == 'typed-equality-context-substitution':
            assert len(ps) == 2
            source, eq = (ns[p]['formula'] for p in ps)
            assert eq[0] == '=' and f in [replace(source, eq[1], eq[2]), replace(source, eq[2], eq[1])]
        elif k == 'uniform-global-trace-instantiation':
            assert ps[0] == 0 and n['index'] == module.INDEX and n['parameters'] == {'watch': '0'}
            assert f == sub(selected['node']['property_template'], {'@index': module.INDEX, 'watch': '0'})
        elif k == 'scoped-natural-index-domain':
            assert not ps and f == ['<=', '1', module.INDEX] and n['scope'] == module.FAMILY
            assert n['support'] == ['INDEX:' + module.FAMILY]
        elif k == 'scoped-induction-hypothesis':
            assert len(ps) == 1 and ns[ps[0]]['kind'] == 'scoped-natural-index-domain'
            assert f == ['eexp-I', ['A', module.INDEX]] and n['scope'] == module.INDEX
            assert set(n['support']) == {'INDEX:' + module.FAMILY, 'IH:' + module.FAMILY}
        elif k == 'ordinary-induction':
            assert i == application['global_node'] and n['fresh_step_index'] == module.INDEX
            assert n['property_template'] == ['eexp-I', ['A', '@index']] and n['quantified_parameters'] == []
            assert ps == [application['base_parent'], application['step_parent']]
            assert n['scoped_IH'] == application['IH_parent']
            assert ns[n['bound_parent']]['formula'] == ['<=', '1', module.INDEX]
            assert ns[n['scoped_IH']]['parents'] == [n['bound_parent']]
            assert ns[n['base_parent']]['formula'] == ['eexp-I', ['A', '1']]
            assert ns[n['step_parent']]['formula'] == ['eexp-I', ['A', ['+', module.INDEX, '1']]]
            assert f == ['forall', [[module.INDEX, 'Int']], ['=>', ['<=', '1', module.INDEX], ['eexp-I', ['A', module.INDEX]]]]
            assert set(n['support']) == set(exports['context'])
            assert set(n['discharged_support']) == {'INDEX:' + module.FAMILY, 'IH:' + module.FAMILY}
        else:
            raise AssertionError(('Unreviewed E scalar rule', i, k))
    control = ns[application['control_instance']]
    assert control['parents'][0] == 0
    for key, position in [('job_projection', 7), ('phase_projection', 8)]:
        n = ns[application[key]]
        assert n['parents'] == [control['id']] and n['position'] == position
    body = ns[application['unfolded_phase']]
    assert body['parents'] == [application['phase_projection'], application['phase_definition']]
    eight = application['eight_projection_parents']
    assert len(eight) == 8
    for p, position in zip(eight, range(1, 9)):
        assert ns[p]['parents'] == [body['id']] and ns[p]['position'] == position
    assert ns[application['eight_conjunction']]['parents'] == eight
    assert ns[application['projected_control_parent']]['parents'] == [application['eight_conjunction'], application['projected_control_definition']]
    assert ns[application['step_parent']]['parents'][1] in range(len(ns))
    indexed = {'A', 'C', 'COLUMNS', 'ROW', 'HEADER', 'GROUP', 'LAYOUT', 'CAPTURE', 'FRAME'}
    def visit_formula(x, allowed):
        if not isinstance(x, list):
            return
        if x and isinstance(x[0], str) and x[0] in indexed:
            assert len(x) == 2 and x[1] in allowed, (x, allowed)
        for t in x:
            visit_formula(t, allowed)
    def ancestry(seed, allowed):
        seen = set()
        def go(i):
            if i in seen:
                return
            seen.add(i)
            if i == 0:
                return
            visit_formula(ns[i]['formula'], allowed)
            for p in ns[i]['parents']:
                go(p)
        go(seed)
        return sorted(seen)
    base = ancestry(application['base_parent'], ['0', '1'])
    step = ancestry(application['step_parent'], [module.INDEX, ['+', module.INDEX, '1']])
    assert {application[k] for k in ['control_instance', 'job_projection', 'phase_projection', 'projected_control_parent', 'IH_parent']} <= set(step)
    n = 'n_engine_exponent_prefix'
    return {'kind': 'same-original-prefix-active-E-J-exponent', 'prefix_bound_domain': ['<=', '1', 'N'],
        'bounded_source_context': deepcopy(exports['prefix_artifact']['inherited_prefix_source_context']),
        'bounded_source_context_sha256': module.CONTEXT_SHA,
        'bounded_formula': ['forall', [[n, 'Int']], ['=>', ['and', ['<=', '1', n], ['<=', n, 'N']], ['eexp-I', ['A', n]]]],
        'base_locality_nodes': base, 'step_locality_nodes': step,
        'state_domain': ['and', ['<=', '1', n], ['<=', n, 'N']], 'edge_domain': ['and', ['<=', '1', n], ['<', n, 'N']],
        'source_supports': ns[application['global_node']]['support'], 'new_native_jobs': 0,
        'original_R0_or_UID_application_proved': False, 'read_metadata_postscale_selector_join_proved': False}

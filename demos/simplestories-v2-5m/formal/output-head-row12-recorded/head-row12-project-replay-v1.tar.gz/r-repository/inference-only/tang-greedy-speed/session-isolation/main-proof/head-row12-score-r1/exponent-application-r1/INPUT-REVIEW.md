# Independent original-prefix exponent application input review

**Decision: GO for the exact metadata-only gate first. If it passes with zero
Proof initializers/nodes, GO for one construction under the same exact frozen
inputs.** Any metadata or construction failure stops the affected gate with
its evidence; no silent repair/retry is authorized. Actual formula/support,
finite-prefix and byte-identical result review remain required afterward.
This static review constructs no proof and grants no original-prefix theorem.

## Exact final inputs and API boundary

| Input | SHA256 |
| --- | --- |
| PLAN.md | `ffb9166b10dbee10ceccdf88a4248d141f0ca4896f9dc936acacd7e39fb88ee4` |
| owner_application.py | `7a4d8b36ba683ba46eed21adb8c00bb82d76b5f78ef88471ce39a298cf0a10cd` |
| owner_prefix.py | `7f25e8c301f07ddbf5d3c52d2f9158d0d458079340739d26955413b8a72f53b1` |
| run_application.py | `6d8c3ec52856e4e0c24857da7f98124b0e88c980542c85579b1a4448593871fe` |
| RAW-INPUTS.json | `5ed3ec422a0062b48460e6ba94cf375c74ff5a92486a93f35b5706de00aa217e` |

The accepted envelope must contain exactly these five files and this review,
six local entries, under the driver's exact scope. All fifteen raw component
pins and four helper pins currently match their actual regular nonsymlink
files. The accepted owner/frame reviews are respectively `e19b07a4...` and
`b4f99e2c...`; the original STEP/row and current-CERT artifacts/seals/reviews
are fixed in that manifest, not selected during proof construction.

The driver uses the genuine accepted loader `fb45a71c...` and read-only auditor
`6f61975f...`. Metadata loading calls only their reviewed cheap export/API and
fixed pure preparation paths. It does not reconstruct the old large proof
graphs. The metadata-only branch returns before ValueProof allocation and
Proof initialization. The exact pinned installer API is
`install_current_globals(proof, language, exports, import_raw)`; the driver
now uses that signature. Its standalone typing text uses the accepted
check-sat/exit marker pattern solely as input to the pure typechecker. The
driver has no native solver/compiler call.

I statically parsed all three new Python files, inspected the actual pinned
helper/API definitions and all new code paths, and rehashed every raw/helper
input. I did not call a new module, metadata function, driver, constructor,
Proof initializer, old checker/writer, engine, compiler or agent. No parent
frozen/sealed file was modified.

## Qualified imports and fixed observer identities

The four existing imports remain the exact accepted control, capture, FRAME
and NF families. The two additional imports copy the full original STEP
global22 from its 46-node accepted graph and CERT global134 from its 135-node
accepted graph, retaining original templates, parameters, formulas, supports
and bounded counterparts. Their context is the unchanged six-root source
context at `bdb8c6c1...`; their finite-prefix context is exactly `41af6255...`.
Original seals bind both component applications and their result reviews.
There is no dropped antecedent or newly assumed historical INDEX.

The application carries accepted NF/FRAME total-definition anchors from the
fixed import preparation. It additionally pins original CERT zero36/step132
from the accepted 135-node graph, including their actual domain parent,
support, source index, equation and component identity. I independently
checked those CERT nodes against the pinned graph. The prefix auditor requires
every reused NF/FRAME/CERT equation to be exactly the corresponding anchor
under one uniform current-index substitution, including original source and
INDEX supports. HS is the sole new observer, with fixed zero/next functions;
it is not a redefinition of an existing NF or CERT history.

HS starts at `HS(1)=hs-zero(NF(1))`. Its recurrence uses the original A(n),
NF(n) and HS(n). NF, FRAME and CERT retain their exact original initial and
next equations. All helpers are literal accepted definitions; a source
function body or datatype selector cannot supply an unstated event/range fact.

## Two ordinary inductions and source application

The first induction is the conjunction of hs-I and the specialized strict-past
HS origin predicate. Base uses actual H(A1) and the original reset-low sample1,
then the literal HS zero equation. It does not insert a head reset or assume
accepted initialized payload. Preservation supplies actual H at n/n+1, full
T(n,n+1), qualified NF-I at both observations and the control component of
the exact joint IH. The successor NF is rewritten using its original accepted
recurrence, not supplied as a convenient value.

The origin step uses the whole accepted origin schema before projecting its
generic implication. Its ordered premise is the active natural bound, origin
component of that same joint IH, literal current actual-event equation and
NF(n)=NF(n) reflexivity. The fixed event is exactly effective head capture
on A(n), and the fixed record function uniformly becomes NF. No stamp or word
can choose another record function.

The clock is obtained from the accepted original STEP global, not from a
guessed NF timestamp. The recorded chain instantiates that global at n,
unfolds its exact predicate and NF observer, reduces only concrete declared
selectors and projects the clock conjunct. The prefix auditor ties the entire
chain to the imported STEP global and checks its ancestry. The separately
accepted clock implication is applied to that actual clock parent; its
equality projection rewrites generic-next at n to literal hs-next, and the HS
recurrence then supplies HS(n+1). These are ordinary checked MP/equality steps,
not a new clock axiom.

The second induction establishes hf-I for the same FRAME/CERT/HS functions.
Its base uses original FRAME/CERT zero equations. Its step supplies the actual
current/successor FRAME and preceding HS invariants, original current CERT
invariant, full H/T and its own hf-I IH in the native leaf's exact order. The
next columns and JobHistory are actual qualified provider arguments, not
future control promises. Literal NF/HS/FRAME/CERT recurrences rewrite the
conclusion to the fixed next property. No desired saved exponent, later
current-NF=CERT equality, future health or successful-use assumption is added.

Both globals use the already accepted ordinary close_factory with exact
HS/HF family/index/template, base/step/IH and domain anchors. The new prefix
auditor checks those fixed identities and support discharge, all parent IDs
preceding children, every restricted deduction kind, full deterministic
schema mappings and accepted bounded imports. Node count is capped at192.
The actual constructed graph must still pass independent result review.

## Function realization and finite-prefix boundary

Every schema records the same actual event, NF record and actual-origin
definitions. The generic `fj-capture-record-at` is uniformly realized by the
original qualified function of A(t), COLUMNS(t), FRAME(t), NF(t), t. Metadata
checks it against the original prefix's fixed function before word choice;
the driver permits only that disclosed UF-to-definition replacement in typing.
This uses validity of the accepted generic theorem for an arbitrary fixed
function interpretation. It does not assume a desired saved record or choose
a new function for each coordinate.

The finite-prefix auditor retains explicit `1<=N`, state conclusions1..N,
step domain1<=n<N, and the original bounded source context with states0..N
and defined edges0..N-1. New base ancestry permits only0/1; step ancestry
permits only n/n+1. The sole NFEMPTY(0) exception is the fixed original initial
parameter, not a source lookup. Qualified global stops retain their literal
accepted bounded exports. The newly completed HS family is a stop for HF
only after HS base/step locality has been checked.

The origin boundary checks exact generic recurrence/predicate ASTs and the
actual applied generic step. Revoke yields invalid history without a past
lookup. Current capture uses n, NF(n) and its actual event equation. Retain
uses the identical old stamp/payload/event/NF lookup under the same valid-IH
lower and strict-past bounds. Historical functions remain opaque at that
guarded boundary until a later application derives their bounds; no old
bounded-past helper, arbitrary allowed historical index, future source access
or infinite-extension assumption is introduced.

## Execution order, evidence and limits

Run the exact metadata-only gate first under the accepted deny-write/process/
network audit. Require zero initializers/nodes and complete actual read/helper
pins. Construction may follow only if that gate passes and the exact six-file
envelope still matches. It uses the accepted lightweight Proof/ValueProof,
SourceLanguage and close_factory; no old parent reconstruction or native job
is authorized.

Success returns the actual DAG, two bounded formulas, typing and complete
read/helper pins for later review. Failure now preserves partial nodes,
active indices, scope labels, index bindings, read pins, executed-helper pins
and explicit unread-helper paths, without claiming qualification. Existing
artifacts are never overwritten. A metadata/assertion/type/locality failure
requires its stopped record and a separately reviewed additive fix, not a
quiet retry.

This checkpoint targets two bounded owner/link invariants. It does not yet
apply the saved-exponent consequence at original j/k or identify the endpoint
R0 with that CERT record. The next current/row application must derive those
bounds and identities while retaining the original STEP/RMS/row provenance.
Registered read, actual metadata, postscale, held score, legal restored-
selector admission, numerical RMS, other rows and whole-device claims remain
open. No public, board or Lean action is involved.

# Independent produced current-CERT result review

Decision: **ACCEPT the exact 135-node current Mode/CERT application and its deterministic reconstruction.** The final CERT ordinary-induction global is checked on the original full-source schema. Finite-prefix export, a separately checked current FRAME endpoint, historical STEP/RMS/ROW applications, numerical RMS and whole-device conclusions remain unproved. A final component envelope/seal remains a separate binding step.

## Exact artifacts and successful input gate

| Artifact | SHA256 |
| --- | --- |
| `CURRENT-FRAME-INPUTS-R1.json` | `7a914ab7b05c662fd8e0f26f1d00625e03ec37be7e1b1fa42e34246e8534361c` |
| `CURRENT-FRAME-METADATA-R1.json` | `3710f9f041315818f163ebaf073190f37ed089f2b7e227ea9d57b95fa162d77f` |
| `CURRENT-FRAME-APPLICATION-R1.json` | `0c5b48b0dea544dceb362471488b9066c7515b135130960336426a5e6a37baba` |
| `CURRENT-FRAME-TYPING-ONLY-R1.smt2` | `457c6695744aab84db433a6a887981b1d173db30c45151873ff5a815393a3a19` |
| Reviewed driver | `c8ff1c2418b0b5232dd286189b5b489ad40406637c5327674933633ffa22236b` |
| Importer | `878c56e1cab0b91d562be141dea0c9ce6dcb7b50698241343b232a45b564a14b` |
| Mode helper | `d9bc93ed18500f7aa7208427b408fb3f5d8222017e083708e2cf69efde08dfdf` |
| CERT helper | `3e1d3e6f10e6be5e64d54ebd3a65180534c424e5817f91e13db68cc323bfec83` |
| Driver/input review | `137aca3d8ec2d3d89f245dc5154ffe7cbc01069a80c8420dd24faf46c30c6daa` |

All nine exact local envelope members match their reviewed hashes. The metadata gate and actual result bind the same envelope. The gate records passed=true, zero proof initializers, zero proof nodes and zero native jobs, with 61 actual read pins and 15 executed helper pins. The result records 62 reads and 17 helpers. Every result helper is covered by its read map, and all recorded result pins were independently rehashed before and after reconstruction.

## One independent read-only reconstruction

Using isolated/no-site/no-bytecode Python 3.12, I loaded the exact driver under a non-main module name and called its `construct()` exactly once. Its existing reviewed audit covered the genuine accepted loader, metadata checks, lightweight bootstrap, four imports, Mode, CERT, typing and final hashes. I did not invoke its writing main or save reconstructed outputs.

The returned full JSON object equals the saved application report exactly. Returned typing equals all 7,486,896 saved bytes exactly. An independent call profile used cached code-object/filename classifications, with no per-call filesystem resolution. It counted exactly one driver construction, one existing base Proof initializer, one SourceLanguage initializer, one fixed import installation, one current mode application and one current CERT application. Any other repository `construct`, `assemble`, `construct_nf` or repository initializer was rejected. No old heavy parent constructor, memory-specific ValueProof initializer, previous NF builder, solver/native job, guard, resource probe, simulation, Git or network action ran. Only this review file was written afterward.

The genuine pure checker reproduces 15,158 symbols, 135 assertions, one check command and passed=true at the saved typing hash. Those assertions are typing specimens, not free source assumptions or engine proofs of their conjunction. The accepted engine implications and checked finite application graph supply the proof argument.

## Imported theorem and source identities

Nodes 0–3 are exactly the accepted control 779, actual-capture 1051, actual-frame 1232 and original-NF 29 globals. Their formulas, templates, parameter lists and supports match the original pinned serialized artifacts. Original IDs occur only as provenance; the new imported nodes have no dangling old parents. Their original accepted bounded exports remain attached for later localization and are not used as permission to remove a bound.

Control/FRAME retain all six root supports. CAPTURE/NF retain their original source/low0 supports. The complete root context remains the exact full composed A/C source, low resets at 0 and 1, vendor storage, runtime-entry image and static metadata. Neither the smaller NF support nor the new small mode proof weakens that context to an arbitrary native-A trace or removes the external model/storage contracts.

The actual total-observer anchors match the accepted original records: COLUMNS 753/773, FRAME 1075/1096, NF 13/27, including their original positive-index domain parents. The new current observer equations are exact instances under uniform index renaming. Their separately accepted bounded bodies also match. This uses the original total nondriving construction definitions; no bounded `i<N` guard is eliminated.

## Checked graph and scope discharge

I independently walked every node's ID, parent order, introduced/inherited/discharged support and applicable rule shape. The graph contains four fixed imported globals, nine qualified implication instances, ten actual source projections, one original reset entry, five conjunction introductions, 72 conjunction eliminations, six MP applications, two current index scopes, two IHs, two ordinary closes, six observer equations, seven equality rewrites, seven current global instances, one sealed capture-projection import and one literal function-definition instance. All parent IDs precede their child; every support set recomputes exactly.

The new mode portion has 26 nodes and closes at node 29. Its accepted base uses actual I(A0), H(A0), H(A1), T(A0,A1) and low reset at A0. Preservation uses H/H'/full T and the scoped current ModeI IH. Base, IH and successor match one template. The close discharges only its actual IH/INDEX labels and retains source/low0 support. The old MODE_N export remains unchanged provenance; it was not promoted to an unbounded theorem.

CERT adds 105 nodes, giving 135 combined with the four imports and mode, below the 256-node cap. The following application interfaces were checked:

- Nodes 30 and 40 are complete uniform instances of the accepted Q conjunction: base, pure BV embedding and step. The arbitrary record-function declaration is specialized to the one typed actual record function, fixed independently of the word.
- The S import at node 48 is correctly conditional on its five original positive imported implications. Four have their exact accepted fixed-import provenance at nodes 41/42/46/47. The pure count embedding is projected from Q at the actual source count. Node 55 removes those five antecedents by checked conjunction/MP; it does not assume S unconditionally.
- Nodes 56–70 supply the actual current providers: control, actual CAPTURE and its exact sealed `c-base` JobHistory projection, H/H'/all native T, FRAME at prefix/write watches, the same NF at both watches, ModeI and the scoped current certificate IH. The assembled node 82 is exactly S's thirteen-provider antecedent. Width/count/watch agreement is derived inside S, not introduced as a new promise.
- COLUMNS and NF successor equations are folded at 97–100. The exact literal record-definition instance is node 101. Q's eight step antecedents are assembled at node 112, and node 121 is its checked MP result. The literal FRAME-next alias and original FRAME/CERT successor folds produce the exact successor template at node 133.

CERT's base is node 37, domain node 38 and sole current IH node 39. The base folds the independent original FRAME zero and `frc-zero(NFEMPTY(0))`. There is no empty(1) shift or reset at head launch. Node 134 has exactly the expected formula:

```text
forall w:BV8, i:Int.
    i>=1 => frc-I(V(i), FRAME(i), NF(i), CERT(i), i, w)
```

Base 37, IH 39 and successor 133 are exact instances of that one template. The fresh index does not occur in the template or base. The close discharges only `IH:original-current-frame-RMS-certificate` and `INDEX:original-current-frame-RMS-certificate`. Its support is exactly the six original roots; no IH or INDEX label escapes. The previously closed mode scope also does not escape into CERT support.

## One fixed record and exact remaining limits

The actual record function contains A/COLUMNS/FRAME/NF at its one record index and contains neither CERT nor the watched word. NF, NFEMPTY, FRAME and CERT are unary fixed histories; the recurrences have no watch argument. CERT captures the entire pre-edge NF and retains Q's original current drop/begin priority, strict partial cursor range, complete-frame independence from current NF and certificate availability clauses. The accepted invariant is therefore one common certificate/history statement, not separately chosen origins for different words.

This accepts the ordinary current CERT invariant on its full-source schema. It does not yet export that family on states 1..N using only edges ending by N, derive a separately checked live complete-FRAME endpoint, unfold a saved record at a historical term, establish original stamped STEP/RMS occurrences or join ROWFRAME. In particular, the full Q instance contains an unused base conjunct with the original fixed `NFEMPTY(0)` parameter; its treatment by a later locality checker remains a separate explicitly reviewed classification, not a reason to grant general observation-0 access during a step.

The result's false flags for finite-prefix, endpoint, historical, numerical and whole-device claims are correct and remain unchanged. The saved pending-review flag records creation before this additive review. The eventual component replay envelope must bind these exact inputs, gate, result, typing, code and reviews; no successor theorem is qualified by this acceptance.

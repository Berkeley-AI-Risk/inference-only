# Same original row: saved RMS exponent and snapshot words

Unrun zero-engine consequence under the independently reviewed root plan
ORIGINAL-ROW-EXPONENT-APPLICATION-PLAN.md and reviewee0c10c5. Budget192nodes,
no new induction or history. Its all256-word conclusion concerns the retained
ROWFRAME snapshot, not unconsumed rr-a entries when row count is merely>0.

At current n, derive valid snapshot/original UID and episode from the qualified
saved-row-frame state invariant. The historical-frame-origin state theorem
gives1<=j<n; accepted integer order gives j<=N before historical source accesses.
Unfold the original record-at-j and literal constructor only after those bounds.
Its capture gives actual J-live/head/E WEIGHTS through the accepted adjudicated
row-capture guard at j. Apply the accepted104-node current-E/R0 consequence at
j. Apply accepted19-node physical continuity at n; unfold the one fixed actual
EXP_AT function at defined j and compose to R0(j).exp.

Preserve the original capture theorem global165 scalar/event payload literally
at j, including original k/p/r, UID/parent/prefix and their existing bounds.
After the scalar proof, choose one fresh BV8 word, retain the full original
capture result and rewrite only its f-data(FRAME(j)) to current snapshot data.
All words and the current E exponent name the same endpoint-saved-NF(j).

Exact static input review/six-file freeze before metadata0 and one construction.
Audit every rule/support, original bounded import/schema, j lookup ledger,
word-independent scalar prefix and literal old payload. No historical INDEX,
future/edge provider, current-NF replacement, new source application at carried
p/r points or success-health filter. Current n may be N; no current edge needed.
Pure typing and independent complete JSON/typing replay; save full stopped DAG,
scope/index/read/helper evidence on any unexpected assertion. Additive reviewed
versions only; no old builder/check-writer/proof reconstruction or native rerun.

Current accumulator completion, actual read/tag/globalrow12 ownership, model
metadata/range, postscale/hold, first-fault/CLEAR classification and actual legal
selector admission remain later obligations. No whole-device or public claim.

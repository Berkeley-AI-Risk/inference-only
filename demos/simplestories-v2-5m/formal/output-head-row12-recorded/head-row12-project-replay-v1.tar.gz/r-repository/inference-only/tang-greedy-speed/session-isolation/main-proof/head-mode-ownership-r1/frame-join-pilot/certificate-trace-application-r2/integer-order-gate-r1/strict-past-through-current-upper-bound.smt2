; PREPARATION ONLY: one source-free LIA implication, no native source or history premise.
(declare-const past Int)
(declare-const current Int)
(declare-const bound Int)
(assert (not (=> (and (< past current) (<= current bound)) (<= past bound))))
(check-sat-using (then simplify propagate-values solve-eqs simplify smt))
(exit)

if not __debug__:raise RuntimeError('Optimization forbidden')
from pathlib import Path
import sys,os,json,hashlib,math,datetime
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
REPO=ROOT.parents[3]
sys.path.insert(0,str(HERE))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rd=lambda p:json.loads(p.read_bytes())
guarded=False
reads=set()
def audit(event,args):
    if not guarded:return
    if event=='open':
        mode=args[1] if len(args)>1 else None;flags=args[2] if len(args)>2 else 0
        if isinstance(mode,str) and any(c in mode for c in 'wax+'):raise RuntimeError('Writable replay open')
        if isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):raise RuntimeError('Writable replay flags')
        if isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.fsdecode(args[0])).resolve()
            if p.is_relative_to(REPO) and p.is_file():reads.add(p)
    if event.startswith(('subprocess.','socket.')) or event in [
        'os.system','os.fork','os.exec','os.spawn','os.posix_spawn','os.mkdir',
        'os.remove','os.rmdir','os.rename','os.link','os.symlink','os.truncate','os.chmod','os.utime']:
        raise RuntimeError('Replay mutation/process/network: '+event)
sys.addaudithook(audit)
def helpers():
    found={Path(__file__).resolve()}
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if isinstance(name,str):
            p=Path(name).resolve()
            if p.is_relative_to(REPO) and p.is_file():found.add(p)
    return found
def dt(x):return datetime.datetime.fromisoformat(x)

def recorded_run(folder,journal,expected_argv,stop_reason=None):
    start=rd(folder/'STARTED.json');finish=rd(folder/'FINISHED.json');monitor=rd(folder/'MONITOR-BINDING.json')
    assert start['argv']==finish['argv']==expected_argv
    assert start['pid']==start['pgid']==finish['pid']==finish['pgid']>0
    assert start['started_utc']==finish['started_utc']
    assert start['kernel_CPU_soft_seconds'] is start['kernel_CPU_hard_seconds'] is None
    assert start['maximum_seconds'] is start['stage_CPU_cap_seconds'] is start['stage_wall_cap_seconds'] is None
    assert start['disk_floor_bytes']==0
    assert finish['resource_stop_reason']==stop_reason and not finish['monitor_errors']
    assert finish['single_process_required']==start['single_process_required']
    assert finish['native_exit']==(0 if stop_reason is None else -15)
    assert finish['raw_wait_status']==(0 if stop_reason is None else 15)
    for key in ['CPU_user_seconds','CPU_system_seconds','wall_seconds']:
        assert math.isfinite(finish[key]) and finish[key]>=0
    assert dt(finish['finished_utc'])>dt(finish['started_utc'])
    assert finish['log']['sha256']==sha(folder/'NATIVE.log')
    assert finish['log']['bytes']==(folder/'NATIVE.log').stat().st_size
    assert monitor['observation_journal_sha256']==sha(journal)
    rows=[json.loads(line) for line in journal.read_text().splitlines()]
    assert rows and rows[0]['kind']=='admission' and rows[0]['pressure']==1
    assert rows[0]['argv']==expected_argv and rows[0]['memory_cap_bytes']==start['memory_cap_bytes']
    assert rows[0]['single_process']==start['single_process_required']
    assert [dt(r['utc']) for r in rows]==sorted(dt(r['utc']) for r in rows)
    pressures=[r for r in rows if r['kind']=='pressure']
    assert pressures and all(r['pressure']==1 for r in pressures)
    groups=[r for r in rows if r['kind']=='owned-group']
    assert groups and monitor['group_observations']==len(groups)
    assert not groups[-1]['members']
    identities={};observed=set();max_rss=max_foot=max_group=0
    for row in groups:
        assert row['pgid']==start['pgid']
        assert row['group_RSS_bytes']==sum(r['rss_bytes'] for r in row['members'])
        assert row['group_footprint_bytes']==sum(r['footprint_bytes'] for r in row['members'])
        for member in row['members']:
            observed.add(member['pid'])
            if member['rss_bytes'] or member['footprint_bytes']:
                key=str(member['pid']);value=member['start_abstime'];assert value>0
                assert identities.get(key,value)==value;identities[key]=value
            assert member['rss_bytes']>=0 and member['footprint_bytes']>=0
        max_rss=max(max_rss,row['group_RSS_bytes']);max_foot=max(max_foot,row['group_footprint_bytes'])
        max_group=max(max_group,len(row['members']))
    assert observed==set(finish['observed_owned_pids'])
    assert identities==monitor['observed_start_identities']
    assert monitor['admission_pressure']==1 and monitor['no_time_or_CPU_kill']
    assert not monitor['canonical_simulation_reservation_claimed']
    assert monitor['guard_source_sha256']==rd(HERE/'GUARD-SOURCE.json')['sha256']
    if stop_reason is None:
        assert max_group==1 and set(identities)=={str(start['pid'])}
        assert 0<max_rss<=start['memory_cap_bytes']==4*(1<<30)
        assert 0<max_foot<=start['memory_cap_bytes']
        assert 0<finish['wait4_maxrss_bytes']<=start['memory_cap_bytes']
    elif stop_reason=='per-process resident/footprint cap':
        assert max_rss>start['memory_cap_bytes'] or max_foot>start['memory_cap_bytes']
    elif stop_reason=='unexpected native helper process':assert max_group>1
    else:raise AssertionError('Unexpected stop reason')
    return start,finish,monitor

def check():
    global guarded
    assert not guarded;guarded=True
    try:
        loaded=helpers();freeze=rd(HERE/'FROZEN-MODE-INPUTS.json');external=rd(HERE/'EXTERNAL-MODE-PINS.json')
        accepted=rd(HERE/'MODE-REVIEW-ACCEPTED.json')
        assert accepted['accepted'] and accepted['frozen_sha256']==sha(HERE/'FROZEN-MODE-INPUTS.json')
        assert accepted['external_pins_sha256']==sha(HERE/'EXTERNAL-MODE-PINS.json')
        for n,h in accepted['reviews'].items():assert sha(HERE/n)==h,n
        for n,h in freeze['files'].items():assert sha(HERE/n)==h,n
        for n,h in external.items():assert sha(REPO/n)==h,n
        assert sha(HERE/'MODE-RESULT-REVIEW.md')=='148aeedf61841506948354168d35b99538452ccc8e49f2dbdd4a7620db6e5455'
        import prepare_mode,mode_application,output_check
        from support import parse_spans
        queries,plan,binding,types=prepare_mode.assemble()
        assert plan==rd(HERE/'QUERY-PLAN.json') and binding==rd(HERE/'MODE-BINDING.json')
        assert types==rd(HERE/'TYPE-CHECK.json')
        spec,application=mode_application.construct(binding)
        assert spec==(HERE/'SOURCE-TRACE-SPECIFICATION.smt2').read_bytes()
        assert application==rd(HERE/'SOURCE-TRACE-APPLICATION.json')
        combined=rd(HERE/'MODE-CHECKPOINT.json');launch=rd(HERE/'MODE-ENGINE-START.json')
        assert combined['all_expected_results_matched'] and combined['active_owned_job'] is None
        assert combined['positive_reset_write_witness_pending'] and not combined['milestone_qualified']
        assert launch['workers']==1 and launch['order']==plan['order']
        assert launch['RSS_and_physical_footprint_cap_bytes']==4*(1<<30)
        assert launch['host_pressure_required']==1 and not launch['time_kill_enabled']
        assert launch['Z3_internal_memory_MB']==4096 and not launch['canonical_simulation_reservation_claimed']
        tool=rd(ROOT/'argmax-provider-pilot-r1/TOOLS.json')['tools']['z3']
        assert tool['sha256']=='ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102'
        assert sha(Path(tool['path']))==tool['sha256']
        assert rd(HERE/'TOOL-PIN-CLARIFICATION.json')['tool']==tool
        assert len(combined['completed'])==len(plan['order'])==3
        results={};pids=set();previous_end=None
        for i,name in enumerate(plan['order']):
            assert queries[name]==(HERE/(name+'.smt2')).read_bytes()
            assert plan['queries'][name]['sha256']==sha(HERE/(name+'.smt2'))
            folder=HERE/'mode-runs'/name;result=rd(folder/'CHECKED-RESULT.json')
            assert result==combined['completed'][i]
            assert result['query_sha256']==plan['queries'][name]['sha256']
            assert result['binary_sha256']==tool['sha256'] and result['expected_result_matched']
            assert result['stdout_parse_error'] is None and result['positive_reset_write_witness_pending']
            assert not result['milestone_qualified'] and not result['whole_device_theorem']
            assert not result['whole_frame_or_ROWFRAME_join_proved']
            argv=[tool['path'],'-smt2','-st','-memory:4096',str(HERE/(name+'.smt2'))]
            assert result['command']==argv
            started,finished,monitor=recorded_run(folder,HERE/'mode-runs'/(name+'-observations.jsonl'),argv)
            assert result['receipt']==finished and result['monitor_binding']==monitor
            if previous_end:assert previous_end<=dt(started['started_utc'])
            previous_end=dt(finished['finished_utc']);assert started['pid'] not in pids;pids.add(started['pid'])
            forms=[x for x,_,_ in parse_spans((folder/'NATIVE.log').read_bytes())]
            assert output_check.accept(forms,'unsat',[]) and result['answer']==result['expected']=='unsat'
            results[name]={'answer':'unsat','query_sha256':result['query_sha256'],
                'wall_seconds':finished['wall_seconds'],'native_waited_and_reaped':True}
        probe=rd(HERE/'GUARD-PROBES.json');assert probe['passed'] and probe['post_stop_cleanup']['passed']
        assert not probe['post_stop_cleanup']['signals_sent_after_reaping']
        for label,reason in [('memory','per-process resident/footprint cap'),('helper','unexpected native helper process')]:
            _,finished,monitor=recorded_run(HERE/'guard-probes'/label,HERE/'guard-probes'/(label+'-observations.jsonl'),
                probe[label+'_probe']['argv'],reason)
            assert finished==probe[label+'_probe'] and monitor in probe['monitor_bindings']
            cleanup=probe['post_stop_cleanup'][label+'_probe']
            assert {str(r['pid']):r['original_start_abstime'] for r in cleanup}==monitor['observed_start_identities']
            assert all(not r['live_original_process'] and r['status'] in ['absent','different-start-identity'] for r in cleanup)
        loaded.update(helpers());closure=(HERE/'FROZEN-REPLAY-INPUTS.json').exists()
        if closure:
            replay=rd(HERE/'FROZEN-REPLAY-INPUTS.json');review=rd(HERE/'REPLAY-ACCEPTED.json')
            assert review['accepted'] and review['scope']=='three-mode-induction-obligations-and-conditional-word-corollary'
            assert review['frozen_sha256']==sha(HERE/'FROZEN-REPLAY-INPUTS.json')
            assert review['review_sha256']==sha(HERE/'REPLAY-REVIEW.md')
            assert review['checker_sha256']==sha(HERE/'check_mode.py')
            for n,h in replay['files'].items():assert sha(HERE/n)==h,n
            covered={(HERE/n).resolve() for n in replay['files']}|{(REPO/n).resolve() for n in external}
            covered.update(HERE/n for n in ['FROZEN-REPLAY-INPUTS.json','REPLAY-ACCEPTED.json'])
            assert reads|loaded<=covered,('Unfrozen read/helper',sorted(str(p) for p in (reads|loaded)-covered))
        return {'passed':True,'results':results,'ordinary_induction_schema_checked':True,
            'literal_event_mode_cut_discharge_checked':True,'specimen_sha256':hashlib.sha256(spec).hexdigest(),
            'independent_replay_review_bound':closure,'new_engine_jobs':0,
            'positive_reset_write_witness_pending':True,'milestone_qualified':False,
            'whole_frame_or_ROWFRAME_join_proved':False,'RMS_numerical_meaning_proved':False,
            'private_RMS_qualification_upgraded':False,'whole_device_theorem':False,'Lean_used':False,
            'actual_read_pins':{str(p.relative_to(REPO)):sha(p) for p in sorted(reads)},
            'loaded_repo_helper_pins':{str(p.relative_to(REPO)):sha(p) for p in sorted(loaded)}}
    finally:guarded=False

if __name__=='__main__':
    report=check()
    (HERE/'CHECK-MODE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['actual_read_pins','loaded_repo_helper_pins']}))

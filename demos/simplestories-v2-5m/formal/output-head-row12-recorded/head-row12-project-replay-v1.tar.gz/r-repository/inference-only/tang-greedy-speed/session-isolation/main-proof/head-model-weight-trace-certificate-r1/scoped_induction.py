if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import transport_certificate
from row_terms import *
from support import smt,atoms,parse_spans
sha=lambda b:hashlib.sha256(b).hexdigest()


def replace_exact(x,old,new):
    if x==old:return new
    return x if isinstance(x,str) else [replace_exact(v,old,new) for v in x]


class Proof:
    def __init__(self,draft):
        self.draft=draft;self.nodes=[];self.global_nodes={}
        self.active_indices={}
        self.index_bindings={};self.scope_labels=set()
        self.root_context={
            'Gamma:actual-composed-source':{'kind':'actual-named-composed-RTL-execution',
                'domain':'Full source composition including the published custom memory path, not arbitrary core/cache input traces.',
                'free_parameters':['named-full-execution','A','C'],
                'native_core_sha256':'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54',
                'native_cache_sha256':'315317846d411305feb9873087b1d4ab2074239461cc4c281872de711964dab9',
                'source_projection_parent':'HEAD-MODEL-WEIGHT-STORAGE-APPLICATION-R1-SEALED.json',
                'formal_native_consequences':[
                    c('|core_workflow_control_i|',c('A','0')),c('|board1_verified_ddr_page_service_i|',c('C','0')),
                    ['forall',[['n_source','Int']],IMP(c('<=','0','n_source'),AND(
                        c('|core_workflow_control_h|',c('A','n_source')),c('|board1_verified_ddr_page_service_h|',c('C','n_source')),
                        c('|core_workflow_control_t|',c('A','n_source'),c('A',c('+','n_source','1'))),
                        c('|board1_verified_ddr_page_service_t|',c('C','n_source'),c('C',c('+','n_source','1'))),
                        c('interface-bindings',c('A','n_source'),c('C','n_source'))))]]},
            'Gamma:entry-reset-low-at-0':{'formula':NOT(n('reset_n',c('A','0')))},
            'Gamma:entry-reset-low-at-1':{'formula':NOT(n('reset_n',c('A','1')))}}
        self.observers={
            'api':{'symbol':'API','source':'A','zero':'api-zero','next':'api-next','parameters':[]},
            'cache':{'symbol':'X','source':'C','zero':c('cacheorder-zero','slot'),'next':'cacheorder-next','parameters':['slot']},
            'request':{'symbol':'REQUEST','source':'C','zero':'request-zero','next':'request-next','parameters':[]},
            'service':{'symbol':'SERVICE','source':'C','zero':'service-zero','next':'service-next','parameters':['slot'],'next_extra_parameters':['slot']}}

    def add(self,kind,formula,parents=(),support=(),**details):
        ids=list(parents)
        assert all(isinstance(i,int) and 0<=i<len(self.nodes) for i in ids)
        inherited=set(support)
        assert inherited<=set(self.root_context)|self.scope_labels,('undeclared support',kind,inherited)
        for i in ids:inherited.update(self.nodes[i]['support'])
        node={'id':len(self.nodes),'kind':kind,'formula':formula,'parents':ids,
            'introduced_support':list(support),'support':sorted(inherited),**details}
        self.nodes.append(node);return node['id']

    def index_support(self,index,positive=False):
        if isinstance(index,str) and index.isdigit():
            assert int(index)>=(1 if positive else 0)
            return []
        if isinstance(index,str):
            assert index in self.active_indices,('Unbound natural step index',index)
            return [self.active_indices[index]['label']]
        assert isinstance(index,list) and len(index)==3 and index[0]=='+' and index[2]=='1'
        return self.index_support(index[1],False)

    def index_parents(self,index):
        if isinstance(index,str) and index.isdigit():return []
        if isinstance(index,str):return [self.active_indices[index]['node']]
        return self.index_parents(index[1])

    def open_index(self,name,index):
        assert index not in self.index_bindings and index not in self.active_indices
        assert index not in set().union(*(atoms(x.get('formula',[])) for x in self.root_context.values()))
        assert index not in atoms(self.root_context['Gamma:actual-composed-source']['formal_native_consequences'])
        assert index not in atoms([v['zero'] for v in self.observers.values()])
        label='INDEX:'+name;self.scope_labels.update([label,'IH:'+name])
        node=self.add('scoped-natural-index-domain',c('<=','1',index),support=[label],scope=name)
        entry={'label':label,'node':node,'name':name}
        self.active_indices[index]=entry;self.index_bindings[index]=entry
        return node

    def source(self,formula):
        # These are semantic projections of the actual pinned source trace,
        # never invariant/value hypotheses added at the module boundary.
        head=formula[0]
        if head=='not':
            term=formula[1]
            assert term[0] in ['|core_workflow_control_n reset_n|','|board1_verified_ddr_page_service_n reset_n|']
            index=term[1][1];assert index in ['0','1']
            assert term[1][0]==('A' if term[0].startswith('|core_') else 'C')
            if term[0].startswith('|board1_'):
                root=self.source(NOT(n('reset_n',c('A',index))))
                binding=self.source(c('interface-bindings',c('A',index),c('C',index)))
                assert self.draft['root_and_arbiter_reset_getters_identical_after_parameter_renaming']
                equality=self.add('checked-physical-reset-binding-and-literal-getter-alias',
                    eq(term,n('reset_n',c('A',index))),[binding])
                return self.add('Boolean-equality-substitution',formula,[root,equality])
            return self.add('actual-common-reset-entry',formula,support=['Gamma:actual-composed-source','Gamma:entry-reset-low-at-'+index])
        assert head in ['|core_workflow_control_i|','|core_workflow_control_h|','|core_workflow_control_t|',
            '|board1_verified_ddr_page_service_i|','|board1_verified_ddr_page_service_h|','|board1_verified_ddr_page_service_t|','interface-bindings']
        if head=='interface-bindings':
            assert formula[1][0]=='A' and formula[2][0]=='C' and formula[1][1]==formula[2][1]
        else:
            assert formula[1][0]==('A' if head.startswith('|core_') else 'C')
        if head.endswith('_i|'):assert formula[1][1]=='0'
        if head.endswith('_t|'):
            a,b=formula[1:];assert a[0]==b[0] and b[1] in ['1',c('+',a[1],'1')]
            if b[1]=='1':assert a[1]=='0'
        support=['Gamma:actual-composed-source']
        for state in formula[1:]:support.extend(self.index_support(state[1]))
        parents=[]
        for state in formula[1:]:parents.extend(self.index_parents(state[1]))
        return self.add('actual-source-trace-projection',formula,list(dict.fromkeys(parents)),support=support)

    def observation(self,which,index,step=False):
        obs=self.observers[which]
        at=lambda i:c(obs['symbol'],*obs['parameters'],i)
        if step:
            bound=self.index_support(index,True)
            lhs=at(c('+',index,'1'));rhs=c(obs['next'],c(obs['source'],index),at(index),*obs.get('next_extra_parameters',[]))
        else:
            assert index=='1';bound=[];lhs=at('1');rhs=obs['zero']
        parents=self.index_parents(index) if step else []
        return self.add('total-observer-definition',eq(lhs,rhs),parents,support=['Gamma:actual-composed-source',*bound],registry=which,step=step,index=index)

    def rewrite(self,node,equality,old,new):
        e=self.nodes[equality]['formula'];assert e in [eq(old,new),eq(new,old)]
        return self.add('typed-equality-context-substitution',replace_exact(self.nodes[node]['formula'],old,new),[node,equality])

    def apply(self,rule,parents):
        assert [self.nodes[i]['formula'] for i in parents]==rule['premises'],('unmatched source application',rule.get('name'))
        return self.add('qualified-source-schema-application',rule['conclusion'],parents,source_rule=rule)

    def source_instance(self,rule,mapping):
        return {**rule,'premises':[SUB(x,mapping) for x in rule['premises']],
            'conclusion':SUB(rule['conclusion'],mapping),'extra_uniform_mapping':mapping}

    def instantiate_global(self,name,index):
        parent=self.global_nodes[name];node=self.nodes[parent]
        assert node['kind']=='ordinary-induction'
        bound=self.index_support(index,True)
        formula=SUB(node['property_template'],{'@index':index})
        return self.add('uniform-global-trace-instantiation',formula,[parent,*self.index_parents(index)],support=bound,index=index)

    def close_induction(self,name,template,base,step,index,ih):
        assert self.nodes[base]['formula']==SUB(template,{'@index':'1'})
        assert self.nodes[ih]['formula']==SUB(template,{'@index':index})
        assert self.nodes[step]['formula']==SUB(template,{'@index':c('+',index,'1')})
        assert self.nodes[ih]['kind']=='scoped-induction-hypothesis'
        assert self.nodes[ih]['scope']==index
        label='IH:'+name
        bound='INDEX:'+name
        assert self.active_indices[index]==self.index_bindings[index]
        assert self.active_indices[index]['name']==name and self.active_indices[index]['label']==bound
        bound_node=self.active_indices[index]['node']
        assert self.nodes[bound_node]['formula']==c('<=','1',index)
        assert self.nodes[bound_node]['kind']=='scoped-natural-index-domain'
        assert self.nodes[ih]['parents']==[bound_node]
        assert set(self.nodes[ih]['support'])=={label,bound}
        assert label not in self.nodes[base]['support']
        assert set(self.nodes[base]['support'])<=set(self.root_context)
        assert set(self.nodes[step]['support'])<=set(self.root_context)|{label,bound}
        assert index not in atoms(self.nodes[base]['formula'])
        assert index not in atoms(template)
        support=sorted((set(self.nodes[base]['support'])|set(self.nodes[step]['support']))-{label,bound})
        parameters=[['slot',['_','BitVec','5']]] if 'slot' in atoms(template) else []
        for parameter,_ in parameters:
            assert parameter not in atoms(self.root_context['Gamma:actual-composed-source']['formal_native_consequences'])
            assert parameter not in set(self.root_context['Gamma:actual-composed-source']['free_parameters'])
        formula=['forall',[*parameters,[index,'Int']],IMP(c('<=','1',index),SUB(template,{'@index':index}))]
        result=self.add('ordinary-induction',formula,[base,step],
            base_parent=base,step_parent=step,scoped_IH=ih,fresh_step_index=index,property_template=template,
            bound_parent=bound_node,quantified_parameters=parameters,scoped_hypothesis_removed=True)
        self.nodes[result]['support']=support
        self.nodes[result]['discharged_support']=[label,bound]
        self.global_nodes[name]=result;return result

    def common_history(self):
        name='common-history';index='n_common'
        template=c('interface-history-equal',c('API','@index'),c('X','slot','@index'))
        proto=self.draft['interface_rule_instances']
        base=self.apply(proto['common-zero'],[])
        for which in ['api','cache']:
            equality=self.observation(which,'1')
            base=self.rewrite(base,equality,self.nodes[equality]['formula'][2],self.nodes[equality]['formula'][1])
        bound=self.open_index(name,index)
        ih=self.add('scoped-induction-hypothesis',SUB(template,{'@index':index}),[bound],support=['IH:'+name],scope=index)
        mapping={'A':c('A',index),'C':c('C',index),'api':c('API',index),'cache':c('X','slot',index)}
        r=self.source_instance(proto['common-step'],mapping)
        parents=[self.source(x) if x!=self.nodes[ih]['formula'] else ih for x in r['premises']]
        step=self.apply(r,parents)
        for which in ['api','cache']:
            equality=self.observation(which,index,True)
            step=self.rewrite(step,equality,self.nodes[equality]['formula'][2],self.nodes[equality]['formula'][1])
        result=self.close_induction(name,template,base,step,index,ih)
        del self.active_indices[index]
        return result

    def slot_constancy(self):
        name='slot-constant';index='n_slot';template=eq(c('c-slot',c('X','slot','@index')),'slot')
        path=ROOT/'head-model-weight-storage-application-r1/OBSERVER-PROJECTION.json'
        laws=json.loads(path.read_bytes())['six_exact_laws']
        receipt_path=path.parent/'runs/cacheorder-total-published-observer-projections/RESULT.json'
        receipt=json.loads(receipt_path.read_bytes())
        assert receipt['answer']=='unsat' and receipt['expected_result_matched']
        provider={'packet':path.parent.name,'query_sha256':receipt['query_sha256'],
            'receipt_sha256':sha(receipt_path.read_bytes()),'all_six_laws':laws}
        assert laws[0]==eq(c('c-slot',c('cacheorder-zero','slot')),'slot')
        base=self.add('qualified-total-observer-law',laws[0],source=provider,law_index=0)
        zero=self.observation('cache','1')
        base=self.rewrite(base,zero,self.nodes[zero]['formula'][2],self.nodes[zero]['formula'][1])
        bound=self.open_index(name,index)
        ih=self.add('scoped-induction-hypothesis',SUB(template,{'@index':index}),[bound],support=['IH:'+name],scope=index)
        instance=SUB(laws[3],{'svc':c('C',index),'ch':c('X','slot',index)})
        step=self.add('qualified-total-observer-law',instance,source=provider,law_index=3,
            uniform_mapping={'svc':c('C',index),'ch':c('X','slot',index)})
        nxt=self.observation('cache',index,True)
        step=self.rewrite(step,nxt,self.nodes[nxt]['formula'][2],self.nodes[nxt]['formula'][1])
        step=self.rewrite(step,ih,self.nodes[ih]['formula'][1],self.nodes[ih]['formula'][2])
        result=self.close_induction(name,template,base,step,index,ih)
        del self.active_indices[index]
        return result

    def observer_projection(self,which):
        assert which in ['request','service']
        is_service=which=='service';field='c-service' if is_service else 'c-requests'
        symbol='SERVICE' if is_service else 'REQUEST'
        other=lambda i:c(symbol,*(['slot'] if is_service else []),i)
        name=which+'-projection';index='n_'+which
        template=eq(c(field,c('X','slot','@index')),other('@index'))
        packet=ROOT/'head-model-weight-storage-application-r1'
        laws=json.loads((packet/'OBSERVER-PROJECTION.json').read_bytes())['six_exact_laws']
        receipt_path=packet/'runs/cacheorder-total-published-observer-projections/RESULT.json'
        receipt=json.loads(receipt_path.read_bytes())
        assert receipt['answer']=='unsat' and receipt['expected_result_matched']
        provider={'packet':packet.name,'query_sha256':receipt['query_sha256'],'receipt_sha256':sha(receipt_path.read_bytes()),'all_six_laws':laws}
        zero_index=2 if is_service else 1;next_index=5 if is_service else 4
        base=self.add('qualified-total-observer-law',laws[zero_index],source=provider,law_index=zero_index)
        for observer in ['cache',which]:
            definition=self.observation(observer,'1')
            base=self.rewrite(base,definition,self.nodes[definition]['formula'][2],self.nodes[definition]['formula'][1])
        bound=self.open_index(name,index)
        ih=self.add('scoped-induction-hypothesis',SUB(template,{'@index':index}),[bound],support=['IH:'+name],scope=index)
        mapping={'svc':c('C',index),'ch':c('X','slot',index)}
        step=self.add('qualified-total-observer-law',SUB(laws[next_index],mapping),source=provider,law_index=next_index,uniform_mapping=mapping)
        nxt=self.observation('cache',index,True)
        step=self.rewrite(step,nxt,self.nodes[nxt]['formula'][2],self.nodes[nxt]['formula'][1])
        step=self.rewrite(step,ih,self.nodes[ih]['formula'][1],self.nodes[ih]['formula'][2])
        if is_service:
            slot=self.instantiate_global('slot-constant',index)
            step=self.rewrite(step,slot,self.nodes[slot]['formula'][1],self.nodes[slot]['formula'][2])
        nxt=self.observation(which,index,True)
        step=self.rewrite(step,nxt,self.nodes[nxt]['formula'][2],self.nodes[nxt]['formula'][1])
        result=self.close_induction(name,template,base,step,index,ih)
        del self.active_indices[index]
        return result

    def family(self,name):
        obj=self.draft['family_step_applications'][name]
        cache=name=='cacheorder';src='C' if cache else 'A';hist='cache' if cache else 'api'
        symbol='X' if cache else 'API';parameters=['slot'] if cache else []
        at=lambda t:c(symbol,*parameters,t)
        state=lambda t:c(src,t)
        inv=lambda t: c(name+'-inv',state(t),at(t),*(['model'] if name=='payload' else []))
        template=inv('@index');index='n_'+name
        base_rule=self.source_instance(obj['base_instance'],{src:state('0'),src+'n':state('1')})
        base_parents=[self.source(x) for x in base_rule['premises']]
        base=self.apply(base_rule,base_parents)
        zero=self.observation('cache' if cache else 'api','1')
        base=self.rewrite(base,zero,self.nodes[zero]['formula'][2],self.nodes[zero]['formula'][1])
        bound=self.open_index(name,index)
        ih=self.add('scoped-induction-hypothesis',inv(index),[bound],support=['IH:'+name],scope=index)
        mapping={src:state(index),src+'n':state(c('+',index,'1')),hist:at(index)}
        context={smt(self.nodes[ih]['formula']):ih}
        for term in obj['step_context']:
            term=SUB(term,mapping);key=smt(term)
            if key in context:continue
            if term[0]=='api-inv':parent=self.instantiate_global('api',index)
            elif term[0]=='interface-word-to-layer':
                assert 'interface-word' in self.global_nodes,'Interface word must be independently proved before payload induction'
                parent=self.instantiate_global('interface-word',index)
            else:parent=self.source(term)
            assert self.nodes[parent]['formula']==term
            context[key]=parent
        conclusion=None
        for prototype in obj['applied_parts']:
            r=self.source_instance(prototype,mapping);parents=[]
            for term in r['premises']:
                key=smt(term)
                if key not in context:
                    assert term[0]=='=' and term[1]==term[2]
                    context[key]=self.add('typed-reflexivity',term)
                parents.append(context[key])
            conclusion=self.apply(r,parents);context[smt(r['conclusion'])]=conclusion
        if obj['join']:
            r=self.source_instance(obj['join'],mapping)
            conclusion=self.apply(r,[context[smt(x)] for x in r['premises']])
        nxt=self.observation('cache' if cache else 'api',index,True)
        conclusion=self.rewrite(conclusion,nxt,self.nodes[nxt]['formula'][2],self.nodes[nxt]['formula'][1])
        result=self.close_induction(name,template,base,conclusion,index,ih)
        del self.active_indices[index]
        return result

    def validate(self):
        """Verify this pinned construction, not arbitrary submitted proofs.

        Fresh source/receipt reconstruction and exact object equality are
        mandatory. The reviewed builder's inference primitives are trusted;
        support/type checks alone are not a certificate acceptance rule.
        """
        fresh=construct_current_proof(transport_certificate.assemble())
        for key in ['nodes','global_nodes','observers','root_context','index_bindings','scope_labels']:
            assert getattr(self,key)==getattr(fresh,key),('changed recorded construction',key)
        assert not self.active_indices
        for expected,node in enumerate(self.nodes):
            assert node['id']==expected and all(0<=p<expected for p in node['parents'])
            computed=set(node['introduced_support'])
            assert computed<=set(self.root_context)|self.scope_labels
            for p in node['parents']:computed.update(self.nodes[p]['support'])
            if node['kind']=='ordinary-induction':
                assert node['parents']==[node['base_parent'],node['step_parent']]
                assert all(node[x]<expected for x in ['scoped_IH','bound_parent'])
                name=self.index_bindings[node['fresh_step_index']]['name']
                assert node['discharged_support']==['IH:'+name,'INDEX:'+name]
                computed-=set(node['discharged_support'])
            assert computed==set(node['support']),('support mismatch',expected)
        for nodeid in self.global_nodes.values():assert set(self.nodes[nodeid]['support'])<=set(self.root_context)
        # Typecheck the actual indexed trace terms and every concrete node.
        from boolean_application import SourceLanguage
        import typed_source
        language=SourceLanguage()
        language.add([x for x,_,_ in parse_spans((HERE/'TRANSPORT-TYPING-ONLY.smt2').read_bytes())])
        S='|core_workflow_control_s|';C='|board1_verified_ddr_page_service_s|';B=['_','BitVec','5']
        for name,args,result in [('A',['Int'],S),('C',['Int'],C),('API',['Int'],'ApiHistory'),('X',[B,'Int'],'CacheorderHistory'),
            ('REQUEST',['Int'],'RequestOrigin'),('SERVICE',[B,'Int'],'ServiceOrigin')]:
            assert name not in language.defs and name not in language.decls
            language.decls[name]=['declare-fun',name,args,result]
        roots=[node['formula'][2] if node['kind']=='ordinary-induction' else node['formula'] for node in self.nodes]
        variables=[('slot',B),('model',['Array',['_','BitVec','18'],['_','BitVec','256']]),
            *[(index,'Int') for index in self.index_bindings]]
        specimen,typed=typed_source.build(language,roots,variables,[S,C])
        return specimen,typed


def construct_current_proof(draft):
    proof=Proof(draft)
    for name in ['api','cacheorder','reader']:proof.family(name)
    proof.common_history();proof.slot_constancy()
    proof.observer_projection('request');proof.observer_projection('service')
    return proof


def assemble():
    draft=transport_certificate.assemble();proof=construct_current_proof(draft)
    specimen,typed=proof.validate()
    return {'nodes':proof.nodes,'global_nodes':proof.global_nodes,'observer_registry':proof.observers,
        'actual_source_domain':'Full named composed RTL execution, not unconstrained standalone core/page input traces.',
        'root_context':proof.root_context,'root_supports':list(proof.root_context),
        'scoped_index_registry':proof.index_bindings,'indexed_source_typing':typed,'typing_specimen':specimen.decode(),
        'acceptance_rule':'Mandatory fresh source/receipt builder reconstruction and exact recorded-object equality, plus scope/support/indexed-type checks.',
        'arbitrary_certificate_validator':False,
        'trusted_builder_sha256':{p.name:sha(p.read_bytes()) for p in [Path(__file__),HERE/'transport_certificate.py']},
        'ownership_inductions_checked':True,'common_history_epoch_selector_payload_and_final_source_pending':True,
        'new_engine_jobs':0,'whole_initialized_source_theorem_qualified':False}


if __name__=='__main__':
    result=assemble()
    specimen=result.pop('typing_specimen')
    (HERE/'SCOPED-INDUCTION-TYPING-ONLY.smt2').write_text('; Typing specimen only; not an engine result.\n'+specimen)
    (HERE/'SCOPED-INDUCTION-DRAFT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'nodes':len(result['nodes']),'closed_global_templates':list(result['global_nodes']),
        'engines':0,'source_qualified':False}))

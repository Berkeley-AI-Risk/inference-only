# Same c070 row12 through actual selector admission

Plan only. No new query preparation, proof construction, engine, simulation,
RTL compile, board or public action has run. The coordinating reviewer accepted
HEAD-STEP-RMS-ROW12-R1-SEALED.json (9c8ca0e4) and requested this next extension.
Preserve all old sealed bytes, source/macro profiles and replay qualification.
No Lean, new working copy, branch or broad publication work is involved.

## End claim

At one legal native greedy-selector handshake for row12 on the same c070
configuration, derive index12, LAST=false and the actual admitted signed50 raw
score and signed8 source exponent:

    raw50 = D(S,M,256) * model_row12_multiplier(M)
    source_exp = S8(eA) + model_row12_exponent(M) - 15.

The already checked S/R0 word identity, original STEP/RMS/snapshot witnesses
and actual completed signed48/signed35 dot must remain in the argument.
Here eA comes from that actual final-RMS record and the native shell -> D
head-start register -> job7 admission path, not a nonexistent FrameHistory
exponent field or an independently supplied private input. A successful tuple
requires representability in signed8; preserve the actual source range checks.
The model is fixed before time/row generalization. No row replication is needed.

The actual synchronous tile dot read, low4 lane/high2 tile selection, metadata
m/e from the fixed image, postscale tags and held output must carry the same
row/UID/episode. Stage1 uses the prior registered tile read on an edge that may
also issue row13; never use the convenient later current dot. Preserve arbitrary
backpressure, source reset/CLEAR/fault priority and first-fault-edge transfers.
No current/future aggregate-health guard may be added to hide a wrong output.

## First useful delivery: native head-start exponent

The existing qualified nf-I contains the shell captured-exponent relation and
D.head_activation_exponent_q relation in E_HEAD, but their guards alone do not
retain the original record through shell fault/cancellation. Start with these
source-matched leaves, then one small nondriving head-start record/invariant:

1. Under H, nf-I and the actual effective D head-start capture, derive the
   precise live shell, HEAD_START state, completed accepted NF record and
   equality of shell final_norm_exponent_q / actual D input exponent to nf-exp.
   The capture is D reset high, no D CLEAR, old D fault absent, D E_IDLE and
   actual head_start_accept. These are source update conditions, not a guessed
   successful future. Native H must discharge all caller wiring and guards.
2. Under both H endpoints and the complete unchanged native T, identify the
   next actual D exponent register with that pre-edge NF exponent. Account for
   successor asynchronous-reset masking explicitly (reset value0 when reset
   is low); do not assume a healthy next state. A current accepted capture may
   coexist with a later fault override of D's engine phase.
3. At actual effective job7 descriptor admission, bind the incoming exponent
   to D.head_activation_exponent_q and the next J exponent register. Use the
   literal incoming job/layer and actual register-update enable, including all
   earlier fault/protocol/CLEAR/reset priorities. Raw start_transfer alone is
   not silently equated with a successful descriptor/register admission. Any
   later qualification must discharge those effective-event conditions from
   the actual owned source history. Do not use a retained stored job7 as birth.
4. Prove D/J exponent physical hold outside their actual capture/reset/CLEAR
   updates, including a current fault and retained payload. This is historical
   data meaning, not permission for a canceled invocation to publish.
5. Define one fixed nondriving HeadExponentHistory record, captured at actual D
   head start from NF(n), with its actual observation n, UID/parent/prefix and
   exponent. It is fixed before word choice. Reset/CLEAR revokes current
   authority; historical payload may persist. A reset-founded invariant must
   supply that owner in D E_HEAD and identify the actual retained D exponent.
   Include a precise live-shell phase constraint if needed, and the existing
   protected-NF relation (which excludes advancing clock/validity flags) to
   connect this original record to the later saved R0. Never equate whole
   NormFrame values at two times: their ghost clocks differ.
6. Apply the qualified original NF and head-start invariants on the same prefix
   to the actual job7 birth and original capture k/j. Derive all witness/lookup
   ranges, retaining original A0/A1 resets and defined edges only. No INDEX
   assumption for a historical term and no current-record substitution.

If the full read/scale join takes longer, seal and report this checked exponent
component immediately, then continue. No result below may assume its desired
future input exponent or correct private numerical answer.

## Read, metadata, postscale and consumer continuation

Audit the existing source-equal Q engine/tile/multiplier contracts. Import only
individually closed leaves and accepted integer/word derivations. The old
aggregate split-postscale solver result is false and remains excluded; do not
call old prepare/check/verify writers or recompile old sources. Check actual
port/reset/clock/macro/parameter bindings before using a standalone theorem.

Reuse the old reset-founded row12/row13 fixture as a sensitivity check within
its engine-interface scope; do not rerun it or promote it to whole-caller
reachability. Its exact-image A[1]=123/eA=0 inputs give dot5781, raw121360533,
exponent-25 and LAST=false, including stalls and CLEAR after MAC drain. The
actual adjacent read13 dot-13899 would give raw-291781707 with row12 metadata.
The independently decoded image (cad8d015...) supplies word213745 slot4 record
0x005201f6, multiplier20993, signed row exponent-10; column1 coefficients are
47 (row12) and-113 (row13). These are checks of source/model binding, never
assumptions that the circuit consumed those values. Prove actual metadata
reader/packed-header/adapter/tile-write ownership from the fixed-image model
contract, including held data across failure. Keep the same actual model M.

The greedy selector is opaque in c070's numerical cut. Its actual compiled
native admission/ownership theorem uses a distinct parent state sort. Do not
conjoin or rename that state sort into c070. Use a checked actual source-instance,
port/clock/reset/parameter projection or an independently qualified component
contract. Bind actual row_valid, row_ready, raw50, exponent8, index and LAST.
The shell head_result_transfer and selector fire can differ on the first fault
edge. Prove the held tuple that is actually admitted, or derive lack of current
successful authority for that divergent admission under the existing qualified
ownership rules. Never change production gates to make an identity true.

The next native read/output obligations need their own concrete reviewed
source/contract plan once the exact reusable leaf inventory is pinned. If a
small read-selection lemma closes first, seal/report it, then continue toward
the held score and actual legal selector admission. Record a missing source
projection or ownership premise explicitly; do not turn it into an environment
promise or silently broaden this source cut.

## Initial budget and stop rule

Phase A preparation: at most four exponent/capture/hold leaves, two reset/base
and preservation obligations for the one head-start owner invariant, one small
pure origin zero/step obligation if the old generic datatype cannot be reused
literally, and at most one diagnostic of the identical first unexpected SAT.
Maximum8 native jobs, sequential dependency order, one owned worker,4GiB sampled
RSS and physical footprint, actual normal Darwin pressure and Z3-memory4096.
Reuse the already accepted guard/probe receipts; run no new resource probes.
There is no elapsed/CPU/token kill, fixed free-RAM floor or simulator-slot use.
No native RTL compile or simulation is planned in this phase.

Concrete event/record/IH formulas, all source/query/tool/guard pins, exact
source-module bindings, dependency order, expected results and typed diagnostic
terms must receive independent review before launch. Current-state source
identities need H; actual register/hold claims retain all452 T conjuncts and
both endpoint H. Independently proved nf-I at the successor is an acyclic
provider if used, with its real defined-edge domain; it is not future health.

Stop the affected chain on an unexpected SAT/error/unknown/resource stop,
unsupported source/helper transfer, failed reset/record identity, hidden
out-of-prefix lookup, or need for another owner/operator induction beyond this
single head-start record. Save the exact formula, raw output/receipt, partial
DAG, active scopes and read/helper pins. No blind retry, relaxed endpoint or
unreviewed strengthening. A bounded source-justified change requires new review
and an additive version; old failures stay intact. Token exhaustion must leave
an accurate continuation checkpoint.

Acceptance requires exact engine receipts, source-bound typed applications,
independent formula/parent/support and read-only byte-identical replay review,
plus frozen closed entry and recovery archive. Publish the earlier checked
exponent/read component privately to the coordinator when ready, and continue
the explicitly requested score path with a new concrete reviewed plan. No
Git/public or board action. Numerical meaning of the upstream final RMS and
its layer5 input is a separate task; other rows and whole-device claims remain
open.

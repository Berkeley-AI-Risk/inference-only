"""Restricted deductions, original payload and defined-past lookup audit."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
sub = lambda x, m: m.get(x, x) if isinstance(x, str) else [sub(t, m) for t in x]


def replace(x, a, b):
    return deepcopy(b) if x == a else x if isinstance(x, str) else [replace(t, a, b) for t in x]


def atoms(x):
    if isinstance(x, str):
        return {x}
    if isinstance(x, list):
        return set().union(*(atoms(t) for t in x)) if x else set()
    if isinstance(x, dict):
        return set().union(*(atoms(t) for t in x.values())) if x else set()
    return set()


def validate(application, exports, data, prepared, forms, module):
    ns, context = application['nodes'], application['root_context']
    assert context == prepared['context'] and module.digest(module.canon(context)) == module.CONTEXT_SHA
    assert len(ns) <= 192 and application['new_native_jobs'] == application['new_inductions'] == 0
    domain = ['<=', '1', 'N']
    current = application['current']
    j = ['FRAMEORIGIN', module.N]
    imports = {}
    selected = exports['selectedglobals']['control']
    imports['qualified-bounded-original-control'] = (['=>', domain, selected['bounded_formula']], selected['node']['support'],
        {'seal': exports['provenance']['seal_sha256'], 'source': exports['provenance']['source_dag_sha256'], 'node': 779})
    for name in ['saved-row-frame', 'historical-frame-origin']:
        value = prepared['globals'][name]
        imports['qualified-bounded-' + name] = (['=>', domain, value['bounded']], value['support'],
            {k: prepared['pins'][k] for k in ['dot_seal', 'dot_application', 'dot_prefix']})
    imports['qualified-bounded-physical-E-row-continuity'] = (
        ['=>', domain, data['continuity_application']['prefix']['bounded_formula']], data['continuity_application']['prefix']['source_supports'],
        {k: prepared['pins'][k] for k in ['continuity_application', 'continuity_review']})
    imports['accepted-current-head-E-original-R0'] = (prepared['engine']['literal_global_formula'], context,
        {k: prepared['pins'][k] for k in ['engine_application', 'engine_review']})
    imports['sealed-original-STEP-RMS-frame-capture'] = (prepared['capture']['literal_global_formula'], context,
        {k: prepared['pins'][k] for k in ['capture_seal', 'capture_application', 'capture_review']})
    definitions = {f[1]: f for f in forms if f[0] == 'define-fun'}
    datatypes = [f for f in forms if f[0] == 'declare-datatypes']
    seen, source_context_nodes = {}, set()
    allowed_bounds = [['<=', '1', module.N], ['<=', module.N, 'N'], ['<=', '1', j], ['<=', j, 'N'], ['<=', '0', j]]
    for i, n in enumerate(ns):
        assert n['id'] == i and all(type(p) is int and 0 <= p < i for p in n['parents'])
        support = set(n['introduced_support'])
        for p in n['parents']:
            support.update(ns[p]['support'])
        assert support - set(n.get('discharged_support', [])) == set(n['support'])
        f, k, ps = n['formula'], n['kind'], n['parents']
        if k == 'checked-fixed-component-context-application':
            name = n['component']
            assert name in imports and name not in seen and not ps
            formula, roots, provenance = imports[name]
            assert f == formula and set(n['support']) == set(roots) and n['accepted_provenance'] == provenance
            assert n['exact_bounded_source_context_sha256'] == module.CONTEXT_SHA
            seen[name] = i
        elif k == 'conjunction-introduction':
            assert f == ['and', *[ns[p]['formula'] for p in ps]]
        elif k == 'conjunction-elimination':
            assert len(ps) == 1 and ns[ps[0]]['formula'][0] == 'and'
            assert 1 <= n['position'] < len(ns[ps[0]]['formula']) and f == ns[ps[0]]['formula'][n['position']]
        elif k == 'implication-elimination':
            assert len(ps) == 2 and ns[ps[0]]['formula'] == ['=>', ns[ps[1]]['formula'], f]
        elif k == 'typed-equality-context-substitution':
            assert len(ps) == 2
            original, equation = (ns[p]['formula'] for p in ps)
            assert equation[0] == '=' and f in [replace(original, equation[1], equation[2]), replace(original, equation[2], equation[1])]
        elif k == 'literal-function-definition-instance':
            d = n['definition']
            assert d == definitions[d[1]] and set(n['uniform_mapping']) == {v[0] for v in d[2]}
            assert f == ['=', [d[1], *[n['uniform_mapping'][v[0]] for v in d[2]]], sub(d[4], n['uniform_mapping'])]
            assert all(ns[p]['formula'] in allowed_bounds for p in ps)
        elif k == 'literal-datatype-constructor-selector':
            assert n['datatype'] in datatypes and not ps
            t = next(t for t in n['datatype'][2] if t[0] == n['datatype_name'])
            ctor = next(c for c in t[1:] if c[0] == n['constructor_name'])
            position = n['selector_position']
            assert 1 <= position < len(ctor) and ctor[position][0] == n['selector_name']
            assert f[0] == '=' and f[1][0] == n['selector_name'] and f[1][1][0] == ctor[0]
            assert len(f[1][1]) == len(ctor) and f[2] == f[1][1][position]
        elif k == 'fixed-typed-forall-elimination-preserving-domain':
            original = ns[ps[0]]['formula']
            assert original == n['original_quantified_formula'] and original[0] == 'forall'
            assert set(n['uniform_mapping']) == {v[0] for v in original[1]} and f == sub(original[2], n['uniform_mapping'])
            assert all(value in [module.N, j, '0', ['_', 'bv0', '8'], module.W] for value in n['uniform_mapping'].values())
            assert all(ns[p]['formula'] in allowed_bounds for p in ps[1:])
        elif k == 'qualified-source-schema-uniform-instance':
            query = n['original_query_sha256']
            if query == prepared['pins']['row_guard_query']:
                goal = data['row_guard_binding']['combined_goal']
                assert n['uniform_mapping'] == {'a': ['A', j], 'columns': ['COLUMNS', j], 'row': ['ROW', j], 'header': ['HEADER', j]}
                assert n['accepted_row_guard_seal_sha256'] == prepared['pins']['row_guard_seal']
                assert n['accepted_raw_result_adjudication'] == data['row_guard_result']
            else:
                assert query == prepared['pins']['math_query'] == 'c7f7abeaf6645e15351877c73c5dfc419e33e7cb1742af514306391074c56a84'
                goal = data['math_binding']['goal']
                assert n['uniform_mapping'] == {'past': j, 'current': module.N, 'bound': 'N'}
                assert n['accepted_math_seal_sha256'] == prepared['pins']['math_seal']
            assert n['original_query_goal'] == goal and f == sub(goal, n['uniform_mapping']) and not n['introduced_support']
        elif k == 'literal-integer-threshold-weakening':
            assert len(ps) == 1 and n['checked_numerals'] == [0, 1]
            assert n['weaker_threshold'] == '0' and n['stronger_threshold'] == '1'
            assert ns[ps[0]]['formula'] == ['<=', '1', j] and f == ['<=', '0', j]
        elif k == 'actual-bounded-source-context-consequence':
            assert not ps and f == context['Gamma:actual-composed-source']['formal_native_consequences'][2]
            assert n['support'] == ['Gamma:actual-composed-source']
            assert n['literal_context_field'] == 'formal_native_consequences[2]' and n['exact_bounded_context_sha256'] == module.CONTEXT_SHA
            source_context_nodes.add(i)
        elif k == 'disjunction-introduction':
            assert len(ps) == 1 and f[0] == 'or'
            assert 1 <= n['selected_disjunct'] < len(f) and f[n['selected_disjunct']] == ns[ps[0]]['formula']
        elif k == 'scoped-natural-index-domain':
            assert not ps and f == ['<=', '1', module.N] and n['scope'] == module.FAMILY
            assert n['support'] == ['INDEX:' + module.FAMILY]
        elif k == 'scoped-case-assumption':
            assert not ps and n['case_label'] == 'CASE:physical-original-row-active-engine' and n['support'] == [n['case_label']]
            assert f == ['and', domain, ['<=', module.N, 'N'], current['guard']]
        elif k == 'implication-introduction':
            assert len(ps) == 2 and ns[ps[0]]['kind'] == 'scoped-case-assumption'
            assert f == ['=>', ns[ps[0]]['formula'], ns[ps[1]]['formula']]
            assert n['discharged_support'] == [ns[ps[0]]['case_label']]
        elif k == 'uniform-trace-consequence':
            assert i == current['global_node'] and len(ps) == 2 and ns[ps[1]]['kind'] == 'scoped-natural-index-domain'
            assert n['fresh_index'] == module.N and n['quantified_parameters'] == [[module.W, ['_', 'BitVec', '8']]]
            assert n['property_template'] == sub(ns[ps[0]]['formula'], {module.N: '@index'})
            assert f == ['forall', [*n['quantified_parameters'], [module.N, 'Int']], ['=>', ['<=', '1', module.N], ns[ps[0]]['formula']]]
            assert set(n['support']) == set(context) and n['discharged_support'] == ns[ps[1]]['support']
        else:
            raise AssertionError(('Unreviewed original-row consequence rule', i, k))
    assert seen == current['imports'] and set(seen) == set(imports)
    assert application['global_nodes'] == {module.FAMILY: current['global_node']}
    assert current['literal_global_formula'] == ns[current['global_node']]['formula']
    expected_guard = sub(data['continuity_binding']['scalar_invariant'][4][1], {'s': ['A', module.N], 'r': ['ROW', module.N], 'origin': j})
    assert current['guard'] == expected_guard
    old = prepared['capture']['literal_global_formula']
    def old_result(word):
        return sub(old[2][2][2], {'i_capture_origin': j, 'capture-origin-watch': word})
    assert ns[current['scalar_capture_parent']]['formula'] == old_result(['_', 'bv0', '8'])
    assert ns[current['word_capture_parent']]['formula'] == old_result(module.W)
    for parent, position in zip(current['scalar_payload_parents'], [1, 2]):
        assert ns[parent]['formula'] == old_result(['_', 'bv0', '8'])[position]
    assert ns[current['original_exponent_parent']]['formula'] == [
        '=', ['|core_workflow_control_n u_native.u_six_layers.u_datapath.u_projection.u_shared_engine.u_engine.activation_exponent_q|', ['A', module.N]],
        ['nf-exp', ['endpoint-saved-NF', j]]]
    assert ns[current['snapshot_word_parent']]['formula'] == ['=',
        ['select', ['srf-data', ['ROWFRAME', module.N]], [['_', 'zero_extend', '2'], module.W]],
        ['select', ['nf-data', ['endpoint-saved-NF', j]], module.W]]
    assert module.W not in atoms(ns[:current['scalar_nodes_end_before_word'] + 1])
    assert len(application['lookup_ledger']) == 1
    lookup = application['lookup_ledger'][0]
    lower, upper = lookup['lower_parent'], lookup['upper_parent']
    assert lookup['index'] == j and not lookup['historical_INDEX_added'] and not lookup['source_edge_requested']
    assert ns[lower]['formula'] == ['<=', '1', j] and ns[upper]['formula'] == ['<=', j, 'N']
    assert ns[lookup['strict_past_parent']]['formula'] == ['<', j, module.N]
    assert max(lower, upper) < lookup['first_actual_record_unfold_parent'] < lookup['source_H_parent'] < lookup['past_engine_instance_parent'] < lookup['historical_EXP_definition_parent']
    wrapper = ns[lookup['historical_EXP_definition_parent']]
    chain = ns[lookup['historical_EXP_bound_conjunction_parent']]
    definition = ns[lookup['historical_EXP_literal_definition_parent']]
    assert wrapper['kind'] == 'conjunction-elimination' and wrapper['position'] == 1
    assert wrapper['parents'] == [chain['id']] and chain['kind'] == 'conjunction-introduction'
    assert chain['parents'] == [definition['id'], lower, upper]
    assert definition['kind'] == 'literal-function-definition-instance' and not definition['parents']
    assert definition['definition'] == data['continuity_binding']['future_fixed_actual_function_definition']
    assert max(lower, upper) < definition['id'] < chain['id'] < wrapper['id']
    imported_ids = set(seen.values())
    closed_foralls = set()
    for i, n in enumerate(ns):
        ps = n['parents']
        if n['kind'] == 'implication-elimination' and len(ps) == 2 and ps[0] in imported_ids:
            original = ns[ps[0]]['formula']
            if original[0] == '=>' and original[1] == domain and original[2][0] == 'forall':
                assert ns[ps[1]]['formula'] == domain and n['formula'] == original[2]
                closed_foralls.add(i)
    assert len(closed_foralls) == 4
    # Carried p/r source terms are exactly the already qualified old capture
    # payload, checked literally above; no new H/provider/definition at p/r.
    p_step, p_rms = ['original-STEP-observation', j], ['original-RMS-observation', j]
    indexed = {'A', 'C', 'COLUMNS', 'ROW', 'HEADER', 'CAPTURE', 'FRAME', 'ROWFRAME', 'FRAMEORIGIN', 'CERT', 'HS'}
    def local(x):
        if not isinstance(x, list):
            return
        if x and isinstance(x[0], str) and x[0] in indexed:
            assert len(x) == 2 and x[1] in [module.N, j, p_step, p_rms], x
        if x and x[0] == 'NF':
            assert len(x) == 2 and x[1] in [module.N, j, ['endpoint-capture-index', j], p_rms], x
        for t in x:
            local(t)
    for i, n in enumerate(ns):
        if i not in imported_ids | closed_foralls | source_context_nodes:
            local(n['formula'])
    return {'passed': True, 'all_deduction_nodes_checked': len(ns), 'bounded_source_context_sha256': module.CONTEXT_SHA,
        'original_j_bounds_before_actual_lookup': True, 'original_scalar_payload_kept_literal': True,
        'all_snapshot_words_not_unconsumed_row_operands': True, 'scalar_before_arbitrary_word': True,
        'closed_bounded_forall_nodes': sorted(closed_foralls), 'new_historical_INDEX_or_edge_provider': False,
        'new_native_jobs': 0, 'read_dot_metadata_postscale_selector_join_proved': False}

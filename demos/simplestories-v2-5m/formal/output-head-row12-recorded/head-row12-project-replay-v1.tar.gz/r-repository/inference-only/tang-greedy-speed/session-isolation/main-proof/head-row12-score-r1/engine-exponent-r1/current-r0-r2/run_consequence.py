"""Read-only current E/head/original-R0 consequence driver; no engines."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import ast
import copy
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
G = HERE.parent
C = G.parent
M = C.parent
P = M / 'head-mode-ownership-r1'
L = P / 'frame-join-pilot/certificate-trace-application-r2'
SCOPE = 'actual-current-active-head-E-original-saved-RMS-exponent-r2'
INPUTS = {'run_consequence.py', 'current_engine.py', 'consequence_audit.py', 'PLAN.md', 'INPUT-REVIEW.md', 'RAW-INPUTS.json'}
RAW = {'saved_seal', 'saved_application', 'saved_typing', 'saved_review', 'component_review',
    'engine_application', 'engine_typing', 'engine_review', 'binding', 'previous_stop'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
FAILURE = None


def load(name, path, expected):
    raw = path.read_bytes()
    assert digest(raw) == expected, str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def construct(metadata_only=False):
    global FAILURE
    FAILURE = None
    proof, audit = None, None
    saved_path, saved_modules = sys.path[:], dict(sys.modules)
    try:
        assert type(metadata_only) is bool and sys.version_info[:2] == (3, 12)
        assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
        audit_path = L / 'check_nf_component.py'
        audit = load('_current_e_r0_readonly_audit', audit_path, '6f61975fae2768fce2d74e127b7ced06094f0abac2ed3a1013518c1cbed70f33')
        audit.ACTIVE = True
        audit_path.read_bytes()
        env_path = HERE / 'ACCEPTED-INPUTS.json'
        env = json.loads(env_path.read_bytes())
        assert env['accepted'] is True and env['scope'] == SCOPE and set(env['files']) == INPUTS
        for name, expected in env['files'].items():
            path = HERE / name
            assert path.is_file() and not path.is_symlink() and digest(path.read_bytes()) == expected
        manifest = json.loads((HERE / 'RAW-INPUTS.json').read_bytes())
        assert set(manifest) == {'paths_relative_to_main_proof', 'pins', 'helper_paths_relative_to_main_proof', 'helper_pins'}
        def read_inputs(paths, pins):
            assert set(paths) == set(pins)
            values = {}
            for name, relative in paths.items():
                path = (M / relative).resolve()
                assert path.is_relative_to(M) and not path.is_symlink()
                values[name] = path.read_bytes()
                assert digest(values[name]) == pins[name]
            return values
        assert set(manifest['pins']) == RAW and set(manifest['helper_pins']) == {'fixed', 'steps'}
        raw = read_inputs(manifest['paths_relative_to_main_proof'], manifest['pins'])
        data = {name: json.loads(value) for name, value in raw.items()
            if manifest['paths_relative_to_main_proof'][name].endswith('.json')}
        assert manifest['pins']['previous_stop'] == '57233d1a5abbfdf51e94e21c75f7f119facec4dc8f4e2e00ec64e3a80ce04543'
        assert data['previous_stop']['result_qualified'] is False
        assert data['previous_stop']['error'] == "AssertionError(['A', 'n_prefix'])"
        assert len(data['previous_stop']['partial_nodes']) == 104 and not data['previous_stop']['active_indices']
        assert data['saved_seal']['independent_component_result_review_sha256'] == manifest['pins']['component_review']
        assert data['saved_application']['typing_sha256'] == digest(raw['saved_typing'])
        assert data['engine_application']['typing_sha256'] == digest(raw['engine_typing'])
        exports = load('_current_e_r0_exports', L / 'accepted_exports_r3.py', '2bc78867ebf370b0cf6f32c6ddf7e15e1f129f49db1764a7b88acc7b1d9bb082').load_parent_exports()
        api = exports['apis']
        def helper(name):
            return load('_current_e_r0_' + name, M / manifest['helper_paths_relative_to_main_proof'][name], manifest['helper_pins'][name])
        fixed, steps = [helper(name) for name in ['fixed', 'steps']]
        module = load('_current_e_r0_application', HERE / 'current_engine.py', env['files']['current_engine.py'])
        checker = load('_current_e_r0_deduction_audit', HERE / 'consequence_audit.py', env['files']['consequence_audit.py'])
        heads = {'declare-sort', 'declare-fun', 'declare-datatypes', 'declare-datatype', 'declare-const', 'define-fun'}
        forms = [f for f, _, _ in api['parse_spans'](raw['saved_typing']) if f[0] in heads]
        definitions = {f[1]: f for f in forms if f[0] == 'define-fun'}
        for key in ['projected_control_definition', 'scalar_invariant']:
            definition = data['binding'][key]
            assert definition[1] not in definitions
            forms.append(definition)
            definitions[definition[1]] = definition
        prepared = module.prepare_metadata(exports, data, manifest['pins'], forms)
        if metadata_only:
            audit.HELPERS.update({Path(__file__).resolve(), audit_path})
            assert audit.HELPERS <= set(audit.READS)
            for path, expected in list(audit.READS.items()):
                assert digest(path.read_bytes()) == expected
            return {'metadata_only_passed': True, 'proof_initializers_called': 0, 'proof_nodes': 0,
                'input_envelope_sha256': digest(env_path.read_bytes()), 'new_native_jobs': 0,
                'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
                'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)}}, None
        proof = api['ValueProof'].__new__(api['ValueProof'])
        api['Proof'].__init__(proof, {})
        for name, original in proof.root_context.items():
            assert all(exports['context'][name][key] == value for key, value in original.items())
        proof.root_context = copy.deepcopy(prepared['context'])
        language = api['SourceLanguage']()
        language.add(forms)
        for f in forms:
            if f[0] == 'declare-const':
                assert f[1] not in language.defs and f[1] not in language.decls
                language.decls[f[1]] = copy.deepcopy(f)
        assert module.I not in language.defs and module.I not in language.decls
        index_declaration = ['declare-const', module.I, 'Int']
        language.decls[module.I] = index_declaration
        app = module.construct(proof, language, exports, data, prepared, steps, fixed)
        deduction = checker.validate(app, exports, data, prepared, forms, module)
        typing_forms = [*forms, index_declaration, *[['assert', n['formula']] for n in proof.nodes],
            ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
        typing = ('\n'.join(map(api['smt'], typing_forms)) + '\n').encode()
        path = P / 'source_typecheck.py'
        type_raw = path.read_bytes()
        assert digest(type_raw) == '2586ce255743a898f7471af39520cd9860ac01594759a3ecb9fd7e9019d03809'
        functions = [f for f in ast.parse(type_raw).body if isinstance(f, ast.FunctionDef) and f.name in ['sort', 'check']]
        namespace = {'c': types.SimpleNamespace(parse_spans=api['parse_spans']), 'sha': digest}
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(path), 'exec'), namespace)
        typed = namespace['check'](typing)
        assert typed['assertions'] == len(proof.nodes)
        audit.HELPERS.update({Path(__file__).resolve(), audit_path})
        assert audit.HELPERS <= set(audit.READS)
        for path, expected in list(audit.READS.items()):
            assert digest(path.read_bytes()) == expected
        return {'application': app, 'deduction_check': deduction, 'type_check': typed, 'typing_sha256': digest(typing),
            'input_envelope_sha256': digest(env_path.read_bytes()), 'new_native_jobs': 0,
            'old_parent_proof_reconstructions_called': 0,
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())},
            'executed_helper_pins': {str(k): audit.READS[k] for k in sorted(audit.HELPERS)},
            'independent_result_review_pending': True, 'historical_selected_row_R0_identity_proved': False,
            'read_metadata_postscale_selector_join_proved': False, 'whole_device_theorem': False}, typing
    except BaseException as error:
        FAILURE = {'error': repr(error), 'partial_nodes': copy.deepcopy(proof.nodes) if proof is not None else [],
            'active_indices': copy.deepcopy(proof.active_indices) if proof is not None else {},
            'scope_labels': sorted(proof.scope_labels) if proof is not None else [],
            'index_bindings': copy.deepcopy(proof.index_bindings) if proof is not None else {},
            'actual_read_pins': {str(k): v for k, v in sorted(audit.READS.items())} if audit is not None else {},
            'executed_helper_pins': {str(k): audit.READS.get(k) for k in sorted(audit.HELPERS)} if audit is not None else {},
            'new_native_jobs': 0, 'result_qualified': False}
        raise
    finally:
        if audit is not None:
            audit.ACTIVE = False
        sys.path[:] = saved_path
        for name in set(sys.modules) - set(saved_modules):
            del sys.modules[name]
        sys.modules.update(saved_modules)


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--metadata-only'])
    name = 'METADATA-R1' if sys.argv[1:] else 'CONSEQUENCE-R1'
    assert not any((HERE / (name + suffix)).exists() for suffix in ['.json', '-STOPPED.json', '-TYPING-ONLY.smt2'])
    def save(suffix, raw):
        with (HERE / (name + suffix)).open('xb') as output:
            output.write(raw)
    try:
        result, typing = construct(bool(sys.argv[1:]))
    except BaseException:
        save('-STOPPED.json', (json.dumps(FAILURE, indent=2, sort_keys=True) + '\n').encode())
        raise
    save('.json', (json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    if typing is not None:
        save('-TYPING-ONLY.smt2', typing)
    print(json.dumps({'metadata_only': bool(sys.argv[1:]), 'new_nodes': len(result.get('application', {}).get('nodes', [])), 'new_native_jobs': 0}))

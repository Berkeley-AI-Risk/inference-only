# Physical selected-row engine-exponent continuity: two native leaves

Exact preparation under ROW-EXPONENT-CONTINUITY-PLAN.md and independent plan
review710b5dd522edfcb496baa43e981ed0c03d71c1694d5cafb321ac7c00f142b266.
Use arbitrary empty-a/w/prefix parameters, later uniformly mapped to the
original accepted observer constants. Do not substitute current arrays for the
original full ROW recurrence. No extra history or source provider is proposed.

The one physical invariant is E active1..5 and row physical/count>0 implies
actual E exponent = fixed EXP_AT(original row origin). It does not grant output
authority. Native step needs only both H/all452 T, current invariant and the
current-point function bridge EXP_AT(observation)=E exponent at a. The next row
and next origin are the exact original selected-row-next/source-view and
row-frame-origin-index-next with that same observation. Base uses H/common
reset-low and arbitrary row/origin. Realization of EXP_AT as actual E getter on
A(t), original ROW/origin recurrences and prefix application are later gates.

Two first native attempts only, one owned worker, 4GiB RSS/physical-footprint
and Z3memory4096, actual normal Darwin pressure, accepted guard/probe reuse.
No wall/CPU/token kill, new probe, free-RAM floor, simulator, compiler, RTL edit,
board or public action. Exact inputs require independent review/freeze before
read-only preflight, then the one-shot recorder. Any unexpected answer/error/
resource stop preserves all records and stops this version and dependents.
Further attempts or changes need an additive concrete independent review.

Accepted leaves alone do not establish ordinary-prefix continuity, original
saved RMS association at a read, accumulator/metadata/postscale or selector
admission. Those remain the active downstream assignment. No whole-device
claim follows from this local component.

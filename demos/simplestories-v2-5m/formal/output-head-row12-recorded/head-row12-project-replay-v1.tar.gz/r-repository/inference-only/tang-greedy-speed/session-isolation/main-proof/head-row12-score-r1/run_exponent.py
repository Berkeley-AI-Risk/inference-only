"""Four reviewed native exponent leaves, one owned pressure-guarded worker."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import fcntl
import hashlib
import json
import signal
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
P = ROOT / 'head-mode-ownership-r1'
SCOPE = 'four-c070-native-head-start-job-exponent-leaves'
NAMES = ['head-start-current-RMS-exponent', 'head-start-register-capture',
         'job7-admission-exponent-cone', 'head-and-job-exponent-hold']
REQUIRED = {'PLAN.md', 'PLAN-REVIEW.md', 'prepare_exponent.py', 'SOURCE-BINDING.json',
    'QUERY-PLAN.json', 'TYPE-CHECK.json', 'READ-PINS.json', 'run_exponent.py',
    'EXTERNAL-PINS.json', 'TOOL-PIN.json', 'INPUT-REVIEW.md', *[name + '.smt2' for name in NAMES]}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
sha = lambda path: digest(Path(path).read_bytes())
rd = lambda path: json.loads(Path(path).read_bytes())
canonical = lambda value: json.loads(json.dumps(value))


def save(name, value):
    with (HERE / name).open('x') as output:
        output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def load(name, path, pins):
    path = Path(path).resolve()
    raw = path.read_bytes()
    assert path in pins and digest(raw) == pins[path], str(path)
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def preflight():
    assert sys.platform == 'darwin' and sys.version_info[:2] == (3, 12)
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    frozen, accepted = rd(HERE / 'FROZEN-INPUTS.json'), rd(HERE / 'REVIEW-ACCEPTED.json')
    assert accepted['accepted'] is True and accepted['scope'] == frozen['scope'] == SCOPE
    assert accepted['max_native_jobs'] == 4 and set(frozen['files']) == REQUIRED
    assert accepted['frozen_sha256'] == sha(HERE / 'FROZEN-INPUTS.json')
    assert accepted['review_sha256'] == sha(HERE / 'INPUT-REVIEW.md')
    pins = {}
    for name, value in frozen['files'].items():
        path = (HERE / name).resolve()
        assert path.is_relative_to(HERE) and path.is_file() and not (HERE / name).is_symlink()
        pins[path] = value
    for name, value in rd(HERE / 'EXTERNAL-PINS.json').items():
        path = Path(name)
        assert path.is_absolute() and path.is_file() and not path.is_symlink()
        assert path not in pins or pins[path] == value
        pins[path] = value
    for path, value in pins.items():
        assert sha(path) == value, str(path)
    for name, value in rd(HERE / 'READ-PINS.json').items():
        assert Path(name).is_absolute() and pins[Path(name)] == value
    # Bind the analyzed source files to the actual frozen c070 compile record.
    connected = ROOT / 'rmsnorm-pilot/model-consumption/connected'
    source_record_path = connected.parent / 'connected-SOURCES.json'
    assert source_record_path in pins
    source_record = rd(source_record_path)
    assert source_record['native_smt_sha256'] == 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
    assert pins[connected / 'native.smt2'] == source_record['native_smt_sha256']
    for name, value in source_record['files'].items():
        assert pins[connected / name] == value and sha(connected / name) == value
    assert pins[connected / 'compile.ys'] == source_record['script_sha256']
    prepare = load('_head_score_exponent_prepare', HERE / 'prepare_exponent.py', pins)
    queries, binding, plan, types, reads = prepare.assemble()
    assert plan['order'] == NAMES and plan['maximum_native_jobs_this_gate'] == 4
    assert plan == rd(HERE / 'QUERY-PLAN.json') and canonical(binding) == rd(HERE / 'SOURCE-BINDING.json')
    assert types == rd(HERE / 'TYPE-CHECK.json') and reads == rd(HERE / 'READ-PINS.json')
    for name in NAMES:
        assert queries[name] == (HERE / (name + '.smt2')).read_bytes()
        assert digest(queries[name]) == plan['queries'][name]['sha256']
    for name in ['mode_guard.py', 'probe_guard.py', 'support.py', 'source_typecheck.py',
                 'output_check.py', 'GUARD-SOURCE.json', 'GUARD-PROBES.json']:
        assert P / name in pins
    for label in ['helper', 'memory']:
        for name in ['STARTED.json', 'FINISHED.json', 'MONITOR-BINDING.json', 'NATIVE.log']:
            assert P / 'guard-probes' / label / name in pins
        assert P / 'guard-probes' / (label + '-observations.jsonl') in pins
    guard = load('_head_score_exponent_guard', P / 'mode_guard.py', pins)
    assert guard.SOURCE.resolve() in pins
    assert sha(guard.SOURCE) == rd(P / 'GUARD-SOURCE.json')['sha256']
    probes = rd(P / 'GUARD-PROBES.json')
    assert probes['passed'] is True and probes['post_stop_cleanup']['passed'] is True
    assert probes['post_stop_cleanup']['signals_sent_after_reaping'] is False
    assert probes['implementation']['mode_guard_sha256'] == sha(P / 'mode_guard.py')
    assert probes['implementation']['native_resource_guard_sha256'] == sha(guard.SOURCE)
    protocol = load('_head_score_exponent_protocol', P / 'output_check.py', pins)
    parser = load('_head_score_exponent_parser', P / 'support.py', pins)
    tool = rd(HERE / 'TOOL-PIN.json')
    assert tool == rd(ROOT / 'argmax-provider-pilot-r1/TOOLS.json')['tools']['z3']
    assert tool['sha256'] == 'ea69d1d234e0060fd480bf9b21a51f62244ed642ed2469d4373306e6e8ab6102'
    assert Path(tool['path']) in pins and sha(tool['path']) == tool['sha256']
    assert not any((HERE / name).exists() for name in ['RUN-INTENT.json', 'RESULTS.json', 'runs'])
    return pins, guard, protocol, parser, tool, plan


def run():
    pins, guard, protocol, parser, tool, plan = preflight()
    save('RUN-INTENT.json', {'scope': SCOPE, 'query_order': NAMES, 'query_plan_sha256': sha(HERE / 'QUERY-PLAN.json'),
        'tool': tool, 'max_native_jobs_this_gate': 4, 'phase_A_job_budget': 8,
        'workers': 1, 'RSS_and_physical_footprint_cap_bytes': 4 * (1 << 30),
        'time_or_CPU_kill_enabled': False, 'new_simulations_or_resource_probes': 0,
        'head_owner_saved_R0_or_selector_score_qualified': False})
    (HERE / 'runs').mkdir()
    results = []
    for name in NAMES:
        assert all(sha(path) == value for path, value in pins.items())
        assert all(row['matched'] is True for row in results)
        query = HERE / (name + '.smt2')
        argv = [tool['path'], '-smt2', '-st', '-memory:4096', str(query)]
        try:
            receipt, monitor = guard.execute(argv, HERE, HERE / 'runs' / name)
        except BaseException as error:
            save('RESULTS.json', {'scope': SCOPE, 'results': results, 'guard_error': repr(error),
                'active_owned_native_job': 'unconfirmed; inspect preserved native receipts',
                'all_expected_results_matched': False, 'head_owner_saved_R0_or_selector_score_qualified': False})
            return False
        folder = HERE / 'runs' / name
        forms, parse_error = [], None
        try:
            forms = [f for f, _, _ in parser.parse_spans((folder / 'NATIVE.log').read_bytes())]
        except Exception as error:
            parse_error = repr(error)
        matched = receipt['native_exit'] == 0 and receipt['resource_stop_reason'] is None and not receipt['monitor_errors']
        matched = bool(matched and parse_error is None and protocol.accept(forms, 'unsat', [])
                       and all(sha(path) == value for path, value in pins.items()))
        assert rd(folder / 'FINISHED.json') == canonical(receipt)
        assert rd(folder / 'MONITOR-BINDING.json') == canonical(monitor)
        row = {'name': name, 'expected': 'unsat', 'answer': forms[0] if forms else None,
            'matched': matched, 'parse_error': parse_error,
            'query_sha256': plan['queries'][name]['sha256'], 'binary_sha256': tool['sha256'],
            'raw_log_sha256': sha(folder / 'NATIVE.log'), 'receipt': receipt, 'monitor_binding': canonical(monitor),
            'head_owner_saved_R0_or_selector_score_qualified': False}
        with (folder / 'CHECKED-RESULT.json').open('x') as output:
            output.write(json.dumps(row, indent=2, sort_keys=True) + '\n')
        results.append(row)
        print(json.dumps({'name': name, 'answer': row['answer'], 'matched': matched,
                          'wall_seconds': receipt['wall_seconds']}), flush=True)
        if not matched:
            break
    passed = len(results) == 4 and all(row['matched'] for row in results)
    save('RESULTS.json', {'scope': SCOPE, 'results': results, 'all_expected_results_matched': passed,
        'active_owned_native_job': None, 'native_jobs': len(results), 'independent_result_review_pending': True,
        'head_owner_saved_R0_or_selector_score_qualified': False, 'whole_device_theorem': False})
    return passed


if __name__ == '__main__':
    assert sys.argv[1:] in ([], ['--preflight'])
    if sys.argv[1:]:
        pins, *_ = preflight()
        print(json.dumps({'preflight_passed': True, 'input_pins': len(pins), 'native_jobs': 0, 'writes': 0}))
        raise SystemExit(0)
    def interrupted(sig, frame):
        raise InterruptedError('Owned exponent gate interrupted')
    previous = signal.signal(signal.SIGTERM, interrupted)
    try:
        with (HERE / 'WORKER.lock').open('a') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            passed = run()
    finally:
        signal.signal(signal.SIGTERM, previous)
    raise SystemExit(0 if passed else 1)

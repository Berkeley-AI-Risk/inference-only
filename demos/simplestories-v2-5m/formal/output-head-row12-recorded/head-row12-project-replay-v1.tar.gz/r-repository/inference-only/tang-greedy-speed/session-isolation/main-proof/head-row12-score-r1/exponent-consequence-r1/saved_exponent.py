"""Fixed current/historical saved-RMS exponent consequence; unrun preparation."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json

CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
CURRENT = 'current-head-frame-original-RMS-exponent'
ROW = 'completed-row12-original-RMS-exponent'
I = 'i_saved_head_exponent'
N = 'n_saved_row_exponent'
W = 'saved-row-exponent-watch'
HS = 'original-head-exponent-owner-and-origin'
HF = 'original-head-exponent-saved-FRAME-link'
canon = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def prepare_metadata(exports, data, raw_pins):
    owner = data['owner_application']
    assert len(owner['application']['nodes']) == 96 and owner['type_check']['assertions'] == 98
    assert owner['prefix']['bounded_source_context_sha256'] == CONTEXT_SHA
    assert owner['prefix']['prefix_bound_domain'] == ['<=', '1', 'N']
    assert owner['prefix']['bounded_source_context'] == exports['prefix_artifact']['inherited_prefix_source_context']
    assert raw_pins['owner_application'] == 'ea1aa06d27b8fd0c42e6db9272cfb450711256153591fbd31d203ad8effbaeec'
    assert raw_pins['owner_review'] == 'be0b442731644ee005f7cf71058d9fbda3cd87095c5f7d8b9ee545fb1f366188'
    assert raw_pins['old_row_application'] == '4e0901b6a2b91b421191ca24622093df340a24fa47d6c87b7fc0d5dbbeee6fb0'
    assert raw_pins['old_row_review'] == 'f438c1214a6994cfe9507af4d7d3295f8c6f41dca3b396142307a094ba73b168'
    old = data['old_row_application']['application']
    assert old['root_context'] == owner['prefix']['bounded_source_context']
    assert old['row_application']['global_node'] == 282 and len(old['nodes']) == 283
    directory = 'frame-join-pilot/certificate-trace-application-r2/step-rms-origin-application-r1/'
    assert data['step_row_seal']['files'][directory + 'CAPTURE-ROW-APPLICATION-R1.json'] == raw_pins['old_row_application']
    assert data['step_row_seal']['files'][directory + 'CAPTURE-ROW-RESULT-REVIEW.md'] == raw_pins['old_row_review']
    assert data['frame_binding']['native_sha256'] == 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
    assert data['frame_results']['all_expected_results_matched']
    assert raw_pins['frame_review'] == '9b404e56c95c876bae0051707693186b32a8e4654bbbb7e3d216ef2948b854ca'
    return {'raw_pins': deepcopy(raw_pins), 'owner': owner, 'old': old}


def construct(proof, language, exports, data, prepared, steps, fixed):
    """Reuse only the accepted fixed bounded/definition helper methods."""
    api = exports['apis']
    class Application(fixed.FixedApplication):
        def __init__(self):
            self.proof, self.language, self.api, self.data, self.steps = proof, language, api, data, steps
            self.c, self.EQ, self.SUB = (api[k] for k in ['c', 'eq', 'SUB'])
            self.context = deepcopy(proof.root_context)
            assert digest(canon(self.context)) == CONTEXT_SHA
            assert not proof.nodes and not proof.active_indices and not proof.global_nodes
            self.imports, self.lookup_ledger = {}, []
            self.prepared = prepared

        def parents(self):
            p, c = self.proof, self.c
            domain = ['<=', '1', 'N']
            prefix = data['owner_application']['prefix']
            self.owner = self.import_fixed('accepted-bounded-original-HS', ['=>', domain, prefix['families'][HS]['bounded_formula']],
                prefix['families'][HS]['root_support'], {'application': prepared['raw_pins']['owner_application'], 'review': prepared['raw_pins']['owner_review']})
            self.link = self.import_fixed('accepted-bounded-original-HF', ['=>', domain, prefix['families'][HF]['bounded_formula']],
                prefix['families'][HF]['root_support'], {'application': prepared['raw_pins']['owner_application'], 'review': prepared['raw_pins']['owner_review']})
            self.frame = self.import_fixed('accepted-bounded-original-FRAME', ['=>', domain, data['dot_prefix']['earlier_bounded_consequences']['actual-frame']],
                self.context, {'seal': prepared['raw_pins']['dot_seal'], 'prefix': prepared['raw_pins']['dot_prefix']})
            self.control = self.import_fixed('accepted-bounded-original-control', ['=>', domain, data['dot_prefix']['earlier_bounded_consequences']['control']],
                self.context, {'seal': prepared['raw_pins']['dot_seal'], 'prefix': prepared['raw_pins']['dot_prefix']})
            self.endpoint = self.import_fixed('accepted-current-FRAME-endpoint', data['endpoint_application']['application']['literal_global_formula'],
                self.context, {'seal': prepared['raw_pins']['endpoint_seal'], 'application': prepared['raw_pins']['endpoint_application']})
            self.old_row = self.import_fixed('accepted-original-STEP-RMS-row12', prepared['old']['row_application']['literal_global_formula'],
                self.context, {'seal': prepared['raw_pins']['step_row_seal'], 'application': prepared['raw_pins']['old_row_application'], 'review': prepared['raw_pins']['old_row_review']})

        def saved_leaf(self, at, lower, upper):
            p, c = self.proof, self.c
            original = data['frame_binding']['goals']['owner-clock-and-saved-exponent']
            mapping = {'a': c('A', at), 'b': c('A', at), 'nf': c('NF', at), 'history': c('HS', at),
                'columns': c('COLUMNS', at), 'next-columns': c('COLUMNS', at),
                'job': c('c-base', c('CAPTURE', at)), 'next-job': c('c-base', c('CAPTURE', at)),
                'frame': c('FRAME', at), 'certificate': c('CERT', at), 'watch-frame': ['_', 'bv0', '10'],
                'watch': ['_', 'bv0', '8'], 'empty-frame': 'unused-frame', 'empty-nf': c('NFEMPTY', '0'),
                'observation': at, 'hs-event-at': 'actual-hs-event-at', 'hs-record-at': 'NF', 'hs-origin-I': 'actual-hs-origin-I'}
            whole = p.add('qualified-source-schema-uniform-instance', self.SUB(original, mapping), [lower, upper],
                original_query_goal=deepcopy(original), uniform_mapping=mapping,
                original_query_sha256=data['frame_plan']['queries']['owner-clock-and-saved-exponent']['sha256'],
                accepted_result_review_sha256=prepared['raw_pins']['frame_review'],
                actual_record_function_definition=deepcopy(language.defs['fj-capture-record-at']),
                original_record_function_declaration=['declare-fun', 'fj-capture-record-at', ['Int'], 'FrameRmsCertificate'])
            return self.part(whole, 2)

        def current(self):
            p, c = self.proof, self.c
            lower = p.open_index(CURRENT, I)
            view = c('fj-source-view', c('A', I), c('COLUMNS', I))
            guard = ['and', c('fv-live', view), c('fv-head', view), c('f-active', c('FRAME', I)), c('f-complete', c('FRAME', I))]
            case = p.assumption('CASE:current-owned-frame-saved-exponent', ['and', ['<=', '1', 'N'], ['<=', I, 'N'], guard])
            domain, upper, owned = [self.part(case, k) for k in [1, 2, 3]]
            endpoint = self.instantiate(self.endpoint, {'endpoint-watch': ['_', 'bv0', '8'], 'i_endpoint': I}, [lower, upper])
            endpoint = p.mp(p.mp(endpoint, lower), case)
            scalar = self.part(endpoint, 1)
            valid = self.part(scalar, 1)
            source_h = self.source_H_at(I, lower, upper)
            frame = self.bounded_instance(p.mp(self.frame, domain), I, lower, upper, {'frame-watch': ['_', 'bv0', '10']})
            owner = self.bounded_instance(p.mp(self.owner, domain), I, lower, upper)
            hs_I, origin = self.part(owner, 1), self.part(owner, 2)
            hf_I = self.bounded_instance(p.mp(self.link, domain), I, lower, upper)
            actual_guard = p.conjunction([self.part(owned, k) for k in [1, 2, 3]] + [valid])
            rule = self.saved_leaf(I, lower, upper)
            exponent = p.mp(rule, p.conjunction([source_h, frame, hs_I, hf_I, actual_guard]))
            alias = self.define('endpoint-saved-NF', [I], [lower, upper])
            equation = p.nodes[alias]['formula']
            exponent = p.rewrite(exponent, alias, equation[2], equation[1])
            claim = p.implication(case, p.conjunction([exponent, scalar, origin]))
            template = self.SUB(p.nodes[claim]['formula'], {I: '@index'})
            final = p.globalize(CURRENT, template, claim, I, [])
            self.current_global = final
            return {'global_node': final, 'literal_global_formula': p.nodes[final]['formula'],
                'guard': guard, 'exact_saved_exponent_parent': exponent, 'endpoint_scalar_parent': scalar}

        def row(self):
            p, c = self.proof, self.c
            lower_n = p.open_index(ROW, N)
            old_formula = prepared['old']['row_application']['literal_global_formula']
            guard = self.SUB(old_formula[2][2][1][3], {'n_row_origin': N})
            case = p.assumption('CASE:completed-original-row-saved-exponent', ['and', ['<=', '1', 'N'], ['<=', N, 'N'], guard])
            domain, upper_n, done = [self.part(case, k) for k in [1, 2, 3]]
            def old_at(word):
                rule = self.instantiate(self.old_row, {'row-origin-watch': word, 'n_row_origin': N}, [lower_n, upper_n])
                return p.mp(p.mp(rule, lower_n), case)
            scalar_row = old_at(['_', 'bv0', '8'])
            historical = self.part(scalar_row, 2)
            lower_j, before_j, capture, complete_frame = [self.part(historical, k) for k in [1, 2, 3, 4]]
            j = c('FRAMEORIGIN', N)
            upper_j = self.upper_from_strict(j, N, before_j, upper_n)
            source_h = self.source_H_at(j, lower_j, upper_j)
            control = self.bounded_instance(p.mp(self.control, domain), j, lower_j, upper_j, {'watch': '0'})
            phase = self.part(control, 8)
            binding = data['row_guard_binding']
            mapping = {'a': c('A', j), 'columns': c('COLUMNS', j), 'row': c('ROW', j), 'header': c('HEADER', j)}
            whole = p.add('qualified-source-schema-uniform-instance', self.SUB(binding['combined_goal'], mapping), [lower_j, upper_j],
                original_query_goal=deepcopy(binding['combined_goal']), uniform_mapping=mapping,
                original_query_sha256='6c28a54981eefd6e1746f6be37b96d7debdd8a99e7ca4bf5ad66687c6c97ccde',
                accepted_row_guard_seal_sha256=prepared['raw_pins']['row_guard_seal'],
                accepted_raw_result_adjudication=deepcopy(data['row_guard_result']))
            owned = p.mp(self.part(whole, 3), p.conjunction([source_h, phase, capture]))
            live, engine, head = [self.part(owned, k) for k in [1, 2, 3]]
            phase_body = self.unfold(phase, 'selected-row-phase-I', [c('A', j), c('COLUMNS', j), c('ROW', j), c('HEADER', j)], [lower_j, upper_j])
            active_engine = self.part(phase_body, 3)
            choices = p.nodes[active_engine]['formula'][1][2]
            engine_active = self.or_intro(engine, choices[1:])
            job_active = p.mp(active_engine, p.conjunction([live, engine_active]))
            job_state = self.part(job_active, 1)
            frame = self.bounded_instance(p.mp(self.frame, domain), j, lower_j, upper_j, {'frame-watch': ['_', 'bv0', '10']})
            frame_body = self.unfold(frame, 'frame-I', [c('A', j), c('COLUMNS', j), c('c-base', c('CAPTURE', j)), c('FRAME', j), ['_', 'bv0', '10']], [lower_j, upper_j])
            frame_live = p.mp(self.part(frame_body, 2), live)
            active_eq = self.part(frame_live, 1)
            choices = p.nodes[active_eq]['formula'][2]
            active = self.or_intro(job_state, choices[1:])
            active = p.rewrite(active, active_eq, choices, c('f-active', c('FRAME', j)))
            live_alias, head_alias = [self.view_field_alias(j, field, lower_j, upper_j) for field in ['live', 'head']]
            view_live = p.rewrite(live, live_alias, p.nodes[live_alias]['formula'][2], p.nodes[live_alias]['formula'][1])
            view_head = p.rewrite(head, head_alias, p.nodes[head_alias]['formula'][2], p.nodes[head_alias]['formula'][1])
            actual_guard = p.conjunction([view_live, view_head, active, complete_frame])
            current_rule = self.instantiate(self.current_global, {I: j}, [lower_j, upper_j])
            current = p.mp(p.mp(current_rule, lower_j), p.conjunction([domain, upper_j, actual_guard]))
            exponent = self.part(current, 1)
            scalar_end = len(p.nodes) - 1
            self.language.decls[W] = ['declare-const', W, ['_', 'BitVec', '8']]
            word_row = old_at(W)
            claim = p.implication(case, p.conjunction([word_row, exponent]))
            template = self.SUB(p.nodes[claim]['formula'], {N: '@index'})
            final = p.globalize(ROW, template, claim, N, [[W, ['_', 'BitVec', '8']]])
            self.lookup_ledger.append({'index': j, 'lower_parent': lower_j, 'strict_past_parent': before_j,
                'upper_parent': upper_j, 'actual_frame_guard_parent': actual_guard,
                'current_exponent_instance_parent': current, 'source_edge_requested': False,
                'historical_INDEX_assumption': False})
            return {'global_node': final, 'literal_global_formula': p.nodes[final]['formula'],
                'scalar_nodes_end_before_word': scalar_end, 'word_parameter': W, 'one_original_row_capture': j}
    app = Application()
    app.parents()
    current, row = app.current(), app.row()
    assert not proof.active_indices and len(proof.nodes) <= 256
    assert proof.root_context == app.context
    return deepcopy({'kind': 'original-saved-RMS-exponent-current-FRAME-and-historical-row12',
        'nodes': proof.nodes, 'global_nodes': proof.global_nodes, 'root_context': app.context,
        'current': current, 'row': row, 'lookup_ledger': app.lookup_ledger,
        'new_native_jobs': 0, 'new_inductions': 0, 'current_or_future_health_filter_added': False,
        'current_NF_substituted_after_FRAME_completion': False, 'postscale_or_selector_score_proved': False,
        'whole_device_theorem': False})

"""Pure full-native physical row/E exponent continuity preparation."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from pathlib import Path
import hashlib
import json
import sys
import types
sys.dont_write_bytecode = True
sys.setrecursionlimit(30000)
HERE = Path(__file__).resolve().parent
C = HERE.parent
ROOT = C.parent
S = '|core_workflow_control_s|'
E = 'u_native.u_six_layers.u_datapath.u_projection.u_shared_engine.u_engine.'
ORDER = ['row-engine-exponent-reset-base', 'row-engine-exponent-preserve']
READS = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
c = lambda name, *args: [name, *args]
AND = lambda *args: c('and', *args)
OR = lambda *args: c('or', *args)
EQ = lambda x, y: c('=', x, y)
NOT = lambda x: c('not', x)
IMP = lambda x, y: c('=>', x, y)
BV = lambda n, w: ['_', 'bv' + str(n), str(w)]
SUB = lambda x, m: m.get(x, x) if isinstance(x, str) else [SUB(t, m) for t in x]


def read(path, expected=None):
    path = Path(path).resolve()
    raw = path.read_bytes()
    value = digest(raw)
    assert expected is None or value == expected, str(path)
    assert READS.setdefault(str(path), value) == value
    return raw


def assemble():
    READS.clear()
    path = C / 'prepare_exponent.py'
    prep = types.ModuleType('_row_exp_existing_helpers')
    prep.__file__ = str(path)
    exec(compile(read(path, '7eb5e7b8917d57e3d5e14a78620d922276901e6d6623a913630e4c80a7ba6cc4'), str(path), 'exec'), prep.__dict__)
    with prep.checked_helpers() as (parser, typing):
        raw = read(ROOT / 'rmsnorm-pilot/model-consumption/connected/native.smt2', prep.NATIVE_SHA)
        native = [f for f, _, _ in parser.parse_spans(raw)]
        defs = {f[1]: f for f in native if f[0] == 'define-fun'}
        assert len(defs['|core_workflow_control_t|'][4]) - 1 == 452
        old_raw = read(ROOT / 'head-completed-model-dot-r1/COMPLETED-DOT-TYPING-ONLY.smt2',
            '11ff55d9fbd14af2deba9ec517f9fd5e01ff44d45be89083afa7ae2ce26dbe8a')
        seal = json.loads(read(ROOT / 'HEAD-COMPLETED-MODEL-DOT-R1-SEALED.json',
            'c5591f6f05aa192edc891e8a6888e43895cc1d9b00a11eb067a0995d4c23b99e'))
        assert seal['files']['COMPLETED-DOT-TYPING-ONLY.smt2'] == digest(old_raw)
        old_forms = [f for f, _, _ in parser.parse_spans(old_raw)]
        old_defs = {f[1]: f for f in old_forms if f[0] == 'define-fun'}
        seeds = {'row-source-view', 'selected-row-zero', 'selected-row-next',
            'row-frame-effective-capture', 'row-frame-origin-index-next'}
        required = set()
        def require(name):
            if name in required or name in defs:
                return
            assert name in old_defs, name
            required.add(name)
            for dependency in sorted(parser.atoms(old_defs[name][4]) & set(old_defs)):
                require(dependency)
        for name in sorted(seeds):
            require(name)
        source_helpers = [f for f in old_forms if f[0] == 'declare-datatypes' or f[0] == 'define-fun' and f[1] in required]
        assert {f[1] for f in source_helpers if f[0] == 'define-fun'} == required
        referenced = parser.atoms(source_helpers) & set(defs)
        getter_names = sorted(name for name in referenced if name.startswith('|core_workflow_control_n '))
        assert getter_names and all(old_defs[name] == defs[name] for name in getter_names)
        getters = {}
        def getter(path, state='s'):
            name = '|core_workflow_control_n ' + path + '|'
            assert defs[name][2] == [['state', S]]
            getters[path] = {'literal_getter_definition': defs[name], 'sort': defs[name][3]}
            return c(name, state)
        exponent = lambda state: getter(E + 'activation_exponent_q', state)
        active = OR(*[EQ(getter(E + 'state_q'), BV(v, 3)) for v in [1, 2, 3, 4, 5]])
        function = ['declare-fun', 'row-engine-exp-at', ['Int'], ['_', 'BitVec', '8']]
        invariant = ['define-fun', 'row-eexp-I', [['s', S], ['r', 'SelectedRow'], ['origin', 'Int']], 'Bool',
            IMP(AND(active, c('rr-physical', 'r'), c('>', c('rr-n', 'r'), '0')),
                EQ(exponent('s'), c('row-engine-exp-at', 'origin')))]
        view = c('row-source-view', 'a', 'columns')
        row_next = c('selected-row-next', 'row', view, 'empty-a', 'empty-w', 'empty-prefix')
        origin_next = c('row-frame-origin-index-next', view, 'row', 'observation', 'old-origin')
        ha, hb, transition = c('|core_workflow_control_h|', 'a'), c('|core_workflow_control_h|', 'b'), c('|core_workflow_control_t|', 'a', 'b')
        base = IMP(AND(ha, NOT(getter('reset_n', 'a'))), c('row-eexp-I', 'a', 'row', 'old-origin'))
        bridge = EQ(c('row-engine-exp-at', 'observation'), exponent('a'))
        providers = [ha, hb, transition, c('row-eexp-I', 'a', 'row', 'old-origin'), bridge]
        preserve = IMP(AND(*providers), c('row-eexp-I', 'b', row_next, origin_next))
        goals = dict(zip(ORDER, [base, preserve]))
        parameters = [('a', S), ('b', S), ('columns', 'ColumnHistory'), ('row', 'SelectedRow'),
            ('old-origin', 'Int'), ('observation', 'Int'),
            ('empty-a', ['Array', 'Int', ['_', 'BitVec', '16']]),
            ('empty-w', ['Array', 'Int', ['_', 'BitVec', '10']]), ('empty-prefix', ['Array', 'Int', 'Int'])]
        declarations = [['declare-const', name, sort] for name, sort in parameters]
        helpers = [*source_helpers, function, invariant]
        queries, reports = {}, {}
        for name in ORDER:
            additions = [*helpers, *declarations, ['assert', NOT(goals[name])],
                ['check-sat-using', ['then', 'simplify', 'propagate-values', 'solve-eqs', 'simplify', 'smt']], ['exit']]
            query = raw + ('\n' + '\n'.join(map(parser.smt, additions)) + '\n').encode()
            assert [f for f, _, _ in parser.parse_spans(query) if f[0] == 'assert'] == [['assert', NOT(goals[name])]]
            reports[name] = typing.check(query)
            queries[name] = query
        actual_name = 'actual-row-engine-exp-at'
        actual_function = ['define-fun', actual_name, [['row-exp-observation', 'Int']], ['_', 'BitVec', '8'],
            getter(E + 'activation_exponent_q', c('A', 'row-exp-observation'))]
        function_map = {'row-engine-exp-at': actual_name, 'row-eexp-I': 'actual-row-eexp-I'}
        READS.update(prep.READS)
        read(HERE / 'prepare_continuity.py')
        binding = {'native_sha256': prep.NATIVE_SHA, 'native_T_conjuncts': 452,
            'entire_native_prefix_retained': True, 'native_getter_bindings': getters,
            'qualified_source_getters_literal': {name: old_defs[name] for name in getter_names},
            'original_source_helpers': source_helpers, 'required_helper_names': sorted(required),
            'fixed_function_declaration': function, 'scalar_invariant': invariant, 'helpers': helpers,
            'declarations': declarations, 'goals': goals, 'preservation_providers': providers,
            'next_row': row_next, 'next_origin': origin_next, 'current_point_bridge': bridge,
            'future_fixed_actual_function_definition': actual_function,
            'future_uniform_function_mapping': function_map, 'future_actual_invariant': SUB(invariant, function_map),
            'array_parameters_are_arbitrary_and_match_original_observer_constants': True,
            'new_observer_or_driving_state': False, 'health_filter_or_extra_control_provider_added': False,
            'ordinary_prefix_or_original_R0_application_proved': False,
            'read_model_metadata_scale_selector_join_proved': False, 'new_native_jobs': 0}
        plan = {'scope': 'two-c070-physical-row-engine-exponent-continuity-leaves', 'order': ORDER,
            'queries': {name: {'sha256': digest(queries[name]), 'expected': 'unsat'} for name in ORDER},
            'maximum_native_jobs_this_gate': 2, 'diagnostic_launch_authorized_by_this_gate': False,
            'workers': 1, 'memory_cap_bytes': 4 * (1 << 30), 'new_native_jobs': 0,
            'time_or_CPU_kill_enabled': False, 'unexpected_result_stops_dependents': True}
        return queries, binding, plan, reports, dict(READS)


if __name__ == '__main__':
    queries, binding, plan, types, pins = assemble()
    for name, raw in queries.items():
        with (HERE / (name + '.smt2')).open('xb') as output:
            output.write(raw)
    for name, value in [('SOURCE-BINDING.json', binding), ('QUERY-PLAN.json', plan),
                        ('TYPE-CHECK.json', types), ('READ-PINS.json', pins)]:
        with (HERE / name).open('x') as output:
            output.write(json.dumps(value, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_queries': list(queries), 'new_native_jobs': 0}))

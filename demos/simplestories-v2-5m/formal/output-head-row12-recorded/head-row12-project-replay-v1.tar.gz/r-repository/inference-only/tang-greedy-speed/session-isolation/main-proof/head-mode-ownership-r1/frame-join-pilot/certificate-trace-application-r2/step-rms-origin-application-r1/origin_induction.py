"""Two fixed original NF stamp inductions; no I/O, source axiom or engine.

The caller binds the reviewed raw inputs and accepted API before initialization.
The finite-prefix validator is separate. Importing this module constructs nothing.
"""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json

QUERY = '0546fed421cf268742c0d1126646381518e7a1c242c21204951b4ce1d22d786a'
GATE_SEAL = '14820c5c54089ce586886f33c42c900beac1ea047e11a8edd5b2f9aefef6c325'
GATE_REVIEW = '1fe7a63c82e3ed5ce9f07cd2145bb3ed85555c2e8eacd082364c193295298f49'
SOURCE = 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54'
TYPES = ('STEP', 'RMS')
PARAMETERS = {'history', 'event', 'event-payload', 'next-valid', 'observation',
              'initial-payload', 's', 'h', 'empty-nf'}
ROOTS = {'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-0',
         'Gamma:entry-reset-low-at-1', 'Gamma:runtime-entry-image',
         'Gamma:static-metadata', 'Gamma:vendor-storage'}
digest = lambda raw: hashlib.sha256(raw).hexdigest()


def prepare_metadata(exports, raw, raw_manifest):
    """Pure fixed provenance/AST checks before a Proof initializer is called."""
    api = exports['apis']
    assert set(raw) == set(raw_manifest['pins'])
    assert all(digest(value) == raw_manifest['pins'][key] for key, value in raw.items())
    assert digest(raw['gate_seal']) == GATE_SEAL and digest(raw['query']) == QUERY
    assert digest(raw['gate_review']) == GATE_REVIEW
    packet = {name: json.loads(value) for name, value in raw.items()
              if not name.endswith(('query', 'typing', 'review', 'source'))}
    construction = json.loads(raw['construction'])
    forms = [f for f, _, _ in api['parse_spans'](raw['query'])]
    goal = construction['combined_goal']
    assert [f[1] for f in forms if f[0] == 'assert'] == [['not', goal]]
    assert {f[1] for f in forms if f[0] == 'declare-const'} == PARAMETERS
    fact_order = ['STEP-zero-projection', 'RMS-zero-projection',
        'STEP-next-projection', 'STEP-next-validity-support',
        'RMS-next-projection', 'RMS-next-validity-support']
    assert set(fact_order) == set(construction['source_recurrence_facts'])
    assert goal == ['and', construction['generic_base'], construction['generic_step'],
                    *[construction['source_recurrence_facts'][name] for name in fact_order],
                    ['=>', construction['certificate_order_premise'],
                     construction['certificate_order_conclusion']]]
    assert len(goal) == 10
    row = next(r for r in packet['gate_results']['results']
               if r['name'] == 'stamped-origin-zero-step-and-nf-recurrences')
    assert row['answer'] == 'unsat' and row['query_sha256'] == QUERY
    assert packet['gate_check']['passed'] is True
    assert packet['gate_check']['independent_replay_review_bound'] is True
    assert packet['gate_check']['result_review_sha256'] == GATE_REVIEW
    assert packet['gate_check']['results'][row['name']]['query_sha256'] == QUERY
    assert packet['gate_seal']['files'][
        'frame-join-pilot/certificate-closure-gate-r1/' + row['name'] + '.smt2'] == QUERY
    provider = exports['nf_provider']
    assert construction['literal_NF_datatype'] == provider['helpers'][0]
    assert construction['literal_nf_zero'] == provider['helpers'][1]
    assert construction['literal_nf_next'] == provider['helpers'][2]
    assert construction['literal_nf_I_timing_conjunct'] == provider['helpers'][3][4][1]
    assert exports['context']['Gamma:actual-composed-source']['native_core_sha256'] == SOURCE
    assert set(exports['context']) == ROOTS
    helper_forms = deepcopy(construction['generic_helpers'])
    assert helper_forms[3] == ['declare-fun', 'stamped-event-at', ['Int'], 'StampedEvent']
    generic_I = helper_forms[6]
    assert generic_I[:2] == ['define-fun', 'stamped-origin-I']
    theory = [*helper_forms[:3], *helper_forms[4:6],
              *construction['source_helper_definitions']]
    events, invariants = {}, {}
    for which in TYPES:
        lower = which.lower()
        event_name = 'actual-' + which + '-event-at'
        I_name = 'actual-' + which + '-origin-I'
        arguments = [['origin-observation', 'Int']]
        i = 'origin-observation'
        state, nf = ['A', i], ['NF', i]
        event = ['nf-effective-' + ('step' if which == 'STEP' else 'rms-start') + '-event', state]
        payload = 'stampedUnit' if which == 'STEP' else ['nf-rms-start-payload', state, nf]
        events[which] = ['define-fun', event_name, arguments, 'StampedEvent',
                         ['mkStampedEvent', event, payload]]
        invariants[which] = api['SUB'](generic_I,
            {'stamped-event-at': event_name, 'stamped-origin-I': I_name})
        theory += [events[which], invariants[which]]
        assert not any('watch' in atom for atom in api['atoms']([events[which], invariants[which]]))
    return deepcopy({'construction': construction, 'goal': goal,
        'theory': theory, 'events': events, 'invariants': invariants,
        'query_sha256': QUERY, 'result_review_sha256': GATE_REVIEW,
        'raw_pins': raw_manifest['pins']})


def construct_origins(proof, language, exports, prepared, logical_steps):
    """Apply the accepted generic stamp lemma to the one original NF history."""
    api = exports['apis']
    assert proof.root_context == exports['context']
    assert not proof.nodes and not proof.active_indices and not proof.global_nodes
    c, EQ, SUB = api['c'], api['eq'], api['SUB']
    language.add(exports['nf_provider']['helpers'])
    language.add(prepared['theory'])
    ARRAY = ['Array', ['_', 'BitVec', '8'], ['_', 'BitVec', '16']]
    language.decls['NF'] = ['declare-fun', 'NF', ['Int'], 'NormFrame']
    language.decls['NFEMPTY'] = ['declare-fun', 'NFEMPTY', ['Int'], ARRAY]
    cst = prepared['construction']
    before_context = deepcopy(proof.root_context)
    reports = {}

    def part(parent, position):
        formula = proof.nodes[parent]['formula']
        assert formula[0] == 'and' and 1 <= position < len(formula)
        return proof.add('conjunction-elimination', formula[position], [parent], position=position)

    def recurrence(index, step=False):
        if step:
            formula = EQ(c('NF', c('+', index, '1')),
                         c('nf-next', c('A', index), c('NF', index), c('NFEMPTY', index)))
            parents = proof.index_parents(index)
            support = proof.index_support(index, True)
        else:
            assert index == '1'
            formula = EQ(c('NF', '1'), c('nf-zero', c('NFEMPTY', '0')))
            parents, support = [], []
        return proof.add('total-same-trace-nondriving-component-observer-definition',
            formula, parents, support=['Gamma:actual-composed-source', *support],
            registry='original-NF', index=index, step=step,
            watched_index_not_an_observer_argument=True,
            exact_source_definition=exports['nf_provider']['helpers'][2 if step else 1])

    def whole(which, index, empty_index):
        nf, state = c('NF', index), c('A', index)
        observer = c('nf-' + which.lower() + '-origin-observer', nf)
        event = c('nf-effective-' + ('step' if which == 'STEP' else 'rms-start') + '-event', state)
        payload = 'stampedUnit' if which == 'STEP' else c('nf-rms-start-payload', state, nf)
        successor = c('nf-next', state, nf, c('NFEMPTY', empty_index))
        mapping = {'history': observer, 'event': event, 'event-payload': payload,
            'next-valid': c('nf-sv' if which == 'STEP' else 'nf-active', successor),
            'observation': index, 'initial-payload': 'stampedUnit' if which == 'STEP'
                else c('stampedRmsStart', '0', ['_', 'bv0', '12']),
            's': state, 'h': nf, 'empty-nf': c('NFEMPTY', empty_index),
            'stamped-origin-I': 'actual-' + which + '-origin-I',
            'stamped-event-at': 'actual-' + which + '-event-at'}
        assert set(mapping) == PARAMETERS | {'stamped-origin-I', 'stamped-event-at'}
        return proof.add('qualified-source-schema-uniform-instance', SUB(prepared['goal'], mapping),
            original_query_goal=deepcopy(prepared['goal']), uniform_mapping=mapping,
            original_query_sha256=QUERY, accepted_gate_seal_sha256=GATE_SEAL,
            accepted_result_review_sha256=GATE_REVIEW,
            actual_event_function_definition=prepared['events'][which],
            actual_origin_definition=prepared['invariants'][which])

    for which in TYPES:
        family = 'original-' + which + '-event-origin'
        index = 'n_' + which + '_origin'
        template = c('actual-' + which + '-origin-I',
                     c('nf-' + which.lower() + '-origin-observer', c('NF', '@index')), '@index')
        base_all = whole(which, '1', '0')
        base = part(base_all, 1)
        base_rule = base
        zero_projection = part(base_all, 3 if which == 'STEP' else 4)
        zero_eq = proof.nodes[zero_projection]['formula']
        base = proof.rewrite(base, zero_projection, zero_eq[2], zero_eq[1])
        zero = recurrence('1')
        zero_eq = proof.nodes[zero]['formula']
        base = proof.rewrite(base, zero, zero_eq[2], zero_eq[1])
        lower = proof.open_index(family, index)
        ih = proof.add('scoped-induction-hypothesis', SUB(template, {'@index': index}),
                       [lower], support=['IH:' + family], scope=index)
        all_step = whole(which, index, index)
        rule = part(all_step, 2)
        valid = part(all_step, 6 if which == 'STEP' else 8)
        validity_clause = valid
        # The source projection uses nf-sv/active; the generic antecedent uses
        # so-valid(observer(h)). Bridge them by its literal constructor selector.
        valid_alias = logical_steps.observer_selector(proof, language, api,
            'nf-' + which.lower() + '-origin-observer', c('NF', index), 'valid')
        valid_eq = proof.nodes[valid_alias]['formula']
        valid = proof.rewrite(valid, valid_alias, valid_eq[2], valid_eq[1])
        event_def = prepared['events'][which]
        arguments = {event_def[2][0][0]: index}
        event_equation = proof.add('literal-function-definition-instance',
            EQ(c(event_def[1], index), SUB(event_def[4], arguments)),
            definition=event_def, uniform_mapping=arguments)
        premise = proof.conjunction([lower, ih, valid, event_equation])
        step = proof.mp(rule, premise)
        applied_step = step
        next_projection = part(all_step, 5 if which == 'STEP' else 7)
        next_eq = proof.nodes[next_projection]['formula']
        step = proof.rewrite(step, next_projection, next_eq[2], next_eq[1])
        next_nf = recurrence(index, True)
        next_eq = proof.nodes[next_nf]['formula']
        step = proof.rewrite(step, next_nf, next_eq[2], next_eq[1])
        assert proof.nodes[base]['formula'] == SUB(template, {'@index': '1'})
        assert proof.nodes[step]['formula'] == SUB(template, {'@index': c('+', index, '1')})
        final = api['close_factory'](proof)(family, template, base, step, index, ih, [])
        assert set(proof.nodes[final]['support']) == {'Gamma:actual-composed-source'}
        reports[which] = {'family': family, 'global_node': final,
            'property_template': template, 'base_parent': base, 'step_parent': step,
            'base_NF_recurrence_parent': zero, 'step_NF_recurrence_parent': next_nf,
            'base_whole_query_parent': base_all, 'base_rule_parent': base_rule,
            'base_zero_projection_parent': zero_projection,
            'step_whole_query_parent': all_step, 'generic_step_rule_parent': rule,
            'source_validity_clause_parent': validity_clause,
            'validity_observer_alias_parent': valid_alias, 'rewritten_validity_parent': valid,
            'current_event_definition_parent': event_equation,
            'step_premise_parent': premise, 'applied_generic_step_parent': applied_step,
            'next_observer_projection_parent': next_projection,
            'fixed_actual_event_definition': prepared['events'][which],
            'fixed_origin_predicate_definition': prepared['invariants'][which]}
    assert not proof.active_indices and proof.root_context == before_context
    assert len(proof.nodes) <= 64
    for i, node in enumerate(proof.nodes):
        assert node['id'] == i
        support = set(node['introduced_support'])
        for parent in node['parents']:
            assert 0 <= parent < i
            support.update(proof.nodes[parent]['support'])
        assert support - set(node.get('discharged_support', [])) == set(node['support'])
    return deepcopy({'kind': 'original-STEP-and-RMS-NF-stamped-origin-ordinary-inductions',
        'nodes': proof.nodes, 'global_nodes': proof.global_nodes, 'families': reports,
        'root_context': proof.root_context, 'query_sha256': QUERY,
        'raw_pins': prepared['raw_pins'], 'new_native_jobs': 0,
        'bounded_prefix_export_qualified': False, 'saved_capture_application_proved': False,
        'historical_row12_join_proved': False, 'numerical_RMS_proved': False,
        'whole_device_theorem': False})

# One original head-start exponent owner

This additive three-query batch continues the independently accepted four
native exponent leaves. No engine has run in this batch. The parent plan and
review remain unchanged. BUDGET-CLARIFICATION-20261112.md records that further
useful exact batches may be reviewed without a new user approval.

Define one nondriving HeadExponentHistory, with valid, original observation
and full original NF snapshot. Reset/CLEAR revokes validity; effective D head
capture otherwise records NF and observation=nf-t(NF)+1; all other edges hold.
The snapshot is fixed before a word. Retained physical payload after fault
is historical truth, not current authority. It grants no canceled work a new
identity. Actual current use retains the source live/phase conditions.

The single compound invariant hs-I has four clauses:

1. A valid snapshot is an accepted completed NF (active, STEP-valid, count256,
   RMS parent equals STEP ID) at the original capture.
2. D reset-high, no-CLEAR, valid history implies its physical exponent register
   equals that snapshot exponent, even in a fault-held phase.
3. Live D in E_HEAD implies a valid owner, six-field protected equality of its
   snapshot to current NF, and live-shell phase17..21. Protected equality is
   exactly data/exp/RMS-UID/RMS-parent/STEP-ID/prefix, excluding the advancing
   clock, count and activity flags. This covers pre-J birth and shell failure.
4. Live J, stored job7, phase LOAD/GROUP_START/GROUP_RUN/DONE implies D E_HEAD,
   a valid owner and its physical J exponent equal to the original snapshot.
   This same invariant extends physical exponent retention beyond JLOAD;
   there is no assumed descriptor birth or supplied correct exponent.

The actual ASTs, native getter definitions, source event definitions and
qualified NF helpers are recorded in SOURCE-BINDING.json. No source/module
renaming, future-health condition or production RTL change is permitted.

Queries, in strict dependency order:

- Base: native H and root reset-low imply hs-I with hs-zero(arbitrary NF).
- Preserve: H(a), H(b), all452 T(a,b), qualified nf-I at both endpoints and
  current hs-I imply hs-I at b for the literal nf-next/hs-next. Successor nf-I
  is an independently qualified acyclic provider, not a success/health filter.
- Origin: generic zero and step for one fixed capture-event and NF-record
  function, plus literal identity between actual hs-next and generic-next.
  Valid history implies1<=original observation<current observation, the
  actual capture event at that original observation and its exact NF snapshot.
  Later finite-prefix application must supply clock=observation-1, actual
  recurrences and derived historical bounds, never INDEX(original).

Review the exact prepared queries, runner, pins and source priorities before
launch. Three first attempts only, one owned worker, 4 GiB RSS/footprint and
internal memory4096, actual normal Darwin pressure. Reuse the pinned accepted
guard/probe receipts. No new probes, simulation, compile, wall/CPU/token kill,
free-RAM floor or simulator slot. An unexpected answer stops dependents and
saves the exact failure. Diagnostics or source-justified changes need another
small reviewed additive gate. Do not weaken, blindly retry or overwrite.

Even successful leaves do not yet provide their ordinary finite-prefix typed
application or connect the owner to the exact saved R0 through the completed
frame/row epoch. That temporal join must be separately checked; in particular
later NF replacement cannot be ignored. Metadata, registered dot read,
postscale and actual selector admission remain downstream. Upstream numerical
RMS is another task. No Lean, public, board or whole-device claim is involved.

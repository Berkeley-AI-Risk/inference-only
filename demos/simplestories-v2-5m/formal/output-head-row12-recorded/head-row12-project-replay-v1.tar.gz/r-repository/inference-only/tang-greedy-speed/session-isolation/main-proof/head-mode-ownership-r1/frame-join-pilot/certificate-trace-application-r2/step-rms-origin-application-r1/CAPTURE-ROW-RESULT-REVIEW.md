# Independent actual STEP/RMS capture-to-row12 result review

**Decision: PASS. Accept the actual saved-capture and completed-row12
composition, with the exact literal exports described below.** The source
proof identifies one effective STEP, one final-RMS API admission and the saved
NF record before the original row snapshot, then joins its all-word identity
to the already qualified fixed-model signed dot. Numerical RMS/model-vector
meaning, exponent/scaling, later head/token/publication behavior and the
whole-device theorem remain open. Closed component packaging/replay is the
next separate closeout.

## Accepted artifacts and independent reconstruction

| Artifact | SHA256 |
| --- | --- |
| `CAPTURE-ROW-INPUTS-R1.json` | `ddc182e63ed76750d3a00a0effacadecfc737bbbf61c750b55ab9ea6283e8a14` |
| `CAPTURE-ROW-METADATA-R1.json` | `08636e80d032fde702cc3568cf32e85e1daefb78465489b8307550a307d0af86` |
| `CAPTURE-ROW-APPLICATION-R1.json` | `4e0901b6a2b91b421191ca24622093df340a24fa47d6c87b7fc0d5dbbeee6fb0` |
| `CAPTURE-ROW-APPLICATION-R1-TYPING-ONLY.smt2` | `0a01f998369553fe2fd8eb07658f3fd9cfeffe2639589273fb035fd760391964` |

The exact thirteen-entry envelope binds the reviewed application `13140a71...`,
driver `10ed5e5e...`, input review `75f9ec5d...`, accepted origin application
`05dea608...`/review `5df15673...`, original raw manifest, and supplemental
actual sealed dot typing `11ff55d9...`. All entries, 27 raw pins, supplemental
typing/seal identity and recorded actual reads/helpers match current bytes.

I ran the genuine pinned driver once read-only in fresh isolated/no-site/
no-bytecode Python3.12 and retained the full tool result. It exited zero in
7.54 seconds. The entire reconstructed JSON serialization and typing bytes
are identical to the saved outputs. There are 283 nodes, globals165 and282,
73 actual reads and 15 executed helpers, all matching. The metadata artifact
uses the same envelope and reports zero initializers/nodes, 72 matching reads,
14 helpers and 15,289 compatible theory forms.

The pure typechecker reports 283 assertions and 15,459 symbols. This is sort
evidence. I separately checked every actual formula/parent rule, component
provenance and inherited/discharged support, including the new elementary
rules. No solver, guard/probe, simulation, old parent-proof reconstruction or
output overwrite ran. Only this new review was written.

## Source and rule provenance

All seven fixed component imports equal their accepted literal formulas:
current FRAME endpoint, bounded NF invariant, both bounded actual event
origins, completed saved-frame model dot, bounded control and bounded frame.
Their source contexts equal the exact six-root bounded context `41af6255...`.
The current source-H point clause is the literal `0..N` context field, not an
unbounded or independently assumed source fact.

The three integer upper-bound instances match accepted query `c7f7abea...`;
the full nine-clause stamped instance matches `0546fed4...`; and the actual
row-capture guard matches `6c28a549...` with the accepted raw adjudication and
preserved original wrapper-failure provenance. All eleven forall-elimination
nodes use complete substitutions and retain their original domains/guards.

I checked all 283 nodes: conjunction introduction/elimination, MP, function
definitions, concrete datatype selectors, equality-context substitution,
symmetry, fixed theorem/source imports, quantifier specialization, scopes and
final globalization. The two symmetry nodes reverse their actual equality
parents. Both OR-introduction nodes select an actual proved disjunct. The one
threshold weakening has actual `1<=j` as parent, concludes `0<=j` for that same
integer term and records literal thresholds0/1. Passing node labels alone
were not used as justification. Both final supports are exactly the original
six roots; no historical INDEX or new induction is present.

## Saved k, staged p/r lookups and RMS payload

The current endpoint is applied at word zero before any fresh capture word.
Its actual scalar identity and lower/upper k parents are retained. Bounded
origin/NF instances at k preserve those range parents. Opening their scalar
clock/guarded clauses and reducing observer constructors does not unfold an
actual historical event function.

The graph first derives both individual p/r lower and upper bounds. Only then
does it unfold actual event functions at those original observations. The
lookup ledger's raw bounds match their actual formulas and its folded bounds
match the exact helper terms through their actual alias-definition equations.
RMS payload lookup includes both A(r) and NF(r); no source edge at k/p/r is
requested. The accepted timing clause and established observation-minus-one
clock give p<r; all scalars are completed before word choice.

Concrete stampedRmsStart selectors yield the actual native statements:

```text
NF(r).sid = R0.sparent = R0.sid
committed_count_q(A(r)) = R0.prefix.
```

The second equality is the pre-edge count at the actual RMS admission, not a
replay-position reconstruction. Both event predicates and their exact native
guard expansions appear in the result. The p/r helper definitions use only
the same saved NF and are independent of the watched coordinate. Source
identifiers retain their distinct clock/UID meanings.

Capture scalar work ends at node158; the fresh-word application starts after
it, and global165 closes the exact case/index scope with the literal
`forall(word,i)` form. No per-word record, origin or history is chosen.

## Historical j and the actual row result

The unchanged physical row-completion guard supplies the old completed-dot
facts, original j, snapshot and strict-past relation. The actual j upper bound
is derived before its fixed record/source lookups. The bounded source point
is specialized with actual `0<=j<=N` parents. Control/phase and accepted capture
guard then derive projection liveness, engine WEIGHTS and job7 at that same j.

The two checked disjunction introductions and the original phase/frame
equalities derive projection GROUP_RUN and FRAME.active. Current-view
selectors supply the exact live/head guard; the original snapshot record
supplies complete FRAME and the saved-array equality. Only bounded state
families are used: the old `accepted-row-frame-origin` edge family is absent,
there is no j+1 source request, and completion observation n may equal N.

The closed capture component is applied at the one j. The graph retains k/p/r
witness-range parents there before the fresh row word, with scalar work ending
at274. The final word at global282 is exactly:

```text
ROWFRAME(n).data[zero_extend(w,2)]
  = endpoint-saved-NF(FRAMEORIGIN(n)).data[w].
```

The resulting deterministic witnesses satisfy
`1<=p<r<k<j<n<=N`, with saved `R0=NF(k)`, original STEP/RMS guards, retained
parent and pre-edge count. The completed actual signed48 accumulator and
signed35 exposed dot retain the original literal `D(S,M,256)` equations and
their qualified range/UID/episode/cancellation conditions. The formal export
conjoins those equations with the all-BV8-word identity; it adds no array lift,
Int/BV conversion, different sum formula or renewed publication authority.

## Readable theorem, scope and remaining closure

I reviewed the proposed `THEOREM.md` body and diagram against those actual
exports. They correctly identify p/r/k/j/n and the two pre-edge payload
equalities. The R0-expanded finite sum is explicitly presented as the
human-readable meaning of the retained canonical sum plus word identities;
it is not advertised as a newly array-lifted machine proof. The diagram and
limits agree. No substantive change is requested. Its pending-status opening
may now distinguish this accepted actual result from still-pending closed
component packaging/replay.

The earlier 46 origin nodes plus 283 composition nodes total329, within the
768-node budget. Composition adds zero inductions, engines, probes or controls.
The unchanged later-NF SAT evidence remains generic wrong-occurrence
sensitivity, not a reset-reachable counterexample or operating witness.
Producer pending flags remain unchanged; this later review supplies actual
result acceptance.

The guarantee is conditional source/API occurrence and value transport for
one c070 selected row under the six existing contracts. Numerical RMS and its
last-layer model input, exponent/scale correspondence, other rows and the
remaining head/token/selector/publication chain, physical behavior, other
variants and whole-device inference-only confinement remain separate. Proceed
only to the planned closed read-only replay and seal/archive closeout; no
larger successor is authorized by this review.

if not __debug__:raise RuntimeError('Optimization forbidden')
from pathlib import Path
import sys,json,hashlib,importlib.util,os,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
REPO=ROOT.parents[3]
SOURCE=REPO/'inference-only/hwic-hnlpu/private-simplestories-attention-20261110-v12/native_resource_guard.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def load():
    expected=json.loads((HERE/'GUARD-SOURCE.json').read_bytes())
    assert str(SOURCE)==expected['path'] and sha(SOURCE)==expected['sha256']
    spec=importlib.util.spec_from_file_location('pinned_mode_native_resource_guard',SOURCE)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def execute(argv,cwd,directory,memory_cap=4*(1<<30),single_process=True):
    directory=Path(directory)
    assert not directory.exists()
    guard=load();raw_pressure=guard.host_pressure;raw_usage=guard.group_usage
    journal=directory.parent/(directory.name+'-observations.jsonl')
    assert not journal.exists()
    starts={};sample_count=0;last_progress=-float('inf');group_stop=None
    before=raw_pressure();assert before==1,'Actual host pressure is not normal at admission'
    with journal.open('x') as log:
        def record(value):
            log.write(json.dumps(value,sort_keys=True)+'\n');log.flush()
        record({'kind':'admission','utc':guard.now(),'pressure':before,
            'argv':argv,'memory_cap_bytes':memory_cap,'single_process':single_process})
        def observed_pressure():
            value=raw_pressure()
            record({'kind':'pressure','utc':guard.now(),'pressure':value})
            return value
        def observed_usage(pgid):
            nonlocal sample_count,last_progress,group_stop
            rows=raw_usage(pgid);sample_count+=1
            for row in rows:
                # The pinned raw probe already checks PGID before its actual
                # per-PID rusage read. Do not add an exit/reaping race here.
                if not row['rss_bytes'] and not row['footprint_bytes']:
                    continue  # Terminal observations do not replace a live start identity.
                key=row['pid'];start=row['start_abstime']
                if key in starts:assert starts[key]==start,'Owned PID identity changed'
                else:starts[key]=start
            rss=sum(r['rss_bytes'] for r in rows)
            footprint=sum(r['footprint_bytes'] for r in rows)
            record({'kind':'owned-group','utc':guard.now(),'pgid':pgid,'members':rows,
                'group_RSS_bytes':rss,'group_footprint_bytes':footprint})
            if rss>memory_cap or footprint>memory_cap:
                group_stop='owned group exceeds explicit RSS/physical-footprint budget'
            tick=time.monotonic()
            if tick-last_progress>=30:
                pressure=observed_pressure()
                print(json.dumps({'progress':{'pgid':pgid,'RSS_bytes':rss,
                    'physical_footprint_bytes':footprint,'pressure':pressure,
                    'owned_PIDs':[r['pid'] for r in rows],
                    'time_kill_enabled':False}}),flush=True)
                last_progress=tick
            return rows
        guard.host_pressure=observed_pressure;guard.group_usage=observed_usage
        # Explicitly disable the imported task's old wall/CPU/disk budgets.
        # This formal worker has only its own group memory and real pressure
        # conditions; no canonical simulation reservation is claimed.
        class FormalBudget(guard.Budget):
            def reason(self):return group_stop or super().reason()
        budget=FormalBudget(HERE,seconds=None,cpu_seconds=None,disk_floor=0)
        try:
            result=guard.execute(argv,str(cwd),directory,budget,maximum_seconds=None,
                memory_cap=memory_cap,cpu_limit_seconds=None,single_process=single_process)
        finally:
            guard.host_pressure=raw_pressure;guard.group_usage=raw_usage
    result_summary={'guard_source_sha256':sha(SOURCE),'observation_journal_sha256':sha(journal),
        'admission_pressure':before,'group_observations':sample_count,
        'observed_start_identities':starts,'no_time_or_CPU_kill':True,
        'canonical_simulation_reservation_claimed':False}
    guard.atomic(directory/'MONITOR-BINDING.json',result_summary)
    return result,result_summary

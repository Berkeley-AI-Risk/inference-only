"""Ordinary physical row/exponent continuity on the existing ROW/origin."""
if not __debug__:
    raise RuntimeError('Optimization forbidden')
from copy import deepcopy
import hashlib
import json
FAMILY = 'original-physical-row-engine-exponent-continuity'
INDEX = 'n_original_row_engine_exponent'
CONTEXT_SHA = 'b8b2b1e926ac9d2cec6a4a3f1e006dbeb50b7f0c68624abadc40e42ea6762383'
digest = lambda v: hashlib.sha256(json.dumps(v, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
SUB = lambda x, m: m.get(x, x) if isinstance(x, str) else [SUB(t, m) for t in x]


def prepare_metadata(exports, data, pins, forms):
    binding, plan, results = [data[k] for k in ['binding', 'plan', 'results']]
    assert binding['native_sha256'] == exports['context']['Gamma:actual-composed-source']['native_core_sha256']
    assert binding['native_T_conjuncts'] == 452 and not binding['health_filter_or_extra_control_provider_added']
    assert plan['order'] == ['row-engine-exponent-reset-base', 'row-engine-exponent-preserve']
    assert len(results['results']) == 2 and results['all_expected_results_matched'] and results['active_owned_native_job'] is None
    for name, row in zip(plan['order'], results['results']):
        assert row['name'] == name and row['answer'] == 'unsat' and row['matched']
        assert row['query_sha256'] == plan['queries'][name]['sha256']
    assert pins['dot_seal'] == 'c5591f6f05aa192edc891e8a6888e43895cc1d9b00a11eb067a0995d4c23b99e'
    for key, relative in [('dot_application', 'COMPLETED-DOT-APPLICATION-DRAFT.json'),
            ('dot_prefix', 'COMPLETED-DOT-PREFIX-APPLICATION-DRAFT.json'), ('dot_typing', 'COMPLETED-DOT-TYPING-ONLY.smt2')]:
        assert data['dot_seal']['files'][relative] == pins[key]
    definitions = {f[1]: f for f in forms if f[0] == 'define-fun'}
    for definition in binding['original_source_helpers']:
        if definition[0] == 'define-fun':
            assert definitions[definition[1]] == definition
    function = binding['future_fixed_actual_function_definition']
    mapping = binding['future_uniform_function_mapping']
    assert mapping == {'row-engine-exp-at': 'actual-row-engine-exp-at', 'row-eexp-I': 'actual-row-eexp-I'}
    assert binding['future_actual_invariant'] == SUB(binding['scalar_invariant'], mapping)
    assert definitions['actual-row-engine-exp-at'] == function
    assert definitions['actual-row-eexp-I'] == binding['future_actual_invariant']
    parameter = 'row-exp-observation'
    expected = ['define-fun', 'actual-row-engine-exp-at', [[parameter, 'Int']], ['_', 'BitVec', '8'],
        ['|core_workflow_control_n u_native.u_six_layers.u_datapath.u_projection.u_shared_engine.u_engine.activation_exponent_q|', ['A', parameter]]]
    assert function == expected
    assert INDEX not in exports['apis']['atoms'](function)
    prefix = data['dot_prefix']
    assert prefix['prefix_bound_domain'] == ['<=', '1', 'N']
    context = exports['prefix_artifact']['inherited_prefix_source_context']
    assert prefix['inherited_continuity_prefix']['inherited_prefix_source_context'] == context and digest(context) == CONTEXT_SHA
    ns = data['dot_application']['nodes']
    anchors = {}
    for family, ids, old_index, old_scope, old_kind in [
            ('ROW', (755, 775), 'n_control', 'control', 'total-controller-observer-definition'),
            ('FRAMEORIGIN', (1654, 1701), 'n_historical_frame_origin', 'historical-frame-origin', 'total-same-trace-nondriving-component-observer-definition')]:
        zero, step = [ns[i] for i in ids]
        assert zero['id'] == ids[0] and step['id'] == ids[1] and zero['kind'] == step['kind'] == old_kind
        assert zero['registry'] == step['registry'] == ('row' if family == 'ROW' else 'origin')
        assert zero['step'] is False and zero['index'] == '1' and not zero['parents']
        assert zero['support'] == zero['introduced_support'] == ['Gamma:actual-composed-source']
        assert step['step'] is True and step['index'] == old_index and len(step['parents']) == 1
        bound = ns[step['parents'][0]]
        assert bound['kind'] == 'scoped-natural-index-domain' and bound['scope'] == old_scope
        assert bound['formula'] == ['<=', '1', old_index]
        assert set(step['support']) == set(step['introduced_support']) == {'Gamma:actual-composed-source', 'INDEX:' + old_scope}
        if family == 'ROW':
            old_bounded = prefix['inherited_continuity_prefix']['inherited_controller_definitions_on_prefix']['row']
            assert old_bounded['zero_at_1'] == zero['formula']
            bounded = old_bounded['next_on_prefix']
            definition = definitions['selected-row-next']
            expected_zero = ['=', ['ROW', '1'], ['selected-row-zero', 'empty-a', 'empty-w', 'empty-prefix']]
            expected_step = ['=', ['ROW', ['+', old_index, '1']], ['selected-row-next', ['ROW', old_index],
                ['row-source-view', ['A', old_index], ['COLUMNS', old_index]], 'empty-a', 'empty-w', 'empty-prefix']]
        else:
            assert prefix['additional_origin_observer_definitions_on_prefix'][0] == zero['formula']
            bounded = prefix['additional_origin_observer_definitions_on_prefix'][1]
            definition = definitions['row-frame-origin-index-next']
            expected_zero = ['=', ['FRAMEORIGIN', '1'], '0']
            expected_step = ['=', ['FRAMEORIGIN', ['+', old_index, '1']], ['row-frame-origin-index-next',
                ['row-source-view', ['A', old_index], ['COLUMNS', old_index]], ['ROW', old_index], old_index, ['FRAMEORIGIN', old_index]]]
        assert zero['formula'] == expected_zero and step['formula'] == expected_step
        binder = bounded[1][0][0]
        assert bounded == ['forall', [[binder, 'Int']], ['=>', ['and', ['<=', '1', binder], ['<', binder, 'N']], SUB(step['formula'], {old_index: binder})]]
        anchors[family] = {'zero': deepcopy(zero), 'step': deepcopy(step), 'bound': deepcopy(bound),
            'old_index': old_index, 'exact_source_definition': deepcopy(definition), 'bounded_step': deepcopy(bounded)}
    return deepcopy({'data': data, 'pins': pins, 'anchors': anchors, 'context': context})


def construct(proof, language, exports, prepared, steps):
    api, data = exports['apis'], prepared['data']
    c = api['c']
    assert not proof.nodes and not proof.active_indices and not proof.global_nodes
    assert proof.root_context == exports['context']
    schema_ids = []
    def schema(name, index, base=False):
        mapping = {'a': c('A', index), 'b': c('A', '1' if base else c('+', index, '1')),
            'columns': c('COLUMNS', index), 'row': c('ROW', index), 'old-origin': c('FRAMEORIGIN', index),
            'observation': index, 'empty-a': 'empty-a', 'empty-w': 'empty-w', 'empty-prefix': 'empty-prefix',
            **data['binding']['future_uniform_function_mapping']}
        goal = data['binding']['goals'][name]
        node = proof.add('qualified-source-schema-uniform-instance', SUB(goal, mapping),
            original_query_goal=deepcopy(goal), uniform_mapping=mapping,
            original_query_sha256=data['plan']['queries'][name]['sha256'], accepted_result_review_sha256=prepared['pins']['review'],
            fixed_function_realizations=[deepcopy(data['binding'][k]) for k in ['future_fixed_actual_function_definition', 'future_actual_invariant']])
        schema_ids.append(node)
        return node
    base_rule = schema('row-engine-exponent-reset-base', '1', True)
    base = proof.mp(base_rule, proof.conjunction([proof.source(c('|core_workflow_control_h|', c('A', '1'))),
        proof.source(['not', c('|core_workflow_control_n reset_n|', c('A', '1'))])]))
    template = c('actual-row-eexp-I', c('A', '@index'), c('ROW', '@index'), c('FRAMEORIGIN', '@index'))
    lower = proof.open_index(FAMILY, INDEX)
    ih = proof.add('scoped-induction-hypothesis', SUB(template, {'@index': INDEX}), [lower], support=['IH:' + FAMILY], scope=INDEX)
    bridge = steps.definition(proof, language, api, 'actual-row-engine-exp-at', [INDEX])
    assert proof.nodes[bridge]['formula'] == SUB(data['binding']['current_point_bridge'],
        {'row-engine-exp-at': 'actual-row-engine-exp-at', 'observation': INDEX, 'a': c('A', INDEX)})
    rule = schema('row-engine-exponent-preserve', INDEX)
    after = c('+', INDEX, '1')
    premise = proof.conjunction([proof.source(c('|core_workflow_control_h|', c('A', INDEX))),
        proof.source(c('|core_workflow_control_h|', c('A', after))),
        proof.source(c('|core_workflow_control_t|', c('A', INDEX), c('A', after))), ih, bridge])
    step = proof.mp(rule, premise)
    observer_nodes = {}
    for family in ['ROW', 'FRAMEORIGIN']:
        anchor = prepared['anchors'][family]
        mapping = {anchor['old_index']: INDEX}
        equation = proof.add('qualified-total-same-trace-observer-definition-instance', SUB(anchor['step']['formula'], mapping),
            [lower], support=['Gamma:actual-composed-source', *proof.index_support(INDEX, True)],
            registry=family, index=INDEX, source_anchor=deepcopy(anchor), uniform_index_mapping=mapping,
            accepted_source_application_sha256=prepared['pins']['dot_application'], accepted_seal_sha256=prepared['pins']['dot_seal'])
        observer_nodes[family] = equation
        value = proof.nodes[equation]['formula']
        step = proof.rewrite(step, equation, value[2], value[1])
    final = api['close_factory'](proof)(FAMILY, template, base, step, INDEX, ih, [])
    assert not proof.active_indices and len(proof.nodes) <= 96
    assert proof.root_context == exports['context']
    assert set(proof.nodes[final]['support']) == {'Gamma:actual-composed-source', 'Gamma:entry-reset-low-at-1'}
    return deepcopy({'kind': 'ordinary-original-physical-row-engine-exponent-continuity', 'nodes': proof.nodes,
        'global_nodes': proof.global_nodes, 'global_node': final, 'root_context': proof.root_context,
        'base_parent': base, 'step_parent': step, 'IH_parent': ih, 'bridge_parent': bridge,
        'schema_nodes': schema_ids, 'observer_definition_nodes': observer_nodes,
        'fixed_actual_function_definition': data['binding']['future_fixed_actual_function_definition'],
        'new_native_jobs': 0, 'new_observer_or_driving_state': False,
        'actual_historical_E_exponent_unfolded': False, 'original_R0_at_read_proved': False,
        'read_metadata_postscale_selector_join_proved': False, 'whole_device_theorem': False})

if not __debug__:
    raise RuntimeError('Optimization forbidden before imports or work')
from pathlib import Path
import sys,json,hashlib
sys.dont_write_bytecode=True
sys.setrecursionlimit(30000)
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import scoped_induction,transport_certificate,trace_context
from row_terms import *
from support import smt,parse_spans,atoms
sha=lambda b:hashlib.sha256(b).hexdigest()
rd=lambda p:json.loads(p.read_bytes())


class ValueProof(scoped_induction.Proof):
    """One reviewed construction, not an arbitrary certificate kernel."""
    def __init__(self,draft,context):
        super().__init__(draft)
        self.context=context
        original=self.root_context['Gamma:actual-composed-source']
        original['published_memory_source_domain']=context['boundaries']['Gamma:actual-composed-source']
        specialization=context['declared_entry_and_source_domain']['projection']['restricted_actual_source_event_specialization']
        assert original['formal_native_consequences']==specialization['source_specialization_inference']['conclusion']
        for key,value in context['boundaries'].items():
            if key!='Gamma:actual-composed-source':self.root_context[key]=value

    def assumption(self,label,formula):
        assert label not in self.scope_labels
        self.scope_labels.add(label)
        return self.add('scoped-case-assumption',formula,support=[label],case_label=label)

    def implication(self,assumption,result):
        a=self.nodes[assumption];r=self.nodes[result]
        assert a['kind']=='scoped-case-assumption'
        label=a['case_label']
        assert a['support']==[label]
        node=self.add('implication-introduction',IMP(a['formula'],r['formula']),[assumption,result],
                      discharged_support=[label])
        self.nodes[node]['support']=sorted(set(self.nodes[node]['support'])-{label})
        return node

    def mp(self,implication,premise):
        f=self.nodes[implication]['formula']
        assert f[0]=='=>' and f[1]==self.nodes[premise]['formula']
        return self.add('implication-elimination',f[2],[implication,premise])

    def conjunction(self,parents):
        return self.add('conjunction-introduction',AND(*[self.nodes[p]['formula'] for p in parents]),parents)

    def split_boolean(self,left,right,condition):
        a,b=self.nodes[left]['formula'],self.nodes[right]['formula']
        assert a[0]==b[0]=='=>' and a[1]==condition and b[1]==NOT(condition) and a[2]==b[2]
        return self.add('exhaustive-Boolean-cases',a[2],[left,right],condition=condition)

    def trace_instance(self,name,index,parameters=None):
        parameters=parameters or {}
        parent=self.global_nodes[name];node=self.nodes[parent]
        assert node['kind'] in ['ordinary-induction','qualified-published-trace-context-application','uniform-trace-consequence']
        allowed={x[0] for x in node['quantified_parameters']}
        assert set(parameters)<=allowed
        mapping={'@index':index,**parameters}
        f=SUB(node['property_template'],mapping)
        return self.add('uniform-global-trace-instantiation',f,[parent,*self.index_parents(index)],
                        support=self.index_support(index,True),index=index,parameters=parameters)

    def globalize(self,name,template,result,index,parameters):
        bound=self.active_indices[index];r=self.nodes[result]
        assert r['formula']==SUB(template,{'@index':index})
        assert index not in atoms(template)
        assert set(r['support'])<=set(self.root_context)|{bound['label']}
        for parameter,_ in parameters:
            assert parameter not in self.root_context['Gamma:actual-composed-source']['free_parameters']
            assert parameter not in atoms(self.root_context['Gamma:actual-composed-source']['formal_native_consequences'])
        formula=['forall',[*parameters,[index,'Int']],IMP(c('<=','1',index),r['formula'])]
        out=self.add('uniform-trace-consequence',formula,[result,bound['node']],
                     property_template=template,quantified_parameters=parameters,
                     fresh_index=index,discharged_support=[bound['label']])
        self.nodes[out]['support']=sorted(set(self.nodes[out]['support'])-{bound['label']})
        self.global_nodes[name]=out
        del self.active_indices[index]
        return out

    def published_memory(self):
        library=self.context['accepted_trace_import']
        # Exact recurrence functions are already reconstructed against the
        # published functions. The internal RAW is a total, readonly extension
        # of this same C trace, with its own exact zero/next; no RAW invariant
        # or desired reply becomes a root assumption.
        for which,key in [('service','SERVICE'),('request','REQUEST')]:
            registered=self.observers[which]
            imported=self.context['observer_instances'][key]
            assert registered['source']==imported['source']=='C'
            assert registered['zero']==imported['zero_at_1']
            assert registered['next']==imported['next_function'][1]
            assert registered['parameters']==imported['fixed_parameters']
        parents=[self.global_nodes[name] for name in ['slot-constant','request-projection','service-projection']]
        parents.extend([self.source(c('|board1_verified_ddr_page_service_i|',c('C','0'))),
                        self.source(NOT(c('|board1_verified_ddr_page_service_n reset_n|',c('C','0')))),
                        self.source(c('|board1_verified_ddr_page_service_h|',c('C','0'))),
                        self.source(c('|board1_verified_ddr_page_service_h|',c('C','1'))),
                        self.source(c('|board1_verified_ddr_page_service_t|',c('C','0'),c('C','1')))])
        params=[['slot',['_','BitVec','5']],['u',['_','BitVec','18']]]
        result=self.add('qualified-published-trace-context-application',library['trace_level_formula'],parents,
            support=list(self.context['boundaries']),
            property_template=library['property_template'],quantified_parameters=params,
            exact_context=self.context,internal_RAW_observer=self.context['observer_instances']['RAW'],
            accepted_library_import='published_trace_rule.assemble with mandatory fresh source/query/receipt replay',
            fixed_model_before_generalization=True,additional_private_value_hypotheses=[])
        self.global_nodes['published-memory']=result
        return result

    def unrestricted_address(self):
        # Generalize fixed slot/u on the SAME trace before selecting either
        # from a live state. Only u's image-range cases are eliminated here.
        name='return-any-address';index='n_return'
        self.open_index(name,index)
        high=c('|board1_verified_ddr_page_service_n reset_n|',c('C',index))
        target=c('bvult','u',bv(227062,18))
        returned=lambda u:c('fixed-model-return',c('C',index),c('SERVICE','slot',index),'slot',u,'model')
        high_a=self.assumption('CASE:return-page-high',high)
        zero=self.trace_instance('published-memory',index,{'u':bv(0,18)})
        zero_range=self.add('literal-unsigned-bitvector-comparison',c('bvult',bv(0,18),bv(227062,18)),
                            evaluated_unsigned_operands=[0,227062],width=18)
        zero=self.mp(zero,self.conjunction([high_a,zero_range]))
        inside_a=self.assumption('CASE:return-inside-image',target)
        inside=self.trace_instance('published-memory',index)
        inside=self.mp(inside,self.conjunction([high_a,inside_a]))
        inside=self.implication(inside_a,inside)
        outside_a=self.assumption('CASE:return-outside-image',NOT(target))
        packet=ROOT/'head-model-weight-storage-application-r1'
        shape=rd(packet/'OBSERVER-PROJECTION.json')['outside_image_application']
        receipt_path=packet/'runs/fixed-zero-return-covers-outside-image-target/RESULT.json'
        receipt=rd(receipt_path)
        assert receipt['answer']=='unsat' and receipt['expected_result_matched']
        mapping={'svc':c('C',index),'sh':c('SERVICE','slot',index)}
        expected=[SUB(shape['derived_constant_target_child'],mapping),SUB(shape['outside_guard'],mapping)]
        assert [self.nodes[p]['formula'] for p in [zero,outside_a]]==expected
        outside=self.add('qualified-outside-image-source-application',SUB(shape['goal'],mapping),[zero,outside_a],
                         qualified_receipt=receipt,receipt_sha256=sha(receipt_path.read_bytes()),uniform_mapping=mapping)
        outside=self.implication(outside_a,outside)
        result=self.split_boolean(inside,outside,target)
        result=self.implication(high_a,result)
        template=IMP(c('|board1_verified_ddr_page_service_n reset_n|',c('C','@index')),
                     c('fixed-model-return',c('C','@index'),c('SERVICE','slot','@index'),'slot','u','model'))
        return self.globalize(name,template,result,index,[['slot',['_','BitVec','5']],['u',['_','BitVec','18']]])

    def interface_word(self):
        name='interface-word';index='n_interface'
        self.open_index(name,index)
        state=c('A',index);cache=c('C',index);api=c('API',index)
        high=n('reset_n',state)
        pagehigh=c('|board1_verified_ddr_page_service_n reset_n|',cache)
        response=c('|board1_verified_ddr_page_service_n response_read_q|',cache)
        address=c('select',c('a-arguments',api),c('a-retire',api))
        word=c('interface-word-to-layer',state,api,'model')
        core_h=self.source(c('|core_workflow_control_h|',state))
        cache_h=self.source(c('|board1_verified_ddr_page_service_h|',cache))
        bindings=self.source(c('interface-bindings',state,cache))
        api_inv=self.trace_instance('api',index)
        root_page=self.add('checked-physical-reset-binding-and-literal-getter-alias',
                           eq(pagehigh,high),[bindings],
                           root_and_arbiter_reset_getters_identical=self.draft['root_and_arbiter_reset_getters_identical_after_parameter_renaming'])
        cases=[]
        for k in range(32):
            const=bv(k,5);x=c('X',const,index);parameters={'slot':const}
            choose=self.assumption('CASE:response-slot-'+str(k),eq(response,const))
            root_high=self.assumption('CASE:core-high-slot-'+str(k),high)
            page_high=self.add('Boolean-equality-substitution',pagehigh,[root_page,root_high])
            c_inv=self.trace_instance('cacheorder',index,parameters)
            common=self.trace_instance('common-history',index,parameters)
            slot=self.trace_instance('slot-constant',index,parameters)
            slot_eq=self.add('equality-symmetry-and-transitivity',eq(c('c-slot',x),response),[slot,choose])
            reflex=self.add('typed-reflexivity',eq(address,address))
            returned=self.trace_instance('return-any-address',index,{'slot':const,'u':address})
            returned=self.mp(returned,page_high)
            projection=self.trace_instance('service-projection',index,parameters)
            # Targeted congruence replaces only the SERVICE argument and then
            # only the slot argument, never constants embedded in X(k,n).
            old=self.nodes[returned]['formula']
            project=self.nodes[projection]['formula'];slot_formula=self.nodes[slot]['formula']
            assert old[2]==project[2] and old[3]==slot_formula[2]
            new=list(old);new[2]=project[1];new[3]=slot_formula[1]
            returned=self.add('typed-equality-argument-congruence',new,[returned,projection,slot],
                              argument_paths=[[2],[3]])
            proto=self.draft['interface_rule_instances']['value-to-layer']
            mapping={'A':state,'C':cache,'api':api,'cache':x,'u':address}
            rule=self.source_instance(proto,mapping)
            parents=[core_h,cache_h,bindings,api_inv,c_inv,common,root_high,slot_eq,reflex,returned]
            value=self.apply(rule,parents)
            value=self.implication(root_high,value)
            value=self.implication(choose,value)
            assert self.nodes[value]['formula']==IMP(eq(response,const),IMP(high,word))
            cases.append(value)
        # A conventional finite-domain inference, with all 32 distinct BV5
        # literals checked here. The prepared solver query is optional and is
        # NOT reported as an engine result or used as an unrun receipt.
        assert [self.nodes[p]['formula'] for p in cases]==[
            IMP(eq(response,bv(k,5)),IMP(high,word)) for k in range(2**5)]
        upper=self.add('exhaustive-five-bit-domain-cases',IMP(high,word),cases,
                       selector=response,bit_width=5,covered_unsigned_values=list(range(32)),
                       engine_receipt_claimed=False)
        low_a=self.assumption('CASE:interface-root-low',NOT(high))
        packet=ROOT/'head-model-weight-history-application-r1'
        shape=rd(packet/'RESET-LOW-APPLICATION.json')
        mapping={'a':state,'api-a':api}
        assert SUB(shape['guard'],mapping)==AND(self.nodes[core_h]['formula'],self.nodes[low_a]['formula'])
        receipt_path=packet/'runs/reset-low-interface-word-is-vacuous/RESULT.json'
        receipt=rd(receipt_path);assert receipt['answer']=='unsat' and receipt['expected_result_matched']
        lower=self.add('qualified-reset-low-source-application',SUB(shape['goal'],mapping),[core_h,low_a],
                       qualified_receipt=receipt,receipt_sha256=sha(receipt_path.read_bytes()),uniform_mapping=mapping)
        lower=self.implication(low_a,lower)
        result=self.split_boolean(upper,lower,high)
        return self.globalize(name,c('interface-word-to-layer',c('A','@index'),c('API','@index'),'model'),result,index,[])


def construct():
    draft=transport_certificate.assemble()
    context=trace_context.assemble()
    proof=ValueProof(draft,context)
    for name in ['api','cacheorder','reader']:proof.family(name)
    proof.common_history();proof.slot_constancy()
    proof.observer_projection('request');proof.observer_projection('service')
    proof.published_memory();proof.unrestricted_address();proof.interface_word()
    return proof


def assemble():
    proof=construct()
    # Reviewed deterministic reconstruction is the acceptance route. This
    # module is not an independent arbitrary proof-assistant kernel.
    fresh=construct()
    for key in ['nodes','global_nodes','root_context','observers','index_bindings','scope_labels']:
        assert getattr(proof,key)==getattr(fresh,key),('fresh construction mismatch',key)
    assert not proof.active_indices
    for expected,node in enumerate(proof.nodes):
        assert node['id']==expected and all(0<=p<expected for p in node['parents'])
        support=set(node['introduced_support'])
        assert support<=set(proof.root_context)|proof.scope_labels
        for parent in node['parents']:support.update(proof.nodes[parent]['support'])
        support-=set(node.get('discharged_support',[]))
        assert support==set(node['support']),('support accounting',expected)
    for node in proof.global_nodes.values():
        assert set(proof.nodes[node]['support'])<=set(proof.root_context)
    final=proof.nodes[proof.global_nodes['interface-word']]
    assert set(final['support'])=={'Gamma:actual-composed-source','Gamma:vendor-storage',
                                  'Gamma:runtime-entry-image','Gamma:static-metadata','Gamma:entry-reset-low-at-0'}
    assert 'Gamma:entry-reset-low-at-1' not in final['support']
    from boolean_application import SourceLanguage
    import typed_source
    language=SourceLanguage()
    language.add([x for x,_,_ in parse_spans((HERE/'TRANSPORT-TYPING-ONLY.smt2').read_bytes())])
    S='|core_workflow_control_s|';C='|board1_verified_ddr_page_service_s|';B=['_','BitVec','5']
    for name,args,result in [('A',['Int'],S),('C',['Int'],C),('API',['Int'],'ApiHistory'),('X',[B,'Int'],'CacheorderHistory'),
                             ('REQUEST',['Int'],'RequestOrigin'),('SERVICE',[B,'Int'],'ServiceOrigin')]:
        assert name not in language.defs and name not in language.decls
        language.decls[name]=['declare-fun',name,args,result]
    # Strip only outer theorem quantifiers for the simple source typechecker;
    # instantiate their bound variables as typed arbitrary constants.
    roots=[node['formula'][2] if node['formula'][0]=='forall' else node['formula'] for node in proof.nodes]
    variables=[('slot',B),('u',['_','BitVec','18']),
               ('model',['Array',['_','BitVec','18'],['_','BitVec','256']]),
               *[(index,'Int') for index in proof.index_bindings],('n_memory','Int')]
    specimen,typed=typed_source.build(language,roots,variables,[S,C])
    return {'nodes':proof.nodes,'global_nodes':proof.global_nodes,'root_context':proof.root_context,
            'observer_registry':proof.observers,'scoped_index_registry':proof.index_bindings,
            'indexed_source_typing':typed,'typing_specimen':specimen.decode(),
            'interface_word_trace_conclusion':final,
            'pending_storage_epoch_selector_interface_applications':[],
            'trusted_restricted_builder_not_independent_kernel':True,
            'additional_private_value_root_promises':[],
            'prepared_local_queries_run_or_credited':False,'new_engine_jobs':0,
            'independent_application_review_pending':True,
            'whole_initialized_head_source_theorem_qualified':False,'whole_device_theorem_qualified':False}


if __name__=='__main__':
    result=assemble();specimen=result.pop('typing_specimen')
    (HERE/'VALUE-TRACE-TYPING-ONLY.smt2').write_text('; Typing only; not an engine query/result.\n'+specimen)
    (HERE/'VALUE-TRACE-APPLICATION-DRAFT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'nodes':len(result['nodes']),'global_templates':list(result['global_nodes']),
                      'interface_support':result['interface_word_trace_conclusion']['support'],
                      'source_typing':result['indexed_source_typing'],'new_engines':0,
                      'independent_review_pending':True,'head_source_qualified':False}))


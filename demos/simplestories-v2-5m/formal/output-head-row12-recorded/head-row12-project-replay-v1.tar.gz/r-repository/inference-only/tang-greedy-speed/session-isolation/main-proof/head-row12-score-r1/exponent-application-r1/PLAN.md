# Apply the original head exponent owner on the same finite prefix

Unrun preparation. Ten first-attempt native checks have passed independent
review: four capture/hold leaves, three HS owner leaves, and three saved-FRAME
link/clock/consequence leaves. No original-prefix exponent theorem follows
until the applications below supply all their premises from actual histories.

Use the existing cheap accepted-export loader, lightweight Proof/ValueProof,
SourceLanguage, ordinary close_factory and the read-only auditor. Do not rebuild
the old large parent proofs, call old writers/compilers, run a new engine, or
copy/execute any Lean package. Preserve every seal and recorded result.

Establish two small ordinary inductions, at most192 typed nodes total:

1. The conjunction hs-I(A(n),NF(n),HS(n)) and original HS capture provenance.
   HS(1)=hs-zero(NF(1)); on defined edges HS(n+1)=hs-next(A(n),NF(n),HS(n)).
   Original NF has its unchanged zero/next. Base uses actual reset sample1,
   not a fresh head reset. Preservation supplies both actual H/all452 T and
   the independently qualified NF invariant at n and n+1. The accepted STEP
   stamp proof supplies nf-t(NF(n))=n-1. The checked clock consequence identifies
   hs-next with generic-next at n. One fixed actual-hs-event-at(t) equals the
   literal effective head capture on A(t), and generic hs-record-at uniformly
   becomes the one actual NF function. The generic zero/step then establishes
   that a valid original snapshot has1<=h<n, that actual event at h, and NF(h).
   Do not add a head occurrence, saved exponent or future-health assumption.
2. hf-I for original FRAME/CERT/HS on the same trace. The existing original
   frame/CERT zero/next equations remain exact. Supply current/successor frame-I
   from the qualified actual-FRAME theorem and current/successor hs-I from the
   preceding induction. Supply original frc-I from its accepted component and
   apply the full native preservation leaf. There is no new observer or owner
   reassignment, and no current-NF=CERT.nf assumption after frame completion.

Qualified imports retain their exact full formulas, supports and separately
checked bounded counterparts. The generic fj-capture-record-at UF in the new
source query is explicitly realized, once and uniformly, by the qualified
actual function at t: fj-current-record(fj-source-view(A(t),COLUMNS(t)),FRAME(t),
NF(t),t). This is function interpretation specialization, not an identical
declaration or a supplied desired result. All overlapping helper definitions
must match literally and source/macro/reset/clock profiles remain c070.

Validate ordinary deduction nodes, inherited scopes/supports, exact source
schema substitutions, actual function realizations, observer recurrences,
and same-prefix locality. States are0..N and defined edges0..N-1. Each new
base uses state1; each step uses only n,n+1 for1<=n<N. Stopping at a qualified
provider requires its literal accepted bounded formula on this same six-root
context. The HS origin predicate has only revoke/invalid, current capture at n,
and retained same-past-record cases. Its retained historical function access
is guarded by the IH lower/strict bounds; no hidden INDEX, infinite extension
or future source lookup is permitted. The end state N is allowed.

Exact code/input review must precede any Proof initializer. Run metadata-only
under deny-write/process/network audit first, with zero constructors. Then run
the frozen constructor once, save its actual DAG and standalone typing, obtain
independent formula/parent/support/locality and byte-identical replay review.
An unexpected assertion saves partial DAG, active scopes and read/helper pins
and stops the affected construction; do not weaken or silently retry. Any fix
is additive and independently reviewed. No wall, CPU or token kill is used.

These two applications supply owner/link bounded invariants. A subsequent
small checked current/row consequence must apply the native saved-exponent
leaf and original endpoint at the exact historical j/k, deriving bounds and
identifying endpoint-saved-NF with its original CERT record. That work remains
active after this checkpoint, followed by registered read, metadata, postscale
and actual legal selector admission. No selector, numerical RMS, other-row,
public, board or whole-device claim is made by these two inductions alone.

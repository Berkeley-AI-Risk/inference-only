"""Bounded owned-process recorder. No virtual-address limit or automatic retry."""
from pathlib import Path
from datetime import datetime, timezone
import ctypes
import errno
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import threading
import time
import uuid

GIB=1024**3

def now():return datetime.now(timezone.utc).isoformat()

def pin(path):
    p=Path(path).resolve(strict=True)
    with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=digest)

def atomic(path,value):
    path=Path(path);temp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex)
    try:
        with temp.open('x') as f:
            json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
        os.link(temp,path)  # create-only receipt; no old evidence replacement
    finally:
        if temp.exists():temp.unlink()

class Usage(ctypes.Structure):
    _fields_=[('uuid',ctypes.c_uint8*16)]+[(n,ctypes.c_uint64) for n in
        ['user_time','system_time','pkg_idle_wkups','interrupt_wkups','pageins',
         'wired_size','resident_size','phys_footprint','proc_start_abstime','proc_exit_abstime']]

assert ctypes.sizeof(Usage)==96
LIB=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
LIB.proc_listpids.argtypes=[ctypes.c_uint,ctypes.c_uint,ctypes.c_void_p,ctypes.c_int]
LIB.proc_listpids.restype=ctypes.c_int
LIB.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p]
LIB.proc_pid_rusage.restype=ctypes.c_int
SYS=ctypes.CDLL(None,use_errno=True)
SYS.sysctlbyname.argtypes=[ctypes.c_char_p,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p,ctypes.c_size_t]
SYS.sysctlbyname.restype=ctypes.c_int

def host_pressure():
    value=ctypes.c_int();size=ctypes.c_size_t(ctypes.sizeof(value))
    if SYS.sysctlbyname(b'kern.memorystatus_vm_pressure_level',ctypes.byref(value),ctypes.byref(size),None,0):
        raise OSError(ctypes.get_errno(),'cannot read actual kernel memory pressure')
    if size.value!=4:raise RuntimeError('unknown pressure ABI')
    return value.value

def group_usage(pgid):
    # Darwin PROC_PGRP_ONLY=2: enumerate only this new owned native group.
    pids=(ctypes.c_int*4096)();n=LIB.proc_listpids(2,pgid,pids,ctypes.sizeof(pids))
    if n<0 or n>=ctypes.sizeof(pids) or n%4:raise RuntimeError('cannot enumerate owned process group')
    observations=[]
    for pid in pids[:n//4]:
        if pid<=0:continue
        try:
            if os.getpgid(pid)!=pgid:continue  # exited/reused enumeration entry
        except ProcessLookupError:continue
        usage=Usage();rc=LIB.proc_pid_rusage(pid,0,ctypes.byref(usage))
        if rc:
            if ctypes.get_errno()==errno.ESRCH:continue
            raise OSError(ctypes.get_errno(),'cannot observe owned process memory')
        observations.append(dict(pid=pid,rss_bytes=usage.resident_size,
            footprint_bytes=usage.phys_footprint,cpu_seconds=((usage.user_time+usage.system_time)*TIMEBASE.numer)/(TIMEBASE.denom*1e9),
            start_abstime=usage.proc_start_abstime))
    return observations

def wait_unreaped(pid,ready,errors):
    try:
        call=SYS.waitid;call.argtypes=[ctypes.c_int,ctypes.c_uint,ctypes.c_void_p,ctypes.c_int];call.restype=ctypes.c_int
        buf=ctypes.create_string_buffer(1024)
        while call(1,pid,buf,os.WEXITED|os.WNOWAIT):
            if ctypes.get_errno()!=errno.EINTR:raise OSError(ctypes.get_errno(),'waitid')
    except BaseException as e:errors.append(repr(e))
    finally:ready.set()

class MachTimebase(ctypes.Structure):
    _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]

TIMEBASE=MachTimebase()
SYS.mach_timebase_info.argtypes=[ctypes.POINTER(MachTimebase)]
SYS.mach_timebase_info.restype=ctypes.c_int
if SYS.mach_timebase_info(ctypes.byref(TIMEBASE)) or not TIMEBASE.numer or not TIMEBASE.denom:
    raise RuntimeError('cannot read actual Mach timebase')

class Budget:
    def __init__(self,root,seconds=2400,cpu_seconds=14400,disk_floor=100*GIB):
        self.root=Path(root);self.started=time.monotonic();self.started_clock=time.time();self.seconds=seconds
        self.cpu_cap=cpu_seconds;self.disk_floor=disk_floor;self.cpu=0.;self.live={}
        self.lock=threading.Lock();self.abort=threading.Event();self.interrupted=None
    def elapsed(self):return max(time.monotonic()-self.started,time.time()-self.started_clock)
    def reason(self):
        if self.abort.is_set():return 'stage aborted or interrupted'
        if self.seconds is not None and self.elapsed()>=self.seconds:return 'stage wall cap'
        with self.lock:cpu=self.cpu+sum(self.live.values())
        if self.cpu_cap is not None and cpu>=self.cpu_cap:return 'stage native CPU cap'
        if shutil.disk_usage(self.root).free<self.disk_floor:return 'disk floor'
        if host_pressure()!=1:return 'kernel memory pressure not normal'
        return None

def execute(argv,cwd,directory,budget,maximum_seconds,environment=None,memory_cap=8*GIB,cpu_limit_seconds=None,single_process=False):
    directory=Path(directory);directory.mkdir()
    reason=budget.reason()
    if reason:raise RuntimeError('admission declined: '+reason)
    log=directory/'NATIVE.log';began=now();clock=time.monotonic();wall_clock=time.time()
    env=os.environ.copy();env.update(environment or {})
    # Child inherits this zero-core policy. No RLIMIT_AS is set.
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    peaks=dict(rss_bytes=0,footprint_bytes=0,group_rss_bytes=0,group_processes=0)
    observations=0;seen_pids=set();child=None;status=usage=None;monitor_errors=[]
    with log.open('xb') as output:
        if cpu_limit_seconds is not None:
            assert isinstance(cpu_limit_seconds,int) and cpu_limit_seconds>=1
        def child_limits():
            if cpu_limit_seconds is not None:
                resource.setrlimit(resource.RLIMIT_CPU,(cpu_limit_seconds,cpu_limit_seconds+1))
        child=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,
            stdout=output,stderr=subprocess.STDOUT,start_new_session=True,
            preexec_fn=child_limits if cpu_limit_seconds is not None else None)
        if os.getpgid(child.pid)!=child.pid:raise RuntimeError('native group not isolated')
        atomic(directory/'STARTED.json',dict(started_utc=began,pid=child.pid,pgid=child.pid,
            argv=argv,cwd=str(cwd),environment_changes=environment or {},maximum_seconds=maximum_seconds,
            memory_cap_bytes=memory_cap,kernel_CPU_soft_seconds=cpu_limit_seconds,kernel_CPU_hard_seconds=None if cpu_limit_seconds is None else cpu_limit_seconds+1,single_process_required=single_process,stage_wall_cap_seconds=budget.seconds,
            stage_CPU_cap_seconds=budget.cpu_cap,disk_floor_bytes=budget.disk_floor))
        ready=threading.Event();errors=[]
        threading.Thread(target=wait_unreaped,args=(child.pid,ready,errors),daemon=True).start()
        signalled=None
        try:
            while not ready.is_set():
                try:
                    rows=group_usage(child.pid);observations+=1
                    if single_process and any(r['pid']!=child.pid and r['footprint_bytes'] for r in rows):
                        reason=reason or 'unexpected native helper process'
                    with budget.lock:budget.live[child.pid]=sum(r['cpu_seconds'] for r in rows)
                    for row in rows:
                        seen_pids.add(row['pid'])
                        peaks['rss_bytes']=max(peaks['rss_bytes'],row['rss_bytes'])
                        peaks['footprint_bytes']=max(peaks['footprint_bytes'],row['footprint_bytes'])
                    peaks['group_processes']=max(peaks['group_processes'],len(rows))
                    peaks['group_rss_bytes']=max(peaks['group_rss_bytes'],sum(r['rss_bytes'] for r in rows))
                    if sum(r['rss_bytes'] for r in rows)>64*GIB or sum(r['footprint_bytes'] for r in rows)>64*GIB:
                        reason=reason or '64GiB owned-group resident/footprint cap'
                    if any(max(r['rss_bytes'],r['footprint_bytes'])>memory_cap for r in rows):reason=reason or 'per-process resident/footprint cap'
                    reason=reason or budget.reason()
                    if maximum_seconds is not None and max(time.monotonic()-clock,time.time()-wall_clock)>=maximum_seconds:reason=reason or 'native wall cap'
                except BaseException as e:
                    monitor_errors.append(repr(e));reason=reason or 'resource monitor failure'
                if reason and signalled is None:
                    os.killpg(child.pid,signal.SIGTERM);signalled=time.monotonic()
                if signalled is not None and time.monotonic()-signalled>1:
                    os.killpg(child.pid,signal.SIGKILL)
                ready.wait(.05)
            if errors:reason=reason or 'waitid observer error';monitor_errors.extend(errors)
            # PID identity remains reserved until wait4. Check/stop only owned
            # surviving descendants; never send a signal to a reaped PID/group.
            survivors=[r for r in group_usage(child.pid) if r['pid']!=child.pid and r['footprint_bytes']]
            if survivors:
                reason=reason or 'owned descendant survived leader'
                os.killpg(child.pid,signal.SIGKILL)
        finally:
            if not ready.is_set():
                try:os.killpg(child.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                ready.wait(5)
            _,status,usage=os.wait4(child.pid,0)
            child.returncode=os.waitstatus_to_exitcode(status)
            with budget.lock:
                budget.live.pop(child.pid,None);budget.cpu+=usage.ru_utime+usage.ru_stime
            output.flush();os.fsync(output.fileno())
    duration=max(time.monotonic()-clock,time.time()-wall_clock)
    if maximum_seconds is not None and duration>=maximum_seconds:reason=reason or 'actual native wall cap'
    if budget.seconds is not None and budget.elapsed()>=budget.seconds:reason=reason or 'actual stage wall cap'
    if observations==0:reason=reason or 'no actual RSS sample'
    if usage.ru_maxrss>memory_cap:reason=reason or 'actual wait4 maximum RSS cap'
    with budget.lock:
        if budget.cpu_cap is not None and budget.cpu>budget.cpu_cap:reason=reason or 'actual cumulative native CPU cap'
    result=dict(started_utc=began,finished_utc=now(),pid=child.pid,pgid=child.pid,
        argv=argv,cwd=str(cwd),native_exit=child.returncode,raw_wait_status=status,
        wall_seconds=duration,CPU_user_seconds=usage.ru_utime,
        CPU_system_seconds=usage.ru_stime,wait4_maxrss_bytes=usage.ru_maxrss,
        resource_stop_reason=reason,kernel_CPU_soft_seconds=cpu_limit_seconds,kernel_CPU_hard_seconds=None if cpu_limit_seconds is None else cpu_limit_seconds+1,single_process_required=single_process,monitor_errors=monitor_errors,observation_count=observations,
        peaks=peaks,observed_owned_pids=sorted(seen_pids),log=pin(log))
    atomic(directory/'FINISHED.json',result)
    return result

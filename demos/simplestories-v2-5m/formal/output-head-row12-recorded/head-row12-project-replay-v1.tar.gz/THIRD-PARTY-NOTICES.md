# Third-party attribution and asset provenance

[Design references and prior work](docs/REFERENCES.md) separately identify
algorithmic and architectural antecedents. Those citations supplement,
and do not replace, the source-revision and license notices here.

## SimpleStories model and tokenizer

The selected model is `SimpleStories/SimpleStories-V2-5M`, revision
`c4b3a4bb81297f5316697098e1d4b65c1249daf8`. Its
[pinned model card](https://huggingface.co/SimpleStories/SimpleStories-V2-5M/blob/c4b3a4bb81297f5316697098e1d4b65c1249daf8/README.md)
declares `license: mit`. The declaration is preserved verbatim in
[LICENSES/SimpleStories-MODEL-CARD.md](LICENSES/SimpleStories-MODEL-CARD.md),
alongside [MIT terms](LICENSES/SimpleStories-MIT.txt).
The selected upstream snapshot supplies no separate copyright line; we do
not invent a copyright holder or substitute a training-code repository's
license for the model declaration.

`reference/upstream/manifest.json` records the six upstream assets and their
hashes. The release bundles the exact tokenizer and a quantized model image;
the original floating-point checkpoint can be fetched for reproduction.

| Asset | Provenance |
| --- | --- |
| `assets/board1-real-semantic-image2048.bin` | Fixed quantized/serialized representation of the trained model. |
| `host-app/assets/tokenizer.json` | Unmodified tokenizer from the pinned model snapshot. |
| `hardware/project/fpga/token_only_model0_ddr_board1/fixed_vector_rmsnorm0/recorded/norm_rom34.memh` | Quantized trained normalization coefficients and fixed exponent/scaling encoding. |
| `hardware/project/metadata192.memh` | Projection-row exponents and multipliers derived from model quantization. |
| `hardware/project/digests32.memh` | SHA-256 integrity values computed from the serialized model, including specified page padding; not an additional copy of its weight tensors. |
| `hardware/project/model_rtl_evidence/attention_sublayer/exp_neg_q30.memh` | Numerical exponential lookup generated from the project's fixed-point formula, not learned weights. |

`demos/simplestories-v2-5m/tools/materialize_image.py` regenerates the image and all four tables.
Their identities are in `MANIFEST.json`. Model derivation does not become
wholly original project authorship merely because a file is small or generated.

## Tang Mega board constraints

`hardware/project/constraints/board1_fixed_product.cst` adapts
`ddr_memory/ddr_memory_test_uart/src/ddr3_1v4_hs.cst` from Sipeed's
`TangMega-138K-example`, revision `06e7d8b118d345915ab6f257b7c22226f81575cd`.
The original GOWIN notice is reproduced unchanged:

```text
Copyright (C)2014-2026 Gowin Semiconductor Corporation.
All rights reserved.
```

The [repository's root license](https://github.com/sipeed/TangMega-138K-example/blob/06e7d8b118d345915ab6f257b7c22226f81575cd/LICENSE)
is preserved in [LICENSES/Sipeed-Apache-2.0.txt](LICENSES/Sipeed-Apache-2.0.txt),
including its notice with the brackets as supplied upstream:

```text
Copyright [2024] [Shenzhen Sipeed Technology Co,Ltd.]
```

Our adaptation renames clock/reset signals and the PLL instance path and
adds UART/flash interface constraints. It is not an unmodified Sipeed example.
An adjacent `.NOTICE` preserves this attribution without changing the tested
constraint bytes or the source-bound hardware identity.

## AES S-box circuit

The encrypted-memory variant's `tang_private_aes256.sv` and
`tang_private_aes256_fixed2.sv` adapt the Boolean S-box in BearSSL's
`br_aes_ct_bitslice_Sbox` to one-bit SystemVerilog signals. The source is
[`src/symcipher/aes_ct.c` at revision `5f045c759957fdff8c85716e6af99e10901fdac0`](https://www.bearssl.org/gitweb/?p=BearSSL;a=blob;f=src/symcipher/aes_ct.c;hb=5f045c759957fdff8c85716e6af99e10901fdac0).
BearSSL credits the underlying Boolean circuit to Boyar and Peralta;
see their [logic-minimization paper](https://eprint.iacr.org/2009/191)
and [BearSSL's explanation](https://bearssl.org/constanttime.html).
The adaptation retains Thomas Pornin's copyright and full MIT permission
notice in both RTL files and in [LICENSES/BearSSL-MIT.txt](LICENSES/BearSSL-MIT.txt).
The project did not originate this S-box circuit. Adapting it to hardware
does not establish resistance to power or electromagnetic side channels.

## Seeded-sampling PRNG

The optional seeded-sampling variant implements xoroshiro128++ 1.0, the
17/49/28-rotation recurrence by David Blackman and Sebastiano Vigna.
Their [reference implementation](https://prng.di.unimi.it/xoroshiro128plusplus.c)
contains a public-domain dedication and permission to use, copy, modify and
distribute it. The project-owned RTL and Python reference implement that
recurrence with the documented 128-bit seed mapping. This noncryptographic
PRNG provides reproducibility; its seed is public and is not a key.

## Vendor outputs, source inputs and tools

The included FPGA configurations are GOWIN-device-specific implementation
outputs. The three original inference configurations and the seeded-sampling variant
incorporate the selected DDR/clock functions;
the separate reader contains no vendor DDR controller. GOWIN and Sipeed
retain their respective third-party rights. See [LICENSING.md](LICENSING.md)
for the output-distribution judgment and its scope.

GOWIN software, vendor libraries, encrypted source IP and flattened netlists
are not bundled. [VENDOR-DEPENDENCIES.json](demos/simplestories-v2-5m/VENDOR-DEPENDENCIES.json) identifies
the four separately fetched source files. Their original notices must be
retained when obtaining them. The downloader checks identity, not permission.
Python packages, numerical libraries and verification tools are likewise
installed separately under their own terms.
The openFPGALoader utility used for restoring a complete factory backup is
also installed separately; no copy of its executable or libraries is bundled.

## Qwen3-1.7B and Qwen3-8B / AWS F2

The Qwen demonstrations use pinned `Qwen/Qwen3-1.7B` and `Qwen/Qwen3-8B` checkpoints,
Berkeley HardFloat modules and AWS-specific integration. Their
[1.7B dependency notice](demos/qwen3-1.7b/NOTICES.md) and
[8B dependency notice](demos/qwen3-8b/NOTICES.md) identify the
upstream model license, BSD-style arithmetic license, Amazon Software License
files and separately installed vendor dependencies. In particular, the project's
Apache-2.0 grant does not override Amazon-platform-use restrictions in AWS files.

The separate [8B protected K/V component notice](demos/qwen3-8b/variants/protected-kv-simulation/capsule/NOTICES.md)
identifies its retained source snapshot and complete dependency licenses.
Its AWS-marked files retain their Amazon-platform-use restriction.

## TLM26 MoE / Tang Mega

The [TLM26 dependency notices](demos/tlm26-moe/NOTICES.md) preserve the upstream
MIT source license and identify the model card's MIT declaration, pinned
checkpoint and tokenizer. The model inputs are fetched during reproduction.
Fable supplied the SHA-256 compressor; the fixed decoder, page integration,
UART/boot controller and board port are project-owned implementation work.
The adjacent `demos/tlm26-moe/board/product.cst.NOTICE` retains the Sipeed and
GOWIN board-constraint notices without modifying the tested constraint bytes.
Vendor DDR/clock IP and tools are obtained separately under their terms.

## AI and media attribution

The README credits GPT 5.6 Sol, GPT 6 Astra and GPT 6.1 Sol for the custom
implementation, Fable for the TLM26 SHA-256 compressor, and Fable 5.1 and
Opus 5.5 for incorporated review feedback. Those credits do not cover
the pretrained model, FPGA silicon, Sipeed board, vendor IP or tools.
The owner-supplied board photograph and demonstration videos are included in
the project's Apache-2.0 grant; removal of personal metadata is not an
ownership claim about their subjects or third-party software shown on screen.

## neoTRNG in the home-authorization S-AWIC

The optional SimpleStories home-authorization variant incorporates neoTRNG by Stephan Nolting under the BSD 3-Clause license. Its source, copyright/license header and complete license are retained in `demos/simplestories-v2-5m/variants/home-authorization/nonce/vendor/`; the pinned upstream identity is in `nonce/DEPENDENCY.json`. This notice does not imply entropy or cryptographic-security qualification.

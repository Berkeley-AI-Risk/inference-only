"""Run the relocated, read-only recorded-receipt/deduction checker."""
if not __debug__:
    raise RuntimeError('Run without Python optimization.')
from pathlib import Path
import ast
import contextlib
import copy
import datetime
import hashlib
import json
import math
import os
import re
import symtable
import sys
import time
import types

ROOT = Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
canonical = lambda value: (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def main():
    assert sys.version_info[:3] == (3, 12, 12) and sys.platform == 'linux'
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert ROOT == Path('/proof'), 'Provision this export at /proof; see README.md.'
    envelope_raw = (ROOT / 'EXPORT-MANIFEST.json').read_bytes()
    envelope = json.loads(envelope_raw)
    expected = {row['path'] for row in envelope['files']}
    assert len(expected) == len(envelope['files'])
    assert all(not path.is_symlink() for path in ROOT.rglob('*'))
    assert {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file()} == expected | {'EXPORT-MANIFEST.json'}
    for row in envelope['files']:
        relative = Path(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        raw = (ROOT / relative).read_bytes()
        assert sha(raw) == row['sha256'] and len(raw) == row['bytes'], row['path']
    relocation = json.loads((ROOT / 'RELOCATION.json').read_bytes())
    assert relocation['original_seal_sha256'] == '8b2cd9877fe5b494624c1de01c2a5c224235084a973bc249acf8ca14a7ac5252'
    for row in relocation['files']:
        path = ROOT / row['path']
        assert path.is_relative_to(ROOT) and not path.is_symlink()
        raw = path.read_bytes()
        assert sha(raw) == row['portable_sha256'] and len(raw) == row['bytes'], row['path']
    folder = ROOT / 'r-repository/inference-only/tang-greedy-speed/session-isolation/main-proof/head-row12-score-r1/engine-row-component-r1'
    checker = folder / 'check_component.py'
    module = types.ModuleType('_portable_head_row12_component')
    module.__file__ = str(checker)
    exec(compile(checker.read_bytes(), str(checker), 'exec'), module.__dict__)
    started = time.monotonic()
    result = module.check()
    assert canonical(result) == (folder / 'CHECK-COMPONENT.json').read_bytes()
    assert result['passed'] and result['recorded_native_leaves'] == 16
    assert result['proof_nodes_reconstructed'] == 513
    assert result['new_native_jobs'] == result['writes'] == 0
    print(json.dumps({'passed': True, 'recorded_native_leaves': 16,
                      'proof_nodes_reconstructed': 513,
                      'reconstructed_result_byte_identical': True,
                      'original_seal_sha256': relocation['original_seal_sha256'],
                      'portable_result_sha256': sha(canonical(result)),
                      'export_manifest_sha256': sha(envelope_raw),
                      'python_version': '3.12.12',
                      'python_executable_sha256': sha(Path(sys.executable).read_bytes()),
                      'connected_native_smt_sha256': 'c07076ec5f5f4f27ca8208e502a0274b047552e5c356dc9bddaf03cd5b648b54',
                      'new_solver_jobs': 0,
                      'whole_device_theorem': False,
                      'wall_seconds': round(time.monotonic() - started, 6)}, sort_keys=True))


if __name__ == '__main__':
    main()

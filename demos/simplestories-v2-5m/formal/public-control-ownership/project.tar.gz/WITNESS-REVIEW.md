# Independent witness diagnosis and selected operating result

**ACCEPT R5 as the selected reset-rooted operating witness, with R2 as the
guard-validation check.** Both have actual clean compile/simulation receipts
and raw success logs. R5 supplies the previously missing directed operating
condition for the reviewed SMT safety composition. This grants no further
engine run and does not extend its numerical, physical-memory or whole-device
scope. Earlier failed attempts must remain preserved and reported.

I read R1–R5 source differences, input manifests, raw run receipts/logs and the
diagnostic runner/budget. Read-only Python checked all source pins, nine run
receipt/log pairs, the selected aggregate result bindings, exact guard change,
read-only reset additions and complete ordered event log. I ran no compiler,
solver or simulator.

## Unknown-value guard diagnosis

R1 retains the original `$isunknown` guard and fatal check, adding only prints
inside the triggered branch. Its raw log shows clear/STEP-valid/STEP-ready/
token-valid all zero, production bridge phase `010`, shell state `00001`, and
concatenation `000001000001`. Individual and concatenated `$isunknown` calls
printed inside that branch all return zero. The run then fails at the retained
fatal check, exit one. This records the observed inconsistent guard behavior
in this elaboration; it does not establish a general Icarus defect theorem or
justify silently removing unknown-value detection.

R2 independently exercises the exact replacement predicate on the same twelve
bits: reduction XOR of the concatenation, case-compared to one-bit X. It rejects
every injected X or Z and accepts every known word. Its source loops over all
4,096 known patterns and each of twelve single-bit X and Z injections, yielding
4,096 known checks, 49,152 X-injection checks and 49,152 Z-injection checks.
These are injection counts, not a claim to enumerate every multi-unknown word.
The raw result is `GUARDPASS known=4096 X=49152 Z=49152`, with zero exit and no
fatal error.

Under four-state XOR semantics, any X/Z operand propagates an X through the
reduction; with all known operands the result is known. Case equality with X
therefore detects the same unknown-bit condition intended by `$isunknown`.
The guard has not been weakened to ignore unknowns or to assume a legal caller.

R3 differs from the approved declaration-portability testbench in exactly that
one guard expression. The original fatal body, source, providers, inputs,
stimulus timing, ownership/payload/reset sequence and all other checks are
unchanged. It passes the complete event sequence and marker. No native register
is forced, no detector is disabled and no production/source/SMT fix is made.

## Explicit reset observation and selected R5

R4 adds reset counters/observations but places two monitor processes before the
clock/reset declarations. Its compiler exits four with explicit unbound event
expression errors. Its raw receipt/log remain; no R4 simulation ran and it has
no success credit.

R5 corrects only those monitor-process positions. Relative to R3 it adds two
initialized integer counters, two read-only observations, a final failing reset
check and a display. Removing those exact additions restores R3 byte-for-byte.
The counters observe the actual DUT reset input low on core rising edges and
count public hard-reset releases. They drive no DUT input or native state.
They require at least two low edges and exactly one release, rather than
assuming those values. All prior stops/checks remain.

The actual selected R5 log is, in order:

```text
STEP ticket=1 count=1 cycle=32378
COMMIT candidate=23 ticket=1
CLEAR old_held=23 captures=0
DRAIN
STEP ticket=2 count=1 cycle=215817
COMMIT candidate=17 ticket=2
CAPTURE ticket=2 value=17
TOKEN_FRAME value=17 late_fault=1
RESET_OBSERVED low_edges=5 releases=1
CASEPASS public steps=2 clear=1 commits=2 captures=1 old=23 new=17 late_fault=1
```

The unchanged checks additionally inspect actual accepted tape values 7/9,
successful next Hold/count/value, cancellation of held 23 before capture, new
work after actual controller drain, one captured 17 reply and all five outgoing
byte values/CRC after the later fault and ignored CLEAR attempt. This is one
real reset-rooted execution of the source controller/UART model at its declared
cut inputs. It does not turn protocol-only K/V stimuli or opaque winners into
numerical/physical providers.

R5 compilation and simulation both exit zero with no stop reason. Its raw log
has the exact marker and no FATAL/ERROR marker. The existing provider address-
width warnings concern unchanged zero/unissued address carriers at abstracted
provider seams; they are not a new driver/width change or a physical memory
claim. R2, R3 and R5 preserve the same production/controller input bindings.

## Integrity, accounting and closeout use

All original 100 frozen proof/model/source inputs still match manifest
`62348b7adc16d158ec5446979e70e758960dbf79e5851f811c379fab43b5b141`.
All R1–R5 input manifests match their current source bytes and the diagnostic
runner digest. The declared providers remain byte-identical. The universal SMT
queries and eighteen selected proof/context receipts are unchanged.

Five of six authorized pairs were used; R4 stopped at compilation, for nine
actual diagnostic tool jobs. All recorded jobs completed within their 60-second
limits and the explicit 03:03:10–03:15:10 UTC window, on the original pilot
clock/resource gate. No more pair is needed or authorized by this review.

The previous `WITNESS-RESULT.json` still identifies the earlier failed
portability simulation. Preserve that record before making the selected-result
pointer identify R5 and R2 explicitly. Do not overwrite the initial compile
failure, portability guard failure, R1 diagnostic failure, R4 compile failure,
or initial unaugmented history SAT. The earlier pre-witness closeout review is
accurate for its timestamp; this separate result now supplies its missing
operating condition.

## Selected result pins

| Artifact | SHA-256 |
| --- | --- |
| `witness-diagnosis/r2/tb.sv` | `48ee6ee7c46d3a1a7497441ebfbdc63deff5de08db0d6a1bf62f025fe38c553e` |
| `witness-diagnosis/r2/INPUTS.json` | `3abf86c6480fe948cbfb23024e1349c465fc3f49abd68210b0fed13d28e58273` |
| `witness-diagnosis/r2/RESULT.json` | `f4de9b7edace6d5fc083e5d302e5dafa6644ce7b26f907e91a135f944b47ccd0` |
| R2 raw simulation log | `a0af9b7128028020c3eb40f1087b82e7fc31b838b8940e7d6f5fbd7d8d0f4559` |
| `witness-diagnosis/r5/tb.sv` | `a87d79410837881eafb94cb1f5d3a03a605bb5789fc1a7ba7b66d8a56966891a` |
| `witness-diagnosis/r5/INPUTS.json` | `cdc5f3ef137ed5d545bb47c81f3d0d934daced14f850c7f3bf46cee6b7cae965` |
| `witness-diagnosis/r5/RESULT.json` | `0f3a1f958091ba14cdb62daded1d19cc93d146fd9b5f4b5cdabe71ffab1b4d66` |
| R5 raw compile receipt | `ac14c3b91c678b9a4419a62c64c3369e4612d2e9cd6c1001c82c240a8754a377` |
| R5 raw simulation receipt | `dcdb70951f55280ea1931c0226b6ddc0e5ee677631dd4f90883a0da8b7c4dc8f` |
| R5 raw simulation log | `0a24397404f642cf3492c2eeed38e3b516997fc20f32dae05f571d6fb3b60654` |

The selected receipts are
`runs/witness-diagnosis-r5-compile-20261107T030534730996Z/RESULT.json` and
`runs/witness-diagnosis-r5-simulation-20261107T030534880245Z/RESULT.json`.
This operating evidence completes the reviewed witness condition alongside
the closed native→phase→history→endpoint safety composition and source defect
check. It does not prove current-invocation argmax origin, `token=P(tape)`,
full graph/numerical provenance, physical drain, all faults/timing/private
effects, protected-K/V composition, other configurations or the original main
theorem. Those limits remain exactly as previously reviewed.

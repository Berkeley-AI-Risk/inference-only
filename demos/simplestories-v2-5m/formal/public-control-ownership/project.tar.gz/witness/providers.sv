module witness_u_fixed_embedding #(
    parameter integer ADDR_W = 25,
    parameter integer METADATA_BASE_WORD = 211920,
    parameter integer MAX_COMPUTE_CYCLES = 4_000_000
) (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    clear_i,
    input  wire                    model_lock_i,
    input  wire                    upstream_fault_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,
    input  wire [11:0]             fixed_token_i,

    output wire                    private_word_req_valid_o,
    input  wire                    private_word_req_ready_i,
    output wire [ADDR_W-1:0]       private_word_req_index_o,
    input  wire                    private_word_rsp_valid_i,
    output wire                    private_word_rsp_ready_o,
    input  wire [255:0]            private_word_rsp_data_i,
    input  wire                    private_word_rsp_fault_i,

    output logic                   result_valid_o,
    input  wire                    result_ready_i,
    output logic [7:0]             result_index_o,
    output logic signed [15:0]     result_mantissa_o,
    output logic signed [7:0]      result_exponent_o,
    output logic                   result_last_o,
    output logic                   done_valid_o,
    input  wire                    done_ready_i,
    output logic                   busy_o,
    output logic                   fail_closed_o
);
reg active=0,captured=0;reg[13:0]incoming=0,outgoing=0,rows=0;
always @(posedge clk) begin
 if(!rst_n || clear_i) begin active<=0;captured<=0;incoming<=0;outgoing<=0;rows<=0;end
 else if(start_valid_i && start_ready_o) begin
  active<=1;captured<=1;incoming<=0;outgoing<=0;rows<=14'd256;
 end else if(active) begin
  
  if(result_valid_o && result_ready_i) outgoing<=outgoing+1'b1;
  if(done_valid_o && done_ready_i) active<=0;
 end
end
assign start_ready_o=!active;
assign private_word_req_valid_o='0;
assign private_word_req_index_o='0;
assign private_word_rsp_ready_o='0;
assign result_valid_o=active && captured && outgoing<rows;
assign result_index_o=outgoing;
assign result_mantissa_o='0;
assign result_exponent_o='0;
assign result_last_o=outgoing==rows-1;
assign done_valid_o=active && captured && outgoing==rows;
assign busy_o=active;
assign fail_closed_o='0;

endmodule
module witness_u_final_rmsnorm #(
    parameter integer MAX_COMPUTE_CYCLES = 2_000_000,
    parameter NORM_ROM_FILE =
        "fpga/token_only_model0_ddr_board1/fixed_vector_rmsnorm0/recorded/norm_rom34.memh"
) (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    clear_i,
    input  wire                    model_lock_i,
    input  wire                    upstream_fault_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,
    input  wire [2:0]              fixed_layer_i,
    // 0=input RMSNorm, 1=post-attention RMSNorm, 2=final RMSNorm.
    input  wire [1:0]              fixed_norm_kind_i,
    input  wire signed [7:0]       input_exponent_i,

    input  wire                    input_valid_i,
    output logic                   input_ready_o,
    input  wire [7:0]              input_row_index_i,
    input  wire signed [15:0]      input_mantissa_i,
    input  wire                    input_last_i,

    output logic                   result_valid_o,
    input  wire                    result_ready_i,
    output logic [7:0]             result_row_index_o,
    output logic signed [15:0]     result_mantissa_o,
    output logic signed [7:0]      result_exponent_o,
    output logic                   result_last_o,
    output logic                   done_valid_o,
    input  wire                    done_ready_i,
    output logic                   busy_o,
    output logic                   range_fault_o
);
reg active=0,captured=0;reg[13:0]incoming=0,outgoing=0,rows=0;
always @(posedge clk) begin
 if(!rst_n || clear_i) begin active<=0;captured<=0;incoming<=0;outgoing<=0;rows<=0;end
 else if(start_valid_i && start_ready_o) begin
  active<=1;captured<=0;incoming<=0;outgoing<=0;rows<=14'd256;
 end else if(active) begin
  if(input_valid_i && input_ready_o) begin
   incoming<=incoming+1'b1;
   if(input_last_i) begin captured<=1;end
  end
  if(result_valid_o && result_ready_i) outgoing<=outgoing+1'b1;
  if(done_valid_o && done_ready_i) active<=0;
 end
end
assign start_ready_o=!active;
assign input_ready_o=active && !captured;
assign result_valid_o=active && captured && outgoing<rows;
assign result_row_index_o=outgoing;
assign result_mantissa_o='0;
assign result_exponent_o='0;
assign result_last_o=outgoing==rows-1;
assign done_valid_o=active && captured && outgoing==rows;
assign busy_o=active;
assign range_fault_o='0;

endmodule
module witness_u_exact_argmax (
    input  wire                    clk,
    input  wire                    reset_n,
    input  wire                    clear_i,
    input  wire                    model_locked_i,
    input  wire                    upstream_fail_closed_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,

    input  wire                    row_valid_i,
    output logic                   row_ready_o,
    input  wire [12:0]             row_index_i,
    input  wire signed [49:0]      row_scaled_raw_i,
    input  wire signed [7:0]       row_source_exponent_i,
    input  wire                    row_last_i,

    output logic                   winner_valid_o,
    input  wire                    winner_ready_i,
    output logic [11:0]            winner_token_id_o,
    output logic signed [49:0]     winner_scaled_raw_o,
    output logic signed [7:0]      winner_source_exponent_o,

    output logic                   busy_o,
    output logic                   fail_closed_o,
 input wire [11:0] witness_token_i,
 input wire witness_release_winner_i
);
reg active=0;reg[12:0]count=0;
always @(posedge clk) begin
 if(!reset_n || clear_i) begin active<=0;count<=0;end
 else if(start_valid_i && start_ready_o) begin active<=1;count<=0;end
 else begin
  if(row_valid_i && row_ready_o) count<=count+1'b1;
  if(winner_valid_o && winner_ready_i) active<=0;
 end
end
assign start_ready_o=!active;
assign row_ready_o=active && count<4019;
assign winner_valid_o=active && count==4019 && witness_release_winner_i;
assign winner_token_id_o=witness_token_i;
assign winner_scaled_raw_o='0;
assign winner_source_exponent_o='0;
assign busy_o=active;
assign fail_closed_o='0;

endmodule
module witness_u_gate_scratch (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [9:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [9:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_up_scratch (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [9:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [9:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_attention_scratch (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [7:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [7:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_rms_scratch (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [7:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [7:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_output_scratch (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [7:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [7:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_hidden_state (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [7:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [7:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_query_state (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [7:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [7:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_key_state (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [6:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [6:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_value_state (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [6:0]              private_read_address_i,
    output logic signed [15:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [6:0]              private_write_address_i,
    input  wire signed [15:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_rope_raw_scratch (
    input  wire                    clk,
    input  wire                    private_read_enable_i,
    input  wire [4:0]              private_read_address_i,
    output logic signed [49:0]     private_read_data_o,
    input  wire                    private_write_enable_i,
    input  wire [4:0]              private_write_address_i,
    input  wire signed [49:0]      private_write_data_i
);
assign private_read_data_o='0;

endmodule
module witness_u_rmsnorm #(
    parameter integer MAX_COMPUTE_CYCLES = 2_000_000,
    parameter NORM_ROM_FILE =
        "fpga/token_only_model0_ddr_board1/fixed_vector_rmsnorm0/recorded/norm_rom34.memh"
) (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    clear_i,
    input  wire                    model_lock_i,
    input  wire                    upstream_fault_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,
    input  wire [2:0]              fixed_layer_i,
    // 0=input RMSNorm, 1=post-attention RMSNorm, 2=final RMSNorm.
    input  wire [1:0]              fixed_norm_kind_i,
    input  wire signed [7:0]       input_exponent_i,

    input  wire                    input_valid_i,
    output logic                   input_ready_o,
    input  wire [7:0]              input_row_index_i,
    input  wire signed [15:0]      input_mantissa_i,
    input  wire                    input_last_i,

    output logic                   result_valid_o,
    input  wire                    result_ready_i,
    output logic [7:0]             result_row_index_o,
    output logic signed [15:0]     result_mantissa_o,
    output logic signed [7:0]      result_exponent_o,
    output logic                   result_last_o,
    output logic                   done_valid_o,
    input  wire                    done_ready_i,
    output logic                   busy_o,
    output logic                   range_fault_o
);
reg active=0,captured=0;reg[13:0]incoming=0,outgoing=0,rows=0;
always @(posedge clk) begin
 if(!rst_n || clear_i) begin active<=0;captured<=0;incoming<=0;outgoing<=0;rows<=0;end
 else if(start_valid_i && start_ready_o) begin
  active<=1;captured<=0;incoming<=0;outgoing<=0;rows<=14'd256;
 end else if(active) begin
  if(input_valid_i && input_ready_o) begin
   incoming<=incoming+1'b1;
   if(input_last_i) begin captured<=1;end
  end
  if(result_valid_o && result_ready_i) outgoing<=outgoing+1'b1;
  if(done_valid_o && done_ready_i) active<=0;
 end
end
assign start_ready_o=!active;
assign input_ready_o=active && !captured;
assign result_valid_o=active && captured && outgoing<rows;
assign result_row_index_o=outgoing;
assign result_mantissa_o='0;
assign result_exponent_o='0;
assign result_last_o=outgoing==rows-1;
assign done_valid_o=active && captured && outgoing==rows;
assign busy_o=active;
assign range_fault_o='0;

endmodule
module witness_u_projection #(
    parameter integer ADDR_W = 25,
    parameter integer METADATA_BASE_WORD = 211920
) (
    input  wire                     clk,
    input  wire                     reset_n,
    input  wire                     clear_i,
    input  wire                     model_locked_i,
    input  wire                     upstream_fail_closed_i,

    input  wire                     start_valid_i,
    output logic                    start_ready_o,
    input  wire [2:0]               fixed_layer_i,
    input  wire [3:0]               fixed_job_i,
    input  wire signed [7:0]        activation_exponent_i,

    input  wire                     activation_valid_i,
    output logic                    activation_ready_o,
    input  wire signed [15:0]       activation_i,
    input  wire                     activation_last_i,

    output wire                     private_word_req_valid_o,
    input  wire                     private_word_req_ready_i,
    output wire [ADDR_W-1:0]        private_word_req_index_o,
    input  wire                     private_word_rsp_valid_i,
    output wire                     private_word_rsp_ready_o,
    input  wire [255:0]             private_word_rsp_data_i,
    input  wire                     private_word_rsp_fault_i,

    output logic                    result_valid_o,
    input  wire                     result_ready_i,
    output logic [12:0]             result_row_index_o,
    output logic signed [49:0]      result_scaled_raw_o,
    output logic signed [7:0]       result_source_exponent_o,
    output logic                    result_last_o,

    output logic                    done_valid_o,
    input  wire                     done_ready_i,
    output logic                    busy_o,
    output logic                    fail_closed_o
);
reg active=0,captured=0;reg[13:0]incoming=0,outgoing=0,rows=0;
always @(posedge clk) begin
 if(!reset_n || clear_i) begin active<=0;captured<=0;incoming<=0;outgoing<=0;rows<=0;end
 else if(start_valid_i && start_ready_o) begin
  active<=1;captured<=0;incoming<=0;outgoing<=0;rows<=(fixed_job_i==1 || fixed_job_i==2)?14'd128:(fixed_job_i==4 || fixed_job_i==5)?14'd682:fixed_job_i==7?14'd4019:14'd256;
 end else if(active) begin
  if(activation_valid_i && activation_ready_o) begin
   incoming<=incoming+1'b1;
   if(activation_last_i) begin captured<=1;end
  end
  if(result_valid_o && result_ready_i) outgoing<=outgoing+1'b1;
  if(done_valid_o && done_ready_i) active<=0;
 end
end
assign start_ready_o=!active;
assign activation_ready_o=active && !captured;
assign private_word_req_valid_o='0;
assign private_word_req_index_o='0;
assign private_word_rsp_ready_o='0;
assign result_valid_o=active && captured && outgoing<rows;
assign result_row_index_o=outgoing;
assign result_scaled_raw_o='0;
assign result_source_exponent_o='0;
assign result_last_o=outgoing==rows-1;
assign done_valid_o=active && captured && outgoing==rows;
assign busy_o=active;
assign fail_closed_o='0;

endmodule
module witness_u_normalizer #(
    parameter integer MAX_COMPUTE_CYCLES = 2_000_000
) (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    clear_i,
    input  wire                    model_lock_i,
    input  wire                    upstream_fault_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,
    input  wire [2:0]              fixed_layer_i,
    input  wire [3:0]              fixed_job_i,

    input  wire                    input_valid_i,
    output logic                   input_ready_o,
    input  wire [9:0]              input_row_index_i,
    input  wire signed [49:0]      input_raw_i,
    input  wire signed [7:0]       input_source_exponent_i,
    input  wire                    input_last_i,

    output logic                   result_valid_o,
    input  wire                    result_ready_i,
    output logic [9:0]             result_row_index_o,
    output logic signed [15:0]     result_mantissa_o,
    output logic signed [7:0]      result_exponent_o,
    output logic                   result_last_o,
    output logic                   done_valid_o,
    input  wire                    done_ready_i,
    output logic                   busy_o,
    output logic                   range_fault_o
);
reg active=0,captured=0;reg[13:0]incoming=0,outgoing=0,rows=0;
always @(posedge clk) begin
 if(!rst_n || clear_i) begin active<=0;captured<=0;incoming<=0;outgoing<=0;rows<=0;end
 else if(start_valid_i && start_ready_o) begin
  active<=1;captured<=0;incoming<=0;outgoing<=0;rows<=14'd256;
 end else if(active) begin
  if(input_valid_i && input_ready_o) begin
   incoming<=incoming+1'b1;
   if(input_last_i) begin captured<=1;rows<=incoming+1'b1;end
  end
  if(result_valid_o && result_ready_i) outgoing<=outgoing+1'b1;
  if(done_valid_o && done_ready_i) active<=0;
 end
end
assign start_ready_o=!active;
assign input_ready_o=active && !captured;
assign result_valid_o=active && captured && outgoing<rows;
assign result_row_index_o=outgoing;
assign result_mantissa_o='0;
assign result_exponent_o='0;
assign result_last_o=outgoing==rows-1;
assign done_valid_o=active && captured && outgoing==rows;
assign busy_o=active;
assign range_fault_o='0;

endmodule
module witness_u_elementwise_lane (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    clear_i,
    input  wire                    request_valid_i,
    output wire                    request_ready_o,
    input  wire [2:0]              operation_i,
    input  wire signed [15:0]      first_i,
    input  wire signed [15:0]      second_i,
    input  wire signed [9:0]       coefficient_i,
    input  wire [15:0]             multiplier_i,
    input  wire signed [15:0]      cosine_i,
    input  wire signed [15:0]      sine_i,
    input  wire signed [7:0]       first_exponent_i,
    input  wire signed [7:0]       second_exponent_i,
    input  wire signed [7:0]       common_exponent_i,
    input  wire signed [7:0]       target_exponent_i,

    output wire                    lut_request_o,
    output wire [15:0]             lut_index_o,
    input  wire                    lut_response_valid_i,
    input  wire signed [15:0]      lut_value_i,
    input  wire                    lut_fault_i,

    output wire                    result_valid_o,
    input  wire                    result_ready_i,
    output wire signed [15:0]      result0_o,
    output wire signed [15:0]      result1_o,
    output wire signed [15:0]      auxiliary_o,
    output wire signed [49:0]      raw0_o,
    output wire signed [49:0]      raw1_o,
    output wire signed [7:0]       source_exponent_o,
    output wire                    range_fault_o
);
reg pending=0;
always @(posedge clk) begin
 if(!rst_n || clear_i) pending<=0;
 else if(request_valid_i && request_ready_o) pending<=1;
 else if(result_valid_o && result_ready_i) pending<=0;
end
assign request_ready_o=!pending;
assign lut_request_o='0;
assign lut_index_o='0;
assign result_valid_o=pending;
assign result0_o='0;
assign result1_o='0;
assign auxiliary_o='0;
assign raw0_o='0;
assign raw1_o='0;
assign source_exponent_o='0;
assign range_fault_o='0;

endmodule
module witness_u_lookup #(
    parameter integer ADDR_W = 25,
    parameter logic [ADDR_W-1:0] ROPE_COS_BASE_WORD = 214261,
    parameter logic [ADDR_W-1:0] ROPE_SIN_BASE_WORD = 214517,
    parameter logic [ADDR_W-1:0] SILU_BASE_WORD = 215286,
    parameter logic [ADDR_W-1:0] ROPE_COS_TAIL_BASE_WORD = 219382,
    parameter logic [ADDR_W-1:0] ROPE_SIN_TAIL_BASE_WORD = 223222,
    parameter logic [ADDR_W-1:0] MODEL_WORDS = 227062
) (
    input  wire                    clk,
    input  wire                    reset_n,
    input  wire                    clear_i,
    input  wire                    model_locked_i,
    input  wire                    upstream_fail_closed_i,

    input  wire                    request_valid_i,
    output logic                   request_ready_o,
    // 0 = RoPE cosine, 1 = RoPE sine, 2 = SiLU.  3 is invalid.
    input  wire [1:0]              fixed_kind_i,
    input  wire [10:0]             rope_position_i,
    input  wire [4:0]              rope_coordinate_i,
    input  wire [15:0]             silu_index_i,

    output logic                   response_valid_o,
    input  wire                    response_ready_i,
    output logic signed [15:0]     response_value_o,
    output logic                   response_fault_o,

    output logic                   private_word_req_valid_o,
    input  wire                    private_word_req_ready_i,
    output logic [ADDR_W-1:0]      private_word_req_index_o,
    input  wire                    private_word_rsp_valid_i,
    output logic                   private_word_rsp_ready_o,
    input  wire [255:0]            private_word_rsp_data_i,
    input  wire                    private_word_rsp_fault_i,

    output logic                   busy_o,
    output logic                   fail_closed_o
);
reg pending=0;
always @(posedge clk) begin
 if(!reset_n || clear_i) pending<=0;
 else if(request_valid_i && request_ready_o) pending<=1;
 else if(response_valid_o && response_ready_i) pending<=0;
end
assign request_ready_o=!pending;
assign response_valid_o=pending;
assign response_value_o='0;
assign response_fault_o='0;
assign private_word_req_valid_o='0;
assign private_word_req_index_o='0;
assign private_word_rsp_ready_o='0;
assign busy_o=pending;
assign fail_closed_o='0;

endmodule
module witness_u_kv_cache (
    input  wire                     clk,
    input  wire                     reset_n,
    input  wire                     clear_i,
    input  wire                     model_locked_i,
    input  wire                     upstream_fault_i,
    input  wire                     endpoint_fault_i,

    // Fixed population role.  Coordinates 0..63 populate head 0 and
    // coordinates 64..127 populate head 1.
    input  wire                     stage_begin_valid_i,
    output logic                    stage_begin_ready_o,
    input  wire  [2:0]              stage_layer_i,
    input  wire  [11:0]             stage_position_i,
    input  wire  signed [15:0]      stage_key_exponents_i,
    input  wire  signed [15:0]      stage_value_exponents_i,
    input  wire                     stage_payload_valid_i,
    output logic                    stage_payload_ready_o,
    input  wire  [6:0]              stage_coordinate_i,
    input  wire  signed [15:0]      stage_key_i,
    input  wire  signed [15:0]      stage_value_i,
    input  wire                     stage_last_i,
    output logic                    pending_complete_o,

    // Exact descriptor commit.  Publication is a metadata operation: both
    // head rows have already reached DDR before this can become ready.
    input  wire                     commit_valid_i,
    output logic                    commit_ready_o,
    input  wire  [2:0]              commit_layer_i,
    input  wire  [11:0]             commit_position_i,

    // Fixed attention role.  Request kind is semantic, never a DDR direction:
    // 00 full K/V, 01 K only, 10 V only, 11 reserved/fault.
    input  wire                     attention_req_valid_i,
    output logic                    attention_req_ready_o,
    input  wire  [1:0]              attention_req_kind_i,
    input  wire  [2:0]              attention_layer_i,
    input  wire  [11:0]             attention_position_i,
    input  wire  [1:0]              attention_kv_head_i,
    output logic                    attention_rsp_valid_o,
    input  wire                     attention_rsp_ready_i,
    output logic [1:0]              attention_rsp_kind_o,
    output logic [1023:0]           attention_rsp_key_vector_o,
    output logic signed [7:0]       attention_rsp_key_exponent_o,
    output logic [1023:0]           attention_rsp_value_vector_o,
    output logic signed [7:0]       attention_rsp_value_exponent_o,
    output logic                    attention_rsp_fault_o,
    output logic                    attention_rsp_from_pending_o,

    // Integration-private typed DDR capabilities.  Direction is fixed by
    // which channel is asserted, not supplied as data by the semantic caller.
    output logic                    kv_write_req_valid_o,
    input  wire                     kv_write_req_ready_i,
    output logic [2:0]              kv_write_req_layer_o,
    output logic [11:0]             kv_write_req_position_o,
    output logic [1:0]              kv_write_req_head_o,
    output logic [3:0]              kv_write_req_row_word_o,
    output logic [18:0]             kv_write_req_shadow_address_o,
    output logic [255:0]            kv_write_req_data_o,
    input  wire                     kv_write_cpl_valid_i,
    output logic                    kv_write_cpl_ready_o,
    input  wire                     kv_write_cpl_fault_i,

    output logic                    kv_read_req_valid_o,
    input  wire                     kv_read_req_ready_i,
    output logic [2:0]              kv_read_req_layer_o,
    output logic [11:0]             kv_read_req_position_o,
    output logic [1:0]              kv_read_req_head_o,
    output logic [3:0]              kv_read_req_row_word_o,
    output logic [18:0]             kv_read_req_shadow_address_o,
    input  wire                     kv_read_rsp_valid_i,
    output logic                    kv_read_rsp_ready_o,
    input  wire  [255:0]            kv_read_rsp_data_i,
    input  wire                     kv_read_rsp_fault_i,

    output logic [71:0]             committed_prefixes_o,
    output logic                    busy_o,
    output logic                    fail_closed_o
);

reg staging=0,complete=0,reply=0; reg [71:0] prefixes=0;
reg [2:0] layer=0; reg[11:0] position=0;reg from_pending=0;
always @(posedge clk) begin
 if(!reset_n || clear_i) begin staging<=0;complete<=0;reply<=0;prefixes<=0;from_pending<=0;end
 else begin
  if(stage_begin_valid_i && stage_begin_ready_o) begin staging<=1;complete<=0;layer<=stage_layer_i;position<=stage_position_i;end
  if(stage_payload_valid_i && stage_payload_ready_o && stage_last_i) begin staging<=0;complete<=1;end
  if(commit_valid_i && commit_ready_o) begin complete<=0;prefixes[12*commit_layer_i+:12]<=commit_position_i+12'd1;end
  if(attention_req_valid_i && attention_req_ready_o) begin reply<=1;from_pending<=complete && attention_position_i==position;end
  else if(attention_rsp_valid_o && attention_rsp_ready_i) reply<=0;
 end
end

assign stage_begin_ready_o=!staging && !complete;
assign stage_payload_ready_o=staging;
assign pending_complete_o=complete;
assign commit_ready_o=complete;
assign attention_req_ready_o=!reply;
assign attention_rsp_valid_o=reply;
assign attention_rsp_kind_o='0;
assign attention_rsp_key_vector_o='0;
assign attention_rsp_key_exponent_o='0;
assign attention_rsp_value_vector_o='0;
assign attention_rsp_value_exponent_o='0;
assign attention_rsp_fault_o='0;
assign attention_rsp_from_pending_o=from_pending;
assign kv_write_req_valid_o='0;
assign kv_write_req_layer_o='0;
assign kv_write_req_position_o='0;
assign kv_write_req_head_o='0;
assign kv_write_req_row_word_o='0;
assign kv_write_req_shadow_address_o='0;
assign kv_write_req_data_o='0;
assign kv_write_cpl_ready_o='0;
assign kv_read_req_valid_o='0;
assign kv_read_req_layer_o='0;
assign kv_read_req_position_o='0;
assign kv_read_req_head_o='0;
assign kv_read_req_row_word_o='0;
assign kv_read_req_shadow_address_o='0;
assign kv_read_rsp_ready_o='0;
assign committed_prefixes_o=prefixes;
assign busy_o=staging || reply;
assign fail_closed_o='0;
endmodule
module witness_u_attention #(
    parameter EXP_FILE = "model_rtl_evidence/attention_sublayer/exp_neg_q30.memh",
    parameter integer MAX_COMPUTE_CYCLES = 40_000_000
) (
    input  wire                    clk,
    input  wire                    rst_n,
    input  wire                    clear_i,
    input  wire                    model_lock_i,
    input  wire                    upstream_fault_i,

    input  wire                    start_valid_i,
    output logic                   start_ready_o,
    input  wire [10:0]             fixed_position_i,
    input  wire [2:0]              fixed_layer_i,
    // Accepted private KV staging/commit observations; no transport changes.
    input wire summary_stage_begin_i, summary_stage_value_valid_i,
    input wire [6:0] summary_stage_coordinate_i,
    input wire signed [15:0] summary_stage_value_i,
    input wire signed [7:0] summary_stage_exponent_i,
    input wire summary_pending_complete_i, summary_commit_i,
    input  wire signed [7:0]       query_exponent_i,

    // Four accepted beats, in hardwired query-head order 0,1,2,3.
    input  wire                    query_valid_i,
    output logic                   query_ready_o,
    input  wire [1023:0]           query_vector_i,
    input  wire                    query_last_i,

    // Private fixed-cache client. Exactly one request may be outstanding.
    // The role comes only from the frozen attention schedule, not the host.
    output logic                   private_cache_request_valid_o,
    output logic [1:0]             private_cache_request_kind_o,
    input  wire                    private_cache_request_ready_i,
    output logic [10:0]            private_cache_request_position_o,
    output logic                   private_cache_request_kv_head_o,
    input  wire                    private_cache_response_valid_i,
    output logic                   private_cache_response_ready_o,
    input  wire [1023:0]           private_cache_response_key_vector_i,
    input  wire signed [7:0]       private_cache_response_key_exponent_i,
    input  wire [1023:0]           private_cache_response_value_vector_i,
    input  wire signed [7:0]       private_cache_response_value_exponent_i,
    input  wire                    private_cache_response_fault_i,

    // Four output beats, again in immutable query-head order.
    output logic                   result_valid_o,
    input  wire                    result_ready_i,
    output logic [1023:0]          result_vector_o,
    output logic signed [7:0]      result_exponent_o,
    output logic                   result_last_o,
    output logic                   done_valid_o,
    input  wire                    done_ready_i,
    output logic                   busy_o,
    output logic                   range_fault_o
);
reg active=0;reg[2:0]state=0;reg[2:0]queries=0;reg last_query=0;reg[10:0]position=0;
always @(posedge clk) begin
 if(!rst_n || clear_i) begin active<=0;state<=0;queries<=0;last_query<=0;position<=0;end
 else if(start_valid_i && start_ready_o) begin active<=1;state<=0;queries<=0;position<=fixed_position_i;end
 else if(active) begin
  if(query_valid_i && query_ready_o) begin last_query<=query_last_i;state<=1;end
  if(private_cache_request_valid_o && private_cache_request_ready_i) state<=2;
  if(private_cache_response_valid_i && private_cache_response_ready_o) begin
   if(private_cache_response_fault_i) $fatal(1,"witness attention received a cache fault");
   state<=3;
  end
  if(result_valid_o && result_ready_i) begin queries<=queries+1'b1;state<=last_query?4:0;end
  if(done_valid_o && done_ready_i) begin active<=0;state<=0;end
 end
end
assign start_ready_o=!active;
assign query_ready_o=active && state==0;
assign private_cache_request_valid_o=active && state==1;
assign private_cache_request_kind_o=2'b00;
assign private_cache_request_position_o=position==0?11'd0:position-11'd1;
assign private_cache_request_kv_head_o=queries[1];
assign private_cache_response_ready_o=active && state==2;
assign result_valid_o=active && state==3;
assign result_vector_o='0;
assign result_exponent_o='0;
assign result_last_o=last_query;
assign done_valid_o=active && state==4;
assign busy_o=active;
assign range_fault_o='0;

endmodule

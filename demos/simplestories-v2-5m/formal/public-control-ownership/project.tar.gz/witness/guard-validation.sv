module unknown_guard_case;
reg clear,step_valid,step_ready,token_valid;
reg[2:0]phase;reg[4:0]shell;
reg[11:0]value;integer pattern,bit_index,known_count=0,x_count=0,z_count=0;
task check(input[11:0]stimulus,input expected_bad);
begin
 {clear,step_valid,step_ready,token_valid,phase,shell}=stimulus;
 #1;
 if((((^{clear,step_valid,step_ready,token_valid,phase,shell})===1'bx))!==expected_bad)
  $fatal(1,"guard mismatch stimulus=%b expected_bad=%b",stimulus,expected_bad);
end endtask
initial begin
 for(pattern=0;pattern<4096;pattern=pattern+1)begin
  value=pattern;check(value,0);known_count=known_count+1;
  for(bit_index=0;bit_index<12;bit_index=bit_index+1)begin
   value=pattern;value[bit_index]=1'bx;check(value,1);x_count=x_count+1;
   value=pattern;value[bit_index]=1'bz;check(value,1);z_count=z_count+1;
  end
 end
 $display("GUARDPASS known=%0d X=%0d Z=%0d",known_count,x_count,z_count);$finish;
end
endmodule

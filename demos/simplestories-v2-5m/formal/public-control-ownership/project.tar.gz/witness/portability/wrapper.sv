module public_command_refinement(
    input wire core_clk_i,reset_n_i,uart_rx_i,
    input wire append_ready,step_ready,token_valid,
    input wire[11:0]token,
    output wire uart_tx_o,clear,append_valid,step_valid,token_ready,
    output wire[11:0]append_token
);
    wire[7:0]f_reply_crc,f_reference_reply_crc;
    wire cmd_valid,cmd_ready,result_valid,result_ready,decoded_clear;
    wire[1:0]cmd;wire[11:0]command_token,result_token;
    wire f_rx_event;
    wire [7:0] f_rx_data;
    wire f_tx_accept;
    wire f_send_byte;
    wire [7:0] f_send_data;
    wire [2:0] f_phase;
    wire [2:0] f_received;
    wire [7:0] f_crc;
    wire [7:0] f_opcode;
    wire [7:0] f_low;
    wire [7:0] f_high;
    wire [1:0] f_operation;
    wire [11:0] f_token;
    wire [7:0] f_reply_kind;
    wire [11:0] f_reply_token;
    wire [2:0] f_sent;
    wire f_cancel_pending;
    wire f_recovery;
    wire[7:0] f_prefix_one;
    wire[7:0] f_prefix_two;
    wire[7:0] f_prefix_three;
    wire[7:0] f_packet_crc;
    token_only_model0_uart_bridge #(.CLKS_PER_BIT(217)) u_fixed_uart (
        .clk(core_clk_i),.rst_n(reset_n_i),.uart_rx_i(uart_rx_i),.uart_tx_o(uart_tx_o),
        .clear_command_o(clear),.cmd_valid_o(cmd_valid),.cmd_ready_i(cmd_ready),.cmd_o(cmd),.in_token_o(command_token),
        .out_valid_i(result_valid),.out_ready_o(result_ready),.out_token_i(result_token),
        .f_rx_event(f_rx_event),
        .f_rx_data(f_rx_data),
        .f_tx_accept(f_tx_accept),
        .f_send_byte(f_send_byte),
        .f_send_data(f_send_data),
        .f_phase(f_phase),
        .f_received(f_received),
        .f_crc(f_crc),
        .f_opcode(f_opcode),
        .f_low(f_low),
        .f_high(f_high),
        .f_operation(f_operation),
        .f_token(f_token),
        .f_reply_kind(f_reply_kind),
        .f_reply_token(f_reply_token),
        .f_sent(f_sent),
        .f_cancel_pending(f_cancel_pending),
        .f_recovery(f_recovery)
    ,
        .f_reply_crc(f_reply_crc)
    );
    board1_fixed_command_adapter u_three_operations (
        .cmd_valid_i(cmd_valid),.cmd_ready_o(cmd_ready),.cmd_i(cmd),.cmd_token_i(command_token),
        .clear_o(decoded_clear),.append_valid_o(append_valid),.append_ready_i(append_ready),.append_token_o(append_token),
        .step_valid_o(step_valid),.step_ready_i(step_ready),.token_valid_i(token_valid),
        .token_ready_o(token_ready),.token_i(token),.result_valid_o(result_valid),
        .result_ready_i(result_ready),.result_token_o(result_token));

    wire r_append,r_step,r_clear,r_ready,r_send,r_cancel;
    wire[11:0]r_append_token,r_offered_token,r_reply_token;
    wire[7:0]r_data,r_opcode,r_low,r_high,r_reply_kind;
    wire[2:0]r_phase,r_received,r_sent;
    wire[1:0]r_operation;
    public_command_reference u_reference (
        .clk(core_clk_i),.reset_n(reset_n_i),.rx_event(f_rx_event),.rx_data(f_rx_data),
        .tx_accept(f_tx_accept),.append_ready(append_ready),.step_ready(step_ready),
        .result_valid(token_valid),.result_token(token),
        .append_offer(r_append),.step_offer(r_step),.clear_level(r_clear),.result_ready(r_ready),
        .append_token(r_append_token),.send_byte(r_send),.send_data(r_data),
        .phase(r_phase),.received(r_received),.sent(r_sent),
        .frame_opcode(r_opcode),.frame_low(r_low),.frame_high(r_high),
        .reply_kind(r_reply_kind),.offered_operation(r_operation),.offered_token(r_offered_token),
        .reply_token(r_reply_token),.cancel_pending(r_cancel),
        .f_prefix_one(f_prefix_one),
        .f_prefix_two(f_prefix_two),
        .f_prefix_three(f_prefix_three),
        .f_packet_crc(f_packet_crc)
    ,
        .f_reference_reply_crc(f_reference_reply_crc)
    );

    always @*begin
        assert(f_phase<=4);
        assert((f_phase==0)==(r_phase==1));
        assert((f_phase==1)==(r_phase==2));
        assert((f_phase==2)==(r_phase==3));
        assert((f_phase==3)==(r_phase==4));
        assert((f_phase==4)==(r_phase==5));
        assert(f_received==r_received);
        assert(f_received<=4);
        assert(f_opcode==r_opcode);
        assert(f_low==r_low);
        assert(f_high==r_high);
        assert(f_operation==r_operation);
        assert(f_token==r_offered_token);
        assert(f_reply_kind==r_reply_kind);
        assert(f_reply_token==r_reply_token);
        assert(f_sent==r_sent);
        assert(f_sent<=4);
        assert(f_cancel_pending==r_cancel);
        assert(!f_recovery);
        if(f_cancel_pending)assert(f_phase==2);
        if(f_phase==1)assert(f_operation<=2);
        if(f_received==1)assert(f_crc==f_prefix_one);
        if(f_received==2)assert(f_crc==f_prefix_two);
        if(f_received==3)assert(f_crc==f_prefix_three);
        if(f_received==4)assert(f_crc==f_packet_crc);
        assert(append_valid==r_append);
        assert(step_valid==r_step);
        assert(clear==r_clear);
        assert(token_ready==r_ready);
        assert(append_token==r_append_token);
        assert(f_send_byte==r_send);
        if(r_send)assert(f_send_data==r_data);
    end


    // The implementation caches CRC on the first transmit cycle; the
    // specification computes it from the complete reply value.
    always @*if(f_sent!=0)assert(f_reply_crc==f_reference_reply_crc);

endmodule

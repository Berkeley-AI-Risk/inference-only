module public_control_case;
integer observed_reset_low_edges=0,observed_reset_releases=0;
reg [11:0] wanted_token=23;reg cancel_old=1;
wire release_winner;
reg core_clk_i;
reg reset_n_i;
reg uart_rx_i;
wire uart_tx_o;
reg model_locked_i;
reg upstream_fail_closed_i;
wire private_runtime_req_valid_o;
reg private_runtime_req_ready_i;
wire [19-1:0]      private_runtime_req_word_index_o;
reg private_runtime_rsp_valid_i;
wire private_runtime_rsp_ready_o;
reg [255:0]            private_runtime_rsp_data_i;
reg private_runtime_rsp_fault_i;
wire kv_write_req_valid_o;
reg kv_write_req_ready_i;
wire [2:0]             kv_write_req_layer_o;
wire [11:0]            kv_write_req_position_o;
wire [1:0]             kv_write_req_head_o;
wire [3:0]             kv_write_req_row_word_o;
wire [18:0]            kv_write_req_shadow_address_o;
wire [255:0]           kv_write_req_data_o;
reg kv_write_cpl_valid_i;
wire kv_write_cpl_ready_o;
reg kv_write_cpl_fault_i;
wire kv_read_req_valid_o;
reg kv_read_req_ready_i;
wire [2:0]             kv_read_req_layer_o;
wire [11:0]            kv_read_req_position_o;
wire [1:0]             kv_read_req_head_o;
wire [3:0]             kv_read_req_row_word_o;
wire [18:0]            kv_read_req_shadow_address_o;
reg kv_read_rsp_valid_i;
wire kv_read_rsp_ready_o;
reg [255:0]            kv_read_rsp_data_i;
reg kv_read_rsp_fault_i;
reg kv_endpoint_fault_i;
wire busy_o;
wire model_locked_o;
wire fail_closed_o;
wire f_shell_f_child_u_fixed_embedding_start_ready_o;
wire f_shell_f_child_u_fixed_embedding_private_word_req_valid_o;
wire [19-1:0]       f_shell_f_child_u_fixed_embedding_private_word_req_index_o;
wire f_shell_f_child_u_fixed_embedding_private_word_rsp_ready_o;
wire f_shell_f_child_u_fixed_embedding_result_valid_o;
wire [7:0]             f_shell_f_child_u_fixed_embedding_result_index_o;
wire signed [15:0]     f_shell_f_child_u_fixed_embedding_result_mantissa_o;
wire signed [7:0]      f_shell_f_child_u_fixed_embedding_result_exponent_o;
wire f_shell_f_child_u_fixed_embedding_result_last_o;
wire f_shell_f_child_u_fixed_embedding_done_valid_o;
wire f_shell_f_child_u_fixed_embedding_busy_o;
wire f_shell_f_child_u_fixed_embedding_fail_closed_o;
wire f_shell_f_child_u_final_rmsnorm_start_ready_o;
wire f_shell_f_child_u_final_rmsnorm_input_ready_o;
wire f_shell_f_child_u_final_rmsnorm_result_valid_o;
wire [7:0]             f_shell_f_child_u_final_rmsnorm_result_row_index_o;
wire signed [15:0]     f_shell_f_child_u_final_rmsnorm_result_mantissa_o;
wire signed [7:0]      f_shell_f_child_u_final_rmsnorm_result_exponent_o;
wire f_shell_f_child_u_final_rmsnorm_result_last_o;
wire f_shell_f_child_u_final_rmsnorm_done_valid_o;
wire f_shell_f_child_u_final_rmsnorm_busy_o;
wire f_shell_f_child_u_final_rmsnorm_range_fault_o;
wire f_shell_f_child_u_exact_argmax_start_ready_o;
wire f_shell_f_child_u_exact_argmax_row_ready_o;
wire f_shell_f_child_u_exact_argmax_winner_valid_o;
wire [11:0]            f_shell_f_child_u_exact_argmax_winner_token_id_o;
wire signed [49:0]     f_shell_f_child_u_exact_argmax_winner_scaled_raw_o;
wire signed [7:0]      f_shell_f_child_u_exact_argmax_winner_source_exponent_o;
wire f_shell_f_child_u_exact_argmax_busy_o;
wire f_shell_f_child_u_exact_argmax_fail_closed_o;
wire signed [15:0]     f_dp_f_child_u_gate_scratch_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_up_scratch_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_attention_scratch_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_rms_scratch_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_output_scratch_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_hidden_state_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_query_state_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_key_state_private_read_data_o;
wire signed [15:0]     f_dp_f_child_u_value_state_private_read_data_o;
wire signed [49:0]     f_dp_f_child_u_rope_raw_scratch_private_read_data_o;
wire f_dp_f_child_u_rmsnorm_start_ready_o;
wire f_dp_f_child_u_rmsnorm_input_ready_o;
wire f_dp_f_child_u_rmsnorm_result_valid_o;
wire [7:0]             f_dp_f_child_u_rmsnorm_result_row_index_o;
wire signed [15:0]     f_dp_f_child_u_rmsnorm_result_mantissa_o;
wire signed [7:0]      f_dp_f_child_u_rmsnorm_result_exponent_o;
wire f_dp_f_child_u_rmsnorm_result_last_o;
wire f_dp_f_child_u_rmsnorm_done_valid_o;
wire f_dp_f_child_u_rmsnorm_busy_o;
wire f_dp_f_child_u_rmsnorm_range_fault_o;
wire f_dp_f_child_u_projection_start_ready_o;
wire f_dp_f_child_u_projection_activation_ready_o;
wire f_dp_f_child_u_projection_private_word_req_valid_o;
wire [19-1:0]        f_dp_f_child_u_projection_private_word_req_index_o;
wire f_dp_f_child_u_projection_private_word_rsp_ready_o;
wire f_dp_f_child_u_projection_result_valid_o;
wire [12:0]             f_dp_f_child_u_projection_result_row_index_o;
wire signed [49:0]      f_dp_f_child_u_projection_result_scaled_raw_o;
wire signed [7:0]       f_dp_f_child_u_projection_result_source_exponent_o;
wire f_dp_f_child_u_projection_result_last_o;
wire f_dp_f_child_u_projection_done_valid_o;
wire f_dp_f_child_u_projection_busy_o;
wire f_dp_f_child_u_projection_fail_closed_o;
wire f_dp_f_child_u_normalizer_start_ready_o;
wire f_dp_f_child_u_normalizer_input_ready_o;
wire f_dp_f_child_u_normalizer_result_valid_o;
wire [9:0]             f_dp_f_child_u_normalizer_result_row_index_o;
wire signed [15:0]     f_dp_f_child_u_normalizer_result_mantissa_o;
wire signed [7:0]      f_dp_f_child_u_normalizer_result_exponent_o;
wire f_dp_f_child_u_normalizer_result_last_o;
wire f_dp_f_child_u_normalizer_done_valid_o;
wire f_dp_f_child_u_normalizer_busy_o;
wire f_dp_f_child_u_normalizer_range_fault_o;
wire f_dp_f_child_u_elementwise_lane_request_ready_o;
wire f_dp_f_child_u_elementwise_lane_lut_request_o;
wire [15:0]             f_dp_f_child_u_elementwise_lane_lut_index_o;
wire f_dp_f_child_u_elementwise_lane_result_valid_o;
wire signed [15:0]      f_dp_f_child_u_elementwise_lane_result0_o;
wire signed [15:0]      f_dp_f_child_u_elementwise_lane_result1_o;
wire signed [15:0]      f_dp_f_child_u_elementwise_lane_auxiliary_o;
wire signed [49:0]      f_dp_f_child_u_elementwise_lane_raw0_o;
wire signed [49:0]      f_dp_f_child_u_elementwise_lane_raw1_o;
wire signed [7:0]       f_dp_f_child_u_elementwise_lane_source_exponent_o;
wire f_dp_f_child_u_elementwise_lane_range_fault_o;
wire f_dp_f_child_u_lookup_request_ready_o;
wire f_dp_f_child_u_lookup_response_valid_o;
wire signed [15:0]     f_dp_f_child_u_lookup_response_value_o;
wire f_dp_f_child_u_lookup_response_fault_o;
wire f_dp_f_child_u_lookup_private_word_req_valid_o;
wire [19-1:0]      f_dp_f_child_u_lookup_private_word_req_index_o;
wire f_dp_f_child_u_lookup_private_word_rsp_ready_o;
wire f_dp_f_child_u_lookup_busy_o;
wire f_dp_f_child_u_lookup_fail_closed_o;
wire f_dp_f_child_u_kv_cache_stage_begin_ready_o;
wire f_dp_f_child_u_kv_cache_stage_payload_ready_o;
wire f_dp_f_child_u_kv_cache_pending_complete_o;
wire f_dp_f_child_u_kv_cache_commit_ready_o;
wire f_dp_f_child_u_kv_cache_attention_req_ready_o;
wire f_dp_f_child_u_kv_cache_attention_rsp_valid_o;
wire [1023:0]           f_dp_f_child_u_kv_cache_attention_rsp_key_vector_o;
wire signed [7:0]       f_dp_f_child_u_kv_cache_attention_rsp_key_exponent_o;
wire [1023:0]           f_dp_f_child_u_kv_cache_attention_rsp_value_vector_o;
wire signed [7:0]       f_dp_f_child_u_kv_cache_attention_rsp_value_exponent_o;
wire f_dp_f_child_u_kv_cache_attention_rsp_fault_o;
wire f_dp_f_child_u_kv_cache_attention_rsp_from_pending_o;
wire f_dp_f_child_u_kv_cache_kv_write_req_valid_o;
wire [2:0]              f_dp_f_child_u_kv_cache_kv_write_req_layer_o;
wire [11:0]             f_dp_f_child_u_kv_cache_kv_write_req_position_o;
wire [1:0]              f_dp_f_child_u_kv_cache_kv_write_req_head_o;
wire [3:0]              f_dp_f_child_u_kv_cache_kv_write_req_row_word_o;
wire [18:0]             f_dp_f_child_u_kv_cache_kv_write_req_shadow_address_o;
wire [255:0]            f_dp_f_child_u_kv_cache_kv_write_req_data_o;
wire f_dp_f_child_u_kv_cache_kv_write_cpl_ready_o;
wire f_dp_f_child_u_kv_cache_kv_read_req_valid_o;
wire [2:0]              f_dp_f_child_u_kv_cache_kv_read_req_layer_o;
wire [11:0]             f_dp_f_child_u_kv_cache_kv_read_req_position_o;
wire [1:0]              f_dp_f_child_u_kv_cache_kv_read_req_head_o;
wire [3:0]              f_dp_f_child_u_kv_cache_kv_read_req_row_word_o;
wire [18:0]             f_dp_f_child_u_kv_cache_kv_read_req_shadow_address_o;
wire f_dp_f_child_u_kv_cache_kv_read_rsp_ready_o;
wire [71:0]             f_dp_f_child_u_kv_cache_committed_prefixes_o;
wire f_dp_f_child_u_kv_cache_busy_o;
wire f_dp_f_child_u_kv_cache_fail_closed_o;
wire f_dp_f_child_u_attention_start_ready_o;
wire f_dp_f_child_u_attention_query_ready_o;
wire f_dp_f_child_u_attention_private_cache_request_valid_o;
wire [1:0]             f_dp_f_child_u_attention_private_cache_request_kind_o;
wire [10:0]            f_dp_f_child_u_attention_private_cache_request_position_o;
wire f_dp_f_child_u_attention_private_cache_request_kv_head_o;
wire f_dp_f_child_u_attention_private_cache_response_ready_o;
wire f_dp_f_child_u_attention_result_valid_o;
wire [1023:0]          f_dp_f_child_u_attention_result_vector_o;
wire signed [7:0]      f_dp_f_child_u_attention_result_exponent_o;
wire f_dp_f_child_u_attention_result_last_o;
wire f_dp_f_child_u_attention_done_valid_o;
wire f_dp_f_child_u_attention_busy_o;
wire f_dp_f_child_u_attention_range_fault_o;
reg [11:0] f_pc_tape_index_i;
wire [11:0] f_pc_tape_value_o;
public_control_whole dut(.core_clk_i(core_clk_i),.reset_n_i(reset_n_i),.uart_rx_i(uart_rx_i),.uart_tx_o(uart_tx_o),.model_locked_i(model_locked_i),.upstream_fail_closed_i(upstream_fail_closed_i),.private_runtime_req_valid_o(private_runtime_req_valid_o),.private_runtime_req_ready_i(private_runtime_req_ready_i),.private_runtime_req_word_index_o(private_runtime_req_word_index_o),.private_runtime_rsp_valid_i(private_runtime_rsp_valid_i),.private_runtime_rsp_ready_o(private_runtime_rsp_ready_o),.private_runtime_rsp_data_i(private_runtime_rsp_data_i),.private_runtime_rsp_fault_i(private_runtime_rsp_fault_i),.kv_write_req_valid_o(kv_write_req_valid_o),.kv_write_req_ready_i(kv_write_req_ready_i),.kv_write_req_layer_o(kv_write_req_layer_o),.kv_write_req_position_o(kv_write_req_position_o),.kv_write_req_head_o(kv_write_req_head_o),.kv_write_req_row_word_o(kv_write_req_row_word_o),.kv_write_req_shadow_address_o(kv_write_req_shadow_address_o),.kv_write_req_data_o(kv_write_req_data_o),.kv_write_cpl_valid_i(kv_write_cpl_valid_i),.kv_write_cpl_ready_o(kv_write_cpl_ready_o),.kv_write_cpl_fault_i(kv_write_cpl_fault_i),.kv_read_req_valid_o(kv_read_req_valid_o),.kv_read_req_ready_i(kv_read_req_ready_i),.kv_read_req_layer_o(kv_read_req_layer_o),.kv_read_req_position_o(kv_read_req_position_o),.kv_read_req_head_o(kv_read_req_head_o),.kv_read_req_row_word_o(kv_read_req_row_word_o),.kv_read_req_shadow_address_o(kv_read_req_shadow_address_o),.kv_read_rsp_valid_i(kv_read_rsp_valid_i),.kv_read_rsp_ready_o(kv_read_rsp_ready_o),.kv_read_rsp_data_i(kv_read_rsp_data_i),.kv_read_rsp_fault_i(kv_read_rsp_fault_i),.kv_endpoint_fault_i(kv_endpoint_fault_i),.busy_o(busy_o),.model_locked_o(model_locked_o),.fail_closed_o(fail_closed_o),.f_shell_f_child_u_fixed_embedding_start_ready_o(f_shell_f_child_u_fixed_embedding_start_ready_o),.f_shell_f_child_u_fixed_embedding_private_word_req_valid_o(f_shell_f_child_u_fixed_embedding_private_word_req_valid_o),.f_shell_f_child_u_fixed_embedding_private_word_req_index_o(f_shell_f_child_u_fixed_embedding_private_word_req_index_o),.f_shell_f_child_u_fixed_embedding_private_word_rsp_ready_o(f_shell_f_child_u_fixed_embedding_private_word_rsp_ready_o),.f_shell_f_child_u_fixed_embedding_result_valid_o(f_shell_f_child_u_fixed_embedding_result_valid_o),.f_shell_f_child_u_fixed_embedding_result_index_o(f_shell_f_child_u_fixed_embedding_result_index_o),.f_shell_f_child_u_fixed_embedding_result_mantissa_o(f_shell_f_child_u_fixed_embedding_result_mantissa_o),.f_shell_f_child_u_fixed_embedding_result_exponent_o(f_shell_f_child_u_fixed_embedding_result_exponent_o),.f_shell_f_child_u_fixed_embedding_result_last_o(f_shell_f_child_u_fixed_embedding_result_last_o),.f_shell_f_child_u_fixed_embedding_done_valid_o(f_shell_f_child_u_fixed_embedding_done_valid_o),.f_shell_f_child_u_fixed_embedding_busy_o(f_shell_f_child_u_fixed_embedding_busy_o),.f_shell_f_child_u_fixed_embedding_fail_closed_o(f_shell_f_child_u_fixed_embedding_fail_closed_o),.f_shell_f_child_u_final_rmsnorm_start_ready_o(f_shell_f_child_u_final_rmsnorm_start_ready_o),.f_shell_f_child_u_final_rmsnorm_input_ready_o(f_shell_f_child_u_final_rmsnorm_input_ready_o),.f_shell_f_child_u_final_rmsnorm_result_valid_o(f_shell_f_child_u_final_rmsnorm_result_valid_o),.f_shell_f_child_u_final_rmsnorm_result_row_index_o(f_shell_f_child_u_final_rmsnorm_result_row_index_o),.f_shell_f_child_u_final_rmsnorm_result_mantissa_o(f_shell_f_child_u_final_rmsnorm_result_mantissa_o),.f_shell_f_child_u_final_rmsnorm_result_exponent_o(f_shell_f_child_u_final_rmsnorm_result_exponent_o),.f_shell_f_child_u_final_rmsnorm_result_last_o(f_shell_f_child_u_final_rmsnorm_result_last_o),.f_shell_f_child_u_final_rmsnorm_done_valid_o(f_shell_f_child_u_final_rmsnorm_done_valid_o),.f_shell_f_child_u_final_rmsnorm_busy_o(f_shell_f_child_u_final_rmsnorm_busy_o),.f_shell_f_child_u_final_rmsnorm_range_fault_o(f_shell_f_child_u_final_rmsnorm_range_fault_o),.f_shell_f_child_u_exact_argmax_start_ready_o(f_shell_f_child_u_exact_argmax_start_ready_o),.f_shell_f_child_u_exact_argmax_row_ready_o(f_shell_f_child_u_exact_argmax_row_ready_o),.f_shell_f_child_u_exact_argmax_winner_valid_o(f_shell_f_child_u_exact_argmax_winner_valid_o),.f_shell_f_child_u_exact_argmax_winner_token_id_o(f_shell_f_child_u_exact_argmax_winner_token_id_o),.f_shell_f_child_u_exact_argmax_winner_scaled_raw_o(f_shell_f_child_u_exact_argmax_winner_scaled_raw_o),.f_shell_f_child_u_exact_argmax_winner_source_exponent_o(f_shell_f_child_u_exact_argmax_winner_source_exponent_o),.f_shell_f_child_u_exact_argmax_busy_o(f_shell_f_child_u_exact_argmax_busy_o),.f_shell_f_child_u_exact_argmax_fail_closed_o(f_shell_f_child_u_exact_argmax_fail_closed_o),.f_dp_f_child_u_gate_scratch_private_read_data_o(f_dp_f_child_u_gate_scratch_private_read_data_o),.f_dp_f_child_u_up_scratch_private_read_data_o(f_dp_f_child_u_up_scratch_private_read_data_o),.f_dp_f_child_u_attention_scratch_private_read_data_o(f_dp_f_child_u_attention_scratch_private_read_data_o),.f_dp_f_child_u_rms_scratch_private_read_data_o(f_dp_f_child_u_rms_scratch_private_read_data_o),.f_dp_f_child_u_output_scratch_private_read_data_o(f_dp_f_child_u_output_scratch_private_read_data_o),.f_dp_f_child_u_hidden_state_private_read_data_o(f_dp_f_child_u_hidden_state_private_read_data_o),.f_dp_f_child_u_query_state_private_read_data_o(f_dp_f_child_u_query_state_private_read_data_o),.f_dp_f_child_u_key_state_private_read_data_o(f_dp_f_child_u_key_state_private_read_data_o),.f_dp_f_child_u_value_state_private_read_data_o(f_dp_f_child_u_value_state_private_read_data_o),.f_dp_f_child_u_rope_raw_scratch_private_read_data_o(f_dp_f_child_u_rope_raw_scratch_private_read_data_o),.f_dp_f_child_u_rmsnorm_start_ready_o(f_dp_f_child_u_rmsnorm_start_ready_o),.f_dp_f_child_u_rmsnorm_input_ready_o(f_dp_f_child_u_rmsnorm_input_ready_o),.f_dp_f_child_u_rmsnorm_result_valid_o(f_dp_f_child_u_rmsnorm_result_valid_o),.f_dp_f_child_u_rmsnorm_result_row_index_o(f_dp_f_child_u_rmsnorm_result_row_index_o),.f_dp_f_child_u_rmsnorm_result_mantissa_o(f_dp_f_child_u_rmsnorm_result_mantissa_o),.f_dp_f_child_u_rmsnorm_result_exponent_o(f_dp_f_child_u_rmsnorm_result_exponent_o),.f_dp_f_child_u_rmsnorm_result_last_o(f_dp_f_child_u_rmsnorm_result_last_o),.f_dp_f_child_u_rmsnorm_done_valid_o(f_dp_f_child_u_rmsnorm_done_valid_o),.f_dp_f_child_u_rmsnorm_busy_o(f_dp_f_child_u_rmsnorm_busy_o),.f_dp_f_child_u_rmsnorm_range_fault_o(f_dp_f_child_u_rmsnorm_range_fault_o),.f_dp_f_child_u_projection_start_ready_o(f_dp_f_child_u_projection_start_ready_o),.f_dp_f_child_u_projection_activation_ready_o(f_dp_f_child_u_projection_activation_ready_o),.f_dp_f_child_u_projection_private_word_req_valid_o(f_dp_f_child_u_projection_private_word_req_valid_o),.f_dp_f_child_u_projection_private_word_req_index_o(f_dp_f_child_u_projection_private_word_req_index_o),.f_dp_f_child_u_projection_private_word_rsp_ready_o(f_dp_f_child_u_projection_private_word_rsp_ready_o),.f_dp_f_child_u_projection_result_valid_o(f_dp_f_child_u_projection_result_valid_o),.f_dp_f_child_u_projection_result_row_index_o(f_dp_f_child_u_projection_result_row_index_o),.f_dp_f_child_u_projection_result_scaled_raw_o(f_dp_f_child_u_projection_result_scaled_raw_o),.f_dp_f_child_u_projection_result_source_exponent_o(f_dp_f_child_u_projection_result_source_exponent_o),.f_dp_f_child_u_projection_result_last_o(f_dp_f_child_u_projection_result_last_o),.f_dp_f_child_u_projection_done_valid_o(f_dp_f_child_u_projection_done_valid_o),.f_dp_f_child_u_projection_busy_o(f_dp_f_child_u_projection_busy_o),.f_dp_f_child_u_projection_fail_closed_o(f_dp_f_child_u_projection_fail_closed_o),.f_dp_f_child_u_normalizer_start_ready_o(f_dp_f_child_u_normalizer_start_ready_o),.f_dp_f_child_u_normalizer_input_ready_o(f_dp_f_child_u_normalizer_input_ready_o),.f_dp_f_child_u_normalizer_result_valid_o(f_dp_f_child_u_normalizer_result_valid_o),.f_dp_f_child_u_normalizer_result_row_index_o(f_dp_f_child_u_normalizer_result_row_index_o),.f_dp_f_child_u_normalizer_result_mantissa_o(f_dp_f_child_u_normalizer_result_mantissa_o),.f_dp_f_child_u_normalizer_result_exponent_o(f_dp_f_child_u_normalizer_result_exponent_o),.f_dp_f_child_u_normalizer_result_last_o(f_dp_f_child_u_normalizer_result_last_o),.f_dp_f_child_u_normalizer_done_valid_o(f_dp_f_child_u_normalizer_done_valid_o),.f_dp_f_child_u_normalizer_busy_o(f_dp_f_child_u_normalizer_busy_o),.f_dp_f_child_u_normalizer_range_fault_o(f_dp_f_child_u_normalizer_range_fault_o),.f_dp_f_child_u_elementwise_lane_request_ready_o(f_dp_f_child_u_elementwise_lane_request_ready_o),.f_dp_f_child_u_elementwise_lane_lut_request_o(f_dp_f_child_u_elementwise_lane_lut_request_o),.f_dp_f_child_u_elementwise_lane_lut_index_o(f_dp_f_child_u_elementwise_lane_lut_index_o),.f_dp_f_child_u_elementwise_lane_result_valid_o(f_dp_f_child_u_elementwise_lane_result_valid_o),.f_dp_f_child_u_elementwise_lane_result0_o(f_dp_f_child_u_elementwise_lane_result0_o),.f_dp_f_child_u_elementwise_lane_result1_o(f_dp_f_child_u_elementwise_lane_result1_o),.f_dp_f_child_u_elementwise_lane_auxiliary_o(f_dp_f_child_u_elementwise_lane_auxiliary_o),.f_dp_f_child_u_elementwise_lane_raw0_o(f_dp_f_child_u_elementwise_lane_raw0_o),.f_dp_f_child_u_elementwise_lane_raw1_o(f_dp_f_child_u_elementwise_lane_raw1_o),.f_dp_f_child_u_elementwise_lane_source_exponent_o(f_dp_f_child_u_elementwise_lane_source_exponent_o),.f_dp_f_child_u_elementwise_lane_range_fault_o(f_dp_f_child_u_elementwise_lane_range_fault_o),.f_dp_f_child_u_lookup_request_ready_o(f_dp_f_child_u_lookup_request_ready_o),.f_dp_f_child_u_lookup_response_valid_o(f_dp_f_child_u_lookup_response_valid_o),.f_dp_f_child_u_lookup_response_value_o(f_dp_f_child_u_lookup_response_value_o),.f_dp_f_child_u_lookup_response_fault_o(f_dp_f_child_u_lookup_response_fault_o),.f_dp_f_child_u_lookup_private_word_req_valid_o(f_dp_f_child_u_lookup_private_word_req_valid_o),.f_dp_f_child_u_lookup_private_word_req_index_o(f_dp_f_child_u_lookup_private_word_req_index_o),.f_dp_f_child_u_lookup_private_word_rsp_ready_o(f_dp_f_child_u_lookup_private_word_rsp_ready_o),.f_dp_f_child_u_lookup_busy_o(f_dp_f_child_u_lookup_busy_o),.f_dp_f_child_u_lookup_fail_closed_o(f_dp_f_child_u_lookup_fail_closed_o),.f_dp_f_child_u_kv_cache_stage_begin_ready_o(f_dp_f_child_u_kv_cache_stage_begin_ready_o),.f_dp_f_child_u_kv_cache_stage_payload_ready_o(f_dp_f_child_u_kv_cache_stage_payload_ready_o),.f_dp_f_child_u_kv_cache_pending_complete_o(f_dp_f_child_u_kv_cache_pending_complete_o),.f_dp_f_child_u_kv_cache_commit_ready_o(f_dp_f_child_u_kv_cache_commit_ready_o),.f_dp_f_child_u_kv_cache_attention_req_ready_o(f_dp_f_child_u_kv_cache_attention_req_ready_o),.f_dp_f_child_u_kv_cache_attention_rsp_valid_o(f_dp_f_child_u_kv_cache_attention_rsp_valid_o),.f_dp_f_child_u_kv_cache_attention_rsp_key_vector_o(f_dp_f_child_u_kv_cache_attention_rsp_key_vector_o),.f_dp_f_child_u_kv_cache_attention_rsp_key_exponent_o(f_dp_f_child_u_kv_cache_attention_rsp_key_exponent_o),.f_dp_f_child_u_kv_cache_attention_rsp_value_vector_o(f_dp_f_child_u_kv_cache_attention_rsp_value_vector_o),.f_dp_f_child_u_kv_cache_attention_rsp_value_exponent_o(f_dp_f_child_u_kv_cache_attention_rsp_value_exponent_o),.f_dp_f_child_u_kv_cache_attention_rsp_fault_o(f_dp_f_child_u_kv_cache_attention_rsp_fault_o),.f_dp_f_child_u_kv_cache_attention_rsp_from_pending_o(f_dp_f_child_u_kv_cache_attention_rsp_from_pending_o),.f_dp_f_child_u_kv_cache_kv_write_req_valid_o(f_dp_f_child_u_kv_cache_kv_write_req_valid_o),.f_dp_f_child_u_kv_cache_kv_write_req_layer_o(f_dp_f_child_u_kv_cache_kv_write_req_layer_o),.f_dp_f_child_u_kv_cache_kv_write_req_position_o(f_dp_f_child_u_kv_cache_kv_write_req_position_o),.f_dp_f_child_u_kv_cache_kv_write_req_head_o(f_dp_f_child_u_kv_cache_kv_write_req_head_o),.f_dp_f_child_u_kv_cache_kv_write_req_row_word_o(f_dp_f_child_u_kv_cache_kv_write_req_row_word_o),.f_dp_f_child_u_kv_cache_kv_write_req_shadow_address_o(f_dp_f_child_u_kv_cache_kv_write_req_shadow_address_o),.f_dp_f_child_u_kv_cache_kv_write_req_data_o(f_dp_f_child_u_kv_cache_kv_write_req_data_o),.f_dp_f_child_u_kv_cache_kv_write_cpl_ready_o(f_dp_f_child_u_kv_cache_kv_write_cpl_ready_o),.f_dp_f_child_u_kv_cache_kv_read_req_valid_o(f_dp_f_child_u_kv_cache_kv_read_req_valid_o),.f_dp_f_child_u_kv_cache_kv_read_req_layer_o(f_dp_f_child_u_kv_cache_kv_read_req_layer_o),.f_dp_f_child_u_kv_cache_kv_read_req_position_o(f_dp_f_child_u_kv_cache_kv_read_req_position_o),.f_dp_f_child_u_kv_cache_kv_read_req_head_o(f_dp_f_child_u_kv_cache_kv_read_req_head_o),.f_dp_f_child_u_kv_cache_kv_read_req_row_word_o(f_dp_f_child_u_kv_cache_kv_read_req_row_word_o),.f_dp_f_child_u_kv_cache_kv_read_req_shadow_address_o(f_dp_f_child_u_kv_cache_kv_read_req_shadow_address_o),.f_dp_f_child_u_kv_cache_kv_read_rsp_ready_o(f_dp_f_child_u_kv_cache_kv_read_rsp_ready_o),.f_dp_f_child_u_kv_cache_committed_prefixes_o(f_dp_f_child_u_kv_cache_committed_prefixes_o),.f_dp_f_child_u_kv_cache_busy_o(f_dp_f_child_u_kv_cache_busy_o),.f_dp_f_child_u_kv_cache_fail_closed_o(f_dp_f_child_u_kv_cache_fail_closed_o),.f_dp_f_child_u_attention_start_ready_o(f_dp_f_child_u_attention_start_ready_o),.f_dp_f_child_u_attention_query_ready_o(f_dp_f_child_u_attention_query_ready_o),.f_dp_f_child_u_attention_private_cache_request_valid_o(f_dp_f_child_u_attention_private_cache_request_valid_o),.f_dp_f_child_u_attention_private_cache_request_kind_o(f_dp_f_child_u_attention_private_cache_request_kind_o),.f_dp_f_child_u_attention_private_cache_request_position_o(f_dp_f_child_u_attention_private_cache_request_position_o),.f_dp_f_child_u_attention_private_cache_request_kv_head_o(f_dp_f_child_u_attention_private_cache_request_kv_head_o),.f_dp_f_child_u_attention_private_cache_response_ready_o(f_dp_f_child_u_attention_private_cache_response_ready_o),.f_dp_f_child_u_attention_result_valid_o(f_dp_f_child_u_attention_result_valid_o),.f_dp_f_child_u_attention_result_vector_o(f_dp_f_child_u_attention_result_vector_o),.f_dp_f_child_u_attention_result_exponent_o(f_dp_f_child_u_attention_result_exponent_o),.f_dp_f_child_u_attention_result_last_o(f_dp_f_child_u_attention_result_last_o),.f_dp_f_child_u_attention_done_valid_o(f_dp_f_child_u_attention_done_valid_o),.f_dp_f_child_u_attention_busy_o(f_dp_f_child_u_attention_busy_o),.f_dp_f_child_u_attention_range_fault_o(f_dp_f_child_u_attention_range_fault_o),.f_pc_tape_index_i(f_pc_tape_index_i),.f_pc_tape_value_o(f_pc_tape_value_o));
witness_u_fixed_embedding p_u_fixed_embedding(.clk(dut.u_core.u_native.u_token_shell.clk),.rst_n(dut.u_core.u_native.u_token_shell.rst_n),.clear_i(dut.u_core.u_native.u_token_shell.clear_i),.model_lock_i(dut.u_core.u_native.u_token_shell.model_lock_i),.upstream_fault_i(dut.u_core.u_native.u_token_shell.upstream_fault_i),.start_valid_i(dut.u_core.u_native.u_token_shell.embed_start_valid),.start_ready_o(f_shell_f_child_u_fixed_embedding_start_ready_o),.fixed_token_i(dut.u_core.u_native.u_token_shell.tape_read_q),.private_word_req_valid_o(f_shell_f_child_u_fixed_embedding_private_word_req_valid_o),.private_word_req_ready_i(dut.u_core.u_native.u_token_shell.embed_req_ready),.private_word_req_index_o(f_shell_f_child_u_fixed_embedding_private_word_req_index_o),.private_word_rsp_valid_i(dut.u_core.u_native.u_token_shell.embed_rsp_valid),.private_word_rsp_ready_o(f_shell_f_child_u_fixed_embedding_private_word_rsp_ready_o),.private_word_rsp_data_i(dut.u_core.u_native.u_token_shell.private_word_rsp_data_i),.private_word_rsp_fault_i(dut.u_core.u_native.u_token_shell.private_word_rsp_fault_i),.result_valid_o(f_shell_f_child_u_fixed_embedding_result_valid_o),.result_ready_i(dut.u_core.u_native.u_token_shell.embed_result_ready),.result_index_o(f_shell_f_child_u_fixed_embedding_result_index_o),.result_mantissa_o(f_shell_f_child_u_fixed_embedding_result_mantissa_o),.result_exponent_o(f_shell_f_child_u_fixed_embedding_result_exponent_o),.result_last_o(f_shell_f_child_u_fixed_embedding_result_last_o),.done_valid_o(f_shell_f_child_u_fixed_embedding_done_valid_o),.done_ready_i(dut.u_core.u_native.u_token_shell.embed_done_ready),.busy_o(f_shell_f_child_u_fixed_embedding_busy_o),.fail_closed_o(f_shell_f_child_u_fixed_embedding_fail_closed_o));
witness_u_final_rmsnorm p_u_final_rmsnorm(.clk(dut.u_core.u_native.u_token_shell.clk),.rst_n(dut.u_core.u_native.u_token_shell.rst_n),.clear_i(dut.u_core.u_native.u_token_shell.clear_i),.model_lock_i(dut.u_core.u_native.u_token_shell.model_lock_i),.upstream_fault_i(dut.u_core.u_native.u_token_shell.upstream_fault_i),.start_valid_i(dut.u_core.u_native.u_token_shell.rms_start_valid),.start_ready_o(f_shell_f_child_u_final_rmsnorm_start_ready_o),.fixed_layer_i(3'd5),.fixed_norm_kind_i(2'd2),.input_exponent_i(dut.u_core.u_native.u_token_shell.layer5_exponent_q),.input_valid_i(dut.u_core.u_native.u_token_shell.rms_input_valid),.input_ready_o(f_shell_f_child_u_final_rmsnorm_input_ready_o),.input_row_index_i(dut.u_core.u_native.u_token_shell.stream_index_q),.input_mantissa_i(dut.u_core.u_native.u_token_shell.layer5_read_q),.input_last_i(dut.u_core.u_native.u_token_shell.stream_index_q == 8'd255),.result_valid_o(f_shell_f_child_u_final_rmsnorm_result_valid_o),.result_ready_i(dut.u_core.u_native.u_token_shell.rms_result_ready),.result_row_index_o(f_shell_f_child_u_final_rmsnorm_result_row_index_o),.result_mantissa_o(f_shell_f_child_u_final_rmsnorm_result_mantissa_o),.result_exponent_o(f_shell_f_child_u_final_rmsnorm_result_exponent_o),.result_last_o(f_shell_f_child_u_final_rmsnorm_result_last_o),.done_valid_o(f_shell_f_child_u_final_rmsnorm_done_valid_o),.done_ready_i(dut.u_core.u_native.u_token_shell.rms_done_ready),.busy_o(f_shell_f_child_u_final_rmsnorm_busy_o),.range_fault_o(f_shell_f_child_u_final_rmsnorm_range_fault_o));
witness_u_exact_argmax p_u_exact_argmax(.clk(dut.u_core.u_native.u_token_shell.clk),.reset_n(dut.u_core.u_native.u_token_shell.rst_n),.clear_i(dut.u_core.u_native.u_token_shell.clear_i),.model_locked_i(dut.u_core.u_native.u_token_shell.model_lock_i),.upstream_fail_closed_i(dut.u_core.u_native.u_token_shell.upstream_fault_i),.start_valid_i(dut.u_core.u_native.u_token_shell.argmax_start_valid),.start_ready_o(f_shell_f_child_u_exact_argmax_start_ready_o),.row_valid_i((dut.u_core.u_native.u_token_shell.state_q == dut.u_core.u_native.u_token_shell.ST_HEAD_SCAN) &&
                     dut.u_core.u_native.u_token_shell.private_head_result_valid_i),.row_ready_o(f_shell_f_child_u_exact_argmax_row_ready_o),.row_index_i(dut.u_core.u_native.u_token_shell.private_head_result_row_index_i),.row_scaled_raw_i(dut.u_core.u_native.u_token_shell.private_head_result_scaled_raw_i),.row_source_exponent_i(dut.u_core.u_native.u_token_shell.private_head_result_source_exponent_i),.row_last_i(dut.u_core.u_native.u_token_shell.private_head_result_last_i),.winner_valid_o(f_shell_f_child_u_exact_argmax_winner_valid_o),.winner_ready_i(dut.u_core.u_native.u_token_shell.argmax_winner_ready),.winner_token_id_o(f_shell_f_child_u_exact_argmax_winner_token_id_o),.winner_scaled_raw_o(f_shell_f_child_u_exact_argmax_winner_scaled_raw_o),.winner_source_exponent_o(f_shell_f_child_u_exact_argmax_winner_source_exponent_o),.busy_o(f_shell_f_child_u_exact_argmax_busy_o),.fail_closed_o(f_shell_f_child_u_exact_argmax_fail_closed_o),.witness_token_i(wanted_token),.witness_release_winner_i(release_winner));
witness_u_gate_scratch p_u_gate_scratch(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.scratch_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.scratch_read_address),.private_read_data_o(f_dp_f_child_u_gate_scratch_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.gate_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_mantissa));
witness_u_up_scratch p_u_up_scratch(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.scratch_read_enable &&
            (dut.u_core.u_native.u_six_layers.u_datapath.engine_state_q == dut.u_core.u_native.u_six_layers.u_datapath.E_ELEM) &&
            (dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_SILU_MUL)),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.scratch_read_address),.private_read_data_o(f_dp_f_child_u_up_scratch_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.up_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_mantissa));
witness_u_attention_scratch p_u_attention_scratch(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_ram_read_address),.private_read_data_o(f_dp_f_child_u_attention_scratch_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_ram_write_address),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_ram_write_data));
witness_u_rms_scratch p_u_rms_scratch(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_ram_read_address),.private_read_data_o(f_dp_f_child_u_rms_scratch_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q[7:0]),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_result_mantissa));
witness_u_output_scratch p_u_output_scratch(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.output_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_ram_read_address),.private_read_data_o(f_dp_f_child_u_output_scratch_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.output_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q[7:0]),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_mantissa));
witness_u_hidden_state p_u_hidden_state(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_ram_read_address),.private_read_data_o(f_dp_f_child_u_hidden_state_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_ram_write_address),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_ram_write_data));
witness_u_query_state p_u_query_state(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.query_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.query_ram_read_address),.private_read_data_o(f_dp_f_child_u_query_state_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.query_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q[7:0]),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_mantissa));
witness_u_key_state p_u_key_state(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.key_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.key_ram_read_address),.private_read_data_o(f_dp_f_child_u_key_state_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.key_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q[6:0]),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_mantissa));
witness_u_value_state p_u_value_state(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.value_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.value_ram_read_address),.private_read_data_o(f_dp_f_child_u_value_state_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.value_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.output_index_q[6:0]),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_mantissa));
witness_u_rope_raw_scratch p_u_rope_raw_scratch(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.private_read_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.rope_raw_ram_read_enable),.private_read_address_i(dut.u_core.u_native.u_six_layers.u_datapath.rope_second_index_q),.private_read_data_o(f_dp_f_child_u_rope_raw_scratch_private_read_data_o),.private_write_enable_i(dut.u_core.u_native.u_six_layers.u_datapath.rope_raw_ram_write_enable),.private_write_address_i(dut.u_core.u_native.u_six_layers.u_datapath.rope_half_q),.private_write_data_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_raw1));
witness_u_rmsnorm p_u_rmsnorm(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.rst_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.model_lock_i(dut.u_core.u_native.u_six_layers.u_datapath.model_lock_i),.upstream_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.upstream_fault_i || dut.u_core.u_native.u_six_layers.u_datapath.fault_q),.start_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_start_valid),.start_ready_o(f_dp_f_child_u_rmsnorm_start_ready_o),.fixed_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.current_layer_q),.fixed_norm_kind_i((dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_INPUT_RMS) ? 2'd0 :
                                                                    2'd1),.input_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_exponent_q),.input_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_input_valid),.input_ready_o(f_dp_f_child_u_rmsnorm_input_ready_o),.input_row_index_i(dut.u_core.u_native.u_six_layers.u_datapath.input_index_q[7:0]),.input_mantissa_i(dut.u_core.u_native.u_six_layers.u_datapath.hidden_ram_read_data),.input_last_i(dut.u_core.u_native.u_six_layers.u_datapath.input_index_q == 10'd255),.result_valid_o(f_dp_f_child_u_rmsnorm_result_valid_o),.result_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_result_ready),.result_row_index_o(f_dp_f_child_u_rmsnorm_result_row_index_o),.result_mantissa_o(f_dp_f_child_u_rmsnorm_result_mantissa_o),.result_exponent_o(f_dp_f_child_u_rmsnorm_result_exponent_o),.result_last_o(f_dp_f_child_u_rmsnorm_result_last_o),.done_valid_o(f_dp_f_child_u_rmsnorm_done_valid_o),.done_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.rms_done_ready),.busy_o(f_dp_f_child_u_rmsnorm_busy_o),.range_fault_o(f_dp_f_child_u_rmsnorm_range_fault_o));
witness_u_projection p_u_projection(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.reset_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.model_locked_i(dut.u_core.u_native.u_six_layers.u_datapath.model_lock_i),.upstream_fail_closed_i(dut.u_core.u_native.u_six_layers.u_datapath.upstream_fault_i || dut.u_core.u_native.u_six_layers.u_datapath.fault_q),.start_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_start_valid),.start_ready_o(f_dp_f_child_u_projection_start_ready_o),.fixed_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_layer),.fixed_job_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_job),.activation_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_is_head ? dut.u_core.u_native.u_six_layers.u_datapath.head_activation_exponent_q :
            (dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_Q || dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_K ||
             dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_V) ? dut.u_core.u_native.u_six_layers.u_datapath.rms_exponent_q :
            (dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_O) ? dut.u_core.u_native.u_six_layers.u_datapath.attention_exponent_q :
            (dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_GATE || dut.u_core.u_native.u_six_layers.u_datapath.current_stage_q == dut.u_core.u_native.u_six_layers.u_datapath.STAGE_UP) ?
                dut.u_core.u_native.u_six_layers.u_datapath.rms_exponent_q : dut.u_core.u_native.u_six_layers.u_datapath.gate_exponent_q),.activation_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_activation_valid),.activation_ready_o(f_dp_f_child_u_projection_activation_ready_o),.activation_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_activation),.activation_last_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_activation_last),.private_word_req_valid_o(f_dp_f_child_u_projection_private_word_req_valid_o),.private_word_req_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_word_req_ready),.private_word_req_index_o(f_dp_f_child_u_projection_private_word_req_index_o),.private_word_rsp_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_word_rsp_valid),.private_word_rsp_ready_o(f_dp_f_child_u_projection_private_word_rsp_ready_o),.private_word_rsp_data_i(dut.u_core.u_native.u_six_layers.u_datapath.private_word_rsp_data_i),.private_word_rsp_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.private_word_rsp_fault_i),.result_valid_o(f_dp_f_child_u_projection_result_valid_o),.result_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_result_ready),.result_row_index_o(f_dp_f_child_u_projection_result_row_index_o),.result_scaled_raw_o(f_dp_f_child_u_projection_result_scaled_raw_o),.result_source_exponent_o(f_dp_f_child_u_projection_result_source_exponent_o),.result_last_o(f_dp_f_child_u_projection_result_last_o),.done_valid_o(f_dp_f_child_u_projection_done_valid_o),.done_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.projection_done_ready),.busy_o(f_dp_f_child_u_projection_busy_o),.fail_closed_o(f_dp_f_child_u_projection_fail_closed_o));
witness_u_normalizer p_u_normalizer(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.rst_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.model_lock_i(dut.u_core.u_native.u_six_layers.u_datapath.model_lock_i),.upstream_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.upstream_fault_i || dut.u_core.u_native.u_six_layers.u_datapath.fault_q),.start_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_start_valid),.start_ready_o(f_dp_f_child_u_normalizer_start_ready_o),.fixed_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.current_layer_q),.fixed_job_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_job),.input_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_input_valid),.input_ready_o(f_dp_f_child_u_normalizer_input_ready_o),.input_row_index_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_input_index),.input_raw_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_input_raw),.input_source_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_input_exponent),.input_last_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_input_last),.result_valid_o(f_dp_f_child_u_normalizer_result_valid_o),.result_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_result_ready),.result_row_index_o(f_dp_f_child_u_normalizer_result_row_index_o),.result_mantissa_o(f_dp_f_child_u_normalizer_result_mantissa_o),.result_exponent_o(f_dp_f_child_u_normalizer_result_exponent_o),.result_last_o(f_dp_f_child_u_normalizer_result_last_o),.done_valid_o(f_dp_f_child_u_normalizer_done_valid_o),.done_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.norm_done_ready),.busy_o(f_dp_f_child_u_normalizer_busy_o),.range_fault_o(f_dp_f_child_u_normalizer_range_fault_o));
witness_u_elementwise_lane p_u_elementwise_lane(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.rst_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.request_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_request_valid),.request_ready_o(f_dp_f_child_u_elementwise_lane_request_ready_o),.operation_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_operation),.first_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_first),.second_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_second),.coefficient_i(10'sd0),.multiplier_i(16'd0),.cosine_i(dut.u_core.u_native.u_six_layers.u_datapath.rope_cosine_q),.sine_i(dut.u_core.u_native.u_six_layers.u_datapath.rope_sine_q),.first_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_first_exponent),.second_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_second_exponent),.common_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_common_exponent),.target_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_safety_exponent),.lut_request_o(f_dp_f_child_u_elementwise_lane_lut_request_o),.lut_index_o(f_dp_f_child_u_elementwise_lane_lut_index_o),.lut_response_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_lut_response_q),.lut_value_i(dut.u_core.u_native.u_six_layers.u_datapath.silu_value_q),.lut_fault_i(1'b0),.result_valid_o(f_dp_f_child_u_elementwise_lane_result_valid_o),.result_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.lane_result_ready),.result0_o(f_dp_f_child_u_elementwise_lane_result0_o),.result1_o(f_dp_f_child_u_elementwise_lane_result1_o),.auxiliary_o(f_dp_f_child_u_elementwise_lane_auxiliary_o),.raw0_o(f_dp_f_child_u_elementwise_lane_raw0_o),.raw1_o(f_dp_f_child_u_elementwise_lane_raw1_o),.source_exponent_o(f_dp_f_child_u_elementwise_lane_source_exponent_o),.range_fault_o(f_dp_f_child_u_elementwise_lane_range_fault_o));
witness_u_lookup p_u_lookup(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.reset_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.model_locked_i(dut.u_core.u_native.u_six_layers.u_datapath.model_lock_i),.upstream_fail_closed_i(dut.u_core.u_native.u_six_layers.u_datapath.upstream_fault_i || dut.u_core.u_native.u_six_layers.u_datapath.fault_q),.request_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_request_valid),.request_ready_o(f_dp_f_child_u_lookup_request_ready_o),.fixed_kind_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_kind),.rope_position_i(dut.u_core.u_native.u_six_layers.u_datapath.current_position_q),.rope_coordinate_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_index[4:0]),.silu_index_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_index),.response_valid_o(f_dp_f_child_u_lookup_response_valid_o),.response_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_response_ready),.response_value_o(f_dp_f_child_u_lookup_response_value_o),.response_fault_o(f_dp_f_child_u_lookup_response_fault_o),.private_word_req_valid_o(f_dp_f_child_u_lookup_private_word_req_valid_o),.private_word_req_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_word_req_ready),.private_word_req_index_o(f_dp_f_child_u_lookup_private_word_req_index_o),.private_word_rsp_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.lookup_word_rsp_valid),.private_word_rsp_ready_o(f_dp_f_child_u_lookup_private_word_rsp_ready_o),.private_word_rsp_data_i(dut.u_core.u_native.u_six_layers.u_datapath.private_word_rsp_data_i),.private_word_rsp_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.private_word_rsp_fault_i),.busy_o(f_dp_f_child_u_lookup_busy_o),.fail_closed_o(f_dp_f_child_u_lookup_fail_closed_o));
witness_u_kv_cache p_u_kv_cache(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.reset_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.model_locked_i(dut.u_core.u_native.u_six_layers.u_datapath.model_lock_i),.upstream_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.upstream_fault_i || dut.u_core.u_native.u_six_layers.u_datapath.fault_q),.endpoint_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_endpoint_fault_i),.stage_begin_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_stage_begin_valid),.stage_begin_ready_o(f_dp_f_child_u_kv_cache_stage_begin_ready_o),.stage_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.current_layer_q),.stage_position_i({1'b0, dut.u_core.u_native.u_six_layers.u_datapath.current_position_q}),.stage_key_exponents_i({dut.u_core.u_native.u_six_layers.u_datapath.key_exponent_q, dut.u_core.u_native.u_six_layers.u_datapath.key_exponent_q}),.stage_value_exponents_i({dut.u_core.u_native.u_six_layers.u_datapath.value_exponent_q, dut.u_core.u_native.u_six_layers.u_datapath.value_exponent_q}),.stage_payload_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_stage_payload_valid),.stage_payload_ready_o(f_dp_f_child_u_kv_cache_stage_payload_ready_o),.stage_coordinate_i(dut.u_core.u_native.u_six_layers.u_datapath.input_index_q[6:0]),.stage_key_i(dut.u_core.u_native.u_six_layers.u_datapath.key_ram_read_data),.stage_value_i(dut.u_core.u_native.u_six_layers.u_datapath.value_ram_read_data),.stage_last_i(dut.u_core.u_native.u_six_layers.u_datapath.input_index_q == 10'd127),.pending_complete_o(f_dp_f_child_u_kv_cache_pending_complete_o),.commit_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_commit_valid),.commit_ready_o(f_dp_f_child_u_kv_cache_commit_ready_o),.commit_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.current_layer_q),.commit_position_i({1'b0, dut.u_core.u_native.u_six_layers.u_datapath.current_position_q}),.attention_req_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_req_valid),.attention_req_ready_o(f_dp_f_child_u_kv_cache_attention_req_ready_o),.attention_req_kind_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_req_kind),.attention_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.current_layer_q),.attention_position_i({1'b0, dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_req_position}),.attention_kv_head_i({1'b0, dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_req_head}),.attention_rsp_valid_o(f_dp_f_child_u_kv_cache_attention_rsp_valid_o),.attention_rsp_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_rsp_ready),.attention_rsp_kind_o(),.attention_rsp_key_vector_o(f_dp_f_child_u_kv_cache_attention_rsp_key_vector_o),.attention_rsp_key_exponent_o(f_dp_f_child_u_kv_cache_attention_rsp_key_exponent_o),.attention_rsp_value_vector_o(f_dp_f_child_u_kv_cache_attention_rsp_value_vector_o),.attention_rsp_value_exponent_o(f_dp_f_child_u_kv_cache_attention_rsp_value_exponent_o),.attention_rsp_fault_o(f_dp_f_child_u_kv_cache_attention_rsp_fault_o),.attention_rsp_from_pending_o(f_dp_f_child_u_kv_cache_attention_rsp_from_pending_o),.kv_write_req_valid_o(f_dp_f_child_u_kv_cache_kv_write_req_valid_o),.kv_write_req_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_write_req_ready_i),.kv_write_req_layer_o(f_dp_f_child_u_kv_cache_kv_write_req_layer_o),.kv_write_req_position_o(f_dp_f_child_u_kv_cache_kv_write_req_position_o),.kv_write_req_head_o(f_dp_f_child_u_kv_cache_kv_write_req_head_o),.kv_write_req_row_word_o(f_dp_f_child_u_kv_cache_kv_write_req_row_word_o),.kv_write_req_shadow_address_o(f_dp_f_child_u_kv_cache_kv_write_req_shadow_address_o),.kv_write_req_data_o(f_dp_f_child_u_kv_cache_kv_write_req_data_o),.kv_write_cpl_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_write_cpl_valid_i),.kv_write_cpl_ready_o(f_dp_f_child_u_kv_cache_kv_write_cpl_ready_o),.kv_write_cpl_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_write_cpl_fault_i),.kv_read_req_valid_o(f_dp_f_child_u_kv_cache_kv_read_req_valid_o),.kv_read_req_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_read_req_ready_i),.kv_read_req_layer_o(f_dp_f_child_u_kv_cache_kv_read_req_layer_o),.kv_read_req_position_o(f_dp_f_child_u_kv_cache_kv_read_req_position_o),.kv_read_req_head_o(f_dp_f_child_u_kv_cache_kv_read_req_head_o),.kv_read_req_row_word_o(f_dp_f_child_u_kv_cache_kv_read_req_row_word_o),.kv_read_req_shadow_address_o(f_dp_f_child_u_kv_cache_kv_read_req_shadow_address_o),.kv_read_rsp_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_read_rsp_valid_i),.kv_read_rsp_ready_o(f_dp_f_child_u_kv_cache_kv_read_rsp_ready_o),.kv_read_rsp_data_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_read_rsp_data_i),.kv_read_rsp_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_read_rsp_fault_i),.committed_prefixes_o(f_dp_f_child_u_kv_cache_committed_prefixes_o),.busy_o(f_dp_f_child_u_kv_cache_busy_o),.fail_closed_o(f_dp_f_child_u_kv_cache_fail_closed_o));
witness_u_attention p_u_attention(.clk(dut.u_core.u_native.u_six_layers.u_datapath.clk),.rst_n(dut.u_core.u_native.u_six_layers.u_datapath.rst_n),.clear_i(dut.u_core.u_native.u_six_layers.u_datapath.clear_i),.model_lock_i(dut.u_core.u_native.u_six_layers.u_datapath.model_lock_i),.upstream_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.upstream_fault_i || dut.u_core.u_native.u_six_layers.u_datapath.fault_q),.start_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_start_valid),.start_ready_o(f_dp_f_child_u_attention_start_ready_o),.fixed_position_i(dut.u_core.u_native.u_six_layers.u_datapath.current_position_q),.fixed_layer_i(dut.u_core.u_native.u_six_layers.u_datapath.current_layer_q),.summary_stage_begin_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_stage_begin_valid && dut.u_core.u_native.u_six_layers.u_datapath.kv_stage_begin_ready),.summary_stage_value_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_stage_payload_valid && dut.u_core.u_native.u_six_layers.u_datapath.kv_stage_payload_ready),.summary_stage_coordinate_i(dut.u_core.u_native.u_six_layers.u_datapath.input_index_q[6:0]),.summary_stage_value_i(dut.u_core.u_native.u_six_layers.u_datapath.value_ram_read_data),.summary_stage_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.value_exponent_q),.summary_pending_complete_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_pending_complete),.summary_commit_i(dut.u_core.u_native.u_six_layers.u_datapath.kv_commit_valid && dut.u_core.u_native.u_six_layers.u_datapath.kv_commit_ready),.query_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.query_exponent_q),.query_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_query_valid),.query_ready_o(f_dp_f_child_u_attention_query_ready_o),.query_vector_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_query_vector),.query_last_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_query_last),.private_cache_request_valid_o(f_dp_f_child_u_attention_private_cache_request_valid_o),.private_cache_request_kind_o(f_dp_f_child_u_attention_private_cache_request_kind_o),.private_cache_request_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_req_ready),.private_cache_request_position_o(f_dp_f_child_u_attention_private_cache_request_position_o),.private_cache_request_kv_head_o(f_dp_f_child_u_attention_private_cache_request_kv_head_o),.private_cache_response_valid_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_rsp_valid),.private_cache_response_ready_o(f_dp_f_child_u_attention_private_cache_response_ready_o),.private_cache_response_key_vector_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_key),.private_cache_response_key_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_key_exp),.private_cache_response_value_vector_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_value),.private_cache_response_value_exponent_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_value_exp),.private_cache_response_fault_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_cache_rsp_fault),.result_valid_o(f_dp_f_child_u_attention_result_valid_o),.result_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_result_ready),.result_vector_o(f_dp_f_child_u_attention_result_vector_o),.result_exponent_o(f_dp_f_child_u_attention_result_exponent_o),.result_last_o(f_dp_f_child_u_attention_result_last_o),.done_valid_o(f_dp_f_child_u_attention_done_valid_o),.done_ready_i(dut.u_core.u_native.u_six_layers.u_datapath.attention_done_ready),.busy_o(f_dp_f_child_u_attention_busy_o),.range_fault_o(f_dp_f_child_u_attention_range_fault_o));

assign release_winner=(dut.u_core.u_native.u_token_shell.state_q===5'd21) && (!cancel_old || (dut.u_public.f_rx_event && dut.u_public.f_received==4));
always @(posedge core_clk_i) if(dut.reset_n_i===1'b0) observed_reset_low_edges=observed_reset_low_edges+1;
always @(posedge reset_n_i) observed_reset_releases=observed_reset_releases+1;
always #5 core_clk_i=~core_clk_i;
integer cycles=0,steps=0,clears=0,commits=0,captures=0,token_frames=0,frame_bytes=0;
integer drained=0,new_step_after_drain=0;reg[7:0] bytes[0:4];
reg[11:0] commit_value,commit_count;
wire successful_branch=dut.u_core.u_native.u_token_shell.rst_n &&
 dut.u_core.u_native.u_token_shell.generated_commit && !dut.clear && !dut.u_core.u_native.root_terminal &&
 !dut.u_core.u_native.u_token_shell.fail_q && !dut.u_core.u_native.u_token_shell.private_head_result_valid_i &&
 !dut.u_core.u_native.u_token_shell.upstream_fault_i && !dut.u_core.u_native.u_token_shell.child_fault &&
 !dut.u_core.u_native.u_token_shell.lock_fault && !dut.u_core.u_native.u_token_shell.watchdog_fault &&
 !dut.u_core.u_native.u_token_shell.public_protocol_fault && !dut.u_core.u_native.u_token_shell.private_protocol_fault;
always @(posedge core_clk_i) if(reset_n_i && successful_branch)begin
 commit_value=dut.u_core.u_native.u_token_shell.completing_winner;
 commit_count=dut.u_core.u_native.u_token_shell.tape_count_q;
 #1;
 if(dut.u_core.u_native.u_token_shell.rst_n!==1'b1 || dut.u_core.u_native.u_token_shell.state_q!==5'd22 ||
    dut.u_core.u_native.u_token_shell.generated_token_q!==commit_value ||
    dut.u_core.u_native.u_token_shell.tape_count_q!==(commit_count+12'd1))$fatal(1,"successful commit did not establish actual Hold/count/value");
 commits=commits+1;$display("COMMIT candidate=%0d ticket=%0d",commit_value,steps);
 if(commits==1 && commit_value!==12'd23)$fatal(1,"old candidate not23");
 if(commits==2 && commit_value!==12'd17)$fatal(1,"new candidate not17");
end
function automatic[7:0] crc(input[7:0]c,input[7:0]d);
 integer bit_index;reg[7:0]v;reg feedback;
 begin v=c;for(bit_index=7;bit_index>=0;bit_index=bit_index-1)begin
 feedback=v[7]^d[bit_index];v={v[6:0],1'b0};if(feedback)v=v^8'h07;end crc=v;end
endfunction
task send_byte(input[7:0]value);integer bit_index;begin
 @(negedge core_clk_i);uart_rx_i=0;repeat(217)@(negedge core_clk_i);
 for(bit_index=0;bit_index<8;bit_index=bit_index+1)begin uart_rx_i=value[bit_index];repeat(217)@(negedge core_clk_i);end
 uart_rx_i=1;repeat(217)@(negedge core_clk_i);
end endtask
task packet(input[7:0]op,input[11:0]value);reg[7:0]sum;begin
 sum=crc(crc(crc(crc(0,8'ha5),op),value[7:0]),{4'b0,value[11:8]});
 send_byte(8'ha5);send_byte(op);send_byte(value[7:0]);send_byte({4'b0,value[11:8]});send_byte(sum);
end endtask
task idle;begin while(dut.u_public.f_phase!==0 || !dut.u_public.f_tx_accept)@(negedge core_clk_i);end endtask
always @(posedge core_clk_i) begin
 if(reset_n_i)begin
  if(((^{dut.clear,dut.step_valid,dut.step_ready,dut.token_valid,dut.u_public.f_phase,dut.u_core.u_native.u_token_shell.state_q})===1'bx))
   $fatal(1,"unknown critical control event");
  cycles=cycles+1;
  if(dut.step_valid && dut.step_ready)begin
   steps=steps+1;$display("STEP ticket=%0d count=%0d cycle=%0d",steps,dut.u_core.u_native.u_token_shell.tape_count_q,cycles);
   if(dut.u_core.u_native.u_token_shell.tape_count_q!==12'd1 || f_pc_tape_value_o!==(steps==1?12'd7:12'd9))
    $fatal(1,"accepted STEP did not snapshot its actual nonzero APPEND tape");
   if(steps==2)begin if(!drained)$fatal(1,"new STEP before observed drain");new_step_after_drain=1;end
  end
  if(dut.clear)begin
   clears=clears+1;
   if(steps!==1 || dut.u_core.u_native.u_token_shell.state_q!==22 || dut.u_core.u_native.u_token_shell.generated_token_q!==23 || dut.token_valid)
    $fatal(1,"CLEAR did not cancel the distinct old held candidate before capture");
   $display("CLEAR old_held=23 captures=%0d",captures);
  end
  if(clears==1 && dut.u_core.u_native.u_token_shell.state_q==23)$display("DRAIN");
  if(clears==1 && dut.u_core.u_native.u_token_shell.state_q==0 && dut.u_public.f_phase==3)drained=1;
  if(dut.u_public.f_phase==2 && !dut.u_public.f_cancel_pending && dut.token_valid)begin
   captures=captures+1;
   if(steps!==2 || clears!==1 || dut.token!==17)$fatal(1,"stale or unowned reply capture");
   $display("CAPTURE ticket=2 value=17");
   upstream_fail_closed_i<=1; // A later fault cannot retract the captured message.
  end
  if(dut.u_public.f_send_byte && dut.u_public.f_tx_accept)begin
   bytes[dut.u_public.f_sent]=dut.u_public.f_send_data;frame_bytes=frame_bytes+1;
   if(dut.u_public.f_sent==4 && bytes[1]==8'h81)begin
    if(bytes[0]!==8'h5a || bytes[2]!==17 || bytes[3]!==0 || bytes[4]!==crc(crc(crc(crc(0,bytes[0]),bytes[1]),bytes[2]),bytes[3]))
     $fatal(1,"final token frame differs from the committed new candidate");
    token_frames=token_frames+1;$display("TOKEN_FRAME value=17 late_fault=%0d",upstream_fail_closed_i);
   end
  end
 end
end
initial begin
core_clk_i=0;
reset_n_i=0;
uart_rx_i=0;
model_locked_i=0;
upstream_fail_closed_i=0;
private_runtime_req_ready_i=0;
private_runtime_rsp_valid_i=0;
private_runtime_rsp_data_i=0;
private_runtime_rsp_fault_i=0;
kv_write_req_ready_i=0;
kv_write_cpl_valid_i=0;
kv_write_cpl_fault_i=0;
kv_read_req_ready_i=0;
kv_read_rsp_valid_i=0;
kv_read_rsp_data_i=0;
kv_read_rsp_fault_i=0;
kv_endpoint_fault_i=0;
f_pc_tape_index_i=0;
 core_clk_i=0;reset_n_i=0;uart_rx_i=1;wanted_token=23;cancel_old=1;
 model_locked_i=1;private_runtime_req_ready_i=1;kv_write_req_ready_i=1;kv_read_req_ready_i=1;
 repeat(5)@(negedge core_clk_i);reset_n_i=1;
 repeat(20)@(negedge core_clk_i);
 packet(0,7);idle();packet(1,0);
 wait(dut.u_core.u_native.u_token_shell.state_q==21 && p_u_exact_argmax.count==4019);
 packet(2,0);idle();
 if(clears!==1 || commits!==1 || captures!==0 || !drained || dut.u_core.u_native.u_token_shell.tape_count_q!==0)
  $fatal(1,"busy CLEAR/drain lost its reset-rooted ordering");
 wanted_token=17;cancel_old=0;
 packet(0,9);idle();packet(1,0);
 wait(captures==1);
 // These host CLEAR bytes arrive during SEND/DRAIN and are not accepted CLEAR.
 packet(2,0);idle();repeat(20)@(negedge core_clk_i);
 if(steps!==2 || clears!==1 || commits!==2 || captures!==1 || token_frames!==1 || !new_step_after_drain || !upstream_fail_closed_i)
  $fatal(1,"reset-rooted public operating trace incomplete");
 if(observed_reset_low_edges<2 || observed_reset_releases!==1)
  $fatal(1,"hard reset was not sampled low or was repeated before new work");
 $display("RESET_OBSERVED low_edges=%0d releases=%0d",observed_reset_low_edges,observed_reset_releases);
 $display("CASEPASS public steps=2 clear=1 commits=2 captures=1 old=23 new=17 late_fault=1");$finish;
end
initial begin #20000000;$fatal(1,"public witness cycle bound exceeded");end

endmodule

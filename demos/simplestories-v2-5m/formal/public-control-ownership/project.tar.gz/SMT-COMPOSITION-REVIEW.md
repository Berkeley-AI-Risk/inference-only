# Independent SMT composition and pre-witness closeout review

**ACCEPT the completed native/phase/history/endpoint SMT safety composition.
The pilot's required operating qualification is incomplete.** The eighteen
selected checks have the exact expected clean answers: fourteen UNSAT and four
SAT. The Icarus witness compilation failed, no simulation ran, and no
reset-rooted successful-work witness can yet be claimed. This does not erase
the completed universal safety proof, nor does it qualify the whole pilot.

This review is read-only evidence assessment, not permission for further
compilation, simulation, solver queries or input changes. I ran only source
reads, hashes and independent query/receipt reconstruction. Frozen inputs and
earlier reviews were not modified.

## Exact artifact checks

The reviewed freeze remains the 100-file manifest
`62348b7adc16d158ec5446979e70e758960dbf79e5851f811c379fab43b5b141`.
Every member hash matches. The acceptance record binds that complete map and
manifest. `PRE-WITNESS-CLOSEOUT.json` hashes to
`a1774bd4bcfd29d7417aea12def9bdc4a567ecc7c5c52b3e5f8974abf11eddf0`;
its eighteen selected entries reconstruct exactly from the current role's
native SMT, unchanged `STATEMENT.smt2`, per-query support definition when
needed, and exact frozen tail. Each saved `query.smt2` equals that reconstruction.

I checked all eighteen query, receipt and raw-log digests. Each selected solver
receipt has exit zero, no stop reason and only its expected literal SAT/UNSAT
answer. The selected model files match their separately recorded model bindings:

| Native role | SMT SHA-256 |
| --- | --- |
| original | `92cead010d79006540b578c103289e680709491c257f709208a557e61375262a` |
| stale-capture | `bbaf0fa6f09730c66e09d3297d1078c1ca0cdfd0f14d3439d37d92f01e11e9fa` |

Both JSON circuits retain 142 assertion cells, no assumption/anyconst/anyseq
cells, and the actual 2049-by-12 token tape. The original and mutant source
and query-role checks remain those in the exact execution reviews. The current
statement digest is
`d9cd23be2d937f35cf430a35c5bbad98747b3e0b81b509b65ec9896c7f161079`;
query-plan digest is
`69a66355f2edada2c8b730d21e0e7d61f1c5bb65519a8e36257905aeadead507`.

## Closed proof chain

The composition is acyclic and covers its full stated conjunction:

| Layer | Completed selected obligations | Meaning |
| --- | --- | --- |
| Native common trace | reset, initial three-edge window, joint three-step preservation | All 142 rebuilt source claims hold from the specified common sampled reset. No PC history premise is used. |
| Independent phase provider | reset base, one-step preservation | Live ghost work implies actual production bridge WAIT_RESULT=2. It uses its own predecessor and closed native facts, not failed PC-I. |
| Complete PC history | reset, initial window, revised joint three-step preservation | All twelve unchanged PC-I clauses hold from reset, using the independently established phase provider on that same trace. |
| Actual endpoints | successful commit, STEP snapshot, publication once, token-message bytes | Actual source events satisfy the named tape/candidate/ticket/message relations under the closed native/history relation. |
| Contexts/control | released-reset SAT, original capture SAT/consumer UNSAT, race context SAT/priority UNSAT, stale-capture SAT | Nonempty named contexts, the exact source priority and sensitivity of the actual captured payload consumer. |

The initial windows and arbitrary three-step preservation compose to unbounded
safety by induction over successive common-clock states. This is not a bounded
execution test. Source facts at a successor are independently closed native
facts; phase facts at a/b/c/d are independently derived from phase reset/step.
No desired PC successor or failed PC invariant is smuggled into either provider.
The aggregate history preservation passed, so no incomplete member subset is
being used as closure credit.

The watched address is arbitrary and fixed. From zero valid count, its history
tracks each accepted APPEND and successful committed candidate at that point;
the accepted STEP stores the actual pre-edge tape point/count/ticket. No native
RAM payload is assumed initialized. Separate held and in-flight message state
connect actual candidate commit to bridge capture and immutable response bytes,
even after the macro live bit drops or a later fault occurs. CLEAR invalidates
authority rather than erasing physical payloads. Publication remains the bridge
capture event; attempted CLEAR during SEND/DRAIN is not an accepted cancellation.

The source-defect check has the correct boundary: it compiles the one stale
capture call, distinguishes old response zero from current opaque token 17,
and reaches a SAT violation at the actual captured-payload/frame consumer.
The positive counterpart passes. The mutant imports neither original-source
successor assertions nor a desired PC successor. Its explicit arbitrary-state
context is useful defect sensitivity, not proof that this fixture is reachable
from reset. The race SAT fixture has the same reachability limitation. The
released-reset context proves two high reset samples are consistent, not that
useful computation or activation has occurred.

## Initial failure remains part of the record

The original unaugmented history query at
`runs/history-joint-three-step-20261107T023824802694Z/` remains SAT. Its saved
query differs from the selected revised UNSAT query, and its raw diagnostic
remains preserved. It exhibited phantom ghost work in actual IDLE/OFFER,
followed by APPEND changing the count, rather than a reset-rooted bad output.
The new phase relation was separately proved and then added as a provider.
It is accurate to report successful revised composition; it is inaccurate to
report that the original query passed unchanged or to discard the first SAT.

## Remaining operating qualification

The sole authorized Icarus compile at
`runs/witness-compile-20261107T025546654341Z/` exited 62. I checked its raw-log
digest
`6a49b6503bc264f38eb3420bd5d8cd8a8c0a63714c10a7e06d5e27df59948407`.
The log rejects observer nets in frontend/core modules that are declared after
their first named output-port use under `default_nettype none`. It also reports
an always-comb sensitivity limitation; that warning is distinct from the fatal
undefined-net/output-port errors. No witness simulation directory exists.

Consequently, there is no current execution evidence of the required reset-rooted
APPEND 7/STEP/held 23/busy CLEAR/drain/APPEND 9/new STEP/capture 17/late-fault
frame sequence. The initial cap of one witness compile is consumed and
`witness_runs` is zero. A declaration-hoist portability fix may be a reasonable
separate proposal, but this review neither approves it nor treats it as already
checked. It would need explicit authorization, an exact fixture-only/source
restoration diff review, and a separate result record while preserving this
failure. The completed SMT inputs and answers must remain untouched.

At the reviewed snapshot no owned job remains. The original engine start is
`2026-11-07T02:35:51.888385+00:00`, solver accounting is 16.148650875333104
seconds, both native model roles are compiled, one diagnostic is consumed and
STOP is present. This review grants no extra budget or new refinement loop.

## Claims that are and are not supported

Supported now: an unbounded, reset-rooted safety relation for this source-bound
baseline controller/UART abstraction, accepted tape snapshots, shell acceptance
and commit of an opaque candidate under a STEP control lease, one-time capture
and immutable token-message bytes; plus the specified arbitrary-state context
and source-defect checks. This is a substantive joined safety result across
the actual public/frontend/core controller path.

Not yet qualified: the complete planned pilot, because its separately required
successful operating witness has not run. Still open regardless of that witness:
origin of a cut argmax value in this invocation's head rows, `token=P(tape)`,
the complete numerical graph/model binding, actual child/physical drain and
startup authentication, full fault/status/timing/private-effect admissibility,
pin-level UART refinement, protected mask/RAM/hash/tag/attention composition,
other configurations and the original all-configuration inference-only theorem.
No detached support count or passing SMT count closes those boundaries.

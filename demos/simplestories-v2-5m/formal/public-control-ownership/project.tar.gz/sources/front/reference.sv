`default_nettype none
// Reference for the current greedy public byte protocol, not model inference.
// Receive bytes are observations of the actual UART receiver. Core readiness
// and token results are unrestricted inputs at the real service interface.
// This machine gives protocol outputs independent meanings: packet validation,
// three operations, response framing, cancellation priority and byte order.
module public_command_reference(
    input wire clk,reset_n,rx_event,
    input wire[7:0]rx_data,
    input wire tx_accept,append_ready,step_ready,result_valid,
    input wire[11:0]result_token,
    output wire append_offer,step_offer,clear_level,result_ready,send_byte,
    output wire[11:0]append_token,
    output wire[7:0]send_data,
    output logic[2:0]phase,received,sent,
    output logic[7:0]frame_opcode,frame_low,frame_high,reply_kind,
    output logic[1:0]offered_operation,
    output logic[11:0]offered_token,reply_token,
    output logic cancel_pending,
    output wire [7:0] f_prefix_one,
    output wire [7:0] f_prefix_two,
    output wire [7:0] f_prefix_three,
    output wire [7:0] f_packet_crc,
    output wire [7:0] f_reference_reply_crc
);
    localparam[2:0] COLLECT=3'd1,OFFER=3'd2,AWAIT_RESULT=3'd3,
        TRANSMIT=3'd4,WAIT_TX_IDLE=3'd5;

    // CRC-8 polynomial x^8+x^2+x+1, MSB first. This mathematical
    // bit-at-a-time form is independent of the RTL's xor-then-shift loop.
    function automatic[7:0] crc_byte(input[7:0]prefix,input[7:0]datum);
        integer bit_index;reg[7:0] remainder;reg feedback;
        begin
            remainder=prefix;
            for(bit_index=7;bit_index>=0;bit_index=bit_index-1)begin
                feedback=remainder[7]^datum[bit_index];
                remainder={remainder[6:0],1'b0};
                if(feedback)remainder=remainder^8'h07;
            end
            crc_byte=remainder;
        end
    endfunction
    wire[7:0]prefix_one=crc_byte(0,8'ha5);
    wire[7:0]prefix_two=crc_byte(prefix_one,frame_opcode);
    wire[7:0]prefix_three=crc_byte(prefix_two,frame_low);
    wire[7:0]packet_crc=crc_byte(prefix_three,frame_high);
    wire[11:0]packet_token={frame_high[3:0],frame_low};
    wire checksum_ok=rx_data==packet_crc;
    wire body_is_clear=checksum_ok && frame_opcode==2 && frame_low==0 && frame_high==0;
    wire body_malformed=!checksum_ok || frame_high[7:4]!=0 || frame_opcode>2;
    wire body_bad_token=frame_opcode==0 ? {1'b0,packet_token}>=13'd4019 : packet_token!=0;
    wire offer_ready=offered_operation==0 ? append_ready : offered_operation==1 ? step_ready : offered_operation==2;
    wire[7:0]reply_crc=crc_byte(crc_byte(crc_byte(crc_byte(0,8'h5a),reply_kind),reply_token[7:0]),{4'b0,reply_token[11:8]});
    assign append_offer=phase==OFFER && offered_operation==0;
    assign step_offer=phase==OFFER && offered_operation==1;
    assign clear_level=(phase==OFFER && offered_operation==2) || (phase==AWAIT_RESULT && cancel_pending);
    assign append_token=phase==AWAIT_RESULT && cancel_pending ? 12'd0 : offered_token;
    assign result_ready=phase==AWAIT_RESULT;
    assign send_byte=phase==TRANSMIT;
    assign send_data=sent==0 ? 8'h5a : sent==1 ? reply_kind : sent==2 ? reply_token[7:0] : sent==3 ? {4'b0,reply_token[11:8]} : reply_crc;

    always_ff @(posedge clk or negedge reset_n)begin
        if(!reset_n)begin
            phase<=COLLECT;received<=0;sent<=0;
            frame_opcode<=0;frame_low<=0;frame_high<=0;
            offered_operation<=0;offered_token<=0;
            reply_kind<=0;reply_token<=0;cancel_pending<=0;
        end else begin
            // During a pending STEP only a complete valid CLEAR can affect
            // the operation. A simultaneously available token takes priority
            // over starting/continuing frame reception on that cycle.
            if(rx_event && (phase==COLLECT || (phase==AWAIT_RESULT && !cancel_pending && !result_valid)))begin
                case(received)
                    0:if(rx_data==8'ha5)received<=1;
                    1:begin frame_opcode<=rx_data;received<=2;end
                    2:begin frame_low<=rx_data;received<=3;end
                    3:begin frame_high<=rx_data;received<=4;end
                    4:begin
                        received<=0;
                        if(phase==AWAIT_RESULT)begin
                            if(body_is_clear)cancel_pending<=1;
                        end else if(body_malformed)begin
                            reply_kind<=8'hcf;reply_token<=0;sent<=0;phase<=TRANSMIT;
                        end else if(body_bad_token)begin
                            reply_kind<=8'hc0|frame_opcode;reply_token<=0;sent<=0;phase<=TRANSMIT;
                        end else begin
                            offered_operation<=frame_opcode[1:0];offered_token<=packet_token;phase<=OFFER;
                        end
                    end
                    default:received<=0;
                endcase
            end
            case(phase)
                OFFER:begin
                    if(offer_ready)begin
                        if(offered_operation==1)phase<=AWAIT_RESULT;
                        else begin
                            reply_kind<=offered_operation==0 ? 8'h80 : 8'h82;
                            reply_token<=0;sent<=0;phase<=TRANSMIT;
                        end
                    end else begin
                        reply_kind<=8'hc0|{6'b0,offered_operation};reply_token<=0;sent<=0;phase<=TRANSMIT;
                    end
                end
                AWAIT_RESULT:begin
                    if(cancel_pending)begin
                        cancel_pending<=0;reply_kind<=8'h82;reply_token<=0;sent<=0;phase<=TRANSMIT;
                    end else if(result_valid)begin
                        reply_kind<=8'h81;reply_token<=result_token;sent<=0;phase<=TRANSMIT;
                    end
                end
                TRANSMIT:if(tx_accept)begin
                    if(sent==4)phase<=WAIT_TX_IDLE;
                    else sent<=sent+1'b1;
                end
                WAIT_TX_IDLE:if(tx_accept)phase<=COLLECT;
                default:begin end
            endcase
        end
    end
    assign f_prefix_one=prefix_one;
    assign f_prefix_two=prefix_two;
    assign f_prefix_three=prefix_three;
    assign f_packet_crc=packet_crc;
    assign f_reference_reply_crc=reply_crc;
endmodule
`default_nettype wire

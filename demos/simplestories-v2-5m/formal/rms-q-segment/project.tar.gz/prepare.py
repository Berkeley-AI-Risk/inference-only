"""Freeze one baseline subtree and compile its native, uncut transition system.

This command never starts a solver. Manifest checking is also used by check.py.
The source roots are the existing frozen baseline and public export, not HWIC.
"""
import argparse
import os
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

from checkpoint import atomic_json

HERE = Path(__file__).resolve().parent
CAMPAIGN = HERE.parent.parent
PUBLIC = Path(os.environ['Q_PRODUCTION_MODEL'])/'hardware/project'
PROJECT = PUBLIC
BINDING = HERE/'model-consumption/source-context/BINDING.json'
TOP = 'board1_fixed_vector_rmsnorm_service'
RMS = 'fpga/token_only_model0_ddr_board1/fixed_vector_rmsnorm0/'
SOURCES = {
    RMS+'rtl/board1_fixed_vector_rmsnorm_service.sv': [TOP],
    RMS+'rtl/board1_fixed_rmsnorm_arithmetic.sv': [
        'board1_fixed_rmsnorm_isqrt_u45_iterative',
        'board1_fixed_rmsnorm_rne_div_signed64_iterative',
        'board1_rmsnorm_bounded28_divider'],
    RMS+'rtl/board1_fixed_rmsnorm_rom.sv': ['board1_fixed_rmsnorm_rom'],
    'fpga/token_only_model0_board0/rtl/physical/board0_exact_isqrt_u45_iterative.sv':
        ['board0_exact_isqrt_u45_iterative'],
    'fpga/token_only_model0_ddr_board1/fixed_elementwise0/rtl/board1_fixed_elementwise_dsp_lane.sv':
        ['board1_fixed_elementwise_dsp_lane'],
    'normalizer_pipeline.sv': ['board1_fixed_vector_normalizer'],
    'candidate.sv': ['board1_fixed_vector_rne_shift_pipeline1'],
}
CALLERS = [
    'fpga/token_only_model0_ddr_board1/context2048_token_machine0/rtl/board1_context2048_semantic_datapath.sv',
    'fpga/token_only_model0_ddr_board1/context2048_token_machine2/rtl/board1_context2048_token_shell.sv',
]
ROM = RMS+'recorded/norm_rom34.memh'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    atomic_json(path, data)


def modules(raw):
    return {m[1]: m[0] for m in re.finditer(
        r'^module\s+(\w+)\b[\s\S]*?^endmodule', raw, re.M)}


def inventory():
    pins = json.loads(BINDING.read_text())['binding']['native_join']['distributed_inputs']
    rows = {}
    selected = []
    callers = {}
    for name in [*SOURCES, ROM, *CALLERS]:
        data = (PROJECT/name).read_bytes()
        expected = pins['project/'+name]
        if sha(data) != expected or sha((PUBLIC/name).read_bytes()) != expected:
            raise ValueError('Baseline source identity mismatch: '+name)
        row = dict(sha256=expected, bytes=len(data), baseline=str(PROJECT/name),
                   public_export=str(PUBLIC/name))
        if name in SOURCES:
            defs = modules(data.decode())
            row['compiled_modules'] = SOURCES[name]
            row['module_sha256'] = {}
            for module in SOURCES[name]:
                body = defs[module]
                row['module_sha256'][module] = sha(body.encode())
                selected.append(body)
        if name in CALLERS:
            text = data.decode()
            pattern = r'board1_fixed_vector_rmsnorm_service\b[\s\S]*?\n    \);'
            found = re.findall(pattern, text)
            if len(found) != 1:
                raise ValueError('Caller instance count changed')
            callers[name] = found[0]
        rows[name] = row
    shell = (PROJECT/CALLERS[1]).read_text()
    if 'RMS_MAX_COMPUTE_CYCLES = 2_000_000;' not in shell:
        raise ValueError('Actual final-caller watchdog changed')
    # Preserve module bodies exactly; only their surrounding file-level
    # presentation is omitted. No child output or memory seam is replaced.
    source = '`undef FORMAL\n`default_nettype none\n'+'\n\n'.join(selected)+'\n'
    return dict(schema='RMSNorm-pilot-source-inventory-v1', top=TOP, files=rows,
        binding_record_sha256=sha(BINDING.read_bytes()),
        compiler_source_sha256=sha(source.encode()), internal_numerical_cuts=[],
        caller_instances=callers,
        production_parameters=dict(MAX_COMPUTE_CYCLES=2000000,
            normalizer_MAX_COMPUTE_CYCLES=2000000, vector_rows=256,
            vector_width=16, normalizer_rows=682, normalizer_width=58),
        configuration=dict(SYNTHESIS=True, FORMAL=False,
            BOARD1_FIXED_ELEMENTWISE_GW5_DSP=False),
        platform_premises=[
            'Two-state RTL and synchronous native clock; no analog/metastability claim.',
            'Configured bypass/no-feedback vendor DSP equals the retained behavioral signed multiply.',
            'Immutable ROM bytes and source parameters are the named baseline, not the HWIC tree.'],
        parent_scope='Universal child inputs; caller instances bind port/parameter specialization only, not a parent operand-provenance proof.'), source


def verify_inventory():
    actual, source = inventory()
    expected = json.loads((HERE/'SOURCES.json').read_text())
    if actual != expected or sha((HERE/'project/native.sv').read_bytes()) != actual['compiler_source_sha256']:
        raise ValueError('Frozen source inventory changed')
    if (HERE/'project'/ROM).read_bytes() != (PROJECT/ROM).read_bytes():
        raise ValueError('Compiled ROM bytes changed')
    return actual


def compile_native():
    manifest, source = inventory()
    project = HERE/'project'
    project.mkdir(exist_ok=True)
    (project/'native.sv').write_text(source)
    dest = project/ROM
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((PROJECT/ROM).read_bytes())
    write_json(HERE/'SOURCES.json', manifest)
    script = '\n'.join([
        'read_verilog -formal -sv -nosynthesis -D SYNTHESIS native.sv',
        'hierarchy -check -top '+TOP, 'proc', 'opt_clean',
        'setattr -set keep 1 t:$dff t:$adff t:$dffe t:$adffe t:$sdff t:$sdffe',
        'flatten', 'async2sync', 'opt_clean', 'dffunmap', 'memory_collect',
        'select -assert-none t:$assume t:$assert t:$anyseq t:$anyconst',
        'check -assert', 'write_json native.json',
        'write_smt2 -wires native.smt2',
    ])+'\n'
    (project/'compile.ys').write_text(script)
    started = time.monotonic()
    with (project/'yosys.log').open('w') as log:
        cp = subprocess.run(['yosys', '-Q', 'compile.ys'], cwd=project,
            stdout=log, stderr=subprocess.STDOUT, timeout=120)
    result = dict(exit_code=cp.returncode, seconds=time.monotonic()-started,
        solver_started=False, source_manifest_sha256=sha((HERE/'SOURCES.json').read_bytes()),
        yosys_log_sha256=sha((project/'yosys.log').read_bytes()))
    if cp.returncode == 0:
        graph = json.loads((project/'native.json').read_text())['modules'][TOP]
        result['memories'] = {n: dict(width=c['parameters']['WIDTH'], size=c['parameters']['SIZE'])
            for n,c in graph['cells'].items() if c['type'] == '$mem_v2'}
        result['native_smt_sha256'] = sha((project/'native.smt2').read_bytes())
    write_json(HERE/'COMPILE.json', result)
    print(json.dumps(result, indent=2))
    return cp.returncode


if __name__ == '__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verify-only', action='store_true')
    args=ap.parse_args()
    if args.verify_only:
        verify_inventory(); print('Frozen source inventory matches baseline and public export.')
    else:
        raise SystemExit(compile_native())

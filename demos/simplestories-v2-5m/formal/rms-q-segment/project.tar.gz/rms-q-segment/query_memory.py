"""Actual query RAM transport with last-writer and request-edge ownership.

Only the numerical meaning of a named Q write is imported later. These rules
prove physical storage/read behavior themselves, including simultaneous reads
and writes, retained payload and logical cancellation. Q-RoPE has its own tag.
"""
from common import bv,both,eq,ext,save_plan
from parent_flow import TOP,S,DP,n,d
from rms_snapshot import definitions as snapshot_definitions
from prepare_context import prepare

M=lambda a='a':f'(|{TOP}_m {DP}u_query_state.payload_mem| {a})'


def definitions():
    defs,_=snapshot_definitions()
    vector='(Array (_ BitVec 8) (_ BitVec 16))'
    arrays=[('value',vector),('valid','(Array (_ BitVec 8) Bool)'),
        ('generation','(Array (_ BitVec 8) Int)'),('stage','(Array (_ BitVec 8) (_ BitVec 5))'),
        ('layer','(Array (_ BitVec 8) (_ BitVec 3))'),('position','(Array (_ BitVec 8) (_ BitVec 11))')]
    reads=[('read-value','(_ BitVec 16)'),('read-valid','Bool'),('read-generation','Int'),
        ('read-stage','(_ BitVec 5)'),('read-layer','(_ BitVec 3)'),
        ('read-position','(_ BitVec 11)'),('read-row','(_ BitVec 8)')]
    fields=arrays+reads
    defs+='(declare-datatypes () ((QueryMemory (query-memory '+' '.join('(qm-'+f+' '+t+')' for f,t in fields)+'))))\n'
    const=lambda sort,value:'((as const '+sort+') '+value+')'
    zero=[M(),const(arrays[1][1],'false'),const(arrays[2][1],'0'),const(arrays[3][1],bv(0,5)),
        const(arrays[4][1],bv(0,3)),const(arrays[5][1],bv(0,11)),d('query_ram_read_data'),'false','0',bv(0,5),bv(0,3),bv(0,11),bv(0,8)]
    defs+=f'(define-fun qm-base ((a {S})) QueryMemory (query-memory '+' '.join(zero)+'))\n'
    write=d('query_ram_write_enable');read=d('query_ram_read_enable')
    wr='((_ extract 7 0) '+d('output_index_q')+')';rd=d('query_ram_read_address')
    newq=both([d('stage_accept'),eq(d('private_stage_i'),bv(1,5))])
    invalidate=f'(or {d("clear_i")} {newq})'
    update_values=[d('norm_result_mantissa'),'true','(rs-generation rs)',d('current_stage_q'),d('current_layer_q'),d('current_position_q')]
    next_arrays=[]
    for (field,sort),value in zip(arrays,update_values,strict=True):
        ordinary=f'(ite {write} (store (qm-{field} h) {wr} {value}) (qm-{field} h))'
        next_arrays.append(f'(ite {invalidate} {const(sort,"false")} {ordinary})' if field=='valid' else ordinary)
    # Synchronous nonblocking RAM reads sample the PRE-WRITE value and tag.
    next_reads=[f'(ite {read} (select (qm-{field} h) {rd}) (qm-read-{field} h))' for field,sort in arrays]
    next_reads[1]=f'(ite {invalidate} false {next_reads[1]})'
    next_reads.append(f'(ite {read} {rd} (qm-read-row h))')
    args=f'((a {S}) (an {S}) (rs RMSSnapshot) (h QueryMemory))'
    defs+=f'(define-fun qm-next {args} QueryMemory (ite (not {d("rst_n")}) (qm-base an) (query-memory '+' '.join(next_arrays+next_reads)+')))\n'
    inv=both([eq(M(),'(qm-value h)'),eq(d('query_ram_read_data'),'(qm-read-value h)')])
    defs+=f'(define-fun qm-inv ((a {S}) (h QueryMemory)) Bool (=> {d("rst_n")} {inv}))\n'
    return defs


def specification():
    defs=definitions();H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
        '(declare-const rs RMSSnapshot)','(declare-const h QueryMemory)','(declare-const hn QueryMemory)',
        '(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    step=ctx+['(qm-inv a h)',eq('hn','(qm-next a an rs h)')]
    wr='((_ extract 7 0) '+d('output_index_q')+')';rd=d('query_ram_read_address')
    rules={
        'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(qm-inv an (qm-base an))'),
        'preserved':dict(assumptions=step,conclusion='(qm-inv an hn)'),
        'actual-request-edge-read-value':dict(assumptions=step+[d('rst_n'),d('rst_n','an'),d('query_ram_read_enable')],
            conclusion=both([eq(d('query_ram_read_data','an'),f'(select (qm-value h) {rd})'),eq('(qm-read-row hn)',rd)])),
        'actual-read-before-same-edge-write':dict(assumptions=step+[d('rst_n'),d('rst_n','an'),d('query_ram_read_enable'),d('query_ram_write_enable'),eq(rd,wr)],
            conclusion=both([eq(d('query_ram_read_data','an'),f'(select (qm-value h) {rd})'),
                eq(f'(select {M("an")} {wr})',d('norm_result_mantissa'))])),
        'actual-query-write-source-kind':dict(assumptions=[H('a'),d('query_ram_write_enable')],
            conclusion=both([f'(or (and {eq(d("engine_state_q"),bv(2,4))} {eq(d("current_stage_q"),bv(1,5))}) (and {eq(d("engine_state_q"),bv(3,4))} {eq(d("current_stage_q"),bv(4,5))}))',
                            f'(not {d("clear_i")})'])),
        'actual-write-stores-value-and-current-owner-tag':dict(assumptions=step+[d('rst_n'),d('rst_n','an'),d('query_ram_write_enable')],
            conclusion=both([eq(f'(select {M("an")} {wr})',d('norm_result_mantissa')),
                f'(select (qm-valid hn) {wr})',eq(f'(select (qm-generation hn) {wr})','(rs-generation rs)'),
                eq(f'(select (qm-stage hn) {wr})',d('current_stage_q')),
                eq(f'(select (qm-layer hn) {wr})',d('current_layer_q')),
                eq(f'(select (qm-position hn) {wr})',d('current_position_q'))])),
        'read-owner-tag-is-sampled-with-read-value':dict(assumptions=step+[d('rst_n'),f'(not {d("clear_i")})',d('query_ram_read_enable')],
            conclusion=both([eq('(qm-read-generation hn)',f'(select (qm-generation h) {rd})'),
                eq('(qm-read-stage hn)',f'(select (qm-stage h) {rd})'),
                eq('(qm-read-layer hn)',f'(select (qm-layer h) {rd})'),
                eq('(qm-read-position hn)',f'(select (qm-position h) {rd})') ])),
        'CLEAR-revokes-all-row-and-read-authority':dict(assumptions=[d('rst_n'),d('clear_i'),eq('hn','(qm-next a an rs h)')],
            conclusion=both(['(not (select (qm-valid hn) watch))','(not (qm-read-valid hn))'])),
        'new-Q-admission-revokes-earlier-query-authority':dict(assumptions=[d('rst_n'),d('stage_accept'),eq(d('private_stage_i'),bv(1,5)),eq('hn','(qm-next a an rs h)')],
            conclusion=both(['(not (select (qm-valid hn) watch))','(not (qm-read-valid hn))'])),
    }
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('query-memory',*specification(),native_label='context')
    print('Prepared actual query RAM storage/read/owner tags and cancellation rules.')

"""Save exact local implication inputs/replies with bounded parallel engines.

Success reports selected engine checks only. It is not segment qualification.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import fcntl
import json
import subprocess
import sys
import threading
import time
from common import HERE, atomic_bytes, atomic_json, sha
from native_induction import validate, query


def stamp():
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('component', nargs='+')
    ap.add_argument('--rule', action='append')
    ap.add_argument('--engine', choices=['original','digit-prefix'],default='original')
    ap.add_argument('--solver',choices=['z3','cvc5-int'],default='z3')
    args = ap.parse_args()
    with (HERE / 'RUN.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        statefile = HERE / 'STATE.json'
        state = json.loads(statefile.read_text())
        if state['active_owned_jobs']:
            raise ValueError('Owned jobs are already active')
        contexts, pending = {}, []
        for label in args.component:
            plan = validate(HERE, label + '-PLAN.json')
            body = '\n'.join((HERE / p).read_text() for p in plan['bodies'])
            identity = sha((HERE / (label + '-PLAN.json')).read_bytes())
            checkfile = HERE / plan['checks_file']
            checks = json.loads(checkfile.read_text()) if checkfile.exists() else {}
            if checks.get('plan_sha256') != identity:
                checks = dict(plan_sha256=identity, rules={})
            contexts[label] = (plan, body, identity, checkfile, checks)
            selected = args.rule or plan['order']
            for name in selected:
                if name not in plan['rules']:
                    raise ValueError('Unknown rule: ' + name)
                if not checks['rules'].get(name, {}).get('passed'):
                    pending.append((label, name))
            # Check the ORIGINAL complete theory's syntax/types without SAT.
            # This is type evidence, never an UNSAT proof.
            typed = query(plan, plan['order'][0], body)
            assert typed.endswith('(check-sat)\n')
            typed = typed[:-len('(check-sat)\n')]
            for rule in plan['rules'].values():
                typed += '\n'.join('(assert ' + t + ')' for t in
                                    [*rule['assumptions'], rule['conclusion']]) + '\n'
            typed += '(exit)\n'
            d = HERE / 'typechecks' / (label + '-' + stamp())
            d.mkdir(parents=True)
            atomic_bytes(d / 'typecheck.smt2', typed.encode())
            started = time.monotonic()
            cp = subprocess.run(['z3', '-memory:8192', '-T:30', str(d / 'typecheck.smt2')],
                                capture_output=True, timeout=35)
            raw = cp.stdout + cp.stderr
            atomic_bytes(d / 'z3.log', raw)
            result = dict(typecheck_only=True, proof_result=False,
                          query_sha256=sha(typed.encode()), log_sha256=sha(raw),
                          exit_code=cp.returncode, passed=cp.returncode == 0 and not raw.strip(),
                          seconds=time.monotonic() - started)
            atomic_json(d / 'RESULT.json', result)
            if not result['passed']:
                raise ValueError('Original theory typecheck failed: ' + str(d))
        ledger = threading.Lock()

        def run(item):
            label, name = item
            plan, body, identity, checkfile, checks = contexts[label]
            if plan['rules'][name].get('dependencies'):
                raise ValueError('This local batch requires independently checked rules')
            d = HERE / 'queries' / (label + '-' + name + '-' + stamp())
            d.mkdir(parents=True)
            text = query(plan, name, body)
            atomic_bytes(d / 'query.smt2', text.encode())
            engine_file='query.smt2'
            engine_text=text
            expected = plan['rules'][name].get('expected', 'unsat')
            if args.engine=='digit-prefix' and expected=='unsat':
                from prefix_forgetting import transform
                engine_text,abstraction=transform(text,label,name)
                atomic_bytes(d/'engine.smt2',engine_text.encode())
                atomic_json(d/'ABSTRACTION.json',abstraction)
                engine_file='engine.smt2'
            if args.solver=='cvc5-int':
                if args.engine!='original' or label not in ['digit-word-bridge','digit-meaning','digit-assembly','rms-word-arithmetic','rms-word-arithmetic-r2']:
                    raise ValueError('This alternate engine is scoped to exact word/integer bridges')
                engine_text=text.replace('(bv2int ','(ubv_to_int ')
                engine_file='query.cvc5.smt2';atomic_bytes(d/engine_file,engine_text.encode())
                atomic_json(d/'CONVERSION.json',dict(rule='Z3 unsigned bv2int spelling to standard ubv_to_int',
                    original_sha256=sha(text.encode()),engine_sha256=sha(engine_text.encode()),no_other_changes=True))
            engine_log='cvc5.log' if args.solver=='cvc5-int' else 'z3.log'
            command = (['z3', '-memory:' + str(state['memory_mib']),
                       '-T:' + str(state['per_query_seconds']), str(d / engine_file)] if args.solver=='z3' else
                       [sys.executable,'-B',str(HERE.parent/'model-consumption/bounded_engine.py'),
                        '--memory-mib',str(state['memory_mib']),'--wall-seconds',str(state['per_query_seconds']+2),'--',
                        'cvc5','--force-logic=ALL','--solve-bv-as-int=sum','--lang=smt2',
                        '--tlimit='+str(state['per_query_seconds']*1000),str(d/engine_file)])
            started = time.monotonic()
            with (d / engine_log).open('w') as log:
                proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
                with ledger:
                    state['active_owned_jobs'].append(dict(pid=proc.pid, component=label,
                                                          rule=name, command=command))
                    state['status'] = 'local_component_checks_running'
                    atomic_json(statefile, state)
                try:
                    code = proc.wait(timeout=state['per_query_seconds'] + 5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
                    code = -1
            raw = (d / engine_log).read_bytes()
            result = dict(component=label, rule=name, expected=expected,
                          passed=code == 0 and raw.strip() == expected.encode(),
                          exit_code=code, seconds=time.monotonic() - started,
                          query_sha256=sha(text.encode()), log_sha256=sha(raw),
                          engine_query_sha256=sha(engine_text.encode()),engine_file=engine_file,
                          engine=args.solver if args.solver!='z3' else ('digit-prefix' if engine_file=='engine.smt2' else 'original'),
                          engine_log=engine_log,
                          plan_sha256=identity, command=command,
                          receipt=str((d / 'RESULT.json').relative_to(HERE)))
            atomic_json(d / 'RESULT.json', result)
            with ledger:
                state['active_owned_jobs'] = [x for x in state['active_owned_jobs']
                                               if x['pid'] != proc.pid]
                state['solver_seconds'] += result['seconds']
                state['status'] = ('local_component_checks_running' if state['active_owned_jobs']
                                   else 'local_component_batch_finished')
                atomic_json(statefile, state)
                checks['rules'][name] = result
                checks['all_rules_passed'] = all(checks['rules'].get(n, {}).get('passed')
                                                for n in plan['order'])
                checks['connected_segment_proved'] = False
                atomic_json(checkfile, checks)
            print(json.dumps({k: result[k] for k in
                              ['component', 'rule', 'passed', 'seconds']}), flush=True)
            return result['passed']

        with ThreadPoolExecutor(max_workers=state['max_concurrent']) as pool:
            results = [f.result() for f in as_completed([pool.submit(run, x) for x in pending])]
        return 0 if all(results) else 1


if __name__ == '__main__':
    raise SystemExit(main())

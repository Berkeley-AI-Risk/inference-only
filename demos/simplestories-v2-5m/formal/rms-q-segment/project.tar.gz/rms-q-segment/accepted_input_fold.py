"""Ordered 256-word accepted-stream substitution, with arbitrary retained tail.

This is a mathematical interface lemma. Native admission/row/data/order and
invocation ownership are supplied separately by the checked source adapters.
"""
from common import HERE,bv,both,eq,ext,sha,atomic_bytes,write_frozen


def specification():
    decl=['(declare-const table (Array (_ BitVec 10) (_ BitVec 16)))',
        '(declare-const vector (Array (_ BitVec 8) (_ BitVec 16)))',
        '(declare-const k (_ BitVec 9))','(declare-const watch (_ BitVec 8))','(declare-const word (_ BitVec 16))']
    at=ext('watch',2);index=ext('k',1);row='((_ extract 7 0) k)'
    prefix=f'(=> (bvult {ext("watch",1)} k) (= (select table {at}) (select vector watch)))'
    next_table=f'(store table {index} word)';kn=f'(bvadd k {bv(1,9)})'
    rules={
        'empty-prefix-allows-arbitrary-old-RAM':dict(assumptions=[eq('k',bv(0,9))],conclusion=prefix),
        'one-accepted-word-preserves-prefix':dict(assumptions=[f'(bvult k {bv(256,9)})',prefix,eq('word',f'(select vector {row})')],
            conclusion=f'(=> (bvult {ext("watch",1)} {kn}) (= (select {next_table} {at}) (select vector watch)))'),
        'stalls-do-not-change-prefix':dict(assumptions=[prefix],conclusion=prefix),
        'complete-used-domain-is-exact-reference':dict(assumptions=[prefix,eq('k',bv(256,9))],
            conclusion=eq(f'(select table {at})','(select vector watch)')),
    }
    return decl,'',rules


def prepare():
    label='accepted-input-fold';d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification();atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Accepted-input-fold-pure-array-v1',sources={},native_hardware_theorem=False))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='Accepted-input-fold-pure-array-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',inputs={f:sha((HERE/f).read_bytes()) for f in files},
        declarations=decl,rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':prepare();print('Prepared used-domain accepted-input fold; no assertion about unused retained addresses.')

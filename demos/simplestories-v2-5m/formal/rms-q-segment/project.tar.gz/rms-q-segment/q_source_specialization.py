"""Read-only specialization of the qualified Q theorem to the restored parent.

Restoring previously arbitrary output cuts only restricts the old source traces.
The old inputs are chosen equal to the restored actual outputs, not equated to
unused new formal ports. The native normalizer and exponent projection are the
same source/default/port specializations as in the qualified Q product.
"""
import sys,json,re
from common import HERE,PILOT,sha,atomic_json
from prepare_context import reconstruction,TOP,DP
from prepare import modules
sys.path.insert(0,str(PILOT/'q-operator'))
from q_columns import TOP as OLD
from pruned_arithmetic import parse,emit
from q_check import check_many
from trace_closure import reconstruction as trace_reconstruction,SCHEDULE,plan
from q_normalizer_product import source_binding as normalizer_binding


def verify():
    files,rom,manifest=reconstruction()
    old_dir=PILOT/'model-consumption/connected'
    restored=files['datapath.sv'].decode()
    original=(old_dir/'datapath.sv').read_text()
    projection=[]
    old_native=(old_dir/'native.smt2').read_text();new_native=(HERE/'context/native.smt2').read_text()
    od={x[1]:x for x in parse(old_native) if x[0]=='define-fun'}
    nd={x[1]:x for x in parse(new_native) if x[0]=='define-fun'}
    for item in reversed(manifest['restored_instances']):
        actual=item['actual_instance']
        substituted='\n'.join('    assign '+row['expression']+'='+row['replacement']+';' for row in item['removed_substitutions'])
        if restored.count(actual)!=1:raise ValueError('Restored instance is not unique')
        restored=restored.replace(actual,substituted,1)
        for row in item['removed_substitutions']:
            if row['assumptions']:raise ValueError('Old arbitrary-output abstraction acquired an assumption')
            expression=row['expression']
            old_symbol='|'+OLD+'_n '+DP+expression+'|'
            new_symbol='|'+TOP+'_n '+DP+expression+'|'
            if old_symbol not in od or new_symbol not in nd or od[old_symbol][3]!=nd[new_symbol][3]:
                raise ValueError('Changed source output/getter type '+expression)
            projection.append(dict(instance=item['instance'],old_unrestricted_input=row['replacement'],
                old_observed_source=old_symbol,actual_restored_source=new_symbol,sort=nd[new_symbol][3],
                assignment='At every edge choose the old arbitrary cut input equal to this actual restored output; do not use the retained unused formal input.'))
    if restored!=original:raise ValueError('Outer controller/source differs beyond the exact restored output substitutions')
    for name,data in files.items():
        if name not in ['datapath.sv','rms-segment-native.sv'] and (old_dir/name).read_bytes()!=data:
            raise ValueError('Changed original qualified source file '+name)
    nbind=normalizer_binding()
    actual_norm=next(x['actual_instance'] for x in manifest['restored_instances'] if x['instance']=='u_normalizer')
    if actual_norm!=nbind['original_instance']:raise ValueError('Changed actual Q normalizer instance/ports/defaults')
    old_modules=modules((PILOT/'q-operator/selector/native.sv').read_text())
    new_modules=modules(files['rms-segment-native.sv'].decode())
    if any(new_modules.get(name)!=body for name,body in old_modules.items()):raise ValueError('Changed native Q normalizer source body')
    trace=trace_reconstruction()
    if not trace['all_premises_closed']:raise ValueError('Qualified Q trace no longer closes')
    requests=[(label,None) for label,profile,base,join in SCHEDULE]
    requests += [('q-trace-links',None),('q-trace-bootstrap',None),('q-endpoint-links',None),
        ('q-main-witness',None),('q-frontier-value-r3',None),('q-raw-scope',None),
        ('q-main',[name for name in trace['endpoints'] if name in plan('q-main')['rules']]+['CLEAR-nonzero-exponent-compatible-context'])]
    reports,census=check_many(requests,with_closure=True)
    boundaries=plan('words',True)['root_external_assumptions']
    expected=['vendor application storage behavior','runtime-entry model-image write-fold identity',
        'static metadata-ROM/model binding','named digital RTL/source/clock/reset semantics']
    if boundaries!=expected:raise ValueError('Changed qualified memory/model boundaries')
    return dict(schema='Qualified-Q-restored-parent-source-specialization-v1',source_specialization_checked=True,
        qualified_Q_commit='2d9eaf6c4f176d03849dd35ba6aaed298a20b69e',
        original_parent_TOP=OLD,actual_parent_TOP=TOP,exact_reversible_restoration=True,
        output_trace_projection=projection,all_other_original_source_bytes_unchanged=True,
        native_normalizer_same_source_ports_defaults=True,qualified_normalizer_binding=nbind,
        qualified_Q_trace=trace,reconstructed_receipt_reports=reports,verified_rule_census=census,
        root_boundaries=boundaries,rule='Universal source trace restriction/identical-source hierarchical specialization. Restored child state can be forgotten while its actual outputs instantiate former unconstrained inputs; normalizer state and the unchanged exponent cone instantiate their qualified source projections.',
        trusted_boundary='Native frontend and standard source/module trace restriction, not equality of foreign native SMT state sorts.',
        extra_numerical_environment_assumptions=[],fresh_solver_replay=False,
        normalized_RMS_argument_identity_still_requires_join=True,query_RAM_numerical_join_still_required=True,
        connected_segment_qualified=False,whole_machine_theorem=False)


if __name__=='__main__':
    result=verify();atomic_json(HERE/'Q-SOURCE-SPECIALIZATION.json',result)
    print('Reconstructed qualified Q receipts/trace and checked exact restored-parent source specialization; RMS argument and query RAM joins remain separate.')

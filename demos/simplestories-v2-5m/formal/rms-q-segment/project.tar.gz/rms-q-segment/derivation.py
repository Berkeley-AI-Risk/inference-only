"""Small explicit typed-rule applications; not an SMT or hardware proof kernel.

Only literal substitution, conjunction elimination, reflexivity and closed
bit-vector constant evaluation are supported. Engine implications are supplied
by the separately reconstructed exact receipt checker.
"""
from rms_native_history import parse,emit


def replace(node,names):
    if isinstance(node,list):
        if node and isinstance(node[0],str) and node[0] in ['let','forall','exists','lambda']:
            raise ValueError('Explicit binder specialization required')
        return [replace(x,names) for x in node]
    return parse(names[node])[0] if node in names else node


def literal(node):
    if isinstance(node,str) and node.startswith('#x'):return int(node[2:],16),4*(len(node)-2)
    if isinstance(node,str) and node.startswith('#b'):return int(node[2:],2),len(node)-2
    if isinstance(node,list) and len(node)==3 and node[0]=='_' and isinstance(node[1],str) and node[1].startswith('bv'):
        return int(node[1][2:]),int(node[2])
    return None


def reduce(node):
    v=literal(node)
    if v:return ['_','bv'+str(v[0]%(1<<v[1])),str(v[1])]
    if not isinstance(node,list):return node
    args=[reduce(x) for x in node];head=args[0] if args else None
    values=[literal(x) for x in args[1:]]
    if head in ['bvadd','bvsub'] and len(values)==2 and all(values):
        (a,w),(b,v)=values
        if w!=v:raise ValueError('Constant word width mismatch')
        return ['_','bv'+str((a+b if head=='bvadd' else a-b)%(1<<w)),str(w)]
    if head in ['bvult','bvule'] and len(values)==2 and all(values):
        (a,w),(b,v)=values
        if w!=v:raise ValueError('Constant comparison width mismatch')
        return 'true' if (a<b if head=='bvult' else a<=b) else 'false'
    if isinstance(head,list) and head[:2]==['_','zero_extend'] and len(values)==1 and values[0]:
        a,w=values[0];return ['_','bv'+str(a),str(w+int(head[2]))]
    if isinstance(head,list) and head[:2]==['_','extract'] and len(values)==1 and values[0]:
        a,w=values[0];hi,lo=map(int,head[2:])
        if not 0<=lo<=hi<w:raise ValueError('Invalid constant extraction')
        return ['_','bv'+str((a>>lo)&((1<<(hi-lo+1))-1)),str(hi-lo+1)]
    if head=='=' and len(args)==3 and args[1]==args[2]:return 'true'
    return args


def canonical(text):return emit(reduce(parse(text)[0]))


def conjuncts(text):
    x=parse(text)[0]
    return [z for y in x[1:] for z in conjuncts(emit(y))] if isinstance(x,list) and x[0]=='and' else [canonical(text)]


def instantiate(rule,names):
    return dict(assumptions=[canonical(emit(replace(parse(x)[0],names))) for x in rule['assumptions']],
        conclusion=canonical(emit(replace(parse(rule['conclusion'])[0],names))))


def apply(rule,names,facts):
    if rule.get('expected','unsat')!='unsat':raise ValueError('SAT is not a rule')
    bound=instantiate(rule,names);have={'true'}|{v for f in facts for v in conjuncts(f)}
    absent={v for f in bound['assumptions'] for v in conjuncts(f)}-have
    if absent:raise ValueError('Missing literal-rule premises: '+str(sorted(absent)))
    return dict(substitution=names,assumptions=bound['assumptions'],conclusion=bound['conclusion'],all_premises_closed=True)

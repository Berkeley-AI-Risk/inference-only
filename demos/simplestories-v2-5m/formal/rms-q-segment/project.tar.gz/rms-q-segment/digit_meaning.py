"""Engine-checked word/integer loop invariants for mathematical helper meaning.

The actual helper prefix functions and bit-assembly linkage are separate joins.
These are concrete finite word steps, not an assumed numerical result function.
"""
from common import HERE,bv,both,eq,ext,sha,atomic_bytes,write_frozen
from digit_word_bridge import unsigned


def definitions():
    defs=''
    def add(name,args,sort,rhs):
        return '(define-fun '+name+' ('+args+') '+sort+' '+rhs+')\n'
    args='(q (_ BitVec 23)) (r (_ BitVec 47)) (d (_ BitVec 2))'
    t=f'(bvadd (bvmul r {bv(4,47)}) {ext("d",45)})'
    trial=f'(bvadd (bvmul {ext("q",24)} {bv(4,47)}) {bv(1,47)})'
    take=f'(bvuge {t} {trial})'
    defs+=add('mr-next-q',args,'(_ BitVec 23)',f'(bvadd (bvmul q {bv(2,23)}) (ite {take} {bv(1,23)} {bv(0,23)}))')
    defs+=add('mr-next-r',args,'(_ BitVec 47)',f'(ite {take} (bvsub {t} {trial}) {t})')
    defs+=add('mr-next-p','(p (_ BitVec 46)) (d (_ BitVec 2))','(_ BitVec 46)',f'(bvadd (bvmul p {bv(4,46)}) {ext("d",44)})')
    inv=both(['(> limit 0)',f'(< {unsigned("q")} limit)',
        eq(unsigned('p'),f'(+ (* {unsigned("q")} {unsigned("q")}) {unsigned("r")})'),
        f'(< {unsigned("r")} (+ (* 2 {unsigned("q")}) 1))'])
    defs+=add('mr-inv','(q (_ BitVec 23)) (r (_ BitVec 47)) (p (_ BitVec 46)) (limit Int)','Bool',inv)
    args='(q (_ BitVec 64)) (r (_ BitVec 65)) (b (_ BitVec 1)) (den (_ BitVec 64))'
    t=f'(bvadd (bvmul r {bv(2,65)}) {ext("b",64)})';take=f'(bvuge {t} {ext("den",1)})'
    defs+=add('md-next-q',args,'(_ BitVec 64)',f'(bvadd (bvmul q {bv(2,64)}) (ite {take} {bv(1,64)} {bv(0,64)}))')
    defs+=add('md-next-r',args,'(_ BitVec 65)',f'(ite {take} (bvsub {t} {ext("den",1)}) {t})')
    defs+=add('md-next-p','(p (_ BitVec 28)) (b (_ BitVec 1))','(_ BitVec 28)',f'(bvadd (bvmul p {bv(2,28)}) {ext("b",27)})')
    inv=both([f'(> {unsigned("den")} 0)',f'(< {unsigned("q")} 268435456)',
        eq(unsigned('p'),f'(+ (* {unsigned("q")} {unsigned("den")}) {unsigned("r")})'),
        f'(< {unsigned("r")} {unsigned("den")})'])
    defs+=add('md-inv','(q (_ BitVec 64)) (r (_ BitVec 65)) (p (_ BitVec 28)) (den (_ BitVec 64))','Bool',inv)
    return defs


def specification():
    decl=['(declare-const rq (_ BitVec 23))','(declare-const rr (_ BitVec 47))',
          '(declare-const rp (_ BitVec 46))','(declare-const rd (_ BitVec 2))','(declare-const limit Int)',
          '(declare-const dq (_ BitVec 64))','(declare-const dr (_ BitVec 65))',
          '(declare-const dp (_ BitVec 28))','(declare-const db (_ BitVec 1))','(declare-const den (_ BitVec 64))']
    rules={
        'root-zero-prefix-invariant':dict(assumptions=[],conclusion=f'(mr-inv {bv(0,23)} {bv(0,47)} {bv(0,46)} 1)'),
        'root-word-integer-invariant-preserved':dict(assumptions=['(mr-inv rq rr rp limit)',
            '(<= limit 4194304)',f'(< {unsigned("rp")} 17592186044416)'],
            conclusion='(mr-inv (mr-next-q rq rr rd) (mr-next-r rq rr rd) (mr-next-p rp rd) (* 2 limit))'),
        'root-final-is-floor-square-interval':dict(assumptions=['(mr-inv rq rr rp limit)'],
            conclusion=both([f'(<= (* {unsigned("rq")} {unsigned("rq")}) {unsigned("rp")})',
                f'(< {unsigned("rp")} (* (+ {unsigned("rq")} 1) (+ {unsigned("rq")} 1)))'])),
        'divider-zero-prefix-invariant':dict(assumptions=[f'(distinct den {bv(0,64)})'],
            conclusion=f'(md-inv {bv(0,64)} {bv(0,65)} {bv(0,28)} den)'),
        'divider-word-integer-invariant-preserved':dict(assumptions=['(md-inv dq dr dp den)',
            f'(< {unsigned("dp")} 134217728)'],
            conclusion='(md-inv (md-next-q dq dr db den) (md-next-r dq dr db den) (md-next-p dp db) den)'),
        'divider-final-is-Euclidean-division':dict(assumptions=['(md-inv dq dr dp den)'],
            conclusion=both([eq(unsigned('dp'),f'(+ (* {unsigned("dq")} {unsigned("den")}) {unsigned("dr")})'),
                f'(>= {unsigned("dr")} 0)',f'(< {unsigned("dr")} {unsigned("den")})'])),
    }
    return decl,definitions(),rules


def prepare():
    label='digit-meaning';d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification();atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Pure-word-integer-loop-invariants-v1',sources={},
        native_hardware_theorem=False,scope='Concrete digit word-step mathematical invariants; prefix/instance composition required'))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='RMS-Q-word-integer-induction-lemmas-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',
        inputs={f:sha((HERE/f).read_bytes()) for f in files},declarations=decl,
        rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':prepare();print('Prepared explicit word/integer root and division loop invariants.')

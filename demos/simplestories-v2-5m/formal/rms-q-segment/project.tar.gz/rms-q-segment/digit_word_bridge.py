"""Exact finite word-to-integer bridges for the two digit procedures.

Bounds are the independent prefix invariants, not expected helper replies.
These lemmas connect the already-checked word algorithms to integer digit laws;
the full prefix/iteration and RMS arithmetic composition remains explicit work.
"""
from common import HERE,bv,both,eq,ext,sha,atomic_bytes,write_frozen


def unsigned(x):return '(bv2int '+x+')'


def signed64(x):
    return f'(ite (= ((_ extract 63 63) {x}) #b1) (- {unsigned(x)} 18446744073709551616) {unsigned(x)})'


def specification():
    decl=['(declare-const rq (_ BitVec 23))','(declare-const rr (_ BitVec 47))',
          '(declare-const rd (_ BitVec 2))','(declare-const dq (_ BitVec 64))',
          '(declare-const dr (_ BitVec 65))','(declare-const dd (_ BitVec 64))',
          '(declare-const db (_ BitVec 1))','(declare-const negative Bool)']
    rules={}
    t=f'(bvadd (bvmul rr {bv(4,47)}) {ext("rd",45)})'
    trial=f'(bvadd (bvmul {ext("rq",24)} {bv(4,47)}) {bv(1,47)})'
    take=f'(bvuge {t} {trial})'
    qn=f'(bvadd (bvmul rq {bv(2,23)}) (ite {take} {bv(1,23)} {bv(0,23)}))'
    rn=f'(ite {take} (bvsub {t} {trial}) {t})'
    ti=f'(+ (* 4 {unsigned("rr")}) {unsigned("rd")})'
    di=f'(+ (* 4 {unsigned("rq")}) 1)';choice=f'(>= {ti} {di})'
    rootctx=[f'(< {unsigned("rq")} 4194304)',f'(< {unsigned("rr")} (+ (* 2 {unsigned("rq")}) 1))']
    rules['root-word-step-is-integer-digit-step']=dict(assumptions=rootctx,
        conclusion=both([eq(unsigned(t),ti),eq(unsigned(trial),di),eq(take,choice),
            eq(unsigned(qn),f'(+ (* 2 {unsigned("rq")}) (ite {choice} 1 0))'),
            eq(unsigned(rn),f'(ite {choice} (- {ti} {di}) {ti})')]))
    t=f'(bvadd (bvmul dr {bv(2,65)}) {ext("db",64)})'
    take=f'(bvuge {t} {ext("dd",1)})'
    qn=f'(bvadd (bvmul dq {bv(2,64)}) (ite {take} {bv(1,64)} {bv(0,64)}))'
    rn=f'(ite {take} (bvsub {t} {ext("dd",1)}) {t})'
    ti=f'(+ (* 2 {unsigned("dr")}) {unsigned("db")})';choice=f'(>= {ti} {unsigned("dd")})'
    divctx=[f'(> {unsigned("dd")} 0)',f'(< {unsigned("dr")} {unsigned("dd")})',f'(< {unsigned("dq")} 268435456)']
    rules['divider-word-step-is-integer-digit-step']=dict(assumptions=divctx,
        conclusion=both([eq(unsigned(t),ti),eq(take,choice),
            eq(unsigned(qn),f'(+ (* 2 {unsigned("dq")}) (ite {choice} 1 0))'),
            eq(unsigned(rn),f'(ite {choice} (- {ti} {unsigned("dd")}) {ti})')]))
    twice=f'(bvmul dr {bv(2,65)})'
    up=f'(or (bvugt {twice} {ext("dd",1)}) (and (= {twice} {ext("dd",1)}) (= ((_ extract 0 0) dq) #b1)))'
    rounded=f'(bvadd dq (ite {up} {bv(1,64)} {bv(0,64)}))'
    iup=f'(or (> (* 2 {unsigned("dr")}) {unsigned("dd")}) (and (= (* 2 {unsigned("dr")}) {unsigned("dd")}) (= (mod {unsigned("dq")} 2) 1)))'
    im=f'(+ {unsigned("dq")} (ite {iup} 1 0))'
    rules['divider-final-word-rounding-is-RNE']=dict(assumptions=divctx,
        conclusion=both([eq(up,iup),eq(unsigned(rounded),im)]))
    value=f'(ite negative (bvneg {rounded}) {rounded})'
    rules['divider-final-sign-is-exact-integer-sign']=dict(assumptions=divctx,
        conclusion=eq(signed64(value),f'(ite negative (- {im}) {im})'))
    return decl,'',rules


def prepare():
    label='digit-word-bridge';d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification();atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Pure-word-integer-bridge-v1',sources={},
        native_hardware_theorem=False,scope='Finite-word interpretations under proved digit prefix bounds'))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='RMS-Q-word-integer-implications-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',
        inputs={f:sha((HERE/f).read_bytes()) for f in files},declarations=decl,
        rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':prepare();print('Prepared exact word/integer digit and signed rounding bridges.')

"""Mathematical digit-algorithm invariants and legal RMS-domain bounds.

These are pure integer lemmas, separate from the native producer relations.
They supply the readable meaning/ranges for the later exact word/instance join.
No whole RMS or hardware result is inferred merely from these lemmas.
"""
from common import HERE,both,sha,atomic_bytes,write_frozen


def specification():
    names=['p','q','r','digit','den','limit','q_other','r_other','a','k','total',
           'term','mean','epsilon','coefficient','scale','product','raw','candidate','source_exp']
    decl=['(declare-const '+n+' Int)' for n in names]
    rules={}
    root_ctx=['(>= q 0)','(>= r 0)','(< r (+ (* 2 q) 1))','(>= digit 0)','(<= digit 3)',
              '(= p (+ (* q q) r))']
    t='(+ (* 4 r) digit)';trial='(+ (* 4 q) 1)'
    for take in [False,True]:
        qn='(+ (* 2 q) '+('1' if take else '0')+')'
        rn='(- '+t+' '+trial+')' if take else t
        rules['root-digit-'+('take' if take else 'skip')]=dict(
            assumptions=root_ctx+['('+('>=' if take else '<')+' '+t+' '+trial+')'],
            conclusion=both(['(= (+ (* 4 p) digit) (+ (* '+qn+' '+qn+') '+rn+'))',
                             '(>= '+qn+' 0)','(>= '+rn+' 0)','(< '+rn+' (+ (* 2 '+qn+') 1))']))
    root_final=['(>= q 0)','(>= r 0)','(< r (+ (* 2 q) 1))','(= p (+ (* q q) r))']
    rules['root-final-floor-square-interval']=dict(assumptions=root_final,
        conclusion=both(['(<= (* q q) p)','(< p (* (+ q 1) (+ q 1)))']))
    rules['positive-radicand-has-positive-root']=dict(assumptions=root_final+['(>= p 1)'],conclusion='(>= q 1)')
    rules['root-prefix-width-doubles']=dict(assumptions=['(> limit 0)','(>= q 0)','(< q limit)','(>= digit 0)','(<= digit 1)'],
        conclusion=both(['(>= (+ (* 2 q) digit) 0)','(< (+ (* 2 q) digit) (* 2 limit))']))
    div_ctx=['(> den 0)','(>= q 0)','(>= r 0)','(< r den)','(>= digit 0)','(<= digit 1)',
             '(= p (+ (* q den) r))']
    t='(+ (* 2 r) digit)'
    for take in [False,True]:
        qn='(+ (* 2 q) '+('1' if take else '0')+')';rn='(- '+t+' den)' if take else t
        rules['divider-digit-'+('take' if take else 'skip')]=dict(
            assumptions=div_ctx+['('+('>=' if take else '<')+' '+t+' den)'],
            conclusion=both(['(= (+ (* 2 p) digit) (+ (* '+qn+' den) '+rn+'))',
                             '(>= '+qn+' 0)','(>= '+rn+' 0)','(< '+rn+' den)']))
    rules['Euclidean-quotient-and-remainder-unique']=dict(assumptions=div_ctx[:4]+[
        '(= p (+ (* q den) r))','(= p (+ (* q_other den) r_other))',
        '(>= q_other 0)','(>= r_other 0)','(< r_other den)'],
        conclusion=both(['(= q q_other)','(= r r_other)']))
    rules['bounded-prefix-quotient-fits']=dict(assumptions=div_ctx[:4]+[
        '(= p (+ (* q den) r))','(< p 268435456)'],conclusion='(< q 268435456)')
    rules['divider-RNE-increment-fits-signed64']=dict(assumptions=['(>= q 0)','(< q 268435456)',
        '(>= digit 0)','(<= digit 1)'],conclusion=both(['(>= (+ q digit) 0)','(< (+ q digit) 9223372036854775808)']))
    rules['legal-activation-square-bound']=dict(assumptions=['(>= a (- 32767))','(<= a 32767)'],
        conclusion=both(['(>= (* a a) 0)','(<= (* a a) 1073676289)']))
    rules['square-prefix-integer-bound']=dict(assumptions=['(>= k 0)','(< k 256)','(>= total 0)',
        '(<= total (* k 1073676289))','(>= term 0)','(<= term 1073676289)'],
        conclusion=both(['(>= (+ total term) 0)','(<= (+ total term) (* (+ k 1) 1073676289))',
                         '(< (+ total term) 274877906944)']))
    rules['mean-epsilon-radicand-fits45']=dict(assumptions=['(>= mean 0)','(< mean 1073741824)',
        '(>= epsilon 0)','(<= epsilon 17592186044416)'],
        conclusion=both(['(>= (ite (= (+ mean epsilon) 0) 1 (+ mean epsilon)) 1)',
                         '(< (ite (= (+ mean epsilon) 0) 1 (+ mean epsilon)) 35184372088832)']))
    rules['legal-divider-numerator-strong-bound']=dict(assumptions=['(>= a (- 32767))','(<= a 32767)'],
        conclusion=both(['(> (* a 4096) (- 134217728))','(< (* a 4096) 134217728)']))
    rules['clamp-output-legal16']=dict(assumptions=[],conclusion=both([
        '(>= (ite (< a (- 32767)) (- 32767) (ite (> a 32767) 32767 a)) (- 32767))',
        '(<= (ite (< a (- 32767)) (- 32767) (ite (> a 32767) 32767 a)) 32767)']))
    rules['weighted-product-fits26']=dict(assumptions=['(>= a (- 32767))','(<= a 32767)',
        '(>= coefficient (- 511))','(<= coefficient 511)'],
        conclusion=both(['(>= (* a coefficient) (- 16743937))','(<= (* a coefficient) 16743937)',
                         '(> (* a coefficient) (- 33554432))','(< (* a coefficient) 33554432)']))
    rules['scaled-raw-fits-native39-limit']=dict(assumptions=['(>= product (- 16743937))','(<= product 16743937)',
        '(> scale 0)','(< scale 32768)'],
        conclusion=both(['(> (* product scale) (- 549755813888))','(< (* product scale) 549755813888)']))
    rules['fixed-RMS-source-exponents-and-shift-domain']=dict(assumptions=[
        '(or (= source_exp (- 35)) (= source_exp (- 34)))','(>= candidate (- 32))','(<= candidate 31)'],
        conclusion=both(['(>= (- candidate source_exp) 2)','(<= (- candidate source_exp) 66)',
                         '(>= source_exp (- 128))','(<= source_exp 127)']))
    return decl,'',rules


def prepare():
    label='integer-algorithms';d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification();atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Pure-mathematical-meaning-lemmas-v1',
        sources={},native_hardware_theorem=False,scope='Independent integer arithmetic and domain lemmas only'))
    paths=[label+'-SOURCES.json',label+'/meaning.smt2']
    plan=dict(schema='RMS-Q-pure-integer-implications-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',
        inputs={p:sha((HERE/p).read_bytes()) for p in paths},declarations=decl,
        rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False)
    write_frozen(HERE/(label+'-PLAN.json'),plan)


if __name__=='__main__':prepare();print('Prepared independent integer digit laws and RMS legal-domain bounds.')

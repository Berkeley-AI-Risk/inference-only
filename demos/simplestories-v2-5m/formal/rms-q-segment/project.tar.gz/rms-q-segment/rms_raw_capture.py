"""Connect the independent RMS scalar records to the real normalizer capture.

The model array is the fixed ROM extension: all 13*256 consumed entries are
bound to the independently decoded release image; unused ROM entries are outside
this algorithm. The port/source ROM binding and its invariant are explicit.
"""
from common import HERE,bv,both,eq,ext,save_plan
from rms_local import LOCAL,to_local,prepare
from rms_scalar_algorithm import definitions as scalar_definitions
from rms_square_fold import definitions as square_definitions
from normalizer_instance import definitions as norm_definitions,PREFIX
from rms_native_history import parse,emit
from rms_capture import r
from rms_read_words import phase

S='|'+LOCAL+'_s|'
R=lambda field,a='a':to_local(r(field,a))
N=lambda field,a='a':f'(|{LOCAL}_n {PREFIX+field}| {a})'
MODEL='(Array (_ BitVec 12) (_ BitVec 34))'
CERT='(Array (_ BitVec 9) (_ BitVec 38))'
ROM=lambda a='a':f'(|{LOCAL}_m u_norm_rom.norm_rom| {a})'


def merge(parts):
    result=[];seen={}
    for text in parts:
        for x in parse(text):
            if x[0]=='declare-datatypes':key=tuple(y[0] for y in x[2])
            elif x[0]in ['define-fun','declare-fun']:key=x[1]
            else:raise ValueError('Unexpected mathematical declaration')
            if key in seen:
                if seen[key]!=x:raise ValueError('Changed duplicate mathematical definition '+str(key))
            else:result.append(x);seen[key]=x
    return '\n'.join(emit(x) for x in result)+'\n'


def definitions():
    defs=merge([scalar_definitions()[0],to_local(square_definitions()),norm_definitions()])
    word='(select model (concat (h-role h) ((_ extract 7 0) row)))'
    root=f'(root-value (rms-radicand (select c {bv(256,9)}) (h-exponent h)))'
    num='(rms-numerator (select (h-vector h) ((_ extract 7 0) row)))'
    normalized=f'(rms-clamp (div-value {num} {ext(root,41)}))'
    raw=f'(rms-scaled {normalized} ((_ extract 9 0) {word}) ((_ extract 25 10) {word}))'
    exponent=f'(bvsub ((_ extract 33 26) {word}) {bv(27,8)})'
    args=f'((h History) (c {CERT}) (model {MODEL}) (row (_ BitVec 10)))'
    defs+=f'(define-fun RMS-record {args} (_ BitVec 58) (concat {exponent} {raw}))\n'
    args=f'((a {S}) (h History) (c {CERT}) (nc NormCapture) (model {MODEL}) (watch (_ BitVec 10)))'
    live=both([R('rst_n'),'(not (failed a))','(square-certificate (h-vector h) c)'])
    active=to_local(phase(*range(8,15)))
    count=f'(ite {to_local(phase(14))} {bv(256,10)} {ext(R("lane_index_q"),2)})'
    clauses=[f'(=> {active} '+both([eq('(nc-rows nc)',bv(256,10)),eq('(nc-job nc)',bv(0,4)),eq('(nc-layer nc)',R('layer_q'))])+')',
        f'(=> {active} {eq("(nc-count nc)",count)})',
        f'(=> (and {active} (bvult watch (nc-count nc))) {eq("(select (nc-vec nc) watch)","(RMS-record h c model watch)")})']
    for i,c in enumerate(clauses):defs+=f'(define-fun rn-clause-{i} {args} Bool (=> {live} {c}))\n'
    defs+=f'(define-fun rn-inv {args} Bool '+both([f'(rn-clause-{i} a h c nc model watch)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda a:f'(|{LOCAL}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h History)','(declare-const hn History)',
        '(declare-const rh RootHistory)','(declare-const dh DivHistory)','(declare-const nc NormCapture)','(declare-const ncn NormCapture)',
        f'(declare-const c {CERT})',f'(declare-const model {MODEL})','(declare-const watch (_ BitVec 10))']
    ctx=[H('a'),H('an'),f'(|{LOCAL}_t| a an)']
    bound=eq('model',ROM());boundn=eq('model',ROM('an'))
    rules={'model-ROM-extension-held':dict(assumptions=ctx+[bound],conclusion=boundn),
        'common-reset-base':dict(assumptions=ctx+[f'(not {R("rst_n")})'],conclusion='(rn-inv an history-zero c nc-zero model watch)')}
    providers=['(rms-u-inv a)','(rms-u-inv an)','(rms-h-inv a h)','(rms-h-inv an hn)',
        '(rw-inv a h)','(sq-inv a h c)','(rsa-inv a h rh dh)','(nc-inv a nc)','(nc-inv an ncn)',
        eq('hn','(history-next a an h)'),eq('ncn','(nc-next a nc)'),bound,boundn]
    live=both([R('rst_n'),'(not (failed a))','(square-certificate (h-vector h) c)'])
    fire=both([N('input_valid_i'),N('input_ready_o')])
    rawgoal=eq(f'(concat {N("input_source_exponent_i")} {N("input_raw_i")})',f'(RMS-record h c model {ext(R("lane_index_q"),2)})')
    rawcontext=[H('a'),live,'(rms-u-inv a)','(rms-h-inv a h)','(rw-inv a h)',
        '(sq-inv a h c)','(rsa-inv a h rh dh)',bound,to_local(phase(13))]
    rules['actual-held-scalar-record-is-profile']=dict(assumptions=rawcontext,conclusion=rawgoal)
    scalar_fact=f'(=> '+both([live,to_local(phase(13))])+' '+rawgoal+')'
    for i in range(len(clauses)):
        rules['preserved-'+str(i)]=dict(assumptions=ctx+providers+[scalar_fact,'(rn-inv a h c nc model watch)'],
            conclusion=f'(rn-clause-{i} an hn c ncn model watch)')
    rules['parts-join']=dict(assumptions=[f'(rn-clause-{i} an hn c ncn model watch)' for i in range(len(clauses))],
        conclusion='(rn-inv an hn c ncn model watch)')
    rules['actual-complete-normalizer-vector-is-profile']=dict(assumptions=[H('a'),live,to_local(phase(14)),
        '(rn-inv a h c nc model watch)',f'(bvult watch {bv(256,10)})'],
        conclusion=both([eq('(nc-count nc)',bv(256,10)),eq('(nc-rows nc)',bv(256,10)),
            eq('(select (nc-vec nc) watch)','(RMS-record h c model watch)')]))
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('rms-raw-capture',*specification(),native_label='rms-local')
    print('Prepared actual whole RMS raw-vector capture and model-ROM extension binding.')

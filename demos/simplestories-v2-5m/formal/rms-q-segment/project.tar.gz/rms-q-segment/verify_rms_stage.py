"""Reconstruct the RMS component's full arithmetic-to-normalizer argument.

This is a component certificate, not connected RMS-to-Q qualification. The Q
source specialization, persistent normalized vector and query-RAM join remain
explicit obligations of the authorized milestone.
"""
import json
from common import HERE,atomic_json,sha
from arithmetic_trace import reconstruct
from verify_rms_meaning import verify
from verify_digit_meaning import main as helper_meaning
from rms_local import complete_instance_binding


def main():
    # Each entry reconstructs formulas, raw engine replies and actual source
    # mappings. A previously saved PASS flag is never an imported theorem.
    helper_meaning()
    integer=verify();trace=reconstruct()
    if not trace['regular_step_closed'] or not trace['reset_bases_checked'] or len(trace['actual_RMS_algorithm_endpoints'])!=3:
        raise ValueError('Incomplete RMS trace/endpoint derivation')
    result=dict(schema='Actual-RMS-independent-algorithm-component-certificate-v1',component_argument_checked=True,
        statement='Every actual held/transferred RMS result refines the independent whole-vector normalization algorithm on the fixed-role scalar records of its complete accepted input. Actual RMS DONE has 256 emitted values. The accepted input is tied to the actual stage-entry snapshot by the caller gate.',
        integer_profile=integer,helper_mathematical_meaning=json.loads((HERE/'HELPER-MEANING-RESULT.json').read_text()),
        source_trace=trace,complete_source_binding=complete_instance_binding(),
        trusted_rules=['Native RTL frontend and named digital/source/clock/reset/DSP semantics','Engine trust',
            'Standard identical-source hierarchical module theorem instantiation','Explicit typed SMT-LIB word interpretation and finite induction/specialization'],
        no_whole_RMS_raw_UNSAT_receipt=True,connected_segment_qualified=False,whole_machine_theorem=False,
        remaining=['Carry the independently normalized result through the retained RMS store and actual Q argument snapshot',
            'Specialize the qualified Q theorem to the restored real parent',
            'Join Q numerical writes to retained query RAM and pre-overwrite reads',
            'Clean portable qualification and scoped publication'])
    atomic_json(HERE/'RMS-STAGE-CERTIFICATE.json',result)
    print('RMS component arithmetic/normalizer argument reconstructed; connected RMS-to-Q segment remains unqualified.')


if __name__=='__main__':main()

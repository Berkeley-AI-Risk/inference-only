"""Retain qualified independent Q outputs in actual query RAM and its reads.

Reference writes use pure Q NormAlgorithm/QArguments witnesses supplied by the
qualified operator theorem. They never copy a DUT result as expected data.
Every other query write revokes that row's unrotated-Q authority; the actual
source classifier identifies those other writes as Q-RoPE. Reads sample the
pre-write value and reference, including simultaneous read/write cases.
"""
from common import HERE,PILOT,bv,both,eq,save_plan
from parent_flow import TOP,S,DP,d
from query_memory import definitions as memory_definitions,M
from rms_native_history import parse,emit
from normalizer_instance import definitions as norm_definitions
from prepare_context import prepare

ARRAYS=[('value','(_ BitVec 16)'),('exponent','(_ BitVec 8)'),('valid','Bool'),
    ('generation','Int'),('layer','(_ BitVec 3)'),('position','(_ BitVec 11)'),
    ('arguments','QArguments'),('algorithm','NormAlgorithm')]


def definitions():
    defs=memory_definitions()
    normalizer=parse(norm_definitions())
    qargs=parse((PILOT/'q-operator/q-arguments-r3/history.smt2').read_text())
    for kind,nodes in [('NormAlgorithm',normalizer),('QArguments',qargs)]:
        defs+=emit(next(x for x in nodes if x[0]=='declare-datatypes' and x[2][0][0]==kind))+'\n'
    for name,nodes in [('na-zero',normalizer),('qa-zero',qargs)]:
        defs+=emit(next(x for x in nodes if x[:2]==['define-fun',name]))+'\n'
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    qwrite=both([d('query_ram_write_enable'),qmode])
    defs+=f'(define-fun qnum-write ((a {S})) Bool {qwrite})\n'
    binding=both([eq(d('norm_result_mantissa'),'(na-mantissa qna)'),eq(d('norm_result_exponent'),'(na-candidate qna)'),
        eq('((_ extract 7 0) '+d('output_index_q')+')','((_ extract 7 0) (na-scan qna))'),
        eq('(na-phase qna)',bv(5,3)),eq('(na-rows qna)',bv(256,10)),eq('(na-emitted qna)','(na-scan qna)'),
        f'(bvult (na-scan qna) {bv(256,10)})','(qa-owned qa)','(qa-complete qa)',eq('(qa-layer qa)',d('current_layer_q'))])
    defs+=f'(define-fun qnum-producer ((a {S}) (qa QArguments) (qna NormAlgorithm)) Bool (=> (qnum-write a) {binding}))\n'
    fields=[('qnum-'+name,'(Array (_ BitVec 8) '+sort+')') for name,sort in ARRAYS]
    fields += [('qnum-read-'+name,sort) for name,sort in ARRAYS]+[('qnum-read-row','(_ BitVec 8)')]
    defs+='(declare-datatypes () ((QueryNumeric (query-numeric '+' '.join('('+name+' '+sort+')' for name,sort in fields)+'))))\n'
    zeros=[bv(0,16),bv(0,8),'false','0',bv(0,3),bv(0,11),'qa-zero','na-zero']
    const=lambda sort,x:'((as const (Array (_ BitVec 8) '+sort+')) '+x+')'
    defs+='(define-fun qnum-zero () QueryNumeric (query-numeric '+' '.join([const(sort,x) for (name,sort),x in zip(ARRAYS,zeros,strict=True)]+zeros+[bv(0,8)])+'))\n'
    wr='((_ extract 7 0) (na-scan qna))';actual_wr='((_ extract 7 0) '+d('output_index_q')+')';rd=d('query_ram_read_address')
    invalidate=both([d('stage_accept'),eq(d('private_stage_i'),bv(1,5))])
    revoke=f'(or {d("clear_i")} {invalidate})'
    values=['(na-mantissa qna)','(na-candidate qna)','true','(rs-generation rs)',d('current_layer_q'),d('current_position_q'),'qa','qna']
    arrays=[]
    for (name,sort),value in zip(ARRAYS,values,strict=True):
        ordinary=f'(ite (qnum-write a) (store (qnum-{name} h) {wr} {value}) (qnum-{name} h))'
        if name=='valid':
            ordinary=f'(ite {revoke} {const(sort,"false")} (ite {d("query_ram_write_enable")} (store (qnum-valid h) {actual_wr} (qnum-write a)) (qnum-valid h)))'
        arrays.append(ordinary)
    reads=[f'(ite {d("query_ram_read_enable")} (select (qnum-{name} h) {rd}) (qnum-read-{name} h))' for name,sort in ARRAYS]
    reads[2]=f'(ite {revoke} false {reads[2]})'
    reads.append(f'(ite {d("query_ram_read_enable")} {rd} (qnum-read-row h))')
    args=f'((a {S}) (rs RMSSnapshot) (qa QArguments) (qna NormAlgorithm) (h QueryNumeric))'
    defs+=f'(define-fun qnum-next {args} QueryNumeric (ite (not {d("rst_n")}) qnum-zero (query-numeric '+' '.join(arrays+reads)+')))\n'
    ref=lambda field:f'(select (qnum-{field} h) watch)'
    props=lambda val,exp,arg,alg,row,layer:both([eq(val,f'(na-mantissa {alg})'),eq(exp,f'(na-candidate {alg})'),
        eq(row,f'((_ extract 7 0) (na-scan {alg}))'),eq(f'(na-phase {alg})',bv(5,3)),eq(f'(na-rows {alg})',bv(256,10)),
        f'(bvult (na-scan {alg}) {bv(256,10)})',f'(qa-owned {arg})',f'(qa-complete {arg})',eq(f'(qa-layer {arg})',layer)])
    row=both([eq(f'(select {M()} watch)',ref('value')),
        props(ref('value'),ref('exponent'),ref('arguments'),ref('algorithm'),'watch',ref('layer'))])
    read=both([eq(d('query_ram_read_data'),'(qnum-read-value h)'),
        props('(qnum-read-value h)','(qnum-read-exponent h)','(qnum-read-arguments h)','(qnum-read-algorithm h)','(qnum-read-row h)','(qnum-read-layer h)')])
    defs+=f'(define-fun qnum-row-inv ((a {S}) (h QueryNumeric) (watch (_ BitVec 8))) Bool (=> (and {d("rst_n")} (select (qnum-valid h) watch)) {row}))\n'
    defs+=f'(define-fun qnum-read-inv ((a {S}) (h QueryNumeric)) Bool (=> (and {d("rst_n")} (qnum-read-valid h)) {read}))\n'
    defs+=f'(define-fun qnum-inv ((a {S}) (h QueryNumeric) (watch (_ BitVec 8))) Bool (and (qnum-row-inv a h watch) (qnum-read-inv a h)))\n'
    return defs


def specification():
    defs=definitions();H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const rs RMSSnapshot)',
        '(declare-const qa QArguments)','(declare-const qna NormAlgorithm)',
        '(declare-const h QueryNumeric)','(declare-const hn QueryNumeric)','(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    relation=eq('hn','(qnum-next a rs qa qna h)')
    # Physical read samples another arbitrary row. The uniform row family
    # supplies its current invariant at the actual request address too.
    readrow=d('query_ram_read_address')
    step=ctx+['(qnum-inv a h watch)',f'(qnum-row-inv a h {readrow})',relation,'(qnum-producer a qa qna)']
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(qnum-inv an qnum-zero watch)'),
        'row-preserved':dict(assumptions=step,conclusion='(qnum-row-inv an hn watch)'),
        'read-preserved':dict(assumptions=step,conclusion='(qnum-read-inv an hn)'),
        'parts-join':dict(assumptions=['(qnum-row-inv an hn watch)','(qnum-read-inv an hn)'],conclusion='(qnum-inv an hn watch)'),
        'actual-retained-unrotated-Q-row-is-independent-result':dict(assumptions=[H('a'),d('rst_n'),'(qnum-inv a h watch)','(select (qnum-valid h) watch)'],
            conclusion=both([eq(f'(select {M()} watch)','(select (qnum-value h) watch)'),
                eq('(select (qnum-value h) watch)','(na-mantissa (select (qnum-algorithm h) watch))')])),
        'actual-tagged-read-is-independent-saved-Q-result':dict(assumptions=[H('a'),d('rst_n'),'(qnum-inv a h watch)','(qnum-read-valid h)'],
            conclusion=both([eq(d('query_ram_read_data'),'(qnum-read-value h)'),
                eq('(qnum-read-value h)','(na-mantissa (qnum-read-algorithm h))')])),
        'other-query-writes-revoke-unrotated-Q-row':dict(assumptions=[d('rst_n'),relation,d('query_ram_write_enable'),'(not (qnum-write a))'],
            conclusion='(not (select (qnum-valid hn) ((_ extract 7 0) '+d('output_index_q')+')))'),
        'CLEAR-revokes-numerical-row-and-read-authority':dict(assumptions=[d('rst_n'),d('clear_i'),relation],
            conclusion=both(['(not (select (qnum-valid hn) watch))','(not (qnum-read-valid hn))'])),
    }
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('query-numeric-store',*specification(),native_label='context')
    print('Prepared retained independent Q result, saved input/program witness, read-before-write and overwrite/CLEAR rules.')

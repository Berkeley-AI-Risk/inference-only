"""Global immutable QA-owner metadata between its exact revocation events."""
from common import both,eq,save_plan
from parent_flow import TOP,S,d
from rms_q_argument import specification as argument_spec
from prepare_context import prepare


def specification():
    decl,defs,_=argument_spec(4);decl+=[f'(declare-const an {S})']
    H=lambda a:f'(|{TOP}_h| {a})'
    norevoke=both([d('rst_n'),'(not '+d('clear_i')+')','(not '+d('stage_accept')+')','(not '+d('head_start_accept')+')'])
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)',norevoke,d('rst_n','an')]
    rules={
        'no-QA-revocation-holds-actual-layer-and-position':dict(assumptions=ctx,
            conclusion=both([eq(d('current_layer_q','an'),d('current_layer_q')),eq(d('current_position_q','an'),d('current_position_q'))])),
        'no-QA-revocation-holds-RMS-generation':dict(assumptions=[H('a'),norevoke],
            conclusion=eq('(rs-generation (rs-next a rs))','(rs-generation rs)')),
    }
    return decl,defs,rules


if __name__=='__main__':prepare();save_plan('q-origin-source',*specification(),native_label='context')

"""Restore the segment's actual RAM and RMS/normalizer producers in its parent.

Start from the previously source-qualified parent abstraction, reverse exactly
five named output substitutions, and add exact native module bodies. Remaining
unrestricted numerical leaves remain explicit. This command translates, not
proves, the resulting source context.
"""
import json
import re
import subprocess
import sys
import time
from common import HERE, PILOT, sha, atomic_bytes, write_frozen
from source_policy import PUBLIC, native_source
from build_connected_parent import reconstruct
from build_semantic_window import NATIVE
from prepare import SOURCES as RMS_MODULES, ROM

TOP='rms_q_context'
DP='u_native.u_six_layers.u_datapath.'
SEQ='u_native.u_six_layers.u_sequence.'
DATAPATH='fpga/token_only_model0_ddr_board1/context2048_token_machine0/rtl/board1_context2048_semantic_datapath.sv'
RAMFILE='fpga/token_only_model0_ddr_board1/fixed_semantic_layer0/rtl/board1_fixed_semantic_vector256_ram.sv'
RESTORE={'u_hidden_state':'board1_fixed_semantic_vector256_ram',
         'u_rms_scratch':'board1_fixed_semantic_vector256_ram',
         'u_query_state':'board1_fixed_semantic_vector256_ram',
         'u_rmsnorm':'board1_fixed_vector_rmsnorm_service',
         'u_normalizer':'board1_fixed_vector_normalizer'}


def reconstruction():
    files,prior=reconstruct()
    frozen=json.loads((PILOT/'model-consumption/connected-SOURCES.json').read_text())
    for name,data in files.items():
        if sha(data)!=frozen['files'][name] or (PILOT/'model-consumption/connected'/name).read_bytes()!=data:
            raise ValueError('Prior connected source changed: '+name)
    actual=(PUBLIC/DATAPATH).read_text()
    if actual!=(NATIVE/'production-datapath.sv').read_text():
        raise ValueError('Different actual datapath')
    oldcuts=json.loads((NATIVE/'INPUTS.json').read_text())['internal_cuts']
    parent=files['datapath.sv'].decode()
    restored=[]
    for inst,module in RESTORE.items():
        pattern=r'^    '+module+r'\s+'+inst+r'\s*\([\s\S]*?^    \);'
        blocks=re.findall(pattern,actual,re.M)
        if len(blocks)!=1:
            raise ValueError('Unique original source instance required: '+inst)
        cuts=[r for r in oldcuts if r['instance']==inst]
        substitutions='\n'.join('    assign '+r['expression']+'='+r['replacement']+';' for r in cuts)
        if not cuts or parent.count(substitutions)!=1:
            raise ValueError('Prior output substitution not exact: '+inst)
        previous=parent
        parent=parent.replace(substitutions,blocks[0],1)
        if parent.replace(blocks[0],substitutions,1)!=previous:
            raise ValueError('Restoration not reversible')
        restored.append(dict(instance=inst,module=module,actual_instance=blocks[0],
                             removed_substitutions=cuts))
    files['datapath.sv']=parent.encode()
    selection=dict(RMS_MODULES)
    selection[RAMFILE]=['board1_fixed_semantic_vector256_ram']
    source,rows=native_source(selection)
    # The RMS/native copy's exact source inventory and original full module
    # bodies are independently rechecked by native_source.
    files['rms-segment-native.sv']=source.encode()
    rom=(PUBLIC/ROM).read_bytes()
    if rom!=(PILOT/'project'/ROM).read_bytes():
        raise ValueError('Old RMS ROM changed')
    return files,rom,dict(schema='RMS-Q-restored-source-context-v1',top=TOP,
        sources={**prior['sources'],**rows},restored_instances=restored,
        prior_context_manifest_sha256=sha((PILOT/'model-consumption/connected-SOURCES.json').read_bytes()),
        unchanged_parent_controller=True,new_HDL_observers=[],
        remaining_unrestricted_numerical_leaves=14,
        remaining_unrestricted_output_ports=prior['remaining_unrestricted_output_ports']-
            sum(len(r['removed_substitutions']) for r in restored),
        unused_old_cut_input_ports_retained=True,
        compiler_initial_ROM_binding=True,ROM_file=ROM,ROM_sha256=sha(rom),
        connected_segment_proved=False,whole_machine_theorem=False)


def recipe(files):
    return '\n'.join([
        'read_verilog -formal -sv -nosynthesis -D SYNTHESIS -defer '+' '.join(files),
        'hierarchy -check -top core_workflow_control','rename -top '+TOP,
        'proc','flatten',
        'setattr -set keep 1 w:'+DP+'* m:'+DP+'* w:'+SEQ+'* m:'+SEQ+'*',
        'select -assert-none t:$assume t:$anyconst t:$anyseq',
        'chformal -remove','opt_clean','async2sync','opt_clean','dffunmap','memory_collect',
        'select -assert-none t:$assume t:$assert t:$cover t:$anyconst t:$anyseq',
        'check -assert','write_json native.json','write_smt2 -wires native.smt2',
    ])+'\n'


def prepare():
    files,rom,manifest=reconstruction()
    d=HERE/'context';d.mkdir(exist_ok=True)
    script=recipe(files)
    if not (d/'native.smt2').exists():
        for name,data in files.items():atomic_bytes(d/name,data)
        atomic_bytes(d/ROM,rom)
        atomic_bytes(d/'compile.ys',script.encode())
        start=time.monotonic()
        with (d/'compile.log').open('w') as log:
            cp=subprocess.run(['yosys','-Q','compile.ys'],cwd=d,
                stdout=log,stderr=subprocess.STDOUT,timeout=180)
        if cp.returncode:raise ValueError('Native context translation failed')
        print('Native source translated in %.3fs'%(time.monotonic()-start))
    if (d/'compile.ys').read_text()!=script or any((d/n).read_bytes()!=b for n,b in files.items()):
        raise ValueError('Existing native context changed')
    graph=json.loads((d/'native.json').read_text())['modules'][TOP]
    memories={n:{k:int(c['parameters'][k],2) for k in ['WIDTH','SIZE','WR_PORTS']}
              for n,c in graph['cells'].items() if c['type']=='$mem_v2'}
    for inst in ['u_hidden_state','u_rms_scratch','u_query_state']:
        if memories.get(DP+inst+'.payload_mem')!={'WIDTH':16,'SIZE':256,'WR_PORTS':1}:
            raise ValueError('Restored actual RAM missing: '+inst)
    for name in [DP+'u_rmsnorm.vector_mem_q',DP+'u_rmsnorm.u_frozen_vector_normalizer.record_mem_q',DP+'u_normalizer.record_mem_q']:
        if name not in memories:raise ValueError('Actual numerical producer workspace missing: '+name)
    if re.search(r'implicitly declared|no driver|out of bounds',(d/'compile.log').read_text(),re.I):
        raise ValueError('Unsupported native source warning')
    manifest.update(files={n:sha(b) for n,b in files.items()},
        compile_script_sha256=sha(script.encode()),
        native_smt_sha256=sha((d/'native.smt2').read_bytes()),
        native_graph_sha256=sha((d/'native.json').read_bytes()),memories=memories)
    write_frozen(HERE/'context-SOURCES.json',manifest)
    print(json.dumps(dict(translated=True,restored_instances=list(RESTORE),
                         memories=len(memories),proof_result=False)))
    return manifest


if __name__=='__main__':prepare()

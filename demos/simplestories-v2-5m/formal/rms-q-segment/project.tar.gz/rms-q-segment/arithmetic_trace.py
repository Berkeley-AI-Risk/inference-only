"""Strict common-parent-trace closure for the RMS arithmetic providers.

The trace source and all observers are the actual parent context. Native local
lemmas are instantiated only through the complete identical-source binding.
This file is a derivation checker, not a solver or proof kernel; every imported
implication is separately reconstructed against raw engine evidence.
"""
import json,re
from common import HERE,both,eq,atomic_json,bv
from parent_flow import TOP,S,DP,d
from rms_local import to_parent,complete_instance_binding
from rms_native_history import parse,emit
from verify_gate import check_component,close_trace,FAMILIES
from close_normalizer import close as normalizer_close

MAPPING={'h':'ch','hn':'chn','c':'sqc','nc':'rnc','ncn':'rncn','watch':'rwatch','model':'nrmodel','na':'rna','sh':'rsh'}
COMPONENTS=[('rms-local-read-words-r4','rms_local',4),('rms-square-fold','rms_square_fold',1),
    ('rms-scalar-words','rms_scalar_words',1),('rms-helper-tickets','rms_scalar_algorithm',1),
    ('rms-scalar-algorithm-r4','rms_scalar_algorithm',4),('rms-raw-capture','rms_raw_capture',1),
    ('rms-endpoints','rms_endpoints',1)]


def replace(x,names):return [replace(y,names) for y in x] if isinstance(x,list) else names.get(x,x)


def alias_table():
    source=(HERE/'context/native.smt2').read_text();groups={}
    for node in parse(source):
        if node[0]=='define-fun' and re.fullmatch(r'\|'+TOP+r'_(n|m) [^|]+\|',node[1]):
            key=emit(node[3])+emit(node[4]);groups.setdefault(key,[]).append(node[1])
    return {symbol:min(group,key=lambda x:(len(x),x)) for group in groups.values() for symbol in group}

ALIASES=None


def normalize(node):
    if not isinstance(node,list):
        if node.startswith('#b'):return ['_','bv'+str(int(node[2:],2)),str(len(node)-2)]
        if node.startswith('#x'):return ['_','bv'+str(int(node[2:],16)),str(4*(len(node)-2))]
        return ALIASES.get(node,node)
    result=[normalize(x) for x in node]
    if result and result[0] in ['and','or'] and len(result)==2:return result[1]
    return result


def canonical(text,names=None,local=False):
    text=to_parent(text) if local else text
    return emit(normalize(replace(parse(text)[0],names or {})))


def flatten(text):
    x=parse(text)[0]
    if isinstance(x,list) and x[0]=='and':return [v for y in x[1:] for v in flatten(emit(y))]
    return [text]


class Ledger:
    def __init__(self,facts,defs,plans):
        self.facts=set();self.steps=[];self.defs=defs;self.plans=plans
        self.add(facts)
    def add(self,facts):
        for fact in facts:self.facts.update(flatten(canonical(fact)))
    def clone(self,guards=()):
        result=Ledger(self.facts,self.defs,self.plans);result.add(guards);return result
    def apply(self,label,name,extra=None):
        rule=self.plans[label]['rules'][name]
        if rule.get('expected','unsat')!='unsat':raise ValueError('A SAT control is not an implication provider')
        names={**MAPPING,**(extra or {})}
        local=label in [x[0] for x in COMPONENTS]
        needed={y for x in rule['assumptions'] for y in flatten(canonical(x,names,local))}
        absent=needed-self.facts
        if absent:raise ValueError(json.dumps(dict(component=label,rule=name,unclosed=sorted(absent)),indent=2))
        result=canonical(rule['conclusion'],names,local)
        self.add([result]);self.steps.append(dict(component=label,rule=name,conclusion=result))
        return result
    def unfold(self,fact):
        fact=canonical(fact)
        if fact not in self.facts:raise ValueError('Unproved predicate to unfold: '+fact)
        x=parse(fact)[0];name=x[0] if isinstance(x,list) else x
        if name not in self.defs:raise ValueError('Unknown exact predicate '+name)
        definition=self.defs[name];args=x[1:] if isinstance(x,list) else []
        if len(args)!=len(definition[2]):raise ValueError('Predicate arity changed')
        body=replace(definition[4],{a[0]:v for a,v in zip(definition[2],args,strict=True)})
        self.add([emit(body)])
    def forward(self):
        changed=True
        while changed:
            changed=False
            for text in list(self.facts):
                x=parse(text)[0]
                if not isinstance(x,list) or not x:continue
                before=len(self.facts)
                if x[0]=='=>' and set(flatten(emit(x[1])))<=self.facts:self.add([emit(x[2])])
                if x[0]=='or':
                    remaining=[v for v in x[1:] if canonical('(not '+emit(v)+')') not in self.facts]
                    if len(remaining)==1:self.add([emit(remaining[0])])
                changed|=len(self.facts)>before
    def conditional(self,label,name,guards,extra=None):
        trial=self.clone(guards);goal=trial.apply(label,name,extra)
        conclusion=canonical('(=> '+both(guards)+' '+goal+')')
        self.add([conclusion]);self.steps.append(dict(conditional_provider=label,rule=name,guards=guards,conclusion=conclusion))
        return conclusion


def close_helpers(plans,defs):
    source=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',d('rst_n')]
    results={}
    for label,family,history,count in [('root-instance','root','rh',23),('divider-instance','div','dh',28)]:
        names={'h':history,'hn':history+'n'}
        inv=f'({family}-inv a {history})';post=f'({family}-inv an {history}n)'
        recurrence=eq(history+'n',f'({family}-next a {history})')
        ledger=Ledger(source+[inv,recurrence],defs,plans)
        if family=='div':
            domain=ledger.apply(label,'actual-RMS-numerator-meets-bounded-helper-domain')
            # The helper preservation provider asks the conditional form of
            # this unconditional native argument-domain theorem.
            candidates=[x for x in plans[label]['rules']['idle-preserved']['assumptions'] if parse(x)[0][0]=='=>']
            if len(candidates)!=1:raise ValueError('Changed divider domain provider interface')
            wanted=candidates[0]
            wanted=canonical(wanted,names)
            term=parse(wanted)[0]
            if term[0]!='=>' or canonical(emit(term[2]))!=domain:
                raise ValueError('Divider source domain does not close actual request premise')
            ledger.add([wanted])
        coverage=ledger.apply(label,'case-coverage',names)
        pword='('+history+'-phase '+history+')';kword='('+history+'-k '+history+')'
        expected_coverage=both(['(or '+eq(pword,'#b00')+' '+eq(pword,'#b10')+' '+eq(pword,'#b01')+')',
            '(=> '+eq(pword,'#b01')+' (bvule '+kword+' '+bv(count-1,5 if family=='root' else 6)+'))'])
        actual=parse(coverage)[0];expected=parse(canonical(expected_coverage))[0]
        if actual[0]!='and' or len(actual)!=3 or actual[1][0]!='or' or expected[1][0]!='or' or set(map(emit,actual[1][1:]))!=set(map(emit,expected[1][1:])) or actual[2]!=expected[2]:
            raise ValueError('Helper finite case coverage differs from the applied cases')
        cases=[('idle-preserved',eq('('+history+'-phase '+history+')','#b00')),
            ('held-preserved',eq('('+history+'-phase '+history+')','#b10'))]
        for k in range(count):cases.append(('digit-'+str(k)+'-preserved',both([
            eq('('+history+'-phase '+history+')','#b01'),eq('('+history+'-k '+history+')',bv(k,5 if family=='root' else 6))])))
        branch_results=[]
        for name,guard in cases:
            branch=ledger.clone([guard]);got=branch.apply(label,name,names)
            if got!=canonical(post):raise ValueError('Helper case proves a different post invariant')
            branch_results.append(dict(rule=name,guard=canonical(guard),post=got))
        # The proved coverage gives phase 00/01/10 and the busy count upper
        # bound; these exact finite BV literals exhaust those legal cases.
        expected_phases={0,1,2}
        if {0,2}|{1 for _ in range(count)}!=expected_phases or set(range(count))!=set(range(23 if family=='root' else 28)):
            raise ValueError('Incomplete helper finite case enumeration')
        base=Ledger(source[:-1]+['(not '+d('rst_n')+')'],defs,plans)
        got=base.apply(label,'common-reset-base',names)
        if got!=canonical(f'({family}-inv an {family}-zero)'):raise ValueError('Helper common reset changed')
        results[label]=dict(common_reset=base.steps,coverage=ledger.steps,branches=branch_results,
            total_functional_history_recurrence=recurrence,all_premises_closed=True,
            finite_case_rule='Case elimination using the raw engine-proved phase/count coverage and exact complete finite BV literal enumeration; no extra reset or request assumption.')
    return results


def reconstruct():
    global ALIASES
    ALIASES=alias_table();binding=complete_instance_binding()
    plans={};receipts={};defs={}
    # The independent caller/RAM joint invariant is already closed on this
    # same parent trace. Its unary/history facts are imports of that theorem.
    gate={label:check_component(label,module,rev)[0] for label,module,rev,*_ in FAMILIES}
    gate_trace=close_trace(gate)
    for label,module,rev in COMPONENTS:
        plans[label],receipts[label]=check_component(label,module,rev)
        text=to_parent((HERE/label/'algorithm.smt2').read_text())
        for x in parse(text):
            if x[0]=='define-fun':
                x=normalize(x)
                if x[1] in defs and defs[x[1]]!=x:raise ValueError('Changed shared arithmetic definition '+x[1])
                defs[x[1]]=x
    for label in ['root-instance','divider-instance']:
        plans[label],receipts[label]=check_component(label,'helper_instances',1)
    helpers=close_helpers(plans,defs)
    normalizer=normalizer_close()
    source=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',d('rst_n')]
    imports=['(rms-u-inv a)','(rms-u-inv an)','(rms-h-inv a ch)','(rms-h-inv an chn)',
        '(root-inv a rh)','(root-inv an rhn)','(div-inv a dh)','(div-inv an dhn)',
        '(nc-inv a rnc)','(nc-inv an rncn)',
        '(shift-inv a rsh)','(ns-inv a rnc rsh)','(na-inv a rnc rna)']
    equations=['(= chn (history-next a an ch))','(= rhn (root-next a rh))',
        '(= dhn (div-next a dh))','(= rncn (nc-next a rnc))']
    current=['(rw-inv a ch)','(sq-inv a ch sqc)','(rsa-inv a ch rh dh)',
        '(rn-inv a ch sqc rnc nrmodel rwatch)']
    model=canonical('(= nrmodel '+f'(|{TOP}_m {DP}u_rmsnorm.u_norm_rom.norm_rom| a))')
    ledger=Ledger(source+imports+equations+current+[model],defs,plans)
    ledger.apply('rms-helper-tickets','root-actual-producer-ticket')
    ledger.apply('rms-helper-tickets','div-actual-producer-ticket')
    for name in ['root-actual-producer-ticket','div-actual-producer-ticket']:
        ledger.apply('rms-helper-tickets',name,{'a':'an','rh':'rhn','dh':'dhn'})
    read='rms-local-read-words-r4'
    for i in range(5):ledger.apply(read,'weight-register-transfer-'+str(i))
    ledger.apply(read,'weight-live-predecessor')
    from rms_read_words import phase
    from rms_local import to_local
    guard=canonical(to_parent(to_local(phase(11))))
    ledger.conditional(read,'actual-weight-word-product',[guard])
    ledger.unfold('(rw-inv a ch)')
    for i in range(2):ledger.apply(read,'preserved-'+str(i))
    ledger.apply(read,'parts-join')
    # Exhaust all actual native 5-bit states. Every branch must prove exactly
    # the same next invariant, and every actual state has one of these values.
    posts=set()
    for k in range(32):
        case=canonical(to_parent(to_local(phase(k))))
        branch=ledger.clone([case]);posts.add(branch.apply('rms-square-fold','preserved-'+str(k)))
    if len(posts)!=1:raise ValueError('Square cases have differing postconditions')
    ledger.add(posts);ledger.steps.append(dict(component='rms-square-fold',exhaustive_native_states=32,post=next(iter(posts))))
    words='rms-scalar-words'
    for name in ['actual-mean-is-profile-mean','actual-divider-clamp-is-profile-clamp','actual-numerator-is-profile-numerator']:
        ledger.apply(words,name)
    # Derive legal exponent from the actual reachable-state conjunction under
    # the exact live guard, then eliminate all 64 permitted exponent cases.
    local_defs=defs['rsa-clause-0'];live=emit(local_defs[4][1])
    trial=ledger.clone([live]);trial.unfold('(rms-u-inv a)');trial.forward()
    trial.unfold('(reachable a)');trial.forward()
    trial.apply(words,'exponent-case-coverage')
    goals=set()
    for e in range(-32,32):
        case=canonical(to_parent(to_local(eq(__import__('rms_capture').r('input_exponent_q'),bv(e,8)))))
        branch=trial.clone([case]);goals.add(branch.apply(words,'actual-epsilon-exponent-'+str(e)))
    if len(goals)!=1:raise ValueError('Epsilon cases have differing endpoints')
    epsilon=next(iter(goals));ledger.add(['(=> '+live+' '+epsilon+')'])
    trial.add([epsilon]);rad=trial.apply(words,'actual-radicand-is-profile-radicand')
    ledger.add(['(=> '+live+' '+rad+')'])
    scalar='rms-scalar-algorithm-r4'
    for name in ['scalar-register-stability-4','scalar-normalized-register-update',
        'scalar-register-stability-5','scalar-raw-register-update','scalar-actual-scale-word','scalar-scaled-word-profile']:
        ledger.apply(scalar,name)
    for i in range(8):ledger.apply(scalar,'preserved-'+str(i))
    ledger.apply(scalar,'parts-join')
    raw='rms-raw-capture';ledger.apply(raw,'model-ROM-extension-held')
    rawrule=plans[raw]['rules']['actual-held-scalar-record-is-profile']
    # All non-observation providers are now available. Discharge the exact
    # source theorem under its live/phase guards; never add its answer as input.
    needed=[canonical(x,MAPPING,True) for x in rawrule['assumptions']]
    guards=[x for x in needed if not set(flatten(x))<=ledger.facts]
    ledger.conditional(raw,'actual-held-scalar-record-is-profile',guards)
    for i in range(3):ledger.apply(raw,'preserved-'+str(i))
    ledger.apply(raw,'parts-join')
    endpoint_exports={}
    for name,rule in plans['rms-endpoints']['rules'].items():
        needed=[canonical(x,MAPPING,True) for x in rule['assumptions']]
        guards=[x for x in needed if not set(flatten(x))<=ledger.facts]
        endpoint_exports[name]=ledger.conditional('rms-endpoints',name,guards)
    complete_post=['(rw-inv an chn)','(sq-inv an chn sqc)','(rsa-inv an chn rhn dhn)',
        '(rn-inv an chn sqc rncn nrmodel rwatch)',
        '(= nrmodel '+f'(|{TOP}_m {DP}u_rmsnorm.u_norm_rom.norm_rom| an))']
    if not {canonical(x) for x in complete_post}<=ledger.facts:
        raise ValueError('Incomplete next arithmetic invariant tuple')
    # One actual common reset edge establishes all added arithmetic histories.
    # The model extension is defined from the reset-edge immutable ROM and
    # carried by the separately checked no-write transition law.
    basefacts=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',
        '(not '+d('rst_n')+')',model]
    base=Ledger(basefacts,defs,plans)
    bases={read:'(rw-inv an history-zero)',
        'rms-square-fold':'(sq-inv an history-zero sqc)',
        scalar:'(rsa-inv an history-zero root-zero div-zero)',
        raw:'(rn-inv an history-zero sqc nc-zero nrmodel rwatch)'}
    for label,wanted in bases.items():
        got=base.apply(label,'common-reset-base')
        if got!=canonical(wanted):raise ValueError('Arithmetic base differs from actual observer zeroes')
    base.apply(raw,'model-ROM-extension-held')
    observer_zeroes={}
    for name,zero in [('history-next','history-zero'),('root-next','root-zero'),('div-next','div-zero'),('nc-next','nc-zero')]:
        node=defs[name][4]
        if node[0]!='ite' or node[2]!=zero:raise ValueError('Observer does not choose the declared reset zero')
        def alternatives(x):
            return [y for z in x[1:] for y in alternatives(z)] if isinstance(x,list) and x[0]=='or' else [emit(x)]
        if canonical('(not '+d('rst_n')+')') not in alternatives(node[1]):
            raise ValueError('Observer reset branch is not the actual common hard reset')
        observer_zeroes[name]=dict(reset_condition=emit(node[1]),reset_value=zero,actual_common_reset_disjunct=True)
    return dict(schema='Actual-parent-RMS-arithmetic-trace-closure-v1',regular_step_closed=True,
        steps=ledger.steps,complete_next_invariant=complete_post,actual_RMS_algorithm_endpoints=endpoint_exports,imported_closed_caller_gate=gate_trace,imported_helper_traces=helpers,imported_normalizer=normalizer,
        complete_source_instance=binding,receipts={k:len(v) for k,v in receipts.items()},
        reset_bases_checked=True,reset_base_steps=base.steps,observer_reset_branches=observer_zeroes,integer_profile_derivation_checked=False,
        full_RMS_algorithm_proved=False,connected_segment_qualified=False,whole_machine_theorem=False)


if __name__=='__main__':
    result=reconstruct();atomic_json(HERE/'ARITHMETIC-TRACE-CLOSURE.json',result)
    print('Closed regular arithmetic provider step on one actual parent trace; integer final joins remain explicitly open.')

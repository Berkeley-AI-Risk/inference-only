"""RMS scalar algorithm with proved real-helper histories as providers.

All native state remains present. Root/division function bodies may be uniformly
forgotten in UNSAT engines only; the original function meanings and helper
producer histories are established separately and joined by exact signatures.
"""
import re
from common import HERE,bv,both,eq,ext,save_plan
from parent_flow import S,TOP,d
from rms_capture import r
from rms_read_words import definitions as read_definitions,phase
from rms_scalar_words import definitions as scalar_definitions
from rms_local import to_local,prepare,LOCAL
from digit_algorithms import root_specification,div_specification,ROOT_TOP,DIV_TOP
from rms_native_history import parse,emit,atoms

PREFIX={'root':'u_exact_isqrt.u_exact_board0_isqrt.','div':'u_exact_divider.u_exact_bounded_divider.'}


def helper_definitions(family):
    old=ROOT_TOP if family=='root' else DIV_TOP
    text=(root_specification() if family=='root' else div_specification())[1]
    text=text.replace('|'+old+'_s|','|'+LOCAL+'_s|')
    text=re.sub(r'\|'+old+r'_(n|m) ([^|]+)\|',lambda m:'|'+LOCAL+'_'+m[1]+' '+PREFIX[family]+m[2]+'|',text)
    if old in text:raise ValueError('Unmapped helper native symbol')
    return text


def definitions():
    defs,_=read_definitions();defs=to_local(defs)+scalar_definitions()
    all_helpers={}
    for family in ['root','div']:
        text=helper_definitions(family);all_helpers[family]=text
        # Keep actual source functions and next histories, but not the full
        # arithmetic helper invariant in the caller proof's native context.
        nodes=parse(text)
        defs+='\n'.join(emit(x) for x in nodes if x[0]!='define-fun' or x[1]!=family+'-inv')+'\n'
    R=lambda field,a='a':to_local(r(field,a))
    phase_local=lambda *k:to_local(phase(*k))
    state='|'+LOCAL+'_s|';args=f'((a {state}) (h History) (rh RootHistory) (dh DivHistory))'
    live=both([R('rst_n'),'(not (failed a))'])
    for family,history in [('root','rh'),('div','dh')]:
        phase_word='('+('rh' if family=='root' else 'dh')+'-phase '+history+')'
        getter=lambda f:f'(|{LOCAL}_n {PREFIX[family]+f}| a)'
        body=[f'(bvule {phase_word} #b10)',eq(getter('busy_q'),eq(phase_word,'#b01')),
            eq(getter('response_valid_o'),eq(phase_word,'#b10'))]
        value='(root-value (rh-x rh))' if family=='root' else '(div-value (dh-n dh) (dh-d dh))'
        body+=[f'(=> {getter("response_valid_o")} {eq(getter("response_result_o"),value)})']
        if family=='root':body+=[f'(not {getter("response_fault_o")})']
        else:body+=[f'(=> {getter("response_valid_o")} {eq(getter("response_fault_o"),eq("(dh-d dh)",bv(0,64)))})']
        defs+=f'(define-fun {family}-ticket ((a {state}) ({history} '+('RootHistory' if family=='root' else 'DivHistory')+')) Bool (=> '+R('rst_n')+' '+both(body)+'))\n'
    rad=f'(rms-radicand {R("square_sum_q")} (h-exponent h))'
    num=f'(rms-numerator (select (h-vector h) {R("lane_index_q")}))'
    den=ext(R('rms_q'),41)
    normalized=f'(rms-clamp (div-value {num} {den}))'
    clauses=[f'(=> {phase_local(*range(5,15))} {eq(R("radicand_q"),rad)})',
        f'(=> {phase_local(6)} '+both(['(or (= (rh-phase rh) #b01) (= (rh-phase rh) #b10))',eq('(rh-x rh)',R('radicand_q'))])+')',
        f'(=> {phase_local(*range(7,15))} {eq(R("rms_q"),f"(root-value {R('radicand_q')})")})',
        f'(=> {phase_local(10)} '+both(['(or (= (dh-phase dh) #b01) (= (dh-phase dh) #b10))',eq('(dh-n dh)',num),eq('(dh-d dh)',den)])+')',
        f'(=> {phase_local(11,12,13)} {eq(R("rms_normalized_q"),normalized)})',
        f'(=> {phase_local(13)} {eq(R("raw_q"),f"(rms-scaled {normalized} {R('rom_coefficient')} {R('rom_multiplier')})")})',
        f'(=> {phase_local(13)} {eq(R("raw_source_exponent_q"),f"(bvsub {R('rom_tensor_exponent')} {bv(27,8)})")})',
        f'(=> {phase_local(*range(7,15))} (distinct {R("rms_q")} {bv(0,23)}))']
    for i,c in enumerate(clauses):defs+=f'(define-fun rsa-clause-{i} {args} Bool (=> {live} {c}))\n'
    defs+=f'(define-fun rsa-inv {args} Bool '+both([f'(rsa-clause-{i} a h rh dh)' for i in range(len(clauses))])+')\n'
    return defs,clauses,all_helpers


def specification(revision=1):
    defs,clauses,_=definitions();state='|'+LOCAL+'_s|'
    R=lambda f,a='a':to_local(r(f,a));H=lambda a:f'(|{LOCAL}_h| {a})'
    decl=[f'(declare-const a {state})',f'(declare-const an {state})',
        '(declare-const h History)','(declare-const hn History)',
        '(declare-const rh RootHistory)','(declare-const rhn RootHistory)',
        '(declare-const dh DivHistory)','(declare-const dhn DivHistory)']
    ctx=[H('a'),H('an'),f'(|{LOCAL}_t| a an)']
    providers=['(rms-u-inv a)','(rms-u-inv an)','(rms-h-inv a h)','(rms-h-inv an hn)',
        '(rw-inv a h)','(rw-inv an hn)','(root-ticket a rh)','(root-ticket an rhn)',
        '(div-ticket a dh)','(div-ticket an dhn)',eq('hn','(history-next a an h)'),
        eq('rhn','(root-next a rh)'),eq('dhn','(div-next a dh)')]
    live=both([R('rst_n'),'(not (failed a))'])
    scalar_mean=eq(R('mean_square_wide'),f'(rms-mean {R("square_sum_q")})')
    scalar_eps=eq(R('epsilon_integer'),f'(rms-epsilon {R("input_exponent_q")})')
    scalar_rad=eq(R('radicand_wide'),f'(rms-radicand-wide {R("square_sum_q")} {R("input_exponent_q")})')
    clamp=eq(R('div_clamped16'),f'(rms-clamp {R("div_response_result")})')
    providers += [scalar_mean,(f'(=> {live} {scalar_eps})' if revision>=4 else scalar_eps),
        (f'(=> {live} {scalar_rad})' if revision>=4 else scalar_rad),clamp]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {R("rst_n")})'],
        conclusion='(rsa-inv an history-zero root-zero div-zero)')}
    for i in range(len(clauses)):
        rules['preserved-'+str(i)]=dict(assumptions=ctx+providers+['(rsa-inv a h rh dh)'],conclusion=f'(rsa-clause-{i} an hn rhn dhn)')
    rules['parts-join']=dict(assumptions=[f'(rsa-clause-{i} an hn rhn dhn)' for i in range(len(clauses))],conclusion='(rsa-inv an hn rhn dhn)')
    rules['actual-owned-raw-is-scalar-algorithm']=dict(assumptions=[H('a'),live,'(rsa-inv a h rh dh)',to_local(phase(13))],
        conclusion=both([f'(rsa-clause-5 a h rh dh)',f'(rsa-clause-6 a h rh dh)']))
    if revision>=2:
        nxt=lambda term:term.replace(' a)',' an)')
        phase_local=lambda *ks:to_local(phase(*ks))
        nphase=lambda *ks:nxt(phase_local(*ks))
        newlive=nxt(live)
        for index,phases,predecessors in [(4,[11,12,13],[10,11,12,13]),(5,[13],[12,13])]:
            incoming=both([newlive,nphase(*phases)])
            stable=both([live,phase_local(*predecessors),
                eq(R('lane_index_q','an'),R('lane_index_q')),
                eq(R('rms_q','an'),R('rms_q')),
                eq('(h-vector hn)','(h-vector h)')])
            if index==5:
                stable=both([stable,eq(R('rom_coefficient','an'),R('rom_coefficient')),
                    eq(R('rom_multiplier','an'),R('rom_multiplier'))])
            fact=f'(=> {incoming} {stable})'
            assumptions=ctx+[eq('hn','(history-next a an h)')]
            rules[f'scalar-register-stability-{index}']=dict(assumptions=assumptions,conclusion=fact)
            if index==4:
                entry=both([R('div_response_valid'),R('div_response_ready'),
                    eq(R('rms_normalized_q','an'),R('div_clamped16'))])
                hold=eq(R('rms_normalized_q','an'),R('rms_normalized_q'))
                update=f'(=> {incoming} (ite {phase_local(10)} {entry} {hold}))'
                rules['scalar-normalized-register-update']=dict(assumptions=ctx,conclusion=update)
                rules['preserved-4']['assumptions']=[fact,update,'(rsa-inv a h rh dh)',
                    '(div-ticket a dh)',clamp]
            else:
                raw=R('raw_q');rawnext=R('raw_q','an')
                update=f'(=> {incoming} (ite {phase_local(12)} '+eq(rawnext,ext(R('dsp_wide_product'),2,True))+' '+eq(rawnext,raw)+'))'
                rules['scalar-raw-register-update']=dict(assumptions=ctx,conclusion=update)
                from rms_read_words import specification as read_spec
                scale=to_local(read_spec(4)[2]['actual-scale-word-product']['conclusion'])
                profile=eq(ext(R('dsp_wide_product'),2,True),f'(rms-scaled {R("rms_normalized_q")} {R("rom_coefficient")} {R("rom_multiplier")})')
                product_fact=f'(=> {both([live,phase_local(12)])} {profile})'
                scale_provider=scale
                if revision>=3:
                    scale_provider=f'(=> {both([live,phase_local(12)])} {scale})'
                    rules['scalar-actual-scale-word']=dict(assumptions=[H('a'),'(rw-inv a h)'],conclusion=scale_provider)
                rules['scalar-scaled-word-profile']=dict(assumptions=['(rw-inv a h)',scale_provider],conclusion=product_fact)
                rules['preserved-5']['assumptions']=[fact,update,product_fact,'(rsa-inv a h rh dh)']
    return decl,defs,rules


def helper_provider_specification():
    defs,_,helpers=definitions()
    # Exact original invariant bodies are additionally present only in these
    # small consequence proofs, never as assumed RMS caller arithmetic.
    for family,text in helpers.items():
        inv=next(x for x in parse(text) if x[:2]==['define-fun',family+'-inv'])
        defs+=emit(inv)+'\n'
    state='|'+LOCAL+'_s|';decl=[f'(declare-const a {state})','(declare-const rh RootHistory)','(declare-const dh DivHistory)']
    rules={family+'-actual-producer-ticket':dict(assumptions=[f'(|{LOCAL}_h| a)',f'({family}-inv a {h})'],
        conclusion=f'({family}-ticket a {h})') for family,h in [('root','rh'),('div','dh')]}
    return decl,defs,rules


if __name__=='__main__':
    import sys
    revision=4 if '--revision-4' in sys.argv else (3 if '--revision-3' in sys.argv else (2 if '--revision-2' in sys.argv else 1))
    prepare();save_plan('rms-helper-tickets',*helper_provider_specification(),native_label='rms-local')
    save_plan('rms-scalar-algorithm'+('-r'+str(revision) if revision>1 else ''),*specification(revision),native_label='rms-local')
    print('Prepared complete native RMS scalar algorithm and exact real-helper provider tickets.')

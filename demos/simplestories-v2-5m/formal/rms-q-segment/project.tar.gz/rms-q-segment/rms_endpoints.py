"""Actual RMS held/transferred/DONE endpoints of the independent algorithm.

All current history/invariant premises are supplied by arithmetic_trace and the
closed normalizer module theorem. The square certificate is supplied by its
independent input-only construction, not a desired square sum or output.
"""
from common import HERE,bv,both,eq,save_plan
from rms_local import LOCAL,prepare,to_local
from rms_raw_capture import definitions as raw_definitions,R,N,S,CERT,MODEL
from rms_read_words import phase


def specification():
    defs=raw_definitions()[0];H=f'(|{LOCAL}_h| a)'
    decl=[f'(declare-const a {S})','(declare-const h History)',f'(declare-const c {CERT})',
        f'(declare-const model {MODEL})','(declare-const watch (_ BitVec 10))',
        '(declare-const nc NormCapture)','(declare-const na NormAlgorithm)','(declare-const sh ShiftHistory)']
    common=[H,'(rms-u-inv a)','(rms-h-inv a h)','(rn-inv a h c nc model watch)',
        '(nc-inv a nc)','(shift-inv a sh)','(ns-inv a nc sh)','(na-inv a nc na)',
        '(square-certificate (h-vector h) c)',f'(bvult watch {bv(256,10)})']
    profile=eq('(select (nc-vec nc) watch)','(RMS-record h c model watch)')
    owner=both(['(h-active h)',eq('(h-captured h)',bv(256,9)),eq('(nc-count nc)',bv(256,10)),
        eq('(nc-rows nc)',bv(256,10)),eq('(na-rows na)',bv(256,10)),profile])
    output=both([owner,eq('(na-phase na)',bv(5,3)),eq(R('result_row_index_o'),'((_ extract 7 0) (na-scan na))'),
        eq(R('result_mantissa_o'),'(na-mantissa na)'),eq(R('result_exponent_o'),'(na-candidate na)'),
        eq(R('result_last_o'),'(na-last na)'),eq('(na-emitted na)','(na-scan na)'),
        f'(bvult (na-scan na) {bv(256,10)})'])
    rules={
        'held-RMS-result-is-independent-algorithm':dict(assumptions=common+[R('result_valid_o')],conclusion=output),
        'transferred-RMS-result-is-independent-algorithm':dict(assumptions=common+[R('result_valid_o'),R('result_ready_i')],conclusion=output),
        'RMS-DONE-is-complete-independent-algorithm':dict(assumptions=common+[R('done_valid_o')],
            conclusion=both([owner,eq('(na-phase na)',bv(6,3)),eq('(na-emitted na)',bv(256,10)),
                eq('(h-ordinal h)',bv(256,9))])),
    }
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('rms-endpoints',*specification(),native_label='rms-local')
    print('Prepared actual RMS held/transfer/DONE algorithm endpoints; connected qualification remains separate.')

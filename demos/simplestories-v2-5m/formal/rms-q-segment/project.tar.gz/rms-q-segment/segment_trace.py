"""Main strict composition: stage-entry RMS through Q to tagged query reads.

All numerical producer implications below are derived module consequences,
never environmental assumptions. This joins reset/step histories and the
accepted-input substitution; operating/portable qualification is separate.
"""
import json
import arithmetic_trace as arithmetic
from common import HERE,PILOT,bv,both,atomic_json
from parent_flow import TOP,DP,d
from rms_capture import r
from rms_native_history import parse,emit
from verify_gate import check_component,close_trace,FAMILIES
from rms_numeric_producer import payload
from query_numeric_producer import specification as legacy_spec,projection as legacy_projection
from query_numeric_store import definitions as query_definitions
from query_write_event import projected_definitions
from rms_local import to_parent
from accepted_interface import verify as input_verify
from verify_rms_meaning import verify as integer_verify
from verify_digit_meaning import main as helper_verify
from normalizer_frame import specification as frame_spec

LOCAL=[('rms-numeric-store-r2','rms_numeric_store',2),('rms-numeric-producer','rms_numeric_producer',1),
 ('rms-q-argument-r4','rms_q_argument',4),('query-numeric-store','query_numeric_store',1),
 ('query-numeric-authority','query_numeric_authority',1),('query-write-event','query_write_event',1),
 ('normalizer-frame','normalizer_frame',1)]


def canon(text,names=None):return arithmetic.canonical(text,names)

def flat(text):return arithmetic.flatten(canon(text))


def names(label):
    result={'watch':'w','q':'qi','qn':'qin','na':'rna'}
    if label.startswith('query-numeric'):
        result.update(h='qu',hn='qun')
    return result


class Ledger:
    def __init__(self,facts,plans):self.facts=set();self.steps=[];self.plans=plans;self.add(facts)
    def add(self,items):
        for item in items:self.facts.update(flat(item))
    def apply(self,label,name,extra=None):
        rule=self.plans[label]['rules'][name]
        if rule.get('expected','unsat')!='unsat':raise ValueError('SAT cannot supply an implication')
        mapping={**names(label),**(extra or {})}
        needed={v for x in rule['assumptions'] for v in flat(canon(x,mapping))}
        absent=needed-self.facts
        if absent:raise ValueError(json.dumps(dict(component=label,rule=name,unclosed=sorted(absent)),indent=2))
        result=canon(rule['conclusion'],mapping);self.add([result]);self.steps.append(dict(component=label,rule=name,conclusion=result))
        return result
    def under(self,label,name,guards,extra=None):
        branch=Ledger(self.facts,self.plans);branch.add(guards);goal=branch.apply(label,name,extra)
        result=canon('(=> '+both(guards)+' '+goal+')');self.add([result])
        self.steps.append(dict(component=label,rule=name,discharged_guards=guards,conclusion=result));return result


def rms_payload_import(trace):
    # Use the checked whole RMS endpoint at the input-only constructed square
    # certificate and literal watched row zero. Both extra guards are closed.
    endpoint=parse(trace['actual_RMS_algorithm_endpoints']['held-RMS-result-is-independent-algorithm'])[0]
    if endpoint[0]!='=>':raise ValueError('RMS endpoint is not a conditional theorem')
    guards=set(flat(emit(endpoint[1])))
    valid=canon(r('result_valid_o'))
    expected={canon('(square-certificate (h-vector ch) sqc)'),
        canon('(bvult rwatch '+bv(256,10)+')'),valid}
    if guards!=expected:raise ValueError('RMS endpoint has an additional unclosed observation guard')
    desired=parse(canon(payload(),{'na':'rna'}))[0]
    if desired[0]!='=>' or desired[1]!=parse(valid)[0]:raise ValueError('Changed retained RMS producer payload interface')
    if not set(flat(emit(desired[2])))<=set(flat(emit(endpoint[2]))):raise ValueError('RMS endpoint does not imply payload producer')
    return dict(consequence=emit(desired),source_endpoint_sha256=__import__('common').sha(emit(endpoint).encode()),
        closed_guards=['make-square-certificate(h-vector) is an input-only witness by the checked finite construction',
            'literal watched BV10 zero is below 256'],
        rule='Universal certificate/row specialization and conjunction elimination; no desired numerical reply.')


def q_payload_import(interface):
    # Apply the adapter in its qualified product before source restriction.
    # The old reset/step checker supplies all current invariant facts; its
    # endpoint applications, rather than a PASS flag, supply the full goal.
    from trace_closure import product,invariant_family,old_interface,inst,rule as old_rule
    from derivation import conjuncts as split,apply as literal_apply
    trace=interface['actual_Q_source_specialization']['qualified_Q_trace']
    endpoint=trace['endpoints']['actual-Q-write-value-address-and-order']
    if endpoint['unresolved'] or endpoint['observation_guard']!=['(Q-write-admission a z)']:
        raise ValueError('Qualified Q endpoint has an unclosed guard')
    goal=old_rule('q-main','actual-Q-write-value-address-and-order')['conclusion']
    selected=[x for x in endpoint['applications'] if x['provider']=='q-main' and x['rule']=='actual-Q-write-value-address-and-order']
    if len(selected)!=1 or selected[0]['missing_count'] or selected[0]['conclusion']!=goal:
        raise ValueError('Missing exact qualified Q endpoint application')
    clauses=split(goal)
    dropped=[x for x in clauses if parse(x)[0][0]=='Q-record-matches']
    if len(dropped)!=1:raise ValueError('Changed full Q numerical certificate conjunct')
    scalar=both([x for x in clauses if x not in dropped])
    conditional='(=> (Q-write-admission a z) '+scalar+')'
    _,_,adapters=legacy_spec(2)
    chosen=adapters['qualified-Q-guarantee-closes-query-numerical-producer']
    specialized={k:([inst(x,'q-main','root') for x in v] if k=='assumptions' else inst(v,'q-main','root')) for k,v in chosen.items()}
    application=literal_apply(specialized,{},product()+invariant_family()+old_interface()+[conditional])
    if application['conclusion']!='(qnum-producer a z qa na)':raise ValueError('Changed Q producer theorem interface')
    caller=adapters['qualified-Q-admission-has-live-Q-caller']
    caller_application=literal_apply(caller,{},product()+['(Q-write-admission a z)'])
    _,legacy_defs,_=legacy_spec(2)
    old=next(x for x in parse(legacy_defs) if x[:2]==['define-fun','qnum-producer'])
    actual=next(x for x in parse(query_definitions()) if x[:2]==['define-fun','qnum-producer'])
    from q_columns import TOP as OLD
    def tr(x):
        if isinstance(x,list):return [tr(v) for v in x]
        return x.replace('|'+OLD+'_n ','|'+TOP+'_n ')
    if canon(emit(tr(old[4][2])))!=canon(emit(actual[4][2])):
        raise ValueError('Qualified Q producer consequent differs at actual source ports')
    event_definitions,event=projected_definitions()
    from derivation import replace
    # Unfold the proven old producer, rename only its pure algorithm history,
    # and observe its native consequent through the actual source root view.
    # All named port/getter sorts are checked by the source event projection
    # or directly against both native models below.
    from selector import TOP as NORM
    old_native={x[1]:x for x in parse((PILOT/'model-consumption/connected/native.smt2').read_text()) if x[0]=='define-fun'}
    actual_native={x[1]:x for x in parse((HERE/'context/native.smt2').read_text()) if x[0]=='define-fun'}
    getters={}
    def source_view(x):
        if isinstance(x,list):return [source_view(v) for v in x]
        if x=='na':return 'qna'
        if x.startswith('|'+OLD+'_n ') or x.startswith('|'+OLD+'_m '):
            target=x.replace('|'+OLD+'_','|'+TOP+'_',1)
            if x not in old_native or target not in actual_native or old_native[x][3]!=actual_native[target][3]:
                raise ValueError('Missing actual Q producer source getter '+x)
            getters[x]=dict(actual=target,sort=old_native[x][3]);return target
        return x
    actual_binding=source_view(old[4][2])
    if canon(emit(actual_binding))!=canon(emit(actual[4][2])):raise ValueError('Actual Q numerical producer binding changed')
    source_consequence=canon('(=> (actual-qualified-Q-write a) '+emit(actual_binding)+')')
    reset=[x for x in split(caller_application['conclusion']) if 'u_datapath.rst_n|' in x]
    if len(reset)!=1:raise ValueError('Qualified Q caller reset consequence changed')
    actual_reset=emit(source_view(parse(reset[0])[0]))
    return dict(consequence='(qnum-producer a qa qna)',legacy_projection=legacy_projection(),actual_event_binding=event,
        closed_source_producer_implication=source_consequence,actual_consequent_getters=getters,
        qualified_caller_application=caller_application,closed_source_reset_implication='(=> (actual-qualified-Q-write a) '+actual_reset+')',
        source_history_instantiation=dict(qa='Exact qualified qa-next at actual Q descriptor/capture events',
            qna='Exact qualified na-next at actual u_normalizer ports; same pure NormAlgorithm datatype/program'),
        qualified_product_application=application,full_numerical_endpoint=goal,
        full_numerical_conjunct_preserved=dropped[0],scalar_conjunction_elimination=dict(source=goal,conclusion=scalar),
        rules=['The reconstructed qualified Q main theorem implies its literal scalar conjunct projection.',
            'query-numeric-producer-r2 proves that consequence and current qualified QA invariant imply the numerical producer in the original root/normalizer product.',
            'Exact restored-source restriction supplies those actual root/normalizer histories.',
            'query-write-event proves actual physical Q write iff the qualified event observer; the checked producer consequents are identical at actual named ports.'],
        no_foreign_state_sort_equality=True,no_extra_numerical_input_assumption=True)


def reconstruct():
    arithmetic.ALIASES=arithmetic.alias_table()
    arithmetic_trace=arithmetic.reconstruct();integer=integer_verify();helper_verify()
    from frame_trace import close as frame_close
    output_frame=frame_close(arithmetic_trace)
    interface=input_verify()
    plans={};receipts={}
    gate={label:check_component(label,module,rev)[0] for label,module,rev,*_ in FAMILIES}
    gate_trace=close_trace(gate)
    for label,module,rev in LOCAL:
        plans[label],receipts[label]=check_component(label,module,rev)
    legacy,rows=check_component('query-numeric-producer-r2','query_numeric_producer',2);receipts['query-numeric-producer-r2']=rows
    rms_import=rms_payload_import(arithmetic_trace);q_import=q_payload_import(interface)
    from full_record_trace import close as record_close
    saved_record=record_close(interface,q_import,output_frame)
    source=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',f'(|{TOP}_i| a)',f'(|{TOP}_i| an)',d('rst_n')]
    gate_current=[x[3] for x in FAMILIES if x[3]]+['(rms-u-inv a)','(rms-h-inv a ch)']
    gate_post=[x[4] for x in FAMILIES if x[4]]+['(rms-u-inv an)','(rms-h-inv an chn)']
    # QueryMemory has a separate uniform row family; its already-closed
    # physical transport theorem supplies qm/qmn and the exact updater.
    root=source+gate_current+gate_post+[
        '(= rsn (rs-next a rs))','(= chn (history-next a an ch))',
        '(= vn (rv-next a an rs v))','(= qmn (qm-next a an rs qm))',
        '(= rrn (rr-next a rsn rna rr))','(= qun (qnum-next a rs qa qna qu))',
        '(rr-inv a rs v rr w)','(qnum-inv a qu w)','(qnum-authority qu qm w)',
        '(qnum-row-inv a qu '+d('query_ram_read_address')+')',
        '(qnum-authority qu qm '+d('query_ram_read_address')+')',
        rms_import['consequence'],q_import['closed_source_producer_implication']]
    # Exact history names in the imported caller gate.
    root=[canon(x,{'q':'qi','qn':'qin','watch':'w'}) for x in root]
    ledger=Ledger(root,plans)
    ledger.apply('rms-numeric-producer','actual-write-discharge-numerical-producer')
    rr='rms-numeric-store-r2'
    for i in range(6):ledger.apply(rr,'preserved-'+str(i))
    ledger.apply(rr,'parts-join')
    ledger.apply('query-write-event','actual-query-Q-write-is-qualified-source-event')
    event_equality=canon('(= (qnum-write a) (actual-qualified-Q-write a))')
    if event_equality not in ledger.facts:raise ValueError('No proved actual Q event equivalence')
    imported=parse(q_import['closed_source_producer_implication'])[0]
    if imported[:2]!=['=>',['actual-qualified-Q-write','a']]:raise ValueError('Changed projected Q implication antecedent')
    rewritten=['=>',['qnum-write','a'],imported[2]]
    actual_producer=next(x for x in parse(query_definitions()) if x[:2]==['define-fun','qnum-producer'])
    if canon(emit(rewritten))!=canon(emit(actual_producer[4])):raise ValueError('Event rewrite cannot fold exact Q producer')
    ledger.add([q_import['consequence']]);ledger.steps.append(dict(inference='Equality replacement in implication antecedent and exact qnum-producer definitional fold',
        premises=[event_equality,q_import['closed_source_producer_implication']],conclusion=q_import['consequence']))
    qn='query-numeric-store'
    for name in ['row-preserved','read-preserved','parts-join']:ledger.apply(qn,name)
    ledger.apply('query-numeric-authority','preserved')
    targets=['(rr-inv an rsn vn rrn w)','(qnum-inv an qun w)','(qnum-authority qun qmn w)']
    if not {canon(x) for x in targets}<=ledger.facts:raise ValueError('Missing complete connected next tuple')
    bases=Ledger([f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)','(not '+d('rst_n')+')'],plans)
    for label in [rr,qn,'query-numeric-authority']:bases.apply(label,'common-reset-base')
    # The numerical producer imports are proved module consequences on this
    # source trace. All newly added histories are total, read-only recurrences.
    return dict(schema='RMS-to-Q-to-query-RAM-connected-trace-v1',regular_step_closed=True,common_reset_bases_closed=True,
        steps=ledger.steps,bases=bases.steps,complete_next_tuple=targets,
        imported_caller_gate=gate_trace,imported_RMS_arithmetic=arithmetic_trace,integer_profile=integer,
        accepted_Q_input_interface=interface,closed_RMS_payload_import=rms_import,closed_Q_payload_import=q_import,
        checked_output_frame=output_frame,checked_saved_full_Q_record=saved_record,
        engine_receipt_counts={k:len(v) for k,v in receipts.items()},
        uniform_row_rule='One arbitrary rigid BV8 row for each entire induction. Ghost updates are row-independent; universal specialization supplies the actual read-request address too.',
        output_frame_rule='See checked_output_frame for the actual source control and pure frame rule applications.',
        physical_read_scope='Mantissas and saved producing Q reference/exponent/owner at request edge before overwrite. Later Q-RoPE values, later actual global exponent and Q-RoPE arithmetic/consumer correspondence are outside.',
        connected_segment_qualified=False,whole_machine_theorem=False)


if __name__=='__main__':
    result=reconstruct();atomic_json(HERE/'CONNECTED-TRACE-CLOSURE.json',result)
    print('Connected reset/step producer and RAM derivation reconstructed; portable/operating/final qualification remains separate.')

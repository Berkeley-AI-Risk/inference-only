"""Replay the old RMS unary/history invariants in the actual parent instance.

Only their needed function-definition dependency closure is retained. Every
native getter is mapped by exact hierarchical name and checked type. The
new implications use the full actual parent transition, not a desired child
reply or an identification of two unrelated native state sorts.
"""
import json
import re
import sys
from common import HERE,PILOT,bv,both,eq,sha,atomic_json,save_plan
from parent_flow import S,TOP,DP,n,d
from rms_capture import r
from prepare_context import prepare
sys.path.insert(0,str(PILOT/'q-operator'))
from pruned_arithmetic import parse,emit,atoms

OLD='board1_fixed_vector_rmsnorm_service'
ROOTS={'failed','reachable','history-inv','history-next','history-output'}


def definitions():
    oldbody=(PILOT/'product.smt2').read_text()+'\n'+(PILOT/'history.smt2').read_text()
    ast=parse(oldbody)
    all_defs={x[1]:x for x in ast if x[0]=='define-fun'}
    needed=set(ROOTS)
    while True:
        more=set(atoms([all_defs[x][2:] for x in needed])) & set(all_defs)
        if more<=needed:break
        needed|=more
    selected=[x for x in ast if x[0]=='declare-datatypes' or x[0]=='define-fun' and x[1]in needed]
    local=parse((PILOT/'project/native.smt2').read_text())
    parent=parse((HERE/'context/native.smt2').read_text())
    local_defs={x[1]:x for x in local if x[0]=='define-fun'}
    parent_defs={x[1]:x for x in parent if x[0]=='define-fun'}
    names={'|'+OLD+'_s|':S}
    getters=[]
    for symbol in sorted(set(atoms(selected))):
        match=re.fullmatch(r'\|'+OLD+r'_(n|m) (.+)\|',symbol)
        if match:
            mapped='|'+TOP+'_'+match[1]+' '+DP+'u_rmsnorm.'+match[2]+'|'
            if symbol not in local_defs or mapped not in parent_defs:
                raise ValueError('Missing exact native instance getter: '+symbol)
            if local_defs[symbol][3]!=parent_defs[mapped][3]:
                raise ValueError('Changed instance getter type: '+symbol)
            names[symbol]=mapped
            getters.append(dict(local=symbol,parent=mapped,sort=emit(local_defs[symbol][3])))
    def tr(node):
        return [tr(x) for x in node] if isinstance(node,list) else names.get(node,node)
    translated=[tr(x) for x in selected]
    if any(OLD in x for x in atoms(translated)):
        raise ValueError('Unmapped native local symbol')
    defs='\n'.join(emit(x) for x in translated)+'\n'
    defs+=f'(define-fun rms-u-inv ((a {S})) Bool (=> {d("rst_n")} (or (failed a) (reachable a))))\n'
    defs+=f'(define-fun rms-h-inv ((a {S}) (h History)) Bool (=> {d("rst_n")} (history-inv a h)))\n'
    return defs,dict(schema='Exact-RMS-unary-history-parent-instantiation-v1',
        old_product_sha256=sha((PILOT/'product.smt2').read_bytes()),
        old_history_sha256=sha((PILOT/'history.smt2').read_bytes()),
        retained_definition_names=sorted(needed),exact_hierarchical_getters=getters,
        unrelated_definitions_pruned_only=True,full_parent_transition_used=True,
        no_internal_reply_assumption=True,new_rules_rerun_in_actual_parent=True)


def specification():
    defs,binding=definitions()
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
          '(declare-const h History)','(declare-const hn History)']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    fresh=f'(or (not {d("rst_n")}) {d("clear_i")})'
    rules={'unary-base':dict(assumptions=ctx+[fresh],conclusion='(rms-u-inv an)'),
        'history-base':dict(assumptions=ctx+[fresh],conclusion='(rms-h-inv an history-zero)')}
    for k in range(32):
        state=eq(r('state_q'),bv(k,5))
        rules[f'unary-preserved-{k}']=dict(assumptions=ctx+['(rms-u-inv a)',state],conclusion='(rms-u-inv an)')
        rules[f'history-preserved-{k}']=dict(assumptions=ctx+['(rms-u-inv a)','(rms-u-inv an)',
            '(rms-h-inv a h)',eq('hn','(history-next a an h)'),state],conclusion='(rms-h-inv an hn)')
    rules['case-coverage']=dict(assumptions=[],conclusion='(or '+' '.join(eq(r('state_q'),bv(k,5)) for k in range(32))+')')
    rules['actual-current-invocation-ordered-output']=dict(assumptions=[H('a'),d('rst_n'),'(rms-u-inv a)','(rms-h-inv a h)'],
        conclusion='(history-output a h)')
    return decl,defs,rules,binding


if __name__=='__main__':
    prepare()
    decl,defs,rules,binding=specification()
    atomic_json(HERE/'RMS-HISTORY-INSTANCE.json',binding)
    save_plan('rms-native-history',decl,defs,rules,native_label='context')
    print('Prepared exact RMS unary/history specialization with all 32 native state cases.')

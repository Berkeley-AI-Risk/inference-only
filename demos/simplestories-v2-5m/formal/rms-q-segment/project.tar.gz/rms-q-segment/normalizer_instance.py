"""Exact qualified normalizer theorem instantiation inside the actual RMS.

This is standard identical-source module trace instantiation, not equality of
unrelated native SMT state sorts. Ports, default parameters, module bodies and
logical getter sorts are checked. Qualified component receipts remain immutable.
"""
import re
import json
from common import HERE,PILOT,sha,atomic_json
from rms_local import LOCAL,prepare
from prepare import modules
from rms_native_history import parse,emit,atoms

Q=PILOT/'q-operator';NORM='board1_fixed_vector_normalizer';PREFIX='u_frozen_vector_normalizer.'
FILES=['norm-capture-r2/history.smt2','norm-shift/history.smt2','norm-algorithm-r2/history.smt2']


def translate(text):
    text=text.replace('|'+NORM+'_s|','|'+LOCAL+'_s|')
    text=re.sub(r'\|'+NORM+r'_(n|m) ([^|]+)\|',lambda m:'|'+LOCAL+'_'+m[1]+' '+PREFIX+m[2]+'|',text)
    for suffix in ['h','t','i']:text=text.replace('|'+NORM+'_'+suffix+'|','|'+LOCAL+'_'+suffix+'|')
    if NORM in text:raise ValueError('Unmapped native normalizer symbol')
    return text


def definitions():return '\n'.join(translate((Q/f).read_text()) for f in FILES)


def binding():
    native=(HERE/'rms-local/native.sv').read_text();original=(Q/'selector/native.sv').read_text()
    ours=modules(native);old=modules(original)
    for name in old:
        if name not in ours or old[name]!=ours[name]:raise ValueError('Changed qualified normalizer module '+name)
    instance=re.findall(r'^    board1_fixed_vector_normalizer u_frozen_vector_normalizer \([\s\S]*?^    \);',native,re.M)
    if len(instance)!=1:raise ValueError('Unique actual default-parameter normalizer instance required')
    ports=dict(re.findall(r'\.(\w+)\(([^()]*)\)',instance[0]));ports={k:re.sub(r'\s+','',v) for k,v in ports.items()}
    expected=dict(clk='clk',rst_n='rst_n',clear_i='clear_i||range_fault_o',model_lock_i='model_lock_i',
        upstream_fault_i='upstream_fault_i||range_fault_o',start_valid_i='norm_start_valid',start_ready_o='norm_start_ready',
        fixed_layer_i='layer_q',fixed_job_i="4'd0",input_valid_i='norm_input_valid',input_ready_o='norm_input_ready',
        input_row_index_i="{2'd0,lane_index_q}",input_raw_i='raw_q',input_source_exponent_i='raw_source_exponent_q',
        input_last_i="lane_index_q==8'd255",result_valid_o='norm_result_valid',result_ready_i='norm_result_ready',
        result_row_index_o='norm_result_row',result_mantissa_o='norm_result_mantissa',result_exponent_o='norm_result_exponent',
        result_last_o='norm_result_last',done_valid_o='norm_done_valid',done_ready_i='norm_done_ready',busy_o='norm_busy',range_fault_o='norm_fault')
    if ports!=expected:raise ValueError('Changed actual RMS normalizer ports')
    local_defs={x[1]:x for x in parse((HERE/'rms-local/native.smt2').read_text()) if x[0]=='define-fun'}
    old_defs={x[1]:x for x in parse((Q/'selector/native.smt2').read_text()) if x[0]=='define-fun'}
    getters=[]
    for symbol in sorted(set(atoms(parse('\n'.join((Q/f).read_text() for f in FILES))))):
        m=re.fullmatch(r'\|'+NORM+r'_(n|m) (.+)\|',symbol)
        if m:
            actual='|'+LOCAL+'_'+m[1]+' '+PREFIX+m[2]+'|'
            if actual not in local_defs or symbol not in old_defs:raise ValueError('Missing normalizer instance getter '+symbol)
            if local_defs[actual][3]!=old_defs[symbol][3]:raise ValueError('Changed normalizer getter type')
            getters.append(dict(old=symbol,actual=actual,sort=old_defs[symbol][3]))
    return dict(schema='Qualified-normalizer-actual-RMS-instance-v1',qualified_Q_commit='2d9eaf6c4f176d03849dd35ba6aaed298a20b69e',
        source_modules={name:sha(old[name].encode()) for name in old},actual_instance=instance[0],ports=ports,parameters={},
        translated_definitions={f:sha((Q/f).read_bytes()) for f in FILES},getters=getters,
        whole_source_identical=True,no_numerical_reply_assumed=True,actual_clear_includes_RMS_fault=True,
        rule='Universal identical-source module theorem instantiation on actual clock/reset/ports; source/reset-port specialization, not equality of foreign SMT state sorts',
        receipt_verification_required=['selector','norm-capture-r2','shift','norm-shift','norm-algorithm-r2'])


if __name__=='__main__':
    prepare();atomic_json(HERE/'NORMALIZER-INSTANCE.json',binding())
    print('Checked exact qualified normalizer source, ports, production defaults and getter sorts.')

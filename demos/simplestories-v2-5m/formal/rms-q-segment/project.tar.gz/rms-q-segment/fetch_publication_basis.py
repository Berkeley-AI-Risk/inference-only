"""Read the current public release into a scoped, non-Git validation artifact."""
import argparse,json,pathlib,subprocess
from common import HERE,atomic_json
REPO='repos/Berkeley-AI-Risk/inference-only/'
PATHS=['demos/simplestories-v2-5m/FORMAL-STATUS.md','demos/simplestories-v2-5m/formal/README.md',
 '.github/workflows/offline-checks.yml','demos/simplestories-v2-5m/MANIFEST.json',
 'demos/simplestories-v2-5m/tools/check_current_three_greedy_v15_v4.py','tools/release-contract.json','tools/verify_release.py','MANIFEST.json']


def get(endpoint):return json.loads(subprocess.check_output(['gh','api',REPO+endpoint]))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path,required=True);args=ap.parse_args()
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
    head=get('git/ref/heads/main')['object']['sha'];commit=get('git/commits/'+head)
    atomic_json(out/'BASIS.json',dict(repository=REPO,parent=head,tree=commit['tree']['sha'],paths=PATHS))
    tree=get('git/trees/'+commit['tree']['sha']+'?recursive=1')
    if tree.get('truncated'):raise ValueError('Incomplete remote tree census')
    atomic_json(out/'TREE.json',tree)
    for name in PATHS:
        p=out/name;p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('wb') as stream:
            r=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw+json',REPO+'contents/'+name+'?ref='+head],stdout=stream,stderr=subprocess.PIPE)
        if r.returncode:raise ValueError('Remote read failed '+name+': '+r.stderr.decode())
    if get('git/ref/heads/main')['object']['sha']!=head:raise ValueError('Remote changed while reading basis; preserve and reconcile')
    print(json.dumps(dict(read_only=True,parent=head,tree=commit['tree']['sha'],files=len(PATHS),remote_entries=len(tree['tree']))))


if __name__=='__main__':main()

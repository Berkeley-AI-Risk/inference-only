# Independent review of the RMSNorm-to-Q milestone

The owner requested a fresh agent audit. The reviewer was given no conversation
history, worked read-only, ran no solvers/compilers/simulations, and changed no
files. This record summarizes the review; it is not engine proof evidence.

**Recommendation: proceed, making the actual caller/RAM composition the next
gate, then strengthen its RMS value interface with the independent algorithm.**
The reviewer found the milestone substantive because it closes both the old
RMS source-defined-meaning gap and Q's excluded caller/RAM gap. It still leaves
the accepted-tape/whole-graph relation open.

The first gate should fix a generation/work owner and hidden-vector identity
at actual input-RMS stage acceptance. Include the semantic sequence and layer
wiring: arbitrary datapath-private ingress can otherwise alter hidden state.
Establish the actual synchronous hidden-RAM read delay and every accepted RMS
capture. Layer/position alone are insufficient because they may repeat after
CLEAR. Bind the existing RMS source-defined interface on the same trace, prove
the complete current-owner RMS write prefix/exponent, and follow actual RMS-RAM
reads into Q's captured arguments. A source-defined-F gate is internal progress,
not the independent-algorithm milestone.

Restore the actual query RAM/read register and define same-edge read/write
behavior and request-edge ownership. Track prefixes and revoke authority on
CLEAR without erasure. Distinguish Q-RoPE overwrites from unrotated Q values.

The arithmetic draft is meaningfully independent of helper replies and RTL
scratch. Before freezing, make square-sum rejection, role multiplier/exponent
laws and raw exponent bounds exact; separate ROM configuration checks from
operand rejection; clarify invalid descriptors/inputs; narrow scalar shifts to
the used domain and pin the qualified normalizer's precise definition. These
are specification repairs, not evidence that the route should be abandoned.

The pure-prefix forgetting experiment is sound for UNSAT if same-signature
arbitrary functions uniformly replace only selected pure definitions while
native transitions and assertions remain unchanged. Require exact mechanical
reconstruction and original-theory typechecks. Abstract SAT must not count as
original nonvacuity. Do not let helper experimentation delay the caller gate.

Legal fixed-model bounds should simplify the arithmetic: S<2^38, 1<=X<2^45,
abs(A<<12)<2^27, raw magnitude<2^39 and raw exponents -35/-34. Preserve source
protocol, lock, watchdog and cancellation interruptions. Existing held-result
queries depend on closing every base/preservation case and the actual instance.

The finite 3,328-row comparison is useful but uses one vector/exponent pattern
across all roles. Add zero, impulse, signed extrema, exponent endpoints and
rounding/root boundaries, plus actual-only wrong-bank, stale-generation and
wrong-read controls with unchanged independent expected values. Final replay
must reconstruct exact query and log receipts; a development checks-file pass
flag is insufficient.

Reviewed scope: project objective, main statement and numerical commitment;
published Q and old RMS statements; new helper generators/runner/status and
independent finite reference; actual RMS arithmetic/wrappers, semantic datapath,
sequence and RAM source. The reviewer did not comprehensively replay or audit
the complete published Q proof chain. No new connected/helper theorem was
accepted as already proved.

Disposition: adopt the caller/RAM-first gate and the specification repairs.
Keep the old published results immutable. Preserve the stopped helper attempt
as incomplete evidence, not a counterexample or a passing theorem.

"""Exact native square fold against a pure finite prefix certificate.

The certificate entries 0..256 are uniquely fixed by the complete accepted
vector; unused entries are arbitrary. It never drives native state. The theorem is universal in certificates;
existence/uniqueness and integer meaning are checked separately by finite fold
induction. No desired square-sum or helper result is an input assumption.
"""
from common import HERE,bv,both,eq,ext,save_plan,atomic_bytes
from parent_flow import S,TOP,DP,d
from rms_capture import r
from rms_read_words import definitions as read_definitions,phase
from rms_local import to_local,prepare


def definitions():
    defs,_=read_definitions()
    vector='(Array (_ BitVec 8) (_ BitVec 16))'
    table='(Array (_ BitVec 9) (_ BitVec 38))'
    defs+=f'(define-fun square-word ((x (_ BitVec 16))) (_ BitVec 32) (bvmul {ext("x",16,True)} {ext("x",16,True)}))\n'
    j=ext('row',1);jn=f'(bvadd {j} {bv(1,9)})'
    term='((_ zero_extend 6) (square-word (select v row)))'
    rec=eq(f'(select c {jn})',f'(bvadd (select c {j}) {term})')
    defs+=f'(define-fun square-certificate ((v {vector}) (c {table})) Bool (and (= (select c {bv(0,9)}) {bv(0,38)}) (forall ((row (_ BitVec 8))) {rec})))\n'
    partial=eq(r('square_sum_q'),f'(select c {ext(r("lane_index_q"),1)})')
    complete=eq(r('square_sum_q'),f'(select c {bv(256,9)})')
    live=both([d('rst_n'),'(not (failed a))'])
    cond=both([f'(=> {phase(2,3)} {partial})',f'(=> {phase(*range(4,15))} {complete})'])
    args=f'((a {S}) (h History) (c {table}))'
    defs+=f'(define-fun sq-inv {args} Bool (=> (and {live} (square-certificate (h-vector h) c)) {cond}))\n'
    return defs


def specification(revision=1):
    defs=definitions();H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
        '(declare-const h History)','(declare-const hn History)',
        '(declare-const c (Array (_ BitVec 9) (_ BitVec 38)))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    providers=['(rms-u-inv a)','(rms-u-inv an)','(rms-h-inv a h)',
        '(rms-h-inv an hn)','(rw-inv a h)',eq('hn','(history-next a an h)')]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(sq-inv an history-zero c)')}
    for k in range(32):
        rules['preserved-'+str(k)]=dict(assumptions=ctx+providers+['(sq-inv a h c)',phase(k)],conclusion='(sq-inv an hn c)')
    rules['actual-complete-square-word']=dict(assumptions=[H('a'),d('rst_n'),'(not (failed a))',
        '(sq-inv a h c)','(square-certificate (h-vector h) c)',phase(*range(4,15))],
        conclusion=eq(r('square_sum_q'),f'(select c {bv(256,9)})'))
    if revision>=2:
        nxt=lambda text:text.replace(' a)',' an)')
        live=both([d('rst_n'),'(not (failed a))'])
        nlive=nxt(live);nphase=lambda *ks:nxt(phase(*ks))
        incoming=both([nlive,nphase(2,4)])
        product=r('dsp_product0')
        stepfacts=both([
            f'(=> {nlive} {nphase(0,2,4)})',
            f'(=> {incoming} '+both([live,
                eq(nxt(r('square_sum_q')),f'(bvadd {r("square_sum_q")} {ext(product,6)})'),
                f'(=> {nphase(2)} '+both([f'(distinct {r("lane_index_q")} {bv(255,8)})',eq(nxt(r('lane_index_q')),f'(bvadd {r("lane_index_q")} {bv(1,8)})')])+')',
                f'(=> {nphase(4)} {eq(r("lane_index_q"),bv(255,8))})'])+')'])
        rules['accumulation-native-register-step']=dict(assumptions=ctx+[phase(3)],conclusion=stepfacts)
        stable=f'(=> {incoming} {eq("(h-vector hn)","(h-vector h)")})'
        rules['accumulation-history-vector-stable']=dict(assumptions=ctx+[phase(3),eq('hn','(history-next a an h)')],conclusion=stable)
        arg=f'(select (h-vector h) {r("lane_index_q")})'
        word=f'(square-word {arg})'
        wordfact=f'(=> {both([live,phase(3)])} {eq(product,word)})'
        rules['accumulation-owned-word-product']=dict(assumptions=[H('a'),'(rw-inv a h)'],conclusion=wordfact)
        cert='(square-certificate (h-vector h) c)'
        index=ext(r('lane_index_q'),1)
        lookup=f'(=> {cert} '+both([eq(f'(select c {bv(0,9)})',bv(0,38)),
            eq(f'(select c (bvadd {index} {bv(1,9)}))',f'(bvadd (select c {index}) {ext(word,6)})')])+')'
        rules['certificate-current-row-lookup']=dict(assumptions=[],conclusion=lookup)
        rules['preserved-3']['assumptions']=[phase(3),'(sq-inv a h c)',stepfacts,stable,wordfact,lookup]
    return [to_local(x) for x in decl],to_local(defs),{name:{**rule,
        'assumptions':[to_local(x) for x in rule['assumptions']],
        'conclusion':to_local(rule['conclusion'])} for name,rule in rules.items()}


if __name__=='__main__':
    import sys
    revision=2 if '--revision-2' in sys.argv else 1
    prepare();save_plan('rms-square-fold'+('-r2' if revision==2 else ''),*specification(revision),native_label='rms-local')
    print('Prepared exact complete RMS square-prefix fold; no desired native reply.')

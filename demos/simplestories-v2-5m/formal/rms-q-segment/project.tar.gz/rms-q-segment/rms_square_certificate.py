"""Pure finite square-prefix construction, independent of native state.

The ordinary finite induction here uses checked scalar integer bounds and
standard array/word semantics. It is an explicit derivation rule, never a raw
engine answer purporting to prove the complete RMS theorem.
"""
from common import HERE,bv,ext,atomic_bytes,atomic_json,sha
from rms_native_history import parse,emit

VECTOR='(Array (_ BitVec 8) (_ BitVec 16))'
CERT='(Array (_ BitVec 9) (_ BitVec 38))'


def definitions():
    defs=f'(define-fun square-prefix-0 ((v {VECTOR})) (_ BitVec 38) {bv(0,38)})\n'
    for k in range(256):
        value=f'(select v {bv(k,8)})'
        word=f'(bvmul {ext(value,16,True)} {ext(value,16,True)})'
        defs+=f'(define-fun square-prefix-{k+1} ((v {VECTOR})) (_ BitVec 38) (bvadd (square-prefix-{k} v) {ext(word,6)}))\n'
    table='((as const '+CERT+') '+bv(0,38)+')'
    for k in range(257):table=f'(store {table} {bv(k,9)} (square-prefix-{k} v))'
    defs+=f'(define-fun make-square-certificate ((v {VECTOR})) {CERT} {table})\n'
    return defs


def construction():
    source=definitions();nodes=parse(source);defs={x[1]:x for x in nodes}
    if len(defs)!=258:raise ValueError('Missing finite prefix definition')
    if defs['square-prefix-0'][4]!=parse(bv(0,38))[0]:raise ValueError('Nonzero initial sum')
    table=defs['make-square-certificate'][4];entries={}
    while isinstance(table,list) and table[0]=='store':
        index=table[2];value=table[3]
        if index[:2]!=['_','bv'+str(int(index[1][2:]))] or index[2]!='9':raise ValueError('Changed prefix table index')
        k=int(index[1][2:]);entries.setdefault(k,value);table=table[1]
    expected_base=parse('((as const '+CERT+') '+bv(0,38)+')')[0]
    if table!=expected_base or set(entries)!=set(range(257)):raise ValueError('Bad finite certificate construction')
    steps=[]
    for k in range(257):
        if entries[k]!=['square-prefix-'+str(k),'v']:raise ValueError('Wrong selected prefix')
        if k==0:continue
        value=f'(select v {bv(k-1,8)})';word=f'(bvmul {ext(value,16,True)} {ext(value,16,True)})'
        expected=parse(f'(bvadd (square-prefix-{k-1} v) {ext(word,6)})')[0]
        if defs['square-prefix-'+str(k)][4]!=expected:raise ValueError('Changed independent square recurrence')
        steps.append(dict(row=k-1,prefix=k,integer_bound=k*32767*32767,
            within_unsigned38=k*32767*32767 < 1<<38,
            term_provider='typed signed16-square-is-exact-signed32',
            bound_provider='integer-algorithms:legal-activation-square-bound and square-prefix-integer-bound',
            addition_provider='rms-word-semantics:positive-add38-no-wrap',
            certificate_read_rule='SMT-LIB select(store(a,i,v),i)=v; later distinct literal BV9 indices do not change that read'))
    if not all(x['within_unsigned38'] for x in steps):raise ValueError('Square sum overflow')
    return dict(schema='Independent-square-certificate-finite-induction-v1',definition_sha256=sha(source.encode()),
        construction_exists_for_each_vector=True,unique_prefix_values_for_indices=list(range(257)),
        legal_integer_statement='For every legal signed16 vector A[0..255], U38(prefix[k]) = sum_{i<k} Z16(A[i])^2, for all k=0..256.',
        final_maximum=256*32767*32767,finite_steps=steps,
        trusted_rule='Standard word/array definitions, finite induction and exact typed specialization of the reconstructed scalar arithmetic providers.',
        required_engine_providers=['integer-algorithms','rms-word-semantics'],required_typed_product_derivation=True,
        raw_whole_fold_UNSAT_receipt=False,full_RMS_algorithm_proved=False)


if __name__=='__main__':
    atomic_bytes(HERE/'rms-square-certificate.smt2',definitions().encode())
    atomic_json(HERE/'SQUARE-CERTIFICATE-CONSTRUCTION.json',construction())
    print('Constructed all 257 independent square prefixes and checked 256 legal integer fold steps; provider verification remains separate.')

"""Independent scalar word profile and actual RMS combinational bindings.

The full vector square fold and helper ownership are separate. These functions
contain only arguments and fixed arithmetic; no actual register or RAM read.
"""
from common import HERE,bv,both,eq,ext,save_plan
from parent_flow import S,TOP,d
from rms_capture import r
from rms_local import to_local,prepare


def definitions():
    s='((_ zero_extend 26) sum)'
    q=f'(bvlshr {s} {bv(8,64)})';rem=f'(bvand {s} {bv(255,64)})'
    up=f'(or (bvugt {rem} {bv(128,64)}) (and (= {rem} {bv(128,64)}) (= ((_ extract 0 0) {q}) #b1)))'
    defs=f'(define-fun rms-mean ((sum (_ BitVec 38))) (_ BitVec 64) (bvadd {q} (ite {up} {bv(1,64)} {bv(0,64)})))\n'
    epsilon=bv(0,45)
    for e in reversed(range(-32,32)):
        h=-20-2*e;value=(1<<h) if h>=0 else 0
        epsilon=f'(ite (= e {bv(e,8)}) {bv(value,45)} {epsilon})'
    defs+=f'(define-fun rms-epsilon ((e (_ BitVec 8))) (_ BitVec 45) {epsilon})\n'
    total=f'(bvadd ((_ zero_extend 1) ((_ extract 44 0) (rms-mean sum))) ((_ zero_extend 1) (rms-epsilon e)))'
    defs+=f'(define-fun rms-radicand-wide ((sum (_ BitVec 38)) (e (_ BitVec 8))) (_ BitVec 46) (ite (= {total} {bv(0,46)}) {bv(1,46)} {total}))\n'
    defs+='(define-fun rms-radicand ((sum (_ BitVec 38)) (e (_ BitVec 8))) (_ BitVec 45) ((_ extract 44 0) (rms-radicand-wide sum e)))\n'
    defs+=f'(define-fun rms-numerator ((v (_ BitVec 16))) (_ BitVec 64) (bvshl {ext("v",48,True)} {bv(12,64)}))\n'
    low=bv(-32767,64);high=bv(32767,64)
    clamp=f'(ite (bvslt x {low}) {low} (ite (bvsgt x {high}) {high} x))'
    defs+=f'(define-fun rms-clamp ((x (_ BitVec 64))) (_ BitVec 16) ((_ extract 15 0) {clamp}))\n'
    product=f'(bvmul {ext("v",10,True)} {ext("c",16,True)})'
    wide=f'(bvmul {ext(product,19,True)} {ext("m",29)})'
    defs+=f'(define-fun rms-scaled ((v (_ BitVec 16)) (c (_ BitVec 10)) (m (_ BitVec 16))) (_ BitVec 50) {ext(wide,5,True)})\n'
    return defs


def specification():
    defs=definitions();H=f'(|{TOP}_h| a)'
    decl=[f'(declare-const a {S})']
    rules={
        'actual-mean-is-profile-mean':dict(assumptions=[H],conclusion=eq(r('mean_square_wide'),f'(rms-mean {r("square_sum_q")})')),
        'actual-divider-clamp-is-profile-clamp':dict(assumptions=[H],conclusion=eq(r('div_clamped16'),f'(rms-clamp {r("div_response_result")})')),
        'actual-numerator-is-profile-numerator':dict(assumptions=[H],conclusion=eq(r('div_numerator'),f'(rms-numerator {r("vector_read_q")})')),
    }
    for e in range(-32,32):
        rules['actual-epsilon-exponent-'+str(e)]=dict(assumptions=[H,eq(r('input_exponent_q'),bv(e,8))],
            conclusion=eq(r('epsilon_integer'),f'(rms-epsilon {r("input_exponent_q")})'))
    epsilon=eq(r('epsilon_integer'),f'(rms-epsilon {r("input_exponent_q")})')
    mean=rules['actual-mean-is-profile-mean']['conclusion']
    rules['actual-radicand-is-profile-radicand']=dict(assumptions=[H,epsilon,mean],
        conclusion=eq(r('radicand_wide'),f'(rms-radicand-wide {r("square_sum_q")} {r("input_exponent_q")})'))
    legal=both([f'(bvsge {r("input_exponent_q")} {bv(-32,8)})',f'(bvsle {r("input_exponent_q")} {bv(31,8)})'])
    rules['exponent-case-coverage']=dict(assumptions=[legal],conclusion='(or '+' '.join(eq(r('input_exponent_q'),bv(e,8)) for e in range(-32,32))+')')
    return [to_local(x) for x in decl],defs,{name:{**rule,'assumptions':[to_local(x) for x in rule['assumptions']],
        'conclusion':to_local(rule['conclusion'])} for name,rule in rules.items()}


if __name__=='__main__':
    prepare();save_plan('rms-scalar-words',*specification(),native_label='rms-local')
    print('Prepared independent scalar arithmetic profile and native bindings.')

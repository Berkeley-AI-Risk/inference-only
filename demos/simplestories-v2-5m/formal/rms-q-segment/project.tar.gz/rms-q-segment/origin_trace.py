"""Checked last-admission fold instantiation at actual RS/RR, QA and NC.

All indices are readonly histories defined from source events. The pure
engine-checked origin/payload induction supplies nonnegative real admissions
and no-intervening-boundary intervals; no arbitrary origin function is assumed.
"""
import itertools
from common import HERE,PILOT,bv,sha,both,eq
from verify_gate import check_component
from rms_native_history import parse,emit,atoms
from derivation import canonical,apply as apply_literal
from rms_numeric_store import definitions as rr_definitions
from rms_snapshot import definitions as rs_definitions
from q_arguments_r3 import specification as qa_spec
from parent_flow import TOP,d
from q_columns import TOP as OLD
from selector import TOP as NORM


def sub(node,names):
    """Explicit safe specialization of the one quantified interval binder."""
    if not isinstance(node,list):return names.get(node,node)
    if node and node[0]=='forall':
        bound={x[0] for x in node[1]};free=set(atoms(list(names.values())))
        if bound&set(names) or bound&free:raise ValueError('Origin binder would capture a substitution')
    return [sub(x,names) for x in node]


def project(node,constructor,old,fields,old_fields,definitions):
    if isinstance(node,list) and node[0]=='ite':return ['ite',node[1],project(node[2],constructor,old,fields,old_fields,definitions),project(node[3],constructor,old,fields,old_fields,definitions)]
    if node==old:return old_fields
    if isinstance(node,str) and node in definitions:return project(definitions[node][4],constructor,old,fields,old_fields,definitions)
    if not isinstance(node,list) or node[0]!=constructor:raise ValueError('Unsupported exact source constructor projection '+emit(node))
    values=[node[i] for i in fields]
    return values[0] if len(values)==1 else ['payload',*values]


def boolean_cases(left,right):
    """Exhaust all Boolean branches; numeric payload leaves remain symbolic."""
    keys=set()
    def collect_guard(x):
        if isinstance(x,list) and x[0] in ['and','or','not']:
            for y in x[1:]:collect_guard(y)
        elif x not in ['true','false']:keys.add(emit(x))
    def scan(x):
        if isinstance(x,list):
            if x[0]=='ite':collect_guard(x[1])
            for y in x:scan(y)
    scan(left);scan(right);keys=sorted(keys)
    if len(keys)>12:raise ValueError('Unexpected Boolean projection size')
    def truth(x,assignment):
        if x=='true':return True
        if x=='false':return False
        if isinstance(x,list) and x[0]=='not':return not truth(x[1],assignment)
        if isinstance(x,list) and x[0]=='and':return all(truth(y,assignment) for y in x[1:])
        if isinstance(x,list) and x[0]=='or':return any(truth(y,assignment) for y in x[1:])
        return assignment[emit(x)]
    def evaluate(x,a):
        if isinstance(x,list) and x[0]=='ite':return evaluate(x[2] if truth(x[1],a) else x[3],a)
        return [evaluate(y,a) for y in x] if isinstance(x,list) else x
    for values in itertools.product([False,True],repeat=len(keys)):
        assignment=dict(zip(keys,values,strict=True))
        if evaluate(left,assignment)!=evaluate(right,assignment):raise ValueError('Source origin projection differs under '+str(assignment))
    return dict(boolean_atoms=keys,complete_boolean_cases=1<<len(keys),numeric_leaves_uninterpreted=True)


def definitions(text):return {x[1]:x for x in parse(text) if x[0]=='define-fun'}


def close():
    plan,receipts=check_component('admission-fold-r2','admission_fold',2)
    native,native_receipts=check_component('q-origin-source','q_origin_source',1)
    rdefs=definitions(rr_definitions(2)[0]);qdefs=definitions(qa_spec()[1]);ndefs=definitions((PILOT/'q-operator/norm-capture-r2/history.smt2').read_text())
    rr=rdefs['rr-next'][4];qa=qdefs['qa-next'][4];nc=ndefs['nc-next'][4]
    # RR reset and CLEAR differ on retained payload, so source metadata is
    # refined only while owned. Their ownership priority must match exactly.
    rrevoke=['or',rr[1],rr[3][1]];rraccept=rr[3][3][1];rrfresh=rr[3][3][2]
    rrfields=[8,9,10,2,3,4];oldr=['payload',*[[name,'rr'] for name in ['rr-input','rr-input-exponent','rr-role','rr-generation','rr-layer','rr-stage']]]
    rlive=project(rr,'rms-numeric-store','rr',[1],['rr-live','rr'],rdefs)
    rlive_target=['ite',rrevoke,'false',['ite',rraccept,'true',['rr-live','rr']]]
    r_owner=boolean_cases(rlive,rlive_target)
    rmeta=project(rr,'rms-numeric-store','rr',rrfields,oldr,rdefs)
    rsample=['payload',*[rrfresh[i] for i in rrfields]]
    # Replace the revoked payload by an arbitrary same symbol on both sides:
    # it has no authority and scoped-owned projection imposes no equality.
    def mask_revoke(node):return ['ite',rrevoke,'revoked-payload',node]
    r_payload=boolean_cases(mask_revoke(rmeta),mask_revoke(['ite',rraccept,rsample,oldr]))
    # Exact QA ownership and immutable epoch/layer/exponent tuple.
    qrevoke=qa[1];qaccept=qa[3][1];qfresh=qa[3][2]
    qlive=project(qa,'q-arguments','h',[2],['qa-owned','h'],qdefs)
    q_owner=boolean_cases(qlive,['ite',qrevoke,'false',['ite',qaccept,'true',['qa-owned','h']]])
    qmeta=project(qa,'q-arguments','h',[4,5,6],['payload',['qa-epoch','h'],['qa-layer','h'],['qa-exponent','h']],qdefs)
    qsample=['payload',*qfresh[4:7]];qzero=['payload',*qdefs['qa-zero'][4][4:7]]
    q_payload=boolean_cases(qmeta,['ite',qrevoke,qzero,['ite',qaccept,qsample,['payload',['qa-epoch','h'],['qa-layer','h'],['qa-exponent','h']]]])
    # NC's rows/job/layer tuple is an unconditional exact fold. Its nonzero
    # rows at Q output imply an owned origin by the generic nonempty lemma.
    nrevoke=nc[1];naccept=nc[3][1];nfresh=nc[3][2]
    nmeta=project(nc,'norm-capture','h',[2,4,5],['payload',['nc-rows','h'],['nc-job','h'],['nc-layer','h']],ndefs)
    nsample=['payload',nfresh[2],nfresh[4],nfresh[5]];nzero=['payload',*([ndefs['nc-zero'][4][i] for i in [2,4,5]])]
    n_payload=boolean_cases(nmeta,['ite',nrevoke,nzero,['ite',naccept,nsample,['payload',['nc-rows','h'],['nc-job','h'],['nc-layer','h']]]])
    schemas={
        'RMS':dict(revoke=rrevoke,accept=rraccept,sample=rsample,source_old='rr',owned=['rr-live','rr'],owner_projection=r_owner,payload_projection=r_payload),
        'Q':dict(revoke=qrevoke,accept=qaccept,sample=qsample,source_old='h',owned=['qa-owned','h'],owner_projection=q_owner,payload_projection=q_payload),
        'Qnorm':dict(revoke=nrevoke,accept=naccept,sample=nsample,source_old='h',owned=None,payload_projection=n_payload)}
    applications={}
    # Apply the checked base/step rule with exact SOURCE event/sample terms.
    # The functions A/B/S are then defined to those terms on the fixed trace.
    for family,schema in schemas.items():
        mapping={'time':'now','h':'origin','hn':'originn','revoke':emit(schema['revoke']),
            'accept':emit(schema['accept']),'sample':emit(schema['sample'])}
        def instantiate(name):
            rule=plan['rules'][name]
            names={k:parse(v)[0] for k,v in mapping.items()}
            return dict(assumptions=[emit(sub(parse(x)[0],names)) for x in rule['assumptions']],
                conclusion=emit(sub(parse(rule['conclusion'])[0],names)))
        base=instantiate('empty-common-reset-base');step=instantiate('last-admission-payload-and-interval-preserved')
        # Each required equation is a definitional consequence of the exact
        # functional extension. No numerical/source-state value is constrained.
        equations=dict(origin_next=step['assumptions'][1],accepted_at=step['assumptions'][2],
            boundary_at=step['assumptions'][3],sampled_at=step['assumptions'][4])
        if step['assumptions'][0]!='(origin-inv now origin)':raise ValueError('Changed origin induction hypothesis')
        ownership=instantiate('owned-origin-is-real-and-payload-is-its-sample')
        projection='scoped-owned-source-payload-projection-preserved' if family!='Qnorm' else 'complete-source-payload-projection-preserved'
        applications[family]=dict(base=base,regular_step=step,checked_functional_definition_equations=equations,
            real_origin_readout=ownership,source_constructor_projection=schema,
            payload_refinement_rule=plan['rules'][projection],
            source_observer_binding='RR/RS exact fixed native parent histories' if family=='RMS' else ('exact qualified qa-next' if family=='Q' else 'exact qualified nc-next'),
            induction='Base at the actual common-reset histories; literal regular-step implication with one current origin-inv IH and the four defining extension equations. Source owner/payload projections above close the companion refinement induction.')
        applications[family]['concrete_history_construction']=construct_family(family,schema,plan)
        applications[family]['checked_payload_refinement']=companion_application(family,schema,plan,native)
    result=dict(schema='Actual-last-admission-payload-source-closure-v1',
        schema_plan=plan['rules'],schema_receipts=receipts,applications=applications,
        normalizer_owned_readout=plan['rules']['nonempty-source-field-has-real-origin'],
        actual_owner_hold_provider=native['rules'],actual_owner_hold_receipts=native_receipts,
        exact_RS_updater=rs_definitions()[0],exact_RR_updater=emit(rdefs['rr-next']),
        exact_QA_updater=emit(qdefs['qa-next']),exact_NC_updater=emit(ndefs['nc-next']),
        all_origins_constructed_by_checked_source_folds=True,
        no_norm_vs_Q_admission_order_assumption=True)
    result['qualified_Q_start_projection']=qualified_Q_start_projection(result)
    return result


def construct_family(family,schema,plan):
    """Build typed readonly history definitions, then instantiate base/step.

    These definitions, not an arbitrary tau-origin declaration, interpret the
    three origin functions used by P_tau. They define a unique natural-number
    history for every actual source trace, and cannot constrain that trace.
    """
    from admission_fold import specification
    from derivation import apply as literal_application
    p={'RMS':'r','Q':'q','Qnorm':'n'}[family]
    types={
        'RMS':[('input','(Array (_ BitVec 8) (_ BitVec 16))'),('exponent','(_ BitVec 8)'),('role','(_ BitVec 4)'),('generation','Int'),('layer','(_ BitVec 3)'),('stage','(_ BitVec 5)')],
        'Q':[('epoch','Int'),('layer','(_ BitVec 3)'),('exponent','(_ BitVec 8)'),('generation','Int'),('position','(_ BitVec 11)')],
        'Qnorm':[('rows','(_ BitVec 10)'),('job','(_ BitVec 4)'),('layer','(_ BitVec 3)')]}
    fields=types[family];payload_type=p+'AdmissionPayload';origin_type=p+'AdmissionOrigin'
    ctor=p+'-admission-payload'
    native=lambda field,i='index':['tau-'+field,'tau',parse(i)[0]]
    def at_source(node):
        mapping={'a':native('actual') if family=='RMS' else (native('Qroot') if family=='Q' else native('Qnorm')),
            'rsn':native('RS','(+ index 1)'),'life':native('Qlife'),'z':native('Qnorm')}
        return sub(node,mapping)
    sample=at_source(schema['sample']);sample[0]=ctor
    if family=='Q':sample += [['rs-generation',native('RS')],parse(d('current_position_q',emit(native('actual'))))[0]]
    value_fields={
        'RMS':[[name,native('RR')] for name in ['rr-input','rr-input-exponent','rr-role','rr-generation','rr-layer','rr-stage']],
        'Q':[[name,native('QA')] for name in ['qa-epoch','qa-layer','qa-exponent']]+[['rs-generation',native('RS')],parse(d('current_position_q',emit(native('actual'))))[0]],
        'Qnorm':[[name,native('QNC')] for name in ['nc-rows','nc-job','nc-layer']]}
    value_definition=['define-fun',p+'-source-value-at',[['index','Int']],payload_type,[ctor,*value_fields[family]]]
    zeros={
        'RMS':['((as const (Array (_ BitVec 8) (_ BitVec 16))) '+bv(0,16)+')',bv(0,8),bv(0,4),'0',bv(0,3),bv(0,5)],
        'Q':['0',bv(0,3),bv(0,8),'0',bv(0,11)],'Qnorm':[bv(0,10),bv(0,4),bv(0,3)]}
    zero=[ctor,*[parse(x)[0] for x in zeros[family]]]
    dtype=['declare-datatypes',[],[[payload_type,[ctor,*[[p+'-sample-'+name,parse(sort)[0]] for name,sort in fields]]]]]
    symbol_map={'AdmissionPayload':payload_type,'AdmissionOrigin':origin_type,'admission-origin':p+'-admission-origin',
        **{name:p+'-'+name for name in ['empty-payload','accepted-at','boundary-at','sampled-at','origin-empty','origin-next','origin-inv','origin-live','origin-edge','origin-payload']}}
    rename=lambda node:sub(node,symbol_map)
    generic=parse(specification(2)[1]);library=[]
    for node in generic:
        if node[0]=='declare-datatypes':library.append(rename(node))
        elif node[0]=='define-fun':library.append(rename(node))
    # Exact source predicates/sample functions, with formal Int index. No
    # numeric value or origin index is a new unconstrained input.
    rev=at_source(schema['revoke']);raw_accept=at_source(schema['accept'])
    accept=['and',['not',rev],raw_accept]
    priority=boolean_cases(['ite',rev,'false',['ite',raw_accept,'true','old-owned']],
        ['ite',rev,'false',['ite',accept,'true','old-owned']])
    fdefs=[['define-fun',p+'-empty-payload',[],payload_type,zero],
        ['define-fun',p+'-revoke-at',[['index','Int']],'Bool',rev],
        ['define-fun',p+'-accepted-at',[['index','Int']],'Bool',accept],
        ['define-fun',p+'-boundary-at',[['index','Int']],'Bool',['or',[p+'-revoke-at','index'],[p+'-accepted-at','index']]],
        ['define-fun',p+'-sampled-at',[['index','Int']],payload_type,sample]]
    # A generic function signature is replaced by one explicit same-sort source
    # function. The typed datatype interpretation is valid for the engine rule
    # proved for every nonempty payload sort.
    definition_ast=[dtype,*fdefs,*library,value_definition]
    history='tau-'+family+'-origin-history';getter='tau-'+family+'-origin'
    declaration=['declare-fun',history,['FixedSegmentTrace','Int'],origin_type]
    getter_definition=['define-fun',getter,[['trace','FixedSegmentTrace'],['index','Int']],'Int',
        [p+'-origin-edge',[history,'trace','index']]]
    base_equation=['=',[history,'tau','0'],p+'-origin-empty']
    recurrence=['forall',[['index','Int']],['=>',['>=','index','0'],
        ['=',[history,'tau',['+','index','1']],[p+'-origin-next','index',[p+'-revoke-at','index'],[p+'-accepted-at','index'],[p+'-sampled-at','index'],[history,'tau','index']]]]]
    available_defs={x[1]:x for x in fdefs}
    variable_names={'time':'now','h':'origin','hn':'originn','revoke':[p+'-revoke-at','now'],
        'accept':[p+'-accepted-at','now'],'sample':[p+'-sampled-at','now']}
    def specialize(name):
        raw=plan['rules'][name]
        return dict(assumptions=[emit(sub(rename(parse(x)[0]),variable_names)) for x in raw['assumptions']],
            conclusion=emit(sub(rename(parse(raw['conclusion'])[0]),variable_names)))
    base=specialize('empty-common-reset-base');step=specialize('last-admission-payload-and-interval-preserved')
    # Build the four facts from the history and source FUNCTION DEFINITIONS,
    # independently of the engine rule's premise list.
    next_eq=eq('originn','('+p+'-origin-next now ('+p+'-revoke-at now) ('+p+'-accepted-at now) ('+p+'-sampled-at now) origin)')
    def bdy(index):return emit(sub(available_defs[p+'-boundary-at'][4],{'index':parse(index)[0]}))
    facts=['('+p+'-origin-inv now origin)',next_eq,
        eq('('+p+'-accepted-at now)','('+p+'-accepted-at now)'),
        eq('('+p+'-boundary-at now)',bdy('now')),
        eq('('+p+'-sampled-at now)','('+p+'-sampled-at now)')]
    step_application=literal_application(step,{},facts)
    base_application=literal_application(base,{},[])
    return dict(payload_fields=fields,typed_source_function_definitions=definition_ast,
        origin_history_declaration=declaration,origin_getter_definition=getter_definition,
        constructed_history_base=base_equation,constructed_history_recurrence=recurrence,
        actual_base_application=base_application,actual_regular_step_application=step_application,
        actual_real_origin_rule=specialize('owned-origin-is-real-and-payload-is-its-sample'),
        source_value_function_definition=value_definition,
        source_sample_expression=sample,source_revoke_expression=rev,source_accept_expression=accept,
        effective_admission_priority_projection=priority,raw_admission_expression=raw_accept,
        existence_rule='Primitive recursion on nonnegative clock indices gives this readonly history for every fixed source trace. Base/step application proves origin-inv by ordinary induction; negative indices are unused.',
        uniform_sort_and_function_specialization=symbol_map)


def companion_application(family,schema,plan,native):
    """Apply source-payload refinement after the checked constructor cases.

    Source fresh/hold facts here are derived by the complete Boolean projection
    checks in close(), with Q's additional generation/position fields supplied
    by the exact separately proved native hold implications.
    """
    from derivation import apply as literal_application
    prefix={'RMS':'r','Q':'q','Qnorm':'n'}[family]
    typ=prefix+'AdmissionPayload';field=prefix+'-identity-field'
    names={
        'time':'now','h':'origin','hn':'originn','value':'('+prefix+'-source-value-at now)','valuen':'('+prefix+'-source-value-at (+ now 1))',
        'sample':'('+prefix+'-sampled-at now)','scope':'true' if family!='Q' else d('rst_n','(tau-actual tau now)'),
        'scopen':'true' if family!='Q' else d('rst_n','(tau-actual tau (+ now 1))'),
        'revoke':'('+prefix+'-revoke-at now)','accept':'('+prefix+'-accepted-at now)',
        'payload-field':field,'origin-next':prefix+'-origin-next','origin-live':prefix+'-origin-live',
        'origin-payload':prefix+'-origin-payload','empty-payload':prefix+'-empty-payload'}
    def specialize(rule):
        mapping={k:parse(v)[0] for k,v in names.items()}
        return dict(assumptions=[emit(sub(parse(x)[0],mapping)) for x in rule['assumptions']],
            conclusion=emit(sub(parse(rule['conclusion'])[0],mapping)))
    nrel=eq('originn','('+prefix+'-origin-next now '+names['revoke']+' '+names['accept']+' '+names['sample']+' origin)')
    if family=='Qnorm':
        key='complete-source-payload-projection-preserved';rule=specialize(plan['rules'][key])
        initial=eq(names['value'],'('+field+' ('+prefix+'-origin-payload origin))')
        reset='(=> '+names['revoke']+' (= '+names['valuen']+' ('+field+' '+prefix+'-empty-payload)))'
        fresh='(=> (and (not '+names['revoke']+') '+names['accept']+') (= '+names['valuen']+' ('+field+' '+names['sample']+')))'
        hold='(=> (and (not '+names['revoke']+') (not '+names['accept']+')) (= '+names['valuen']+' '+names['value']+'))'
        facts=[nrel,initial,reset,fresh,hold]
    else:
        key='scoped-owned-source-payload-projection-preserved';rule=specialize(plan['rules'][key])
        initial='(=> (and '+names['scope']+' ('+prefix+'-origin-live origin)) (= '+names['value']+' ('+field+' ('+prefix+'-origin-payload origin))))'
        fresh='(=> (and '+names['scopen']+' (not '+names['revoke']+') '+names['accept']+') (= '+names['valuen']+' ('+field+' '+names['sample']+')))'
        hold='(=> (and '+names['scopen']+' (not '+names['revoke']+') (not '+names['accept']+') ('+prefix+'-origin-live origin)) (and '+names['scope']+' (= '+names['valuen']+' '+names['value']+')))'
        facts=[nrel,initial,fresh,hold]
    extra={}
    if family=='Q':
        # The old root is the exact source observation of the same actual
        # parent. Its QA reset/clear/stage/head predicate is mapped by name.
        def view(x):
            return [view(y) for y in x] if isinstance(x,list) else x.replace('|'+OLD+'_n ','|'+TOP+'_n ')
        projected_revoke=view(schema['revoke'])
        pos=native['rules']['no-QA-revocation-holds-actual-layer-and-position']
        gen=native['rules']['no-QA-revocation-holds-RMS-generation']
        norevoke=pos['assumptions'][3]
        de_morgan=boolean_cases(['ite',parse(norevoke)[0],'true','false'],['ite',['not',projected_revoke],'true','false'])
        pos_app=literal_application(pos,{},pos['assumptions'])
        gen_app=literal_application(gen,{},gen['assumptions'])
        extra=dict(exact_NoQARevoke_source_projection=de_morgan,
            native_position_hold=pos_app,native_generation_hold=gen_app,
            field_extension=['Sample actual RS generation at the SAME descriptor edge',
                'Sample actual parent position at that SAME descriptor edge'],
            source_fresh_hold_congruence='Under not revoke, both native source implications apply (position requires post-reset scope). Fresh and held QA metadata come from the exact projected constructors. Tuple congruence supplies the five-field source value in the generic projection rule.')
    return dict(rule=key,actual_application=literal_application(rule,{},facts),
        legitimate_predecessor_projection_IH=initial,
        source_constructor_providers=[fresh,hold] if family!='Qnorm' else [reset,fresh,hold],
        source_projection=schema['payload_projection'],additional_native_source_providers=extra,
        identity_payload_field_definition=['define-fun',field,[['value',typ]],typ,'value'],
        induction_rule='Exact source constructor projections supply reset/fresh/hold; one predecessor payload-refinement IH, total readonly origin recurrence, and the engine-checked parametric projection implication supply the next refinement.')


def lookup(binding,family,index):
    """Actual-origin and sampled-field consequence under explicit authority.

    Its only open conditions are the source ownership/rows and scope guards,
    which the producer must discharge from its qualified endpoint/admission.
    """
    item=binding['applications'][family];concrete=item['concrete_history_construction']
    prefix={'RMS':'r','Q':'q','Qnorm':'n'}[family]
    history='(tau-'+family+'-origin-history tau '+index+')';origin='(tau-'+family+'-origin tau '+index+')'
    parsed_index=parse(index)[0]
    rule=concrete['actual_real_origin_rule'];rename={'now':parsed_index,'origin':parse(history)[0]}
    rule={key:([emit(sub(parse(x)[0],rename)) for x in value] if key=='assumptions' else emit(sub(parse(value)[0],rename))) for key,value in rule.items()}
    have=['('+prefix+'-origin-inv '+index+' '+history+')','('+prefix+'-origin-live '+history+')']
    if set(map(canonical,rule['assumptions']))!=set(map(canonical,have)):raise ValueError('Changed actual origin ownership readout interface')
    # The first fact is the just reconstructed common-reset/step induction.
    # The second comes from the exact source owner projection, or the NC
    # nonempty-payload application described below.
    source_owner={'RMS':'(rr-live (tau-RR tau '+index+'))',
        'Q':'(qa-owned (tau-QA tau '+index+'))','Qnorm':'(= (nc-rows (tau-QNC tau '+index+')) '+bv(256,10)+')'}[family]
    scope='true' if family!='Q' else d('rst_n','(tau-actual tau '+index+')')
    definitions=concrete['typed_source_function_definitions']
    value=concrete['source_value_function_definition'][4]
    sample=concrete['source_sample_expression']
    value=sub(value,{'index':parsed_index});sample=sub(sample,{'index':parse(origin)[0]})
    if value[0]!=sample[0] or len(value)!=len(sample):raise ValueError('Payload source/sample constructor cannot be decomposed')
    fields=[eq(emit(a),emit(b)) for a,b in zip(value[1:],sample[1:],strict=True)]
    effective=sub(concrete['source_accept_expression'],{'index':parse(origin)[0]})
    if effective[0]!='and' or effective[1][0]!='not':raise ValueError('Origin readout lacks nonrevoked admission')
    consequences=['(>= '+origin+' 0)','(< '+origin+' '+index+')',emit(effective),*fields]
    function_defs={x[1]:x for x in definitions if x[0]=='define-fun'}
    def inline(node):
        if not isinstance(node,list):return node
        if node and node[0] in [prefix+'-boundary-at',prefix+'-revoke-at',prefix+'-accepted-at']:
            definition=function_defs[node[0]]
            return inline(sub(definition[4],{'index':node[1]}))
        return [inline(x) for x in node]
    interval=['forall',[['origin_interval_k','Int']],['=>',
        ['and',['<',parse(origin)[0],'origin_interval_k'],['<','origin_interval_k',parsed_index]],
        ['not',inline([prefix+'-boundary-at','origin_interval_k'])]]]
    consequences.append(emit(interval))
    nonempty=None
    if family=='Qnorm':
        value_def=concrete['source_value_function_definition']
        empty=next(x for x in definitions if x[:2]==['define-fun','n-empty-payload'])[4]
        if value_def[4][0]!=empty[0] or empty[1]!=parse(bv(0,10))[0]:raise ValueError('NC empty-payload row discriminant changed')
        if parse(bv(256,10))[0]==empty[1]:raise ValueError('NC row discriminant is not distinct')
        raw=binding['normalizer_owned_readout']
        # Generic field is identity on this typed payload, with complete
        # source-value projection established above at every predecessor.
        mappings={'time':parsed_index,'h':parse(history)[0],
            'value':parse('(n-source-value-at '+index+')')[0],
            'origin-inv':'n-origin-inv','origin-live':'n-origin-live','origin-payload':'n-origin-payload',
            'empty-payload':'n-empty-payload','payload-field':'n-identity-field'}
        specialized={key:([emit(sub(parse(x)[0],mappings)) for x in val] if key=='assumptions' else emit(sub(parse(val)[0],mappings))) for key,val in raw.items()}
        expected=[have[0],eq('(n-source-value-at '+index+')','(n-identity-field (n-origin-payload '+history+'))'),
            '(distinct (n-source-value-at '+index+') (n-identity-field n-empty-payload))']
        from derivation import apply as literal_application
        nonempty=dict(application=literal_application(specialized,{},expected),
            projection_provider=item['checked_payload_refinement'],
            distinct_constructor_field=dict(source_condition=source_owner,actual_rows=bv(256,10),empty_rows=bv(0,10),
                rule='Typed datatype constructor injectivity: distinct literal BV10 rows force different complete payloads.'))
    return dict(open_source_authority_conditions=[source_owner]+([] if scope=='true' else [scope]),
        checked_origin_induction=item['concrete_history_construction']['actual_regular_step_application'],
        exact_source_owner_projection=item['source_constructor_projection'].get('owner_projection'),
        normalizer_nonempty_application=nonempty,
        actual_real_origin_rule_application=dict(assumptions=have,conclusion=rule['conclusion'],all_premises_closed_by_origin_induction_and_source_authority=True),
        payload_projection_application=item['checked_payload_refinement']['actual_application'],
        constructor_decomposition=dict(current=emit(value),sample_at_real_admission=emit(sample),field_equalities=fields),
        conclusion=both(consequences),real_admission_event=emit(effective),
        interval_without_revocation_or_readmission=emit(interval),
        same_origin_interval=rule['conclusion'],
        inference='Apply the checked origin invariant readout to its constructed history, rewrite its edge with the exact origin getter definition, combine the scoped source-payload projection with payload-at-admission, and eliminate equal typed constructor fields.')


def qualified_Q_start_projection(binding):
    """Actual QA admission is the same Q-mode projection-child start event."""
    from query_numeric_producer import body_files
    from rms_q_argument import j
    from q_input_capture import definitions as qinput_definitions
    original={}
    for name in body_files():original.update(definitions((PILOT/'q-operator'/name).read_text()))
    source=binding['applications']['Q']['source_constructor_projection']['accept']
    old_native=definitions((PILOT/'model-consumption/connected/native.smt2').read_text())
    actual_native=definitions((HERE/'context/native.smt2').read_text())
    getters={}
    def unfold(node):
        if not isinstance(node,list):return node
        if node[0] in ['qn-Q-mode','ql-P-start']:
            definition=original[node[0]]
            return unfold(sub(definition[4],{a[0]:v for a,v in zip(definition[2],node[1:],strict=True)}))
        if isinstance(node[0],str) and node[0].startswith('|'+OLD+'_n '):
            target=node[0].replace('|'+OLD+'_n ','|'+TOP+'_n ',1)
            if node[0] not in old_native or target not in actual_native or old_native[node[0]][3]!=actual_native[target][3]:
                raise ValueError('Missing typed actual descriptor source view '+node[0])
            getters[node[0]]=dict(actual=target,sort=old_native[node[0]][3]);return [target,*node[1:]]
        return [unfold(x) for x in node]
    actual=emit(unfold(source))
    desired=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5)),j('start_transfer')])
    from derivation import conjuncts
    if set(conjuncts(actual))!=set(conjuncts(desired)):raise ValueError('QA admission is not the actual Q-mode projection start')
    return dict(original_source_event=emit(source),actual_source_event=actual,desired_event=desired,
        complete_literal_conjunction_projection=True,typed_source_getters=getters,
        descriptor_validity_provider='rms-q-argument-r4:actual-Q-start-descriptor-is-valid, under the closed current caller/RR/QInput joint invariant at this real admission')

# Baseline RMSNorm-to-Q graph segment

The owner authorized this milestone after publication of the complete Q
operator. Work is local until the connected milestone is qualified. The old
RMSNorm, memory, operand and Q packets remain unchanged.

## Statement to establish

For the named baseline digital RTL, start from its actual common hard reset.
At an accepted input-RMS stage, name the current layer/work owner and the
complete hidden vector that this stage actually consumes. Show that:

1. RMSNorm refines a fixed, independently written finite arithmetic algorithm
   on that vector, its exponent and the fixed role-selected model coefficients.
   State every rounding, saturation, rejection and permitted emitted prefix.
2. Each RMS RAM write has that current result and owner. The following Q stage
   reads exactly that complete vector and its corresponding exponent through
   the actual synchronous RAM/caller path. Correct private RAM replies are not
   assumptions.
3. Invoke the qualified Q theorem at its actual source instance and invocation.
   The Q-store admissions, retained Q RAM and subsequent pre-overwrite reads
   have the resulting values. Identify any Q-RoPE overwrite rather than
   attributing its new values to the unrotated Q operator.
4. Actual stage sequencing, CLEAR, faults, drain and later invocations preserve
   this ownership. No extra DUT reset, clean retained RAM, future-health promise
   or correct numerical child reply is assumed.

The incoming layer activation is an explicit segment boundary. Its full graph
and accepted-tape meaning is still a later obligation. This segment does not
prove the remaining graph, timing/fault authorization, all public commands,
startup image authentication, other configurations or bitstream equivalence.

## Proof route

The fresh approach review recommends a caller/RAM-first internal gate. Fix the
stage-entry generation/owner/vector, prove its captured RMS inputs, then the
complete RMS write/exponent prefix and actual Q captures. Use the existing
source-defined RMS F interface provisionally, with its actual producer bound
on the same trace. This gate is not the advertised independent-algorithm result.
The full segment milestone must subsequently replace F by the closed algorithm.

Freeze an independent arithmetic profile. Reuse the existing normalizer
algorithm and exact implementation theorem where source/parameters agree.
Establish the RMS square/prefix, mean/epsilon, integer-root digit algorithm,
bounded rounded division, clamp and two model-scaled multiplies with actual
producer/port bindings. Reuse the old RMS invocation/history result rather than
re-proving its stall/CLEAR independence.

Restore/prove the actual hidden, RMS and query RAMs and the caller controller
cones. Use total read-only SMT histories of accepted events, not added driving
HDL. A source-preserving arbitrary-signal cut may support a local lemma, but
its original signal and exact source instance must be bound in the final trace.
Local implications are not a composed theorem until every premise is closed
on the same trace and owner. Keep the public Q packet immutable.

Qualify at the connected segment, including full-vector actual RTL operating
cases, stalls, cancellation/fresh work without another hard reset and actual-only
wrong-bank/stale-RAM/wrong-read defects. Independently computed arithmetic
expected values must remain unchanged when the actual design is mutated.

## Resource and recovery policy

No token cap. At most eight owned solver processes, 8 GiB each, 64 GiB total,
600 seconds per query. Keep every canonical query, engine input, raw answer,
failure and source/spec pin. Reassess a failing/timeout decomposition; do not
repeat an unchanged query or silently weaken the theorem. Longer targeted
retries require a saved reason. Save atomic state after each result and a
compact checkpoint before method changes. Do not run the old recursive pilot
snapshot over all historical build artifacts.

Completion requires actual induction/algorithm correspondence, exact provider
and instance premise closure, portable reproducibility and finite operating and
defect evidence. Counts of local passing queries are never segment completion.

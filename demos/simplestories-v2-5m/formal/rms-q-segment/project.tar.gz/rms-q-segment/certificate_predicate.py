"""Concrete immutable-trace predicate and fresh full-record introduction.

Tau is fixed OUTSIDE the storage induction: one legal source trace and its
already certified deterministic observers, source projections, model and clock
semantics. Saved indices point into that fixed family, never the later current
RMS/QA/program state. The predicate carries literal Q numerical clauses and
actual RMS-origin/accepted-input/program-history bindings.
"""
from common import bv,both,eq
from rms_native_history import parse,emit
from derivation import replace,canonical,conjuncts
from parent_flow import TOP,d
from q_columns import TOP as QTOP
from selector import TOP as NTOP
from q_model import MODEL

FIELDS=[('rms-admission','Int'),('q-admission','Int'),('normalizer-admission','Int'),('edge','Int'),
    ('value','(_ BitVec 16)'),('exponent','(_ BitVec 8)'),('row','(_ BitVec 8)'),('generation','Int'),
    ('layer','(_ BitVec 3)'),('position','(_ BitVec 11)'),('QA','QArguments'),('QNA','NormAlgorithm'),('QNC','NormCapture')]
TRACE_FIELDS={'actual':'|'+TOP+'_s|','Qroot':'|'+QTOP+'_s|','Qnorm':'|'+NTOP+'_s|',
    'RS':'RMSSnapshot','RR':'RMSNumericStore','QA':'QArguments','QNA':'NormAlgorithm','QNC':'NormCapture',
    'Qout':'QOutput','Qlife':'QLifecycle','RMS-origin':'Int','Q-origin':'Int','Qnorm-origin':'Int'}


def at(field,index):return '(tau-'+field+' tau '+index+')'
def field(name):return '(proof-'+name+' record)'


def origin_bindings(interface,frame):
    # This is a last-admission/source-history construction, not an extra input
    # assumption. Verify the actual fold constructors it specializes.
    from rms_numeric_store import definitions as rr_defs
    from rms_snapshot import definitions as rs_defs
    from q_arguments_r3 import specification as qa_spec
    rr=next(x for x in parse(rr_defs(2)[0]) if x[:2]==['define-fun','rr-next'])
    body=rr[4];fresh=body[3][3][2]
    if fresh[0]!='rms-numeric-store' or fresh[8:]!=parse('(rs-vector rsn) (rs-exponent rsn) (bvadd (bvmul ((_ zero_extend 1) (rs-layer rsn)) '+bv(2,4)+') (ite (= (rs-stage rsn) '+bv(0,5)+') '+bv(0,4)+' '+bv(1,4)+'))'):
        raise ValueError('RMS origin input/role is not the exact new-admission snapshot')
    # Every non-admission branch holds those three input fields, including
    # CLEAR; a cancelled frame cannot acquire a complete authoritative count.
    for constructor in [body[3][2],body[3][3][3][2]]:
        if constructor[0]!='rms-numeric-store' or constructor[8:]!=[['rr-input','rr'],['rr-input-exponent','rr'],['rr-role','rr']]:
            raise ValueError('RMS saved origin input changes inside a frame')
    if not frame['all_selected_frame_rules_applied'] or len(interface['checked_accepted_fold_derivation']['accepted_steps'])!=256:
        raise ValueError('Origin introduction needs closed full RMS frame and accepted fold')
    from origin_trace import close as origin_close
    checked=origin_close()
    return dict(rule='Deterministic last-admission fold on one fixed source trace; simultaneous reset/CLEAR/new-admission priorities are exactly the certified history constructors',
        checked_actual_source_origin_folds=checked,
        constructed_origin_definitions={name:row['concrete_history_construction'] for name,row in checked['applications'].items()},
        checked_RR_fresh_constructor=emit(fresh),checked_RR_hold_branches=True,
        established_ownership='The closed RS/RR/QA/lifecycle histories start unowned, gain authority only at these actual admissions, and revoke it under their exact cancellation priorities. A completed/current Q write supplies their admission witnesses; numeric epoch/generation equality is never used as identity.',
        actual_program_history='tau-QNC and tau-QNA are the exact qualified capture and na-next observer histories at actual u_normalizer ports, with their reset bases and source projection; tau-Qnorm-origin identifies that execution prefix. They are fixed parameters of P_tau, not arbitrary program/event witnesses.')


def build(interface,q_import,frame):
    origins=origin_bindings(interface,frame)
    edge=field('edge');qedge=field('q-admission');redge=field('rms-admission')
    qa=field('QA');na=field('QNA');nc=field('QNC');rr=at('RR',qedge)
    clauses={}
    def add(name,text):clauses[name]=canonical(text)
    add('same-RMS-origin',eq(redge,at('RMS-origin',qedge)))
    add('same-Q-admission',eq(qedge,at('Q-origin',edge)))
    add('same-Q-normalizer-prefix',eq(field('normalizer-admission'),at('Qnorm-origin',edge)))
    from origin_trace import lookup
    origin_witnesses={f:lookup(origins['checked_actual_source_origin_folds'],f,
        qedge if f=='RMS' else edge) for f in ['RMS','Q','Qnorm']}
    for name,witness in origin_witnesses.items():
        # Nonnegative real admission indices and explicit uncancelled
        # intervals are part of P, not reflexive index-field equalities alone.
        index=qedge if name=='RMS' else edge
        origin=at(name+'-origin',index)
        add(name+'-origin-exists','(>= '+origin+' 0)')
        add(name+'-origin-is-prior','(< '+origin+' '+index+')')
        add(name+'-real-admission',witness['real_admission_event'])
        add(name+'-uncancelled-interval',witness['interval_without_revocation_or_readmission'])
    add('saved-QA-history',eq(qa,at('QA',edge)))
    add('saved-QNA-history',eq(na,at('QNA',edge)))
    add('saved-captured-Q-input',eq(nc,at('QNC',edge)))
    add('complete-RMS-reference',eq('(rr-count '+rr+')',bv(256,9)))
    add('RMS-input-from-admission',eq('(rr-input '+rr+')','(rs-vector '+at('RS','(+ '+redge+' 1)')+')'))
    add('RMS-exponent-from-admission',eq('(rr-input-exponent '+rr+')','(rs-exponent '+at('RS','(+ '+redge+' 1)')+')'))
    add('Q-accepted-exponent',eq('(qa-exponent '+qa+')','(rr-exponent '+rr+')'))
    add('Q-accepted-layer',eq('(qa-layer '+qa+')','(rr-layer '+rr+')'))
    add('Q-accepted-epoch',eq('(qa-epoch '+qa+')','(ql-epoch '+at('Qlife',qedge)+')'))
    add('saved-value',eq(field('value'),'(na-mantissa '+na+')'))
    add('saved-exponent',eq(field('exponent'),'(na-candidate '+na+')'))
    add('saved-row',eq(field('row'),'((_ extract 7 0) (na-scan '+na+'))'))
    add('saved-generation',eq(field('generation'),'(rr-generation '+rr+')'))
    add('saved-layer',eq(field('layer'),'(qa-layer '+qa+')'))
    add('saved-position',eq(field('position'),'(|'+TOP+'_n u_native.u_six_layers.u_datapath.current_position_q| '+at('actual',qedge)+')'))
    # Expand the uniform-row theorem at every literal used coordinate. There
    # is no claim about the unused BV10 tail of the accepted array.
    goal=q_import['full_numerical_endpoint']
    for row in range(256):
        add('accepted-word-'+str(row),eq('(select (qa-vector '+qa+') '+bv(row,10)+')','(select (rr-vector '+rr+') '+bv(row,8)+')'))
        substitutions={'a':at('Qroot',edge),'z':at('Qnorm',edge),'qa':qa,'na':na,'nc':nc,
            'out':at('Qout',edge),'model':'fixed-Q-model','watch':bv(row,10)}
        full=emit(replace(parse(goal)[0],substitutions))
        for i,c in enumerate(conjuncts(full)):add('full-Q-'+str(row)+'-'+str(i),c)
    datatype='(declare-datatypes () ((SegmentProofRecord (segment-proof-record '+' '.join('(proof-'+n+' '+sort+')' for n,sort in FIELDS)+'))))\n'
    declaration='(declare-sort FixedSegmentTrace 0)\n(declare-const tau FixedSegmentTrace)\n(declare-const fixed-Q-model '+MODEL+')\n'
    declaration+=''.join('(declare-fun tau-'+name+' (FixedSegmentTrace Int) '+sort+')\n' for name,sort in TRACE_FIELDS.items())
    predicate='(define-fun P_tau ((record SegmentProofRecord)) Bool '+both(list(dict.fromkeys(clauses.values())))+')\n'
    fresh_values=['(tau-RMS-origin tau (tau-Q-origin tau t))','(tau-Q-origin tau t)','(tau-Qnorm-origin tau t)','t',
        '(na-mantissa '+at('QNA','t')+')','(na-candidate '+at('QNA','t')+')','((_ extract 7 0) (na-scan '+at('QNA','t')+'))',
        '(rs-generation '+at('RS','t')+')',d('current_layer_q',at('actual','t')),d('current_position_q',at('actual','t')),
        at('QA','t'),at('QNA','t'),at('QNC','t')]
    constructor='(segment-proof-record '+' '.join(fresh_values)+')'
    # Expand every getter of the explicit fresh constructor. The provider
    # builders below are independent of P's conjunction and must derive each
    # resulting clause from the fixed-history module contracts.
    field_values={'(proof-'+name+' record)':value for (name,sort),value in zip(FIELDS,fresh_values,strict=True)}
    def expand(node):
        text=emit(node)
        if text in field_values:return parse(field_values[text])[0]
        return [expand(x) for x in node] if isinstance(node,list) else node
    required={name:canonical(emit(expand(parse(text)[0]))) for name,text in clauses.items()}
    return dict(datatype=datatype,trace_declarations=declaration,predicate=predicate,
        clauses=clauses,expanded_fresh_clauses=required,fresh_constructor=constructor,
        field_values=field_values,origin_construction=origins,
        actual_origin_witnesses=origin_witnesses,
        fixed_trace_context='One actual common-reset legal source trace; its exact deterministic admitted histories and pure-program recurrences are fixed before P_tau or the storage induction. The reconstructed caller/RMS/Q certificates and four named boundaries supply those trace families.')


def fixed_family_binding(interface):
    from common import PILOT,sha
    from trace_closure import UPDATERS,ZERO,SCHEDULE
    needed={'nc':'(nc-next z nc)','na':'(na-next z nc na)','qa':'(qa-next a z life ch qa)',
        'life':'(ql-next a z life)'}
    if any(UPDATERS.get(k)!=v for k,v in needed.items()):raise ValueError('Changed certified Q program/capture/argument history family')
    if not {'norm-algorithm-r2','norm-capture-r2','q-arguments-r3','q-lifecycle-r2'}<=set(x[0] for x in SCHEDULE):
        raise ValueError('Fixed trace lacks a certified history family')
    source=interface['actual_Q_source_specialization']
    if not source['qualified_Q_trace']['all_premises_closed'] or not source['native_normalizer_same_source_ports_defaults']:
        raise ValueError('Fixed trace lacks closed actual Q/normalizer source specialization')
    files=['norm-algorithm-r2/history.smt2','norm-capture-r2/history.smt2','q-arguments-r3/history.smt2','q-lifecycle-r2/history.smt2']
    return dict(qualified_reset_and_step=source['qualified_Q_trace'],exact_actual_source_projection=source['output_trace_projection'],
        deterministic_history_updaters=needed,actual_common_reset_bases={k:ZERO[k] for k in needed},
        frozen_history_definitions={f:sha((PILOT/'q-operator'/f).read_bytes()) for f in files},
        semantics='tau is one fixed actual legal trace and these deterministic observer folds from its actual common reset, instantiated through the checked source projections. Inputs/events of na-next are those exact source expressions. The captured input and invocation prefix origin remain available at saved indices.')


def producer(interface,q_import,frame,owner_applications,admission_application):
    """Introduce P_tau(fresh) by literal clause expansion and closed providers."""
    certificate=build(interface,q_import,frame)
    family=fixed_family_binding(interface)
    qedge=at('Q-origin','t');redge=at('RMS-origin',qedge);qa=at('QA','t');na=at('QNA','t');nc=at('QNC','t');rr=at('RR',qedge)
    facts={'true'};providers=[]
    def supply(rule,conclusions,premises):
        rows=[canonical(x) for x in conclusions];facts.update(v for x in rows for v in conjuncts(x))
        providers.append(dict(rule=rule,premises=premises,conclusions=rows))
    # This source is the reconstructed full endpoint, not the scalar adapter
    # and not the target P. Apply its uniform row family at every used row.
    goals=[]
    for row in range(256):
        mapping={'a':at('Qroot','t'),'z':at('Qnorm','t'),'qa':qa,'na':na,'nc':nc,
            'out':at('Qout','t'),'model':'fixed-Q-model','watch':bv(row,10)}
        goals.append(emit(replace(parse(q_import['full_numerical_endpoint'])[0],mapping)))
    supply('Full qualified Q theorem: exact source/history specialization and 256 literal watched-row applications',goals,
        ['closed_Q_payload_import.full_numerical_endpoint','fixed_family_binding'])
    actual_binding=parse(q_import['closed_source_producer_implication'])[0]
    if actual_binding[:2]!=['=>',['actual-qualified-Q-write','a']]:raise ValueError('Changed actual scalar producer source guard')
    supply('Already-derived exact actual Q event rewrite and scalar field-binding adapter',[
        emit(replace(actual_binding[2],{'a':at('actual','t'),'qa':qa,'qna':na}))],
        ['literal qualified-product adapter application','proved actual Q-write / qualified event equivalence'])
    reset=parse(q_import['closed_source_reset_implication'])[0]
    if reset[:2]!=['=>',['actual-qualified-Q-write','a']]:raise ValueError('Changed qualified caller reset implication')
    supply('Qualified source-event live-caller application, exact actual event rewrite',[
        emit(replace(reset[2],{'a':at('actual','t')}))],
        [q_import['qualified_caller_application'],'actual Q-write event equivalence'])
    # The final accepted prefix theorem is literally substituted into the
    # already checked qa-next snapshot event, followed by its hold rule.
    complete=interface['checked_accepted_fold_derivation']['complete']['conclusion']
    expected='(= (select table_256 ((_ zero_extend 2) watch)) (select vector watch))'
    if canonical(complete)!=canonical(expected):raise ValueError('Changed accepted-prefix output contract')
    words=[]
    for row in range(256):
        words.append(emit(replace(parse(complete)[0],{'table_256':'(qa-vector '+qa+')','vector':'(rr-vector '+rr+')','watch':bv(row,8)})))
    supply('Definitional late-QA snapshot, then qualified QA hold; exact finite accepted-fold output substitution',words,
        ['accepted_input_certificate: base + 256 accepted steps + completion',
            'exact source_histories.qa_snapshot_guard and qa_snapshot',
            'checked_native_adapter_applications.admission_reference_hold','qualified QA/lifecycle ownership and same-admission origin fold'])
    # Metadata expressions below are independent of P's clause list. Their
    # source binders are checked against exact constructor/event fields.
    histories=interface['accepted_history']
    fresh=parse(histories['qa_fresh'])[0]
    from q_columns import TOP as OLD,J
    oldn=lambda f:['|'+OLD+'_n '+J+f+'|','a']
    if fresh[4:]!=[['ql-epoch','life'],oldn('fixed_layer_i'),oldn('activation_exponent_i')]:
        raise ValueError('QA metadata source constructor changed')
    adapter=interface['checked_native_adapter_applications']['applications']['actual-Q-admission-fixes-independent-RMS-reference']['application']['conclusion']
    from rms_q_argument import j
    required=[eq(j('activation_exponent_i'),'(rr-exponent rr)'),eq(j('fixed_layer_i'),'(rr-layer rr)'),eq('(rr-count rr)',bv(256,9))]
    if not set(map(canonical,required))<=set(conjuncts(adapter)):raise ValueError('Actual descriptor lacks required numerical/metadata binders')
    # First obtain the actual Q and normalizer admission witnesses. Their
    # authority conditions are consequences of the qualified full Q endpoint
    # and actual live caller; no arbitrary origin/-1 assumption is supplied.
    from origin_trace import lookup
    origin_binding=certificate['origin_construction']['checked_actual_source_origin_folds']
    lookups={f:lookup(origin_binding,f,'t') for f in ['Q','Qnorm']}
    for name,witness in lookups.items():
        absent=[x for x in witness['open_source_authority_conditions'] if canonical(x) not in facts]
        if absent:raise ValueError('Unclosed actual origin authority '+name+': '+str(absent))
        supply('Constructed actual '+name+' origin invariant/payload readout',
            [witness['conclusion']],[witness])
    # The same real descriptor is established by exact Q-mode/start source
    # projection. Its validity and current RR facts are the already checked
    # actual input-adapter applications on that historical edge.
    if not origin_binding['qualified_Q_start_projection']['complete_literal_conjunction_projection']:
        raise ValueError('Historical Q origin is not the actual descriptor admission')
    past= {'a':at('actual',qedge),'rs':at('RS',qedge),'rr':rr}
    admit_goal=emit(replace(parse(admission_application['conclusion'])[0],past))
    supply('Actual input-adapter and origin-tag application at the constructed real Q admission',[
        admit_goal,eq('(rr-count '+rr+')',bv(256,9))],
        [lookups['Q']['real_admission_event'],origin_binding['qualified_Q_start_projection'],
            'rms-q-argument-r4:actual-Q-start-descriptor-is-valid',admission_application])
    rms_witness=lookup(origin_binding,'RMS',qedge)
    missing=[x for x in rms_witness['open_source_authority_conditions'] if canonical(x) not in facts]
    if missing:raise ValueError('Unclosed real RMS admission ownership '+str(missing))
    supply('Constructed actual RMS origin and sampled entry payload readout',[rms_witness['conclusion']],[rms_witness])
    # Descriptor exponent/layer equalities are literal output conjuncts of the
    # native source adapter, instantiated at that same real historical edge.
    supply('Literal real-descriptor exponent/layer reference binders at its proved origin',[
        emit(replace(parse(x)[0],{'a':at('actual',qedge),'rr':rr})) for x in required],
        [lookups['Q']['real_admission_event'],'actual source descriptor projection and valid-descriptor provider',
            interface['checked_native_adapter_applications']['applications']['actual-Q-admission-fixes-independent-RMS-reference']])
    # Native field equality between the qualified old source view and the
    # actual restored parent is checked for the descriptor sample ports too.
    from common import HERE,PILOT
    old_defs={x[1]:x for x in parse((PILOT/'model-consumption/connected/native.smt2').read_text()) if x[0]=='define-fun'}
    new_defs={x[1]:x for x in parse((HERE/'context/native.smt2').read_text()) if x[0]=='define-fun'}
    historical_views=[]
    for f in ['fixed_layer_i','activation_exponent_i']:
        old='|'+OLD+'_n '+J+f+'|';new=old.replace('|'+OLD+'_n ','|'+TOP+'_n ',1)
        if old not in old_defs or new not in new_defs or old_defs[old][3]!=new_defs[new][3]:raise ValueError('Missing typed historical descriptor source view '+old)
        historical_views.append(eq('('+old+' '+at('Qroot',qedge)+')','('+new+' '+at('actual',qedge)+')'))
    supply('Exact typed descriptor-port source projection at its real admission',historical_views,
        [origin_binding['qualified_Q_start_projection'],'qualified restored-parent source restriction'])
    # The constructed Q payload already includes exact source generation and
    # position, with scoped source-refinement applications. No unproved
    # iteration statement is used in place of that history.
    required_context={'Q-invocation-layer-and-position-held','Q-invocation-RMS-reference-and-origin-held'}
    if set(owner_applications)!=required_context or not admission_application['all_premises_closed']:
        raise ValueError('Missing actual owner/tag source applications')
    views=[]
    for old,row in q_import['actual_consequent_getters'].items():
        views.append(eq('('+old+' '+at('Qroot','t')+')','('+row['actual']+' '+at('actual','t')+')'))
    supply('Exact typed old-root source observation at the one actual parent trace',views,
        ['reconstructed Q source restriction','checked actual_consequent_getters; no equality of foreign state sorts'])
    # Equality symmetry is an explicit logical rule; do not fabricate a new
    # source fact when a full-Q field binding has the opposite orientation.
    for text in list(facts):
        x=parse(text)[0]
        if isinstance(x,list) and x[0]=='=':facts.add(canonical(emit(['=',x[2],x[1]])))
    parents={}
    def root(x):
        parents.setdefault(x,x)
        if parents[x]!=x:parents[x]=root(parents[x])
        return parents[x]
    for text in facts:
        x=parse(text)[0]
        if isinstance(x,list) and x[0]=='=':
            left,right=map(emit,x[1:]);parents[root(left)]=root(right)
    equality_applications=[]
    for name,text in certificate['expanded_fresh_clauses'].items():
        x=parse(text)[0]
        if text not in facts and isinstance(x,list) and x[0]=='=' and root(emit(x[1]))==root(emit(x[2])):
            facts.add(text);equality_applications.append(dict(clause=name,conclusion=text,rule='equality transitivity/symmetry over explicitly supplied field/source equations'))
    absent={name:text for name,text in certificate['expanded_fresh_clauses'].items() if not set(conjuncts(text))<=facts}
    if absent:raise ValueError('Unclosed concrete P_tau fresh-record clauses: '+str(absent))
    constructor=certificate['fresh_constructor']
    implication='(=> (qnum-write '+at('actual','t')+') (P_tau '+constructor+'))'
    return dict(schema='Concrete-fixed-trace-full-record-producer-introduction-v1',
        fixed_family_binding=family,explicit_predicate=certificate,
        provider_applications=providers,equality_applications=equality_applications,all_expanded_clauses_closed=True,unclosed_clauses={},
        inference='Expand each explicit record getter at the constructor, apply the reconstructed provider conclusions, use equality symmetry/reflexivity and conjunction introduction, then fold the exact P_tau definition. tau and its observer histories are fixed outside the induction.',
        conclusion=implication)

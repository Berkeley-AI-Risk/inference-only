"""Query numerical producer as a consequence of the immutable qualified Q proof.

Prove the port/metadata adapter inside the original Q product, then apply the
checked source restriction to the restored parent. No foreign SMT state sorts
are identified. The conditional scalar guarantee is a literal conjunct
projection of the qualified Q endpoint; numerical/model meaning stays in that
full theorem and its accepted-input specialization.
"""
import sys,json
from common import HERE,PILOT,sha,atomic_bytes,write_frozen,both
sys.path.insert(0,str(PILOT/'q-operator'))
from q_main import specification as main_spec,current,body_files
from q_columns import TOP as OLD
from selector import TOP as NORM
from pruned_arithmetic import parse,emit
from query_numeric_store import definitions as numeric_definitions
from prepare_context import TOP


def conjuncts(node):
    return [z for y in node[1:] for z in conjuncts(y)] if isinstance(node,list) and node[0]=='and' else [node]


def specification(revision=1):
    declarations,_,main=main_spec();goal=parse(main['actual-Q-write-value-address-and-order']['conclusion'])[0]
    parts=conjuncts(goal);dropped=[x for x in parts if isinstance(x,list) and x[0]=='Q-record-matches']
    if len(dropped)!=1:raise ValueError('Qualified Q scalar projection changed')
    scalar=both([emit(x) for x in parts if x not in dropped])
    source=parse(numeric_definitions());selected=[x for x in source if x[0]=='define-fun' and x[1] in ['qnum-write','qnum-producer']]
    if len(selected)!=2:raise ValueError('Changed query numeric producer definitions')
    if revision>=2:
        # The old RAM-output abstraction optimized away its unused physical
        # write-enable wire. Its qualified source-level event predicate is the
        # interface. A separate real-parent adapter proves physical equivalence.
        selected=[x for x in selected if x[1]=='qnum-producer']
        selected[0][2].insert(1,['z','|'+NORM+'_s|'])
        selected[0][4][1]=['Q-write-admission','a','z']
    text='\n'.join(emit(x) for x in selected)+'\n'
    text=text.replace('|'+TOP+'_s|','|'+OLD+'_s|').replace('|'+TOP+'_n ','|'+OLD+'_n ')
    if TOP in text:raise ValueError('Unmapped numerical producer source')
    root=[f'(|{OLD}_h| a)',f'(|{NORM}_h| z)','(qn-bind a z)']
    qainv=[x for x in current() if parse(x)[0][0]=='qa-inv']
    if len(qainv)!=1:raise ValueError('Changed qualified persistent Q argument predicate')
    conditional='(=> (Q-write-admission a z) '+scalar+')'
    rules={
        'actual-query-Q-write-is-qualified-Q-admission':dict(assumptions=root+['(qnum-write a)'],conclusion='(Q-write-admission a z)'),
        'qualified-Q-guarantee-closes-query-numerical-producer':dict(assumptions=root+qainv+[conditional],conclusion='(qnum-producer a qa na)'),
    }
    if revision>=2:
        from q_normalizer_product import dn
        rules={
            'qualified-Q-admission-has-live-Q-caller':dict(assumptions=root+['(Q-write-admission a z)'],
                conclusion=both(['(qn-Q-mode a)',dn('rst_n'),'(not '+dn('fault_q')+')'])),
            'qualified-Q-guarantee-closes-query-numerical-producer':dict(assumptions=root+qainv+[conditional],conclusion='(qnum-producer a z qa na)')}
    return declarations,text,rules


def projection():
    goal=main_spec()[2]['actual-Q-write-value-address-and-order']['conclusion']
    parts=conjuncts(parse(goal)[0]);removed=[emit(x) for x in parts if isinstance(x,list) and x[0]=='Q-record-matches']
    return dict(schema='Qualified-Q-scalar-consequence-projection-v1',original_endpoint='q-main:actual-Q-write-value-address-and-order',
        original_conclusion_sha256=sha(goal.encode()),removed_conjuncts=removed,
        rule='Conjunction elimination only; the full numerical/model conclusion remains required by Q-SOURCE-SPECIALIZATION and accepted-input substitution.',
        adapter_scope='Original Q root/normalizer product; restored parent application uses the checked exact source restriction.')


def prepare(revision=1):
    label='query-numeric-producer'+('-r2' if revision==2 else '');d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification(revision);atomic_bytes(d/'algorithm.smt2',defs.encode())
    write_frozen(d/'PROJECTION.json',projection())
    # Reuse all immutable original declaration/definition context. Only new
    # implication inputs/results live here; no old proof artifact is modified.
    bodies=['../q-operator/'+x for x in body_files()]+[label+'/algorithm.smt2']
    paths=['../model-consumption/connected-SOURCES.json','../q-operator/q-main-PLAN.json',label+'/PROJECTION.json',*bodies]
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='Qualified-Q-query-reference-adapter-v1',component=label,
        bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',
        inputs={f:sha((HERE/f).read_bytes()) for f in paths},declarations=decl,rules=rules,order=list(rules),
        checks_file=label+'-CHECKS.json',external_facts={},connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':
    prepare(2 if '--revision-2' in sys.argv else 1)
    print('Prepared exact qualified-Q scalar guarantee and actual query-write/producer adapter in its original source product.')

"""Exact local/helper-instance receipts and current algorithm induction census.

The mathematical word/integer and full RMS joins are not claimed by this entry.
"""
import json
from common import HERE,sha,atomic_json
from verify_gate import check_component,canonical
from parent_flow import TOP,d
from rms_capture import r
from native_induction import query


def verify_original_types(label,plan):
    body='\n'.join((HERE/f).read_text() for f in plan['bodies'])
    first=query(plan,plan['order'][0],body)
    if not first.endswith('(check-sat)\n'):raise ValueError('Unexpected query terminator')
    typed=first[:-len('(check-sat)\n')]
    for rule in plan['rules'].values():
        typed+='\n'.join('(assert '+t+')' for t in [*rule['assumptions'],rule['conclusion']])+'\n'
    typed+='(exit)\n'
    records=[]
    for directory in (HERE/'typechecks').glob(label+'-*'):
        if not (directory/'RESULT.json').exists():continue
        record=json.loads((directory/'RESULT.json').read_text())
        if record.get('query_sha256')!=sha(typed.encode()):continue
        if (directory/'typecheck.smt2').read_text()!=typed:
            raise ValueError('Original theory type input changed')
        raw=(directory/'z3.log').read_bytes()
        if record['exit_code']!=0 or raw.strip() or sha(raw)!=record['log_sha256'] or not record['typecheck_only']:
            raise ValueError('Original type evidence failed')
        records.append(str(directory.relative_to(HERE)))
    if not records:raise ValueError('Missing original theory typecheck: '+label)
    return dict(typecheck_only=True,proof_result=False,no_check_sat=True,records=records)


def main():
    rows={}
    for label,module in [('root-r2','digit_algorithms'),('divider','digit_algorithms'),
                         ('root-instance','helper_instances'),('divider-instance','helper_instances'),
                         ('integer-algorithms','integer_algorithms'),('digit-word-bridge','digit_word_bridge')]:
        plan,receipts=check_component(label,module,1)
        types=verify_original_types(label,plan)
        if module=='helper_instances':
            from helper_instances import specification
            binding=specification(label)[3]
            if json.loads((HERE/(label+'-INSTANCE.json')).read_text())!=binding:
                raise ValueError('Changed actual helper source binding')
        if label in ['root-r2','divider','root-instance','divider-instance']:
            family='root' if label.startswith('root') else 'div'
            phase='rh' if family=='root' else 'dh'
            limit=23 if family=='root' else 28
            state='|'+TOP+'_s|' if label.endswith('instance') else ('|board0_exact_isqrt_u45_iterative_s|' if family=='root' else '|board1_rmsnorm_bounded28_divider_s|')
            current=f'({family}-inv a h)';post=f'({family}-inv an hn)'
            required=['common-reset-base','idle-preserved','held-preserved',
                      *['digit-'+str(k)+'-preserved' for k in range(limit)]]
            for name in required:
                rule=plan['rules'][name]
                if rule.get('expected','unsat')!='unsat':raise ValueError('Non-implication in induction')
                if name!='common-reset-base' and canonical(current) not in {canonical(x) for x in rule['assumptions']}:
                    raise ValueError('Missing current invariant')
                expected=f'({family}-inv an {family}-zero)' if name=='common-reset-base' else post
                if canonical(rule['conclusion'])!=canonical(expected):raise ValueError('Changed helper postcondition')
            # The precise generator/rules and all base/case receipts were
            # reconstructed above. The phase/count domain in the invariant
            # and case-coverage implication supply the finite exhaustion.
        rows[label]=dict(checks=len(receipts),unsat=sum(x['expected']=='unsat' for x in receipts),
                         original_sat_controls=sum(x['expected']=='sat' for x in receipts),original_type_evidence=types,
                         receipts=receipts)
    result=dict(schema='RMS-helper-local-and-instance-exact-evidence-v1',passed=True,components=rows,
        actual_RMS_divider_domain_discharged=True,
        word_to_integer_composition_completed=False,full_RMS_algorithm_proved=False,
        connected_segment_qualified=False,whole_machine_theorem=False)
    atomic_json(HERE/'HELPER-RESULT.json',result)
    print(json.dumps(dict(passed=True,engine_results=sum(v['checks'] for v in rows.values()),
        full_RMS_algorithm_proved=False,connected_segment_qualified=False)))


if __name__=='__main__':main()

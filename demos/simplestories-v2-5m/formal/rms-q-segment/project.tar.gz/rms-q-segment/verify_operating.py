"""Validate fresh native operating and actual-only numerical defect evidence."""
import csv
import json
from common import HERE,sha,atomic_json
from prepare_context import reconstruction
from prepare import ROM,modules
from segment_fixture import CASES,testbench,prepare_assets
from rms_reference import rms
from reference import q as q_reference,normalize,signed


def main():
    raw,asset=prepare_assets();asset_sha=sha(asset.read_bytes())
    source,rom,manifest=reconstruction()
    cases=[(name,'native') for name in CASES]+[('small',d) for d in ['wrong-bank','wrong-read','stale-generation']]
    rows=[]
    for name,defect in cases:
        d=HERE/'operating'/(name+'-'+defect+'-r4')
        record=json.loads((d/'RESULT.json').read_text())
        exponent,vector=CASES[name]
        rms_values,outcome=rms(raw,0,vector,exponent)
        q_values,q_outcome=normalize(q_reference(raw,0,[x[1] for x in rms_values],rms_values[0][2]))
        if not outcome['success'] or not q_outcome['success']:raise ValueError('Unexpected numerical rejection')
        expected={}
        for label,values in [('rms',rms_values),('q',q_values)]:
            expected[label]=''.join('%06x\n'%(((e&255)<<16)|(a&65535)) for i,a,e,last in values).encode()
            if (d/('reference-'+label+'.memh')).read_bytes()!=expected[label]:raise ValueError('Changed independent expected values')
        if (d/'input.memh').read_text()!=''.join('%04x\n'%(a&65535) for a in vector):raise ValueError('Changed activation input')
        if sha((d/'model.memh').read_bytes())!=asset_sha or (d/ROM).read_bytes()!=rom:raise ValueError('Changed model/ROM fixture')
        if record['compile_exit']!=0 or record['engine']!='verilator' or record['actual_internal_state_drives']:
            raise ValueError('Invalid native operating source/execution')
        if record['actual_hard_resets']!=1 or not record['old_work_cancelled_with_outstanding_DDR']:
            raise ValueError('Missing cancellation/restart operating case')
        for path,data in source.items():
            actual=(d/path).read_bytes()
            if sha(actual)!=record['sources'][path]:raise ValueError('Changed recorded actual source')
            if defect=='native' and actual!=data:raise ValueError('Native operating source changed')
            if defect!='native' and path not in ['datapath.sv','rms-segment-native.sv'] and actual!=data:
                raise ValueError('Unrelated actual-only source changed')
        bench=testbench(source['layer.sv'].decode(),exponent).encode()
        if (d/'testbench.sv').read_bytes()!=bench or sha(bench)!=record['bench_sha256']:
            raise ValueError('Native stimulus/observations changed')
        log=(d/'simulation.log').read_bytes()
        if sha(log)!=record['simulation_log_sha256']:raise ValueError('Changed raw simulation log')
        if defect=='native':
            if record['simulation_exit']!=0 or b'SEGMENT_OPERATING_PASS rms=256 q=256' not in log:
                raise ValueError('Incomplete native operating case')
            transcript=list(csv.reader((d/'values.csv').read_text().splitlines()))
            expected_rows=[]
            for kind,values in [('R',rms_values),('Q',q_values)]:
                expected_rows.extend((kind,i,a,e) for i,a,e,last in values)
            actual_rows=[(kind,int(i),signed(int(a,16),16),signed(int(e,16),8)) for kind,i,a,e in transcript]
            if actual_rows!=expected_rows:raise ValueError('Actual transcript differs from independent integer results')
        else:
            mutation=record['mutation']
            if mutation['independent_expected_values_changed']:raise ValueError('Reference changed in a defect control')
            base=source['datapath.sv'].decode()
            if base.count(mutation['before'])!=1 or (d/'datapath.sv').read_text()!=base.replace(mutation['before'],mutation['after'],1):
                raise ValueError('Actual-only defect substitution differs')
            numerical=(b'RMS_VALUE_MISMATCH' in log or b'Q_VALUE_MISMATCH' in log or b'QUERY_RAM_MISMATCH' in log)
            if record['simulation_exit']==0 or not numerical:raise ValueError('Defect was not detected numerically')
            if defect=='stale-generation':
                parent=(d/'rms-segment-native.sv').read_text()
                if not parent.startswith(source['rms-segment-native.sv'].decode()) or 'segment_stale_rms_ram' not in modules(parent):
                    raise ValueError('Stale RAM control is not confined to its actual source')
            elif (d/'rms-segment-native.sv').read_bytes()!=source['rms-segment-native.sv']:
                raise ValueError('Unrelated native arithmetic changed in defect')
        rows.append(dict(case=name,defect=defect,result_sha256=sha((d/'RESULT.json').read_bytes()),
            bench_sha256=sha(bench),log_sha256=sha(log),passed=True))
    result=dict(schema='Fresh-RMS-Q-native-operating-evidence-v1',passed=True,
        native_cases=6,actual_RMS_values_compared=1536,actual_Q_values_compared=1536,
        query_RAM_rows_checked=1536,actual_only_numerical_defects=3,
        actual_reset_count_per_case=1,old_DDR_work_cancelled_and_drained=True,
        caller_RAM_gate_has_no_layer_zero_restriction=True,finite_layer=0,
        records=rows,unbounded_proof=False,connected_segment_qualified=False)
    atomic_json(HERE/'FRESH-OPERATING-RESULT.json',result)
    print(json.dumps({k:result[k] for k in ['passed','native_cases','actual_RMS_values_compared','actual_Q_values_compared','actual_only_numerical_defects','connected_segment_qualified']}))


if __name__=='__main__':main()

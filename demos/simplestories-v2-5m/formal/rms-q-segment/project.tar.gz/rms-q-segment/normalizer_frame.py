"""One independent normalizer invocation has one output exponent.

After the reference reaches its write phase, its candidate stays fixed through
write/result/DONE/reject. A cancel or a fresh invocation ends that frame. The
native ordered ownership theorems prevent mixing restarted frames into one
completed RMS or Q vector.
"""
from common import HERE,bv,both,eq,sha,atomic_bytes,write_frozen
from verify_rms_meaning import independent_programs
from normalizer_instance import definitions as all_definitions
from rms_native_history import parse,emit


def specification():
    selected=set(independent_programs()['na-step']['functions']);nodes=parse(all_definitions())
    kept=[]
    for x in nodes:
        if x[0]=='declare-datatypes' and x[2][0][0] in ['NormAlgorithm','ShiftHistory']:kept.append(x)
        elif x[0]=='define-fun' and x[1] in selected:kept.append(x)
    defs='\n'.join(emit(x) for x in kept)+'\n'
    decl=['(declare-const h NormAlgorithm)','(declare-const vector (Array (_ BitVec 10) (_ BitVec 58)))',
        '(declare-const rows (_ BitVec 10))']+['(declare-const '+x+' Bool)' for x in ['start','capture','select','shift','result','done','cancel','interrupt']]
    step='(na-step h vector rows start capture select shift result done cancel interrupt)'
    phases='(or '+' '.join(eq('(na-phase h)',bv(k,3)) for k in [4,5,6,7])+')'
    remaining='(or '+' '.join(eq('(na-phase '+step+')',bv(k,3)) for k in [0,4,5,6,7])+')'
    rules={
        'output-frame-candidate-is-held':dict(assumptions=[phases,'(not cancel)'],
            conclusion=eq('(na-candidate '+step+')','(na-candidate h)')),
        'output-frame-does-not-reenter-selection':dict(assumptions=[phases,'(not cancel)'],conclusion=remaining),
        'fresh-frame-resets-output-count':dict(assumptions=[eq('(na-phase h)',bv(0,3)),'start','(not cancel)','(not interrupt)'],
            conclusion=both([eq('(na-emitted '+step+')',bv(0,10)),eq('(na-phase '+step+')',bv(1,3))])),
    }
    return decl,defs,rules


def prepare():
    label='normalizer-frame';d=HERE/label;d.mkdir(exist_ok=True);decl,defs,rules=specification()
    atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Independent-normalizer-output-frame-v1',sources={},native_hardware_theorem=False))
    paths=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='Independent-normalizer-output-frame-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',inputs={f:sha((HERE/f).read_bytes()) for f in paths},
        declarations=decl,rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':prepare();print('Prepared independent normalizer output exponent/frame lemmas.')

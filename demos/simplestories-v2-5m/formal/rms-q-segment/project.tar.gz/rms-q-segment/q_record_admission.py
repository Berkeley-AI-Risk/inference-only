"""Actual Q descriptor's retained numerical origin tags."""
from common import both,eq,bv,save_plan
from rms_q_argument import specification as argument_spec
from parent_flow import d
from prepare_context import prepare


def specification(revision=1):
    decl,defs,old=argument_spec(4)
    rule=old['actual-Q-admission-fixes-independent-RMS-reference']
    parts=[eq('(rr-generation rr)','(rs-generation rs)'),eq('(rr-layer rr)',d('current_layer_q')),eq('(rr-count rr)',bv(256,9))]
    if revision>=2:parts+=['(rr-live rr)']
    return decl,defs,{'actual-Q-admission-binds-RMS-origin-tags':dict(assumptions=rule['assumptions'],conclusion=both(parts))}


if __name__=='__main__':
    import sys
    revision=2 if '--revision-2' in sys.argv else 1
    prepare();save_plan('q-record-admission'+('-r2' if revision>=2 else ''),*specification(revision),native_label='context')

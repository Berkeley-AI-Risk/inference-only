"""Fresh finite native RMS-to-Q operating cases against independent integers.

Only external semantic-layer ports are driven. Hierarchical signals/memories
are observed, never assigned. One actual reset, cancelled old Q work with DDR
drain, then fresh ingress/RMS/Q. Unrelated numerical cuts stay idle.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time
from common import HERE,PILOT,sha,atomic_bytes,atomic_json
from prepare_context import reconstruction
from prepare import ROM,modules
from rms_reference import image,rms
from reference import q as q_reference,normalize

TOP='board1_context2048_semantic_layer'
CASES={'small':(-12,[((i%23)-11)*733 for i in range(256)]),
       'zero-high-exponent':(31,[0]*256),
       'impulse':(-12,[16384]+[0]*255),
       'maximum-low-exponent':(-32,[32767]*256),
       'minimum-high-exponent':(31,[-32767]*256),
       'alternating':(31,[32767 if i%2 else -32767 for i in range(256)])}


def testbench(layer_source,exponent):
    header=layer_source[layer_source.index('module '+TOP):]
    header=header[:header.index('\n);')]
    header=re.sub(r'//[^\n]*','',header)
    ports=re.findall(r'\b(input|output)\s+(?:wire|logic|reg)\s*(?:signed\s*)?(\[[^]]+\])?\s*(\w+)',header)
    if len({p[2] for p in ports})!=len(ports) or not ports:raise ValueError('Unsupported native layer ports')
    lines=['`timescale 1ns/1ps','module segment_witness;']
    for direction,shape,name in ports:
        shape=shape.replace('ADDR_W','19')
        lines.append(('reg ' if direction=='input' else 'wire ')+shape+' '+name+('=0' if direction=='input' else '')+';')
    lines+=['always #5 clk=~clk;',TOP+' #(.ADDR_W(19)) dut('+','.join('.'+name+'('+name+')' for _,_,name in ports)+');']
    lines.append('localparam integer FRESH_EXPONENT='+str(exponent)+';')
    lines.append('''
integer cycles=0,r_count=0,q_count=0,k,fd,delay_q=0;
reg monitor=0,pending=0;
reg [255:0] reply=0;
reg [255:0] model_words [0:227061];
reg [15:0] fresh_input [0:255];
reg [23:0] reference_rms [0:255],reference_q [0:255];
always @(negedge clk) begin
    private_word_req_ready_i=!pending && (cycles%7>=2);
    private_word_rsp_valid_i=pending && delay_q==0;
    private_word_rsp_data_i=reply;
end
always @(posedge clk) begin
    cycles=cycles+1;
    if(cycles>400000) $fatal(1,"OPERATING_TIMEOUT");
    if(private_word_rsp_valid_i && private_word_rsp_ready_o) pending=0;
    if(pending && delay_q>0) delay_q=delay_q-1;
    if(private_word_req_valid_o && private_word_req_ready_i) begin
        if(private_word_req_index_o>=227062) $fatal(1,"MODEL_ADDRESS");
        reply=model_words[private_word_req_index_o];pending=1;delay_q=3;
    end
    if(monitor) begin
        if(range_fault_o || dut.u_datapath.fault_q || dut.u_sequence.fault_q)
            $fatal(1,"ACTUAL_SOURCE_FAULT");
        if(dut.u_datapath.rms_ram_write_enable) begin
            if(r_count>=256 || dut.u_datapath.output_index_q!==r_count ||
               dut.u_datapath.rms_result_mantissa!==reference_rms[r_count][15:0] ||
               dut.u_datapath.rms_result_exponent!==reference_rms[r_count][23:16])
                $fatal(1,"RMS_VALUE_MISMATCH row=%0d",r_count);
            $fdisplay(fd,"R,%0d,%h,%h",r_count,dut.u_datapath.rms_result_mantissa,dut.u_datapath.rms_result_exponent);
            r_count=r_count+1;
        end
        if(dut.u_datapath.query_ram_write_enable) begin
            if(dut.u_datapath.current_stage_q!==5'd1 || q_count>=256 ||
               dut.u_datapath.output_index_q!==q_count ||
               dut.u_datapath.norm_result_mantissa!==reference_q[q_count][15:0] ||
               dut.u_datapath.norm_result_exponent!==reference_q[q_count][23:16])
                $fatal(1,"Q_VALUE_MISMATCH row=%0d",q_count);
            $fdisplay(fd,"Q,%0d,%h,%h",q_count,dut.u_datapath.norm_result_mantissa,dut.u_datapath.norm_result_exponent);
            q_count=q_count+1;
        end
    end
end
task start_work(input integer exponent);
begin
    wait(start_ready_o);
    @(negedge clk); input_exponent_i=exponent;fixed_position_i=0;start_valid_i=1;
    @(posedge clk);if(!start_ready_o) $fatal(1,"START_REJECTED");
    @(negedge clk);start_valid_i=0;
end
endtask
task feed_vector(input integer old);
integer row;
begin
    for(row=0;row<256;row=row+1) begin
        @(negedge clk);input_valid_i=0;
        if(row%11==0)repeat(2) @(negedge clk);
        input_valid_i=1;input_index_i=row;
        input_mantissa_i=old ? (3000+row%31) : fresh_input[row];input_last_i=row==255;
        @(posedge clk);if(!input_ready_o) $fatal(1,"INGRESS_REJECTED");
    end
    @(negedge clk);input_valid_i=0;
end
endtask
initial begin
    $readmemh("model.memh",model_words);$readmemh("input.memh",fresh_input);
    $readmemh("reference-rms.memh",reference_rms);$readmemh("reference-q.memh",reference_q);
    fd=$fopen("values.csv","w");model_lock_i=1;
    repeat(4) @(posedge clk);@(negedge clk);rst_n=1;
    start_work(-10);feed_vector(1);
    // Cancel with an actually outstanding old projection read. Deliver the
    // same held response through the real ownership/drain path after CLEAR.
    wait(pending);@(negedge clk);clear_i=1;
    repeat(2) @(posedge clk);@(negedge clk);clear_i=0;
    wait(!busy_o && !pending);monitor=1;
    start_work(FRESH_EXPONENT);feed_vector(0);
    wait(dut.u_datapath.stage_done_q && dut.u_datapath.current_stage_q==5'd1);
    @(negedge clk);
    if(r_count!=256 || q_count!=256) $fatal(1,"INCOMPLETE_VECTOR");
    for(k=0;k<256;k=k+1) begin
        if(dut.u_datapath.u_query_state.payload_mem[k]!==reference_q[k][15:0])
            $fatal(1,"QUERY_RAM_MISMATCH row=%0d",k);
    end
    if(dut.u_datapath.query_exponent_q!==reference_q[0][23:16])
        $fatal(1,"QUERY_EXPONENT_MISMATCH");
    $fclose(fd);$display("SEGMENT_OPERATING_PASS rms=%0d q=%0d cycles=%0d",r_count,q_count,cycles);
    $finish;
end
endmodule
''')
    return '\n'.join(lines)+'\n'


def prepare_assets():
    raw=image();d=HERE/'fixture-assets';d.mkdir(exist_ok=True)
    target=d/'model.memh'
    text=''.join('%064x\n'%int.from_bytes(raw[i:i+32],'little') for i in range(0,len(raw),32))
    if target.exists() and target.read_text()!=text:raise ValueError('Changed operating model asset')
    if not target.exists():atomic_bytes(target,text.encode())
    return raw,target


def run(case,defect,raw,model,engine='iverilog',tag=''):
    exponent,vector=CASES[case]
    rms_values,rms_outcome=rms(raw,0,vector,exponent)
    if not rms_outcome['success']:raise ValueError('Chosen RMS operating case rejects')
    q_values,q_outcome=normalize(q_reference(raw,0,[r[1] for r in rms_values],rms_values[0][2]))
    if not q_outcome['success']:raise ValueError('Chosen Q operating case rejects')
    files,rom,manifest=reconstruction()
    mutation=None
    if defect!='native':
        src=files['datapath.sv'].decode()
        if defect=='stale-generation':
            row=next(i for i,a,e,last in rms_values if a and vector[i]<0)
            sign=1 if rms_values[row][1]<0 else 0
            original=modules(files['rms-segment-native.sv'].decode())['board1_fixed_semantic_vector256_ram']
            clone=original.replace('module board1_fixed_semantic_vector256_ram','module segment_stale_rms_ram',1)
            if clone.count('if (private_write_enable_i)')!=1:raise ValueError('RAM mutation site changed')
            clone=clone.replace('if (private_write_enable_i)',
                f"if (private_write_enable_i && !(private_write_address_i==8'd{row} && private_write_data_i[15]==1'b{sign}))",1)
            files['rms-segment-native.sv']+=('\n'+clone+'\n').encode()
            before='board1_fixed_semantic_vector256_ram u_rms_scratch'
            after='segment_stale_rms_ram u_rms_scratch'
        elif defect=='wrong-read':
            before='hidden_ram_read_address = input_index_q[7:0];'
            after="hidden_ram_read_address = input_index_q[7:0] + 8'd1;"
        elif defect=='wrong-bank':
            before=".fixed_norm_kind_i((current_stage_q == STAGE_INPUT_RMS) ? 2'd0 :"
            after=".fixed_norm_kind_i((current_stage_q == STAGE_INPUT_RMS) ? 2'd1 :"
        else:raise ValueError('Unknown actual-only mutation')
        if src.count(before)!=1:raise ValueError('Mutation site is not unique')
        files['datapath.sv']=src.replace(before,after,1).encode()
        mutation=dict(before=before,after=after,independent_expected_values_changed=False)
    if tag and not re.fullmatch(r'[a-zA-Z0-9_-]+',tag):raise ValueError('Invalid operating tag')
    folder=HERE/'operating'/(case+'-'+defect+('-'+tag if tag else ''))
    folder.mkdir(parents=True,exist_ok=False)
    for name,data in files.items():atomic_bytes(folder/name,data)
    atomic_bytes(folder/ROM,rom)
    os.link(model,folder/'model.memh')
    atomic_bytes(folder/'input.memh',''.join('%04x\n'%(a&65535) for a in vector).encode())
    for label,rows in [('rms',rms_values),('q',q_values)]:
        atomic_bytes(folder/('reference-'+label+'.memh'),''.join('%06x\n'%(((e&255)<<16)|(a&65535)) for i,a,e,last in rows).encode())
    bench=testbench(files['layer.sv'].decode(),exponent)
    atomic_bytes(folder/'testbench.sv',bench.encode())
    # GNU Make requires a build path without spaces. This is generated C++
    # build output only, not another repository checkout or source working copy.
    build=Path(tempfile.mkdtemp(prefix='rmsq-segment-build-',dir='/private/tmp')) if engine=='verilator' else None
    if build:atomic_json(folder/'BUILD.json',dict(generated_build_directory=str(build),source_copy_created=False))
    command=(['iverilog','-g2012','-gno-assertions','-DSYNTHESIS','-s','segment_witness','-o','sim',*files,'testbench.sv']
        if engine=='iverilog' else ['verilator','--binary','--timing','-Wno-fatal','--top-module','segment_witness',
            '--Mdir',str(build),'-j','4','-o','sim','-DSYNTHESIS',*files,'testbench.sv'])
    start=time.monotonic()
    with (folder/'compile.log').open('w') as log:
        cp=subprocess.run(command,cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    result=dict(case=case,defect=defect,compile_exit=cp.returncode,engine=engine,compile_command=command,
        sources={f:sha(b) for f,b in files.items()},bench_sha256=sha(bench.encode()),
        model_sha256=sha(raw),reference_RMS=rms_outcome,reference_Q=q_outcome,
        reference_values_sha256={x:sha((folder/('reference-'+x+'.memh')).read_bytes()) for x in ['rms','q']},
        actual_hard_resets=1,old_work_cancelled_with_outstanding_DDR=True,
        actual_internal_state_drives=False,mutation=mutation,unbounded_proof=False)
    if cp.returncode==0:
        with (folder/'simulation.log').open('w') as log:
            try:
                cp=subprocess.run(['vvp','sim'] if engine=='iverilog' else [str(build/'sim')],cwd=folder,stdout=log,stderr=subprocess.STDOUT,timeout=180)
                code=cp.returncode
            except subprocess.TimeoutExpired:code=-1
        text=(folder/'simulation.log').read_text()
        result.update(simulation_exit=code,operating_pass=code==0 and 'SEGMENT_OPERATING_PASS' in text,
            actual_only_defect_detected=defect!='native' and code!=0 and bool(re.search(r'RMS_VALUE_MISMATCH|Q_VALUE_MISMATCH|QUERY_RAM_MISMATCH',text)),
            simulation_log_sha256=sha(text.encode()))
        if (folder/'values.csv').exists():result['values_sha256']=sha((folder/'values.csv').read_bytes())
    result['seconds']=time.monotonic()-start
    result['passed']=result.get('operating_pass',False) if defect=='native' else result.get('actual_only_defect_detected',False)
    atomic_json(folder/'RESULT.json',result)
    print(json.dumps({k:result.get(k) for k in ['case','defect','passed','compile_exit','simulation_exit','seconds']}),flush=True)
    return result['passed']


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case',choices=list(CASES),default='small')
    ap.add_argument('--defect',choices=['native','wrong-bank','wrong-read','stale-generation'],default='native')
    ap.add_argument('--engine',choices=['iverilog','verilator'],default='iverilog')
    ap.add_argument('--tag',default='')
    ap.add_argument('--all',action='store_true');args=ap.parse_args()
    raw,model=prepare_assets()
    items=[(args.case,args.defect)]
    if args.all:items=[(c,'native') for c in CASES]+[('small',d) for d in ['wrong-bank','wrong-read','stale-generation']]
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(lambda item:run(*item,raw,model,args.engine,args.tag),items))
    return 0 if all(results) else 1


if __name__=='__main__':raise SystemExit(main())

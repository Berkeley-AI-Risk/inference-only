"""Unrotated numerical authority equals the physical query last-writer tag.

This prevents the numerical read theorem from being vacuous: every valid row
whose last writer is Q has numerical authority; a Q-RoPE overwrite removes it.
No assertion is made about a later rotated payload's numerical meaning.
"""
from common import HERE,bv,both,eq,save_plan
from parent_flow import TOP,S,d
from query_numeric_store import definitions
from prepare_context import prepare


def specification():
    defs=definitions()
    row=f'(= (select (qnum-valid h) watch) (and (select (qm-valid qm) watch) (= (select (qm-stage qm) watch) {bv(1,5)})))'
    read=f'(= (qnum-read-valid h) (and (qm-read-valid qm) (= (qm-read-stage qm) {bv(1,5)})))'
    defs+=f'(define-fun qnum-authority ((h QueryNumeric) (qm QueryMemory) (watch (_ BitVec 8))) Bool '+both([row,read])+')\n'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const rs RMSSnapshot)',
        '(declare-const qa QArguments)','(declare-const qna NormAlgorithm)',
        '(declare-const h QueryNumeric)','(declare-const hn QueryNumeric)',
        '(declare-const qm QueryMemory)','(declare-const qmn QueryMemory)','(declare-const watch (_ BitVec 8))']
    H=lambda a:f'(|{TOP}_h| {a})'
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    equations=[eq('hn','(qnum-next a rs qa qna h)'),eq('qmn','(qm-next a an rs qm)')]
    rd=d('query_ram_read_address')
    rules={
        'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(qnum-authority qnum-zero (qm-base an) watch)'),
        'preserved':dict(assumptions=ctx+equations+[d('rst_n'),'(qnum-authority h qm watch)',f'(qnum-authority h qm {rd})'],
            conclusion='(qnum-authority hn qmn watch)'),
        'every-last-Q-writer-row-has-numerical-authority':dict(assumptions=['(qnum-authority h qm watch)',
            '(select (qm-valid qm) watch)',eq('(select (qm-stage qm) watch)',bv(1,5))],conclusion='(select (qnum-valid h) watch)'),
        'every-request-edge-last-Q-read-has-numerical-authority':dict(assumptions=['(qnum-authority h qm watch)',
            '(qm-read-valid qm)',eq('(qm-read-stage qm)',bv(1,5))],conclusion='(qnum-read-valid h)'),
    }
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('query-numeric-authority',*specification(),native_label='context')
    print('Prepared exact equivalence of numerical Q authority and actual query-memory Q last-writer tags.')

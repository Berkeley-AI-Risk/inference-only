"""Actual query-RAM Q write equals the qualified source admission observer.

The old output-cut model optimized away its unused physical RAM write-enable.
Reconstruct its qualified source observer at the real root/normalizer ports,
then prove equivalence to the retained physical write-enable. This is an
observer projection from one parent state, not equality of foreign state sorts.
"""
import sys,re,json
from common import HERE,PILOT,sha,atomic_json,save_plan
from prepare_context import TOP,DP,reconstruction,prepare
from parent_flow import S
from query_numeric_store import definitions as numeric_definitions
sys.path.insert(0,str(PILOT/'q-operator'))
from q_columns import TOP as OLD
from selector import TOP as NORM
from q_main import body_files
from pruned_arithmetic import parse,emit


def projected_definitions():
    definitions={}
    for name in body_files():
        for x in parse((PILOT/'q-operator'/name).read_text()):
            if x[0]=='define-fun' and not x[1].startswith('|'):definitions[x[1]]=x
    selected={'Q-write-admission'}
    def refs(x,bound):
        if not isinstance(x,list):return {x} if x in definitions and not definitions[x][2] and x not in bound else set()
        if not x:return set()
        if x[0]=='let':return set().union(*(refs(y[1],bound) for y in x[1]))|refs(x[2],bound|{y[0] for y in x[1]})
        result={x[0]} if isinstance(x[0],str) and x[0] in definitions and x[0] not in bound else set()
        for y in x:result|=refs(y,bound)
        return result
    while True:
        more=set().union(*(refs(definitions[name][4],{p[0] for p in definitions[name][2]}) for name in selected))
        if more<=selected:break
        selected|=more
    _,_,manifest=reconstruction()
    cutmap={'f_dp_'+row['replacement']:DP+row['expression'] for item in manifest['restored_instances'] for row in item['removed_substitutions']}
    old_root={x[1]:x for x in parse((PILOT/'model-consumption/connected/native.smt2').read_text()) if x[0]=='define-fun'}
    old_norm={x[1]:x for x in parse((PILOT/'q-operator/selector/native.smt2').read_text()) if x[0]=='define-fun'}
    actual={x[1]:x for x in parse((HERE/'context/native.smt2').read_text()) if x[0]=='define-fun'}
    mapping={'|'+OLD+'_s|':S,'|'+NORM+'_s|':S,**{name:'qevent-'+name for name in selected}}
    getters={}
    def tr(x):
        if isinstance(x,list):return [tr(y) for y in x]
        if x in mapping:return mapping[x]
        m=re.fullmatch(r'\|('+re.escape(OLD)+'|'+re.escape(NORM)+r')_(n|m) (.+)\|',x)
        if m:
            field=m[3]
            target=DP+'u_normalizer.'+field if m[1]==NORM else cutmap.get(field,field)
            symbol='|'+TOP+'_'+m[2]+' '+target+'|'
            source=old_norm if m[1]==NORM else old_root
            if x not in source or symbol not in actual or source[x][3]!=actual[symbol][3]:raise ValueError('Missing/mistyped actual Q event getter '+x)
            getters[x]=dict(actual=symbol,sort=source[x][3]);return symbol
        if x.startswith('|'+OLD+'_') or x.startswith('|'+NORM+'_'):raise ValueError('Unsupported foreign native predicate in source observer')
        return x
    nodes=[tr(x) for name,x in definitions.items() if name in selected]
    text='\n'.join(emit(x) for x in nodes)+'\n'
    # The real root and normalizer source views are both observations of the
    # same actual parent state. Native named ports/getters were checked above.
    text+=f'(define-fun actual-qualified-Q-write ((a {S})) Bool (qevent-Q-write-admission a a))\n'
    original=next(x for x in parse(numeric_definitions()) if x[:2]==['define-fun','qnum-write'])
    text+=emit(original)+'\n'
    return text,dict(schema='Qualified-Q-admission-real-source-observer-v1',original_function_names=sorted(selected),
        original_definitions_sha256=sha(('\n'.join(emit(definitions[x]) for x in sorted(selected))+'\n').encode()),
        actual_getter_projection=getters,restored_output_cut_input_projection=cutmap,
        real_state_projection='Each foreign source view is observed at its exact actual root/submodule ports from this one real parent state; no foreign state-sort equality assertion.',
        native_numerical_reply_assumed=False)


def specification():
    defs,_=projected_definitions();decl=[f'(declare-const a {S})']
    H=f'(|{TOP}_h| a)'
    rules={'actual-query-Q-write-is-qualified-source-event':dict(assumptions=[H],conclusion='(= (qnum-write a) (actual-qualified-Q-write a))')}
    return decl,defs,rules


if __name__=='__main__':
    prepare();_,binding=projected_definitions();atomic_json(HERE/'QUERY-WRITE-EVENT-BINDING.json',binding)
    save_plan('query-write-event',*specification(),native_label='context')
    print('Prepared actual physical Q-write and qualified source-observer equivalence.')

"""Close finite word-function loops with engine-checked mathematical invariants.

No raw UNSAT receipt is invented for the combined theorem. Its argument is
ordinary loop induction: exact word recurrences, verified base/step/end lemmas,
all 23/28 digit applications and checked assembly of the original input. Native
actual-helper source instantiation and its unbounded handshake history remain
the separately verified producer connection.
"""
from common import HERE,bv,sha,atomic_json
from verify_gate import check_component
from verify_helpers import verify_original_types
from digit_algorithms import root_functions,div_functions
from digit_meaning import definitions as mathematical_definitions
from digit_assembly import definitions as assembly_definitions
from digit_word_bridge import specification as bridge_specification
import sys
sys.path.insert(0,str(HERE.parent/'q-operator'))
from pruned_arithmetic import parse,emit,atoms


def definitions(text):
    nodes=parse(text)
    result={x[1]:x for x in nodes if x[0]=='define-fun'}
    if len(result)!=sum(x[0]=='define-fun' for x in nodes):raise ValueError('Duplicate definition')
    return result


def substitute(node,terms):
    if not isinstance(node,list):return terms.get(node,node)
    # The exact step templates contain no binders. Reject rather than attempt
    # a capture-prone textual substitution in a newly changed definition.
    if node and node[0] in ['let','forall','exists','lambda']:
        raise ValueError('Unexpected binder in exact word-step template')
    return [substitute(x,terms) for x in node]


def apply_function(defs,name,args):
    definition=defs[name]
    parameters=definition[2]
    if len(parameters)!=len(args):raise ValueError('Incorrect function arity')
    return substitute(definition[4],{p[0]:a for p,a in zip(parameters,args,strict=True)})


def unfold(node,defs,allowed):
    if not isinstance(node,list):return node
    if node and isinstance(node[0],str) and node[0] in allowed:
        return unfold(apply_function(defs,node[0],node[1:]),defs,allowed)
    return [unfold(x,defs,allowed) for x in node]


def check_word_loop(family,source,meaning,assembly):
    root=family=='root'
    count=23 if root else 28
    qprefix='root-q-' if root else 'div-q-'
    rprefix='root-r-' if root else 'div-r-'
    aprefix='rp' if root else 'dp'
    mnext='mr' if root else 'md'
    source_args=['x'] if root else ['x','den']
    steps=[]
    expected_q=23 if root else 64;expected_r=47 if root else 65
    for name,width in [(qprefix+'0',expected_q),(rprefix+'0',expected_r)]:
        if source[name][3]!=['_','BitVec',str(width)] or source[name][4]!=parse(bv(0,width))[0]:
            raise ValueError('Digit loop does not start with zero q/r')
    if assembly[aprefix+'-0'][4]!=parse(bv(0,46 if root else 28))[0]:
        raise ValueError('Digit input prefix does not start at zero')
    all_defs={**source,**meaning,**assembly}
    for k in range(count):
        q=[qprefix+str(k),*source_args]
        r=[rprefix+str(k),*source_args]
        digit=[aprefix+'-digit-'+str(k),'x']
        if root:
            allowed={'root-t-'+str(k),'root-d-'+str(k),aprefix+'-digit-'+str(k)}
            args=[q,r,digit]
        else:
            allowed={'div-t-'+str(k),aprefix+'-digit-'+str(k)}
            args=[q,r,digit,'den']
        for field,prefix in [('q',qprefix),('r',rprefix)]:
            actual=unfold(apply_function(source,prefix+str(k+1),source_args),all_defs,allowed)
            expected=unfold(apply_function(meaning,mnext+'-next-'+field,args),all_defs,allowed)
            if actual!=expected:
                raise ValueError('Word algorithm differs from proved mathematical step: '+family+':'+str(k)+':'+field)
        actual=apply_function(assembly,aprefix+'-'+str(k+1),['x'])
        expected=apply_function(meaning,mnext+'-next-p',[[aprefix+'-'+str(k),'x'],digit])
        if actual!=expected:raise ValueError('Input assembly differs from mathematical step')
        steps.append(dict(index=k,digit_bits=2 if root else 1,
            exact_word_step=True,input_prefix_function=aprefix+'-'+str(k),
            quotient_function=qprefix+str(k),remainder_function=rprefix+str(k),
            root_limit=1<<k if root else None,
            pre_root_limit_within_checked_guard=(1<<k)<=1<<22 if root else None))
    return steps


def reduce_literal_prefix(node):
    """Evaluate only literal BV-index equality tests in a pure prefix selector."""
    if not isinstance(node,list):return node
    if node and node[0]=='ite':
        condition=node[1]
        if not isinstance(condition,list) or condition[0]!='=':raise ValueError('Unexpected prefix selector condition')
        def word(x):
            if isinstance(x,str) and x.startswith('#b'):return int(x[2:],2),len(x)-2
            if isinstance(x,str) and x.startswith('#x'):return int(x[2:],16),4*(len(x)-2)
            if isinstance(x,list) and len(x)==3 and x[0]=='_' and x[1].startswith('bv'):
                return int(x[1][2:]),int(x[2])
            raise ValueError('Nonliteral prefix selector index')
        choice=word(condition[1])==word(condition[2])
        return reduce_literal_prefix(node[2 if choice else 3])
    return [reduce_literal_prefix(x) for x in node]


def endpoint_links(root,divider,assembly,instance_plans):
    bounds=[]
    for family,count,width in [('rp',23,5),('dp',28,6)]:
        for k in range(count):
            actual=reduce_literal_prefix(apply_function(assembly,family+'-prefix',['x',parse(bv(k,width))[0]]))
            if actual!=[family+'-'+str(k),'x']:raise ValueError('Wrong specialized input-prefix bound')
            if not k<count:raise ValueError('Undischarged finite prefix bound index')
            bounds.append(dict(family=family,index=k,index_word=bv(k,width),selector_equals=emit(actual),
                provider='digit-assembly:'+('root' if family=='rp' else 'divider')+'-preterminal-prefix-bound',
                index_upper_bound=count,premise_discharged_by_exact_literal_value=True))
    if apply_function(root,'root-value',['x'])!=['root-q-23','x']:raise ValueError('Root endpoint not final digit quotient')
    rules=bridge_specification()[2]
    rounding=parse(rules['divider-final-word-rounding-is-RNE']['conclusion'])[0]
    # The checked bridge's second conjunct interprets its exact rounded word.
    rounded_word=rounding[2][1]
    if rounded_word[0]!='bv2int':raise ValueError('Changed rounding interpretation bridge')
    expected=substitute(rounded_word[1],{'dq':['div-q-28','x','d'],'dr':['div-r-28','x','d'],'dd':'d'})
    if apply_function(divider,'div-rounded',['x','d'])!=expected:raise ValueError('Final division rounding differs from proved RNE bridge')
    sign=['=',[['_','extract','63','63'],'n'],'#b1']
    magnitude=['ite',sign,['bvneg','n'],'n']
    if apply_function(divider,'div-magnitude',['n'])!=magnitude:raise ValueError('Changed signed magnitude')
    if divider['div-value'][2]!=[['n',['_','BitVec','64']],['d',['_','BitVec','64']]]:raise ValueError('Changed final signed divider signature')
    value=divider['div-value'][4]
    if value[0]!='let' or len(value[1])!=1 or value[1][0][0]!='q':raise ValueError('Changed final signed-value binding')
    actual=substitute(value[2],{'q':value[1][0][1]})
    q=['div-rounded',[['_','extract','27','0'],['div-magnitude','n']],'d']
    expected=['ite',['=','d',parse(bv(0,64))[0]],parse(bv(0,64))[0],['ite',sign,['bvneg',q],q]]
    if actual!=expected:raise ValueError('Final divider value differs from proved zero/sign/RNE branches')
    endpoints={}
    for label,family in [('root-instance','root'),('divider-instance','div')]:
        rule=instance_plans[label]['rules']['actual-held-result']
        endpoint='(root-value (rh-x h))' if family=='root' else '(div-value (dh-n h) (dh-d h))'
        if parse(endpoint)[0] not in list_walk(parse(rule['conclusion'])[0]):raise ValueError('Actual held result does not use the interpreted endpoint')
        endpoints[label]=dict(actual_held_rule=rule,accepted_argument='(rh-x h)' if family=='root' else ['(dh-n h)','(dh-d h)'],
            exact_interpreted_function=endpoint,original_input_narrowing_provider=None if family=='root' else 'digit-assembly:bounded-magnitude-narrowing-and-signed-meaning',
            mathematical_endpoint_provider='digit-meaning:root-final-is-floor-square-interval' if family=='root' else 'digit-meaning:divider-final-is-Euclidean-division and digit-word-bridge final rounding/sign')
    return dict(prefix_bound_specializations=bounds,exact_root_final_function=True,
        exact_divider_final_rounding=True,exact_divider_zero_sign_function=True,
        native_accepted_history_endpoint_substitutions=endpoints)


def list_walk(node):
    yield node
    if isinstance(node,list):
        for x in node:yield from list_walk(x)


def main():
    receipts={};instance_plans={}
    for label,module in [('digit-word-bridge','digit_word_bridge'),('digit-meaning','digit_meaning'),
                         ('digit-assembly','digit_assembly'),('integer-algorithms','integer_algorithms')]:
        plan,rows=check_component(label,module,1)
        receipts[label]=dict(queries=len(rows),receipts=rows,original_types=verify_original_types(label,plan))
    # Require the exact local and actual-instance word-algorithm verification,
    # not a self-asserted status flag in an imported receipt.
    from helper_instances import specification as instance_spec
    for label in ['root-instance','divider-instance']:
        plan,rows=check_component(label,'helper_instances',1)
        instance_plans[label]=plan
        verify_original_types(label,plan)
        if instance_spec(label)[1]!=(HERE/label/'algorithm.smt2').read_text():raise ValueError('Changed actual algorithm')
        receipts[label]=dict(queries=len(rows),receipts=rows)
    source_root=definitions(root_functions());source_div=definitions(div_functions())
    meaning=definitions(mathematical_definitions());assembly=definitions(assembly_definitions())
    loops={family:check_word_loop(family,source,meaning,assembly) for family,source in [('root',source_root),('divider',source_div)]}
    # The source functions must be the ones actually named by the native
    # producer histories, not just equivalent-looking unused local functions.
    for label,source_text in [('root-instance',root_functions()),('divider-instance',div_functions())]:
        if not (HERE/label/'algorithm.smt2').read_text().startswith(source_text):
            # Instance translation canonicalizes whitespace. Compare the
            # precise parsed leading function definitions instead.
            actual=parse((HERE/label/'algorithm.smt2').read_text())
            original=parse(source_text)
            if actual[:len(original)]!=original:raise ValueError('Producer uses a different pure function')
    endpoint_derivation=endpoint_links(source_root,source_div,assembly,instance_plans)
    result=dict(schema='RMS-actual-helper-mathematical-meaning-v1',passed=True,
        argument='Finite loop induction using exact source word recurrences, engine-proved mathematical invariants, and exact original-input assembly',
        root='For each owned held response, U23(result)^2 <= U45(argument) < (U23(result)+1)^2.',
        divider='For abs(n)<2^28 and positive uint64 d, each owned held response is round-to-nearest ties-to-even of n/d; zero d retains its proved fault/result rule.',
        source_history='Actual common reset, cancel and accepted-request history in the exact RMS helper source instances.',
        loop_steps=loops,endpoint_derivation=endpoint_derivation,receipts=receipts,
        trusted_rule='Ordinary finite loop induction and exact binder-free typed first-order function specialization; all numerical base/step/end laws have raw engine evidence.',
        raw_whole_helper_UNSAT_receipt=False,full_RMS_algorithm_proved=False,
        connected_segment_qualified=False,whole_machine_theorem=False)
    atomic_json(HERE/'HELPER-MEANING-RESULT.json',result)
    print('{"passed":true,"root_digits":23,"division_digits":28,"full_RMS_algorithm_proved":false}')


if __name__=='__main__':main()

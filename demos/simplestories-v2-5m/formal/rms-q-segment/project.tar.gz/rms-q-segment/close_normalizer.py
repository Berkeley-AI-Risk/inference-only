"""Close the reused normalizer theorem independently of the outer Q caller.

Uses the immutable Q packet's exact rule instantiation and strict premise
ledger, then the separately checked identical-module RMS source instance.
No proof file in the Q packet is written.
"""
import sys,json
from common import HERE,PILOT,atomic_json,both
sys.path.insert(0,str(PILOT/'q-operator'))
from trace_closure import Ledger,rule,invariant,plan,literal_substitute
from q_check import check_many
from selector import TOP as NORM
from normalizer_instance import binding

FAMILIES=[('norm-capture-r2','normalizer','nc'),('shift','helper','sh'),
          ('norm-shift','normalizer','ns'),('norm-algorithm-r2','normalizer','na')]


def close():
    H=[f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)',f'(|{NORM}_t| z zn)']
    current=[invariant(label,profile,'parts-join') for label,profile,_ in FAMILIES]
    equations=['(= ncn (nc-next z nc))','(= shn (shift-next z sh))','(= nan (na-next z nc na))']
    response=rule('norm-shift','actual-response-current-vector','normalizer')
    imported='(=> '+both(response['assumptions'])+' '+response['conclusion']+')'
    ledger=Ledger(H+current+equations+[imported])
    ledger.apply('norm-capture-r2','native-step-weakening','normalizer')
    for label,profile,_ in FAMILIES:ledger.parts(label,profile,'parts-join')
    base=Ledger(H+[f'(not (|{NORM}_n rst_n| z))'])
    # Literal instance rst_n(clk reset) alias. Check exact native SMT bodies;
    # use equality of definitions, not a new reset assumption.
    from pruned_arithmetic import parse
    native_defs={x[1]:x for x in parse((PILOT/'q-operator/selector/native.smt2').read_text()) if x[0]=='define-fun'}
    reset=native_defs[f'|{NORM}_n rst_n|'][4]
    helper_reset=native_defs[f'|{NORM}_n u_shift.rst_n|'][4]
    if reset!=helper_reset:raise ValueError('Normalizer/helper actual reset alias changed')
    base.add([f'(not (|{NORM}_n u_shift.rst_n| z))'])
    for label,profile,_ in FAMILIES:base.apply(label,'reset-base',profile)
    if ledger.missing or base.missing:raise ValueError(json.dumps(dict(step=ledger.missing,base=base.missing),indent=2))
    reports,census=check_many([(x,None) for x,_,_ in FAMILIES]+[('selector',None)],with_closure=True)
    return dict(schema='Qualified-normalizer-standalone-common-trace-v1',premises_closed=True,
        bases=base.audit,step=ledger.audit,current=current,equations=equations,
        universally_imported_proved_response_lemma=imported,actual_helper_reset_alias_checked=True,
        exact_source_instance=binding(),receipt_reports=reports,verified_rule_census=census,
        rule='Ordinary joint invariant induction from the actual common reset, followed by identical-source module instantiation at the recorded real RMS ports.',
        fresh_solver_replay=False,full_RMS_algorithm_proved=False,connected_segment_qualified=False)


if __name__=='__main__':
    result=close();atomic_json(HERE/'NORMALIZER-TRACE-CLOSURE.json',result)
    print('Closed qualified standalone normalizer reset/step premises and checked actual RMS source instance.')

"""Reconstruct exact engines, native sources and the connected derivation.

This is the local derivation gate. Publication qualification additionally
requires independent final review and a clean portable replay. No saved PASS
flag substitutes for a reconstructed source/formula/raw-reply application.
"""
import json
from common import HERE,atomic_json,sha
import verify_gate
from verify_helpers import main as helpers
from segment_trace import reconstruct
from verify_operating import main as operating


def main():
    verify_gate.main();helpers()
    trace=reconstruct()
    if not trace['regular_step_closed'] or not trace['common_reset_bases_closed']:
        raise ValueError('Unclosed connected numerical trace')
    if not trace['checked_output_frame']['all_selected_frame_rules_applied'] or not trace['checked_saved_full_Q_record']['full_record_provenance_checked']:
        raise ValueError('Missing full-frame/full-record derivation')
    operating()
    from statement import generate
    statement,statement_manifest=generate(trace['checked_saved_full_Q_record'])
    typed=json.loads((HERE/'STATEMENT-TYPECHECK.json').read_text())
    if not typed['passed'] or typed['proof_result'] or typed['query_sha256']!=sha(statement.encode()) or typed['log_sha256']!=sha((HERE/'STATEMENT-TYPECHECK.log').read_bytes()):
        raise ValueError('Concrete statement original type evidence differs')
    atomic_json(HERE/'CONNECTED-TRACE-CLOSURE.json',trace)
    census={label:sorted(names) for label,names in sorted(verify_gate.VERIFIED_CENSUS.items())}
    atomic_json(HERE/'SELECTED-CENSUS.json',census)
    answers={x:0 for x in ['unsat','sat']}
    for label,names in census.items():
        checks=json.loads((HERE/(label+'-CHECKS.json')).read_text())
        for name in names:answers[checks['rules'][name]['expected']]+=1
    result=dict(schema='RMS-Q-segment-local-derivation-gate-v1',passed=True,
        current_source_exactly_reconstructed=True,all_selected_engine_receipts_reconstructed=True,
        explicit_connected_reset_step_and_numerical_imports_checked=True,
        single_RMS_program_frame_checked=True,full_query_record_certificate_transport_checked=True,
        accepted_input_used_domain_fold_checked=True,
        selected_components=len(census),selected_engine_checks=sum(map(len,census.values())),answers=answers,
        census_sha256=sha((HERE/'SELECTED-CENSUS.json').read_bytes()),
        trace_sha256=sha((HERE/'CONNECTED-TRACE-CLOSURE.json').read_bytes()),
        finite_operating_result_sha256=sha((HERE/'FRESH-OPERATING-RESULT.json').read_bytes()),
        concrete_statement=statement_manifest,typechecking_counted_as_proof=False,
        connected_segment_qualified=False,published=False,whole_machine_theorem=False,
        remaining=['Independent final composition audit','Clean portable native/engine/type replay','Readable scoped theorem and publication qualification'])
    atomic_json(HERE/'DERIVATION-RESULT.json',result)
    state=json.loads((HERE/'STATE.json').read_text());state.update(status='connected_derivation_checked_pending_qualification',
        phase='portable_qualification_and_review',local_derivation='DERIVATION-RESULT.json')
    atomic_json(HERE/'STATE.json',state)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

"""Reconstruct local receipts and close the caller/RAM gate on one trace.

This checks an intermediate gate, not the complete independent-algorithm
segment or whole-device theorem. It never treats a checks-file PASS as evidence
without reconstructing its exact query, engine input and raw answer.
"""
import json
import sys
from common import HERE,PILOT,sha,atomic_json,both
from native_induction import validate,query
from prepare_context import reconstruction,recipe,TOP
from parent_flow import d
sys.path.insert(0,str(PILOT/'q-operator'))
from pruned_arithmetic import parse,emit

# Export only implications whose exact source/formula/engine evidence has
# actually been reconstructed during the connected derivation. This is a
# census, not another premise or a self-authenticating PASS flag.
VERIFIED_CENSUS={}

FAMILIES=[
    ('native-config','native_config',1,None,None,None),
    ('parent-flow','parent_flow',1,'(flow-inv a)','(flow-inv an)',None),
    ('parent-kinds','parent_kinds',1,'(kind-inv a)','(kind-inv an)',None),
    ('rms-snapshot','rms_snapshot',1,'(rs-inv a rs)','(rs-inv an rsn)',{'h':'rs','hn':'rsn'}),
    ('rms-native-history','rms_native_history',1,None,None,None),
    ('rms-capture','rms_capture',1,'(rc-inv a rs watch)','(rc-inv an rsn watch)',{'h':'rs','hn':'rsn'}),
    ('rms-arguments','rms_arguments',1,'(ra-inv a rs)','(ra-inv an rsn)',None),
    ('rms-store-r4','rms_store',4,'(rv-inv a rs ch v)','(rv-inv an rsn chn vn)',None),
    ('q-input-capture-r3','q_input_capture',3,'(qi-inv a v q watch)','(qi-inv an vn qn watch)',None),
    ('query-memory','query_memory',1,'(qm-inv a qm)','(qm-inv an qmn)',{'h':'qm','hn':'qmn'}),
]


def canonical(term,names=None):
    names=names or {}
    def tr(x):return [tr(y) for y in x] if isinstance(x,list) else names.get(x,x)
    return emit(tr(parse(term)[0]))


def check_component(label,module,revision,selected_rules=None):
    imported=__import__(module)
    if module=='rms_scalar_algorithm' and label=='rms-helper-tickets':spec=imported.helper_provider_specification()
    elif module=='helper_instances':spec=imported.specification(label)
    elif module=='digit_algorithms':spec=imported.root_specification() if label=='root-r2' else imported.div_specification()
    else:spec=imported.specification(revision) if revision!=1 else imported.specification()
    decl,defs,rules=spec[:3]
    plan=validate(HERE,label+'-PLAN.json')
    if plan['declarations']!=decl or plan['rules']!=rules or plan['order']!=list(rules):
        raise ValueError('Changed declarative component: '+label)
    definition_file='meaning.smt2' if module in ['integer_algorithms','digit_word_bridge','digit_meaning','digit_assembly','rms_word_arithmetic','rms_word_semantics','accepted_input_fold','normalizer_frame','record_transport','admission_fold'] else 'algorithm.smt2'
    if (HERE/label/definition_file).read_text()!=defs:
        raise ValueError('Changed functional definitions: '+label)
    rawplan=(HERE/(label+'-PLAN.json')).read_bytes()
    checks=json.loads((HERE/plan['checks_file']).read_text())
    if checks['plan_sha256']!=sha(rawplan):raise ValueError('Stale checks identity')
    body='\n'.join((HERE/p).read_text() for p in plan['bodies'])
    receipts=[]
    for name in (selected_rules if selected_rules is not None else plan['order']):
        result=checks['rules'][name]
        directory=(HERE/result['receipt']).resolve().parent
        directory.relative_to((HERE/'queries').resolve())
        if json.loads((directory/'RESULT.json').read_text())!=result:
            raise ValueError('Changed raw result: '+name)
        original=query(plan,name,body)
        if (directory/'query.smt2').read_text()!=original or sha(original.encode())!=result['query_sha256']:
            raise ValueError('Query differs from current exact rule: '+name)
        engine=original
        if result.get('engine')=='cvc5-int':
            if label not in ['digit-word-bridge','digit-meaning','digit-assembly','rms-word-arithmetic','rms-word-arithmetic-r2']:
                raise ValueError('Unsupported word/integer engine translation')
            engine=original.replace('(bv2int ','(ubv_to_int ')
            record=dict(rule='Z3 unsigned bv2int spelling to standard ubv_to_int',
                        original_sha256=sha(original.encode()),engine_sha256=sha(engine.encode()),no_other_changes=True)
            if (directory/'query.cvc5.smt2').read_text()!=engine or json.loads((directory/'CONVERSION.json').read_text())!=record:
                raise ValueError('Changed exact unsigned conversion')
        elif result.get('engine','original')!='original':
            if label not in ['root-r2','divider','root-instance','divider-instance','rms-scalar-algorithm','rms-scalar-algorithm-r2','rms-scalar-algorithm-r3','rms-scalar-algorithm-r4','rms-helper-tickets','rms-raw-capture','rms-endpoints'] or result['expected']!='unsat':
                raise ValueError('Unsupported abstract engine implication')
            from prefix_forgetting import transform
            engine,abstraction=transform(original,label,name)
            if (directory/'engine.smt2').read_text()!=engine or json.loads((directory/'ABSTRACTION.json').read_text())!=abstraction:
                raise ValueError('Changed exact pure-prefix strengthening')
        raw=(directory/result.get('engine_log','z3.log')).read_bytes()
        expected=rules[name].get('expected','unsat')
        if result['exit_code']!=0 or raw.strip()!=expected.encode() or sha(raw)!=result['log_sha256']:
            raise ValueError('Required exact engine result missing: '+label+':'+name)
        if result.get('engine_query_sha256',sha(original.encode()))!=sha(engine.encode()):
            raise ValueError('Unrecorded engine transformation')
        receipts.append(dict(rule=name,expected=expected,query_sha256=sha(original.encode()),
            result_sha256=sha((directory/'RESULT.json').read_bytes())))
    VERIFIED_CENSUS.setdefault(label,set()).update(x['rule'] for x in receipts)
    return plan,receipts


def close_trace(plans):
    # Every pre invariant is initialized below. Post invariants are produced
    # in this order; the ledger rejects an unproved post/provider premise.
    source={canonical(f'(|{TOP}_h| {x})') for x in ['a','an']}
    source.add(canonical(f'(|{TOP}_t| a an)'))
    source.add(canonical(f'(|{TOP}_i| a)'))
    current=[row[3] for row in FAMILIES if row[3]]
    current+=['(rms-u-inv a)','(rms-h-inv a ch)']
    available=source|{canonical(x) for x in current}
    # Split on the ACTUAL current reset signal. Reset-low edges use the
    # checked bases and the actual observer reset branches below; ordinary
    # edges use this true guard. This inserts no reset into the circuit.
    available.add(canonical(d('rst_n')))
    # These are total observer recurrences; none drive or constrain the DUT.
    equations=['(= rsn (rs-next a rs))','(= chn (history-next a an ch))',
               '(= vn (rv-next a an rs v))','(= qn (qi-next a v q))',
               '(= qmn (qm-next a an rs qm))']
    available.update(canonical(x) for x in equations)
    steps=[]

    def application(label,names,rule_name,case=None):
        rule=plans[label]['rules'][rule_name]
        if rule.get('expected','unsat')!='unsat':raise ValueError('SAT is not an implication')
        facts={canonical(x,names) for x in rule['assumptions']}
        allowed=available|({canonical(case)} if case else set())
        if facts-allowed:raise ValueError('Unclosed common-trace premise: '+label+':'+rule_name+' '+str(facts-allowed))
        return canonical(rule['conclusion'],names)

    for label,module,revision,pre,post,names in FAMILIES:
        if label=='native-config':
            # Initial ROM identity is the named native configuration boundary.
            # The exact proved transition law supplies its subsequent instances.
            obtained=application(label,{},'native-ROM-configuration-preserved')
            if obtained!=canonical(f'(|{TOP}_i| an)'):
                raise ValueError('Configuration preservation has a different endpoint')
            available.add(obtained)
            continue
        if label=='rms-native-history':
            names={'h':'ch','hn':'chn'}
            for family,post in [('unary','(rms-u-inv an)'),('history','(rms-h-inv an chn)')]:
                for k in range(32):
                    case=f'(= (|{TOP}_n u_native.u_six_layers.u_datapath.u_rmsnorm.state_q| a) (_ bv{k} 5))'
                    if application(label,names,family+'-preserved-'+str(k),case)!=canonical(post):
                        raise ValueError('Native state case does not prove its post invariant')
                available.add(canonical(post))
                steps.append(dict(component=label,family=family,all_native_5bit_states=32,post=post))
            outcome=application(label,names,'actual-current-invocation-ordered-output')
            available.add(outcome)
            continue
        names=names or {}
        if label=='query-memory':
            if application(label,names,'preserved')!=canonical(post):
                raise ValueError('Query RAM preservation has a different endpoint')
            available.add(canonical(post))
            steps.append(dict(component=label,parts=1,post=post))
            continue
        selected=[k for k in plans[label]['order'] if k.startswith('preserved-')]
        parts=[application(label,names,k) for k in selected]
        join=plans[label]['rules']['parts-join']
        if {canonical(x,names) for x in join['assumptions']}!=set(parts) or canonical(join['conclusion'],names)!=canonical(post):
            raise ValueError('Incomplete invariant conjunction: '+label)
        available.add(canonical(post))
        steps.append(dict(component=label,parts=len(parts),post=post))

    # All base rules must start from the same actual reset edge and the stated
    # functional observer zeroes; next-state ROM identity is already supplied.
    base=source|{canonical(f'(|{TOP}_i| an)'),canonical('(not '+d('rst_n')+')'),
                  canonical('(or (not '+d('rst_n')+') '+d('clear_i')+')')}
    expected_bases={
        'parent-flow':['(flow-inv an)'],'parent-kinds':['(kind-inv an)'],
        'rms-snapshot':['(rs-inv an rs-zero)'],
        'rms-native-history':['(rms-u-inv an)','(rms-h-inv an history-zero)'],
        'rms-capture':['(rc-inv an rs-zero watch)'],
        'rms-arguments':['(ra-inv an rs-zero)'],
        'rms-store-r4':['(rv-inv an rs-zero history-zero (rv-base an))'],
        'q-input-capture-r3':['(qi-inv an (rv-base an) qi-zero watch)'],
        'query-memory':['(qm-inv an (qm-base an))'],
    }
    for label,module,revision,pre,post,names in FAMILIES:
        if label=='native-config':continue
        rules=plans[label]['rules']
        selected=['unary-base','history-base'] if label=='rms-native-history' else ['common-reset-base']
        for name,expected in zip(selected,expected_bases[label],strict=True):
            missing={canonical(x,names) for x in rules[name]['assumptions']}-base
            if missing:raise ValueError('Unclosed reset premise: '+label+' '+str(missing))
            if canonical(rules[name]['conclusion'],names)!=canonical(expected):
                raise ValueError('Wrong common-reset observer extension: '+label)
    return dict(checked=True,one_actual_source_trace=True,common_reset_bases_checked=True,
                actual_reset_case_split='Reset-low edges use bases; reset-high edges use regular preservation. No extra reset.',
                total_observer_equations=equations,induction_schedule=steps,
                watched_row='One arbitrary rigid BV8 row per entire trace; histories are watch independent.',
                configuration_boundary='Native initial immutable ROM identity, with proved preservation.',
                statement_scope='Actual stage-entry RMS arguments, result ordering/store ownership, complete RMS-to-Q input capture, and query RAM storage/read transport',
                query_RAM_transport_checked=True,
                independent_RMS_algorithm_proved=False,query_output_RAM_composed=False,
                connected_segment_qualified=False,whole_machine_theorem=False)


def main():
    files,rom,manifest=reconstruction()
    record=json.loads((HERE/'context-SOURCES.json').read_text())
    if any((HERE/'context'/n).read_bytes()!=b or record['files'][n]!=sha(b) for n,b in files.items()):
        raise ValueError('Native context differs from exact reconstruction')
    if (HERE/'context/compile.ys').read_text()!=recipe(files):raise ValueError('Changed native recipe')
    if sha((HERE/'context/native.smt2').read_bytes())!=record['native_smt_sha256'] or sha((HERE/'context/native.json').read_bytes())!=record['native_graph_sha256']:
        raise ValueError('Changed translated native model')
    plans={};receipts={}
    for label,module,revision,*rest in FAMILIES:
        plans[label],receipts[label]=check_component(label,module,revision)
    trace=close_trace(plans)
    result=dict(schema='RMS-Q-caller-gate-exact-receipts-and-trace-v1',passed=True,
        trace=trace,engine_results={k:len(v) for k,v in receipts.items()},receipts=receipts,
        connected_segment_qualified=False,whole_machine_theorem=False)
    atomic_json(HERE/'CALLER-GATE-RESULT.json',result)
    print(json.dumps(dict(passed=True,checks=sum(len(v) for v in receipts.values()),
        one_trace_closed=True,connected_segment_qualified=False,whole_machine_theorem=False)))


if __name__=='__main__':main()

"""Small integer providers for explicit standard word-semantic interpretation.

As in the qualified Q packet, typed unfolding of SMT-LIB word operations is a
stated trusted derivation rule. These receipts prove the integer algebra and
bounds, not a fictional monolithic BV/integer UNSAT result.
"""
from common import HERE,both,sha,atomic_bytes,write_frozen


def specification():
    decl=['(declare-const '+x+' Int)' for x in ['u','x','y','k','j','z','t']]
    rules={}
    for small,large in [(16,32),(16,26),(10,26),(26,45),(45,48)]:
        lo=1<<small;hi=1<<large;half=lo//2
        signed=f'(ite (< u {half}) u (- u {lo}))'
        rules[f'sign-extend-{small}-to-{large}']=dict(assumptions=['(<= 0 u)',f'(< u {lo})'],
            conclusion=f'(= (mod {signed} {hi}) (ite (< u {half}) u (+ u {hi-lo})))')
    for w in [26,32,38,45,48]:
        m=1<<w;h=m//2
        rules[f'product-factor-{w}']=dict(assumptions=[],conclusion=f'(= (* (+ x (* {m} k)) (+ y (* {m} j))) (+ (* x y) (* {m} (+ (* x j) (* y k) (* {m} k j)))))')
        rules[f'remove-multiple-{w}']=dict(assumptions=[],conclusion=f'(= (mod (+ z (* {m} t)) {m}) (mod z {m}))')
        rules[f'signed-residue-{w}']=dict(assumptions=[f'(<= (- {h}) z)',f'(< z {h})'],
            conclusion=f'(= (ite (< (mod z {m}) {h}) (mod z {m}) (- (mod z {m}) {m})) z)')
    rules['signed16-square-fits32']=dict(assumptions=['(<= (- 32768) x)','(< x 32768)'],
        conclusion=both(['(<= 0 (* x x))','(<= (* x x) 1073741824)','(< (* x x) 2147483648)']))
    rules['signed16-signed10-fits26']=dict(assumptions=['(<= (- 32768) x)','(< x 32768)','(<= (- 512) y)','(< y 512)'],
        conclusion=both(['(< (- 33554432) (* x y))','(< (* x y) 33554432)']))
    rules['signed26-unsigned16-fits45']=dict(assumptions=['(<= (- 33554432) x)','(< x 33554432)','(<= 0 y)','(< y 65536)'],
        conclusion=both(['(< (- 17592186044416) (* x y))','(< (* x y) 17592186044416)']))
    rules['positive-add38-no-wrap']=dict(assumptions=['(<= 0 x)','(<= 0 y)','(< (+ x y) 274877906944)'],conclusion='(= (mod (+ x y) 274877906944) (+ x y))')
    return decl,'',rules


def prepare():
    label='rms-word-semantics';d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification();atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='RMS-word-integer-algebra-v1',sources={},native_hardware_theorem=False))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='RMS-word-integer-algebra-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',inputs={f:sha((HERE/f).read_bytes()) for f in files},
        declarations=decl,rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':prepare();print('Prepared integer providers for standard typed word interpretations.')

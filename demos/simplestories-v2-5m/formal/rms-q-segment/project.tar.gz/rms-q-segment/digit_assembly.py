"""Exact input-digit assembly, prefix bounds and signed numerator meaning."""
from common import HERE,bv,both,eq,ext,sha,atomic_bytes,write_frozen
from digit_word_bridge import unsigned,signed64


def definitions():
    defs=''
    for family,width,iterations,digit_width in [('rp',45,23,2),('dp',28,28,1)]:
        outwidth=46 if family=='rp' else 28
        args=f'((x (_ BitVec {width})))'
        defs+=f'(define-fun {family}-0 {args} (_ BitVec {outwidth}) {bv(0,outwidth)})\n'
        for k in range(iterations):
            high=(outwidth-1)-digit_width*k;low=high-digit_width+1
            value='(concat #b0 x)' if family=='rp' else 'x'
            digit=f'((_ extract {high} {low}) {value})'
            defs+=f'(define-fun {family}-digit-{k} {args} (_ BitVec {digit_width}) {digit})\n'
            body=f'(bvadd (bvmul ({family}-{k} x) {bv(1<<digit_width,outwidth)}) {ext(f"({family}-digit-{k} x)",outwidth-digit_width)})'
            defs+=f'(define-fun {family}-{k+1} {args} (_ BitVec {outwidth}) {body})\n'
        k_width=5 if family=='rp' else 6
        body=f'({family}-{iterations} x)'
        for k in reversed(range(iterations)):
            body=f'(ite (= k {bv(k,k_width)}) ({family}-{k} x) {body})'
        defs+=f'(define-fun {family}-prefix ((x (_ BitVec {width})) (k (_ BitVec {k_width}))) (_ BitVec {outwidth}) {body})\n'
    return defs


def specification():
    decl=['(declare-const x (_ BitVec 45))','(declare-const y (_ BitVec 28))',
          '(declare-const kr (_ BitVec 5))','(declare-const kd (_ BitVec 6))',
          '(declare-const n (_ BitVec 64))']
    magnitude=f'(ite (= ((_ extract 63 63) n) #b1) (bvneg n) n)'
    narrow='((_ extract 27 0) '+magnitude+')'
    rules={
        'root-23-base4-digits-assemble-input':dict(assumptions=[],conclusion=eq('(rp-23 x)','(concat #b0 x)')),
        'root-preterminal-prefix-bound':dict(assumptions=[f'(bvult kr {bv(23,5)})'],
            conclusion=f'(< {unsigned("(rp-prefix x kr)")} 17592186044416)'),
        'divider-28-binary-digits-assemble-magnitude':dict(assumptions=[],conclusion=eq('(dp-28 y)','y')),
        'divider-preterminal-prefix-bound':dict(assumptions=[f'(bvult kd {bv(28,6)})'],
            conclusion=f'(< {unsigned("(dp-prefix y kd)")} 134217728)'),
        'bounded-magnitude-narrowing-and-signed-meaning':dict(assumptions=[f'(bvult {magnitude} {bv(1<<28,64)})'],
            conclusion=both([eq(unsigned(narrow),unsigned(magnitude)),
                eq(signed64('n'),f'(ite (= ((_ extract 63 63) n) #b1) (- {unsigned(narrow)}) {unsigned(narrow)})')]))
    }
    return decl,definitions(),rules


def prepare():
    label='digit-assembly';d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification();atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Pure-fixed-digit-assembly-v1',sources={},
        native_hardware_theorem=False,scope='Exact digit/input linkage for root and bounded division'))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='RMS-Q-fixed-digit-assembly-lemmas-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',
        inputs={f:sha((HERE/f).read_bytes()) for f in files},declarations=decl,
        rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':prepare();print('Prepared exact input digit assembly and prefix bounds.')

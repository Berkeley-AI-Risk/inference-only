"""Last-admission/payload origin induction over a fixed immutable trace.

The generic events and payload function are instantiated with exact source
observer constructors. Their uninterpreted nature strengthens the lemma; they
are never assumptions about numerical hardware replies.
"""
from common import HERE,both,eq,sha,atomic_bytes,write_frozen


def specification(revision=1):
    defs='''(declare-sort AdmissionPayload 0)
(declare-const empty-payload AdmissionPayload)
(declare-fun accepted-at (Int) Bool)
(declare-fun boundary-at (Int) Bool)
(declare-fun sampled-at (Int) AdmissionPayload)
(declare-datatypes () ((AdmissionOrigin (admission-origin (origin-live Bool) (origin-edge Int) (origin-payload AdmissionPayload)))))
(define-fun origin-empty () AdmissionOrigin (admission-origin false (- 1) empty-payload))
(define-fun origin-next ((time Int) (revoke Bool) (accept Bool) (sample AdmissionPayload) (old AdmissionOrigin)) AdmissionOrigin
 (ite revoke origin-empty (ite accept (admission-origin true time sample) old)))
(define-fun origin-inv ((time Int) (h AdmissionOrigin)) Bool
 (and (>= time 0)
  (=> (origin-live h) (and (>= (origin-edge h) 0) (< (origin-edge h) time)
   (accepted-at (origin-edge h)) (= (origin-payload h) (sampled-at (origin-edge h)))
   (forall ((k Int)) (=> (and (< (origin-edge h) k) (< k time)) (not (boundary-at k))))))
  (=> (not (origin-live h)) (and (= (origin-edge h) (- 1)) (= (origin-payload h) empty-payload)))))
'''
    decl=['(declare-const time Int)','(declare-const h AdmissionOrigin)','(declare-const hn AdmissionOrigin)',
        '(declare-const revoke Bool)','(declare-const accept Bool)','(declare-const sample AdmissionPayload)']
    step=['(origin-inv time h)',eq('hn','(origin-next time revoke accept sample h)'),
        eq('(accepted-at time)','accept'),eq('(boundary-at time)','(or revoke accept)'),eq('sample','(sampled-at time)')]
    rules={
        'empty-common-reset-base':dict(assumptions=[],conclusion='(origin-inv 0 origin-empty)'),
        'last-admission-payload-and-interval-preserved':dict(assumptions=step,conclusion='(origin-inv (+ time 1) hn)'),
        'owned-origin-is-real-and-payload-is-its-sample':dict(assumptions=['(origin-inv time h)','(origin-live h)'],
            conclusion=both(['(>= (origin-edge h) 0)','(< (origin-edge h) time)','(accepted-at (origin-edge h))',
                eq('(origin-payload h)','(sampled-at (origin-edge h))'),
                '(forall ((k Int)) (=> (and (< (origin-edge h) k) (< k time)) (not (boundary-at k))))'])),
        'revocation-dominates-simultaneous-admission':dict(assumptions=step+['revoke'],conclusion=eq('hn','origin-empty')),
    }
    if revision>=2:
        defs+='(declare-sort PayloadValue 0)\n(declare-fun payload-field (AdmissionPayload) PayloadValue)\n'
        decl+=['(declare-const value PayloadValue)','(declare-const valuen PayloadValue)',
            '(declare-const scope Bool)','(declare-const scopen Bool)']
        next_relation=eq('hn','(origin-next time revoke accept sample h)')
        rules['scoped-owned-source-payload-projection-preserved']=dict(assumptions=[next_relation,
            '(=> (and scope (origin-live h)) (= value (payload-field (origin-payload h))))',
            '(=> (and scopen (not revoke) accept) (= valuen (payload-field sample)))',
            '(=> (and scopen (not revoke) (not accept) (origin-live h)) (and scope (= valuen value)))'],
            conclusion='(=> (and scopen (origin-live hn)) (= valuen (payload-field (origin-payload hn))))')
        rules['complete-source-payload-projection-preserved']=dict(assumptions=[next_relation,
            eq('value','(payload-field (origin-payload h))'),
            '(=> revoke (= valuen (payload-field empty-payload)))',
            '(=> (and (not revoke) accept) (= valuen (payload-field sample)))',
            '(=> (and (not revoke) (not accept)) (= valuen value))'],
            conclusion=eq('valuen','(payload-field (origin-payload hn))'))
        rules['nonempty-source-field-has-real-origin']=dict(assumptions=['(origin-inv time h)',
            eq('value','(payload-field (origin-payload h))'),'(distinct value (payload-field empty-payload))'],
            conclusion='(origin-live h)')
    return decl,defs,rules


def prepare(revision=1):
    label='admission-fold'+('-r2' if revision>=2 else '');d=HERE/label;d.mkdir(exist_ok=True);decl,defs,rules=specification(revision);atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Last-admission-payload-origin-induction-v1',sources={},native_hardware_theorem=False))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='Last-admission-payload-origin-induction-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',inputs={f:sha((HERE/f).read_bytes()) for f in files},
        declarations=decl,rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':
    import sys
    prepare(2 if '--revision-2' in sys.argv else 1)

# Independent baseline RMSNorm arithmetic profile (draft)

This is a proposed closed numerical meaning, not a completed implementation
proof. No reference operation below reads RTL scratch, actual helper replies
or an actual output. Inputs are the accepted vector A[0..255], exponent e and
fixed model role r. All arithmetic is mathematical integer arithmetic except
the explicitly described finite bit-string digit procedures.

Legal inputs have -32767 <= A[i] <= 32767 and -32 <= e <= 31. Roles 0..11
select input/post-attention normalization at layer floor(r/2); role 12 is final
normalization. Coefficients, multiplier and tensor exponent come from the
pinned 13-bank norm ROM, with the independently decoded model binding retained.

Define RNE(n,d), d>0: q=floor(abs(n)/d), t=abs(n)-q*d. Increment q if 2*t>d
or if 2*t=d and q is odd. Restore n's sign. RNE-shift(n,k) applies RNE(n,2^k)
for 1..62, returns n for k=0, returns zero for k>62, and for -62..-1 left-shifts
n by -k. The service's scalar shift returns zero for k<-62; the vector
normalizer instead rejects that count and checks left-shift overflow.

1. S=sum(A[i]^2). Reject if S>=2^38 rather than wrapping.
2. M=RNE-shift(S,8). Set h=-20-2*e. For h<0, epsilon=RNE-shift(1,-h);
   for h>44, epsilon=2^45-1; otherwise epsilon=2^h.
   Set X=max(1,M+epsilon); reject if X>=2^45 or M<0.
3. Compute the unsigned 45-bit integer square root by the 23-digit procedure
   below, obtaining D. Reject if D=0.
4. For i in order 0..255, compute Z=RNE(A[i]*4096,D), clamp Z into
   [-32767,32767], then B[i]=Z*coefficient[r,i]*multiplier[r,i]. Reject an
   ROM/configuration validation requires coefficient!=-512, tensor exponent=-8
   for roles 0..11 or -7 for role 12, and the role multiplier table below.
   Define the raw source exponent as tensor_exponent[r,i]-27; reject if it is
   outside [-128,127] or B[i] is outside [-(2^39-1),2^39-1].
   The multiplications fit their
   named intermediate widths; that correspondence must be proved.
5. Apply the already specified independent whole-vector normalization algorithm
   from ../q-operator/NORMALIZATION-PROFILE-DRAFT.md to those 256 raw rows.
   Its rounding, candidate/retry, zero-vector and prefix/rejection rules apply.

The root digit procedure starts remainder=0, root=0 and consumes the 23 base-4
digits of the 46-bit string 0||X, most significant first. For digit d, set
t=4*remainder+d and trial=4*root+1. If t>=trial, set remainder=t-trial and
root=2*root+1; otherwise set remainder=t and root=2*root. The final root is D.

The bounded divider digit procedure starts remainder=0, quotient=0 and consumes
the 28 binary digits of abs(n), most significant first. Here abs(n)<2^28.
For bit b, set t=2*remainder+b. If t>=d, set remainder=t-d and
quotient=2*quotient+1; otherwise set remainder=t and quotient=2*quotient.
Use the final remainder/quotient to apply the RNE rule above and restore sign.
Zero divisor rejects. The helper's public 64-bit numerator pins do not enlarge
the caller's prescribed bounded domain.

Arbitrary external stalls and source interruptions can truncate the stream;
they cannot excuse an earlier incorrect live output. A complete interruption,
watchdog and owner composition is required before this profile is qualified.

The role multiplier table, in role order 0 through 12, is
18950,17930,18104,18211,18373,18536,18639,19036,19944,19662,20229,20732,23930.
The service uses its scalar shift only for nonnegative shift counts. Its
negative-count branch is not needed by this RMS algorithm; no unbounded integer
left-shift equivalence is claimed for that finite signed64 RTL function.

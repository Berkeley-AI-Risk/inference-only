"""Scoped native proof plumbing; no theorem is established by this module."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PILOT = HERE.parent
sys.path.insert(0, str(PILOT / 'model-consumption'))
from source_policy import native_source, require_exact
sys.path.insert(0, str(PILOT))
from checkpoint import atomic_bytes, atomic_json


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bv(x, w):
    return '(_ bv%d %d)' % (x % (1 << w), w)


def both(items):
    return '(and ' + ' '.join(items) + ')' if items else 'true'


def eq(a, b):
    return '(= ' + a + ' ' + b + ')'


def ext(x, w, signed=False):
    return '((_ %s_extend %d) %s)' % ('sign' if signed else 'zero', w, x)


def compile_native(label, top, selection):
    source, rows = native_source(selection)
    require_exact(source, selection)
    recipe = '\n'.join([
        'read_verilog -formal -sv -nosynthesis native.sv',
        'hierarchy -check -top ' + top, 'proc', 'opt_clean', 'flatten',
        'async2sync', 'opt_clean', 'dffunmap', 'memory_collect',
        'select -assert-none t:$assert t:$assume t:$anyconst t:$anyseq',
        'check -assert', 'write_json native.json', 'write_smt2 -wires native.smt2',
    ]) + '\n'
    d = HERE / label
    d.mkdir(exist_ok=True)
    if not (d / 'native.smt2').exists():
        atomic_bytes(d / 'native.sv', source.encode())
        atomic_bytes(d / 'compile.ys', recipe.encode())
        with (d / 'compile.log').open('w') as log:
            cp = subprocess.run(['yosys', '-Q', 'compile.ys'], cwd=d,
                                stdout=log, stderr=subprocess.STDOUT, timeout=120)
        if cp.returncode:
            raise ValueError('Native translation failed: ' + label)
    if (d / 'native.sv').read_text() != source or (d / 'compile.ys').read_text() != recipe:
        raise ValueError('Changed existing source or recipe: ' + label)
    manifest = dict(schema='RMS-Q-exact-native-model-v1', top=top, sources=rows,
                    source_sha256=sha(source.encode()), internal_cuts=[],
                    native_smt_sha256=sha((d / 'native.smt2').read_bytes()),
                    native_graph_sha256=sha((d / 'native.json').read_bytes()),
                    HDL_observer_additions=[], translation_only=True)
    write_frozen(HERE / (label + '-SOURCES.json'), manifest)
    return manifest


def write_frozen(path, value):
    if path.exists() and json.loads(path.read_text()) != value:
        raise ValueError('Changed frozen record; use a new revision: ' + str(path))
    atomic_json(path, value)


def save_plan(label, declarations, definitions, rules, native_label=None):
    d = HERE / label
    d.mkdir(exist_ok=True)
    native_label=native_label or label
    atomic_bytes(d / 'algorithm.smt2', definitions.encode())
    bodies = [native_label + '/native.smt2', label + '/algorithm.smt2']
    files = [native_label + '-SOURCES.json', native_label + '/compile.ys',
             native_label + '/native.json', *bodies]
    plan = dict(schema='RMS-Q-local-native-implications-v1', component=label,
                bodies=bodies, source_manifest=native_label + '-SOURCES.json',
                inputs={p: sha((HERE / p).read_bytes()) for p in files},
                declarations=declarations, rules=rules, order=list(rules),
                checks_file=label + '-CHECKS.json', external_facts={},
                connected_segment_proved=False, whole_machine_theorem=False)
    write_frozen(HERE / (label + '-PLAN.json'), plan)
    return plan

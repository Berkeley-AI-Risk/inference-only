"""Checkable UNSAT-preserving strengthening of pure digit-prefix theories.

Uniformly forget only earlier pure function definitions. Keep base zero and the
single current k->k+1 recurrence; native source and every assertion are byte
unchanged. Instantiating arbitrary functions with the forgotten definitions
recovers the original theory, so UNSAT is sufficient. SAT is not transferable.
"""
import re
import sys
from common import PILOT, sha
sys.path.insert(0,str(PILOT/'q-operator'))
from pruned_arithmetic import parse,emit


def transform(text,component,rule):
    if component not in ['root-r2','divider','root-instance','divider-instance','rms-scalar-algorithm','rms-scalar-algorithm-r2','rms-scalar-algorithm-r3','rms-scalar-algorithm-r4','rms-helper-tickets','rms-raw-capture','rms-endpoints']:
        raise ValueError('Unsupported pure digit family')
    scalar=component in ['rms-scalar-algorithm','rms-scalar-algorithm-r2','rms-scalar-algorithm-r3','rms-scalar-algorithm-r4','rms-helper-tickets','rms-raw-capture','rms-endpoints']
    family='root' if component in ['root-r2','root-instance'] else 'div'
    m=re.fullmatch(r'digit-(\d+)-preserved',rule)
    keep={0}
    if m:keep.add(int(m[1])+1)
    raw_capture=component=='rms-raw-capture'
    pure_getters=component in ['rms-scalar-algorithm-r3','rms-scalar-algorithm-r4'] and rule=='preserved-5'
    if pure_getters:
        # This selected lemma has no native H/T/i premise: all implementation
        # transfer/producer facts are separately proved providers. Forgetting
        # named getter aliases removes their irrelevant internal combinational
        # expansion and proves the same pure congruence for arbitrary getters.
        for line in text.splitlines():
            if line.startswith('(assert ') and re.search(r'\|board1_fixed_vector_rmsnorm_service_[hti]\|',line):
                raise ValueError('Native premise in pure getter-congruence lemma')
    dsp_rule=(component in ['rms-scalar-algorithm-r3','rms-scalar-algorithm-r4'] and rule=='scalar-raw-register-update') or raw_capture
    dsp_symbol=None
    if dsp_rule:
        getter='|board1_fixed_vector_rmsnorm_service_n dsp_wide_product|'
        node=next(x for x in parse(text) if x[:2]==['define-fun',getter])
        if node[3]!=['_','BitVec','48'] or len(node[4])!=2 or node[4][1]!='state':
            raise ValueError('Changed native DSP word alias')
        dsp_symbol=node[4][0]
        if not re.fullmatch(r'\|board1_fixed_vector_rmsnorm_service#[0-9]+\|',dsp_symbol):
            raise ValueError('DSP alias is not a native internal function')
    out=[];changes=[]
    for ordinal,line in enumerate(text.splitlines(keepends=True)):
        found=re.match(r'\(define-fun ('+family+r'-[qr]-(\d+)) ',line)
        scalar_found=re.match(r'\(define-fun (root-value|div-value'+('|RMS-record' if component=='rms-endpoints' else ('|rms-scaled|rms-clamp|rms-numerator|rms-radicand|rms-radicand-wide|rms-mean|rms-epsilon' if raw_capture else ('|rms-scaled|rms-clamp|rms-numerator' if pure_getters else '')))+r') ',line) if scalar else None
        getter_found=re.match(r'\(define-fun \|board1_fixed_vector_rmsnorm_service_(n|m) ',line) if pure_getters else None
        dsp_found=dsp_symbol and line.startswith('(define-fun '+dsp_symbol+' ')
        if scalar_found or getter_found or dsp_found or not scalar and found and int(found[2]) not in keep:
            nodes=parse(line)
            if len(nodes)!=1 or len(nodes[0])!=5:
                raise ValueError('Unsupported pure function definition')
            node=nodes[0]
            replacement=emit(['declare-fun',node[1],[a[1] for a in node[2]],node[3]])+'\n'
            changes.append(dict(line=ordinal,name=node[1],original=line,replacement=replacement))
            out.append(replacement)
        else:out.append(line)
    if not changes:raise ValueError('No pure prefix definition forgotten')
    transformed=''.join(out)
    restored=transformed.splitlines(keepends=True)
    for c in changes:
        if restored[c['line']]!=c['replacement']:
            raise ValueError('Changed abstraction signature')
        restored[c['line']]=c['original']
    if ''.join(restored)!=text:
        raise ValueError('Abstraction altered a non-definition byte')
    record=dict(schema='Uniform-pure-digit-prefix-forgetting-v1',component=component,
        rule=rule,kept_prefix_indices=sorted(keep),forgotten_functions=[c['name'] for c in changes],
        original_sha256=sha(text.encode()),engine_sha256=sha(transformed.encode()),
        original_reconstructed_byte_identically=True,native_and_assertions_unchanged=not (pure_getters or dsp_rule),
        usable_engine_answer='unsat',sat_transfer_forbidden=True)
    if pure_getters:
        record['pure_native_getter_congruence']=True
        record['pure_profile_congruence_functions']=['rms-scaled','rms-clamp','rms-numerator']
        record['no_native_transition_or_hierarchy_premise']=True
        record['rule_explanation']='Uniform same-signature forgetting of native getter aliases in a pure logical join; every original model is recovered by reinstating those exact definitions.'
    if pure_getters or dsp_rule:record['assertions_unchanged']=True
    if raw_capture:record['independent_scalar_function_congruence']=True
    if component=='rms-endpoints':record['reference_record_function_congruence']=True
    if dsp_rule:
        record['native_dsp_word_function']=dsp_symbol
        record['rule_explanation']='Uniform same-signature forgetting of the native DSP word function in a register-transfer-only lemma. Native transition and observed DSP getter still share that exact function; its numerical equation is a separately proved provider.'
    return transformed,record

"""Parametric full-record certificate transport, including pre-write reads.

P is arbitrary: substitution with the complete numerical/admission/owner
certificate is valid only after proving P(new-record) at every actual Q write.
Unused physical entries are unconstrained; they have no valid certificate.
"""
from common import HERE,both,eq,sha,atomic_bytes,write_frozen


def specification(revision=1):
    defs='(declare-sort ProofRecord 0)\n(declare-fun P (ProofRecord) Bool)\n'
    decl=['(declare-const '+x+' Bool)' for x in ['reset','revoke','write','qwrite','read','sample-valid']]
    decl+=['(declare-const '+x+' (_ BitVec 8))' for x in ['address','watch','read-address']]
    decl+=['(declare-const table (Array (_ BitVec 8) ProofRecord))',
        '(declare-const valid (Array (_ BitVec 8) Bool))','(declare-const fresh ProofRecord)',
        '(declare-const sample ProofRecord)']
    nexttable='(ite qwrite (store table address fresh) table)'
    nextvalid='(ite (or reset revoke) ((as const (Array (_ BitVec 8) Bool)) false) (ite write (store valid address qwrite) valid))'
    nextsample='(ite read (select table read-address) sample)'
    nextreadvalid='(ite (or reset revoke) false (ite read (select valid read-address) sample-valid))'
    rules={
        'arbitrary-retained-records-have-no-reset-authority':dict(assumptions=['reset'],
            conclusion='(not (select '+nextvalid+' watch))'),
        'full-record-property-is-preserved':dict(assumptions=['(=> (select valid watch) (P (select table watch)))','(=> qwrite (P fresh))'],
            conclusion='(=> (select '+nextvalid+' watch) (P (select '+nexttable+' watch)))'),
        'prewrite-read-property-is-preserved':dict(assumptions=['(=> (select valid read-address) (P (select table read-address)))',
            '(=> sample-valid (P sample))'],conclusion='(=> '+nextreadvalid+' (P '+nextsample+'))'),
        'read-and-write-same-address-uses-old-record':dict(assumptions=['read',eq('read-address','address')],conclusion=eq(nextsample,'(select table address)')),
    }
    if revision>=2:
        decl+=['(declare-const qaddress (_ BitVec 8))']
        old=nexttable;new='(ite qwrite (store table qaddress fresh) table)'
        rule=rules['full-record-property-is-preserved']
        rule['assumptions']+=['(=> qwrite (= qaddress address))']
        rule['conclusion']=rule['conclusion'].replace(old,new)
    return decl,defs,rules


def prepare(revision=1):
    label='record-transport'+('-r2' if revision>=2 else '');d=HERE/label;d.mkdir(exist_ok=True);decl,defs,rules=specification(revision)
    atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Parametric-full-record-certificate-transport-v1',sources={},native_hardware_theorem=False))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='Parametric-full-record-certificate-transport-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',inputs={f:sha((HERE/f).read_bytes()) for f in files},
        declarations=decl,rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':
    import sys
    prepare(2 if '--revision-2' in sys.argv else 1)

"""Joint actual sequence/datapath phase gate for the RMS-to-Q segment.

Unchanged source controllers and actual segment producers, not unrestricted
private ingress/stage ports. This unary invariant is a first composition gate;
it supplies no desired numerical reply or model-derived activation assumption.
"""
from common import bv,both,eq,save_plan
from prepare_context import TOP,DP,SEQ,prepare

S='|'+TOP+'_s|'
n=lambda path,a='a':f'(|{TOP}_n {path}| {a})'
d=lambda field,a='a':n(DP+field,a)
s=lambda field,a='a':n(SEQ+field,a)


def definitions():
    args=f'((a {S}))'
    healthy=both([d('rst_n'),f'(not {d("fault_q")})',f'(not {s("fault_q")})'])
    active='(or '+' '.join(eq(d('engine_state_q'),bv(k,4)) for k in range(1,8))+')'
    matched=both([eq(d('current_stage_q'),s('stage_q')),
                  eq(d('current_layer_q'),s('layer_q')),
                  eq(d('current_position_q'),s('position_q'))])
    clauses=[
        f'(bvule {d("engine_state_q")} {bv(8,4)})',
        f'(=> {eq(s("state_q"),bv(1,3))} {eq(d("engine_state_q"),bv(0,4))})',
        f'(=> {eq(s("state_q"),bv(2,3))} '+both([eq(d('engine_state_q'),bv(0,4)),f'(not {d("stage_done_q")})'])+')',
        f'(=> {active} '+both([eq(s('state_q'),bv(3,3)),matched])+')',
        f'(=> {eq(s("state_q"),bv(3,3))} '+both([matched,f'(or {active} (and {eq(d("engine_state_q"),bv(0,4))} {d("stage_done_q")}))'])+')',
        f'(=> {d("stage_done_q")} '+both([eq(d('engine_state_q'),bv(0,4)),eq(s('state_q'),bv(3,3))])+')',
        f'(=> {eq(d("engine_state_q"),bv(8,4))} {eq(s("state_q"),bv(0,3))})',
    ]
    defs=f'(define-fun flow-healthy {args} Bool {healthy})\n'
    for i,c in enumerate(clauses):
        defs+=f'(define-fun flow-clause-{i} {args} Bool (=> (flow-healthy a) {c}))\n'
    defs+=f'(define-fun flow-inv {args} Bool '+both([f'(flow-clause-{i} a)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions()
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    step=ctx+['(flow-inv a)']
    parts=[f'(flow-clause-{i} an)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(flow-inv an)'),
           **{f'preserved-{i}':dict(assumptions=step,conclusion=p) for i,p in enumerate(parts)},
           'parts-join':dict(assumptions=parts,conclusion='(flow-inv an)')}
    rms=eq(d('engine_state_q'),bv(1,4))
    rules['owned-RMS-has-no-hidden-write']=dict(assumptions=[H('a'),'(flow-inv a)','(flow-healthy a)',rms],
        conclusion=both([f'(not {d("private_ingress_write_i")})',f'(not {d("hidden_ram_write_enable")})',
                         eq(s('state_q'),bv(3,3))]))
    rules['accepted-RMS-input-no-hidden-write']=dict(assumptions=[H('a'),'(flow-inv a)',d('rms_input_fire')],
        conclusion=both(['(flow-healthy a)',rms,f'(not {d("hidden_ram_write_enable")})']))
    rules['Q-stage-accepted-by-fixed-sequence']=dict(assumptions=[H('a'),d('stage_accept'),eq(d('private_stage_i'),bv(1,5))],
        conclusion=both([eq(s('state_q'),bv(2,3)),eq(s('stage_q'),bv(1,5)),
                        eq(d('private_layer_i'),s('layer_q')),eq(d('private_position_i'),s('position_q'))]))
    rules['nontrivial-RMS-context']=dict(assumptions=[H('a'),'(flow-inv a)','(flow-healthy a)',rms],
        conclusion='false',expected='sat')
    return decl,defs,rules


if __name__=='__main__':
    prepare()
    save_plan('parent-flow',*specification(),native_label='context')
    print('Prepared joint source-controller induction; no solver started.')

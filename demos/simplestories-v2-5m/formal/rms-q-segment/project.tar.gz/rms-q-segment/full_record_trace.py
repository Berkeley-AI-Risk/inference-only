"""Instantiate full-certificate last-writer transport at actual query RAM.

The immutable proof record includes a producing-admission witness. Its P
predicate is about that saved trace prefix and independent programs, never the
current RMS buffer or a later current native state. Pure store/select induction
transports that entire certificate in parallel with the saved visible fields.
"""
from common import bv,sha
from verify_gate import check_component
from rms_native_history import parse,emit
from query_numeric_store import definitions,ARRAYS
from parent_flow import d
from derivation import apply,canonical,conjuncts


def close(interface,q_import,frame):
    plan,_=check_component('record-transport-r2','record_transport',2)
    fold=interface['checked_accepted_fold_derivation']
    if len(fold['accepted_steps'])!=256 or not fold['complete']['all_premises_closed']:
        raise ValueError('Full Q certificate needs actual accepted-input substitution')
    projection=q_import['scalar_conjunction_elimination']
    full=q_import['full_numerical_endpoint']
    if full!=projection['source'] or q_import['full_numerical_conjunct_preserved'] not in full:
        raise ValueError('Full numerical Q certificate was dropped')
    if not q_import['qualified_product_application']['all_premises_closed']:
        raise ValueError('Full saved certificate needs a closed Q product application')
    if not frame['all_selected_frame_rules_applied'] or not frame['complete_RMS_profile_endpoint']:
        raise ValueError('Saved RMS reference lacks a single independent program frame')
    owner_plan,_=check_component('q-record-context','q_record_context',1)
    owner_applications={name:apply(rule,{},rule['assumptions']) for name,rule in owner_plan['rules'].items()}
    admission_plan,_=check_component('q-record-admission-r2','q_record_admission',2)
    interface_source=interface['checked_native_adapter_applications']
    admission_guards=interface_source['applications']['actual-Q-admission-fixes-independent-RMS-reference']['observation_guards']
    admission=apply(admission_plan['rules']['actual-Q-admission-binds-RMS-origin-tags'],{},
        interface_source['current_joint_invariants']+[interface_source['qmode_observation']]+admission_guards)
    from certificate_predicate import producer as introduce,at
    introduction=introduce(interface,q_import,frame,owner_applications,admission)
    nodes={x[1]:x for x in parse(definitions()) if x[0]=='define-fun'}
    nxt=nodes['qnum-next'][4]
    if nxt[0]!='ite' or nxt[2]!='qnum-zero' or nxt[3][0]!='query-numeric':raise ValueError('Changed query record reset/constructor')
    fields=nxt[3][1:];wr='((_ extract 7 0) (na-scan qna))';rd=d('query_ram_read_address')
    values=['(na-mantissa qna)','(na-candidate qna)','true','(rs-generation rs)',d('current_layer_q'),d('current_position_q'),'qa','qna']
    revoke='(or '+d('clear_i')+' (and '+d('stage_accept')+' (= '+d('private_stage_i')+' '+bv(1,5)+')))'
    bindings={}
    for i,((name,sort),value) in enumerate(zip(ARRAYS,values,strict=True)):
        ordinary='(ite (qnum-write a) (store (qnum-'+name+' h) '+wr+' '+value+') (qnum-'+name+' h))'
        if name=='valid':ordinary='(ite '+revoke+' ((as const (Array (_ BitVec 8) Bool)) false) (ite '+d('query_ram_write_enable')+' (store (qnum-valid h) ((_ extract 7 0) '+d('output_index_q')+') (qnum-write a)) (qnum-valid h)))'
        if canonical(emit(fields[i]))!=canonical(ordinary):raise ValueError('Full record write field mismatch '+name)
        read='(ite '+d('query_ram_read_enable')+' (select (qnum-'+name+' h) '+rd+') (qnum-read-'+name+' h))'
        if name=='valid':read='(ite '+revoke+' false '+read+')'
        if canonical(emit(fields[i+len(ARRAYS)]))!=canonical(read):raise ValueError('Full record pre-write read field mismatch '+name)
        bindings[name]=dict(actual_reference_field=value,write=emit(fields[i]),prewrite_read=emit(fields[i+len(ARRAYS)]))
    row='(ite '+d('query_ram_read_enable')+' '+rd+' (qnum-read-row h))'
    if canonical(emit(fields[-1]))!=canonical(row):raise ValueError('Saved read row no longer samples actual request address')
    # Instantiate the parametric certificate lemmas. P(fresh) is supplied by
    # the full Q theorem + the checked admission substitution below, not a
    # numerical environment premise. The row/read hypotheses are exactly the
    # two inductive certificate predicates at this predecessor.
    # The current state/history symbols in the native induction denote these
    # exact members of the one fixed trace family at t. This is a history
    # specialization; no foreign native state sorts are equated.
    aliases={at('actual','t'):'a',at('RS','t'):'rs',at('QA','t'):'qa',at('QNA','t'):'qna'}
    def current(node):
        text=emit(node)
        if text in aliases:return parse(aliases[text])[0]
        return [current(x) for x in node] if isinstance(node,list) else node
    fresh=emit(current(parse(introduction['explicit_predicate']['fresh_constructor'])[0]))
    intro=canonical(emit(current(parse(introduction['conclusion'])[0])))
    mapping={'reset':'(not '+d('rst_n')+')','revoke':revoke,
        'write':d('query_ram_write_enable'),'qwrite':'(qnum-write a)',
        'read':d('query_ram_read_enable'),'address':'((_ extract 7 0) '+d('output_index_q')+')','read-address':rd,
        'qaddress':wr,'P':'P_tau',
        'table':'saved-certificate-table','valid':'(qnum-valid h)',
        'fresh':fresh,'sample':'saved-read-certificate',
        'sample-valid':'(qnum-read-valid h)'}
    from derivation import instantiate
    rowrule=instantiate(plan['rules']['full-record-property-is-preserved'],mapping)
    readrule=instantiate(plan['rules']['prewrite-read-property-is-preserved'],mapping)
    row_equality='(= '+wr+' ((_ extract 7 0) '+d('output_index_q')+'))'
    actual_producer=nodes['qnum-producer'][4]
    from arithmetic_trace import canonical as source_canonical,flatten
    reverse='(= ((_ extract 7 0) '+d('output_index_q')+') '+wr+')'
    if source_canonical(reverse) not in flatten(source_canonical(emit(actual_producer[2]))):
        raise ValueError('Qualified numerical producer does not bind the actual Q store address')
    row_provider='(=> (qnum-write a) '+row_equality+')'
    if canonical(intro)!=canonical(rowrule['assumptions'][1]):raise ValueError('Concrete P introduction does not discharge actual transport producer premise')
    rowapp=apply(plan['rules']['full-record-property-is-preserved'],mapping,[rowrule['assumptions'][0],intro,row_provider])
    readapp=apply(plan['rules']['prewrite-read-property-is-preserved'],mapping,readrule['assumptions'])
    base=apply(plan['rules']['arbitrary-retained-records-have-no-reset-authority'],mapping,['(not '+d('rst_n')+')'])
    same=apply(plan['rules']['read-and-write-same-address-uses-old-record'],mapping,[d('query_ram_read_enable'),'(= '+rd+' '+mapping['address']+')'])
    return dict(schema='Actual-query-full-numerical-certificate-transport-v1',
        predicate_scope='P(record) refers only to the saved immutable producing-admission/source-trace prefix, fixed model, fixed RMS entry and independent RMS/Q programs. It has no current-RMS/native-state parameter.',
        proof_record_fields=['RMS stage-entry input/exponent/role and generation',
            'Same actual Q descriptor admission ticket, including its distinct Q lifecycle epoch',
            'Independent normalized RMS reference and accepted used-domain QA vector/exponent',
            'FULL qualified Q numerical/program/owner certificate at the producing edge',
            'Saved QArguments, NormAlgorithm, exponent, row, generation, layer and position'],
        constructor_bindings=bindings,actual_sampled_read_row=row,
        concrete_predicate_and_producer_introduction=introduction,current_trace_history_aliases=aliases,
        store_address_rewrite=dict(actual='((_ extract 7 0) '+d('output_index_q')+')',reference=wr,
            guard='(qnum-write a)',provider=row_provider,
            inference='The literal Q producer consequent equates both low8 rows on Q writes. Rewrite guarded record stores only; invalidation always uses actual output_index_q on every physical write.'),
        actual_Q_owner_and_reference_hold_applications=owner_applications,
        producer=dict(guard='(qnum-write a)',full_Q_endpoint=full,
            full_raw_reference=q_import['full_numerical_conjunct_preserved'],
            exact_accepted_input_substitution=fold['complete'],
            independent_Q_reference_congruence=interface['used_domain_reference_substitution'],
            Q_histories=q_import['source_history_instantiation'],
            RMS_profile_frame=frame,
            P_fresh_provider='Existential introduction of THIS real producing edge, its same-admission RMS origin, and its reconstructed full Q trace certificate; save the witnesses, not merely the scalar adapter'),
        induction_hypotheses=dict(row=rowrule['assumptions'][0],read=readrule['assumptions']),
        derived_producer=intro,derived_Q_address_binding=row_provider,
        parameterized_row_application=rowapp,parameterized_read_application=readapp,
        common_reset_application=base,simultaneous_same_address_read_application=same,
        zip_rule='Each parallel field array has the exact same Q-write guard/index and same old-array read address. Zip them with a read-only certificate shadow (including producing edge/origin). The checked store/select rule preserves arbitrary P on the complete record. Other writes revoke authority. Uniform row specialization supplies the actual read address.',
        no_clean_retained_memory_assumption=True,no_current_RMS_reference_after_production=True,
        full_record_provenance_checked=True)

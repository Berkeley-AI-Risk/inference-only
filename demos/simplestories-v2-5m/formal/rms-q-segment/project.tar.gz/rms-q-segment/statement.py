"""Expose the concrete saved-certificate specification as typed SMT-LIB.

Native observation signatures are extracted from the pinned native models;
implementation meaning and legal trace/history constraints are supplied by the
reconstructed source-bound components. This file is a readable specification,
not a stand-alone SAT proof of a source trace or of the whole device.
"""
from common import HERE,PILOT,sha,atomic_bytes,atomic_json
from rms_native_history import parse,emit,atoms
from query_numeric_producer import body_files
from rms_numeric_store import definitions as rr_definitions
from query_numeric_store import definitions as query_definitions
from certificate_predicate import FIELDS,TRACE_FIELDS


def generate(saved):
    intro=saved['concrete_predicate_and_producer_introduction'];spec=intro['explicit_predicate']
    sources=['\n'.join((PILOT/'q-operator'/f).read_text() for f in body_files()),
        (HERE/'context/native.smt2').read_text(),rr_definitions(2)[0],query_definitions()]
    origin_terms=[];origin_declarations=[];origin_constraints=[]
    origins=spec['origin_construction']['checked_actual_source_origin_folds']
    for name in sorted(origins['applications']):
        row=origins['applications'][name]
        construction=row['concrete_history_construction']
        origin_terms+=construction['typed_source_function_definitions']
        origin_terms.append(construction['origin_getter_definition'])
        origin_declarations.append(construction['origin_history_declaration'])
        origin_constraints += [construction['constructed_history_base'],construction['constructed_history_recurrence']]
    sources.append('\n'.join(emit(x) for x in origin_terms))
    functions={};datatypes={};getters={}
    for text in sources:
        for x in parse(text):
            if x[0] in ['define-fun','define-fun-rec']:functions[x[1]]=x
            if x[0]=='declare-datatypes':
                for dtype in x[2]:
                    name=dtype[0]
                    if len(x[2])!=1:raise ValueError('Explicit mutually recursive datatype support required')
                    datatypes[name]=x
                    for constructor in dtype[1:]:
                        getters[constructor[0]]=name
                        for field in constructor[1:]:getters[field[0]]=name
    context='(define-fun ConstructedOriginHistoriesSpec () Bool (and '+' '.join(emit(x) for x in origin_constraints)+'))\n'
    target=context+spec['predicate']+'\n(define-fun SegmentRecordProducerSpec ((t Int)) Bool (=> (and (>= t 0) ConstructedOriginHistoriesSpec) '+intro['conclusion']+'))\n'
    required_types=set();selected={};native={};active=set()
    def dtype(name):
        if name in required_types:return
        required_types.add(name)
        for token in sorted(set(atoms([datatypes[name]]))):
            if token in datatypes and token!=name:dtype(token)
    def visit(name):
        if name in getters:dtype(getters[name]);return
        if name in selected or name in native or name not in functions:return
        x=functions[name]
        if name.startswith('|'):
            native[name]=['declare-fun',name,[a[1] for a in x[2]],x[3]];return
        if name in active:
            if x[0]!='define-fun-rec':raise ValueError('Unsupported recursive definition '+name)
            return
        active.add(name)
        for token in sorted(set(atoms(x[2:]))):
            if token in datatypes:dtype(token)
            if token!=name:visit(token)
        active.remove(name);selected[name]=x
    for sort in [s for n,s in FIELDS]+list(TRACE_FIELDS.values()):
        for token in atoms(parse(sort)):
            if token in datatypes:dtype(token)
    for token in sorted(set(atoms(parse(target)))):visit(token)
    # Native state sorts have no numerical content in this specification. Their
    # complete source-bound definitions are the separately reconstructed model.
    sorts=set()
    for text in [*FIELDS,*TRACE_FIELDS.items()]:
        for token in atoms(parse(text[1])):
            if token.endswith('_s|'):sorts.add(token)
    for node in native.values():
        for token in atoms([node[2],node[3]]):
            if token.endswith('_s|'):sorts.add(token)
    header='; Concrete RMS→Q saved-record specification. Source semantics: fixed certified trace families.\n; No check-sat here; typechecking this specification is not a hardware proof.\n'
    raw=header+'\n'.join('(declare-sort '+s+' 0)' for s in sorted(sorts))+'\n'
    # Datatype dependencies were visited depth first; use a fresh topological
    # pass because sets above deliberately did not encode declaration order.
    ordered=[];done=set()
    def put(name):
        if name in done:return
        for token in sorted(set(atoms([datatypes[name]]))):
            if token in required_types and token!=name:put(token)
        done.add(name);ordered.append(emit(datatypes[name]))
    for name in sorted(required_types):put(name)
    # The three indices are concrete getters on constructed origin histories,
    # not unconstrained Int-valued source functions in this specification.
    free_origins={'tau-'+name+'-origin' for name in origins['applications']}
    trace_declarations=[x for x in parse(spec['trace_declarations']) if not (x[0]=='declare-fun' and x[1] in free_origins)]
    raw+='\n'.join(ordered)+'\n'+'\n'.join(emit(x) for x in trace_declarations+origin_declarations)+'\n'+spec['datatype']
    raw+='\n'.join(emit(x) for x in native.values())+'\n'+'\n'.join(emit(x) for x in selected.values())+'\n'+target+'(exit)\n'
    atomic_bytes(HERE/'STATEMENT.smt2',raw.encode())
    manifest=dict(schema='RMS-Q-concrete-record-statement-v1',statement_sha256=sha(raw.encode()),
        native_observation_signatures=len(native),pure_definitions=len(selected),
        fixed_trace_context=spec['fixed_trace_context'],no_check_sat=True,proof_result=False)
    atomic_json(HERE/'STATEMENT.json',manifest)
    return raw,manifest


if __name__=='__main__':
    import json
    current=json.loads((HERE/'DEBUG-CONCRETE-RECORD.json').read_text())
    raw,manifest=generate(current);print(manifest)

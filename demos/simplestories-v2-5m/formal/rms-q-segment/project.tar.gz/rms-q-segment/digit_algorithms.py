"""Pure finite digit algorithms and their native helper implementation relations.

These algorithm functions take only an accepted argument. They do not execute
a reference circuit or read any actual helper state. Proofs use common-reset
event histories; the local caller-bound domain must be discharged at composition.
"""
from common import HERE, bv, both, eq, ext, compile_native, save_plan

ROOT_TOP = 'board0_exact_isqrt_u45_iterative'
DIV_TOP = 'board1_rmsnorm_bounded28_divider'
ROOT_FILE = 'fpga/token_only_model0_board0/rtl/physical/board0_exact_isqrt_u45_iterative.sv'
DIV_FILE = 'fpga/token_only_model0_ddr_board1/fixed_vector_rmsnorm0/rtl/board1_fixed_rmsnorm_arithmetic.sv'


def root_functions():
    defs = ''
    add = lambda name, sort, rhs: '(define-fun ' + name + ' ((x (_ BitVec 45))) ' + sort + ' ' + rhs + ')\n'
    defs += add('root-q-0', '(_ BitVec 23)', bv(0, 23))
    defs += add('root-r-0', '(_ BitVec 47)', bv(0, 47))
    for k in range(23):
        digit = '((_ extract %d %d) (concat #b0 x))' % (45-2*k, 44-2*k)
        trial = f'(bvadd (bvmul {ext(f"(root-q-{k} x)", 24)} {bv(4,47)}) {bv(1,47)})'
        t = f'(bvadd (bvmul (root-r-{k} x) {bv(4,47)}) {ext(digit,45)})'
        defs += add('root-t-' + str(k), '(_ BitVec 47)', t)
        defs += add('root-d-' + str(k), '(_ BitVec 47)', trial)
        take = f'(bvuge (root-t-{k} x) (root-d-{k} x))'
        defs += add('root-r-' + str(k+1), '(_ BitVec 47)',
                    f'(ite {take} (bvsub (root-t-{k} x) (root-d-{k} x)) (root-t-{k} x))')
        defs += add('root-q-' + str(k+1), '(_ BitVec 23)',
                    f'(bvadd (bvmul (root-q-{k} x) {bv(2,23)}) (ite {take} {bv(1,23)} {bv(0,23)}))')
    for field, width in [('q',23), ('r',47)]:
        rhs = f'(root-{field}-22 x)'
        for k in reversed(range(22)):
            rhs = f'(ite (= k {bv(k,5)}) (root-{field}-{k} x) {rhs})'
        defs += f'(define-fun root-{field}-prefix ((x (_ BitVec 45)) (k (_ BitVec 5))) (_ BitVec {width}) {rhs})\n'
    defs += '(define-fun root-value ((x (_ BitVec 45))) (_ BitVec 23) (root-q-23 x))\n'
    return defs


def div_functions():
    defs = ''
    args = '((x (_ BitVec 28)) (d (_ BitVec 64)))'
    add = lambda name, width, rhs: f'(define-fun {name} {args} (_ BitVec {width}) {rhs})\n'
    defs += add('div-q-0',64,bv(0,64)) + add('div-r-0',65,bv(0,65))
    for k in range(28):
        digit = f'((_ extract {27-k} {27-k}) x)'
        t = f'(bvadd (bvmul (div-r-{k} x d) {bv(2,65)}) {ext(digit,64)})'
        defs += add('div-t-'+str(k),65,t)
        take = f'(bvuge (div-t-{k} x d) {ext("d",1)})'
        defs += add('div-r-'+str(k+1),65,
                    f'(ite {take} (bvsub (div-t-{k} x d) {ext("d",1)}) (div-t-{k} x d))')
        defs += add('div-q-'+str(k+1),64,
                    f'(bvadd (bvmul (div-q-{k} x d) {bv(2,64)}) (ite {take} {bv(1,64)} {bv(0,64)}))')
    for field, width in [('q',64),('r',65)]:
        rhs = f'(div-{field}-27 x d)'
        for k in reversed(range(27)):
            rhs = f'(ite (= k {bv(k,6)}) (div-{field}-{k} x d) {rhs})'
        defs += f'(define-fun div-{field}-prefix ((x (_ BitVec 28)) (d (_ BitVec 64)) (k (_ BitVec 6))) (_ BitVec {width}) {rhs})\n'
    twice=f'(bvmul (div-r-28 x d) {bv(2,65)})'
    up=f'(or (bvugt {twice} {ext("d",1)}) (and (= {twice} {ext("d",1)}) (= ((_ extract 0 0) (div-q-28 x d)) #b1)))'
    defs += add('div-rounded',64,f'(bvadd (div-q-28 x d) (ite {up} {bv(1,64)} {bv(0,64)}))')
    defs += '(define-fun div-magnitude ((n (_ BitVec 64))) (_ BitVec 64) (ite (= ((_ extract 63 63) n) #b1) (bvneg n) n))\n'
    defs += f'(define-fun div-domain ((n (_ BitVec 64))) Bool (bvult (div-magnitude n) {bv(1<<28,64)}))\n'
    defs += f'(define-fun div-value ((n (_ BitVec 64)) (d (_ BitVec 64))) (_ BitVec 64) (let ((q (div-rounded ((_ extract 27 0) (div-magnitude n)) d))) (ite (= d {bv(0,64)}) {bv(0,64)} (ite (= ((_ extract 63 63) n) #b1) (bvneg q) q))))\n'
    return defs


def root_specification():
    top = ROOT_TOP
    S = '|' + top + '_s|'
    n = lambda name, a='a': f'(|{top}_n {name}| {a})'
    defs = root_functions()
    defs += '(declare-datatypes () ((RootHistory (root-history (rh-phase (_ BitVec 2)) (rh-k (_ BitVec 5)) (rh-x (_ BitVec 45))))))\n'
    defs += f'(define-fun root-zero () RootHistory (root-history #b00 {bv(0,5)} {bv(0,45)}))\n'
    fire=both([n('request_valid_i'),n('request_ready_o')])
    cancel=f'(or (not {n("rst_n")}) {n("cancel_i")})'
    nxt=f'(ite {fire} (root-history #b01 {bv(0,5)} {n("request_value_i")}) (ite (= (rh-phase h) #b01) (root-history (ite (= (rh-k h) {bv(22,5)}) #b10 #b01) (ite (= (rh-k h) {bv(22,5)}) (rh-k h) (bvadd (rh-k h) {bv(1,5)})) (rh-x h)) (ite (and (= (rh-phase h) #b10) {n("response_ready_i")}) root-zero h)))'
    defs += f'(define-fun root-next ((a {S}) (h RootHistory)) RootHistory (ite {cancel} root-zero {nxt}))\n'
    busy=eq('(rh-phase h)','#b01');held=eq('(rh-phase h)','#b10')
    fields=[f'(bvule (rh-phase h) #b10)',eq(n('busy_q'),busy),eq(n('response_valid_o'),held),
            f'(=> {busy} '+both([f'(bvule (rh-k h) {bv(22,5)})',eq(n('iteration_q'),'(rh-k h)'),
                eq(n('radicand_shift_q'),f'(bvshl (concat #b0 (rh-x h)) (bvmul {ext("(rh-k h)",41)} {bv(2,46)}))'),
                eq(n('root_q'),'(root-q-prefix (rh-x h) (rh-k h))'),eq(n('remainder_q'),'(root-r-prefix (rh-x h) (rh-k h))')])+')',
            eq(n('response_fault_o'),'false'),
            f'(=> {held} {eq(n("response_result_o"),"(root-value (rh-x h))")})',
            f'(=> (not {held}) {eq(n("response_result_o"),bv(0,23))})']
    defs += f'(define-fun root-inv ((a {S}) (h RootHistory)) Bool (=> {n("rst_n")} {both(fields)}))\n'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h RootHistory)','(declare-const hn RootHistory)']
    H=lambda a:f'(|{top}_h| {a})'
    ctx=[H('a'),H('an'),f'(|{top}_t| a an)']
    step=ctx+['(root-inv a h)',eq('hn','(root-next a h)')]
    rules={'common-reset-base':dict(assumptions=ctx+['(not '+n('rst_n')+')'],conclusion='(root-inv an root-zero)'),
           'idle-preserved':dict(assumptions=step+[eq('(rh-phase h)','#b00')],conclusion='(root-inv an hn)'),
           'held-preserved':dict(assumptions=step+[eq('(rh-phase h)','#b10')],conclusion='(root-inv an hn)')}
    for k in range(23):
        rules[f'digit-{k}-preserved']=dict(assumptions=step+[busy,eq('(rh-k h)',bv(k,5))],conclusion='(root-inv an hn)')
    rules['case-coverage']=dict(assumptions=[H('a'),n('rst_n'),'(root-inv a h)'],
        conclusion=both([f'(or (= (rh-phase h) #b00) {held} {busy})',f'(=> {busy} (bvule (rh-k h) {bv(22,5)}))']))
    rules['actual-held-result']=dict(assumptions=[H('a'),n('rst_n'),'(root-inv a h)',n('response_valid_o')],
        conclusion=both([held,eq(n('response_result_o'),'(root-value (rh-x h))'),f'(not {n("response_fault_o")})']))
    rules['nonzero-response-compatible-context']=dict(assumptions=[H('a'),n('rst_n'),'(root-inv a h)',n('response_valid_o'),eq('(rh-x h)',bv(81,45))],
        conclusion=eq(n('response_result_o'),bv(0,23)),expected='sat')
    return decl,defs,rules


def div_specification():
    top=DIV_TOP;S='|'+top+'_s|';n=lambda name,a='a':f'(|{top}_n {name}| {a})'
    defs=div_functions()
    defs+='(declare-datatypes () ((DivHistory (div-history (dh-phase (_ BitVec 2)) (dh-k (_ BitVec 6)) (dh-n (_ BitVec 64)) (dh-d (_ BitVec 64))))))\n'
    defs+=f'(define-fun div-zero () DivHistory (div-history #b00 {bv(0,6)} {bv(0,64)} {bv(0,64)}))\n'
    fire=both([n('request_valid_i'),n('request_ready_o')]);cancel=f'(or (not {n("rst_n")}) {n("cancel_i")})'
    nxt=f'(ite {fire} (div-history #b01 {bv(0,6)} {n("request_numerator_i")} {n("request_denominator_i")}) (ite (= (dh-phase h) #b01) (div-history (ite (= (dh-k h) {bv(27,6)}) #b10 #b01) (ite (= (dh-k h) {bv(27,6)}) (dh-k h) (bvadd (dh-k h) {bv(1,6)})) (dh-n h) (dh-d h)) (ite (and (= (dh-phase h) #b10) {n("response_ready_i")}) div-zero h)))'
    defs+=f'(define-fun div-next ((a {S}) (h DivHistory)) DivHistory (ite {cancel} div-zero {nxt}))\n'
    busy=eq('(dh-phase h)','#b01');held=eq('(dh-phase h)','#b10');x='((_ extract 27 0) (div-magnitude (dh-n h)))'
    fields=[f'(bvule (dh-phase h) #b10)',eq(n('busy_q'),busy),eq(n('response_valid_o'),held),
        f'(=> (or {busy} {held}) (div-domain (dh-n h)))',
        f'(=> {busy} '+both([f'(bvule (dh-k h) {bv(27,6)})',eq(n('iteration_q'),f'(bvadd (dh-k h) {bv(36,6)})'),
            eq(n('negative_q'),'(%s ((_ extract 63 63) (dh-n h)) #b1)'%'='),eq(n('divide_by_zero_q'),eq('(dh-d h)',bv(0,64))),eq(n('divisor_q'),'(dh-d h)'),
            eq(n('dividend_shift_q'),f'(bvshl (div-magnitude (dh-n h)) (bvadd {bv(36,64)} {ext("(dh-k h)",58)}))'),
            eq(n('quotient_q'),f'(div-q-prefix {x} (dh-d h) (dh-k h))'),
            eq(n('remainder_q'),f'(div-r-prefix {x} (dh-d h) (dh-k h))')])+')',
        f'(=> {held} '+both([eq(n('response_result_o'),'(div-value (dh-n h) (dh-d h))'),eq(n('response_fault_o'),eq('(dh-d h)',bv(0,64)))])+')',
        f'(=> (not {held}) '+both([eq(n('response_result_o'),bv(0,64)),f'(not {n("response_fault_o")})'])+')']
    defs+=f'(define-fun div-inv ((a {S}) (h DivHistory)) Bool (=> {n("rst_n")} {both(fields)}))\n'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h DivHistory)','(declare-const hn DivHistory)']
    H=lambda a:f'(|{top}_h| {a})';ctx=[H('a'),H('an'),f'(|{top}_t| a an)']
    domain=f'(=> {fire} (div-domain {n("request_numerator_i")}))'
    step=ctx+['(div-inv a h)',eq('hn','(div-next a h)'),domain]
    rules={'common-reset-base':dict(assumptions=ctx+['(not '+n('rst_n')+')'],conclusion='(div-inv an div-zero)'),
        'idle-preserved':dict(assumptions=step+[eq('(dh-phase h)','#b00')],conclusion='(div-inv an hn)'),
        'held-preserved':dict(assumptions=step+[held],conclusion='(div-inv an hn)')}
    for k in range(28):
        rules[f'digit-{k}-preserved']=dict(assumptions=step+[busy,eq('(dh-k h)',bv(k,6))],conclusion='(div-inv an hn)')
    rules['case-coverage']=dict(assumptions=[H('a'),n('rst_n'),'(div-inv a h)'],conclusion=both([
        f'(or (= (dh-phase h) #b00) {busy} {held})',f'(=> {busy} (bvule (dh-k h) {bv(27,6)}))']))
    rules['actual-held-result']=dict(assumptions=[H('a'),n('rst_n'),'(div-inv a h)',n('response_valid_o')],
        conclusion=both([held,eq(n('response_result_o'),'(div-value (dh-n h) (dh-d h))'),eq(n('response_fault_o'),eq('(dh-d h)',bv(0,64)))]))
    rules['nonzero-response-compatible-context']=dict(assumptions=[H('a'),n('rst_n'),'(div-inv a h)',n('response_valid_o'),eq('(dh-n h)',bv(-7,64)),eq('(dh-d h)',bv(2,64))],
        conclusion=eq(n('response_result_o'),bv(0,64)),expected='sat')
    return decl,defs,rules


def prepare(label):
    if label in ['root','root-r2']:
        compile_native(label,ROOT_TOP,{ROOT_FILE:[ROOT_TOP]})
        spec=root_specification()
    elif label=='divider':
        compile_native(label,DIV_TOP,{DIV_FILE:[DIV_TOP]})
        spec=div_specification()
    else:
        raise ValueError('Unknown digit helper')
    return save_plan(label,*spec)


if __name__=='__main__':
    import sys
    for label in sys.argv[1:] or ['root','divider']:
        prepare(label)
        print('Prepared exact source and pure digit algorithm: '+label)

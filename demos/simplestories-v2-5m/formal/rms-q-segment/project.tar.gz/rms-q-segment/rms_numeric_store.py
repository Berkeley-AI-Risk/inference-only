"""Retain independently normalized RMS values for the subsequent Q argument.

The reference writes pure NormAlgorithm mantissas/candidate/scan, never native
result data. Its producer implication is discharged by the checked RMS stage
certificate and actual caller admission bindings in the final composition.
Unwritten payload is not required to equal arbitrary retained physical RAM.
"""
from common import HERE,bv,both,eq,ext,save_plan
from parent_flow import TOP,S,DP,d
from rms_store import definitions as store_definitions
from rms_snapshot import ARRAY
from rms_capture import r
from normalizer_instance import definitions as norm_definitions
from rms_native_history import parse,emit
from prepare_context import prepare

FIELDS=[('live','Bool'),('generation','Int'),('layer','(_ BitVec 3)'),('stage','(_ BitVec 5)'),
    ('count','(_ BitVec 9)'),('vector',ARRAY),('exponent','(_ BitVec 8)'),
    ('input',ARRAY),('input-exponent','(_ BitVec 8)'),('role','(_ BitVec 4)')]


def definitions(revision=1):
    defs,_=store_definitions(4)
    nd=next(x for x in parse(norm_definitions()) if x[0]=='declare-datatypes' and x[2][0][0]=='NormAlgorithm')
    defs+=emit(nd)+'\n'
    defs+='(declare-datatypes () ((RMSNumericStore (rms-numeric-store '+' '.join('(rr-'+f+' '+t+')' for f,t in FIELDS)+'))))\n'
    zero=['false','0',bv(0,3),bv(0,5),bv(0,9),'((as const '+ARRAY+') '+bv(0,16)+')',bv(0,8),'((as const '+ARRAY+') '+bv(0,16)+')',bv(0,8),bv(0,4)]
    defs+='(define-fun rr-zero () RMSNumericStore (rms-numeric-store '+' '.join(zero)+'))\n'
    hold=['(rr-'+f+' rr)' for f,t in FIELDS]
    fresh=hold[:];fresh[:5]=['true','(rs-generation rsn)','(rs-layer rsn)','(rs-stage rsn)',bv(0,9)]
    fresh[7:]=['(rs-vector rsn)','(rs-exponent rsn)',f'(bvadd (bvmul {ext("(rs-layer rsn)",1)} {bv(2,4)}) (ite (= (rs-stage rsn) {bv(0,5)}) {bv(0,4)} {bv(1,4)}))']
    clear=hold[:];clear[0]='false';clear[4]=bv(0,9)
    write=hold[:];write[4]=f'(bvadd (rr-count rr) {bv(1,9)})'
    write[5]='(store (rr-vector rr) ((_ extract 7 0) (na-scan na)) (na-mantissa na))'
    write[6]='(na-candidate na)'
    constructor=lambda values:'(rms-numeric-store '+' '.join(values)+')'
    args=f'((a {S}) (rsn RMSSnapshot) (na NormAlgorithm) (rr RMSNumericStore))'
    defs+=f'(define-fun rr-next {args} RMSNumericStore (ite (not {d("rst_n")}) rr-zero (ite {d("clear_i")} {constructor(clear)} (ite (rs-accept a) {constructor(fresh)} (ite {d("rms_ram_write_enable")} {constructor(write)} rr)))))\n'
    binding=both([eq(d('rms_result_mantissa'),'(na-mantissa na)'),eq(d('rms_result_exponent'),'(na-candidate na)'),
        eq(d('output_index_q'),'(na-scan na)'),f'(bvult (na-scan na) {bv(256,10)})'])
    if revision>=2:
        binding=both([binding,'(flow-healthy a)','(not (failed a))',eq(d('engine_state_q'),bv(1,4)),
            '(rs-live rs)',f'(bvult (rs-layer rs) {bv(6,3)})',
            f'(or (= (rs-stage rs) {bv(0,5)}) (= (rs-stage rs) {bv(10,5)}))',
            f'(bvsge (rs-exponent rs) {bv(-32,8)})',f'(bvsle (rs-exponent rs) {bv(31,8)})',
            f'(distinct (select (rs-vector rs) watch) {bv(-32768,16)})'])
    producer_args=f'((a {S}) (rs RMSSnapshot) (na NormAlgorithm) (watch (_ BitVec 8)))' if revision>=2 else f'((a {S}) (na NormAlgorithm))'
    defs+=f'(define-fun rr-producer {producer_args} Bool (=> {d("rms_ram_write_enable")} {binding}))\n'
    metadata=both([eq('(rr-live rr)','(rv-live v)'),eq('(rr-generation rr)','(rv-generation v)'),
        eq('(rr-layer rr)','(rv-layer v)'),eq('(rr-stage rr)','(rv-stage v)'),eq('(rr-count rr)','(rv-count v)')])
    clauses=[metadata,
        f'(=> (bvult {ext("watch",1)} (rr-count rr)) {eq("(select (rv-vector v) watch)","(select (rr-vector rr) watch)")})',
        f'(=> (bvugt (rr-count rr) {bv(0,9)}) {eq("(rv-exponent v)","(rr-exponent rr)")})',
        f'(=> (and (rr-live rr) (rs-live rs)) '+both([eq('(rr-input rr)','(rs-vector rs)'),
            eq('(rr-input-exponent rr)','(rs-exponent rs)'),eq('(rr-generation rr)','(rs-generation rs)'),
            eq('(rr-layer rr)','(rs-layer rs)'),eq('(rr-stage rr)','(rs-stage rs)')])+')']
    if revision>=2:
        role=f'(bvadd (bvmul {ext("(rr-layer rr)",1)} {bv(2,4)}) (ite (= (rr-stage rr) {bv(0,5)}) {bv(0,4)} {bv(1,4)}))'
        clauses.append(f'(=> (rr-live rr) {eq("(rr-role rr)",role)})')
        clauses.append(f'(=> (bvugt (rr-count rr) {bv(0,9)}) '+both(['(rr-live rr)',
            f'(bvult (rr-layer rr) {bv(6,3)})',f'(or (= (rr-stage rr) {bv(0,5)}) (= (rr-stage rr) {bv(10,5)}))',
            f'(bvsge (rr-input-exponent rr) {bv(-32,8)})',f'(bvsle (rr-input-exponent rr) {bv(31,8)})',
            f'(distinct (select (rr-input rr) watch) {bv(-32768,16)})'])+')')
    args=f'((a {S}) (rs RMSSnapshot) (v RMSStore) (rr RMSNumericStore) (watch (_ BitVec 8)))'
    for i,c in enumerate(clauses):defs+=f'(define-fun rr-clause-{i} {args} Bool (=> {d("rst_n")} {c}))\n'
    defs+=f'(define-fun rr-inv {args} Bool '+both([f'(rr-clause-{i} a rs v rr watch)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision);H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const rs RMSSnapshot)','(declare-const rsn RMSSnapshot)',
        '(declare-const ch History)','(declare-const chn History)','(declare-const v RMSStore)','(declare-const vn RMSStore)',
        '(declare-const rr RMSNumericStore)','(declare-const rrn RMSNumericStore)',
        '(declare-const na NormAlgorithm)','(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    providers=['(flow-inv a)','(flow-inv an)','(kind-inv a)','(kind-inv an)',
        '(rs-inv a rs)','(rs-inv an rsn)','(rv-inv a rs ch v)','(rv-inv an rsn chn vn)',
        eq('rsn','(rs-next a rs)'),eq('vn','(rv-next a an rs v)'),eq('rrn','(rr-next a rsn na rr)'),
        ('(rr-producer a rs na watch)' if revision>=2 else '(rr-producer a na)')]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],
        conclusion='(rr-inv an rs-zero (rv-base an) rr-zero watch)')}
    parts=[f'(rr-clause-{i} an rsn vn rrn watch)' for i in range(len(clauses))]
    for i,p in enumerate(parts):rules['preserved-'+str(i)]=dict(assumptions=ctx+providers+['(rr-inv a rs v rr watch)'],conclusion=p)
    rules['parts-join']=dict(assumptions=parts,conclusion='(rr-inv an rsn vn rrn watch)')
    rules['complete-RMS-store-is-independent-numerical-reference']=dict(assumptions=[d('rst_n'),'(rr-inv a rs v rr watch)',eq('(rv-count v)',bv(256,9))],
        conclusion=both([eq('(select (rv-vector v) watch)','(select (rr-vector rr) watch)'),eq('(rv-exponent v)','(rr-exponent rr)'),
            eq('(rr-count rr)',bv(256,9))]))
    # This source-only admission rule gives the exact actual service event,
    # address and data expressions consumed by the already-proved endpoint.
    rules['actual-RMS-write-admission-service-binding']=dict(assumptions=[H('a'),d('rms_ram_write_enable')],
        conclusion=both([r('result_valid_o'),r('result_ready_i'),
            eq(d('rms_result_mantissa'),r('result_mantissa_o')),eq(d('rms_result_exponent'),r('result_exponent_o')),
            eq('((_ extract 7 0) '+d('output_index_q')+')',r('result_row_index_o'))]))
    return decl,defs,rules


if __name__=='__main__':
    import sys
    revision=2 if '--revision-2' in sys.argv else 1
    prepare();save_plan('rms-numeric-store'+('-r2' if revision==2 else ''),*specification(revision),native_label='context')
    print('Prepared retained pure numerical RMS reference prefix and actual RAM correspondence.')

"""Preserve the native frontend's immutable case tables and fixed norm ROM.

The native initial predicate constrains only compiler-initialized ROM contents.
This is configuration identity, not a promise about resetless mutable RAM.
"""
import json
from common import HERE,save_plan
from parent_flow import TOP,S
from prepare_context import prepare


def specification():
    graph=json.loads((HERE/'context/native.json').read_text())['modules'][TOP]
    if any('init' in row.get('attributes',{}) for row in graph['netnames'].values()):
        raise ValueError('Register initialization needs a separate invariant')
    decl=[f'(declare-const a {S})',f'(declare-const an {S})']
    H=lambda a:f'(|{TOP}_h| {a})';I=lambda a:f'(|{TOP}_i| {a})'
    rules={
        'native-ROM-configuration-preserved':dict(assumptions=[H('a'),H('an'),f'(|{TOP}_t| a an)',I('a')],conclusion=I('an')),
        'native-ROM-configuration-compatible':dict(assumptions=[H('a'),I('a')],conclusion='false',expected='sat'),
    }
    return decl,'',rules


if __name__=='__main__':
    prepare();save_plan('native-config',*specification(),native_label='context')
    print('Prepared immutable initialized configuration preservation, separate from payload RAM.')

"""Independent exact integer meanings of the RMS multiply and mean words."""
from common import HERE,bv,both,eq,ext,sha,atomic_bytes,write_frozen


def U(x):return '(bv2int '+x+')'


def Z(x,width):
    return f'(ite (= ((_ extract {width-1} {width-1}) {x}) #b1) (- {U(x)} {1<<width}) {U(x)})'


def specification(revision=1):
    decl=['(declare-const x (_ BitVec 16))','(declare-const c (_ BitVec 10))',
          '(declare-const p (_ BitVec 26))','(declare-const m (_ BitVec 16))',
          '(declare-const s (_ BitVec 38))']
    square=f'(bvmul {ext("x",16,True)} {ext("x",16,True)})'
    direct=f'(bvmul {ext("x",10,True)} {ext("c",16,True)})'
    scaled=f'(bvmul {ext("p",19,True)} {ext("m",29)})'
    value=ext('s',26)
    q=f'(bvlshr {value} {bv(8,64)})';r=f'(bvand {value} {bv(255,64)})'
    up=f'(or (bvugt {r} {bv(128,64)}) (and (= {r} {bv(128,64)}) (= ((_ extract 0 0) {q}) #b1)))'
    rounded=f'(bvadd {q} (ite {up} {bv(1,64)} {bv(0,64)}))'
    iq=f'(div {U("s")} 256)';ir=f'(mod {U("s")} 256)'
    iup=f'(or (> {ir} 128) (and (= {ir} 128) (= (mod {iq} 2) 1)))'
    rules={
        'signed16-square-is-exact-signed32':dict(assumptions=[],
            conclusion=eq(Z(square,32),f'(* {Z("x",16)} {Z("x",16)})')),
        'signed16-by-signed10-is-exact-signed26':dict(assumptions=[],
            conclusion=eq(Z(direct,26),f'(* {Z("x",16)} {Z("c",10)})')),
        'signed26-by-unsigned16-is-exact-signed45':dict(assumptions=[],
            conclusion=eq(Z(scaled,45),f'(* {Z("p",26)} {U("m")})')),
        'signed45-to48-extension-preserves-integer':dict(assumptions=[],
            conclusion=eq(Z(ext(scaled,3,True),48),Z(scaled,45))),
        'positive-square-sum-mean-is-RNE-div256':dict(assumptions=[],
            conclusion=both([eq(U(rounded),f'(+ {iq} (ite {iup} 1 0))'),
                f'(< {U(rounded)} 1073741824)',f'(>= {Z(rounded,64)} 0)'])),
    }
    if revision>=2:
        rules['positive-square-sum-mean-is-RNE-div256']['assumptions']=[f'(bvule s {bv(256*32767*32767,38)})']
    return decl,'',rules


def prepare(revision=1):
    label='rms-word-arithmetic'+('-r2' if revision==2 else '');d=HERE/label;d.mkdir(exist_ok=True)
    decl,defs,rules=specification(revision);atomic_bytes(d/'meaning.smt2',defs.encode())
    write_frozen(HERE/(label+'-SOURCES.json'),dict(schema='Pure-RMS-word-integer-meaning-v1',sources={},
        native_hardware_theorem=False,scope='Exact finite multiply and RNE mean word interpretations'))
    files=[label+'-SOURCES.json',label+'/meaning.smt2']
    write_frozen(HERE/(label+'-PLAN.json'),dict(schema='RMS-Q-word-arithmetic-lemmas-v1',component=label,
        bodies=[label+'/meaning.smt2'],source_manifest=label+'-SOURCES.json',
        inputs={f:sha((HERE/f).read_bytes()) for f in files},declarations=decl,
        rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',external_facts={},
        connected_segment_proved=False,whole_machine_theorem=False))


if __name__=='__main__':
    import sys
    prepare(2 if '--revision-2' in sys.argv else 1)
    print('Prepared exact RMS word multiply and RNE mean interpretations.')

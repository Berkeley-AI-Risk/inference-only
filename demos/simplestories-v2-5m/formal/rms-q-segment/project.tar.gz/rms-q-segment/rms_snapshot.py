"""Fix the hidden vector at actual RMS stage admission, then prove its reads.

The snapshot is chosen at admission, not reconstructed from consumed words.
Actual controller/sequence and synchronous RAM transitions prove that it remains
the RMS input. CLEAR revokes authority without clearing the physical payload.
"""
from common import bv,both,eq,ext,save_plan
from parent_flow import S,TOP,DP,n,d,s,definitions as flow_definitions
from prepare_context import prepare

ARRAY='(Array (_ BitVec 8) (_ BitVec 16))'
mem=lambda a='a':f'(|{TOP}_m {DP}u_hidden_state.payload_mem| {a})'


def definitions():
    defs,_=flow_definitions()
    fields=[('generation','Int'),('live','Bool'),('layer','(_ BitVec 3)'),
            ('stage','(_ BitVec 5)'),('position','(_ BitVec 11)'),
            ('exponent','(_ BitVec 8)'),('vector',ARRAY),('captured','(_ BitVec 9)')]
    defs+='(declare-datatypes () ((RMSSnapshot (rms-snapshot '+' '.join('(rs-'+f+' '+t+')' for f,t in fields)+'))))\n'
    zvec='((as const '+ARRAY+') '+bv(0,16)+')'
    zero=f'(rms-snapshot 0 false {bv(0,3)} {bv(0,5)} {bv(0,11)} {bv(0,8)} {zvec} {bv(0,9)})'
    defs+='(define-fun rs-zero () RMSSnapshot '+zero+')\n'
    accept=both([d('stage_accept'),f'(or {eq(d("private_stage_i"),bv(0,5))} {eq(d("private_stage_i"),bv(10,5))})'])
    defs+=f'(define-fun rs-accept ((a {S})) Bool {accept})\n'
    args=f'((a {S}) (h RMSSnapshot))'
    values=[f'(+ (rs-generation h) 1)','true',d('private_layer_i'),d('private_stage_i'),d('private_position_i'),
            f'(ite {d("transaction_seen_q")} {d("hidden_exponent_q")} {d("private_initial_exponent_i")})',mem(),bv(0,9)]
    fresh='(rms-snapshot '+' '.join(values)+')'
    hold=['(rs-'+f+' h)' for f,t in fields]
    hold[-1]=f'(bvadd (rs-captured h) (ite {d("rms_input_fire")} {bv(1,9)} {bv(0,9)}))'
    cleared=['(rs-'+f+' h)' for f,t in fields]
    cleared[1]='false';cleared[-1]=bv(0,9)
    defs+=f'(define-fun rs-next {args} RMSSnapshot (ite (not {d("rst_n")}) rs-zero (ite {d("clear_i")} (rms-snapshot '+' '.join(cleared)+f') (ite (rs-accept a) {fresh} (rms-snapshot '+' '.join(hold)+')))))\n'
    owned=both(['(flow-healthy a)',eq(d('engine_state_q'),bv(1,4))])
    cursor=f'(ite {d("input_done_q")} {bv(256,9)} ((_ extract 8 0) {d("input_index_q")}))'
    vectorword=f'(select (rs-vector h) ((_ extract 7 0) {d("input_index_q")}))'
    clauses=[
        '(>= (rs-generation h) 0)',
        f'(bvule (rs-captured h) {bv(256,9)})',
        f'(=> {owned} '+both(['(rs-live h)','(> (rs-generation h) 0)',
            eq('(rs-layer h)',d('current_layer_q')),eq('(rs-stage h)',d('current_stage_q')),
            eq('(rs-position h)',d('current_position_q')),eq('(rs-exponent h)',d('hidden_exponent_q'))])+')',
        f'(=> {owned} {eq(mem(),"(rs-vector h)")})',
        f'(=> {owned} '+both([f'(bvule {d("input_index_q")} {bv(255,10)})',eq('(rs-captured h)',cursor)])+')',
        f'(=> (and {owned} {d("hidden_read_valid_q")}) {eq(d("hidden_ram_read_data"),vectorword)})',
    ]
    for i,c in enumerate(clauses):
        defs+=f'(define-fun rs-clause-{i} {args} Bool (=> {d("rst_n")} {c}))\n'
    defs+=f'(define-fun rs-inv {args} Bool '+both([f'(rs-clause-{i} a h)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions()
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
          '(declare-const h RMSSnapshot)','(declare-const hn RMSSnapshot)']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    step=ctx+['(flow-inv a)','(flow-inv an)','(rs-inv a h)',eq('hn','(rs-next a h)')]
    parts=[f'(rs-clause-{i} an hn)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(rs-inv an rs-zero)'),
        **{f'preserved-{i}':dict(assumptions=step,conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(rs-inv an hn)')}
    current=[H('a'),'(flow-inv a)','(rs-inv a h)',d('rms_input_fire')]
    result=both(['(rs-live h)','(> (rs-generation h) 0)',f'(bvult (rs-captured h) {bv(256,9)})',
        eq('(rs-captured h)',ext('((_ extract 7 0) '+d('input_index_q')+')',1)),
        eq(d('hidden_ram_read_data'),f'(select (rs-vector h) ((_ extract 7 0) {d("input_index_q")}))'),
        eq(d('current_layer_q'),'(rs-layer h)'),eq(d('current_position_q'),'(rs-position h)'),
        f'(not {d("hidden_ram_write_enable")})'])
    rules['actual-RMS-input-is-entry-vector']=dict(assumptions=current,conclusion=result)
    rules['CLEAR-revokes-snapshot-authority']=dict(assumptions=[eq('hn','(rs-next a h)'),d('rst_n'),d('clear_i')],
        conclusion=both([f'(not (rs-live hn))',eq('(rs-generation hn)','(rs-generation h)')]))
    rules['fresh-RMS-generation-distinguishes-replay']=dict(assumptions=[eq('hn','(rs-next a h)'),d('rst_n'),f'(not {d("clear_i")})','(rs-accept a)'],
        conclusion=both(['(rs-live hn)',eq('(rs-generation hn)','(+ (rs-generation h) 1)'),eq('(rs-vector hn)',mem())]))
    return decl,defs,rules


if __name__=='__main__':
    prepare()
    save_plan('rms-snapshot',*specification(),native_label='context')
    print('Prepared stage-entry snapshot and actual synchronous hidden-RAM capture obligations.')

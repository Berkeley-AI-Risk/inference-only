"""Discharge numerical-store producer from actual RMS endpoint and caller.

The endpoint implication is an already-proved module consequence, closed by
RMS-STAGE-CERTIFICATE, not an environment supplying correct numerical data.
All physical admission, owner, row and stage-entry/domain facts are native.
"""
from common import HERE,bv,both,eq,save_plan
from parent_flow import TOP,S,d
from rms_capture import r
from rms_arguments import definitions as argument_definitions
from rms_numeric_store import definitions as numeric_definitions
from rms_raw_capture import merge
from prepare_context import prepare


def payload():
    result=both([eq(r('result_mantissa_o'),'(na-mantissa na)'),eq(r('result_exponent_o'),'(na-candidate na)'),
        eq(r('result_row_index_o'),'((_ extract 7 0) (na-scan na))'),f'(bvult (na-scan na) {bv(256,10)})'])
    return f'(=> {r("result_valid_o")} {result})'


def specification():
    defs=merge([argument_definitions()[0],numeric_definitions(2)[0]])
    H=f'(|{TOP}_h| a)'
    decl=[f'(declare-const a {S})','(declare-const rs RMSSnapshot)','(declare-const ch History)',
        '(declare-const v RMSStore)','(declare-const na NormAlgorithm)','(declare-const watch (_ BitVec 8))']
    current=[H,'(flow-inv a)','(kind-inv a)','(rs-inv a rs)','(rc-inv a rs watch)',
        '(ra-inv a rs)','(rms-u-inv a)','(rms-h-inv a ch)','(rv-inv a rs ch v)']
    scope=both(['(flow-healthy a)','(not (failed a))',eq(d('engine_state_q'),bv(1,4)),eq(r('state_q'),bv(14,5))])
    domain=both(['(rs-live rs)',f'(bvult (rs-layer rs) {bv(6,3)})',
        f'(or (= (rs-stage rs) {bv(0,5)}) (= (rs-stage rs) {bv(10,5)}))',
        f'(bvsge (rs-exponent rs) {bv(-32,8)})',f'(bvsle (rs-exponent rs) {bv(31,8)})',
        f'(distinct (select (rs-vector rs) watch) {bv(-32768,16)})'])
    rules={
        'actual-write-has-live-RMS-scope':dict(assumptions=current+[d('rms_ram_write_enable')],conclusion=scope),
        'actual-write-has-fixed-entry-domain':dict(assumptions=current+[d('rms_ram_write_enable')],conclusion=domain),
        'actual-write-source-index-is-bounded':dict(assumptions=current+[d('rms_ram_write_enable')],
            conclusion=f'(bvult {d("output_index_q")} {bv(256,10)})'),
        'actual-write-discharge-numerical-producer':dict(assumptions=current+[payload()],conclusion='(rr-producer a rs na watch)'),
    }
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('rms-numeric-producer',*specification(),native_label='context')
    print('Prepared actual source/entry/numerical-endpoint closure of the retained reference producer.')

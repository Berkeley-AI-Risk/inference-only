"""Explicit integer interpretation of the independently defined RMS profile.

Raw engine providers prove integer algebra/ranges and the mean. Exact native
word equations are separate source producer theorems. Standard typed word
semantic unfolding, finite induction and constant evaluation are stated trusted
inference rules; this file never invents a whole-algorithm UNSAT receipt.
"""
import json
from common import HERE,bv,both,eq,ext,sha,atomic_json
from verify_gate import check_component
from verify_helpers import verify_original_types
from rms_word_arithmetic import specification as primitive_spec,Z,U
from rms_square_certificate import construction,definitions as certificate_definitions
from rms_scalar_words import definitions as scalar_definitions
from rms_reference import coefficients,image,MULTIPLIERS
from prepare import ROM
from rms_native_history import parse,emit,atoms

THEORY='https://smt-lib.org/theories-FixedSizeBitVectors.shtml'


def product_derivation(name,a,b,aw,bw,out,unsigned_b=False):
    aext=ext(a,out-aw,True);bext=ext(b,out-bw,not unsigned_b)
    word=f'(bvmul {aext} {bext})'
    mathematical=f'(* {Z(a,aw)} '+(U(b) if unsigned_b else Z(b,bw))+')'
    expected=eq(Z(word,out),mathematical)
    rule=primitive_spec(2)[2][name]
    if rule['assumptions'] or parse(rule['conclusion'])!=parse(expected):
        raise ValueError('Typed product target changed')
    required=[f'sign-extend-{aw}-to-{out}',f'product-factor-{out}',f'remove-multiple-{out}',f'signed-residue-{out}']
    if not unsigned_b:required.append(f'sign-extend-{bw}-to-{out}')
    required.append({'signed16-square-is-exact-signed32':'signed16-square-fits32',
        'signed16-by-signed10-is-exact-signed26':'signed16-signed10-fits26',
        'signed26-by-unsigned16-is-exact-signed45':'signed26-unsigned16-fits45'}[name])
    return dict(target=rule,typing=dict(a=aw,b=bw,result=out,a_signed=True,b_signed=not unsigned_b),
        exact_operand_extensions=[aext,bext],integer_product=mathematical,
        standard_unfolding=[
            'U_out(bvmul(Aext,Bext))=(U_out(Aext)*U_out(Bext)) mod 2^out',
            'U_out(sign_extend(a))=Z_aw(a)+2^out*k for its exact sign indicator k; zero extension preserves unsigned value',
            'Apply the proved product factorization and whole-multiple removal with these signed representatives',
            'Z_out(result)=signed_residue_out(Z_aw(a)*Z_or_U_bw(b))',
            'Apply the proved full-type product bound and signed-residue no-wrap theorem'],
        providers=list(dict.fromkeys(required)),premise_discharge='Exact declared word-type ranges and standard extraction/sign-extension meanings; no hardware value assumption',
        raw_mixed_BV_integer_UNSAT_receipt=False)


def fixed_model():
    raw=image();words=[int(line.split('//',1)[0].strip(),16) for line in (HERE/'rms-local'/ROM).read_text().splitlines() if line.split('//',1)[0].strip()]
    checked=[]
    for role in range(13):
        for row,(c,m,e) in enumerate(coefficients(raw,role)):
            packed=(c&1023)|(m<<10)|((e&255)<<26)
            if words[role*256+row]!=packed:raise ValueError('Actual model ROM differs from independent image decoder')
            if not -511<=c<=511 or m!=MULTIPLIERS[role] or not 0<m<32768 or e!=(-8 if role<12 else -7):
                raise ValueError('Fixed RMS metadata outside the proved integer domain')
            checked.append(dict(role=role,row=row,coefficient=c,multiplier=m,tensor_exponent=e,source_exponent=e-27))
    return dict(model_sha256=sha(raw),ROM_sha256=sha((HERE/'rms-local'/ROM).read_bytes()),consumed_entries=checked,
        used_addresses=list(range(3328)),unused_extension_irrelevant=True,
        binding='Native immutable ROM initial predicate plus exact source/ROM identity and independently decoded fixed model bytes; carried by model-ROM-extension-held.')


def independent_programs():
    from rms_raw_capture import definitions as record_definitions
    from normalizer_instance import definitions as normalizer_definitions
    texts=record_definitions()[0]+'\n'+normalizer_definitions()
    all_defs={x[1]:x for x in parse(texts) if x[0]=='define-fun'}
    reports={}
    for root in ['RMS-record','na-step']:
        def references(node,bound):
            if not isinstance(node,list):
                return {node} if node in all_defs and not all_defs[node][2] and node not in bound else set()
            if not node:return set()
            if node[0]=='let':
                result=set().union(*(references(x[1],bound) for x in node[1]))
                return result|references(node[2],bound|{x[0] for x in node[1]})
            if isinstance(node[0],str) and node[0] in ['forall','exists','lambda']:
                return references(node[2],bound|{x[0] for x in node[1]})
            result={node[0]} if isinstance(node[0],str) and node[0] in all_defs and node[0] not in bound else set()
            for x in node:result|=references(x,bound)
            return result
        selected={root}
        while True:
            more=set().union(*(references(all_defs[name][4],{x[0] for x in all_defs[name][2]}) for name in selected))
            if more<=selected:break
            selected|=more
        bodies=[all_defs[name] for name in sorted(selected)]
        tokens=set(atoms(bodies))
        if any('_n ' in token or '_m ' in token or token.endswith('_s|') for token in tokens):
            raise ValueError('Reference numeric program reads actual native state')
        reports[root]=dict(functions=sorted(selected),definition_sha256=sha(('\n'.join(emit(x) for x in bodies)+'\n').encode()),
            no_native_register_memory_helper_reply_or_candidate_input=True,
            inputs=all_defs[root][2])
    record=all_defs['RMS-record']
    if [x[0] for x in record[2]]!=['h','c','model','row']:
        raise ValueError('Independent RMS record interface changed')
    forbidden={'h-ordinal','h-active','h-captured'}
    if set(atoms([all_defs[x] for x in reports['RMS-record']['functions']]))&forbidden:
        raise ValueError('RMS numeric function depends on controller/output history')
    return reports


def verify():
    receipts={};plans={}
    for label,module,rev,selected in [('rms-word-semantics','rms_word_semantics',1,None),
        ('integer-algorithms','integer_algorithms',1,None),
        ('rms-word-arithmetic-r2','rms_word_arithmetic',2,['positive-square-sum-mean-is-RNE-div256','signed45-to48-extension-preserves-integer'])]:
        plans[label],rows=check_component(label,module,rev,selected)
        receipts[label]=dict(checked_rules=rows,original_types=verify_original_types(label,plans[label]))
    products=[product_derivation('signed16-square-is-exact-signed32','x','x',16,16,32),
        product_derivation('signed16-by-signed10-is-exact-signed26','x','c',16,10,26),
        product_derivation('signed26-by-unsigned16-is-exact-signed45','p','m',26,16,45,True)]
    for item in products:
        if not set(item['providers'])<=set(plans['rms-word-semantics']['rules']):raise ValueError('Unproved integer provider')
    certificate=construction()
    if (HERE/'rms-square-certificate.smt2').read_text()!=certificate_definitions():raise ValueError('Changed square certificate')
    model=fixed_model()
    # Exact independent profile definitions are the ones already used by the
    # native scalar bindings and RMS-record. Integer interpretation is tied to
    # their syntax, not to an unused reference routine.
    expected=scalar_definitions()
    if not (HERE/'rms-scalar-words/algorithm.smt2').read_text()==expected:raise ValueError('Changed scalar profile')
    defs={x[1]:x for x in parse(expected)}
    for width,name in [(64,'rms-mean'),(45,'rms-epsilon'),(46,'rms-radicand-wide'),(45,'rms-radicand'),
        (64,'rms-numerator'),(16,'rms-clamp'),(50,'rms-scaled')]:
        if defs[name][3]!=['_','BitVec',str(width)]:raise ValueError('Changed scalar profile type')
    epsilon_cases=[]
    for e in range(-32,32):
        h=-20-2*e;epsilon=(1<<h) if h>=0 else 0
        if h<0 and h>-2:raise ValueError('Unexpected epsilon rounding case')
        if not 0<=epsilon<=1<<44:raise ValueError('Epsilon exceeds bound')
        epsilon_cases.append(dict(exponent=e,shift=h,epsilon=epsilon,
            integer_rule='Exact integer power' if h>=0 else 'RNE(1/2^(-h))=0 since -h>=2; out-of-range shift also returns zero'))
    return dict(schema='Independent-RMS-profile-integer-meaning-v1',checked=True,
        word_theory=THEORY,typed_products=products,integer_square_fold=certificate,independent_numeric_programs=independent_programs(),
        mean='RNE(sum A_i^2 / 256); exact mean word theorem under the legal prefix bound',
        epsilon_cases=epsilon_cases,radicand='X=max(1,mean+epsilon), with 1<=X<2^45 by the reconstructed integer bound',
        helper_meaning_required='HELPER-MEANING-RESULT.json must be reconstructed, not trusted as a status flag',
        numerator='Standard bvshl64 means multiplication by 4096 modulo 2^64; the proved legal signed16 numerator bound removes wrap.',
        clamp='Exact signed64 comparisons select -32767, 32767 or the unchanged value; low16 extraction preserves each selected bounded signed integer.',
        scaled='Two exact typed products followed by sign extension; fixed coefficient/multiplier bounds prove abs(B)<2^39.',
        exponent='Every consumed fixed ROM tensor exponent is -8 or -7; subtracting 27 yields -35 or -34 and fits signed8 exactly.',
        fixed_model=model,receipts=receipts,
        inference_rules=['Standard typed SMT-LIB word semantic unfolding','Finite induction with exact checked prefix recurrences','Exact constant arithmetic evaluation and typed theorem specialization'],
        raw_whole_RMS_UNSAT_receipt=False,full_RMS_algorithm_proved=False,connected_segment_qualified=False,whole_machine_theorem=False)


if __name__=='__main__':
    result=verify();atomic_json(HERE/'RMS-PROFILE-INTEGER-MEANING.json',result)
    print('Reconstructed integer providers, exact typed products, all square-prefix steps and all 3328 fixed model entries; final RMS trace/normalizer theorem remains separate.')

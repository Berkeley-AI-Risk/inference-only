"""Exact accepted-input specialization of the qualified Q operator theorem.

Composition is at real descriptor/capture events, not post-DONE QInput state.
The old theorem supplies persistent QA ownership and downstream computation.
Only BV10 coordinates 0..255 are substituted from the BV8 RMS reference.
"""
import sys,json
from common import HERE,PILOT,sha,bv,atomic_json
from verify_gate import check_component
from rms_native_history import parse,emit,atoms
from q_source_specialization import verify as source_verify
sys.path.insert(0,str(PILOT/'q-operator'))
from q_columns import TOP as OLD,J
from q_model import definitions as model_definitions
from q_arguments_r3 import specification as argument_spec
from derivation import apply as apply_literal,canonical as literal_canonical


def accepted_fold(plan):
    """Apply every finite prefix step, with one rigid arbitrary watched row.

    table_k is a definitional name for the actual admission table after k
    accepted stores. The checked source recurrence below justifies that view;
    stalls leave k/table unchanged, and revocation discards the entire frame.
    """
    from derivation import replace
    rules=plan['rules'];base=apply_literal(rules['empty-prefix-allows-arbitrary-old-RAM'],
        {'k':bv(0,9),'table':'table_0'},['true'])
    prefix=base['conclusion'];steps=[]
    for k in range(256):
        names={'k':bv(k,9),'table':'table_'+str(k),
            'word':'(select vector '+bv(k,8)+')'}
        step=apply_literal(rules['one-accepted-word-preserves-prefix'],names,[prefix])
        store=['store','table_'+str(k),parse(bv(k,10))[0],parse(names['word'])[0]]
        def fold(node):
            if node==store:return 'table_'+str(k+1)
            return [fold(x) for x in node] if isinstance(node,list) else node
        prefix=literal_canonical(emit(fold(parse(step['conclusion'])[0])))
        step['definitional_table_update']='(= table_'+str(k+1)+' '+emit(store)+')'
        step['folded_conclusion']=prefix;steps.append(step)
    complete=apply_literal(rules['complete-used-domain-is-exact-reference'],
        {'k':bv(256,9),'table':'table_256'},[prefix])
    stall=apply_literal(rules['stalls-do-not-change-prefix'],{},[rules['stalls-do-not-change-prefix']['assumptions'][0]])
    return dict(base=base,accepted_steps=steps,complete=complete,stall_schema=stall,
        row='One rigid arbitrary BV8 watch for all 256 steps',
        actual_trace_specialization=dict(table_0='j-memory at the same valid descriptor edge, unconstrained before new stores',
            table_k='actual accepted JobHistory memory after exactly k current LOAD writes',
            k='zero-extended qi-count before each accepted write; native activation_count_q is its BV10 extension',
            word='actual activation_i, equal to the admission-fixed reference at low8(k) by the checked source adapter',
            snapshot='Exact qa-next completion/ownership guard copies table_256; child DONE never substitutes a zeroed QInput',
            partial_frame='Actual reset/CLEAR/failure/new-start priorities discard its certificate before another frame; no completion is assumed'))


def adapter_applications(plan):
    from verify_gate import FAMILIES
    from parent_flow import TOP
    from rms_q_argument import j,d,both,eq
    from q_input_capture import definitions as qi_definitions
    current=[f'(|{TOP}_h| a)',f'(|{TOP}_i| a)',
        *[x[3] for x in FAMILIES if x[3]],'(rr-inv a rs v rr watch)']
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    facts=current+[qmode];applications={}
    from derivation import conjuncts
    have={x for f in facts for x in conjuncts(f)}
    for name,rule in plan['rules'].items():
        guards=[x for x in rule['assumptions'] if not set(conjuncts(x))<=have]
        # Each adapter has only its named real observation event left open.
        # Any new invariant/provider is a composition failure, not a guard.
        allowed=[j('activation_store_write'),j('start_transfer'),both([j('start_transfer'),j('incoming_descriptor_valid')])]
        if any(x not in allowed for x in guards):raise ValueError('Unclosed Q input adapter provider '+str(guards))
        applications[name]=dict(observation_guards=guards,application=apply_literal(rule,{},facts+guards))
    # Exact QInput recurrence: admission fixes ALL fields, ordinary steps hold
    # the vector/owner/exponent and only count actual writes. This is the
    # input-only frame used for the finite fold, not a post-DONE invariant.
    qi=next(x for x in parse(qi_definitions(3)[0]) if x[:2]==['define-fun','qi-next'])
    branch=qi[4]
    if branch[0]!='ite' or branch[2]!='qi-zero' or branch[3][0]!='ite':raise ValueError('Changed QInput revoke/start priority')
    ordinary=branch[3][3]
    fields=['live','generation','layer','exponent','vector']
    if ordinary[0]!='q-input' or ordinary[1:6]!=[['qi-'+x,'q'] for x in fields]:raise ValueError('QInput admission reference is not held')
    expected=parse('(bvadd (qi-count q) (ite (and (qi-live q) '+j('activation_store_write')+') '+bv(1,9)+' '+bv(0,9)+'))')[0]
    if ordinary[6]!=expected:raise ValueError('QInput count does not count exactly actual accepted writes')
    return dict(current_joint_invariants=current,qmode_observation=qmode,applications=applications,
        admission_reference_hold=emit(ordinary),reset_or_cancel_discards_frame=emit(branch[1]),
        all_conditional_adapter_premises_closed=True)


def walk(x):
    yield x
    if isinstance(x,list):
        for y in x:yield from walk(y)


def reference_fold():
    nodes=parse(model_definitions());defs={x[1]:x for x in nodes}
    p=defs['Q-prefix']
    previous=f'(bvsub count {bv(1,10)})'
    expected=f'(ite (= count {bv(0,10)}) 0 (+ (Q-prefix vector model layer group row {previous}) (Q-product vector model layer group row {previous})))'
    if p[0]!='define-fun-rec' or p[4]!=parse(expected)[0]:raise ValueError('Changed Q finite mathematical prefix')
    product=defs['Q-product']
    reads=[x for x in walk(product[4]) if isinstance(x,list) and len(x)==3 and x[:2]==['select','vector']]
    if not reads or any(x!=['select','vector','column'] for x in reads):raise ValueError('Q product has another input-vector read')
    steps=[dict(count=k,previous=k-1,index_word=bv(k-1,10),in_used_domain=0<=k-1<256,
        rule='Equal used input word gives equal signed product with the same fixed coefficient; equal prior sums give equal next sums.') for k in range(1,257)]
    return dict(checked_definition_sha256=sha(model_definitions().encode()),base='Q-prefix(count=0)=0',
        finite_congruence_steps=steps,terminal_count=bv(256,10),
        vector_representation='RMS BV8-indexed vector mapped only at zero-extended BV10 coordinates 0..255; no whole-array equality over unused addresses.',
        trusted_rule='Ordinary finite induction and typed equality congruence on the exact independently defined Q reference functions.')


def source_histories():
    text=(PILOT/'model-consumption/parentcapture/history.smt2').read_text()
    d={x[1]:x for x in parse(text) if x[0]=='define-fun'}
    n=lambda field:['|'+OLD+'_n '+J+field+'|','a']
    memory=['j-memory','h'];position=['j-pos','h']
    job=d['job-next'];body=job[4]
    if body[0]!='ite' or body[1]!=['not',n('reset_n')] or body[2]!=['job-zero','a'] or body[3][0]!='job-history':
        raise ValueError('Changed qualified job reset/constructor')
    fields=body[3][1:]
    expected=['ite',n('activation_store_write'),['store',memory,position,n('activation_i')],memory]
    if fields[0]!=expected:raise ValueError('Qualified capture fold does not record exact native write/address/data')
    start=['and',n('start_transfer'),n('incoming_descriptor_valid')]
    if fields[2]!=['ite',start,n('incoming_columns'),['j-cols','h']]:raise ValueError('Changed accepted shape snapshot')
    done=['and',n('done_valid_o'),n('done_ready_i')]
    revoke=['or',n('clear_i'),n('integrated_fail'),done]
    reset=['or',revoke,start]
    one=parse(bv(1,10))[0];zero_word=parse(bv(0,10))[0]
    last=['=',position,['bvsub',['j-cols','h'],one]]
    expected_pos=['ite',reset,zero_word,['ite',n('activation_store_write'),
        ['ite',last,zero_word,['bvadd',position,one]],position]]
    expected_complete=['ite',reset,'false',['or',['j-complete','h'],['and',n('activation_store_write'),last]]]
    if fields[1]!=expected_pos or fields[4]!=expected_complete:
        raise ValueError('Changed accepted-prefix counter/completion/reset recurrence')
    zero=d['job-zero'][4]
    if zero[0]!='job-history' or zero[1]!=['|'+OLD+'_m '+J+'activation_memory_q|','a']:
        raise ValueError('Retained RAM prefix zero is not arbitrary actual RAM')
    capture=d['capture-next'][4]
    if capture[0]!='ite' or capture[3][1]!=['job-next','a',['c-base','h']]:raise ValueError('Capture history uses another job fold')
    # Check exact QA priority and late snapshot: reset/CLEAR/new stage wins,
    # a new actual Q start creates incomplete authority, then the complete
    # current accepted-input memory is copied once. Child DONE is not a revoke.
    args=argument_spec()[1];qa={x[1]:x for x in parse(args) if x[0]=='define-fun'}
    q=qa['qa-next'][4]
    if q[0]!='ite' or q[2]!='qa-zero' or q[3][0]!='ite':raise ValueError('Changed QA reset/start priority')
    fresh=q[3][2];held=q[3][3]
    if fresh[0]!='q-arguments' or fresh[2:4]!=['true','false']:raise ValueError('Fresh QA has completed authority')
    if fresh[4]!=['ql-epoch','life'] or fresh[5]!=n('fixed_layer_i') or fresh[6]!=n('activation_exponent_i'):
        raise ValueError('QA descriptor epoch/layer/exponent sample changed')
    if q[3][1]!=['and',['qn-Q-mode','a'],['ql-P-start','a']]:raise ValueError('QA samples a different invocation admission')
    if held[0]!='q-arguments' or held[1][0]!='ite' or held[1][2]!=['j-memory',['c-base','ch']] or held[1][3]!=['qa-vector','h']:
        raise ValueError('QA copies another vector or changes a completed snapshot')
    guard=held[1][1]
    required=[['qa-owned','h'],['not',['qa-complete','h']],['qn-Q-mode','a'],['ql-p-owned','life'],
        ['not',n('integrated_fail')],['j-complete',['c-base','ch']]]
    if guard!=['and',*required]:raise ValueError('QA completion/ownership guard changed')
    revoke_tokens=set(atoms(q[1]))
    if '|'+OLD+'_n u_native.u_six_layers.u_datapath.rst_n|' not in revoke_tokens:raise ValueError('Missing QA actual reset revocation')
    for field in ['clear_i','stage_accept','head_start_accept']:
        if '|'+OLD+'_n u_native.u_six_layers.u_datapath.'+field+'|' not in revoke_tokens:raise ValueError('Missing QA revocation '+field)
    if held[2]!=['qa-owned','h'] or held[4:]!=[['qa-epoch','h'],['qa-layer','h'],['qa-exponent','h']]:raise ValueError('Completed QA metadata is not held')
    if held[3]!=['or',['qa-complete','h'],guard]:raise ValueError('QA completion authority does not persist exactly')
    if any('done_valid_o' in token for token in revoke_tokens):raise ValueError('QA no longer persists through child DONE')
    return dict(accepted_memory_update=emit(fields[0]),accepted_columns_update=emit(fields[2]),
        counter_update=emit(fields[1]),completion_update=emit(fields[4]),
        actual_capture_wrapper=emit(capture[:3]),
        qa_fresh=emit(fresh),qa_snapshot_guard=emit(guard),qa_snapshot=emit(held[1]),qa_revoke=emit(q[1]),
        original_source_functions_sha256=sha(text.encode()),qa_source_functions_sha256=sha(args.encode()),
        no_clean_retained_RAM_assumption=True,completion_snapshot_after_last_capture=True,exact_counter_and_completion_recurrence_checked=True,
        input_data_ports='Actual native activation_store_write, activation_i and ordered j-pos; source Q adapter proves their admission-fixed RMS values.',
        invocation_ticket='The same actual Q descriptor edge; qualified Q lifecycle epoch and RMS generation are recorded by that edge, not equated numerically.',
        post_DONE_use='Qualified QA persistence and Q endpoint theorem; never substitute a zeroed post-DONE QInput.')


def verify():
    receipts={}
    plans={}
    for label,module,rev in [('accepted-input-fold','accepted_input_fold',1),('rms-q-argument-r4','rms_q_argument',4)]:
        plan,rows=check_component(label,module,rev);receipts[label]=rows
        plans[label]=plan
    source=source_verify();histories=source_histories();reference=reference_fold()
    return dict(schema='RMS-normalized-to-qualified-Q-accepted-interface-v1',input_interface_substitution_checked=True,
        actual_Q_source_specialization=source,accepted_history=histories,used_domain_reference_substitution=reference,
        engine_receipts=receipts,
        checked_native_adapter_applications=adapter_applications(plans['rms-q-argument-r4']),
        checked_accepted_fold_derivation=accepted_fold(plans['accepted-input-fold']),
        proof_rule='At each real valid Q descriptor admission fix the complete RMS numerical reference and exponent. The source adapter fixes that vector in QInput; each native accepted write has its ordered reference word. Apply the checked arbitrary-RAM prefix base and 256 accepted-word steps, with stalls. QA copies the resulting complete used-domain table at its exact ownership/completion event, then the qualified Q theorem preserves and consumes that snapshot through projection DONE.',
        reset_fault_rule='Actual reset/revocation priorities and qualified ownership exclude partial/rejected/cancelled captures from completed authority. No future completion is assumed.',
        numerical_Q_definition_reads_only_used_domain=True,unused_BV10_tail_unconstrained=True,
        connected_segment_qualified=False,whole_machine_theorem=False)


if __name__=='__main__':
    result=verify();atomic_json(HERE/'ACCEPTED-Q-INTERFACE.json',result)
    print('Checked exact Q admission/capture/snapshot interface and finite used-domain substitution; no post-DONE QInput hypothesis.')

"""Exact standalone RMS arithmetic context and checked parent-instance mapping.

Arithmetic lemmas need not carry the unrelated 64-lane Q array in their native
transition. The same complete RMS source, memories, production parameters and
real helpers are retained; the caller/RAM gate separately supplies its arguments.
"""
import json
import re
from common import HERE,PILOT,sha,atomic_bytes,atomic_json,compile_native,save_plan
from prepare import SOURCES,ROM,TOP as LOCAL,modules
from source_policy import PUBLIC
from parent_flow import TOP,DP
from prepare_context import prepare as parent_prepare


def prepare():
    d=HERE/'rms-local';d.mkdir(exist_ok=True)
    atomic_bytes(d/ROM,(PUBLIC/ROM).read_bytes())
    manifest=compile_native('rms-local',LOCAL,SOURCES)
    parent=(HERE/'context/rms-segment-native.sv').read_text()
    local=(d/'native.sv').read_text()
    for file,names in SOURCES.items():
        for module in names:
            if modules(parent)[module]!=modules(local)[module]:raise ValueError('Changed actual RMS module '+module)
    return manifest


def to_local(text):
    text=text.replace('|'+TOP+'_s|','|'+LOCAL+'_s|')
    text=re.sub(r'\|'+TOP+r'_(n|m) '+re.escape(DP+'u_rmsnorm.')+r'([^|]+)\|',
        lambda m:'|'+LOCAL+'_'+m[1]+' '+m[2]+'|',text)
    text=text.replace('|'+TOP+'_n '+DP+'rst_n|','|'+LOCAL+'_n rst_n|')
    for suffix in ['h','t','i']:text=text.replace('|'+TOP+'_'+suffix+'|','|'+LOCAL+'_'+suffix+'|')
    if TOP in text:raise ValueError('Arithmetic lemma still refers to an external parent signal')
    return text


def specification(revision=3):
    from rms_read_words import specification as parent_spec
    decl,defs,rules=parent_spec(revision)
    translated={name:{**rule,'assumptions':[to_local(x) for x in rule['assumptions']],
        'conclusion':to_local(rule['conclusion'])} for name,rule in rules.items()}
    return [to_local(x) for x in decl],to_local(defs),translated


def instance_binding():
    manifest=prepare()
    local=(HERE/'rms-local/native.smt2').read_text();parent=(HERE/'context/native.smt2').read_text()
    defs=specification()[1]
    fields=sorted(set(re.findall(r'\|'+LOCAL+r'_(n|m) ([^|]+)\|',defs)))
    from pruned_arithmetic import parse
    local_defs={x[1]:x for x in parse(local) if x[0]=='define-fun'}
    parent_defs={x[1]:x for x in parse(parent) if x[0]=='define-fun'}
    getters=[]
    for kind,field in fields:
        left=f'(define-fun |{LOCAL}_{kind} {field}| ((state |{LOCAL}_s|)) '
        right=f'(define-fun |{TOP}_{kind} {DP}u_rmsnorm.{field}| ((state |{TOP}_s|)) '
        if local.count(left)!=1 or parent.count(right)!=1:raise ValueError('Missing actual RMS getter '+field)
        # First complete sort after the binder; arrays may contain spaces.
        l=local_defs['|'+LOCAL+'_'+kind+' '+field+'|']
        r=parent_defs['|'+TOP+'_'+kind+' '+DP+'u_rmsnorm.'+field+'|']
        if l[3]!=r[3]:raise ValueError('Actual RMS getter type changed')
        getters.append(dict(local=field,kind=kind,sort=l[3]))
    return dict(schema='Exact-whole-RMS-source-instance-v1',local_model='rms-local/native.smt2',
        local_model_sha256=sha(local.encode()),actual_context_sha256=sha(parent.encode()),
        identical_native_module_bodies=True,actual_prefix=DP+'u_rmsnorm.',getters=getters,
        actual_instance=next(row['actual_instance'] for row in json.loads((HERE/'context-SOURCES.json').read_text())['restored_instances'] if row['instance']=='u_rmsnorm'),
        source_rule='Universal identical-source hierarchical module theorem instantiation with actual clock/reset/ports and default production parameters.',
        no_numerical_cut=True,no_reduced_geometry=True,no_desired_reply=True,
        trusted_boundary='Native frontend and standard identical-source hierarchical instantiation')


def to_parent(text):
    """Instantiate a positive local native premise at the actual source module.

    This is a source-module theorem specialization, not SMT state-sort equality.
    Complete body/port/type checks are performed by complete_instance_binding.
    """
    from parent_flow import S
    text=text.replace('|'+LOCAL+'_s|',S)
    text=re.sub(r'\|'+LOCAL+r'_(n|m) ([^|]+)\|',
        lambda m:'|'+TOP+'_'+m[1]+' '+DP+'u_rmsnorm.'+m[2]+'|',text)
    text=text.replace('|'+TOP+'_n '+DP+'u_rmsnorm.rst_n|','|'+TOP+'_n '+DP+'rst_n|')
    for suffix in ['h','t','i']:text=text.replace('|'+LOCAL+'_'+suffix+'|','|'+TOP+'_'+suffix+'|')
    if LOCAL in text:raise ValueError('Unmapped exact RMS source symbol')
    return text


def complete_instance_binding():
    from rms_square_fold import specification as square
    from rms_scalar_words import specification as scalar_words
    from rms_scalar_algorithm import specification as scalar,helper_provider_specification
    from rms_raw_capture import specification as raw_capture
    from rms_endpoints import specification as endpoints
    specs={'rms-local-read-words-r4':specification(4),'rms-square-fold':square(),
        'rms-scalar-words':scalar_words(),'rms-helper-tickets':helper_provider_specification(),
        'rms-scalar-algorithm-r4':scalar(4),'rms-raw-capture':raw_capture(),'rms-endpoints':endpoints()}
    local=(HERE/'rms-local/native.smt2').read_text();parent=(HERE/'context/native.smt2').read_text()
    from pruned_arithmetic import parse,atoms,emit
    ld={x[1]:x for x in parse(local) if x[0]=='define-fun'}
    pd={x[1]:x for x in parse(parent) if x[0]=='define-fun'}
    getters={};interfaces={}
    for label,(declarations,definitions,rules) in specs.items():
        all_text='\n'.join([*declarations,definitions,*[t for rule in rules.values() for t in [*rule['assumptions'],rule['conclusion']]]])
        interfaces[label]=sha(all_text.encode())
        predicates={'|'+LOCAL+'_'+kind+'|' for kind in ['h','t','i']}
        for name,rule in rules.items():
            if set(atoms(parse(rule['conclusion'])))&predicates:
                raise ValueError('Native predicate in imported theorem conclusion: '+label+':'+name)
            for premise in rule['assumptions']:
                node=parse(premise)[0];present=set(atoms([node]))&predicates
                if present and (not isinstance(node,list) or node[0] not in predicates):
                    raise ValueError('Source instantiation needs a positive native antecedent')
        for symbol in set(atoms(parse(all_text))):
            m=re.fullmatch(r'\|'+LOCAL+r'_(n|m) ([^|]+)\|',symbol)
            if not m:continue
            target=to_parent(symbol)
            if symbol not in ld or target not in pd or ld[symbol][3]!=pd[target][3]:
                raise ValueError('Missing or mistyped complete theorem getter '+symbol)
            getters[symbol]=dict(actual=target,sort=ld[symbol][3])
    record=instance_binding()
    record['schema']='Complete-RMS-theorem-actual-source-instance-v1'
    record['interfaces']=interfaces;record['getters_from_complete_imported_interfaces']=getters
    record['includes_rules_premises_conclusions_declarations_definitions']=True
    record['native_predicate_rule']='Only positive hierarchy/transition antecedents are strengthened to full actual parent predicates; conclusions contain no foreign native predicate.'
    return record


if __name__=='__main__':
    import sys
    revision=4 if '--revision-4' in sys.argv else 3
    parent_prepare();prepare()
    atomic_json(HERE/'RMS-LOCAL-INSTANCE.json',instance_binding())
    save_plan('rms-local-read-words'+('-r4' if revision==4 else ''),*specification(revision),native_label='rms-local')
    print('Prepared exact complete RMS component arithmetic context and actual source-instance binding.')

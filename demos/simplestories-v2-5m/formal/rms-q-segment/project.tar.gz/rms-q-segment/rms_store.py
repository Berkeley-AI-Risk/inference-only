"""Actual RMS write prefix, retained RAM and authority for the following Q.

The stored vector observes actual writes only. It supplies no data to the DUT
and no desired value hypothesis. The RMS component history supplies separately
proved result ordering; independent numerical meaning remains a later join.
"""
from common import bv,both,eq,ext,save_plan
from parent_flow import S,TOP,DP,n,d,definitions as flow_definitions
from rms_snapshot import definitions as snapshot_definitions,ARRAY
from rms_native_history import definitions as native_definitions
from rms_capture import r
from prepare_context import prepare

memory=lambda a='a':f'(|{TOP}_m {DP}u_rms_scratch.payload_mem| {a})'


def definitions(revision=1):
    defs,_=snapshot_definitions()
    local,_=native_definitions();defs+=local
    fields=[('live','Bool'),('generation','Int'),('layer','(_ BitVec 3)'),
            ('stage','(_ BitVec 5)'),('count','(_ BitVec 9)'),
            ('vector',ARRAY),('exponent','(_ BitVec 8)')]
    defs+='(declare-datatypes () ((RMSStore (rms-store '+' '.join('(rv-'+f+' '+t+')' for f,t in fields)+'))))\n'
    defs+=f'(define-fun rv-base ((a {S})) RMSStore (rms-store false 0 {bv(0,3)} {bv(0,5)} {bv(0,9)} {memory()} {bv(0,8)}))\n'
    values=['(rv-'+f+' v)' for f,t in fields]
    values[4]=f'(bvadd (rv-count v) (ite {d("rms_ram_write_enable")} {bv(1,9)} {bv(0,9)}))'
    values[5]=f'(ite {d("rms_ram_write_enable")} (store (rv-vector v) ((_ extract 7 0) {d("output_index_q")}) {d("rms_result_mantissa")}) (rv-vector v))'
    values[6]=f'(ite {d("rms_ram_write_enable")} {d("rms_result_exponent")} (rv-exponent v))'
    fresh=['true','(+ (rs-generation rs) 1)',d('private_layer_i'),d('private_stage_i'),bv(0,9),'(rv-vector v)','(rv-exponent v)']
    clear=['false','(rv-generation v)','(rv-layer v)','(rv-stage v)',bv(0,9),'(rv-vector v)','(rv-exponent v)']
    args=f'((a {S}) (an {S}) (rs RMSSnapshot) (v RMSStore))'
    defs+=f'(define-fun rv-next {args} RMSStore (ite (not {d("rst_n")}) (rv-base an) (ite {d("clear_i")} (rms-store '+' '.join(clear)+') (ite (rs-accept a) (rms-store '+' '.join(fresh)+') (rms-store '+' '.join(values)+')))))\n'
    mode=eq(d('engine_state_q'),bv(1,4))
    healthy=both(['(flow-healthy a)',f'(not (failed a))'])
    owned=both([healthy,mode])
    active='(or '+' '.join(eq(d('engine_state_q'),bv(k,4)) for k in range(1,8))+')'
    qready=both(['(flow-healthy a)',f'(bvuge {d("expected_stage_q")} {bv(1,5)})',f'(bvule {d("expected_stage_q")} {bv(9,5)})'])
    clauses=[
        eq(memory(),'(rv-vector v)'),
        f'(bvule (rv-count v) {bv(256,9)})',
        f'(=> (and (flow-healthy a) {active}) '+both([eq(d('expected_stage_q'),d('current_stage_q')),eq(d('expected_layer_q'),d('current_layer_q'))])+')',
        f'(=> (and (flow-healthy a) {mode}) '+both(['(rv-live v)',eq('(rv-generation v)','(rs-generation rs)'),eq('(rv-layer v)',d('current_layer_q')),eq('(rv-stage v)',d('current_stage_q'))])+')',
        f'(=> {owned} {eq("(rv-count v)","(h-ordinal ch)")})',
        f'(=> {owned} '+both([f'(bvule {d("output_index_q")} {bv(255,10)})',eq('(rv-count v)',f'(ite {d("output_done_q")} {bv(256,9)} ((_ extract 8 0) {d("output_index_q")}))')])+')',
        f'(=> (and {owned} (bvugt (rv-count v) {bv(0,9)})) {eq("(rv-exponent v)",d("rms_exponent_q"))})',
        f'(=> {qready} '+both(['(rv-live v)',eq('(rv-count v)',bv(256,9)),eq('(rv-stage v)',bv(0,5)),
            eq('(rv-layer v)',d('expected_layer_q')),eq('(rv-generation v)','(rs-generation rs)'),eq('(rv-exponent v)',d('rms_exponent_q'))])+')',
    ]
    if revision>=3:
        # Actual RMS DONE follows the entire emitted prefix, so the parent
        # leaves E_RMS on its first DONE handshake. A stale done-seen flag
        # cannot stand in for a completion belonging to this stage.
        clauses.append(f'(=> (and (flow-healthy a) {mode}) (not {d("service_done_seen_q")}))')
    args=f'((a {S}) (rs RMSSnapshot) (ch History) (v RMSStore))'
    for i,c in enumerate(clauses):defs+=f'(define-fun rv-clause-{i} {args} Bool (=> {d("rst_n")} {c}))\n'
    defs+=f'(define-fun rv-inv {args} Bool '+both([f'(rv-clause-{i} a rs ch v)' for i in range(len(clauses))])+')\n'
    if revision>=2:
        from rms_capture import definitions as capture_definitions
        prefix,_=snapshot_definitions()
        capture,_=capture_definitions()
        if not capture.startswith(prefix):raise ValueError('Changed source capture definitions')
        defs+=capture[len(prefix):]
    if revision>=4:
        from parent_kinds import kind_definitions
        kinds,_=kind_definitions();defs+=kinds
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision)
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
          '(declare-const rs RMSSnapshot)','(declare-const rsn RMSSnapshot)',
          '(declare-const ch History)','(declare-const chn History)',
          '(declare-const v RMSStore)','(declare-const vn RMSStore)']
    if revision>=2:decl+=['(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    providers=['(flow-inv a)','(flow-inv an)','(rs-inv a rs)','(rs-inv an rsn)',
        '(rms-u-inv a)','(rms-u-inv an)','(rms-h-inv a ch)','(rms-h-inv an chn)',
        '(history-output a ch)',eq('rsn','(rs-next a rs)'),eq('chn','(history-next a an ch)')]
    if revision>=2:providers+=['(rc-inv a rs watch)','(rc-inv an rsn watch)']
    if revision>=4:providers+=['(kind-inv a)','(kind-inv an)']
    step=ctx+providers+['(rv-inv a rs ch v)',eq('vn','(rv-next a an rs v)')]
    parts=[f'(rv-clause-{i} an rsn chn vn)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(rv-inv an rs-zero history-zero (rv-base an))'),
        **{f'preserved-{i}':dict(assumptions=step,conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(rv-inv an rsn chn vn)')}
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    rules['actual-Q-has-complete-current-RMS-store']=dict(assumptions=[H('a'),'(flow-healthy a)',qmode,'(rv-inv a rs ch v)'],
        conclusion=both(['(rv-live v)',eq('(rv-count v)',bv(256,9)),eq('(rv-layer v)',d('current_layer_q')),
            eq('(rv-stage v)',bv(0,5)),eq('(rv-exponent v)',d('rms_exponent_q')),eq(memory(),'(rv-vector v)'),
            eq('(rv-generation v)','(rs-generation rs)')]))
    return decl,defs,rules


if __name__=='__main__':
    import sys
    revision=next((k for k in [4,3,2] if '--revision-'+str(k) in sys.argv),1)
    prepare()
    save_plan('rms-store' if revision==1 else 'rms-store-r'+str(revision),*specification(revision),native_label='context')
    print('Prepared actual RMS store/prefix/exponent authority and following-Q obligations.')

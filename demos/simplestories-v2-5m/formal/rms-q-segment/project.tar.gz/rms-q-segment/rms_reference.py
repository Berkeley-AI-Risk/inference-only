"""Independent integer RMSNorm profile; finite qualification support only.

Expected values depend on the fixed image and accepted arguments, never a DUT
helper, scratch register, ROM output or result. No unbounded claim is made.
"""
import csv
import json
from math import isqrt
from pathlib import Path
from common import HERE, PILOT, sha, atomic_json
import sys
sys.path.insert(0, str(PILOT / 'q-operator'))
from reference import image, normalize, signed

MULTIPLIERS = [18950,17930,18104,18211,18373,18536,18639,
               19036,19944,19662,20229,20732,23930]


def rne(n, d):
    if d <= 0:
        raise ValueError('Positive divisor required')
    q, r = divmod(abs(n), d)
    q += 2*r > d or (2*r == d and q % 2 == 1)
    return -q if n < 0 else q


def scalar_shift(n, k):
    if k > 62 or k < -62:
        return 0
    return rne(n, 1 << k) if k >= 0 else n << -k


def root_digits(x):
    if not 0 <= x < 1 << 45:
        raise ValueError('45-bit radicand required')
    rem = root = 0
    for k in range(23):
        digit = (x >> (44 - 2*k)) & 3
        t, trial = 4*rem + digit, 4*root + 1
        take = t >= trial
        rem, root = t - (trial if take else 0), 2*root + int(take)
    return root


def divider_digits(n, d):
    if not abs(n) < 1 << 28 or not 0 <= d < 1 << 64:
        raise ValueError('Bounded numerator/uint64 divisor required')
    if d == 0:
        return None
    rem = q = 0
    for k in range(28):
        t = 2*rem + ((abs(n) >> (27-k)) & 1)
        take = t >= d
        rem, q = t - (d if take else 0), 2*q + int(take)
    q += 2*rem > d or (2*rem == d and q % 2 == 1)
    return -q if n < 0 else q


def coefficients(raw, role):
    if not 0 <= role <= 12:
        raise ValueError('Invalid norm role')
    base = 6777600 + role*320 if role < 12 else 6856000
    meta = 6855936 + role*4 if role < 12 else 6856320
    exponent = signed(raw[meta], 8)
    multiplier = int.from_bytes(raw[meta+1:meta+3], 'little')
    values = []
    for row in range(256):
        bit = row*10
        at = base + bit//8
        word = int.from_bytes(raw[at:at+2], 'little') >> (bit % 8)
        values.append((signed(word,10),multiplier,exponent))
    return values


def rms(raw, role, vector, exponent):
    if len(vector) != 256 or not -32 <= exponent <= 31:
        return [], dict(success=False, reason='descriptor')
    if any(not -32767 <= a <= 32767 for a in vector):
        return [], dict(success=False, reason='capture')
    total = sum(a*a for a in vector)
    if total >= 1 << 38:
        return [], dict(success=False, reason='square-range')
    mean = scalar_shift(total,8)
    h = -20 - 2*exponent
    epsilon = scalar_shift(1,-h) if h < 0 else ((1 << 45)-1 if h > 44 else 1 << h)
    x = max(1, mean+epsilon)
    if x >= 1 << 45 or mean < 0:
        return [], dict(success=False, reason='radicand')
    divisor = isqrt(x)
    if root_digits(x) != divisor:
        raise ValueError('Digit root differs from independent integer root')
    if divisor == 0:
        return [], dict(success=False, reason='root-zero')
    records = []
    for a,(coefficient,multiplier,tensor_exp) in zip(vector,coefficients(raw,role)):
        if (coefficient == -512 or multiplier != MULTIPLIERS[role]
                or tensor_exp != (-8 if role < 12 else -7)):
            return [], dict(success=False,reason='metadata')
        z = rne(a*4096,divisor)
        if divider_digits(a*4096,divisor) != z:
            raise ValueError('Digit divider differs from independent RNE')
        z = max(-32767,min(32767,z))
        b = z*coefficient*multiplier
        source_exp = tensor_exp-27
        if abs(b) > (1 << 39)-1 or not -128 <= source_exp <= 127:
            return [], dict(success=False,reason='scaled-range')
        records.append((b,source_exp))
    rows,outcome = normalize(records)
    return rows,dict(outcome,square_sum=total,radicand=x,divisor=divisor)


def check_existing():
    raw = image()
    vector = [((i % 23)-11)*733 for i in range(256)]
    checks = []
    for role in range(13):
        expected,outcome = rms(raw,role,vector,-12)
        if not outcome['success'] or len(expected) != 256:
            raise ValueError('Unexpected reference rejection')
        p = PILOT / 'witnesses' / ('native-role'+str(role)) / 'values.csv'
        by_kind = {'reference':[], 'actual':[]}
        for kind,ordinal,word in csv.reader(p.read_text().splitlines()):
            packed = int(word,16)
            row = packed >> 25
            mantissa = signed((packed >> 9) & 65535,16)
            exp = signed((packed >> 1) & 255,8)
            by_kind[kind].append((row,mantissa,exp,packed & 1))
            if int(ordinal) != len(by_kind[kind])-1:
                raise ValueError('Saved transcript ordinal changed')
        if any(rows != expected for rows in by_kind.values()):
            raise ValueError('Independent arithmetic mismatch: role '+str(role))
        checks.append(dict(role=role,rows=256,saved_csv_sha256=sha(p.read_bytes()),
                           expected_sha256=sha(json.dumps(expected).encode()),outcome=outcome))
    result = dict(schema='RMS-independent-integer-finite-comparison-v1',passed=True,
                  roles=13,actual_rows_compared=3328,canonical_rows_compared=3328,
                  model_image_sha256=sha(raw),reference_source_sha256=sha(Path(__file__).read_bytes()),
                  checks=checks,fresh_simulations=False,unbounded_proof=False,
                  connected_segment_proved=False)
    atomic_json(HERE / 'INDEPENDENT-ARITHMETIC-FINITE.json',result)
    print(json.dumps({k:result[k] for k in ['passed','roles','actual_rows_compared','fresh_simulations','unbounded_proof']}))


if __name__=='__main__':
    check_existing()

"""Checked native-to-pure output-frame applications for one RMS prefix."""
from common import HERE,bv,sha
from verify_gate import check_component,FAMILIES
from rms_native_history import parse,emit
from derivation import apply,instantiate,conjuncts,replace,canonical
from normalizer_instance import binding,definitions as normalizer_definitions
from rms_local import to_parent
from parent_flow import TOP,d
from rms_numeric_store import definitions as rr_definitions


def close(arithmetic):
    control,_=check_component('rms-frame-control','rms_frame_control',1)
    admission,_=check_component('rms-frame-admission','rms_frame_admission',1)
    pure,_=check_component('normalizer-frame','normalizer_frame',1)
    if not arithmetic['regular_step_closed'] or not arithmetic['reset_bases_checked']:
        raise ValueError('Output frame needs closed RMS/normalizer trace')
    exact_binding=binding();renaming={'nc':'rnc','na':'rna'}
    current=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',d('rst_n'),
        *[x[3] for x in FAMILIES if x[3]],'(rms-u-inv a)','(rms-h-inv a ch)','(na-inv a rnc rna)']
    current_set={v for x in current for v in conjuncts(x)}
    from rms_frame_control import specification as control_spec
    control_defs={x[1]:x for x in parse(control_spec()[1]) if x[0]=='define-fun'}
    start=emit(replace(control_defs['na-next'][4][4],renaming))
    observed={canonical(x) for x in ['(flow-healthy a)','(not (failed a))',
        '(= '+d('engine_state_q')+' '+bv(1,4)+')','(bvugt (rv-count v) '+bv(0,9)+')',
        '(not '+d('clear_i')+')',d('rst_n','an'),'(failed a)',start]}
    native_applications={}
    for label,plan in [('control',control),('admission',admission)]:
        for name,rule in plan['rules'].items():
            specialized=instantiate(rule,renaming)
            guards=[x for x in specialized['assumptions'] if not set(conjuncts(x))<=current_set]
            # Only actual observation conditions may be discharged. Missing
            # auxiliary histories/providers are not licensed as conditions.
            for guard in guards:
                if canonical(guard) not in observed:
                    raise ValueError('Unclosed frame provider '+guard)
            native_applications[name]=dict(observation_guards=guards,
                application=apply(specialized,{},current+guards))
    defs={x[1]:x for x in parse(to_parent(normalizer_definitions())) if x[0]=='define-fun'}
    nextbody=replace(defs['na-next'][4],{'h':'rna','nc':'rnc'})
    params=['h','vector','rows','start','capture','select','shift','result','done','cancel','interrupt']
    if nextbody[0]!='na-step' or len(nextbody)!=12:raise ValueError('Changed actual pure-program step specialization')
    substitutions=dict(zip(params,[emit(x) for x in nextbody[1:]],strict=True))
    positive=native_applications['positive-owned-prefix-is-one-output-frame']['application']['conclusion']
    phases=parse(positive)[0]
    needed=instantiate(pure['rules']['output-frame-candidate-is-held'],substitutions)['assumptions'][0]
    target=parse(needed)[0]
    if phases[0]!='or' or target[0]!='or' or not set(map(emit,phases[1:]))<=set(map(emit,target[1:])):
        raise ValueError('Native prefix does not imply pure output phase domain')
    no_cancel=native_applications['owned-prefix-without-parent-CLEAR-does-not-cancel-normalizer']['application']['conclusion']
    frame_apps={name:apply(pure['rules'][name],substitutions,[needed,no_cancel])
        for name in ['output-frame-candidate-is-held','output-frame-does-not-reenter-selection']}
    fresh=native_applications['actual-normalizer-start-is-fresh-current-RMS-program']
    frame_apps['fresh-frame-resets-output-count']=apply(pure['rules']['fresh-frame-resets-output-count'],substitutions,
        [fresh['application']['conclusion'],*fresh['observation_guards']])
    # Bind the new program frame to exactly the reset/count branches of RR.
    rr=next(x for x in parse(rr_definitions(2)[0]) if x[:2]==['define-fun','rr-next'])
    body=rr[4]
    if body[0]!='ite' or body[2]!='rr-zero' or body[3][0]!='ite' or body[3][3][0]!='ite':
        raise ValueError('Changed RMS numeric prefix reset/CLEAR/new-admission priority')
    clear=body[3][2];new=body[3][3][2]
    for node in [clear,new]:
        if node[0]!='rms-numeric-store' or node[5]!=parse(bv(0,9))[0]:raise ValueError('New/reset RMS frame does not discard prefix count')
    held=arithmetic['actual_RMS_algorithm_endpoints']['held-RMS-result-is-independent-algorithm']
    # The full, universally watched raw-profile consequence is retained as the
    # numeric input certificate for this one frame; no scalar-only projection.
    required=['RMS-record','(h-vector ch)','(h-exponent ch)','(h-role ch)']
    if 'RMS-record' not in held:raise ValueError('Missing full RMS profile input certificate')
    return dict(schema='RMS-one-normalizer-frame-checked-derivation-v1',
        exact_actual_module_binding=exact_binding,native_applications=native_applications,
        actual_na_next_body=emit(nextbody),pure_step_substitution=substitutions,
        pure_phase_weakening=dict(source=positive,conclusion=needed),pure_frame_applications=frame_apps,
        exact_prefix_restart_branches=dict(common_reset='rr-zero',CLEAR=emit(clear),new_RMS=emit(new)),
        complete_RMS_profile_endpoint=held,
        prefix_trace_induction=dict(base='RR count zero; no claimed retained word',
            first_write='Full RMS profile endpoint fixes this program frame; producer binds pure mantissa/candidate/scan',
            continuation='Positive healthy RMS prefix has only pure phases 4/5/6, no new child start and no cancel without parent CLEAR; apply the checked na-next candidate/phase consequences on every continuation edge',
            cancellation='Actual reset/CLEAR discards count. Remaining child cancel is RMS range fault and is sticky by the checked native transition; the proved RMS write producer requires not failed. It cannot append again before count reset',
            restart='Every actual new child normalizer start has RMS count zero, and every actual new RMS admission explicitly resets RR count',
            input='At actual child start, the checked native admission binds complete h-vector/exponent/role to the current RS stage entry. Full RMS endpoint supplies every captured raw row from that same input; normalizer ownership fixes that capture frame'),
        all_selected_frame_rules_applied=True)

(declare-sort ProofRecord 0)
(declare-fun P (ProofRecord) Bool)

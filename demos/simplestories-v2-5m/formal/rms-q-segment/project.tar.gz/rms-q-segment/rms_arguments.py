"""Bind the established RMS invocation's entire argument to stage entry."""
from common import bv,both,eq,ext,save_plan
from parent_flow import TOP,S,DP,n,d
from rms_store import definitions as store_definitions
from rms_capture import r
from prepare_context import prepare


def definitions():
    defs,_=store_definitions(4)
    active=both([f'(bvuge {r("state_q")} {bv(1,5)})',f'(bvule {r("state_q")} {bv(14,5)})'])
    owned=both(['(flow-healthy a)','(not (failed a))',active])
    role=f'(bvadd (bvmul {ext("(rs-layer rs)",1)} {bv(2,4)}) (ite {eq("(rs-stage rs)",bv(0,5))} {bv(0,4)} {bv(1,4)}))'
    clauses=[
        both([eq(r('layer_q'),'(rs-layer rs)'),eq(r('input_exponent_q'),'(rs-exponent rs)'),eq(r('selector_q'),role)]),
        f'(or {eq("(rs-stage rs)",bv(0,5))} {eq("(rs-stage rs)",bv(10,5))})',
        both([f'(bvult (rs-layer rs) {bv(6,3)})',f'(bvsge (rs-exponent rs) {bv(-32,8)})',f'(bvsle (rs-exponent rs) {bv(31,8)})']),
    ]
    args=f'((a {S}) (rs RMSSnapshot))'
    for i,c in enumerate(clauses):defs+=f'(define-fun ra-clause-{i} {args} Bool (=> {owned} {c}))\n'
    defs+=f'(define-fun ra-inv {args} Bool '+both([f'(ra-clause-{i} a rs)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
        '(declare-const rs RMSSnapshot)','(declare-const rsn RMSSnapshot)',
        '(declare-const ch History)','(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    providers=['(flow-inv a)','(flow-inv an)','(kind-inv a)','(kind-inv an)',
        '(rs-inv a rs)','(rs-inv an rsn)','(rc-inv a rs watch)','(rc-inv an rsn watch)',eq('rsn','(rs-next a rs)')]
    step=ctx+providers+['(ra-inv a rs)']
    parts=[f'(ra-clause-{i} an rsn)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(ra-inv an rs-zero)'),
        **{f'preserved-{i}':dict(assumptions=step,conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(ra-inv an rsn)')}
    current=[H('a'),'(flow-healthy a)','(not (failed a))',
        f'(bvuge {r("state_q")} {bv(2,5)})',f'(bvule {r("state_q")} {bv(14,5)})',
        '(flow-inv a)','(rs-inv a rs)','(rc-inv a rs watch)','(ra-inv a rs)',
        '(rms-u-inv a)','(rms-h-inv a ch)']
    rules['actual-complete-RMS-argument-is-fixed-entry']=dict(assumptions=current,conclusion=both([
        '(rs-live rs)','(h-active ch)',eq('(h-captured ch)',bv(256,9)),
        eq('(h-role ch)',r('selector_q')),eq('(h-exponent ch)','(rs-exponent rs)'),
        eq('(select (h-vector ch) watch)','(select (rs-vector rs) watch)')]))
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('rms-arguments',*specification(),native_label='context')
    print('Prepared complete RMS accepted tuple/entry-vector binding.')

"""Native RMS scalar reads, ROM words and configured multiply word equations."""
import json
import re
from common import HERE,PILOT,bv,both,eq,ext,save_plan
from parent_flow import TOP,S,DP,n,d
from rms_capture import r
from rms_native_history import definitions as history_definitions,OLD
from prepare_context import prepare


def phase(*values):return '(or '+' '.join(eq(r('state_q'),bv(k,5)) for k in values)+')'


def definitions():
    defs,_=history_definitions()
    read=eq(r('vector_read_q'),f'(select (h-vector h) {r("lane_index_q")})')
    product=f'(bvmul {ext(r("rms_normalized_q"),10,True)} {ext(r("rom_coefficient"),16,True)})'
    clauses=[f'(=> {phase(3,9,10,11,12,13)} {read})',
             f'(=> {phase(12,13)} {eq(r("weight_product_q"),product)})']
    args=f'((a {S}) (h History))';live=both([d('rst_n'),'(not (failed a))'])
    for i,c in enumerate(clauses):defs+=f'(define-fun rw-clause-{i} {args} Bool (=> {live} {c}))\n'
    defs+=f'(define-fun rw-inv {args} Bool '+both([f'(rw-clause-{i} a h)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def translate_local(text):
    text=text.replace('|'+OLD+'_s|',S)
    text=re.sub(r'\|'+OLD+r'_(n|m) ([^|]+)\|',lambda m:'|'+TOP+'_'+m[1]+' '+DP+'u_rmsnorm.'+m[2]+'|',text)
    for suffix in ['h','t','i']:text=text.replace('|'+OLD+'_'+suffix+'|','|'+TOP+'_'+suffix+'|')
    if OLD in text:raise ValueError('Unmapped RMS instance symbol')
    return text


def specification(revision=2):
    defs,clauses=definitions();H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h History)','(declare-const hn History)']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    providers=['(rms-u-inv a)','(rms-u-inv an)','(rms-h-inv a h)','(rms-h-inv an hn)',eq('hn','(history-next a an h)')]
    parts=[f'(rw-clause-{i} an hn)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(rw-inv an history-zero)'),
        **{f'preserved-{i}':dict(assumptions=ctx+providers+['(rw-inv a h)'],conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(rw-inv an hn)')}
    if revision>=3:
        # This register/ROM holding law is independent of the vector observer.
        # Prove it under the stronger minimal source context, avoiding an
        # irrelevant quantified accepted-vector RAM relation in this query.
        rules['preserved-1']['assumptions']=ctx+['(rw-clause-1 a h)']
    current=[H('a'),d('rst_n'),'(not (failed a))','(rw-inv a h)']
    arg=f'(select (h-vector h) {r("lane_index_q")})'
    sq=f'(bvmul {ext(arg,16,True)} {ext(arg,16,True)})'
    rules['actual-square-word-product-from-owned-row']=dict(assumptions=current+[phase(3)],
        conclusion=eq(r('dsp_product0'),sq))
    mul=f'(bvmul {ext(r("rms_normalized_q"),10,True)} {ext(r("rom_coefficient"),16,True)})'
    rules['actual-weight-word-product']=dict(assumptions=current+[phase(11)],
        conclusion=eq('((_ extract 25 0) '+r('dsp_product0')+')',mul))
    wide=f'(bvmul {ext(r("weight_product_q"),19,True)} {ext(r("rom_multiplier"),29)})'
    rules['actual-scale-word-product']=dict(assumptions=current+[phase(12)],
        conclusion=eq(r('dsp_wide_product'),ext(wide,3,True)))
    numerator=f'(bvshl {ext(arg,48,True)} {bv(12,64)})'
    rules['actual-divider-argument-from-owned-row']=dict(assumptions=current+[phase(9,10)],
        conclusion=eq(r('div_numerator'),numerator))
    old=json.loads((PILOT/'PROOF-PLAN.json').read_text())['nodes']['coefficient-bank-binding']
    rules['actual-role-row-ROM-word']=dict(assumptions=[H('a'),d('rst_n'),'(rms-u-inv a)','(rms-h-inv a h)'],
        conclusion=translate_local(old['conclusion']))
    if revision>=4:
        # Separate source register transfer from exact multiply meaning. This
        # avoids asking a bit-blaster to rediscover multiply congruence across
        # two complete native state encodings. Every intermediate is proved.
        nxt=lambda text:text.replace(' a)',' an)')
        next_weight=phase(12,13).replace(' a)',' an)')
        incoming=both([next_weight,d('rst_n','an'),'(not (failed an))'])
        prior_mul=phase(11)
        prior_hold=phase(12,13)
        transfers=[f'(=> {incoming} (or {prior_mul} {prior_hold}))',
            f'(=> {incoming} {eq(nxt(r("rms_normalized_q")),r("rms_normalized_q"))})',
            f'(=> {incoming} {eq(nxt(r("rom_coefficient")),r("rom_coefficient"))})',
            f'(=> {both([incoming,prior_mul])} {eq(nxt(r("weight_product_q")),"((_ extract 25 0) "+r("dsp_product0")+")")})',
            f'(=> {both([incoming,prior_hold])} {eq(nxt(r("weight_product_q")),r("weight_product_q"))})']
        for i,t in enumerate(transfers):
            rules['weight-register-transfer-'+str(i)]=dict(assumptions=ctx,conclusion=t)
        rules['actual-weight-word-product']['assumptions']=[H('a'),phase(11)]
        word=rules['actual-weight-word-product']['conclusion']
        rules['preserved-1']['assumptions']=[*transfers,'(rw-clause-1 a h)',
            f'(=> {prior_mul} {word})',
            # If the next state is live the current edge must be live too;
            # this is proved separately and needs no arithmetic assumption.
            f'(=> {incoming} {both([d("rst_n"),"(not (failed a))"])})']
        rules['weight-live-predecessor']=dict(assumptions=ctx,
            conclusion=rules['preserved-1']['assumptions'][-1])
    return decl,defs,rules


if __name__=='__main__':
    import sys
    revision=3 if '--revision-3' in sys.argv else 2
    prepare();save_plan('rms-read-words-r'+str(revision),*specification(revision),native_label='context')
    print('Prepared actual RMS scalar-read/ROM/word-multiply producer rules.')

"""Connect retained RMS RAM through actual synchronous reads to Q capture.

The entry vector is fixed at the actual accepted Q-child descriptor. A rigid
arbitrary watched row covers its complete 256-word capture prefix. No desired
Q arithmetic result or private memory response is assumed.
"""
from common import bv,both,eq,ext,save_plan
from parent_flow import TOP,S,DP,n,d
from rms_store import definitions as store_definitions
from prepare_context import prepare

j=lambda field,a='a':n(DP+'u_projection.'+field,a)
qmem=lambda a='a':f'(|{TOP}_m {DP}u_projection.activation_memory_q| {a})'


def definitions(revision=1):
    defs,_=store_definitions(4)
    fields=[('live','Bool'),('generation','Int'),('layer','(_ BitVec 3)'),
            ('exponent','(_ BitVec 8)'),('vector','(Array (_ BitVec 8) (_ BitVec 16))'),
            ('count','(_ BitVec 9)')]
    defs+='(declare-datatypes () ((QInput (q-input '+' '.join('(qi-'+f+' '+t+')' for f,t in fields)+'))))\n'
    zvec='((as const (Array (_ BitVec 8) (_ BitVec 16))) '+bv(0,16)+')'
    defs+=f'(define-fun qi-zero () QInput (q-input false 0 {bv(0,3)} {bv(0,8)} {zvec} {bv(0,9)}))\n'
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    start=both([j('start_transfer'),j('incoming_descriptor_valid')])
    fresh='(q-input true (rv-generation v) '+d('current_layer_q')+' '+d('rms_exponent_q')+' (rv-vector v) '+bv(0,9)+')'
    change='(q-input '+' '.join(['(qi-'+f+' q)' for f,t in fields[:-1]])+f' (bvadd (qi-count q) (ite (and (qi-live q) {j("activation_store_write")}) {bv(1,9)} {bv(0,9)})))'
    revoke=f'(or (not {d("rst_n")}) {d("clear_i")} {d("stage_accept")} {j("integrated_fail")} (and {j("done_valid_o")} {j("done_ready_i")}))'
    defs+=f'(define-fun qi-next ((a {S}) (v RMSStore) (q QInput)) QInput (ite {revoke} qi-zero (ite {start} (ite {qmode} {fresh} qi-zero) {change})))\n'
    active='(or '+' '.join(eq(j('state_q'),bv(k,3)) for k in range(1,5))+')'
    compute='(or '+' '.join(eq(j('state_q'),bv(k,3)) for k in [2,3,4])+')'
    healthy=both(['(flow-healthy a)',f'(not {j("integrated_fail")})'])
    own=both([healthy,qmode,active])
    qrow='((_ extract 7 0) '+j('activation_count_q')+')'
    clauses=[
        f'(=> (and {healthy} {active}) '+both([
            f'(or {eq(d("engine_state_q"),bv(2,4))} {eq(d("engine_state_q"),bv(8,4))})',
            d('service_start_seen_q'),eq(j('job_q'),d('projection_job')),eq(j('layer_q'),d('projection_layer'))])+')',
        f'(=> (and {healthy} {d("service_done_seen_q")} {eq(d("engine_state_q"),bv(2,4))}) '+both([
            d('service_start_seen_q'),f'(not {active})'])+')',
        f'(=> (and {healthy} {qmode} (not {d("service_start_seen_q")})) {eq(j("state_q"),bv(0,3))})',
        f'(=> (and (flow-healthy a) {qmode}) (bvule '+d('input_index_q')+' '+bv(255,10)+'))',
        f'(=> (and (flow-healthy a) {qmode} {d("rms_read_valid_q")}) '+
            eq(d('rms_ram_read_data'),f'(select (rv-vector v) ((_ extract 7 0) {d("input_index_q")}))')+')',
        f'(=> {own} '+both(['(qi-live q)',eq('(qi-generation q)','(rv-generation v)'),
            eq('(qi-vector q)','(rv-vector v)'),eq('(qi-layer q)',d('current_layer_q')),
            eq('(qi-exponent q)',d('rms_exponent_q')),eq(j('activation_exponent_q'),'(qi-exponent q)'),
            eq(j('job_q'),bv(0,4)),eq(j('columns_q'),bv(256,10)),f'(bvule (qi-count q) {bv(256,9)})'])+')',
        f'(=> (and {own} {eq(j("state_q"),bv(1,3))}) '+both([
            f'(not {d("input_done_q")})',f'(bvult (qi-count q) {bv(256,9)})',
            eq(j('activation_count_q'),d('input_index_q')),
            eq(ext('(qi-count q)',1),j('activation_count_q'))])+')',
        f'(=> (and {own} {compute}) '+both([d('input_done_q'),eq('(qi-count q)',bv(256,9))])+')',
        f'(=> (and {own} (bvult {ext("watch",1)} (qi-count q))) '+both([
            eq(f'(select {qmem()} {ext("watch",2)})','(select (qi-vector q) watch)'),
            f'(distinct (select (qi-vector q) watch) {bv(-32768,16)})'])+')',
    ]
    if revision>=2:
        # Old DDR work may be draining before the child accepts this Q job.
        # Its native start-ready gate supplies quiescence at actual admission;
        # no current computation is inferred from the parent's stage name.
        # Prove the caller cursor's fresh initialization instead of requiring
        # an unnecessary idle child throughout that wait.
        clauses[2]=f'(=> (and {healthy} {qmode} (not {d("service_start_seen_q")})) '+both([
            eq(d('input_index_q'),bv(0,10)),f'(not {d("input_done_q")})'])+')'
    args=f'((a {S}) (v RMSStore) (q QInput) (watch (_ BitVec 8)))'
    for i,c in enumerate(clauses):defs+=f'(define-fun qi-clause-{i} {args} Bool (=> {d("rst_n")} {c}))\n'
    defs+=f'(define-fun qi-inv {args} Bool '+both([f'(qi-clause-{i} a v q watch)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision)
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
        '(declare-const rs RMSSnapshot)','(declare-const rsn RMSSnapshot)',
        '(declare-const ch History)','(declare-const chn History)',
        '(declare-const v RMSStore)','(declare-const vn RMSStore)',
        '(declare-const q QInput)','(declare-const qn QInput)',
        '(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    if revision>=3:ctx+=[f'(|{TOP}_i| a)',f'(|{TOP}_i| an)']
    providers=['(flow-inv a)','(flow-inv an)','(kind-inv a)','(kind-inv an)',
        '(rv-inv a rs ch v)','(rv-inv an rsn chn vn)',
        eq('rsn','(rs-next a rs)'),eq('vn','(rv-next a an rs v)')]
    step=ctx+providers+['(qi-inv a v q watch)',eq('qn','(qi-next a v q)')]
    parts=[f'(qi-clause-{i} an vn qn watch)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(qi-inv an (rv-base an) qi-zero watch)'),
        **{f'preserved-{i}':dict(assumptions=step,conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qi-inv an vn qn watch)')}
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    current=[H('a'),'(flow-healthy a)',f'(not {j("integrated_fail")})',qmode,
             '(rv-inv a rs ch v)','(qi-inv a v q watch)']
    rules['actual-Q-write-argument-from-current-RMS']=dict(assumptions=current+[j('activation_store_write')],
        conclusion=both(['(qi-live q)',eq(j('activation_i'),f'(select (rv-vector v) ((_ extract 7 0) {j("activation_count_q")}))'),
            f'(bvult {j("activation_count_q")} {bv(256,10)})',eq(j('activation_exponent_q'),'(rv-exponent v)'),
            eq('(qi-generation q)','(rv-generation v)')]))
    compute='(or '+' '.join(eq(j('state_q'),bv(k,3)) for k in [2,3,4])+')'
    rules['actual-complete-Q-argument-row-from-current-RMS']=dict(assumptions=current+[compute],
        conclusion=both(['(qi-live q)',eq('(qi-count q)',bv(256,9)),
            eq(f'(select {qmem()} {ext("watch",2)})','(select (rv-vector v) watch)'),
            eq(j('activation_exponent_q'),'(rv-exponent v)'),eq('(qi-generation q)','(rv-generation v)')]))
    return decl,defs,rules


if __name__=='__main__':
    import sys
    revision=3 if '--revision-3' in sys.argv else (2 if '--revision-2' in sys.argv else 1)
    prepare();save_plan('q-input-capture' if revision==1 else 'q-input-capture-r'+str(revision),*specification(revision),native_label='context')
    print('Prepared actual RMS RAM/read pipeline/Q argument capture induction.')

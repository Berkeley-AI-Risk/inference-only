"""Actual Q admission/capture receives the fixed independent RMS reference.

The QInput observer fixes its vector at real child admission. The qualified Q
accepted-event fold/argument persistence theorem is composed at this interface;
QInput is not required to survive projection DONE.
"""
from common import HERE,bv,both,eq,ext,save_plan
from parent_flow import TOP,S,d
from q_input_capture import definitions as input_definitions,j
from rms_numeric_store import definitions as numeric_definitions
from rms_raw_capture import merge
from prepare_context import prepare


def specification(revision=1):
    defs=merge([input_definitions(3)[0],numeric_definitions(2)[0]])
    H=f'(|{TOP}_h| a)';I=f'(|{TOP}_i| a)'
    decl=[f'(declare-const a {S})','(declare-const rs RMSSnapshot)','(declare-const ch History)',
        '(declare-const v RMSStore)','(declare-const rr RMSNumericStore)','(declare-const q QInput)',
        '(declare-const watch (_ BitVec 8))']
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    current=[H,I,'(flow-inv a)','(kind-inv a)','(rs-inv a rs)','(rv-inv a rs ch v)',
        '(rr-inv a rs v rr watch)','(qi-inv a v q watch)',qmode]
    descriptor=both([j('start_transfer'),j('incoming_descriptor_valid')])
    fire=j('activation_store_write')
    source_live=both(['(flow-healthy a)',f'(not {j("integrated_fail")})'])
    snapshot='(qi-next a v q)'
    fixed=both(['(qi-live '+snapshot+')',eq('(qi-count '+snapshot+')',bv(0,9)),
        eq('(qi-generation '+snapshot+')','(rr-generation rr)'),eq('(qi-layer '+snapshot+')','(rr-layer rr)'),
        eq('(qi-exponent '+snapshot+')','(rr-exponent rr)'),
        eq('(select (qi-vector '+snapshot+') watch)','(select (rr-vector rr) watch)'),
        eq('(rr-stage rr)',bv(0,5)),eq('(rr-count rr)',bv(256,9)),
        eq(j('activation_exponent_i'),'(rr-exponent rr)'),eq(j('fixed_layer_i'),'(rr-layer rr)'),
        eq(j('fixed_job_i'),bv(0,4)),eq(j('incoming_columns'),bv(256,10))])
    actual_row=j('activation_count_q');row8='((_ extract 7 0) '+actual_row+')'
    captured=both(['(qi-live q)',f'(bvult {actual_row} {bv(256,10)})',
        eq(actual_row,ext('(qi-count q)',1)),
        eq(j('activation_i'),f'(select (qi-vector q) {row8})'),
        eq('(qi-generation q)','(rr-generation rr)'),eq('(qi-layer q)','(rr-layer rr)'),
        eq('(qi-exponent q)','(rr-exponent rr)')])
    rules={
        'actual-Q-descriptor-is-live':dict(assumptions=current+[descriptor],conclusion=source_live),
        'actual-Q-admission-fixes-independent-RMS-reference':dict(assumptions=current+[descriptor],conclusion=fixed),
        'actual-Q-capture-is-live':dict(assumptions=current+[fire],conclusion=source_live),
        'actual-Q-capture-word-is-fixed-admission-reference':dict(assumptions=current+[fire],conclusion=captured),
    }
    if revision>=2:
        rules['actual-Q-start-descriptor-is-valid']=dict(assumptions=current+[j('start_transfer')],conclusion=j('incoming_descriptor_valid'))
    if revision>=3:
        rules['active-Q-freezes-RMS-reference-owner']=dict(assumptions=[H,qmode],
            conclusion=both([f'(not {d("stage_accept")})','(not (rs-accept a))',
                f'(not {d("rms_ram_write_enable")})',f'(not {d("head_start_accept")})']))
        rules['actual-Q-capture-has-exact-fold-event']=dict(assumptions=current+[fire],
            conclusion=both([eq(j('state_q'),bv(1,3)),
                eq(j('activation_last_i'),eq(j('activation_count_q'),bv(255,10))),
                f'(distinct {j("activation_i")} {bv(-32768,16)})']))
    if revision>=4:
        cancel=f'(or {j("clear_i")} {j("integrated_fail")} (and {j("done_valid_o")} {j("done_ready_i")}))'
        validstart=both([j('start_transfer'),j('incoming_descriptor_valid')])
        rules['actual-Q-capture-is-not-a-revocation-or-new-start']=dict(assumptions=current+[fire],
            conclusion=both([j('reset_n'),f'(not {cancel})',f'(not {validstart})']))
    return decl,defs,rules


if __name__=='__main__':
    import sys
    revision=4 if '--revision-4' in sys.argv else (3 if '--revision-3' in sys.argv else (2 if '--revision-2' in sys.argv else 1))
    prepare();save_plan('rms-q-argument'+('-r'+str(revision) if revision>1 else ''),*specification(revision),native_label='context')
    print('Prepared actual admission-fixed RMS reference and every accepted Q activation word.')

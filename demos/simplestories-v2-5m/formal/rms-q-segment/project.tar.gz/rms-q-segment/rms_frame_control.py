"""Actual RMS output-prefix ownership of one independent normalizer frame.

These are source control/provider facts. Candidate persistence itself is an
application of the independently checked pure normalizer transition laws.
"""
from common import HERE,bv,both,eq,save_plan
from parent_flow import S,TOP,d
from rms_capture import r
from rms_numeric_store import definitions as rr_definitions
from normalizer_instance import definitions as norm_definitions
from rms_local import to_parent
from rms_raw_capture import merge
from rms_native_history import parse,emit
from prepare_context import prepare


def specification():
    defs=merge([rr_definitions(2)[0],to_parent(norm_definitions())])
    nd={x[1]:x for x in parse(defs) if x[0]=='define-fun'}
    step=nd['na-next'][4]
    if step[0]!='na-step' or len(step)!=12:raise ValueError('Changed independent next interface')
    cancel=emit(step[-2]);start=emit(step[4])
    H=f'(|{TOP}_h| a)'
    current=[H,d('rst_n'),'(flow-inv a)','(kind-inv a)','(rms-u-inv a)',
        '(rms-h-inv a ch)','(rv-inv a rs ch v)','(na-inv a nc na)']
    healthy=['(flow-healthy a)','(not (failed a))',eq(d('engine_state_q'),bv(1,4)),
        f'(bvugt (rv-count v) {bv(0,9)})']
    output='(or '+' '.join(eq('(na-phase na)',bv(k,3)) for k in [4,5,6])+')'
    rules={
        'positive-owned-prefix-is-one-output-frame':dict(assumptions=current+healthy,conclusion=output),
        'positive-owned-prefix-does-not-start-another-normalizer':dict(assumptions=current+healthy,conclusion='(not '+start+')'),
        'owned-prefix-without-parent-CLEAR-does-not-cancel-normalizer':dict(assumptions=current+healthy+['(not '+d('clear_i')+')'],conclusion='(not '+cancel+')'),
        'normalizer-start-has-empty-RMS-prefix-and-fixed-arguments':dict(assumptions=current+[
            '(flow-healthy a)','(not (failed a))',eq(d('engine_state_q'),bv(1,4)),start],
            conclusion=both([eq('(rv-count v)',bv(0,9)),'(h-active ch)',eq('(h-captured ch)',bv(256,9))])),
        'failed-RMS-is-sticky-until-reset-or-CLEAR':dict(assumptions=[H,f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',
            d('rst_n'),d('rst_n','an'),'(not '+d('clear_i')+')','(failed a)'],conclusion='(failed an)'),
    }
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const ch History)',
        '(declare-const rs RMSSnapshot)','(declare-const v RMSStore)',
        '(declare-const nc NormCapture)','(declare-const na NormAlgorithm)']
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('rms-frame-control',*specification(),native_label='context')
    print('Prepared actual single-normalizer-frame prefix control facts.')

"""Prove which fixed stages can own each actual datapath engine mode."""
from common import bv,both,eq,save_plan
from parent_flow import TOP,S,d,definitions as flow_definitions
from prepare_context import prepare

KINDS={1:[0,10],2:[1,2,3,8,11,12,14],3:[4,5],4:[6],
       5:[7],6:[9,13,15],7:[16]}


def kind_definitions():
    clauses=[]
    for engine,stages in KINDS.items():
        stages='(or '+' '.join(eq(d('current_stage_q'),bv(k,5)) for k in stages)+')'
        clauses.append(f'(=> (and (flow-healthy a) {eq(d("engine_state_q"),bv(engine,4))}) {stages})')
    args=f'((a {S}))'
    defs=''
    for i,c in enumerate(clauses):defs+=f'(define-fun kind-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun kind-inv {args} Bool '+both([f'(kind-clause-{i} a)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    flow,_=flow_definitions();defs,clauses=kind_definitions();defs=flow+defs
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    parts=[f'(kind-clause-{i} an)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(kind-inv an)'),
        **{f'preserved-{i}':dict(assumptions=ctx+['(kind-inv a)'],conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(kind-inv an)')}
    return decl,defs,rules


if __name__=='__main__':
    prepare();save_plan('parent-kinds',*specification(),native_label='context')
    print('Prepared exact fixed-stage/engine-mode induction.')

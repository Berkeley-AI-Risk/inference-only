"""Fresh local algorithm implications at the exact native RMS helper instances.

This is a checked identical-source module specialization followed by new engine
queries using the full parent transition. It identifies no unrelated state
sorts and assumes no numerical helper result.
"""
import json
import re
import sys
from common import HERE,PILOT,bv,both,eq,sha,atomic_json,save_plan
from parent_flow import TOP,S,DP
from prepare_context import prepare
from digit_algorithms import ROOT_TOP,DIV_TOP,root_specification,div_specification
from prepare import modules
sys.path.insert(0,str(PILOT/'q-operator'))
from pruned_arithmetic import parse,emit,atoms


def specification(label):
    if label=='root-instance':
        old=ROOT_TOP;prefix=DP+'u_rmsnorm.u_exact_isqrt.u_exact_board0_isqrt.'
        local='root-r2';decl,defs,rules=root_specification()
    elif label=='divider-instance':
        old=DIV_TOP;prefix=DP+'u_rmsnorm.u_exact_divider.u_exact_bounded_divider.'
        local='divider';decl,defs,rules=div_specification()
    else:raise ValueError('Unknown helper instance')
    source=(HERE/'context/rms-segment-native.sv').read_text()
    if modules(source)[old]!=modules((HERE/local/'native.sv').read_text())[old]:
        raise ValueError('Actual helper is not the exact proved source module')
    old_ast=parse((HERE/local/'native.smt2').read_text())
    parent_ast=parse((HERE/'context/native.smt2').read_text())
    local_defs={x[1]:x for x in old_ast if x[0]=='define-fun'}
    parent_defs={x[1]:x for x in parent_ast if x[0]=='define-fun'}
    symbols=set(atoms(parse(defs)))|set(atoms(parse('\n'.join(decl))))
    for rule in rules.values():symbols|=set(atoms(parse('\n'.join(rule['assumptions']+[rule['conclusion']]))))
    mapping={'|'+old+'_s|':S,'|'+old+'_h|':'|'+TOP+'_h|','|'+old+'_t|':'|'+TOP+'_t|'}
    getters=[]
    for name in sorted(symbols):
        m=re.fullmatch(r'\|'+old+r'_(n|m) (.+)\|',name)
        if not m:continue
        target='|'+TOP+'_'+m[1]+' '+prefix+m[2]+'|'
        if target not in parent_defs or name not in local_defs or local_defs[name][3]!=parent_defs[target][3]:
            raise ValueError('Missing or mistyped actual helper getter: '+name)
        mapping[name]=target
        getters.append(dict(local=name,actual=target,sort=emit(local_defs[name][3])))
    def tr(x):return [tr(y) for y in x] if isinstance(x,list) else mapping.get(x,x)
    def text(s):
        result=tr(parse(s))
        if any(old in token for token in atoms(result)):raise ValueError('Incomplete helper specialization')
        return '\n'.join(emit(x) for x in result)+('\n' if s.endswith('\n') else '')
    new_decl=[text(x) for x in decl]
    new_defs=text(defs)
    new_rules={name:{**rule,'assumptions':[text(x) for x in rule['assumptions']],
                           'conclusion':text(rule['conclusion'])} for name,rule in rules.items()}
    if label=='divider-instance':
        numerator=f'(|{TOP}_n {prefix}request_numerator_i| a)'
        new_rules['actual-RMS-numerator-meets-bounded-helper-domain']=dict(
            assumptions=[f'(|{TOP}_h| a)'],conclusion=f'(div-domain {numerator})')
    binding=dict(schema='Exact-source-RMS-helper-parent-specialization-v1',
        local=local,actual_module=old,actual_prefix=prefix,
        identical_module_sha256=sha(modules(source)[old].encode()),getters=getters,
        full_actual_parent_transition=True,no_desired_reply_assumption=True,
        native_frontend_and_source_module_instantiation_boundary=True)
    return new_decl,new_defs,new_rules,binding


if __name__=='__main__':
    prepare()
    for label in sys.argv[1:] or ['root-instance','divider-instance']:
        decl,defs,rules,binding=specification(label)
        atomic_json(HERE/(label+'-INSTANCE.json'),binding)
        save_plan(label,decl,defs,rules,native_label='context')
        print('Prepared exact native RMS instance algorithm: '+label)

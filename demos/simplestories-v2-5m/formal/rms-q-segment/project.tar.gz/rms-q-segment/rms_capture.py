"""Actual RMS child capture RAM and entry-vector correspondence.

The watched row is arbitrary and fixed through base and preservation. The
consequence is thus universal in the row, not a bounded set of simulations.
"""
from common import bv,both,eq,ext,save_plan
from parent_flow import S,TOP,DP,n,d
from rms_snapshot import definitions as snapshot_definitions
from prepare_context import prepare

r=lambda field,a='a':n(DP+'u_rmsnorm.'+field,a)
rmem=lambda a='a':f'(|{TOP}_m {DP}u_rmsnorm.vector_mem_q| {a})'


def definitions():
    defs,_=snapshot_definitions()
    healthy=both(['(flow-healthy a)',f'(not {r("range_fault_o")})'])
    mode=eq(d('engine_state_q'),bv(1,4))
    active=both([f'(bvuge {r("state_q")} {bv(1,5)})',f'(bvule {r("state_q")} {bv(14,5)})'])
    owned=both([healthy,mode])
    clauses=[
        f'(bvule {r("state_q")} {bv(14,5)})',
        f'(=> (not {mode}) {eq(r("state_q"),bv(0,5))})',
        f'(=> {active} '+both([mode,d('service_start_seen_q')])+')',
        f'(=> (and {mode} (not {d("service_start_seen_q")})) '+both([eq(r('state_q'),bv(0,5)),eq('(rs-captured h)',bv(0,9))])+')',
        f'(=> (and {mode} {d("service_done_seen_q")}) '+both([d('service_start_seen_q'),eq(r('state_q'),bv(0,5))])+')',
        f'(=> (and {mode} {eq(r("state_q"),bv(1,5))}) {eq("(rs-captured h)",ext(r("capture_index_q"),1))})',
        f'(=> (and {mode} (bvuge {r("state_q")} {bv(2,5)})) {eq("(rs-captured h)",bv(256,9))})',
        f'(=> (and {mode} (bvult {ext("watch",1)} (rs-captured h))) '+both([
            eq(f'(select {rmem()} watch)','(select (rs-vector h) watch)'),
            f'(distinct (select (rs-vector h) watch) {bv(-32768,16)})'])+')',
    ]
    args=f'((a {S}) (h RMSSnapshot) (watch (_ BitVec 8)))'
    for i,c in enumerate(clauses):
        defs+=f'(define-fun rc-clause-{i} {args} Bool (=> {healthy} {c}))\n'
    defs+=f'(define-fun rc-inv {args} Bool '+both([f'(rc-clause-{i} a h watch)' for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions()
    H=lambda a:f'(|{TOP}_h| {a})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',
          '(declare-const h RMSSnapshot)','(declare-const hn RMSSnapshot)',
          '(declare-const watch (_ BitVec 8))']
    ctx=[H('a'),H('an'),f'(|{TOP}_t| a an)']
    step=ctx+['(flow-inv a)','(flow-inv an)','(rs-inv a h)','(rs-inv an hn)',
              '(rc-inv a h watch)',eq('hn','(rs-next a h)')]
    parts=[f'(rc-clause-{i} an hn watch)' for i in range(len(clauses))]
    rules={'common-reset-base':dict(assumptions=ctx+[f'(not {d("rst_n")})'],conclusion='(rc-inv an rs-zero watch)'),
        **{f'preserved-{i}':dict(assumptions=step,conclusion=p) for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(rc-inv an hn watch)')}
    context=[H('a'),'(flow-inv a)','(rs-inv a h)','(rc-inv a h watch)',
             '(flow-healthy a)',f'(not {r("range_fault_o")})',eq(d('engine_state_q'),bv(1,4)),
             f'(bvuge {r("state_q")} {bv(2,5)})']
    rules['actual-complete-captured-row-is-entry-vector']=dict(assumptions=context,
        conclusion=both(['(rs-live h)',eq('(rs-captured h)',bv(256,9)),
            eq(f'(select {rmem()} watch)','(select (rs-vector h) watch)'),
            f'(distinct (select (rs-vector h) watch) {bv(-32768,16)})']))
    return decl,defs,rules


if __name__=='__main__':
    prepare()
    save_plan('rms-capture',*specification(),native_label='context')
    print('Prepared actual RMS capture RAM/entry-vector and lifecycle induction.')

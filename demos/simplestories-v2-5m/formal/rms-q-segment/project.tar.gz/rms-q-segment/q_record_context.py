"""Actual Q invocation keeps its admission owner and RMS reference fixed."""
from common import bv,both,eq,save_plan
from parent_flow import S,TOP,d
from rms_q_argument import specification as argument_spec
from rms_native_history import parse,emit
from prepare_context import prepare


def specification():
    decl,defs,_=argument_spec(4)
    decl += [f'(declare-const an {S})','(declare-const rsn RMSSnapshot)']
    qmode=both([eq(d('engine_state_q'),bv(2,4)),eq(d('current_stage_q'),bv(1,5))])
    ctx=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',
        d('rst_n'),d('rst_n','an'),'(not '+d('clear_i')+')',qmode]
    rn='(rr-next a rsn na rr)'
    # The expected numeric-store helper needs a pure algorithm argument but
    # cannot consult it in Q mode, because actual RMS writes are excluded.
    decl+=['(declare-const na NormAlgorithm)']
    rules={
        'Q-invocation-layer-and-position-held':dict(assumptions=ctx,
            conclusion=both([eq(d('current_layer_q','an'),d('current_layer_q')),eq(d('current_position_q','an'),d('current_position_q'))])),
        'Q-invocation-RMS-reference-and-origin-held':dict(assumptions=ctx,
            conclusion=both([eq(rn,'rr'),eq('(rs-generation (rs-next a rs))','(rs-generation rs)'),
                eq('(rs-layer (rs-next a rs))','(rs-layer rs)'),eq('(rs-position (rs-next a rs))','(rs-position rs)')])),
    }
    return decl,defs,rules


if __name__=='__main__':prepare();save_plan('q-record-context',*specification(),native_label='context')

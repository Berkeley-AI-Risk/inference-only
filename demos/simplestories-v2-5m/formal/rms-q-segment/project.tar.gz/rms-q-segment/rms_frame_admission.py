"""Bind the real RMS child-normalizer admission to the fixed RMS invocation."""
from common import bv,both,eq,save_plan
from rms_frame_control import specification as control_spec
from rms_arguments import definitions as argument_definitions
from rms_raw_capture import merge
from parent_flow import S,TOP,d
from rms_capture import r
from rms_native_history import parse,emit
from prepare_context import prepare


def specification():
    decl,defs,_=control_spec();defs=merge([defs,argument_definitions()[0]])
    nd={x[1]:x for x in parse(defs) if x[0]=='define-fun'};step=nd['na-next'][4]
    start=emit(step[4]);cancel=emit(step[-2]);interrupt=emit(step[-1])
    H=f'(|{TOP}_h| a)';current=[H,d('rst_n'),'(flow-inv a)','(kind-inv a)',
        '(rms-u-inv a)','(rms-h-inv a ch)','(rv-inv a rs ch v)','(na-inv a nc na)',
        '(rs-inv a rs)','(rc-inv a rs watch)','(ra-inv a rs)']
    observed=['(flow-healthy a)','(not (failed a))',eq(d('engine_state_q'),bv(1,4)),start]
    rules={'actual-normalizer-start-is-fresh-current-RMS-program':dict(assumptions=current+observed,
        conclusion=both([eq('(na-phase na)',bv(0,3)),'(not '+cancel+')','(not '+interrupt+')',
            eq(r('state_q'),bv(7,5)), '(rs-live rs)','(h-active ch)',eq('(h-captured ch)',bv(256,9)),
            eq('(h-exponent ch)','(rs-exponent rs)'),eq('(select (h-vector ch) watch)','(select (rs-vector rs) watch)'),
            eq('(h-role ch)',r('selector_q'))]))}
    decl+=['(declare-const watch (_ BitVec 8))']
    return decl,defs,rules


if __name__=='__main__':prepare();save_plan('rms-frame-admission',*specification(),native_label='context')

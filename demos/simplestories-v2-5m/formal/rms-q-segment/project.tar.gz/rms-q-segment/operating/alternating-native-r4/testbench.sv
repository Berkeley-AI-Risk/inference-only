`timescale 1ns/1ps
module segment_witness;
reg  clk=0;
reg  rst_n=0;
reg  clear_i=0;
reg  model_lock_i=0;
reg  upstream_fault_i=0;
reg  private_head_start_valid_i=0;
wire  private_head_start_ready_o;
reg [7:0] private_head_activation_exponent_i=0;
reg  private_head_activation_valid_i=0;
wire  private_head_activation_ready_o;
reg [7:0] private_head_activation_index_i=0;
reg [15:0] private_head_activation_mantissa_i=0;
reg  private_head_activation_last_i=0;
wire  private_head_result_valid_o;
reg  private_head_result_ready_i=0;
wire [12:0] private_head_result_row_index_o;
wire [49:0] private_head_result_scaled_raw_o;
wire [7:0] private_head_result_source_exponent_o;
wire  private_head_result_last_o;
wire  private_head_done_valid_o;
reg  private_head_done_ready_i=0;
reg  start_valid_i=0;
wire  start_ready_o;
reg [10:0] fixed_position_i=0;
reg [7:0] input_exponent_i=0;
reg  input_valid_i=0;
wire  input_ready_o;
reg [7:0] input_index_i=0;
reg [15:0] input_mantissa_i=0;
reg  input_last_i=0;
wire  result_valid_o;
reg  result_ready_i=0;
wire [7:0] result_index_o;
wire [15:0] result_mantissa_o;
wire [7:0] result_exponent_o;
wire  result_last_o;
wire  done_valid_o;
reg  done_ready_i=0;
wire  private_word_req_valid_o;
reg  private_word_req_ready_i=0;
wire [19-1:0] private_word_req_index_o;
reg  private_word_rsp_valid_i=0;
wire  private_word_rsp_ready_o;
reg [255:0] private_word_rsp_data_i=0;
reg  private_word_rsp_fault_i=0;
wire  kv_write_req_valid_o;
reg  kv_write_req_ready_i=0;
wire [2:0] kv_write_req_layer_o;
wire [11:0] kv_write_req_position_o;
wire [1:0] kv_write_req_head_o;
wire [3:0] kv_write_req_row_word_o;
wire [18:0] kv_write_req_shadow_address_o;
wire [255:0] kv_write_req_data_o;
reg  kv_write_cpl_valid_i=0;
wire  kv_write_cpl_ready_o;
reg  kv_write_cpl_fault_i=0;
wire  kv_read_req_valid_o;
reg  kv_read_req_ready_i=0;
wire [2:0] kv_read_req_layer_o;
wire [11:0] kv_read_req_position_o;
wire [1:0] kv_read_req_head_o;
wire [3:0] kv_read_req_row_word_o;
wire [18:0] kv_read_req_shadow_address_o;
reg  kv_read_rsp_valid_i=0;
wire  kv_read_rsp_ready_o;
reg [255:0] kv_read_rsp_data_i=0;
reg  kv_read_rsp_fault_i=0;
reg  kv_endpoint_fault_i=0;
wire [71:0] committed_prefixes_o;
wire  busy_o;
wire  range_fault_o;
reg [15:0] f_child_u_gate_scratch_private_read_data_o=0;
reg [15:0] f_child_u_up_scratch_private_read_data_o=0;
reg [15:0] f_child_u_attention_scratch_private_read_data_o=0;
reg [15:0] f_child_u_rms_scratch_private_read_data_o=0;
reg [15:0] f_child_u_output_scratch_private_read_data_o=0;
reg [15:0] f_child_u_hidden_state_private_read_data_o=0;
reg [15:0] f_child_u_query_state_private_read_data_o=0;
reg [15:0] f_child_u_key_state_private_read_data_o=0;
reg [15:0] f_child_u_value_state_private_read_data_o=0;
reg [49:0] f_child_u_rope_raw_scratch_private_read_data_o=0;
reg  f_child_u_rmsnorm_start_ready_o=0;
reg  f_child_u_rmsnorm_input_ready_o=0;
reg  f_child_u_rmsnorm_result_valid_o=0;
reg [7:0] f_child_u_rmsnorm_result_row_index_o=0;
reg [15:0] f_child_u_rmsnorm_result_mantissa_o=0;
reg [7:0] f_child_u_rmsnorm_result_exponent_o=0;
reg  f_child_u_rmsnorm_result_last_o=0;
reg  f_child_u_rmsnorm_done_valid_o=0;
reg  f_child_u_rmsnorm_busy_o=0;
reg  f_child_u_rmsnorm_range_fault_o=0;
reg  f_child_u_projection_start_ready_o=0;
reg  f_child_u_projection_activation_ready_o=0;
reg  f_child_u_projection_private_word_req_valid_o=0;
reg [19-1:0] f_child_u_projection_private_word_req_index_o=0;
reg  f_child_u_projection_private_word_rsp_ready_o=0;
reg  f_child_u_projection_result_valid_o=0;
reg [12:0] f_child_u_projection_result_row_index_o=0;
reg [49:0] f_child_u_projection_result_scaled_raw_o=0;
reg [7:0] f_child_u_projection_result_source_exponent_o=0;
reg  f_child_u_projection_result_last_o=0;
reg  f_child_u_projection_done_valid_o=0;
reg  f_child_u_projection_busy_o=0;
reg  f_child_u_projection_fail_closed_o=0;
reg  f_child_u_normalizer_start_ready_o=0;
reg  f_child_u_normalizer_input_ready_o=0;
reg  f_child_u_normalizer_result_valid_o=0;
reg [9:0] f_child_u_normalizer_result_row_index_o=0;
reg [15:0] f_child_u_normalizer_result_mantissa_o=0;
reg [7:0] f_child_u_normalizer_result_exponent_o=0;
reg  f_child_u_normalizer_result_last_o=0;
reg  f_child_u_normalizer_done_valid_o=0;
reg  f_child_u_normalizer_busy_o=0;
reg  f_child_u_normalizer_range_fault_o=0;
reg  f_child_u_elementwise_lane_request_ready_o=0;
reg  f_child_u_elementwise_lane_lut_request_o=0;
reg [15:0] f_child_u_elementwise_lane_lut_index_o=0;
reg  f_child_u_elementwise_lane_result_valid_o=0;
reg [15:0] f_child_u_elementwise_lane_result0_o=0;
reg [15:0] f_child_u_elementwise_lane_result1_o=0;
reg [15:0] f_child_u_elementwise_lane_auxiliary_o=0;
reg [49:0] f_child_u_elementwise_lane_raw0_o=0;
reg [49:0] f_child_u_elementwise_lane_raw1_o=0;
reg [7:0] f_child_u_elementwise_lane_source_exponent_o=0;
reg  f_child_u_elementwise_lane_range_fault_o=0;
reg  f_child_u_lookup_request_ready_o=0;
reg  f_child_u_lookup_response_valid_o=0;
reg [15:0] f_child_u_lookup_response_value_o=0;
reg  f_child_u_lookup_response_fault_o=0;
reg  f_child_u_lookup_private_word_req_valid_o=0;
reg [19-1:0] f_child_u_lookup_private_word_req_index_o=0;
reg  f_child_u_lookup_private_word_rsp_ready_o=0;
reg  f_child_u_lookup_busy_o=0;
reg  f_child_u_lookup_fail_closed_o=0;
reg  f_child_u_kv_cache_stage_begin_ready_o=0;
reg  f_child_u_kv_cache_stage_payload_ready_o=0;
reg  f_child_u_kv_cache_pending_complete_o=0;
reg  f_child_u_kv_cache_commit_ready_o=0;
reg  f_child_u_kv_cache_attention_req_ready_o=0;
reg  f_child_u_kv_cache_attention_rsp_valid_o=0;
reg [1023:0] f_child_u_kv_cache_attention_rsp_key_vector_o=0;
reg [7:0] f_child_u_kv_cache_attention_rsp_key_exponent_o=0;
reg [1023:0] f_child_u_kv_cache_attention_rsp_value_vector_o=0;
reg [7:0] f_child_u_kv_cache_attention_rsp_value_exponent_o=0;
reg  f_child_u_kv_cache_attention_rsp_fault_o=0;
reg  f_child_u_kv_cache_attention_rsp_from_pending_o=0;
reg  f_child_u_kv_cache_kv_write_req_valid_o=0;
reg [2:0] f_child_u_kv_cache_kv_write_req_layer_o=0;
reg [11:0] f_child_u_kv_cache_kv_write_req_position_o=0;
reg [1:0] f_child_u_kv_cache_kv_write_req_head_o=0;
reg [3:0] f_child_u_kv_cache_kv_write_req_row_word_o=0;
reg [18:0] f_child_u_kv_cache_kv_write_req_shadow_address_o=0;
reg [255:0] f_child_u_kv_cache_kv_write_req_data_o=0;
reg  f_child_u_kv_cache_kv_write_cpl_ready_o=0;
reg  f_child_u_kv_cache_kv_read_req_valid_o=0;
reg [2:0] f_child_u_kv_cache_kv_read_req_layer_o=0;
reg [11:0] f_child_u_kv_cache_kv_read_req_position_o=0;
reg [1:0] f_child_u_kv_cache_kv_read_req_head_o=0;
reg [3:0] f_child_u_kv_cache_kv_read_req_row_word_o=0;
reg [18:0] f_child_u_kv_cache_kv_read_req_shadow_address_o=0;
reg  f_child_u_kv_cache_kv_read_rsp_ready_o=0;
reg [71:0] f_child_u_kv_cache_committed_prefixes_o=0;
reg  f_child_u_kv_cache_busy_o=0;
reg  f_child_u_kv_cache_fail_closed_o=0;
reg  f_child_u_attention_start_ready_o=0;
reg  f_child_u_attention_query_ready_o=0;
reg  f_child_u_attention_private_cache_request_valid_o=0;
reg [1:0] f_child_u_attention_private_cache_request_kind_o=0;
reg [10:0] f_child_u_attention_private_cache_request_position_o=0;
reg  f_child_u_attention_private_cache_request_kv_head_o=0;
reg  f_child_u_attention_private_cache_response_ready_o=0;
reg  f_child_u_attention_result_valid_o=0;
reg [1023:0] f_child_u_attention_result_vector_o=0;
reg [7:0] f_child_u_attention_result_exponent_o=0;
reg  f_child_u_attention_result_last_o=0;
reg  f_child_u_attention_done_valid_o=0;
reg  f_child_u_attention_busy_o=0;
reg  f_child_u_attention_range_fault_o=0;
wire [2:0] f_w_seq_state_o;
wire [10:0] f_w_seq_position_o;
wire [2:0] f_w_seq_layer_o;
wire [4:0] f_w_seq_stage_o;
wire  f_w_stage_issue_o;
wire  f_w_export_issue_o;
wire  f_x_import_retire_o;
wire  f_x_stage_retire_o;
wire  f_x_export_retire_o;
wire [7:0] f_x_seq_stream_o;
wire  f_x_seq_fault_o;
always #5 clk=~clk;
board1_context2048_semantic_layer #(.ADDR_W(19)) dut(.clk(clk),.rst_n(rst_n),.clear_i(clear_i),.model_lock_i(model_lock_i),.upstream_fault_i(upstream_fault_i),.private_head_start_valid_i(private_head_start_valid_i),.private_head_start_ready_o(private_head_start_ready_o),.private_head_activation_exponent_i(private_head_activation_exponent_i),.private_head_activation_valid_i(private_head_activation_valid_i),.private_head_activation_ready_o(private_head_activation_ready_o),.private_head_activation_index_i(private_head_activation_index_i),.private_head_activation_mantissa_i(private_head_activation_mantissa_i),.private_head_activation_last_i(private_head_activation_last_i),.private_head_result_valid_o(private_head_result_valid_o),.private_head_result_ready_i(private_head_result_ready_i),.private_head_result_row_index_o(private_head_result_row_index_o),.private_head_result_scaled_raw_o(private_head_result_scaled_raw_o),.private_head_result_source_exponent_o(private_head_result_source_exponent_o),.private_head_result_last_o(private_head_result_last_o),.private_head_done_valid_o(private_head_done_valid_o),.private_head_done_ready_i(private_head_done_ready_i),.start_valid_i(start_valid_i),.start_ready_o(start_ready_o),.fixed_position_i(fixed_position_i),.input_exponent_i(input_exponent_i),.input_valid_i(input_valid_i),.input_ready_o(input_ready_o),.input_index_i(input_index_i),.input_mantissa_i(input_mantissa_i),.input_last_i(input_last_i),.result_valid_o(result_valid_o),.result_ready_i(result_ready_i),.result_index_o(result_index_o),.result_mantissa_o(result_mantissa_o),.result_exponent_o(result_exponent_o),.result_last_o(result_last_o),.done_valid_o(done_valid_o),.done_ready_i(done_ready_i),.private_word_req_valid_o(private_word_req_valid_o),.private_word_req_ready_i(private_word_req_ready_i),.private_word_req_index_o(private_word_req_index_o),.private_word_rsp_valid_i(private_word_rsp_valid_i),.private_word_rsp_ready_o(private_word_rsp_ready_o),.private_word_rsp_data_i(private_word_rsp_data_i),.private_word_rsp_fault_i(private_word_rsp_fault_i),.kv_write_req_valid_o(kv_write_req_valid_o),.kv_write_req_ready_i(kv_write_req_ready_i),.kv_write_req_layer_o(kv_write_req_layer_o),.kv_write_req_position_o(kv_write_req_position_o),.kv_write_req_head_o(kv_write_req_head_o),.kv_write_req_row_word_o(kv_write_req_row_word_o),.kv_write_req_shadow_address_o(kv_write_req_shadow_address_o),.kv_write_req_data_o(kv_write_req_data_o),.kv_write_cpl_valid_i(kv_write_cpl_valid_i),.kv_write_cpl_ready_o(kv_write_cpl_ready_o),.kv_write_cpl_fault_i(kv_write_cpl_fault_i),.kv_read_req_valid_o(kv_read_req_valid_o),.kv_read_req_ready_i(kv_read_req_ready_i),.kv_read_req_layer_o(kv_read_req_layer_o),.kv_read_req_position_o(kv_read_req_position_o),.kv_read_req_head_o(kv_read_req_head_o),.kv_read_req_row_word_o(kv_read_req_row_word_o),.kv_read_req_shadow_address_o(kv_read_req_shadow_address_o),.kv_read_rsp_valid_i(kv_read_rsp_valid_i),.kv_read_rsp_ready_o(kv_read_rsp_ready_o),.kv_read_rsp_data_i(kv_read_rsp_data_i),.kv_read_rsp_fault_i(kv_read_rsp_fault_i),.kv_endpoint_fault_i(kv_endpoint_fault_i),.committed_prefixes_o(committed_prefixes_o),.busy_o(busy_o),.range_fault_o(range_fault_o),.f_child_u_gate_scratch_private_read_data_o(f_child_u_gate_scratch_private_read_data_o),.f_child_u_up_scratch_private_read_data_o(f_child_u_up_scratch_private_read_data_o),.f_child_u_attention_scratch_private_read_data_o(f_child_u_attention_scratch_private_read_data_o),.f_child_u_rms_scratch_private_read_data_o(f_child_u_rms_scratch_private_read_data_o),.f_child_u_output_scratch_private_read_data_o(f_child_u_output_scratch_private_read_data_o),.f_child_u_hidden_state_private_read_data_o(f_child_u_hidden_state_private_read_data_o),.f_child_u_query_state_private_read_data_o(f_child_u_query_state_private_read_data_o),.f_child_u_key_state_private_read_data_o(f_child_u_key_state_private_read_data_o),.f_child_u_value_state_private_read_data_o(f_child_u_value_state_private_read_data_o),.f_child_u_rope_raw_scratch_private_read_data_o(f_child_u_rope_raw_scratch_private_read_data_o),.f_child_u_rmsnorm_start_ready_o(f_child_u_rmsnorm_start_ready_o),.f_child_u_rmsnorm_input_ready_o(f_child_u_rmsnorm_input_ready_o),.f_child_u_rmsnorm_result_valid_o(f_child_u_rmsnorm_result_valid_o),.f_child_u_rmsnorm_result_row_index_o(f_child_u_rmsnorm_result_row_index_o),.f_child_u_rmsnorm_result_mantissa_o(f_child_u_rmsnorm_result_mantissa_o),.f_child_u_rmsnorm_result_exponent_o(f_child_u_rmsnorm_result_exponent_o),.f_child_u_rmsnorm_result_last_o(f_child_u_rmsnorm_result_last_o),.f_child_u_rmsnorm_done_valid_o(f_child_u_rmsnorm_done_valid_o),.f_child_u_rmsnorm_busy_o(f_child_u_rmsnorm_busy_o),.f_child_u_rmsnorm_range_fault_o(f_child_u_rmsnorm_range_fault_o),.f_child_u_projection_start_ready_o(f_child_u_projection_start_ready_o),.f_child_u_projection_activation_ready_o(f_child_u_projection_activation_ready_o),.f_child_u_projection_private_word_req_valid_o(f_child_u_projection_private_word_req_valid_o),.f_child_u_projection_private_word_req_index_o(f_child_u_projection_private_word_req_index_o),.f_child_u_projection_private_word_rsp_ready_o(f_child_u_projection_private_word_rsp_ready_o),.f_child_u_projection_result_valid_o(f_child_u_projection_result_valid_o),.f_child_u_projection_result_row_index_o(f_child_u_projection_result_row_index_o),.f_child_u_projection_result_scaled_raw_o(f_child_u_projection_result_scaled_raw_o),.f_child_u_projection_result_source_exponent_o(f_child_u_projection_result_source_exponent_o),.f_child_u_projection_result_last_o(f_child_u_projection_result_last_o),.f_child_u_projection_done_valid_o(f_child_u_projection_done_valid_o),.f_child_u_projection_busy_o(f_child_u_projection_busy_o),.f_child_u_projection_fail_closed_o(f_child_u_projection_fail_closed_o),.f_child_u_normalizer_start_ready_o(f_child_u_normalizer_start_ready_o),.f_child_u_normalizer_input_ready_o(f_child_u_normalizer_input_ready_o),.f_child_u_normalizer_result_valid_o(f_child_u_normalizer_result_valid_o),.f_child_u_normalizer_result_row_index_o(f_child_u_normalizer_result_row_index_o),.f_child_u_normalizer_result_mantissa_o(f_child_u_normalizer_result_mantissa_o),.f_child_u_normalizer_result_exponent_o(f_child_u_normalizer_result_exponent_o),.f_child_u_normalizer_result_last_o(f_child_u_normalizer_result_last_o),.f_child_u_normalizer_done_valid_o(f_child_u_normalizer_done_valid_o),.f_child_u_normalizer_busy_o(f_child_u_normalizer_busy_o),.f_child_u_normalizer_range_fault_o(f_child_u_normalizer_range_fault_o),.f_child_u_elementwise_lane_request_ready_o(f_child_u_elementwise_lane_request_ready_o),.f_child_u_elementwise_lane_lut_request_o(f_child_u_elementwise_lane_lut_request_o),.f_child_u_elementwise_lane_lut_index_o(f_child_u_elementwise_lane_lut_index_o),.f_child_u_elementwise_lane_result_valid_o(f_child_u_elementwise_lane_result_valid_o),.f_child_u_elementwise_lane_result0_o(f_child_u_elementwise_lane_result0_o),.f_child_u_elementwise_lane_result1_o(f_child_u_elementwise_lane_result1_o),.f_child_u_elementwise_lane_auxiliary_o(f_child_u_elementwise_lane_auxiliary_o),.f_child_u_elementwise_lane_raw0_o(f_child_u_elementwise_lane_raw0_o),.f_child_u_elementwise_lane_raw1_o(f_child_u_elementwise_lane_raw1_o),.f_child_u_elementwise_lane_source_exponent_o(f_child_u_elementwise_lane_source_exponent_o),.f_child_u_elementwise_lane_range_fault_o(f_child_u_elementwise_lane_range_fault_o),.f_child_u_lookup_request_ready_o(f_child_u_lookup_request_ready_o),.f_child_u_lookup_response_valid_o(f_child_u_lookup_response_valid_o),.f_child_u_lookup_response_value_o(f_child_u_lookup_response_value_o),.f_child_u_lookup_response_fault_o(f_child_u_lookup_response_fault_o),.f_child_u_lookup_private_word_req_valid_o(f_child_u_lookup_private_word_req_valid_o),.f_child_u_lookup_private_word_req_index_o(f_child_u_lookup_private_word_req_index_o),.f_child_u_lookup_private_word_rsp_ready_o(f_child_u_lookup_private_word_rsp_ready_o),.f_child_u_lookup_busy_o(f_child_u_lookup_busy_o),.f_child_u_lookup_fail_closed_o(f_child_u_lookup_fail_closed_o),.f_child_u_kv_cache_stage_begin_ready_o(f_child_u_kv_cache_stage_begin_ready_o),.f_child_u_kv_cache_stage_payload_ready_o(f_child_u_kv_cache_stage_payload_ready_o),.f_child_u_kv_cache_pending_complete_o(f_child_u_kv_cache_pending_complete_o),.f_child_u_kv_cache_commit_ready_o(f_child_u_kv_cache_commit_ready_o),.f_child_u_kv_cache_attention_req_ready_o(f_child_u_kv_cache_attention_req_ready_o),.f_child_u_kv_cache_attention_rsp_valid_o(f_child_u_kv_cache_attention_rsp_valid_o),.f_child_u_kv_cache_attention_rsp_key_vector_o(f_child_u_kv_cache_attention_rsp_key_vector_o),.f_child_u_kv_cache_attention_rsp_key_exponent_o(f_child_u_kv_cache_attention_rsp_key_exponent_o),.f_child_u_kv_cache_attention_rsp_value_vector_o(f_child_u_kv_cache_attention_rsp_value_vector_o),.f_child_u_kv_cache_attention_rsp_value_exponent_o(f_child_u_kv_cache_attention_rsp_value_exponent_o),.f_child_u_kv_cache_attention_rsp_fault_o(f_child_u_kv_cache_attention_rsp_fault_o),.f_child_u_kv_cache_attention_rsp_from_pending_o(f_child_u_kv_cache_attention_rsp_from_pending_o),.f_child_u_kv_cache_kv_write_req_valid_o(f_child_u_kv_cache_kv_write_req_valid_o),.f_child_u_kv_cache_kv_write_req_layer_o(f_child_u_kv_cache_kv_write_req_layer_o),.f_child_u_kv_cache_kv_write_req_position_o(f_child_u_kv_cache_kv_write_req_position_o),.f_child_u_kv_cache_kv_write_req_head_o(f_child_u_kv_cache_kv_write_req_head_o),.f_child_u_kv_cache_kv_write_req_row_word_o(f_child_u_kv_cache_kv_write_req_row_word_o),.f_child_u_kv_cache_kv_write_req_shadow_address_o(f_child_u_kv_cache_kv_write_req_shadow_address_o),.f_child_u_kv_cache_kv_write_req_data_o(f_child_u_kv_cache_kv_write_req_data_o),.f_child_u_kv_cache_kv_write_cpl_ready_o(f_child_u_kv_cache_kv_write_cpl_ready_o),.f_child_u_kv_cache_kv_read_req_valid_o(f_child_u_kv_cache_kv_read_req_valid_o),.f_child_u_kv_cache_kv_read_req_layer_o(f_child_u_kv_cache_kv_read_req_layer_o),.f_child_u_kv_cache_kv_read_req_position_o(f_child_u_kv_cache_kv_read_req_position_o),.f_child_u_kv_cache_kv_read_req_head_o(f_child_u_kv_cache_kv_read_req_head_o),.f_child_u_kv_cache_kv_read_req_row_word_o(f_child_u_kv_cache_kv_read_req_row_word_o),.f_child_u_kv_cache_kv_read_req_shadow_address_o(f_child_u_kv_cache_kv_read_req_shadow_address_o),.f_child_u_kv_cache_kv_read_rsp_ready_o(f_child_u_kv_cache_kv_read_rsp_ready_o),.f_child_u_kv_cache_committed_prefixes_o(f_child_u_kv_cache_committed_prefixes_o),.f_child_u_kv_cache_busy_o(f_child_u_kv_cache_busy_o),.f_child_u_kv_cache_fail_closed_o(f_child_u_kv_cache_fail_closed_o),.f_child_u_attention_start_ready_o(f_child_u_attention_start_ready_o),.f_child_u_attention_query_ready_o(f_child_u_attention_query_ready_o),.f_child_u_attention_private_cache_request_valid_o(f_child_u_attention_private_cache_request_valid_o),.f_child_u_attention_private_cache_request_kind_o(f_child_u_attention_private_cache_request_kind_o),.f_child_u_attention_private_cache_request_position_o(f_child_u_attention_private_cache_request_position_o),.f_child_u_attention_private_cache_request_kv_head_o(f_child_u_attention_private_cache_request_kv_head_o),.f_child_u_attention_private_cache_response_ready_o(f_child_u_attention_private_cache_response_ready_o),.f_child_u_attention_result_valid_o(f_child_u_attention_result_valid_o),.f_child_u_attention_result_vector_o(f_child_u_attention_result_vector_o),.f_child_u_attention_result_exponent_o(f_child_u_attention_result_exponent_o),.f_child_u_attention_result_last_o(f_child_u_attention_result_last_o),.f_child_u_attention_done_valid_o(f_child_u_attention_done_valid_o),.f_child_u_attention_busy_o(f_child_u_attention_busy_o),.f_child_u_attention_range_fault_o(f_child_u_attention_range_fault_o),.f_w_seq_state_o(f_w_seq_state_o),.f_w_seq_position_o(f_w_seq_position_o),.f_w_seq_layer_o(f_w_seq_layer_o),.f_w_seq_stage_o(f_w_seq_stage_o),.f_w_stage_issue_o(f_w_stage_issue_o),.f_w_export_issue_o(f_w_export_issue_o),.f_x_import_retire_o(f_x_import_retire_o),.f_x_stage_retire_o(f_x_stage_retire_o),.f_x_export_retire_o(f_x_export_retire_o),.f_x_seq_stream_o(f_x_seq_stream_o),.f_x_seq_fault_o(f_x_seq_fault_o));
localparam integer FRESH_EXPONENT=31;

integer cycles=0,r_count=0,q_count=0,k,fd,delay_q=0;
reg monitor=0,pending=0;
reg [255:0] reply=0;
reg [255:0] model_words [0:227061];
reg [15:0] fresh_input [0:255];
reg [23:0] reference_rms [0:255],reference_q [0:255];
always @(negedge clk) begin
    private_word_req_ready_i=!pending && (cycles%7>=2);
    private_word_rsp_valid_i=pending && delay_q==0;
    private_word_rsp_data_i=reply;
end
always @(posedge clk) begin
    cycles=cycles+1;
    if(cycles>400000) $fatal(1,"OPERATING_TIMEOUT");
    if(private_word_rsp_valid_i && private_word_rsp_ready_o) pending=0;
    if(pending && delay_q>0) delay_q=delay_q-1;
    if(private_word_req_valid_o && private_word_req_ready_i) begin
        if(private_word_req_index_o>=227062) $fatal(1,"MODEL_ADDRESS");
        reply=model_words[private_word_req_index_o];pending=1;delay_q=3;
    end
    if(monitor) begin
        if(range_fault_o || dut.u_datapath.fault_q || dut.u_sequence.fault_q)
            $fatal(1,"ACTUAL_SOURCE_FAULT");
        if(dut.u_datapath.rms_ram_write_enable) begin
            if(r_count>=256 || dut.u_datapath.output_index_q!==r_count ||
               dut.u_datapath.rms_result_mantissa!==reference_rms[r_count][15:0] ||
               dut.u_datapath.rms_result_exponent!==reference_rms[r_count][23:16])
                $fatal(1,"RMS_VALUE_MISMATCH row=%0d",r_count);
            $fdisplay(fd,"R,%0d,%h,%h",r_count,dut.u_datapath.rms_result_mantissa,dut.u_datapath.rms_result_exponent);
            r_count=r_count+1;
        end
        if(dut.u_datapath.query_ram_write_enable) begin
            if(dut.u_datapath.current_stage_q!==5'd1 || q_count>=256 ||
               dut.u_datapath.output_index_q!==q_count ||
               dut.u_datapath.norm_result_mantissa!==reference_q[q_count][15:0] ||
               dut.u_datapath.norm_result_exponent!==reference_q[q_count][23:16])
                $fatal(1,"Q_VALUE_MISMATCH row=%0d",q_count);
            $fdisplay(fd,"Q,%0d,%h,%h",q_count,dut.u_datapath.norm_result_mantissa,dut.u_datapath.norm_result_exponent);
            q_count=q_count+1;
        end
    end
end
task start_work(input integer exponent);
begin
    wait(start_ready_o);
    @(negedge clk); input_exponent_i=exponent;fixed_position_i=0;start_valid_i=1;
    @(posedge clk);if(!start_ready_o) $fatal(1,"START_REJECTED");
    @(negedge clk);start_valid_i=0;
end
endtask
task feed_vector(input integer old);
integer row;
begin
    for(row=0;row<256;row=row+1) begin
        @(negedge clk);input_valid_i=0;
        if(row%11==0)repeat(2) @(negedge clk);
        input_valid_i=1;input_index_i=row;
        input_mantissa_i=old ? (3000+row%31) : fresh_input[row];input_last_i=row==255;
        @(posedge clk);if(!input_ready_o) $fatal(1,"INGRESS_REJECTED");
    end
    @(negedge clk);input_valid_i=0;
end
endtask
initial begin
    $readmemh("model.memh",model_words);$readmemh("input.memh",fresh_input);
    $readmemh("reference-rms.memh",reference_rms);$readmemh("reference-q.memh",reference_q);
    fd=$fopen("values.csv","w");model_lock_i=1;
    repeat(4) @(posedge clk);@(negedge clk);rst_n=1;
    start_work(-10);feed_vector(1);
    // Cancel with an actually outstanding old projection read. Deliver the
    // same held response through the real ownership/drain path after CLEAR.
    wait(pending);@(negedge clk);clear_i=1;
    repeat(2) @(posedge clk);@(negedge clk);clear_i=0;
    wait(!busy_o && !pending);monitor=1;
    start_work(FRESH_EXPONENT);feed_vector(0);
    wait(dut.u_datapath.stage_done_q && dut.u_datapath.current_stage_q==5'd1);
    @(negedge clk);
    if(r_count!=256 || q_count!=256) $fatal(1,"INCOMPLETE_VECTOR");
    for(k=0;k<256;k=k+1) begin
        if(dut.u_datapath.u_query_state.payload_mem[k]!==reference_q[k][15:0])
            $fatal(1,"QUERY_RAM_MISMATCH row=%0d",k);
    end
    if(dut.u_datapath.query_exponent_q!==reference_q[0][23:16])
        $fatal(1,"QUERY_EXPONENT_MISMATCH");
    $fclose(fd);$display("SEGMENT_OPERATING_PASS rms=%0d q=%0d cycles=%0d",r_count,q_count,cycles);
    $finish;
end
endmodule


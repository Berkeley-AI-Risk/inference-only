"""Save and verify local pilot checkpoints without a Git commit or push.

Objects contain this pilot's files and its draft plan only. Source code,
formulas, raw answers and unfinished work are preserved, not certified as
correct. Identical files share one compressed object across checkpoints.
"""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
CAMPAIGN = HERE.parent.parent
STORE = HERE/'checkpoints'
DRAFT = CAMPAIGN/'DRAFT-BASELINE-CONFINEMENT-AND-RMSNORM-PILOT.md'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_bytes(path, data):
    """Flush a complete replacement before atomically installing it."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.'+path.name+'.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def atomic_json(path, data):
    atomic_bytes(path, (json.dumps(data, indent=2, sort_keys=True)+'\n').encode())


def snapshot(reason):
    state_bytes = (HERE/'STATE.json').read_bytes()
    state = json.loads(state_bytes)
    active = list(state.get('active_owned_jobs', []))
    for child_state in HERE.glob('*/SETUP-STATE.json'):
        child = json.loads(child_state.read_text())
        active.extend(dict(job, project=str(child_state.parent.relative_to(HERE)))
                      for job in child.get('active_owned_jobs', []))
    files=[]
    for root,dirs,names in os.walk(HERE):
        dirs[:]=[name for name in dirs if name not in ['checkpoints','__pycache__']
                 and not (Path(root)/name).is_symlink()]
        files.extend(Path(root)/name for name in names
                     if not name.endswith(('.tmp','.pyc')) and name!='.DS_Store'
                     and not (Path(root)/name).is_symlink())
    if DRAFT.is_file():
        files.append(DRAFT)
    objects = STORE/'objects'
    objects.mkdir(parents=True, exist_ok=True)
    previous={}
    if (STORE/'LATEST.json').exists():
        pointer=json.loads((STORE/'LATEST.json').read_text())
        saved=(STORE/pointer['manifest']).read_bytes()
        if digest(saved)!=pointer['sha256']:raise ValueError('Previous checkpoint manifest changed')
        previous=json.loads(saved)['files']
    rows = {}
    for f in sorted(files):
        relative=str(f.relative_to(CAMPAIGN))
        stat=f.stat()
        metadata=dict(size=stat.st_size,mtime_ns=stat.st_mtime_ns,inode=stat.st_ino)
        old=previous.get(relative,{})
        if (f!=HERE/'STATE.json' and old.get('source_metadata')==metadata
            and old.get('bytes')==stat.st_size and (STORE/old['object']).is_file()):
            # Previously verified immutable object; full read-back verification
            # remains available through --verify-latest at milestones.
            rows[relative]=old
            continue
        data = state_bytes if f == HERE/'STATE.json' else f.read_bytes()
        identity = digest(data)
        obj = objects/(identity+'.gz')
        if not obj.exists():
            atomic_bytes(obj, gzip.compress(data, compresslevel=3, mtime=0))
        if digest(gzip.decompress(obj.read_bytes())) != identity:
            raise ValueError('Checkpoint object verification failed: '+str(obj))
        rows[relative] = dict(sha256=identity, bytes=len(data),
            object=str(obj.relative_to(STORE)),source_metadata=metadata if f!=HERE/'STATE.json' else None)
    stamp = datetime.now(timezone.utc)
    manifest = dict(schema='RMSNorm-local-checkpoint-v1',created_utc=stamp.isoformat(),
        reason=reason,scope='RMSNorm pilot directory and its draft plan only',
        status=state.get('status'),phase=state.get('phase'),
        active_owned_jobs=active,
        partial_proof_jobs_present=bool(active),
        proof_completion_claim=False,files=rows)
    path = STORE/(stamp.strftime('%Y%m%dT%H%M%S%fZ')+'.json')
    atomic_json(path, manifest)
    atomic_json(STORE/'LATEST.json',dict(manifest=path.name,sha256=digest(path.read_bytes())))
    return path


def verify_latest():
    pointer = json.loads((STORE/'LATEST.json').read_text())
    path = STORE/pointer['manifest']
    if digest(path.read_bytes()) != pointer['sha256']:
        raise ValueError('Checkpoint manifest changed')
    manifest = json.loads(path.read_text())
    for row in manifest['files'].values():
        data = gzip.decompress((STORE/row['object']).read_bytes())
        if digest(data) != row['sha256'] or len(data) != row['bytes']:
            raise ValueError('Checkpoint content mismatch')
    return dict(manifest=str(path),files_verified=len(manifest['files']),
        partial_proof_jobs_present=manifest['partial_proof_jobs_present'],
        proof_completion_claim=False)


if __name__ == '__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--reason',default='manual checkpoint')
    ap.add_argument('--verify-latest',action='store_true')
    args=ap.parse_args()
    if not args.verify_latest:
        snapshot(args.reason)
    print(json.dumps(verify_latest(),indent=2))

"""Retain the accepted engine row offset in the closed frontier source cut.

R2's SAT model could choose a different next engine group. R3 imports separately
checked prior accepted-group identity and actual one-edge group stability, and
retains the qualified prior Q group bound. No endpoint-health premise is added.
"""
import copy,json
from arithmetic import HERE,bv,eq,sha,write_json
from q_columns import TOP,J,n
from q_frontier_value import specification as original,root as old_root,PROVIDERS as old_providers
from q_frontier_control import specification as control_spec,body_files as control_files
from fact_composition import apply


PROVIDERS=old_providers+['q-frontier-rows']


def root():return old_root()+['(tilemeta-inv a model)']


def specification():
    decl,defs,rules,audit=original();rules=copy.deepcopy(rules)
    applications=[dict(kind='engine',provider='q-frontier-control',rule=name,substitution={})for name in control_spec()[2]]
    applications += [dict(kind='engine',provider='q-frontier-rows',rule=name,substitution={})for name in
        ['previous-engine-group-is-accepted-group','engine-group-stable-at-next-live-output']]
    applications.append(dict(kind='engine',provider='q-routing-r2',rule='actual-job-to-engine-result',substitution={'a':'an'}))
    facts,source_audit=apply(root(),applications)
    direct=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)','(qmd-inv a fr model)','(qi-inv a ch qi)',
        '(qc-inv a pc th ch lane tile)','(frame-inv an frn)','(qj-inv an qjn)',
        n(J+'result_valid_o','an'),eq(n(J+'job_q','an'),bv(0,4))]
    if not set(direct)<=set(root()):raise ValueError('Unclosed source-frame direct premise')
    rules['next-output-certified-frame']['assumptions']=direct+facts
    for record in audit:
        if record.get('provider')=='q-frontier-value':
            record.update(provider='q-frontier-value-r3',premises=root())
    return decl,defs,rules,dict(root_assumptions=root(),source_applications=source_audit,algebra_applications=audit)


def body_files():return control_files()+['q-frontier-rows/history.smt2','q-frontier-value-r3/history.smt2']


def prepare():
    decl,defs,rules,audit=specification();d=HERE/'q-frontier-value-r3';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',audit)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json','q-frontier-value-r3/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-one-edge-endpoint-value-closed-source-r3-v1',component='q-frontier-value-r3',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),
        checks_file='q-frontier-value-r3-CHECKS.json',providers=PROVIDERS,root_assumptions=root(),external_facts={},
        whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-frontier-value-r3-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed row-bound source frontier composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Accepted engine group and native group stability retained in frontier composition.')

; Previous healthy completed dot; next live output may have arbiter failure.

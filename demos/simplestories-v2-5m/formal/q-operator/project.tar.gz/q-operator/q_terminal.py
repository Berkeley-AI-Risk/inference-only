"""Native terminal shutdown, reset suppression and first-failure frontier."""
import json
from arithmetic import HERE,both,eq,sha,write_json
from q_columns import TOP,S,A,J,n
from q_normalizer_product import NORM,NS,nn,dn
from q_write_source import definitions as write_definitions,binding as write_binding


def definitions():
    defs=write_definitions()
    defs+='(declare-datatypes () ((PreviousFailure (previous-failure (pf-failed Bool)))))\n'
    defs+='(define-fun pf-zero () PreviousFailure (previous-failure false))\n'
    defs+=f'(define-fun pf-next ((a {S})) PreviousFailure (ite (not {n("reset_n")}) pf-zero (previous-failure {n(A+"fail_q")})))\n'
    defs+=f'(define-fun pf-inv ((a {S}) (pf PreviousFailure)) Bool (=> (and {n(A+"fail_q")} {n("u_native.child_reset_n")}) (not (pf-failed pf))))\n'
    return defs


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})',
        '(declare-const pf PreviousFailure)','(declare-const pfn PreviousFailure)']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)']
    T=f'(|{TOP}_t| a an)';product='(qn-native-step a an z zn)'
    inactive=f'(not {n("u_native.child_reset_n")})'
    outputs=both([f'(not {n(J+"result_valid_o")})',f'(not {n(J+"done_valid_o")})',f'(not {dn("stage_done_q")})',
        f'(not {nn("result_valid_o")})',f'(not {nn("done_valid_o")})','(not (Q-write-admission a z))'])
    from semantic_facts import substitute
    nextoutputs=substitute(outputs,{'a':'an','z':'zn'})
    rules={
        'sticky-arbiter-failure-is-root-terminal':dict(assumptions=H+[n(A+'fail_q')],conclusion=n('u_native.root_terminal')),
        'failed-root-resets-children-next-edge':dict(assumptions=H+[T,n(A+'fail_q')],conclusion=f'(not {n("u_native.child_reset_n","an")})'),
        'child-reset-suppresses-raw-norm-and-Q-write':dict(assumptions=H+['(qn-bind a z)',inactive],conclusion=outputs),
        'startup-after-child-reset-has-no-output':dict(assumptions=H+[product,inactive],conclusion=nextoutputs),
        'frontier-reset-base':dict(assumptions=H+[T,f'(not {n("reset_n")})'],conclusion='(pf-inv an pf-zero)'),
        'frontier-preserved':dict(assumptions=H+[T,'(pf-inv a pf)','(= pfn (pf-next a))'],conclusion='(pf-inv an pfn)')}
    return decl,definitions(),rules


def prepare():
    decl,defs,rules=specification();d=HERE/'q-terminal';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs);write_json(d/'WRITE-SOURCE.json',write_binding())
    bodies=['../model-consumption/connected/native.smt2','selector/native.smt2','q-normalizer-product/history.smt2','q-terminal/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv','q-normalizer-product-PLAN.json','q-normalizer-product/SOURCE-BINDING.json','q-terminal/WRITE-SOURCE.json',*bodies]
    plan=dict(schema='Typed-Q-terminal-frontier-v1',component='q-terminal',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-terminal-CHECKS.json',
        providers=['q-normalizer-product'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-terminal-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed native terminal frontier')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Native terminal-next-reset/frontier and source Q-write suppression prepared.')

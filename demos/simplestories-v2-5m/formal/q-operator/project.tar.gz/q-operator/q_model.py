"""Pure fixed-Q coefficient/product/prefix definitions and actual input binding.

Q-prefix is a finite mathematical recursion on an unsigned ten-bit count.
Its only inputs are the accepted vector, fixed model image and row identity.
It contains no hardware product, accumulator, private reply or output.
"""
import json
from arithmetic import HERE,OPERANDS,bv,both,eq,signed,sha,write_json
from q_columns import TOP,S,ENGINE,J,n

MODEL='(Array (_ BitVec 18) (_ BitVec 256))'
VECTOR='(Array (_ BitVec 10) (_ BitVec 16))'


def definitions():
    defs=f'(define-fun Q-base ((layer (_ BitVec 3)) (group (_ BitVec 6))) (_ BitVec 19) (bvadd (bvmul ((_ zero_extend 16) layer) {bv(28580,19)}) (bvmul ((_ zero_extend 13) group) {bv(640,19)})))\n'
    args=f'((vector {VECTOR}) (model {MODEL}) (layer (_ BitVec 3)) (group (_ BitVec 6)) (row (_ BitVec 6)) (column (_ BitVec 10)))'
    word=f'((_ extract 9 0) (bvlshr (model-Q-beat model (Q-base layer group) column) ((_ zero_extend 630) (bvmul ((_ zero_extend 4) row) {bv(10,10)}))))'
    defs+=f'(define-fun Q-weight ((model {MODEL}) (layer (_ BitVec 3)) (group (_ BitVec 6)) (row (_ BitVec 6)) (column (_ BitVec 10))) (_ BitVec 10) {word})\n'
    product=f'(* {signed("(select vector column)",16)} {signed("(Q-weight model layer group row column)",10)})'
    defs+='(define-fun Q-product '+args+' Int '+product+')\n'
    pargs=f'((vector {VECTOR}) (model {MODEL}) (layer (_ BitVec 3)) (group (_ BitVec 6)) (row (_ BitVec 6)) (count (_ BitVec 10)))'
    previous=f'(bvsub count {bv(1,10)})'
    body=f'(ite (= count {bv(0,10)}) 0 (+ (Q-prefix vector model layer group row {previous}) (Q-product vector model layer group row {previous})))'
    defs+='(define-fun-rec Q-prefix '+pargs+' Int '+body+')\n'
    return defs


def specification():
    decl=[f'(declare-const a {S})','(declare-const pc PrefixHistory)','(declare-const th TileHistory)','(declare-const ch CaptureHistory)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))',f'(declare-const model {MODEL})']
    context=[f'(|{TOP}_h| a)','(capture-inv a ch)','(prefix-inv a pc)','(lineage-inv a pc th lane tile)',
        '(tile-inv a th lane tile)','(qc-inv a pc th ch lane tile)','(macmodel-inv a ch model)']
    col='(pc-opcol pc)';vector='(j-memory (c-base ch))';layer=n(J+'layer_q');group=n(J+'group_q');row='(concat tile lane)'
    conclusion=both([eq('(th-A th)',f'(select {vector} {col})'),eq('(th-W th)',f'(Q-weight model {layer} {group} {row} {col})'),
        f'(bvult {col} {bv(256,10)})',f'(bvult {layer} {bv(6,3)})',f'(bvult {group} {bv(4,6)})'])
    rules={'current-Q-operands-fixed-model':dict(assumptions=context+['(qc-op a th tile)'],conclusion=conclusion)}
    return decl,definitions(),rules


def body_files():
    old=json.loads((OPERANDS/'macmodel-PLAN.json').read_text())
    return ['../model-consumption/'+b for b in old['bodies']]+['q-engine/history.smt2','q-columns-r3/history.smt2','q-model/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-model';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-fixed-model-input-binding-v1',component='q-model',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-model-CHECKS.json',
        old_providers=['macmodel'],new_providers=['q-columns-r3'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-model-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed fixed Q input binding')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Independent finite integer Q prefix and fixed-model input binding prepared.')

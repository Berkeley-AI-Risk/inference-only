"""Current Q row/vector identity at the source engine's accepted group start.

The snapshot is of the independently recorded accepted activation history, not
a native arithmetic result or unspecified RAM read. The invariant proves its
complete-argument ownership and stability throughout the actual engine job.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,ENGINE,J,n,phase,F
from q_model import MODEL,VECTOR,body_files as model_body_files


def definitions():
    fields=[('qi-vector',VECTOR),('qi-layer','(_ BitVec 3)'),('qi-group','(_ BitVec 6)'),('qi-owned','Bool')]
    defs='(declare-datatypes () ((QIdentity (q-identity '+' '.join('('+k+' '+t+')'for k,t in fields)+'))))\n'
    zero='(q-identity ((as const '+VECTOR+') '+bv(0,16)+') '+bv(0,3)+' '+bv(0,6)+' false)'
    defs+='(define-fun qi-zero () QIdentity '+zero+')\n'
    fresh='(q-identity (j-memory (c-base ch)) '+n(J+'layer_q')+' '+n(J+'group_q')+' '+eq(n(J+'job_q'),bv(0,4))+')'
    reset=f'(or (not {n(ENGINE+"reset_n")}) {n(ENGINE+"kill")})'
    begin=n(ENGINE+'g_tile[0].u_tile.begin_i')
    defs+=f'(define-fun qi-next ((a {S}) (ch CaptureHistory) (qi QIdentity)) QIdentity (ite {reset} qi-zero (ite {begin} {fresh} qi)))\n'
    active=both(['(qc-live a)',phase(1,2,3,4,5)])
    clauses=[f'(=> {active} '+both(['(qi-owned qi)',eq('(qi-vector qi)','(j-memory (c-base ch))'),eq('(qi-layer qi)',n(J+'layer_q')),eq('(qi-group qi)',n(J+'group_q')),'(j-active (c-base ch))','(j-complete (c-base ch))'])+')']
    params=f'((a {S}) (ch CaptureHistory) (qi QIdentity))'
    for i,c in enumerate(clauses):defs+=f'(define-fun qi-clause-{i} {params} Bool {c})\n'
    defs+=f'(define-fun qi-inv {params} Bool '+both([f'(qi-clause-{i} a ch qi)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def provider_fact():
    from q_model import specification
    r=specification()[2]['current-Q-operands-fixed-model']
    return '(=> '+both(r['assumptions'])+' '+r['conclusion']+')'


def specification():
    defs,clauses=definitions();H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const qi QIdentity)','(declare-const qin QIdentity)','(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))',f'(declare-const model {MODEL})']
    current=['(capture-inv a ch)','(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(tile-inv a th lane tile)','(qc-inv a pc th ch lane tile)','(qi-inv a ch qi)']
    step=[H('a'),H('an'),'(operand-native-step a an)',*current,'(= chn (capture-next a ch))','(capture-inv an chn)',
        '(= pcn (prefix-next a pc))','(prefix-inv an pcn)','(= thn (tile-next a th lane tile))','(lineage-inv an pcn thn lane tile)','(tile-inv an thn lane tile)',
        '(qc-inv an pcn thn chn lane tile)','(= qin (qi-next a ch qi))']
    parts=[f'(qi-clause-{i} an chn qin)'for i in range(len(clauses))]
    col='(pc-opcol pc)';row='(concat tile lane)'
    out=both(['(qi-owned qi)',eq('(th-A th)',f'(select (qi-vector qi) {col})'),
        eq('(th-W th)',f'(Q-weight model (qi-layer qi) (qi-group qi) {row} {col})'),
        f'(bvult {col} {bv(256,10)})',eq(n(ENGINE+'columns_q'),bv(256,10))])
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("reset_n")})','(capture-inv an (capture-zero an))'],conclusion='(qi-inv an (capture-zero an) qi-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qi-inv an chn qin)'),
        'current-fixed-Q-snapshot-operands':dict(assumptions=[H('a'),*current,'(macmodel-inv a ch model)','(qc-op a th tile)',provider_fact()],conclusion=out)}
    return decl,defs,rules


def body_files():return model_body_files()+['q-identity/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-identity';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-model-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-accepted-vector-identity-v1',component='q-identity',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-identity-CHECKS.json',
        old_providers=['parentcapture','macmodel'],new_providers=['q-columns-r3','q-model'],provider_facts=[provider_fact()],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-identity-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed accepted Q identity')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Accepted-vector/model row identity snapshot and stability induction prepared.')

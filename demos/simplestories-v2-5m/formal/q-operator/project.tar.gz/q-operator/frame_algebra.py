"""Actual frame's low48 positivity and exact signed/unsigned operand views."""
import json
from arithmetic import HERE,bv,both,eq,signed,sha,write_json


def specification():
    declarations=['(declare-const d (_ BitVec 35))','(declare-const m (_ BitVec 16))']
    low='(frame-low d m)'
    rules={
        'low48-product-nonnegative':dict(assumptions=[],conclusion=f'(= ((_ extract 47 47) {low}) #b0)'),
        'low48-zero-extension-is-signed-extension':dict(assumptions=[],dependencies=['low48-product-nonnegative'],
            conclusion=f'(= ((_ zero_extend 2) {low}) ((_ sign_extend 2) {low}))'),
        'scale18-is-unsigned16':dict(assumptions=[],conclusion=eq(signed('((_ zero_extend 2) m)',18),'(bv2int m)')),
        'low27-is-unsigned25':dict(assumptions=[],conclusion=eq(signed('((_ zero_extend 2) ((_ extract 24 0) d))',27),'(bv2int ((_ extract 24 0) d))')),
        'high27-is-signed10':dict(assumptions=[],conclusion=eq(signed('((_ sign_extend 17) ((_ extract 34 25) d))',27),signed('((_ extract 34 25) d)',10))),
        'legal-m16-is-m15-embedding':dict(assumptions=['(= ((_ extract 15 15) m) #b0)'],
            conclusion=both([eq('m','((_ zero_extend 1) ((_ extract 14 0) m))'),'(<= 0 (bv2int m))','(< (bv2int m) 32768)'])),
    }
    return declarations,'',rules


def prepare():
    declarations,defs,rules=specification();d=HERE/'frame-algebra';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','frame/history.smt2','frame-algebra/history.smt2'];paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-frame-algebra-v1',component='frame-algebra',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='frame-algebra-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'frame-algebra-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed frame algebra plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

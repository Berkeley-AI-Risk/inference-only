"""Preserve the independent raw-vector meaning through actual stage completion."""
import json
from arithmetic import HERE,bv,both,sha,write_json
from q_columns import S
from q_model import MODEL
from q_done_support import specification as support_spec,step,guard,body_files as support_files
from q_certificate import body_files as certificate_files
from q_capture_support import scope
from fact_composition import apply


def authority(a='a',h='h'):return both([guard(a,h),f'(bvult watch {bv(256,10)})'])


def definitions():
    args=f'((a {S}) (qa QArguments) (nc NormCapture) (h QOutput) (watch (_ BitVec 10)) (model {MODEL}))'
    return f'(define-fun qdone-inv {args} Bool (=> {authority()} (Q-record-matches qa model watch (select (nc-vec nc) watch))))\n'


def root():
    return step()+['(qd-source-inv an qan ncn nan hn)','(qcert-inv a z qa nc watch model)','(qdone-inv a qa nc h watch model)']


def composition():
    future=authority('an','hn')
    app=dict(kind='engine',provider='q-done-support',rule='retained-completed-reference-or-current-native-DONE',substitution={})
    facts,audit=apply(root()+[future],[app])
    premises=['(qcert-inv a z qa nc watch model)','(qdone-inv a qa nc h watch model)',
        '(=> '+future+' '+both(facts)+')']
    return premises,dict(root_assumptions=root(),discharged_guard=future,applications=audit,
        proof_rule='Implication introduction; retained-word congruence or current complete active capture certificate'),[app]


def specification():
    decl=support_spec()[0]+['(declare-const watch (_ BitVec 10))',f'(declare-const model {MODEL})']
    premises,audit,applications=composition()
    rules={'empty-completion-reset-base':dict(assumptions=[],conclusion='(qdone-inv an qa-zero nc-zero qh-zero watch model)'),
        'preserved':dict(assumptions=premises,conclusion='(qdone-inv an qan ncn hn watch model)'),
        'completed-reference-watched-value':dict(assumptions=['(qdone-inv a qa nc h watch model)',authority()],
            conclusion='(Q-record-matches qa model watch (select (nc-vec nc) watch))')}
    return decl,definitions(),rules,audit,applications


def body_files():
    result=[]
    for x in certificate_files()+support_files()+['q-done-certificate/history.smt2']:
        if x not in result:result.append(x)
    return result


PROVIDERS=['q-certificate','q-done-support']


def prepare():
    decl,defs,rules,audit,applications=specification();d=HERE/'q-done-certificate';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',audit)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-done-certificate/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-post-DONE-reference-value-certificate-v1',component='q-done-certificate',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-done-certificate-CHECKS.json',
        providers=PROVIDERS,root_assumptions=root(),applications=applications,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-done-certificate-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed completed reference numerical certificate')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Exact guarded completion certificate transport prepared.')

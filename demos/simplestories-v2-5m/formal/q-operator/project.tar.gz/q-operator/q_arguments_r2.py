"""Use the fully closed lifecycle invariant for persistent Q arguments."""
import json
from arithmetic import HERE,sha,write_json
from q_arguments import specification,body_files as original_files


PROVIDERS=['q-lifecycle-r2','norm-capture-r2']


def body_files():return [x.replace('q-lifecycle/history.smt2','q-lifecycle-r2/history.smt2').replace('q-arguments/history.smt2','q-arguments-r2/history.smt2')for x in original_files()]


def prepare():
    decl,defs,rules=specification();d=HERE/'q-arguments-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv',
        '../model-consumption/parentcapture-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-persistent-accepted-argument-snapshot-r2-v1',component='q-arguments-r2',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-arguments-r2-CHECKS.json',
        providers=PROVIDERS,old_providers=['parentcapture'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-arguments-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed qualified lifecycle argument binding')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Persistent Q argument proof prepared with closed lifecycle provider.')

"""Use the actual optimized native getters; unused descriptor flops were removed.

R1 generated references to unused job/layer registers that Yosys eliminated.
Every R1 receipt is rejected because the raw log contained parser errors.
Only the input-history descriptor and actual retained row count are claimed.
"""
import json
from arithmetic import HERE,sha,write_json
from norm_capture import specification as original,transition


def specification():return original(native_descriptors=False)


def prepare():
    decl,defs,rules=specification();d=HERE/'norm-capture-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture-r2/history.smt2']
    paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json',*bodies]
    plan=dict(schema='Typed-Q-normalizer-vector-capture-r2-v1',component='norm-capture-r2',bodies=bodies,
        source_manifest='selector-SOURCES.json',native_source='selector/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=decl,rules=rules,order=list(rules),checks_file='norm-capture-r2-CHECKS.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'norm-capture-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed vector capture revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Removed references to optimized-away native descriptor registers; actual state/model unchanged.')

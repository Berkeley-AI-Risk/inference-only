"""A stronger first-order query by uniform abstraction of every 26-bit bvmul.

If the new query is UNSAT for an arbitrary total F:BV26xBV26->BV26, it is UNSAT
when F is instantiated by standard bvmul. No arithmetic axiom is assumed.
The original concrete query is always retained. This is useful for tracking
the same products through storage, not for proving multiplication's meaning.
"""
import re

NAME='q_uniform_abstract_mul26'
DECL=f'(declare-fun {NAME} ((_ BitVec 26) (_ BitVec 26)) (_ BitVec 26))\n'


def transform(text):
    if NAME in text:raise ValueError('Abstract function is not fresh')
    count=len(re.findall(r'\(\s*bvmul\b',text))
    if not count or count!=text.count('(bvmul '):raise ValueError('Unsupported nonuniform multiply syntax')
    if '(check-sat)'not in text:raise ValueError('Missing concrete implication query')
    return DECL+text.replace('(bvmul ','('+NAME+' ')


def transform_arithmetic(text):
    add='q_uniform_abstract_add48'
    if add in text:raise ValueError('Abstract addition is not fresh')
    count=len(re.findall(r'\(\s*bvadd\b',text))
    if not count or count!=text.count('(bvadd '):raise ValueError('Unsupported nonuniform addition syntax')
    result=transform(text).replace('(bvadd ','('+add+' ')
    return f'(declare-fun {add} ((_ BitVec 48) (_ BitVec 48)) (_ BitVec 48))\n'+result

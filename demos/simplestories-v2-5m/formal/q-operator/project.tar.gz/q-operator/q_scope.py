"""Unfold the actual Q runtime guard and reset/wire aliases for composition."""
import json
from arithmetic import HERE,both,eq,bv,sha,write_json
from q_columns import TOP,S,J,A,ENGINE,n


def specification():
    decl=[f'(declare-const a {S})']
    fields=[n('reset_n'),n('u_native.child_reset_n'),f'(not {n(A+"fail_q")})',f'(not {n(J+"integrated_fail")})',
        eq(n(J+'job_q'),bv(0,4)),n(J+'reset_n'),n(ENGINE+'reset_n'),n(ENGINE+'result_valid_o')]
    rules={'live-Q-source-domain':dict(assumptions=[f'(|{TOP}_h| a)','(qc-live a)',n(J+'result_valid_o')],conclusion=both(fields))}
    return decl,'; Source-defined qc-live and actual reset/VALID aliases.\n',rules


def prepare():
    decl,defs,rules=specification();d=HERE/'q-scope';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['../model-consumption/connected/native.smt2','../model-consumption/parentcapture/history.smt2','q-engine/history.smt2','q-columns-r3/history.smt2','q-scope/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-current-source-scope-v1',component='q-scope',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-scope-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-scope-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed actual Q runtime scope')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual reset/VALID source aliases for current Q scope prepared.')

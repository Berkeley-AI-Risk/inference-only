"""Classify every live raw endpoint using actual root shutdown/reset.

A next-edge raw VALID implies the previous root had no sticky arbiter failure.
The current root may already have failed. This lets the one-edge completed-dot
theorem cover every live raw endpoint, rather than only a hand-picked fault case.
"""
import json
from arithmetic import HERE,sha,write_json
from q_columns import TOP,S,A,J,n


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)']
    rules={
        'live-next-raw-has-previous-nonfailed-root':dict(assumptions=H+['(operand-native-step a an)',n(J+'result_valid_o','an')],
            conclusion=f'(not {n(A+"fail_q")})'),
        'raw-reset-base':dict(assumptions=H+['(operand-native-step a an)',f'(not {n("reset_n")})'],
            conclusion=f'(not {n(J+"result_valid_o","an")})')}
    return decl,'; No arbiter-health restriction on the current raw endpoint.\n',rules


def body_files():return ['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','q-raw-scope/history.smt2']


PROVIDERS=[]


def prepare():
    decl,defs,rules=specification();d=HERE/'q-raw-scope';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        '../model-consumption/OPERAND-STEP.json',*bodies]
    plan=dict(schema='Typed-Q-all-current-raw-endpoint-classification-v1',component='q-raw-scope',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-raw-scope-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-raw-scope-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed all-current raw endpoint classification')
    write_json(path,plan)


if __name__=='__main__':prepare();print('All-current raw endpoint classification prepared without current arbiter-health assumption.')

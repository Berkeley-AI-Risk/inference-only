"""Owned first-delimited accumulation through the actual resetless tile MAC.

History contains only accepted operands and arithmetic on those histories.
There is no hypothesis about the native dot/product/accumulator result.
"""
import json
from arithmetic import HERE,MAC,bv,both,eq,sext,compile_model,sha,write_json

TOP='board1_projection_tile16'
S='|'+TOP+'_s|'
n=lambda x,s='a':f'(|{TOP}_n {x}| {s})'


def definitions():
    fields=[('o','Bool'),('p','Bool'),('f','Bool'),('pf','Bool'),
        ('A','(_ BitVec 16)'),('W','(_ BitVec 10)'),('P','(_ BitVec 26)'),
        ('owned','Bool'),('sum','(_ BitVec 48)'),('read','Bool'),('dot','(_ BitVec 35)')]
    defs='(declare-datatypes () ((TileHistory (tile-history '+' '.join('(th-'+k+' '+t+')'for k,t in fields)+'))))\n'
    zero='(tile-history false false false false '+bv(0,16)+' '+bv(0,10)+' '+bv(0,26)+' false '+bv(0,48)+' false '+bv(0,35)+')'
    defs+='(define-fun tile-zero () TileHistory '+zero+')\n'
    revoke=both(['true'])
    revoke='(or (not '+n('reset_n')+') '+n('kill_i')+' '+n('begin_i')+')'
    prod=f'(bvmul {sext("(th-A h)",10)} {sext("(th-W h)",16)})'
    sm=f'(bvadd (ite (th-pf h) {bv(0,48)} (th-sum h)) {sext("(th-P h)",22)})'
    values=[n('accept_i'),'(th-o h)',n('first_i'),'(th-f h)',
        f'(ite {n("accept_i")} {n("activation_i")} (th-A h))',
        f'(ite {n("accept_i")} ((_ extract 9 0) {n("weights_i")}) (th-W h))',
        f'(ite (th-o h) {prod} (th-P h))',
        '(ite (th-p h) (or (th-pf h) (th-owned h)) (th-owned h))',
        f'(ite (th-p h) {sm} (th-sum h))',
        both([n('read_i'),eq(n('read_lane_i'),bv(0,4)),'(th-owned h)']),
        f'(ite {both([n("read_i"),eq(n("read_lane_i"),bv(0,4)),"(th-owned h)"])} ((_ extract 34 0) (th-sum h)) (th-dot h))']
    defs+=f'(define-fun tile-next ((a {S}) (h TileHistory)) TileHistory (ite {revoke} tile-zero (tile-history '+ ' '.join(values)+')))\n'
    clauses=[eq(n('op_valid_q'),'(th-o h)'),eq(n('product_valid_q'),'(th-p h)'),
        f'(=> (th-o h) {both([eq(n("activation_q"),"(th-A h)"),eq(n("weight_q[0]"),"(th-W h)"),eq(n("op_first_q"),"(th-f h)")])})',
        f'(=> (th-p h) {both([eq(n("g_lane[0].u_mac.product_q"),"(th-P h)"),eq(n("product_first_q"),"(th-pf h)")])})',
        f'(=> (th-owned h) {eq(n("g_lane[0].u_mac.accumulator_q"),"(th-sum h)")})',
        f'(=> (th-read h) {eq(n("dot_o"),"(th-dot h)")})']
    for i,clause in enumerate(clauses):defs+=f'(define-fun tile-clause-{i} ((a {S}) (h TileHistory)) Bool (=> {n("reset_n")} {clause}))\n'
    defs+=f'(define-fun tile-inv ((a {S}) (h TileHistory)) Bool '+both([f'(tile-clause-{i} a h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda x:f'(|{TOP}_h| {x})'
    T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h TileHistory)','(declare-const hn TileHistory)']
    context=[H('a'),H('an'),T]
    step=context+['(tile-inv a h)','(= hn (tile-next a h))']
    parts=[f'(tile-clause-{i} an hn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=context+['(not '+n('reset_n')+')'],conclusion='(tile-inv an tile-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(tile-inv an hn)'),
        'consequence':dict(assumptions=[H('a'),'(tile-inv a h)',n('reset_n')],
            conclusion=both([f'(=> (th-owned h) {eq(n("g_lane[0].accumulated"),"(th-sum h)")})',f'(=> (th-read h) {eq(n("dot_o"),"(th-dot h)")})'])),
        'arbitrary-payload-base-witness':dict(assumptions=context+['(not '+n('reset_n')+')'],
            conclusion=eq(n('g_lane[0].u_mac.accumulator_q','an'),bv(0,48)),expected='sat')}
    return decl,defs,rules


def prepare():
    compile_model('tile',TOP,{'cluster-tile.sv':[MAC,TOP]})
    declarations,defs,rules=specification()
    (HERE/'tile/history.smt2').write_text(defs)
    bodies=['tile/native.smt2','tile/history.smt2']
    paths=['tile-SOURCES.json','tile/native.sv','tile/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-owned-tile-history-v1',component='tile',bodies=bodies,
        source_manifest='tile-SOURCES.json',native_source='tile/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=declarations,rules=rules,order=list(rules),checks_file='tile-CHECKS.json',external_facts={},
        whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'tile-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed owned-history plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':
    prepare();print('Frozen exact tile and total first-delimited lane0 history; all-lane lifting remains separate.')

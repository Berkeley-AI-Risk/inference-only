; Laws use the independent define-fun-rec Q-prefix in q-model/history.smt2.

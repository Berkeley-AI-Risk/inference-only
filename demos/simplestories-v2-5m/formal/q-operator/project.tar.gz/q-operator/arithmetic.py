"""Source-bound local arithmetic rules for the complete-Q continuation.

No HDL observers or correct-result input. This is a component, not Q completion.
Rule constructors are also used by the independent artifact/shape checker.
"""
from pathlib import Path
import json
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PILOT = HERE.parent
OPERANDS = PILOT/'model-consumption'
sys.path.insert(0, str(OPERANDS))
from source_policy import native_source, require_exact, sha, write_json, PUBLIC

MAC = 'board1_projection_dsp_accumulator'
MUL = 'board1_projection_postscale_mul'


def bv(x, w):
    return '(_ bv%d %d)' % (x % (1 << w), w)


def both(xs):
    return '(and ' + ' '.join(xs) + ')' if xs else 'true'


def eq(a, b):
    return '(= '+a+' '+b+')'


def sext(x, w):
    return '((_ sign_extend %d) %s)' % (w, x)


def signed(x, w):
    return '(ite (= ((_ extract %d %d) %s) #b1) (- (bv2int %s) %d) (bv2int %s))' % (w-1,w-1,x,x,1<<w,x)


def compile_model(label, top, selection):
    d=HERE/label
    source, rows=native_source(selection)
    require_exact(source,selection)
    recipe='\n'.join(['read_verilog -formal -sv -nosynthesis native.sv',
        'hierarchy -check -top '+top,'proc','opt_clean','flatten','async2sync',
        'opt_clean','dffunmap','memory_collect',
        'select -assert-none t:$assert t:$assume t:$anyconst t:$anyseq',
        'check -assert','write_json native.json','write_smt2 -wires native.smt2'])+'\n'
    if not d.exists():
        d.mkdir()
        (d/'native.sv').write_text(source)
        (d/'compile.ys').write_text(recipe)
        with (d/'compile.log').open('w') as f:
            result=subprocess.run(['yosys','-Q','compile.ys'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=120)
        if result.returncode:raise ValueError('Native compile failed: '+label)
    if (d/'native.sv').read_text()!=source or (d/'compile.ys').read_text()!=recipe:
        raise ValueError('Changed existing native arithmetic model')
    if re.search(r'implicitly declared|out of bounds|no driver',(d/'compile.log').read_text(),re.I):
        raise ValueError('Unsupported native arithmetic model')
    manifest=dict(sources=rows,top=top,parameters={},source_sha256=sha(source.encode()),
        native_smt_sha256=sha((d/'native.smt2').read_bytes()),
        internal_cuts=[],HDL_observer_additions=[],source_policy='exact-native-module-bodies',
        native_DSP_equivalence='explicit platform boundary; behavioral recurrence only')
    path=HERE/(label+'-SOURCES.json')
    if path.exists() and json.loads(path.read_text())!=manifest:raise ValueError('Changed model pins')
    write_json(path,manifest)
    return manifest


def specification(label):
    """Return canonical typed rules; all assumptions are explicit local domains."""
    top=MAC if label=='mac' else MUL
    S='|'+top+'_s|'
    n=lambda x,s='a':f'(|{top}_n {x}| {s})'
    H=lambda s:f'(|{top}_h| {s})'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})']
    rules={}
    defs=''
    if label=='mac':
        context=[H('a'),H('an'),f'(|{top}_t| a an)']
        product=f'(bvmul {sext(n("activation_i"),10)} {sext(n("weight_i"),16)})'
        p=n('product_q');pn=n('product_q','an')
        acc=n('accumulator_q');accn=n('accumulator_q','an')
        rhs=f'(bvadd (ite {n("first_i")} {bv(0,48)} {acc}) {sext(p,22)})'
        rules['native-product-recurrence']=dict(assumptions=context,conclusion=eq(pn,f'(ite {n("multiply_i")} {product} {p})'))
        rules['native-accumulator-recurrence']=dict(assumptions=context,conclusion=eq(accn,f'(ite {n("accumulate_i")} {rhs} {acc})'))
        rules['native-output']=dict(assumptions=[H('a')],conclusion=eq(n('accumulator_o'),acc))
        # Independent integer arithmetic and exact two's-complement bridge.
        A=n('activation_i');W=n('weight_i')
        legal=[f'(distinct {A} {bv(-32768,16)})',f'(distinct {W} {bv(-512,10)})']
        rules['signed-product-integer']=dict(assumptions=context+[n('multiply_i')],
            conclusion=eq(signed(pn,26),f'(* {signed(A,16)} {signed(W,10)})'))
        rules['legal-product-bound']=dict(assumptions=context+[n('multiply_i')]+legal,
            conclusion=both([f'(bvsge {pn} {bv(-32767*511,26)})',f'(bvsle {pn} {bv(32767*511,26)})']))
        # Owned history uses independently captured operands, not the native
        # product value. Ownership of the pending product is a tile obligation.
        declarations += ['(declare-const hp (_ BitVec 26))','(declare-const hs (_ BitVec 48))']
        owned=[eq(p,'hp'),eq(acc,'hs')]
        rules['owned-prefix-step']=dict(assumptions=context+owned,
            conclusion=eq(accn,f'(ite {n("accumulate_i")} (bvadd (ite {n("first_i")} {bv(0,48)} hs) {sext("hp",22)}) hs)'))
        rules['FIRST-discards-arbitrary-old-accumulator']=dict(assumptions=context+[n('accumulate_i'),n('first_i')],
            conclusion=eq(accn,sext(p,22)))
        # A witness guards against deriving a current dot from an unowned or
        # reset-assumed accumulator. This is not a proof dependency.
        rules['arbitrary-old-state-witness']=dict(assumptions=context+[f'(not {n("multiply_i")})',f'(not {n("accumulate_i")})'],
            conclusion=eq(accn,bv(0,48)),expected='sat')
    elif label=='mul':
        product=f'(bvmul {sext(n("a_i"),21)} {sext(n("b_i"),30)})'
        rules['native-multiplier-recurrence']=dict(assumptions=[H('a')],conclusion=eq(n('product_o'),product))
    else:raise ValueError('Unsupported local model')
    return declarations,defs,rules


def prepare(label):
    top=MAC if label=='mac' else MUL
    manifest=compile_model(label,top,{'cluster-tile.sv':[top]})
    declarations,defs,rules=specification(label)
    d=HERE/label
    (d/'history.smt2').write_text(defs)
    bodies=[label+'/native.smt2',label+'/history.smt2']
    paths=[label+'-SOURCES.json',label+'/native.sv',label+'/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-local-arithmetic-v1',component=label,bodies=bodies,
        source_manifest=label+'-SOURCES.json',native_source=label+'/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,
        rules=rules,order=list(rules),checks_file=label+'-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/(label+'-PLAN.json')
    if path.exists() and json.loads(path.read_text())!=plan:raise ValueError('Changed existing arithmetic plan; save a new revision')
    write_json(path,plan)


if __name__=='__main__':
    for label in sys.argv[1:] or ['mac','mul']:prepare(label)
    print('Frozen exact native arithmetic and typed rules; no solver started.')

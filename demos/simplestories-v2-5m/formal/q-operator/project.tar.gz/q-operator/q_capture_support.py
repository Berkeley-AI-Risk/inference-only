"""Source-only capture, descriptor and argument continuity for Q records.

No raw numerical equality is an invariant premise here. The watched index is
an arbitrary fixed observer; its low six bits select the already-proved lane.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,J,ENGINE,n
from q_normalizer_product import NORM,NS,nn,dn
from q_arguments_r3 import body_files as argument_files
from q_frontier_vector import body_files as vector_files


def scope(a='a',z='z'):
    return both([f'(qn-Q-mode {a})',dn('rst_n',a),f'(not {dn("fault_q",a)})',nn('rst_n',z),
        f'(bvuge {nn("state_q",z)} {bv(1,4)})',f'(bvule {nn("state_q",z)} {bv(12,4)})'])


def definitions():
    pactive=both([n(J+'reset_n'),f'(not {n(J+"integrated_fail")})',
        '(or '+' '.join(eq(n(J+'state_q'),bv(i,3))for i in [1,2,3,4])+')'])
    goal=both([eq(n(J+'job_q'),'(ql-p-job life)'),eq(n(J+'layer_q'),'(ql-p-layer life)')])
    return f'(define-fun pd-inv ((a {S}) (life QLifecycle)) Bool (=> {pactive} {goal}))\n'


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})',
        '(declare-const life QLifecycle)','(declare-const lifen QLifecycle)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const nc NormCapture)','(declare-const ncn NormCapture)','(declare-const qa QArguments)','(declare-const qan QArguments)',
        '(declare-const qj QJobHistory)','(declare-const qjn QJobHistory)','(declare-const fr FrameHistory)',
        '(declare-const watch (_ BitVec 10))','(declare-const tile (_ BitVec 2))','(declare-const lane (_ BitVec 4))']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)']
    current=[f'(|{TOP}_h| a)',f'(|{NORM}_h| z)','(qn-bind a z)',
        '(ql-inv a z life)','(capture-inv a ch)','(nc-inv z nc)','(qa-inv a z life ch nc qa)','(pd-inv a life)','(qj-inv a qj)']
    step=H+['(qn-native-step a an z zn)','(operand-native-step a an)',
        '(ql-inv a z life)','(ql-inv an zn lifen)','(= lifen (ql-next a z life))',
        '(capture-inv a ch)','(capture-inv an chn)','(= chn (capture-next a ch))',
        '(nc-inv z nc)','(nc-inv zn ncn)','(= ncn (nc-next z nc))',
        '(qa-inv a z life ch nc qa)','(qa-inv an zn lifen chn ncn qan)','(= qan (qa-next a z life ch qa))',
        '(pd-inv a life)','(qj-inv a qj)','(qj-inv an qjn)','(= qjn (qj-next a qj))']
    captured=both([n(J+'result_valid_o'),n(J+'result_ready_i'),eq(n(J+'job_q'),bv(0,4)),
        eq(nn('input_raw_i'),n(J+'result_scaled_raw_o')),eq(nn('input_source_exponent_i'),n(J+'result_source_exponent_o')),
        eq('((_ zero_extend 3) '+nn('input_row_index_i')+')',n(J+'result_row_index_o')),
        f'(bvult {nn("input_row_index_i")} {bv(256,10)})',
        '(qa-owned qa)','(qa-complete qa)',eq('(qa-vector qa)','(j-memory (c-base ch))'),
        eq('(qa-layer qa)',n(J+'layer_q')),eq('(qa-exponent qa)',n(J+'activation_exponent_q')),
        eq('(nc-job nc)',bv(0,4)),eq('(nc-layer nc)','(qa-layer qa)'),
        eq('(ql-n-epoch life)','(qa-epoch qa)')])
    nextguard=both([scope('an','zn'),f'(bvult watch (nc-count ncn))'])
    oldwatched=f'(bvult watch (nc-count nc))'
    newwatched=both([nn('record_write_enable'),eq(nn('input_row_index_i'),'watch')])
    rules={
        'descriptor-reset-base':dict(assumptions=H+['(qn-native-step a an z zn)',f'(not {dn("rst_n")})'],conclusion='(pd-inv an ql-zero)'),
        'descriptor-preserved':dict(assumptions=step,conclusion='(pd-inv an lifen)'),
        'Q-record-write-source-and-arguments':dict(assumptions=current+[scope(),nn('record_write_enable')],conclusion=captured),
        'watched-source-frame-row':dict(assumptions=current+[scope(),nn('record_write_enable'),'(frame-inv a fr)',
            eq(nn('input_row_index_i'),'watch'),eq('tile','((_ extract 5 4) watch)'),eq('lane','((_ extract 3 0) watch)')],
            conclusion=both([eq('((_ extract 5 4) (fr-R3 fr))','tile'),eq('((_ extract 3 0) (fr-R3 fr))','lane')])),
        'next-authoritative-record-comes-from-old-current-invocation':dict(assumptions=step+[nextguard],
            conclusion=both([scope(),eq('qan','qa'),'(qa-owned qa)','(qa-complete qa)',f'(bvult watch {bv(256,10)})',
                '(or '+oldwatched+' '+newwatched+')']))}
    return decl,definitions(),rules


def body_files():
    result=[]
    for x in vector_files()+argument_files()+['q-capture-support/history.smt2']:
        if x not in result:result.append(x)
    return result


PROVIDERS=['q-arguments-r3','q-lifecycle-r2','norm-capture-r2','q-job-r2','frame']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-capture-support';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','../model-consumption/parentcapture-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-native-raw-record-capture-support-v1',component='q-capture-support',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-capture-support-CHECKS.json',
        providers=PROVIDERS,old_providers=['parentcapture'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-capture-support-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed source-only raw record capture support')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Source-only descriptor, raw capture and persistent argument continuation prepared.')

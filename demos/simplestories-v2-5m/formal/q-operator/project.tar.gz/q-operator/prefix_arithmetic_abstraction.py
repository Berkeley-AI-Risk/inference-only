"""Uniformly abstract integer multiplication after pure-prefix forgetting.

Every bare SMT '*' token is replaced, including in helper definitions and
assumptions. The unchanged query is an instance with F(x,y)=x*y. The ordinary
engine type check must accept each application as binary Int×Int→Int. No
native 'bvmul', constraints, other tokens or whitespace are changed.
"""
import re
from prefix_abstraction import transform as forget_prefix

TOKEN=re.compile(r';[^\n]*|\|[^|]*\||"(?:""|[^"])*"|[()]|[^\s();]+')
FRESH='q_prefix_uniform_imul'
DECLARATION='(declare-fun '+FRESH+' (Int Int) Int)\n'


def tokens_replace(text,old,new):
    pieces=[];last=0;count=0
    for match in TOKEN.finditer(text):
        if match.group(0)!=old:continue
        pieces.extend([text[last:match.start()],new]);last=match.end();count+=1
    pieces.append(text[last:])
    return ''.join(pieces),count


def transform(text):
    if any(m.group(0)in [FRESH,'|'+FRESH+'|']for m in TOKEN.finditer(text)):raise ValueError('Multiplication abstraction symbol is not fresh')
    prefix=forget_prefix(text)
    rewritten,count=tokens_replace(prefix,'*',FRESH)
    if not count:raise ValueError('No integer multiplication to abstract')
    restored,back=tokens_replace(rewritten,FRESH,'*')
    if back!=count or restored!=prefix:raise ValueError('Nonuniform integer multiplication abstraction')
    return DECLARATION+rewritten

"""Actual Q write admissions, exponent updates and completion ownership.

History records only actual parent stage acceptance, source write/update
enables, and child DONE handshakes. It supplies no expected numerical value.
The native pure-normalizer refinement supplies result ordering/counts.
"""
import json,re,sys
from arithmetic import HERE,OPERANDS,bv,both,eq,sha,write_json
from q_columns import TOP,S,J,n
from q_normalizer_product import NORM,NS,nn,dn
from q_capture_support import scope,body_files as support_files
from q_write_source import definitions as write_definitions,binding as write_binding


def source_binding():
    original=write_binding();source=__import__('pathlib').Path(original['source']).read_text()
    matches=re.findall(r'^    board1_fixed_semantic_vector256_ram u_query_state \([\s\S]*?^    \);',source,re.M)
    if len(matches)!=1:raise ValueError('Unique actual query store instance required')
    ports={k:re.sub(r'\s+','',v)for k,v in re.findall(r'\.(\w+)\(([^()]*)\)',matches[0])}
    if ports!={'clk':'clk','private_read_enable_i':'query_ram_read_enable','private_read_address_i':'query_ram_read_address',
        'private_read_data_o':'query_ram_read_data','private_write_enable_i':'query_ram_write_enable',
        'private_write_address_i':'output_index_q[7:0]','private_write_data_i':'norm_result_mantissa'}:raise ValueError('Changed actual query store ports')
    fragment='''                                    STAGE_Q: begin
                                        query_exponent_q <=
                                            norm_result_exponent;
                                    end'''
    if source.count(fragment)!=1:raise ValueError('Changed exact Q exponent update branch')
    return dict(write_source=original,query_store_instance=matches[0],query_store_ports=ports,
        exponent_source_fragment=fragment,retained_query_RAM_claimed=False)


def qmode(a='a'):return both([f'(qn-Q-mode {a})',dn('rst_n',a),f'(not {dn("fault_q",a)})'])


def definitions(revision=1):
    defs=write_definitions()
    order=both([eq(nn('result_row_index_o'),dn('output_index_q')),
        eq(nn('result_last_o'),eq(dn('output_index_q'),f'(bvsub {dn("projection_result_count")} {bv(1,10)})'))])
    update=both([qmode(),f'(not {dn("clear_i")})',nn('result_valid_o'),dn('norm_result_ready'),order])
    defs+=f'(define-fun Q-exponent-update ((a {S}) (z {NS})) Bool {update})\n'
    fields=[('qh-owned','Bool'),('qh-layer','(_ BitVec 3)'),('qh-epoch','Int'),('qh-count','(_ BitVec 10)'),
        ('qh-Pdone','Bool'),('qh-Ndone','Bool'),('qh-exponent','(_ BitVec 8)')]
    defs+='(declare-datatypes () ((QOutput (q-output '+' '.join('('+k+' '+t+')'for k,t in fields)+'))))\n'
    defs+='(define-fun qh-zero () QOutput (q-output false '+bv(0,3)+' 0 '+bv(0,10)+' false false '+bv(0,8)+'))\n'
    accept='(or '+dn('stage_accept')+' '+dn('head_start_accept')+')'
    acceptedQ=both([dn('stage_accept'),f'(not {dn("head_start_accept")})',eq(dn('private_stage_i'),bv(1,5))])
    fresh=f'(q-output {acceptedQ} {dn("private_layer_i")} (+ (ql-epoch life) 1) {bv(0,10)} false false {dn("query_exponent_q")})'
    Pdone=both([qmode(),f'(not {dn("clear_i")})',n(J+'done_valid_o'),n(J+'done_ready_i')])
    Ndone=both([qmode(),f'(not {dn("clear_i")})',nn('done_valid_o'),nn('done_ready_i')])
    held='(q-output (qh-owned h) (qh-layer h) (qh-epoch h) (bvadd (qh-count h) (ite (Q-write-admission a z) '+bv(1,10)+' '+bv(0,10)+')) '+\
        '(or (qh-Pdone h) '+Pdone+') (or (qh-Ndone h) '+Ndone+') '+\
        '(ite (Q-exponent-update a z) '+nn('result_exponent_o')+' (qh-exponent h)))'
    revoke='(or (not '+dn('rst_n')+') '+dn('clear_i')+')'
    defs+=f'(define-fun qh-next ((a {S}) (z {NS}) (life QLifecycle) (h QOutput)) QOutput (ite {revoke} qh-zero (ite {accept} {fresh} {held})))\n'
    current=qmode();active=scope()
    identity=both(['(qh-owned h)',eq('(qh-layer h)',dn('current_layer_q')),eq('(qh-epoch h)','(ql-epoch life)')])
    full=eq('(na-emitted na)',bv(256,10))
    count=both([eq('(qh-count h)','(na-emitted na)'),eq(dn('output_index_q'),f'(ite {full} {bv(255,10)} (na-emitted na))'),
        eq(dn('output_done_q'),full),eq('(nc-rows nc)',bv(256,10)),eq('(na-rows na)',bv(256,10))])
    stageDone=both([dn('rst_n'),dn('stage_done_q'),eq(dn('current_stage_q'),bv(1,5))])
    beforestart=both([current,'(not '+dn('norm_start_seen_q')+')'])
    clauses=[f'(=> {current} {identity})',
        f'(=> {beforestart} (= (qh-count h) {bv(0,10)}))',
        f'(=> {active} {count})',
        f'(=> {current} (= (qh-Ndone h) {dn("norm_done_seen_q")}))',
        f'(=> {current} (= (qh-Pdone h) {dn("service_done_seen_q")}))',
        f'(=> (qh-Ndone h) '+both(['(qh-owned h)',eq('(qh-count h)',bv(256,10))])+')',
        f'(=> {stageDone} '+both(['(qh-owned h)','(qh-Ndone h)','(qh-Pdone h)',eq('(qh-count h)',bv(256,10))])+')',
        f'(=> (qh-owned h) (= {dn("query_exponent_q")} (qh-exponent h)))',
        f'(=> {both([active,f"(bvugt (na-emitted na) {bv(0,10)})"])} (= (qh-exponent h) (na-candidate na)))',
        f'(=> (qh-Ndone h) (= (qh-exponent h) (na-candidate na)))']
    if revision in [2,3]:
        clauses[7]=f'(=> {both(["(qh-owned h)",dn("rst_n")])} (= {dn("query_exponent_q")} (qh-exponent h)))'
        clauses.append(f'(=> {both(["(qh-owned h)",dn("rst_n"),"(not "+dn("fault_q")+")"])} '+
            both([eq(dn('current_stage_q'),bv(1,5)),eq('(qh-layer h)',dn('current_layer_q')),eq('(qh-epoch h)','(ql-epoch life)')])+')')
    if revision==3:
        clauses[1]=f'(=> {beforestart} '+both([eq('(qh-count h)',bv(0,10)),eq(dn('output_index_q'),bv(0,10)),f'(not {dn("output_done_q")})'])+')'
        healthy=both([dn('rst_n'),f'(not {dn("fault_q")})'])
        owner=both([healthy,'(qh-owned h)'])
        clauses.append(f'(=> {owner} (or '+eq(dn('engine_state_q'),bv(0,4))+' '+eq(dn('engine_state_q'),bv(2,4))+'))')
        stage=both([healthy,eq(dn('current_stage_q'),bv(1,5))])
        clauses.append(f'(=> {stage} (or '+ ' '.join(eq(dn('engine_state_q'),bv(k,4))for k in [0,2,8])+'))')
    args=f'((a {S}) (z {NS}) (life QLifecycle) (nc NormCapture) (na NormAlgorithm) (h QOutput))'
    for i,c in enumerate(clauses):defs+=f'(define-fun qh-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun qh-inv {args} Bool '+both([f'(qh-clause-{i} a z life nc na h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision)
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})',
        '(declare-const life QLifecycle)','(declare-const lifen QLifecycle)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const qa QArguments)','(declare-const qan QArguments)','(declare-const nc NormCapture)','(declare-const ncn NormCapture)',
        '(declare-const na NormAlgorithm)','(declare-const nan NormAlgorithm)','(declare-const qj QJobHistory)','(declare-const qjn QJobHistory)',
        '(declare-const h QOutput)','(declare-const hn QOutput)']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)']
    current=[f'(|{TOP}_h| a)',f'(|{NORM}_h| z)','(qn-bind a z)','(ql-inv a z life)',
        '(capture-inv a ch)','(qa-inv a z life ch nc qa)','(nc-inv z nc)','(na-inv z nc na)',
        '(pd-inv a life)','(qj-inv a qj)','(qh-inv a z life nc na h)']
    step=H+['(qn-native-step a an z zn)','(operand-native-step a an)',
        '(ql-inv a z life)','(ql-inv an zn lifen)','(= lifen (ql-next a z life))',
        '(capture-inv a ch)','(capture-inv an chn)','(= chn (capture-next a ch))',
        '(qa-inv a z life ch nc qa)','(qa-inv an zn lifen chn ncn qan)','(= qan (qa-next a z life ch qa))',
        '(nc-inv z nc)','(nc-inv zn ncn)','(= ncn (nc-next z nc))',
        '(na-inv z nc na)','(na-inv zn ncn nan)','(= nan (na-next z nc na))',
        '(pd-inv a life)','(pd-inv an lifen)','(qj-inv a qj)','(qj-inv an qjn)','(= qjn (qj-next a qj))',
        '(qh-inv a z life nc na h)','(= hn (qh-next a z life h))']
    parts=[f'(qh-clause-{i} an zn lifen ncn nan hn)'for i in range(len(clauses))]
    writegoal=both(['(qh-owned h)','(qa-owned qa)','(qa-complete qa)',eq('(qh-layer h)','(qa-layer qa)'),eq('(qh-epoch h)','(qa-epoch qa)'),
        eq('(qh-count h)',nn('result_row_index_o')),eq(dn('output_index_q'),'(qh-count h)'),
        f'(bvult (qh-count h) {bv(256,10)})',eq(nn('result_last_o'),eq('(qh-count h)',bv(255,10))),
        eq('(nc-count nc)',bv(256,10)),eq('(na-phase na)',bv(5,3)),eq('(na-emitted na)','(qh-count h)'),
        eq(nn('result_mantissa_o'),'(na-mantissa na)'),eq(nn('result_exponent_o'),'(na-candidate na)')])
    rules={'reset-base':dict(assumptions=H+['(qn-native-step a an z zn)',f'(not {dn("rst_n")})'],
            conclusion='(qh-inv an zn ql-zero nc-zero na-zero qh-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qh-inv an zn lifen ncn nan hn)'),
        'actual-Q-write-current-ordered-normalizer-output':dict(assumptions=current+['(Q-write-admission a z)'],conclusion=writegoal),
        'actual-Q-exponent-update':dict(assumptions=step+['(Q-exponent-update a z)'],conclusion=eq(dn('query_exponent_q','an'),
            nn('result_exponent_o')if revision==1 else f'(ite {dn("rst_n","an")} {nn("result_exponent_o")} {bv(0,8)})')),
        'stage-DONE-full-Q-writes-and-child-completions':dict(assumptions=current+[dn('rst_n'),dn('stage_done_q'),eq(dn('current_stage_q'),bv(1,5))],
            conclusion=both(['(qh-owned h)','(qh-Ndone h)','(qh-Pdone h)',eq('(qh-count h)',bv(256,10)),
                eq(dn('query_exponent_q'),'(na-candidate na)')]))}
    return decl,defs,rules


def body_files():
    import json
    norm=json.loads((HERE/'norm-algorithm-r2-PLAN.json').read_text())['bodies'];result=[]
    for x in support_files()+norm+['q-output-ownership/history.smt2']:
        if x not in result:result.append(x)
    return result


PROVIDERS=['q-capture-support','q-arguments-r3','q-lifecycle-r2','norm-algorithm-r2','q-job-r2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-output-ownership';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'SOURCE-BINDING.json',source_binding())
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-output-ownership/SOURCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-parent-write-exponent-DONE-ownership-v1',component='q-output-ownership',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-output-ownership-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-output-ownership-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed Q output ownership')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual Q admission, exponent register and full-completion history prepared.')

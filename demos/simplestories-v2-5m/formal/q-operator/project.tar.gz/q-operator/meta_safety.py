"""Accepted metadata discharges the integer engine's uint15 multiplier guard.

The native resetless metadata RAM is arbitrary outside the current accepted
prefix. Only accepted error-free metadata can become an owned multiplier.
Synchronous reads and the held frame preserve that legality through output.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from prefix_control import TOP,S,n
from frame import flag

phase=lambda *states:'(or '+' '.join(eq(n('state_q'),bv(i,3))for i in states)+')'


def legal(x):return both([eq('((_ extract 15 15) '+x+')','#b0'),f'(distinct {x} {bv(0,16)})'])


def definitions(revision=1):
    defs='(declare-datatypes () ((MetaRead (meta-read (mr-live Bool) (mr-row (_ BitVec 6))))))\n'
    defs+='(define-fun mr-zero () MetaRead (meta-read false '+bv(0,6)+'))\n'
    revoke=f'(or (not {n("reset_n")}) {n("kill")} {n("g_tile[0].u_tile.begin_i")})'
    defs+=f'(define-fun mr-next ((a {S}) (mr MetaRead)) MetaRead (ite {revoke} mr-zero (ite {n("issue")} (meta-read true ((_ extract 5 0) {n("issue_count_q")})) mr)))\n'
    memory=[];read=[]
    for t in range(4):
        memory.append(f'(select (|{TOP}_m g_tile[{t}].u_tile.multiplier_q| a) ((_ extract 3 0) row))')
        read.append(n(f'tile_multiplier[{t}]'))
    for name,choices in [('ms-memory',memory),('ms-read',read)]:
        v=choices[3]
        for t in reversed(range(3)):v=f'(ite (= ((_ extract 5 4) row) {bv(t,2)}) {choices[t]} {v})'
        defs+=f'(define-fun {name} ((a {S}) (row (_ BitVec 6))) (_ BitVec 16) {v})\n'
    active=phase(1,2,3,4,5);complete=phase(2,3,4,5)
    row7='((_ zero_extend 1) row)'
    owned=both([f'(bvult {row7} {n("valid_lanes_q")})',f'(or {complete} (and {phase(1)} (bvult {row7} {n("metadata_count_q")})))'])
    clauses=[
        f'(=> {active} '+both([f'(bvugt {n("valid_lanes_q")} {bv(0,7)})',f'(bvule {n("valid_lanes_q")} {bv(64,7)})',f'(bvult {n("metadata_count_q")} {n("valid_lanes_q")})'])+')',
        f'(forall ((row (_ BitVec 6))) (=> {owned} {legal("(ms-memory a row)")}))',
        f'(=> (mr-live mr) {legal("(ms-read a (mr-row mr))")})',
        f'(=> (and {phase(4)} {flag(0)}) '+both(['(mr-live mr)',eq('(mr-row mr)',n('row_pipe_q[0]')),eq(n('selected_tile_q'),'((_ extract 5 4) (mr-row mr))')])+')',
        f'(=> {phase(1,2,3)} (= {n("scale_valid_q")} {bv(0,4)}))',
        *[f'(=> (and {phase(4)} {flag(i)}) {legal("(fr-M"+str(i)+" fr)")})'for i in [1,2,3]],
    ]
    if revision==2:clauses.append(f'(=> {n("fail_q")} {phase(7)})')
    args=f'((a {S}) (mr MetaRead) (fr FrameHistory))'
    for i,c in enumerate(clauses):defs+=f'(define-fun ms-clause-{i} {args} Bool (=> {n("reset_n")} {c}))\n'
    defs+=f'(define-fun ms-inv {args} Bool '+both([f'(ms-clause-{i} a mr fr)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision);H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const mr MetaRead)','(declare-const mrn MetaRead)','(declare-const fr FrameHistory)','(declare-const frn FrameHistory)']
    step=[H('a'),H('an'),'(prefix-native-step a an)','(frame-inv a fr)','(frame-inv an frn)',
        '(= frn (frame-next a fr))','(= mrn (mr-next a mr))','(ms-inv a mr fr)']
    parts=[f'(ms-clause-{i} an mrn frn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("reset_n")})'],conclusion='(ms-inv an mr-zero frame-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(ms-inv an mrn frn)'),
        'output-multiplier-is-positive-uint15':dict(assumptions=[H('a'),n('reset_n'),'(ms-inv a mr fr)',n('result_valid_o')],conclusion=legal('(fr-M3 fr)'))}
    return decl,defs,rules


def prepare():
    decl,defs,rules=specification();d=HERE/'meta-safety';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','frame/history.smt2','meta-safety/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','frame-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-native-metadata-legality-v1',component='meta-safety',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='meta-safety-CHECKS.json',
        providers=['frame'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'meta-safety-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed native metadata legality')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Current-prefix metadata legality, synchronous read and held multiplier induction prepared.')

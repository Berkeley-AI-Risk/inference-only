"""Use the fully closed Q-job counter contract in actual result routing."""
import json
from arithmetic import HERE,sha,write_json
from q_routing import specification
from q_metadata import body_files as metadata_body_files


def body_files():return metadata_body_files()+['q-job-r2/history.smt2','q-routing-r2/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-routing-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/tilemeta-PLAN.json','q-engine/INSTANCE-BINDING.json','q-job-r2-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-native-result-routing-r2-v1',component='q-routing-r2',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-routing-r2-CHECKS.json',
        old_providers=['parentcapture','tilemeta'],new_providers=['q-job-r2'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-routing-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed actual Q result routing')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Source result wires, accepted descriptor and 4×64 global row routing prepared.')

"""Prove the missing sticky-fault phase invariant in the metadata component.

R1's saved SAT model has fail_q=true in EMIT, an unreachable combination.
The new fact is established from reset and preserved, not assumed as health.
"""
import json
from arithmetic import HERE,sha,write_json
from meta_safety import specification as original


def specification():return original(revision=2)


def prepare():
    decl,defs,rules=specification();d=HERE/'meta-safety-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','frame/history.smt2','meta-safety-r2/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','frame-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-native-metadata-legality-r2-v1',component='meta-safety-r2',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='meta-safety-r2-CHECKS.json',
        providers=['frame'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'meta-safety-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed strengthened metadata legality')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Metadata legality strengthened with an independently proved sticky-fault phase fact.')

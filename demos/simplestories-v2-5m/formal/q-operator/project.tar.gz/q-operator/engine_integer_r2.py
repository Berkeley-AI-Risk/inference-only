"""Readable engine integer theorem with closed component applications and cuts."""
import copy
import json
from arithmetic import HERE,both,sha,write_json
from frame import TOP,S
from engine_integer import specification as old_specification
from fact_composition import apply

PROVIDERS=['prefix-r2','tile-held','frame','lineage','sum-frame','math-fold-r2','frame-integer','word-scalar']


def applications():
    return [dict(kind='semantic',provider='frame-integer-function',substitution={'d':'(fr-D3 fr)','m':'(fr-M3 fr)'}),
        dict(kind='engine',provider='frame-integer',rule='current-output-integer',substitution={'h':'fr'}),
        dict(kind='engine',provider='sum-frame',rule='current-result-dot-argument',substitution={}),
        dict(kind='engine',provider='math-fold-r2',rule='current-sum-fits35',substitution={}),
        dict(kind='engine',provider='word-scalar',rule='signed-low35-preserves-bounded-value',substitution={'w':'(th-sum th)'}),
        dict(kind='engine',provider='math-fold-r2',rule='emit-count-and-reference',substitution={})]


def specification():
    declarations,_,old=old_specification();rule=old['completed-integer-fold-at-output']
    root=rule['assumptions'][:-4]
    facts,audit=apply(root,applications())
    arguments=f'((a {S}) (pc PrefixHistory) (th TileHistory) (mh MathHistory) (fr FrameHistory) (lane (_ BitVec 4)) (tile (_ BitVec 2)))'
    theorem=f'(define-fun Engine-integer-theorem {arguments} Bool (=> {both(root)} {rule["conclusion"]}))\n'
    rules={'joined-integer-output':dict(assumptions=facts,conclusion=rule['conclusion'])}
    return declarations,theorem,rules,root,audit


def prepare():
    declarations,theorem,rules,root,audit=specification();d=HERE/'engine-integer-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(theorem)
    write_json(d/'APPLICATIONS.json',dict(root_assumptions=root,applications=audit,engine_join_uses_only_checked_provider_consequences=True))
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2','sum-frame/history.smt2','math-fold-r2/history.smt2','engine-integer-r2/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','engine-integer-r2/APPLICATIONS.json',*[p+'-PLAN.json'for p in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-engine-integer-fact-composition-v1',component='engine-integer-r2',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='engine-integer-r2-CHECKS.json',
        providers=PROVIDERS,applications=applications(),root_assumptions=root,root_theorem=theorem,
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'engine-integer-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed integer fact composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Closed literal provider applications frozen; the engine join assumes only their proved consequences.')

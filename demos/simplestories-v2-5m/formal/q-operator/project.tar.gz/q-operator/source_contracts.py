"""Exact source-instance applications of closed arithmetic component theorems.

The native engine has one actual source instance. q-engine and q-meta-safety
check its full module bodies, ports, parameters, getter types and functional
histories. This rule specializes their universal theorems at that instance;
it never interprets a standalone SMT state as an unrelated parent state.
"""
import json
from arithmetic import HERE,both
from q_engine import translate


def target(name):
    if name=='engine-integer':
        p=json.loads((HERE/'engine-integer-r2-PLAN.json').read_text())
        assumptions=p['root_assumptions'];conclusion=p['rules']['joined-integer-output']['conclusion']
    elif name=='metadata-legality':
        p=json.loads((HERE/'meta-safety-r2-PLAN.json').read_text())
        r=p['rules']['output-multiplier-is-positive-uint15'];assumptions=r['assumptions'];conclusion=r['conclusion']
    else:raise ValueError('Unsupported exact source component contract')
    return dict(assumptions=[translate(x).strip()for x in assumptions],conclusion=translate(conclusion).strip())


def apply(root,name):
    from fact_composition import flattened
    available={x for formula in root for x in flattened(formula)}
    rule=target(name);needed={x for formula in rule['assumptions']for x in flattened(formula)}
    if not needed<=available:raise ValueError('Unclosed exact source-contract premises: '+str(sorted(needed-available)))
    facts=flattened(rule['conclusion'])
    return facts,dict(contract=name,source_instance='q-engine/INSTANCE-BINDING.json',
        metadata_instance='q-meta-safety/INSTANCE-BINDING.json'if name=='metadata-legality'else None,
        premises=rule['assumptions'],conclusion=rule['conclusion'],closed_by_root_or_previous_application=True)


def verify():
    from q_engine import verify as engine_verify
    from q_meta_safety import record,definitions
    from q_check import check
    engine_verify();check('meta-safety-r2',True)
    if json.loads((HERE/'q-meta-safety/INSTANCE-BINDING.json').read_text())!=record():raise ValueError('Changed parent metadata source specialization')
    if (HERE/'q-meta-safety/history.smt2').read_text()!=definitions():raise ValueError('Changed parent metadata functional history')

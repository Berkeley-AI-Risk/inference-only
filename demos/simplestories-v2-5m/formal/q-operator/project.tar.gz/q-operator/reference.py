"""Independent mathematical Q and finite normalization reference.

This executable specification is qualification support, not an engine proof.
It reads the pinned I0 model bytes and has no native-state observations.
"""
from arithmetic import PUBLIC,sha

IMAGE_SHA='cad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0'


def signed(x,w):
    x &= (1<<w)-1
    return x-(1<<w)if x&(1<<(w-1))else x


def shift(x,d):
    if d < -62:return None
    if d > 62:return 0
    if d < 0:
        value=x*(1<<(-d))
        return value if -(1<<63)<=value<(1<<63)else None
    q,r=divmod(abs(x),1<<d)
    if d and (r>(1<<(d-1)) or (r==(1<<(d-1))and q%2)):q+=1
    return -q if x<0 else q


def normalize(records):
    nonzero=[max(-32,min(31,e+abs(r).bit_length()-15))for r,e in records if r]
    if nonzero:
        for candidate in range(max(nonzero),32):
            values=[shift(r,candidate-e)for r,e in records]
            bad=next((i for i,x in enumerate(values)if x is None),None)
            if bad is not None:return [],dict(success=False,reason='helper',row=bad)
            if all(-32767<=x<=32767 for x in values):
                return [(i,x,candidate,int(i==len(values)-1))for i,x in enumerate(values)],dict(success=True)
        return [],dict(success=False,reason='no-fit')
    prefix=[]
    for i,(r,e)in enumerate(records):
        x=shift(r,-e)
        if x is None:return prefix,dict(success=False,reason='helper',row=i)
        prefix.append((i,x,0,int(i==len(records)-1)))
    return prefix,dict(success=True)


def image():
    raw=(PUBLIC.parents[1]/'assets/board1-real-semantic-image2048.bin').read_bytes()
    if sha(raw)!=IMAGE_SHA:raise ValueError('Wrong model image')
    return raw


def q(raw,layer,activations,exponent):
    if not 0<=layer<6 or len(activations)!=256 or not -128<=exponent<=127:
        raise ValueError('Invalid Q arguments')
    if any(not -32767<=a<=32767 for a in activations):raise ValueError('Illegal activation')
    rows=[]
    for r in range(256):
        group,lane=divmod(r,64)
        dot=0
        for c,a in enumerate(activations):
            bit=layer*914560*8+10*((group*256+c)*64+lane)
            word=int.from_bytes(raw[bit//8:bit//8+3],'little')
            w=signed(word>>(bit%8),10)
            if w==-512:raise ValueError('Illegal model coefficient')
            dot+=a*w
        at=(211920+304*layer+8*group+lane//8)*32+(lane%8)*4
        record=int.from_bytes(raw[at:at+4],'little')
        mult=(record>>8)&65535;row_exp=signed(record,8)
        if record>>24 or not 0<mult<32768:raise ValueError('Illegal metadata')
        e=exponent+row_exp-15
        if not -128<=e<=127:raise ValueError('Metadata exponent rejection')
        rows.append((dot*mult,e))
    return rows

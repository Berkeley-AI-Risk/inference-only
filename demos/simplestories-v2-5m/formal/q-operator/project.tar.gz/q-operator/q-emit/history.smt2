; The full owned Q dot is ready before the output pipeline first asserts VALID.

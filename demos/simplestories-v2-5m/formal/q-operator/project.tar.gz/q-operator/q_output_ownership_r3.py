"""Prove pre-start output controls and Q stage/engine context.

R2 retained three clean SAT induction attempts. The fresh audit identified
missing source invariants: pre-N-start index/done freshness, and healthy Q
stage/owner engine context. They are jointly proved, never caller assumptions.
The source step drops only the already-qualified 128 irrelevant MAC updates.
"""
import json
from arithmetic import HERE,both,sha,write_json
from q_columns import TOP
from q_normalizer_product import NORM
from q_exponent import ES,TOP as ETOP
from q_output_ownership_r2 import specification as original,body_files as original_files,PROVIDERS,output_binding,exponent_binding


def control_definition():
    from q_columns import S
    from q_normalizer_product import NS
    return f'(define-fun qe-control-step ((a {S}) (an {S}) (z {NS}) (zn {NS}) (e {ES}) (een {ES})) Bool '+\
        both(['(operand-native-step a an)',f'(|{NORM}_t| z zn)','(qn-bind a z)','(qn-bind an zn)',
            f'(|{ETOP}_t| e een)','(qe-bind a e)','(qe-bind an een)'])+')\n'


def specification():
    decl,defs,rules=original(revision=3)
    for rule in rules.values():
        rule['assumptions']=[x.replace('(qe-native-step a an z zn e een)','(qe-control-step a an z zn e een)')for x in rule['assumptions']]
    first={'full-native-product-implies-control-step':dict(assumptions=['(qe-native-step a an z zn e een)'],conclusion='(qe-control-step a an z zn e een)')}
    return decl,control_definition()+defs,{**first,**rules}


def body_files():return original_files()[:-1]+['q-output-ownership-r3/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-output-ownership-r3';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'SOURCE-BINDING.json',dict(output=output_binding(),exponent=exponent_binding(),
        control_step='Full native product implies the literal MAC-update weakening; native normalization and exponent transitions retained'))
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        '../model-consumption/OPERAND-STEP.json','q-engine/INSTANCE-BINDING.json','q-output-ownership-r3/SOURCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-parent-write-exponent-DONE-ownership-r3-v1',component='q-output-ownership-r3',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-output-ownership-r3-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-output-ownership-r3-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed Q source controller support')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Q pre-start output freshness and stage/owner mode support prepared.')

"""Actual Q job/engine wiring and global row decomposition; no result oracle."""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,ENGINE,J,A,n
from q_model import MODEL
from q_metadata import body_files as metadata_body_files

DP='u_native.u_six_layers.u_datapath.'


def specification():
    H=f'(|{TOP}_h| a)'
    decl=[f'(declare-const a {S})','(declare-const ch CaptureHistory)','(declare-const fr FrameHistory)','(declare-const qj QJobHistory)',f'(declare-const model {MODEL})']
    qmode=both([eq(n(DP+'engine_state_q'),bv(2,4)),eq(n(DP+'current_stage_q'),bv(1,5))])
    live=both([n('reset_n'),n('u_native.child_reset_n'),f'(not {n(A+"fail_q")})',f'(not {n(J+"integrated_fail")})',eq(n(J+'job_q'),bv(0,4))])
    valid=n(J+'result_valid_o');ev=n(ENGINE+'result_valid_o')
    payload=[eq(n(J+field),n(ENGINE+field))for field in ['result_row_index_o','result_scaled_raw_o','result_source_exponent_o']]
    row=n(J+'result_row_index_o');group=n(J+'group_q')
    split=both([eq('(fr-R3 fr)','((_ extract 5 0) '+row+')'),eq(group,'((_ zero_extend 4) ((_ extract 7 6) '+row+'))'),
        f'(bvult {row} {bv(256,13)})',eq(row,f'(bvadd (bvshl ((_ zero_extend 7) {group}) {bv(6,13)}) ((_ zero_extend 7) (fr-R3 fr)))'),
        eq(n(J+'layer_q'),'(qj-layer qj)'),eq(n(J+'activation_exponent_q'),'(qj-exponent qj)'),
        eq(n(J+'result_source_exponent_o'),'(fr-E3 fr)')])
    rules={
        'accepted-parent-Q-start-descriptor':dict(assumptions=[H,qmode,n(J+'start_transfer'),n(J+'incoming_descriptor_valid')],conclusion=both([
            eq(n(J+'fixed_job_i'),bv(0,4)),eq(n(J+'fixed_layer_i'),n(DP+'current_layer_q')),eq(n(J+'activation_exponent_i'),n(DP+'rms_exponent_q'))])),
        'actual-job-to-engine-result':dict(assumptions=[H,valid],conclusion=both([ev,*payload])),
        'actual-job-to-engine-transfer':dict(assumptions=[H,valid,n(J+'result_ready_i')],conclusion=both([ev,n(ENGINE+'result_ready_i'),*payload])),
        'current-Q-global-row-and-accepted-descriptor':dict(assumptions=[H,'(capture-inv a ch)','(tilemeta-inv a model)','(frame-inv a fr)','(qj-inv a qj)',live,valid],conclusion=split)}
    return decl,'; Exact source-wire and global Q row/descriptor routing.\n',rules


def body_files():return metadata_body_files()+['q-job/history.smt2','q-routing/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-routing';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/tilemeta-PLAN.json','q-engine/INSTANCE-BINDING.json','q-job-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-native-result-routing-v1',component='q-routing',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-routing-CHECKS.json',
        old_providers=['parentcapture','tilemeta'],new_providers=['q-job'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-routing-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed actual Q result routing')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Source result wires, accepted descriptor and 4×64 global row routing prepared.')

"""Capture-free literal applications of checked finite word semantic rules."""
from pruned_arithmetic import parse,emit
from word_derivation import expected


def substitute(text,mapping):
    ast=parse(text)
    if len(ast)!=1:raise ValueError('Expected one semantic formula')
    replacements={}
    for key,value in mapping.items():
        parsed=parse(value)
        if len(parsed)!=1:raise ValueError('Expected one substitution term')
        replacements[key]=parsed[0]
    def walk(node):
        if isinstance(node,list):return [walk(x)for x in node]
        return replacements.get(node,node)
    return emit(walk(ast[0]))


def fact(kind,mapping):
    target=expected(kind)['target']
    declared=[parse(d)[0][1]for d in target['declarations']]
    if set(mapping)!=set(declared):raise ValueError('Incomplete semantic application')
    conclusion=substitute(target['conclusion'],mapping)
    assumptions=[substitute(a,mapping)for a in target['assumptions']]
    return '(=> (and '+' '.join(assumptions)+') '+conclusion+')'if assumptions else conclusion

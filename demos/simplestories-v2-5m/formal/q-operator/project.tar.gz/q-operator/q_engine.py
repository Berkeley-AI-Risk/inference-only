"""Exact source specialization of the proved integer engine in its parent.

These are functional history/accessor substitutions at the one actual engine
instance. Source-level module substitution and the native frontend are explicit
trusted boundaries; no arithmetic output is connected to a desired-value input.
"""
import re
from arithmetic import HERE,OPERANDS,sha,write_json
from prefix_control import TOP as LOCAL
from lanes import TOP,S,ENGINE,verify_sources
from pruned_arithmetic import parse,emit,atoms

HISTORIES=['prefix-r2','frame','lineage','sum-frame','math-fold-r2']
PROVIDERS=['prefix-r2','tile-held','frame','frame-algebra','frame-integer','lineage','sum-frame','math-fold-r2','word-scalar','engine-integer-r2']


def translate(text):
    nodes=parse(text);parent=(OPERANDS/'connected/native.smt2').read_text();local=(HERE/'prefix/native.smt2').read_text()
    fields=sorted(set(re.findall(r'\|'+LOCAL+r'_(n|m) ([^|]+)\|',text)))
    mapping={f'|{LOCAL}_s|':S}
    for kind,field in fields:
        marker=f'(define-fun |{LOCAL}_{kind} {field}| ((state |{LOCAL}_s|)) '
        target=f'(define-fun |{TOP}_{kind} {ENGINE+field}| ((state {S})) '
        if local.count(marker)!=1 or parent.count(target)!=1:raise ValueError('Missing native engine getter '+field)
        sort=re.match(r'(Bool|\(_ BitVec \d+\)|\(Array \(_ BitVec \d+\) \(_ BitVec \d+\)\)) ',local.split(marker,1)[1]).group(1)
        if not parent.split(target,1)[1].startswith(sort+' '):raise ValueError('Changed parent getter type '+field)
        mapping[f'|{LOCAL}_{kind} {field}|']=f'|{TOP}_{kind} {ENGINE+field}|'
    # Native hierarchy functions in root assumptions are true combinational
    # constraints; the mapped module's full behavior is justified by binding().
    mapping[f'|{LOCAL}_h|']=f'|{TOP}_h|'
    def tr(x):return [tr(y)for y in x]if isinstance(x,list)else mapping.get(x,x)
    result=[tr(x)for x in nodes]
    if any(LOCAL in x for x in atoms(result)):raise ValueError('Incomplete engine specialization')
    return '\n'.join(emit(x)for x in result)+'\n'


def definitions():
    return translate('\n'.join((HERE/(p+'/history.smt2')).read_text()for p in HISTORIES))


def binding():
    verify_sources();source=(OPERANDS/'connected/projection-native.sv').read_text()
    start=source.index('    '+LOCAL+' u_engine (');end=source.index('    );',start)+6
    instance=source[start:end];ports={};i=instance.index('(')+1
    while i<len(instance):
        match=re.search(r'\.(\w+)\s*\(',instance[i:])
        if not match:break
        key=match.group(1);first=i+match.end();depth=1;j=first
        while depth:
            depth+=(instance[j]=='(')-(instance[j]==')');j+=1
        ports[key]=re.sub(r'\s+','',instance[first:j-1]);i=j
    expected=dict(clk='clk',reset_n='reset_n',clear_i='clear_i',model_locked_i='model_locked_i',upstream_fail_closed_i='upstream_fail_closed_i||fail_q',
        start_valid_i='engine_start_valid',start_ready_o='engine_start_ready',
        fixed_layer_i='(state_q==AD_IDLE)?group_layer_i:layer_q',fixed_job_i='(state_q==AD_IDLE)?group_job_i:job_q',fixed_group_i='(state_q==AD_IDLE)?group_index_i:group_q',
        activation_exponent_i='(state_q==AD_IDLE)?activation_exponent_i:activation_exponent_q',
        metadata_valid_i='engine_metadata_valid',metadata_ready_o='engine_metadata_ready',metadata_exponent_i='selected_metadata_exponent',metadata_multiplier_i='group_row_multiplier_i[metadata_lane_q*16+:16]',metadata_row_index_i='metadata_row',metadata_last_i='metadata_is_last',
        weight_valid_i='engine_weight_valid',weight_ready_o='engine_weight_ready',activation_i='activation_i',weight_data_i='weight_data_i',weight_last_i='weight_last_i',
        result_valid_o='engine_result_valid',result_ready_i='result_ready_i',result_row_index_o='engine_result_row',result_scaled_raw_o='engine_result_scaled',result_source_exponent_o='engine_result_exponent',result_last_o='engine_result_last',done_valid_o='engine_done_valid',done_ready_i='done_ready_i',busy_o='engine_busy',fail_closed_o='engine_fail')
    if ports!=expected:raise ValueError('Changed actual engine instance ports')
    from prepare import modules
    native=modules((HERE/'prefix/native.sv').read_text());parent=modules(source)
    for name,body in native.items():
        if parent.get(name)!=body:raise ValueError('Changed actual numerical engine subtree body '+name)
    return dict(schema='Exact-native-Q-engine-source-specialization-v1',path=ENGINE,instance=instance,ports=ports,parameters={},
        numerical_subtree={k:sha(v.encode())for k,v in native.items()},projection_sha256=sha(source.encode()),
        providers=PROVIDERS,functional_histories=HISTORIES,
        application='Universal identical-source engine theorem at this exact source instance and mapped functional histories; no extra reset or healthy-input assumption',
        trust='Source-level module substitution and native frontend',whole_Q_operator_proved=False)


def verify():
    from q_check import check
    for p in PROVIDERS:check(p,True)
    return binding()


def prepare():
    d=HERE/'q-engine';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(definitions());write_json(d/'INSTANCE-BINDING.json',binding())


if __name__=='__main__':prepare();print('Exact arithmetic-engine source instance and all histories specialized into unchanged qualified parent.')

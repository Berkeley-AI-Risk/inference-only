"""Previously accepted group identity survives the terminal output edge."""
import json
from arithmetic import HERE,bv,eq,sha,write_json
from q_columns import TOP,ENGINE,J,n
from q_frontier_control import specification as control_spec,body_files as control_files


def specification():
    decl=control_spec()[0]
    rules={
        'previous-engine-group-is-accepted-group':dict(assumptions=[f'(|{TOP}_h| a)','(tilemeta-inv a model)',
            '(qc-live a)',eq(n(ENGINE+'state_q'),bv(4,3))],conclusion=eq(n(ENGINE+'group_q'),n(J+'group_q'))),
        'engine-group-stable-at-next-live-output':dict(assumptions=control_spec()[2]['previous-certified-EMIT']['assumptions'],
            conclusion=eq(n(ENGINE+'group_q','an'),n(ENGINE+'group_q')))}
    return decl,'; The row offset uses the captured engine group, not a free next-state group.\n',rules


def body_files():return control_files()+['q-frontier-rows/history.smt2']


PROVIDERS=['q-frontier-control']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-frontier-rows';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        '../model-consumption/tilemeta-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-terminal-row-offset-continuity-v1',component='q-frontier-rows',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-frontier-rows-CHECKS.json',
        providers=PROVIDERS,old_providers=['tilemeta'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-frontier-rows-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed frontier row offset support')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Accepted engine group and one-edge row-offset continuity prepared.')

"""Continue a completed Q dot/frame across the single active fault frontier.

The new state is not assumed arbiter-healthy. No post-fault memory response or
API ownership rule is imported. The only model-valued support is the previous
healthy EMIT sum and its already certified metadata frames.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,ENGINE,J,n
from q_frontier_control import specification as control_spec,body_files as control_files
from q_raw import value_conclusion
from fact_composition import apply,flattened
from semantic_facts import substitute
from source_contracts import target


PROVIDERS=['q-frontier-control','q-emit','q-routing-r2','q-job-r2','engine-integer-r2','meta-safety-r2','q-metadata']


def root():
    old=control_spec()[2]['previous-certified-EMIT']['assumptions']
    return old+['(tile-inv a th lane tile)','(qc-inv a pc th ch lane tile)',
        '(macmodel-inv a ch model)','(qp-inv a pc th mh qi model lane tile)',
        '(qmd-inv a fr model)',
        '(sumframe-inv an thn frn lane tile)','(math-inv an pcn thn mhn)',
        '(ms-inv an mrn frn)',
        '(and (= ((_ extract 5 4) (fr-R3 frn)) tile) (= ((_ extract 3 0) (fr-R3 frn)) lane))']


def endpoint_binding():
    row='(fr-R3 frn)';record=f'(Q-metadata model (qi-layer qin) (qi-group qin) {row})'
    exponent=f'(Q-record-exponent (qj-exponent qjn) {record})'
    return both([n(ENGINE+'reset_n','an'),n(J+'reset_n','an'),
        eq(n(J+'result_source_exponent_o','an'),'(fr-E3 frn)'),
        eq('(fr-M3 frn)','((_ extract 23 8) '+record+')'),
        eq('(fr-E3 frn)','((_ extract 7 0) '+exponent+')'),
        f'(bvsge {exponent} {bv(-128,11)})',f'(bvsle {exponent} {bv(127,11)})',
        eq('(qi-layer qin)','(qj-layer qjn)'),eq(n(J+'group_q','an'),'(qi-group qin)'),
        eq(n(J+'result_row_index_o','an'),f'(bvadd (bvshl ((_ zero_extend 7) (qi-group qin)) {bv(6,13)}) ((_ zero_extend 7) {row}))'),
        '(qi-owned qin)'])


def application(label,rule,mapping=None):
    return dict(kind='engine',provider=label,rule=rule,substitution=mapping or {})


def composition():
    available=root();facts=[];audit=[]
    def add(label,rule,mapping=None):
        nonlocal available
        new,record=apply(available,[application(label,rule,mapping)])
        available+=new;facts.extend(new);audit.extend(record)
    for rule in control_spec()[2]:add('q-frontier-control',rule)
    add('q-emit','all-EMIT-completed-Q-dot')
    # This new source-only consequence is proved independently below, in the
    # identical native root context. Its explicit premises close literally.
    available.extend(flattened(endpoint_binding()));facts.extend(flattened(endpoint_binding()))
    audit.append(dict(provider='q-frontier-value',rule='next-output-certified-frame',premises=root(),conclusion=endpoint_binding()))
    add('q-routing-r2','actual-job-to-engine-result',{'a':'an'})
    add('q-job-r2','live-Q-output-prefix',{'a':'an','ch':'chn','qj':'qjn'})
    mapping={'a':'an','pc':'pcn','th':'thn','fr':'frn','mh':'mhn','mr':'mrn'}
    for name in ['metadata-legality','engine-integer']:
        contract=target(name)
        premises=[substitute(x,mapping)for x in contract['assumptions']]
        needed={x for formula in premises for x in flattened(formula)}
        present={x for formula in available for x in flattened(formula)}
        if not needed<=present:raise ValueError('Unclosed frontier source contract: '+str(sorted(needed-present)))
        conclusion=substitute(contract['conclusion'],mapping)
        new=flattened(conclusion);available+=new;facts+=new
        audit.append(dict(source_contract=name,substitution=mapping,premises=premises,conclusion=conclusion))
    direct=['(= qin qi)','(= (mh-S mhn) (mh-S mh))',root()[-1]]
    # Equality facts are independently provided by q-frontier-control.
    if not set(direct[:2])<={x for f in facts for x in flattened(f)}:raise ValueError('Missing frontier equality facts')
    return direct+facts,audit


def specification():
    decl=control_spec()[0]+['(declare-const mrn MetaRead)']
    premises,audit=composition()
    goal=substitute(value_conclusion(),
        {'a':'an','qi':'qin','qj':'qjn','fr':'frn'})
    rules={
        'next-output-certified-frame':dict(assumptions=root(),conclusion=endpoint_binding()),
        'next-output-raw-Q-value':dict(assumptions=premises,conclusion=goal,dependencies=['next-output-certified-frame'])}
    return decl,'; Previous healthy completed dot; next live output may have arbiter failure.\n',rules,audit


def body_files():return control_files()+['q-frontier-value/history.smt2']


def prepare():
    decl,defs,rules,audit=specification();d=HERE/'q-frontier-value';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',dict(root_assumptions=root(),applications=audit))
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json','q-frontier-value/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-one-edge-endpoint-value-v1',component='q-frontier-value',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),
        checks_file='q-frontier-value-CHECKS.json',providers=PROVIDERS,root_assumptions=root(),external_facts={},
        whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-frontier-value-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed fault-frontier value composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('One-edge completed-dot/frame value continuation prepared.')

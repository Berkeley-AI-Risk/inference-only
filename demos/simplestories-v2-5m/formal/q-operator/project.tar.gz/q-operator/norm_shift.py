"""Exact helper instance and current-vector normalizer output value.

This proves row-wise value and held-output correctness for the actual candidate.
The candidate-selection/whole-vector minimal-fit theorem is a separate join.
"""
import json,re
from arithmetic import HERE,bv,both,eq,sext,sha,write_json,native_source
from selector import TOP,S,n,HELPER
from norm_capture import phase,transition
from shift import TOP as LOCAL,definitions as helper_definitions
from pruned_arithmetic import parse,emit,atoms


def translated_history():
    source,_=helper_definitions();nodes=parse(source)
    local=(HERE/'shift/native.smt2').read_text();parent=(HERE/'selector/native.smt2').read_text()
    fields=sorted(set(re.findall(r'\|'+LOCAL+r'_n ([^|]+)\|',source)))
    mapping={f'|{LOCAL}_s|':S}
    for field in fields:
        marker=f'(define-fun |{LOCAL}_n {field}| ((state |{LOCAL}_s|)) '
        pm=f'(define-fun |{TOP}_n u_shift.{field}| ((state {S})) '
        if local.count(marker)!=1 or parent.count(pm)!=1:raise ValueError('Missing exact helper getter '+field)
        sort=re.match(r'(Bool|\(_ BitVec \d+\)) ',local.split(marker,1)[1]).group(1)
        if not parent.split(pm,1)[1].startswith(sort+' '):raise ValueError('Helper getter sort changed')
        mapping[f'|{LOCAL}_n {field}|']=f'|{TOP}_n u_shift.{field}|'
    def tr(x):return [tr(v)for v in x]if isinstance(x,list)else mapping.get(x,x)
    translated=[tr(x)for x in nodes]
    if any(LOCAL in x for x in atoms(translated)):raise ValueError('Unmapped helper symbol')
    return '\n'.join(emit(x)for x in translated)+'\n'


def source_binding():
    source=(HERE/'selector/native.sv').read_text();begin=source.index('    '+HELPER+' u_shift (');end=source.index('    );',begin)+6
    instance=source[begin:end]
    # Read port expressions as balanced parentheses, rather than a permissive
    # regex that could silently miss nested CLEAR/concatenation expressions.
    ports={};i=instance.index('(')+1
    while i<len(instance):
        match=re.search(r'\.(\w+)\s*\(',instance[i:])
        if not match:break
        key=match.group(1);start=i+match.end();depth=1;j=start
        while depth:
            depth+=(instance[j]=='(')-(instance[j]==')');j+=1
        ports[key]=re.sub(r'\s+','',instance[start:j-1]);i=j
    expected=dict(clk='clk',rst_n='rst_n',clear_i='clear_i||range_fault_o',
        request_valid_i='shift_request_valid',request_ready_o='shift_request_ready',
        request_value_i='{{14{selected_raw[49]}},selected_raw}',request_shift_i='requested_shift',
        response_valid_o='shift_response_valid',response_ready_i='shift_response_ready',
        response_result_o='shift_response_result',response_fault_o='shift_response_fault')
    if ports!=expected:raise ValueError('Changed actual normalizer helper connections')
    body,rows=native_source({'candidate.sv':[HELPER]})
    from source_policy import PREFIX
    if not source.endswith(body.removeprefix(PREFIX)):raise ValueError('Normalizer helper body differs from exact proved source')
    return dict(instance=instance,ports=ports,source_sha256=sha(source.encode()),helper_sources=rows,
        parameters={},clock='clk',history='Exact source module instance under the translated shift-next history',
        trust='Native frontend and universal identical-source module substitution',
        arithmetic_oracle=False)


def definitions():
    defs=translated_history()
    record=f'(select (nc-vec nc) {n("scan_index_q")})'
    val=sext('((_ extract 49 0) '+record+')',14)
    count=f'(bvsub {sext(n("candidate_q"),1)} {sext("((_ extract 57 50) "+record+")",1)})'
    defs+=f'(define-fun ns-current ((a {S}) (nc NormCapture)) ShiftHistory (shift-history #b000 {val} {count}))\n'
    idle=phase(0,1,2,3,4,5,7,8,9,10,11,12)
    wait=phase(6);result=phase(9)
    clauses=[
        f'(=> {idle} (= (sh-phase sh) #b000))',
        f'(=> {wait} '+both(['(distinct (sh-phase sh) #b000)',eq('(sh-value sh)','(sh-value (ns-current a nc))'),eq('(sh-count sh)','(sh-count (ns-current a nc))')])+')',
        f'(=> {result} '+both(['(not (sh-fault (ns-current a nc)))',
            f'(bvsge (sh-result (ns-current a nc)) {bv(-32767,64)})',f'(bvsle (sh-result (ns-current a nc)) {bv(32767,64)})',
            eq(n('result_mantissa_o'),'((_ extract 15 0) (sh-result (ns-current a nc)))')])+')',
    ]
    for i,clause in enumerate(clauses):defs+=f'(define-fun ns-clause-{i} ((a {S}) (nc NormCapture) (sh ShiftHistory)) Bool (=> {n("rst_n")} {clause}))\n'
    defs+=f'(define-fun ns-inv ((a {S}) (nc NormCapture) (sh ShiftHistory)) Bool '+both([f'(ns-clause-{i} a nc sh)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const nc NormCapture)','(declare-const ncn NormCapture)',
        '(declare-const sh ShiftHistory)','(declare-const shn ShiftHistory)']
    current=['(nc-inv a nc)','(shift-inv a sh)','(ns-inv a nc sh)']
    step=[H('a'),H('an'),'(norm-memory-native-step a an)',*current,
        '(= ncn (nc-next a nc))','(nc-inv an ncn)','(= shn (shift-next a sh))','(shift-inv an shn)']
    parts=[f'(ns-clause-{i} an ncn shn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("rst_n")})','(nc-inv an nc-zero)','(shift-inv an shift-zero)'],conclusion='(ns-inv an nc-zero shift-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(ns-inv an ncn shn)'),
        'actual-response-current-vector':dict(assumptions=[H('a'),n('rst_n'),*current,phase(6),n('shift_response_valid')],
            conclusion=both([eq(n('shift_response_result'),'(sh-result (ns-current a nc))'),eq(n('shift_response_fault'),'(sh-fault (ns-current a nc))')])),
        'actual-held-output-current-vector':dict(assumptions=[H('a'),n('rst_n'),*current,n('result_valid_o')],
            conclusion=both([eq(n('result_mantissa_o'),'((_ extract 15 0) (sh-result (ns-current a nc)))'),
                '(not (sh-fault (ns-current a nc)))',f'(bvsge (sh-result (ns-current a nc)) {bv(-32767,64)})',f'(bvsle (sh-result (ns-current a nc)) {bv(32767,64)})',
                eq(n('result_exponent_o'),n('candidate_q')),eq(n('result_row_index_o'),n('scan_index_q'))]))}
    return decl,defs,rules


def prepare():
    decl,defs,rules=specification();d=HERE/'norm-shift';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    write_json(d/'INSTANCE-BINDING.json',source_binding())
    bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture-r2/history.smt2','norm-shift/history.smt2']
    paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json','norm-capture-r2-PLAN.json','shift-PLAN.json','norm-shift/INSTANCE-BINDING.json',*bodies]
    plan=dict(schema='Typed-Q-normalizer-shift-composition-v1',component='norm-shift',bodies=bodies,source_manifest='selector-SOURCES.json',native_source='selector/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='norm-shift-CHECKS.json',
        providers=['norm-capture-r2','shift'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'norm-shift-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed actual helper composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Exact helper source/ports bound; actual candidate row-wise output proof prepared.')

`undef FORMAL
`define SYNTHESIS
`default_nettype none
module board1_projection_dsp_accumulator(
    input wire clk,multiply_i,accumulate_i,first_i,
    input wire signed [15:0] activation_i,
    input wire signed [9:0] weight_i,
    output wire signed [47:0] accumulator_o
);
    wire signed [26:0] weight_operand={{17{weight_i[9]}},weight_i};
    wire signed [17:0] activation_operand={{2{activation_i[15]}},activation_i};
`ifdef BOARD1_PROJECTION_MAC_NATIVE
    MULTALU27X18 #(
        .AREG_CLK("BYPASS"), .BREG_CLK("BYPASS"),
        .DREG_CLK("BYPASS"), .C_IREG_CLK("BYPASS"),
        .PSEL_IREG_CLK("BYPASS"), .PADDSUB_IREG_CLK("BYPASS"),
        .ADDSUB0_IREG_CLK("BYPASS"), .ADDSUB1_IREG_CLK("BYPASS"),
        .CSEL_IREG_CLK("BYPASS"), .CASISEL_IREG_CLK("BYPASS"),
        .ACCSEL_IREG_CLK("BYPASS"), .PREG_CLK("CLK0"), .PREG_CE("CE0"),
        .ADDSUB0_PREG_CLK("BYPASS"), .ADDSUB1_PREG_CLK("BYPASS"),
        .CSEL_PREG_CLK("BYPASS"), .CASISEL_PREG_CLK("BYPASS"),
        .ACCSEL_PREG_CLK("BYPASS"), .C_PREG_CLK("BYPASS"),
        .OREG_CLK("CLK0"), .OREG_CE("CE1"), .FB_PREG_EN("FALSE"),
        .SOA_PREG_EN("FALSE"), .PRE_LOAD(48'd0),
        .DYN_P_SEL("FALSE"), .P_SEL(1'b0),
        .DYN_P_ADDSUB("FALSE"), .P_ADDSUB(1'b0),
        .DYN_A_SEL("FALSE"), .A_SEL(1'b0),
        .DYN_ADD_SUB_0("FALSE"), .ADD_SUB_0(1'b0),
        .DYN_ADD_SUB_1("FALSE"), .ADD_SUB_1(1'b0),
        .DYN_C_SEL("FALSE"), .C_SEL(1'b0),
        .DYN_CASI_SEL("FALSE"), .CASI_SEL(1'b0),
        .DYN_ACC_SEL("TRUE"), .ACC_SEL(1'b0),
        .MULT12X12_EN("FALSE")
    ) u_signed_product (
        .DOUT(accumulator_o), .CASO(), .SOA(),
        .A(weight_operand), .SIA(27'd0), .B(activation_operand),
        .C(48'd0), .D(26'd0), .CASI(48'd0),
        .ACCSEL(!first_i), .PSEL(1'b0), .ASEL(1'b0),
        .PADDSUB(1'b0), .CSEL(1'b0), .CASISEL(1'b0),
        .ADDSUB(2'b00),
        .CLK({1'b0,clk}), .CE({accumulate_i,multiply_i}), .RESET(2'b00)
    );
`else
    reg signed [25:0] product_q;
    reg signed [47:0] accumulator_q;
    always @(posedge clk)begin
        if(multiply_i)product_q<=activation_i*weight_i;
        if(accumulate_i)accumulator_q<=(first_i ? 48'sd0 : accumulator_q)+
            {{22{product_q[25]}},product_q};
    end
    assign accumulator_o=accumulator_q;
`endif
endmodule

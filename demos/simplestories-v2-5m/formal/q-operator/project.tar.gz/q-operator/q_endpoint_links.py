"""Actual native output guards needed for unconditional raw-prefix endpoints."""
import json
from arithmetic import HERE,both,sha,write_json
from q_columns import TOP,S,J,n
from q_trace_links import body_files as trace_files


def specification():
    decl=[f'(declare-const a {S})']
    rules={}
    for signal in ['result_valid_o','done_valid_o']:
        rules[signal+'-requires-actual-job-reset']=dict(assumptions=[f'(|{TOP}_h| a)',n(J+signal)],conclusion=n(J+'reset_n'))
    return decl,'; Actual raw/DONE output validity implies its source instance is out of reset.\n',rules


def body_files():return trace_files()+['q-endpoint-links/history.smt2']


PROVIDERS=[]


def prepare():
    decl,defs,rules=specification();d=HERE/'q-endpoint-links';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json',*bodies]
    plan=dict(schema='Typed-Q-live-raw-endpoint-guard-v1',component='q-endpoint-links',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-endpoint-links-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-endpoint-links-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed live raw endpoint links')
    write_json(path,plan)

if __name__=='__main__':prepare();print('Actual raw/DONE reset guards frozen.')

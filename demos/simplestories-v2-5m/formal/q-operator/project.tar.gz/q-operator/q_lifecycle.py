"""Actual parent-stage epochs and child-invocation ownership.

Epochs change only at actual parent stage/head acceptance. Child ownership is
recorded at its own handshake and revoked at reset, CLEAR or DONE transfer.
Arbiter failure does not revoke this history: first-failing-cycle endpoints
must retain their accepted invocation. No numerical result is an input.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,J,n
from q_normalizer_product import NORM,NS,nn,dn


def definitions(revision=1):
    fields=[('ql-epoch','Int')]
    for who in ['n','p']:
        fields += [(f'ql-{who}-owned','Bool'),(f'ql-{who}-epoch','Int'),
            (f'ql-{who}-kind','(_ BitVec 4)'),(f'ql-{who}-stage','(_ BitVec 5)'),
            (f'ql-{who}-layer','(_ BitVec 3)'),(f'ql-{who}-job','(_ BitVec 4)')]
    defs='(declare-datatypes () ((QLifecycle (q-lifecycle '+' '.join('('+k+' '+t+')'for k,t in fields)+'))))\n'
    zeros=['0']
    for who in ['n','p']:zeros+=['false','0',bv(0,4),bv(0,5),bv(0,3),bv(0,4)]
    defs+='(define-fun ql-zero () QLifecycle (q-lifecycle '+' '.join(zeros)+'))\n'
    startN=both([nn('start_valid_i'),nn('start_ready_o')]);doneN=both([nn('done_valid_o'),nn('done_ready_i')])
    startP=n(J+'start_transfer');doneP=both([n(J+'done_valid_o'),n(J+'done_ready_i')])
    defs+=f'(define-fun ql-N-start ((a {S}) (z {NS})) Bool {startN})\n'
    defs+=f'(define-fun ql-P-start ((a {S})) Bool {startP})\n'
    accept='(or '+dn('stage_accept')+' '+dn('head_start_accept')+')'
    values=[f'(+ (ql-epoch h) (ite {accept} 1 0))']
    for who,start,done,layer,job in [('n',startN,doneN,nn('fixed_layer_i'),nn('fixed_job_i')),
            ('p',startP,doneP,n(J+'fixed_layer_i'),n(J+'fixed_job_i'))]:
        values += [f'(ite {start} true (ite {done} false (ql-{who}-owned h)))',
            f'(ite {start} (ql-epoch h) (ql-{who}-epoch h))',
            f'(ite {start} {dn("engine_state_q")} (ql-{who}-kind h))',
            f'(ite {start} {dn("current_stage_q")} (ql-{who}-stage h))',
            f'(ite {start} {layer} (ql-{who}-layer h))',f'(ite {start} {job} (ql-{who}-job h))']
    clear='(or (not '+dn('rst_n')+') '+dn('clear_i')+')'
    defs+=f'(define-fun ql-next ((a {S}) (z {NS}) (h QLifecycle)) QLifecycle (ite {clear} ql-zero (q-lifecycle '+ ' '.join(values)+')))\n'
    healthy=both([dn('rst_n'),f'(not {dn("fault_q")})'])
    nactive='(and (bvuge '+nn('state_q')+' '+bv(1,4)+') (bvule '+nn('state_q')+' '+bv(12,4)+'))'
    pactive=both([n(J+'reset_n'),f'(not {n(J+"integrated_fail")})',
        '(or '+' '.join(eq(n(J+'state_q'),bv(x,3))for x in [1,2,3,4])+')'])
    clauses=[f'(=> {nactive} (ql-n-owned h))',f'(=> {pactive} (ql-p-owned h))']
    for who,kinds,startseen,doneseen in [('n',[2,3,6],'norm_start_seen_q','norm_done_seen_q'),('p',[2,8],'service_start_seen_q','service_done_seen_q')]:
        owned=f'(ql-{who}-owned h)';guard=both([healthy,owned])
        clauses += [f'(=> {guard} '+both([
            eq(f'(ql-{who}-epoch h)','(ql-epoch h)'),eq(f'(ql-{who}-kind h)',dn('engine_state_q')),
            '(or '+' '.join(eq(f'(ql-{who}-kind h)',bv(x,4))for x in kinds)+')',
            eq(f'(ql-{who}-stage h)',dn('current_stage_q')),eq(f'(ql-{who}-layer h)',
                dn('current_layer_q')if who=='n'else'(ite '+eq(dn('engine_state_q'),bv(8,4))+' '+bv(7,3)+' '+dn('current_layer_q')+')'),
            '(=> (and '+eq(dn('engine_state_q'),bv(2,4))+' '+eq(dn('current_stage_q'),bv(1,5))+') '+eq(f'(ql-{who}-job h)',bv(0,4))+')',
            dn(startseen)])+')']
        # HEAD does not retain a done-seen bit, and cannot have a subsequent
        # child invocation before returning through parent IDLE.
        mode='(or '+' '.join(eq(dn('engine_state_q'),bv(x,4))for x in ([2,3,6]if who=='n'else[2]))+')'
        clauses += [f'(=> {both([healthy,mode,dn(doneseen)])} (not {owned}))']
        if revision==2:
            clauses += [f'(=> {both([healthy,mode,dn(doneseen)])} {dn(startseen)})']
    args=f'((a {S}) (z {NS}) (h QLifecycle))'
    for i,c in enumerate(clauses):defs+=f'(define-fun ql-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun ql-inv {args} Bool '+both([f'(ql-clause-{i} a z h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision)
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})',
        '(declare-const h QLifecycle)','(declare-const hn QLifecycle)']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)']
    step=H+['(qn-native-step a an z zn)','(ql-inv a z h)','(= hn (ql-next a z h))']
    parts=[f'(ql-clause-{i} an zn hn)'for i in range(len(clauses))]
    current=[f'(|{TOP}_h| a)',f'(|{NORM}_h| z)','(qn-bind a z)','(ql-inv a z h)',
        '(qn-Q-mode a)',dn('rst_n'),f'(not {dn("fault_q")})']
    nowner=both(['(ql-n-owned h)',eq('(ql-n-kind h)',bv(2,4)),eq('(ql-n-stage h)',bv(1,5)),
        eq('(ql-n-epoch h)','(ql-epoch h)'),eq('(ql-n-layer h)',dn('current_layer_q'))])
    powner=both(['(ql-p-owned h)',eq('(ql-p-kind h)',bv(2,4)),eq('(ql-p-stage h)',bv(1,5)),
        eq('(ql-p-epoch h)','(ql-epoch h)'),eq('(ql-p-layer h)',dn('current_layer_q'))])
    rules={'reset-base':dict(assumptions=H+['(qn-native-step a an z zn)',f'(not {dn("rst_n")})'],conclusion='(ql-inv an zn ql-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(ql-inv an zn hn)'),
        'live-Q-normalizer-current-invocation':dict(assumptions=current+[nn('result_valid_o')],conclusion=nowner),
        'accepted-Q-raw-common-invocation':dict(assumptions=current+[nn('input_valid_i'),nn('input_ready_o')],conclusion=both([nowner,powner,eq('(ql-n-epoch h)','(ql-p-epoch h)')]))}
    return decl,defs,rules


def body_files():return ['../model-consumption/connected/native.smt2','selector/native.smt2','q-normalizer-product/history.smt2','q-lifecycle/history.smt2']


PROVIDERS=['q-normalizer-product']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-lifecycle';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-parent-child-invocation-lifecycle-v1',component='q-lifecycle',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-lifecycle-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-lifecycle-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed parent invocation ownership')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual stage epochs and child invocation ownership prepared.')

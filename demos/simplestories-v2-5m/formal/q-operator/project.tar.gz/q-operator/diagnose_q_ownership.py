"""Save bounded countermodels for proposed source/ownership invariants."""
from datetime import datetime,timezone
import fcntl,json,subprocess,time,sys
from arithmetic import HERE,PILOT,sha
from q_columns import J,ENGINE,n
from q_normalizer_product import nn,dn
sys.path.insert(0,str(PILOT))
from checkpoint import atomic_bytes,atomic_json


def observations(label):
    if label=='q-arguments-r2':
        out=[dn(f,s)for s in ['a','an']for f in ['rst_n','clear_i','fault_q','engine_state_q','current_stage_q','current_layer_q',
            'stage_accept','head_start_accept','service_start_seen_q','norm_start_seen_q']]
        out += [n(J+f,s)for s in ['a','an']for f in ['state_q','job_q','layer_q','activation_exponent_q','integrated_fail',
            'activation_store_write','start_transfer','done_valid_o','result_valid_o']]
        out += [nn(f,s)for s in ['z','zn']for f in ['state_q','descriptor_valid','start_valid_i','start_ready_o','record_write_enable','input_valid_i','input_ready_o','input_last_i']]
        out += [f'(ql-{who}-{f} {h})'for h in ['life','lifen']for who in ['n','p']for f in ['owned','epoch','kind','stage','job']]
        out += [f'(qa-{f} {h})'for h in ['h','hn']for f in ['owned','complete','epoch','layer','exponent']]
        out += ['(nc-count nc)','(nc-count ncn)','(nc-job nc)','(nc-job ncn)',
            '(j-complete (c-base ch))','(j-complete (c-base chn))','(j-pos (c-base ch))','(j-pos (c-base chn))',
            '(= (qa-vector h) (j-memory (c-base ch)))','(= (qa-vector hn) (j-memory (c-base chn)))']
        return out
    if label=='q-lifecycle':
        fields=['rst_n','clear_i','fault_q','engine_state_q','current_stage_q','current_layer_q',
            'stage_accept','head_start_accept','norm_start_seen_q','service_start_seen_q','norm_done_seen_q','service_done_seen_q',
            'norm_start_valid','norm_start_ready','norm_done_valid','norm_done_ready','projection_start_valid','projection_start_ready',
            'projection_done_valid','projection_done_ready','output_done_q','norm_result_fire']
        out=[dn(f,s)for s in ['a','an']for f in fields]
        out += [nn(f,s)for s in ['z','zn']for f in ['state_q','start_valid_i','start_ready_o','done_valid_o','done_ready_i','result_valid_o']]
        out += [n(J+f,s)for s in ['a','an']for f in ['state_q','job_q','fixed_job_i','fixed_layer_i','start_transfer','done_valid_o','done_ready_i','integrated_fail']]
        out += [f'(ql-{who}-{f} {h})'for h in ['h','hn']for who in ['n','p']for f in ['owned','epoch','kind','stage','layer','job']]
        out += ['(ql-epoch h)','(ql-epoch hn)']
        return out
    out=[n(J+f,s)for s in ['a','an']for f in ['state_q','job_q','layer_q','group_q','activation_exponent_q','result_row_index_o','result_valid_o','integrated_fail']]
    out += [n(ENGINE+f,s)for s in ['a','an']for f in ['state_q','scale_valid_q','advance','result_row_index_o','result_source_exponent_o','reset_n']]
    out += [f'(fr-{f}{i} {h})'for h in ['fr','frn']for f in ['R','M','E']for i in [2,3]]
    out += ['(qc-live a)','(qmd-live a)','(qi-layer qi)','(qi-group qi)','(qi-owned qi)','(qj-layer qj)','(qj-layer qjn)','(qj-exponent qj)','(qj-exponent qjn)','(qi-owned qin)']
    from q_frontier_value import endpoint_binding
    from fact_composition import flattened
    out += flattened(endpoint_binding())
    return out


def main():
    with(HERE/'RUN.lock').open('w')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        statepath=HERE/'STATE.json';state=json.loads(statepath.read_text())
        if state['active_owned_jobs']:raise ValueError('Another owned batch is active')
        cases=([('q-arguments-r2','preserved-'+str(i))for i in [3,5]]if '--arguments'in sys.argv else
            [('q-frontier-value-r2','next-output-certified-frame')]+[('q-lifecycle','preserved-'+str(i))for i in [2,3,4,5]])
        for label,rule in cases:
            prior=json.loads((HERE/(label+'-CHECKS.json')).read_text())['rules'][rule]
            if prior['answers']!=['sat']:raise ValueError('Not a saved SAT case')
            source=(HERE/prior['receipt']).parent/prior['engine_query_file'];text=source.read_text()
            diagnostic=text+'(get-value ('+' '.join(observations(label))+'))\n'
            d=HERE/'diagnostics'/(label+'-'+rule+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));d.mkdir(parents=True)
            atomic_bytes(d/'query.smt2',diagnostic.encode());command=['z3','-memory:8192','-T:55',str(d/'query.smt2')]
            begin=time.monotonic()
            with(d/'z3.log').open('w')as log:
                proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                state['active_owned_jobs']=[dict(pid=proc.pid,component=label+'-diagnostic',rule=rule,command=command)]
                atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
                try:code=proc.wait(timeout=60)
                except subprocess.TimeoutExpired:proc.kill();proc.wait();code=-1
            seconds=time.monotonic()-begin;raw=(d/'z3.log').read_bytes()
            atomic_json(d/'RESULT.json',dict(rule=rule,diagnostic_only=True,proof_result=False,exit_code=code,seconds=seconds,
                canonical_source_sha256=sha(source.read_bytes()),query_sha256=sha(diagnostic.encode()),log_sha256=sha(raw)))
            state['active_owned_jobs']=[];state['solver_seconds']+=seconds
            atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
            print(label,rule,str(d.relative_to(HERE)),raw.decode(),flush=True)


if __name__=='__main__':main()

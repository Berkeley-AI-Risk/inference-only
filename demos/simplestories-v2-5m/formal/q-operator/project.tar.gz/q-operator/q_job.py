"""Accepted Q-job descriptor and ordered output-prefix ownership.

History records only the actual accepted job start, result transfers and
cancellation. No engine result value or expected output count is an input.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,J,n

phase=lambda *states:'(or '+' '.join(eq(n(J+'state_q'),bv(i,3))for i in states)+')'


def definitions(revision=1):
    defs='(declare-datatypes () ((QJobHistory (q-job-history (qj-owned Bool) (qj-layer (_ BitVec 3)) (qj-exponent (_ BitVec 8)) (qj-count (_ BitVec 13))))))\n'
    defs+='(define-fun qj-zero () QJobHistory (q-job-history false '+bv(0,3)+' '+bv(0,8)+' '+bv(0,13)+'))\n'
    live=both([n(J+'reset_n'),f'(not {n(J+"integrated_fail")})'])
    qscope=both([live,eq(n(J+'job_q'),bv(0,4)),phase(1,2,3,4)])
    defs+=f'(define-fun qj-scope ((a {S})) Bool {qscope})\n'
    revoke='(or (not '+n(J+'reset_n')+') '+n(J+'clear_i')+' '+n(J+'integrated_fail')+' (and '+n(J+'done_valid_o')+' '+n(J+'done_ready_i')+'))'
    goodstart=both([n(J+'start_transfer'),n(J+'incoming_descriptor_valid')])
    fresh='(ite '+eq(n(J+'fixed_job_i'),bv(0,4))+' (q-job-history true '+n(J+'fixed_layer_i')+' '+n(J+'activation_exponent_i')+' '+bv(0,13)+') qj-zero)'
    increment=both(['(qj-owned qj)',n(J+'result_valid_o'),n(J+'result_ready_i')])
    hold=f'(q-job-history (qj-owned qj) (qj-layer qj) (qj-exponent qj) (bvadd (qj-count qj) (ite {increment} {bv(1,13)} {bv(0,13)})))'
    defs+=f'(define-fun qj-next ((a {S}) (qj QJobHistory)) QJobHistory (ite {revoke} qj-zero (ite {goodstart} {fresh} {hold})))\n'
    captured=both(['(qj-owned qj)',eq('(qj-layer qj)',n(J+'layer_q')),eq('(qj-exponent qj)',n(J+'activation_exponent_q')),
        eq(n(J+'rows_q'),bv(256,13)),eq(n(J+'columns_q'),bv(256,10)),eq(n(J+'groups_q'),bv(4,7)),f'(bvult (qj-layer qj) {bv(6,3)})'])
    clauses=[f'(=> (qj-owned qj) (bvule (qj-count qj) {bv(256,13)}))',
        f'(=> (qj-scope a) {captured})',
        f'(=> (and {live} (qj-owned qj)) (qj-scope a))',
        f'(=> (and (qj-scope a) {phase(2,3,4)}) (= (qj-count qj) {n(J+"expected_row_q")}))',
        f'(=> (and (qj-scope a) {phase(4)}) (= (qj-count qj) {bv(256,13)}))']
    if revision==2:clauses.append(f'(=> (and (qj-scope a) {phase(1)}) (= (qj-count qj) {bv(0,13)}))')
    args=f'((a {S}) (qj QJobHistory))'
    for i,c in enumerate(clauses):defs+=f'(define-fun qj-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun qj-inv {args} Bool '+both([f'(qj-clause-{i} a qj)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision);H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const qj QJobHistory)','(declare-const qjn QJobHistory)']
    context=[H('a'),H('an'),'(operand-native-step a an)','(capture-inv a ch)','(= chn (capture-next a ch))','(capture-inv an chn)',
        '(qj-inv a qj)','(= qjn (qj-next a qj))']
    parts=[f'(qj-clause-{i} an qjn)'for i in range(len(clauses))]
    current=[H('a'),'(capture-inv a ch)','(qj-inv a qj)',n(J+'reset_n'),eq(n(J+'job_q'),bv(0,4))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("reset_n")})'],conclusion='(qj-inv an qj-zero)'),
        **{'preserved-'+str(i):dict(assumptions=context,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qj-inv an qjn)'),
        'live-Q-output-prefix':dict(assumptions=current+[n(J+'result_valid_o')],conclusion=both(['(qj-owned qj)',
            eq(n(J+'result_row_index_o'),'(qj-count qj)'),f'(bvult (qj-count qj) {bv(256,13)})',eq(n(J+'result_last_o'),eq('(qj-count qj)',bv(255,13)))])),
        'Q-DONE-full-prefix':dict(assumptions=current+[n(J+'done_valid_o')],conclusion=both(['(qj-owned qj)',eq('(qj-count qj)',bv(256,13))]))}
    return decl,defs,rules


def prepare():
    decl,defs,rules=specification();d=HERE/'q-job';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2','q-job/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-accepted-job-and-prefix-v1',component='q-job',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-job-CHECKS.json',
        old_providers=['parentcapture'],new_providers=[],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-job-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed accepted Q job/prefix')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual accepted Q descriptor and output transfer prefix induction prepared.')

"""Persistent accepted Q arguments through projection DONE/normalization.

The vector snapshot is the independent accepted-activation JobHistory once
complete, never an arithmetic reply. Model Q-prefix reads only its 256 newly
accepted coordinates. No resetless/native RAM value is asserted as an input.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,J,n
from q_model import VECTOR
from q_normalizer_product import NORM,NS,nn,dn
from q_lifecycle import body_files as lifecycle_files


def definitions(revision=1):
    defs=f'(declare-datatypes () ((QArguments (q-arguments (qa-vector {VECTOR}) (qa-owned Bool) (qa-complete Bool) (qa-epoch Int) (qa-layer (_ BitVec 3)) (qa-exponent (_ BitVec 8))))))\n'
    defs+='(define-fun qa-zero () QArguments (q-arguments ((as const '+VECTOR+') '+bv(0,16)+') false false 0 '+bv(0,3)+' '+bv(0,8)+'))\n'
    start=both(['(qn-Q-mode a)','(ql-P-start a)'])
    snapshot=both(['(qa-owned h)','(not (qa-complete h))','(qn-Q-mode a)','(ql-p-owned life)',
        f'(not {n(J+"integrated_fail")})','(j-complete (c-base ch))'])
    fresh=f'(q-arguments (qa-vector h) true false (ql-epoch life) {n(J+"fixed_layer_i")} {n(J+"activation_exponent_i")})'
    held='(q-arguments (ite '+snapshot+' (j-memory (c-base ch)) (qa-vector h)) (qa-owned h) (or (qa-complete h) '+snapshot+') (qa-epoch h) (qa-layer h) (qa-exponent h))'
    revoke='(or (not '+dn('rst_n')+') '+dn('clear_i')+' '+dn('stage_accept')+' '+dn('head_start_accept')+')'
    defs+=f'(define-fun qa-next ((a {S}) (z {NS}) (life QLifecycle) (ch CaptureHistory) (h QArguments)) QArguments (ite {revoke} qa-zero (ite {start} {fresh} {held})))\n'
    current=both(['(qn-Q-mode a)',dn('rst_n'),f'(not {dn("fault_q")})'])
    pactive=both([current,'(ql-p-owned life)',n(J+'reset_n'),f'(not {n(J+"integrated_fail")})',
        '(or '+' '.join(eq(n(J+'state_q'),bv(x,3))for x in [1,2,3,4])+')'])
    owns=both(['(qa-owned h)',eq('(qa-epoch h)','(ql-epoch life)'),eq('(qa-layer h)',dn('current_layer_q'))])
    nactive=both([nn('rst_n'),f'(bvuge {nn("state_q")} {bv(1,4)})',f'(bvule {nn("state_q")} {bv(12,4)})'])
    clauses=[
        f'(=> {nactive} '+both([eq('(nc-job nc)','(ql-n-job life)'),eq('(nc-layer nc)','(ql-n-layer life)')])+')',
        f'(=> {pactive} '+both([owns,eq('(qa-layer h)',n(J+'layer_q')),eq('(qa-exponent h)',n(J+'activation_exponent_q'))])+')',
        f'(=> {both([current,"(qa-owned h)"])} '+both([owns,dn('service_start_seen_q')])+')',
        f'(=> {both([current,"(qa-owned h)","(qa-complete h)"])} (= (qa-vector h) (j-memory (c-base ch))))',
        f'(=> {both([pactive,"(or "+eq(n(J+"state_q"),bv(3,3))+" "+eq(n(J+"state_q"),bv(4,3))+")"])} (qa-complete h))',
        f'(=> {both([current,"(ql-n-owned life)",f"(bvugt (nc-count nc) {bv(0,10)})"]+([nactive]if revision==2 else []))} '+both([owns,'(qa-complete h)'])+')',
    ]
    if revision==2:
        clauses += [f'(=> {both([current,"(qa-owned h)","(qa-complete h)"])} (not '+eq(n(J+'state_q'),bv(1,3))+'))']
    args=f'((a {S}) (z {NS}) (life QLifecycle) (ch CaptureHistory) (nc NormCapture) (h QArguments))'
    for i,c in enumerate(clauses):defs+=f'(define-fun qa-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun qa-inv {args} Bool '+both([f'(qa-clause-{i} a z life ch nc h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(revision=1):
    defs,clauses=definitions(revision)
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})',
        '(declare-const life QLifecycle)','(declare-const lifen QLifecycle)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const nc NormCapture)','(declare-const ncn NormCapture)','(declare-const h QArguments)','(declare-const hn QArguments)']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)']
    step=H+['(qn-native-step a an z zn)','(operand-native-step a an)',
        '(ql-inv a z life)','(ql-inv an zn lifen)','(= lifen (ql-next a z life))',
        '(capture-inv a ch)','(capture-inv an chn)','(= chn (capture-next a ch))',
        '(nc-inv z nc)','(nc-inv zn ncn)','(= ncn (nc-next z nc))',
        '(qa-inv a z life ch nc h)','(= hn (qa-next a z life ch h))']
    parts=[f'(qa-clause-{i} an zn lifen chn ncn hn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=H+['(qn-native-step a an z zn)',f'(not {dn("rst_n")})'],
            conclusion='(qa-inv an zn ql-zero (capture-zero an) nc-zero qa-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qa-inv an zn lifen chn ncn hn)')}
    return decl,defs,rules


def body_files():
    return lifecycle_files()[:-1]+['../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2',
        'norm-capture/control-step.smt2','norm-capture-r2/history.smt2','q-lifecycle/history.smt2','q-arguments/history.smt2']


PROVIDERS=['q-lifecycle','norm-capture-r2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-arguments';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv',
        '../model-consumption/parentcapture-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-persistent-accepted-argument-snapshot-v1',component='q-arguments',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-arguments-CHECKS.json',
        providers=PROVIDERS,old_providers=['parentcapture'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-arguments-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed persistent Q argument snapshot')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Input-only accepted vector snapshot and post-projection persistence prepared.')

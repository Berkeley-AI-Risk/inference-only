"""Closed raw-Q value composition in the ordinary root runtime domain.

The terminal frontier is a separate required join. This helper explicitly
retains qc-live; it must not be published as the all-fault complete Q theorem.
"""
import json
from arithmetic import HERE,bv,both,eq,signed,sha,write_json
from q_columns import TOP,S,J,n
from q_model import MODEL
from fact_composition import apply,flattened
from source_contracts import apply as source_apply


def root():
    return [f'(|{TOP}_h| a)','(qc-live a)',n(J+'result_valid_o'),
        '(capture-inv a ch)','(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(tile-inv a th lane tile)',
        '(sumframe-inv a th fr lane tile)','(math-inv a pc th mh)','(frame-inv a fr)',
        '(qc-inv a pc th ch lane tile)','(qi-inv a ch qi)','(macmodel-inv a ch model)',
        '(qp-inv a pc th mh qi model lane tile)','(qmd-inv a fr model)','(ms-inv a mr fr)',
        '(qj-inv a qj)','(tilemeta-inv a model)',
        '(and (= ((_ extract 5 4) (fr-R3 fr)) tile) (= ((_ extract 3 0) (fr-R3 fr)) lane))']


def application(label,rule):return dict(kind='engine',provider=label,rule=rule,substitution={})


def composition(include_match=False):
    original=root();available=list(original);facts=[];audit=[]
    def add_engine(label,rule):
        nonlocal available
        new,record=apply(available,[application(label,rule)]);available+=new;facts.extend(new);audit.extend(record)
    def add_source(name):
        nonlocal available
        new,record=source_apply(available,name);available+=new;facts.extend(new);audit.append(record)
    add_engine('q-scope','live-Q-source-domain')
    add_engine('q-routing-r2','actual-job-to-engine-result')
    add_source('metadata-legality')
    add_source('engine-integer')
    add_engine('q-prefix-r3','completed-fixed-Q-dot')
    add_engine('q-routing-r2','current-Q-global-row-and-accepted-descriptor')
    add_engine('q-job-r2','live-Q-output-prefix')
    guard='(qmd-live a)';app=application('q-metadata','current-output-metadata')
    conditional,record=apply(available+[guard],[app])
    facts.append('(=> '+guard+' '+both(conditional)+')')
    audit.append(dict(discharged_guard=guard,applications=record,implication_introduction=True))
    # These are direct qualified invariants/current-domain predicates, retained
    # explicitly, rather than an unqualified expected result premise.
    direct=['(qi-inv a ch qi)','(qc-live a)']
    if include_match:direct.append(original[-1])
    if not set(direct)<=set(original):raise ValueError('Unclosed raw composition root')
    return direct+facts,audit


def value_conclusion():
    row='(fr-R3 fr)';record=f'(Q-metadata model (qi-layer qi) (qi-group qi) {row})'
    dot=f'(Q-prefix (qi-vector qi) model (qi-layer qi) (qi-group qi) {row} {bv(256,10)})'
    exponent=f'(Q-record-exponent (qj-exponent qj) {record})'
    value='(* '+dot+' (bv2int ((_ extract 23 8) '+record+')))'
    conclusion=both([eq(signed(n(J+'result_scaled_raw_o'),50),value),
        eq(n(J+'result_source_exponent_o'),'((_ extract 7 0) '+exponent+')'),
        f'(bvsge {exponent} {bv(-128,11)})',f'(bvsle {exponent} {bv(127,11)})',
        eq('(qi-layer qi)','(qj-layer qj)'),eq(n(J+'group_q'),'(qi-group qi)'),
        eq(n(J+'result_row_index_o'),f'(bvadd (bvshl ((_ zero_extend 7) (qi-group qi)) {bv(6,13)}) ((_ zero_extend 7) {row}))'),
        f'(bvult {n(J+"result_row_index_o")} {bv(256,13)})',eq(n(J+'result_last_o'),eq(n(J+'result_row_index_o'),bv(255,13))),
        '(qi-owned qi)','(qj-owned qj)'])
    return conclusion


def specification(include_match=False):
    declarations=[f'(declare-const a {S})','(declare-const pc PrefixHistory)','(declare-const th TileHistory)',
        '(declare-const mh MathHistory)','(declare-const fr FrameHistory)','(declare-const ch CaptureHistory)',
        '(declare-const qi QIdentity)','(declare-const qj QJobHistory)','(declare-const mr MetaRead)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))',f'(declare-const model {MODEL})']
    conclusion=value_conclusion()
    premises,audit=composition(include_match)
    args=' '.join('('+d.removeprefix('(declare-const ').removesuffix(')')+')'for d in declarations)
    defs='; Ordinary-domain raw value theorem; terminal continuation remains separate.\n'+f'(define-fun Q-raw-runtime-theorem ({args}) Bool (=> {both(root())} {conclusion}))\n'
    rules={'joined-raw-Q-value':dict(assumptions=premises,conclusion=conclusion)}
    return declarations,defs,rules,audit


def body_files():
    from q_prefix_r3 import body_files as prefix_files
    from q_metadata import body_files as meta_files
    from q_routing_r2 import body_files as route_files
    result=[]
    for name in prefix_files()+meta_files()+route_files()+['q-meta-safety/history.smt2','q-scope/history.smt2','q-raw/history.smt2']:
        if name not in result:result.append(name)
    return result


NEW_PROVIDERS=['q-scope','q-routing-r2','q-job-r2','q-prefix-r3','q-metadata','meta-safety-r2','engine-integer-r2']


def prepare():
    declarations,defs,rules,audit=specification();d=HERE/'q-raw';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',dict(root_assumptions=root(),applications=audit))
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json','q-raw/APPLICATIONS.json',*[x+'-PLAN.json'for x in NEW_PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-raw-value-closed-composition-v1',component='q-raw',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='q-raw-CHECKS.json',
        providers=NEW_PROVIDERS,root_assumptions=root(),runtime_domain='qc-live; terminal frontier still required',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-raw-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed raw Q value composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Closed fixed-model raw Q theorem prepared with explicit ordinary-runtime scope.')

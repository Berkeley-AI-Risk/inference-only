"""Eliminate unused define-funs, then uniformly abstract remaining BV48 mul.

The removed definitions have no reference path from any retained non-definition
statement. Declarations, assertions and retained bodies are otherwise unchanged.
The fresh arbitrary F48 gives a stronger query; choose bvmul48 to recover it.
"""
import re


def parse(text):
    tokens=[t for t in re.findall(r';[^\n]*|\|[^|]*\||"(?:""|[^"])*"|[()]|[^\s();]+',text)if not t.startswith(';')]
    # The frozen parent contains deeply nested native ROM expressions. Use an
    # explicit stack without changing the tokenization or S-expression tree.
    ast=[];stack=[ast]
    for token in tokens:
        if token=='(':
            node=[];stack[-1].append(node);stack.append(node)
        elif token==')':
            if len(stack)==1:raise ValueError('Unexpected SMT close')
            stack.pop()
        else:stack[-1].append(token)
    if len(stack)!=1:raise ValueError('Unclosed SMT statement')
    return ast


def emit(node):
    return '('+' '.join(emit(x)for x in node)+')'if isinstance(node,list)else node


def atoms(node):
    if isinstance(node,list):
        for child in node:yield from atoms(child)
    else:yield node


def prune(text):
    ast=parse(text)
    definitions={node[1]:node for node in ast if isinstance(node,list)and node and node[0]=='define-fun'}
    if len(definitions)!=sum(isinstance(node,list)and bool(node)and node[0]=='define-fun'for node in ast):raise ValueError('Duplicate SMT definitions')
    roots=[node for node in ast if not(isinstance(node,list)and node and node[0]=='define-fun')]
    needed=set(atoms(roots))&set(definitions);pending=list(needed)
    while pending:
        name=pending.pop()
        dependencies=set(atoms(definitions[name][2:]))&set(definitions)
        new=dependencies-needed;needed.update(new);pending.extend(new)
    pruned=[node for node in ast if not(isinstance(node,list)and node and node[0]=='define-fun'and node[1]not in needed)]
    # Verify the dependency boundary explicitly; this includes zero-argument
    # functions referenced as bare symbols, not only ordinary applications.
    if set(atoms(pruned))& (set(definitions)-needed):raise ValueError('Referenced definition would be removed')
    return pruned


def prune_only(text):
    return '\n'.join(emit(node)for node in prune(text))+'\n'


def transform(text):
    ast=parse(text);pruned=prune(text)
    fresh='q_pruned_uniform_mul48'
    if fresh in set(atoms(ast)):raise ValueError('Abstract multiplication name not fresh')
    count=0
    def replace(node):
        nonlocal count
        if not isinstance(node,list):return node
        children=[replace(x)for x in node]
        if children and children[0]=='bvmul':
            if len(children)!=3:raise ValueError('Only binary multiplication is supported')
            children[0]=fresh;count+=1
        return children
    transformed=replace(pruned)
    if not count:raise ValueError('No multiplication remains to abstract')
    def undo(node):
        if not isinstance(node,list):return node
        result=[undo(x)for x in node]
        if result and result[0]==fresh:result[0]='bvmul'
        return result
    if undo(transformed)!=pruned:raise ValueError('Nonuniform arithmetic abstraction')
    declaration=['declare-fun',fresh,[['_','BitVec','48'],['_','BitVec','48']],['_','BitVec','48']]
    # The engine's ordinary type check must accept every remaining multiply as
    # BV48; a mixed-width application produces an error and cannot be evidence.
    return '\n'.join(emit(node)for node in [declaration,*transformed])+'\n'

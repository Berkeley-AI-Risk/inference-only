"""Exact source Q-write admission term, with actual normalizer output bindings.

The optimized old parent omits this otherwise-unused RAM-write getter because
query RAM is abstract. Reconstruct only its source-pinned STAGE_Q branch; this
does not establish RAM storage/readback. No expected arithmetic value is used.
"""
import re,sys
from arithmetic import HERE,OPERANDS,bv,both,eq,sha
from q_normalizer_product import DP,TOP,S,NS,nn,dn,source_binding


def definitions():
    order=both([eq(nn('result_row_index_o'),dn('output_index_q')),
        eq(nn('result_last_o'),eq(dn('output_index_q'),f'(bvsub {dn("projection_result_count")} {bv(1,10)})'))])
    live=both([f'(not {dn("fault_q")})',f'(not {dn("clear_i")})',dn('model_lock_i'),f'(not {dn("upstream_fault_i")})',f'(not {dn("child_fault")})',
        nn('result_valid_o'),dn('norm_result_ready'),'(qn-Q-mode a)',order])
    return f'(define-fun Q-write-admission ((a {S}) (z {NS})) Bool {live})\n'


def binding():
    parent=source_binding();sys.path.insert(0,str(OPERANDS))
    from build_semantic_window import NATIVE
    source=(NATIVE/'production-datapath.sv').read_text()
    assignments=re.findall(r'    assign query_ram_write_enable = [\s\S]*?;',source)
    if len(assignments)!=1:raise ValueError('Unique actual Q write enable required')
    expected='''    assign query_ram_write_enable = !fault_q && !clear_i && model_lock_i &&
        !upstream_fault_i && !child_fault && norm_result_fire &&
        (((engine_state_q == E_PROJ) && (current_stage_q == STAGE_Q) &&
          projection_norm_result_order_ok) ||
         ((engine_state_q == E_ROPE) &&
          (current_stage_q == STAGE_Q_ROPE) &&
          (norm_result_index == output_index_q) &&
          (norm_result_last == (output_index_q == 10'd255))));'''
    if assignments[0]!=expected:raise ValueError('Changed source query write gates')
    order='''    wire projection_norm_result_order_ok =
        (norm_result_index == output_index_q) &&
        (norm_result_last ==
         (output_index_q == projection_result_count - 1'b1));'''
    if source.count(order)!=1:raise ValueError('Changed exact projection result ordering')
    return dict(source=parent['source'],source_sha256=parent['source_sha256'],write_enable_assignment=expected,order_assignment=order,
        restriction='Actual E_PROJ/STAGE_Q branch; E_ROPE is a different operator',
        normalizer_outputs='Bound by q-normalizer-product',old_parent_write_getter_optimized_out=True,
        proof_boundary='Actual source-defined write admission only; retained RAM/readback not claimed')

; Exact source-wire and global Q row/descriptor routing.

"""Universally watched lane of the unchanged native 16-lane tile.

The watch index is a fixed proof parameter, not a circuit input or HDL observer.
All 16 values of its BV4 sort are included in every induction query.
"""
import json
import re
from arithmetic import HERE,MAC,bv,sha,write_json,compile_model
from tile import TOP,S,definitions as first_definitions,specification as first_specification,n


def select(field,state='a'):
    value=n(f'g_lane[15].u_mac.{field}',state)
    for lane in reversed(range(15)):
        value=f'(ite (= lane {bv(lane,4)}) {n(f"g_lane[{lane}].u_mac.{field}",state)} {value})'
    return value


def selectors():
    defs=''
    for field,width in [('product_q',26),('accumulator_q',48),('accumulator_o',48)]:
        defs+=f'(define-fun watch-{field} ((a {S}) (lane (_ BitVec 4))) (_ BitVec {width}) {select(field)})\n'
    for target,width in [('weight',10),('input',10)]:
        values=[n(f'weight_q[{i}]')if target=='weight'else f'((_ extract {i*10+9} {i*10}) {n("weights_i")})'for i in range(16)]
        value=values[15]
        for i in reversed(range(15)):value=f'(ite (= lane {bv(i,4)}) {values[i]} {value})'
        defs+=f'(define-fun watch-{target} ((a {S}) (lane (_ BitVec 4))) (_ BitVec {width}) {value})\n'
    return defs


def translate(text):
    for st in ['a','an']:
        for field in ['product_q','accumulator_q','accumulator_o']:
            text=text.replace(n('g_lane[0].u_mac.'+field,st),f'(watch-{field} {st} lane)')
        text=text.replace(n('g_lane[0].accumulated',st),f'(watch-accumulator_o {st} lane)')
        text=text.replace(n('weight_q[0]',st),f'(watch-weight {st} lane)')
        text=text.replace(f'((_ extract 9 0) {n("weights_i",st)})',f'(watch-input {st} lane)')
        text=text.replace(f'(= {n("read_lane_i",st)} {bv(0,4)})',f'(= {n("read_lane_i",st)} lane)')
    text=text.replace('(h TileHistory))','(h TileHistory) (lane (_ BitVec 4)))')
    # These are exact application forms; no datatype constructors are changed.
    text=re.sub(r'\((tile-next|tile-inv|tile-clause-\d+) (a|an) (h|hn|tile-zero)\)',r'(\1 \2 \3 lane)',text)
    return text


def specification():
    declarations,defs,rules=first_specification()
    declarations+=['(declare-const lane (_ BitVec 4))']
    definitions,_=first_definitions()
    defs=selectors()+translate(definitions)
    rules=json.loads(translate(json.dumps(rules)))
    return declarations,defs,rules


def prepare():
    compile_model('tile',TOP,{'cluster-tile.sv':[MAC,TOP]})
    declarations,defs,rules=specification();d=HERE/'tile-any';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['tile/native.smt2','tile-any/history.smt2'];paths=['tile-SOURCES.json','tile/native.sv','tile/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-any-lane-tile-history-v1',component='tile-any',bodies=bodies,
        source_manifest='tile-SOURCES.json',native_source='tile/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=declarations,rules=rules,order=list(rules),checks_file='tile-any-CHECKS.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'tile-any-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed arbitrary-lane history plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Universal watch-lane proof prepared on unchanged native tile model.')

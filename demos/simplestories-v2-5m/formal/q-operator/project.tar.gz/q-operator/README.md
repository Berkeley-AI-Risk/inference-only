# Baseline Q operator: source-bound trace proof

This project checks the complete source-bound Q trace argument. The enclosing
package's qualification and reproduction receipts state exactly which checks
were replayed. No production RTL or board image is changed.

Read [THEOREM.md](THEOREM.md) for the guarantee and diagram,
[SPECIFICATION.md](SPECIFICATION.md) for the independent arithmetic specification,
and [EVENTS-AND-FAULTS.md](EVENTS-AND-FAULTS.md) for scope. This proves fixed-operator
functionality and current-invocation value ownership. It supports the later
whole-device inference-only proof; it is not that whole-device theorem.

The proof connects fixed-model memory provenance, all 64 MAC lanes, exact integer
accumulation and scaling, four-group result order, the actual normalizer, actual
Q write admissions, the actual exponent register and stage completion. It
checks common-reset initialization, the first-step bootstrap, regular induction
and raw/normalized/rejection endpoints on the same trace. There is no numerical
reply oracle. Interruptions may truncate a correct output prefix; later faults
cannot excuse earlier wrong values.

From this directory, with Python 3.11 and the named native tools:

```sh
python3.11 -B trace_closure.py --verify
```

The command reconstructs source/parameter/port identity, exact provider rules,
canonical and transformed query bytes, raw engine answers, typed substitutions
and literal premise closure. It also starts an original-theory typecheck with
no SAT request. `TRACE-CLOSURE.json` records the result. `run.py` separately
starts bounded solver jobs; a Python import or compilation alone is no proof.

The proof uses SMT-LIB invariants and induction over the Yosys native RTL model,
with explicit finite word-semantic rules described in
[WORD-INTERPRETATION.md](WORD-INTERPRETATION.md). Identical-source module
instantiation and the native frontend remain stated trust boundaries. The
independent [common-trace review](F1-COMMON-TRACE-REVIEW.md) found no concrete
remaining scoped soundness gap.

Finite qualification compares every raw and normalized row for all six layers
and all 64 lanes against an independent integer reference. Inputs include both
maximum signs, cancellation, zero and impulse patterns, stalls, cancellation
with old reads draining, and fresh invocations without hard reset. Source-only
defects in product sign, FIRST handling, accumulation, postscale splitting and
normalizer row reads are detected. Separate normalization cases cover rounding,
shift limits, zero-prefix rejection and the watchdog's last transfer. These
finite fixtures complement the trace proof.

The proof preserves four named model/memory boundaries. It does not cover caller
RMSNorm/whole-graph meaning, Q RoPE/attention, retained query-RAM reads, timed
fault authorization, other configurations or physical DSP/bitstream equivalence.
Completed work and failed attempts are saved locally; only qualified current
results belong in the public release.

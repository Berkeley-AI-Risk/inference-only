"""First native rejection cannot be justified by its own sticky fault flag."""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from selector import TOP,S,n
from norm_algorithm_r2 import specification as algorithm_spec
from pruned_arithmetic import parse,emit


def definitions():
    source=algorithm_spec()[1];nodes=parse(source)
    interrupt=next(x for x in nodes if isinstance(x,list)and x[:2]==['define-fun','na-interrupt'])
    if interrupt[4][0]!='or'or emit(interrupt[4][1])!=n('range_fault_o'):raise ValueError('Changed exact sticky fault/first-entry boundary')
    external=emit(['or',*interrupt[4][2:]])
    nextfun=next(x for x in nodes if isinstance(x,list)and x[:2]==['define-fun','na-next'])
    body=nextfun[4]
    if body[0]!='na-step'or body[-1]!=['na-interrupt','a']:raise ValueError('Changed independent algorithm interrupt argument')
    noirq=[*body[:-1],'false']
    return f'(define-fun nf-inv ((a {S})) Bool (= {n("range_fault_o")} (= {n("state_q")} {bv(15,4)})))\n'+\
        f'(define-fun na-source-external-interrupt ((a {S})) Bool {external})\n'+\
        '(define-fun na-next-no-interrupt '+emit(nextfun[2])+ ' NormAlgorithm '+emit(noirq)+')\n'


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const nc NormCapture)','(declare-const ncn NormCapture)',
        '(declare-const h NormAlgorithm)','(declare-const hn NormAlgorithm)']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)'];T=f'(|{TOP}_t| a an)'
    step=H+[T,'(nf-inv a)','(nc-inv a nc)','(nc-inv an ncn)','(= ncn (nc-next a nc))',
        '(na-inv a nc h)','(na-inv an ncn hn)','(= hn (na-next a nc h))']
    first=[f'(not {n("range_fault_o")})',n('range_fault_o','an')]
    numeric=both([f'(distinct (na-phase h) {bv(7,3)})',eq('(na-phase (na-next-no-interrupt a nc h))',bv(7,3))])
    clean=step+first+['(not (na-source-external-interrupt a))']
    rules={
        'fault-state-reset-base':dict(assumptions=H+[T,f'(not {n("rst_n")})'],conclusion='(nf-inv an)'),
        'fault-state-preserved':dict(assumptions=H+[T,'(nf-inv a)'],conclusion='(nf-inv an)'),
        'first-fault-is-named-interruption-or-independent-rejection':dict(assumptions=step+first,
            conclusion='(or (na-source-external-interrupt a) '+numeric+')'),
        'clean-first-fault-enters-independent-numeric-rejection':dict(assumptions=clean,conclusion=numeric),
        'clean-numeric-rejection-preserves-emitted-prefix':dict(assumptions=clean,
            conclusion=both([eq('(na-emitted hn)','(na-emitted h)'),f'(not {n("result_valid_o")})',
                f'(not {n("result_valid_o","an")})',f'(not {n("done_valid_o","an")})']))}
    return decl,definitions(),rules


def body_files():return json.loads((HERE/'norm-algorithm-r2-PLAN.json').read_text())['bodies']+['normalizer-faults/history.smt2']


PROVIDERS=['norm-algorithm-r2','norm-capture-r2']


def prepare():
    decl,defs,rules=specification();d=HERE/'normalizer-faults';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-first-normalizer-rejection-classification-v1',component='normalizer-faults',bodies=bodies,
        source_manifest='selector-SOURCES.json',native_source='selector/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=decl,rules=rules,order=list(rules),checks_file='normalizer-faults-CHECKS.json',providers=PROVIDERS,
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'normalizer-faults-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed first-entry rejection classification')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Sticky fault separated from first-entry interruption/numeric rejection proof.')

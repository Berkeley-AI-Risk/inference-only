"""Bootstrap the three-state captured-row certificate without another reset.

One common-reset edge establishes the ordinary component bases at a1. A1 has
no raw/normalizer record write; its capture history therefore remains empty at
a2, even if a new descriptor starts. Three-state qcert preservation can then
start at a2 with all predecessor invariants available at a1.
"""
import json
from arithmetic import HERE,bv,eq,sha,write_json
from q_columns import TOP,S,n
from q_normalizer_product import NORM,NS,nn
from q_certificate import body_files as certificate_files


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})',
        '(declare-const ncn NormCapture)']
    H=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{NORM}_h| z)',f'(|{NORM}_h| zn)']
    root=H+['(qn-native-step a an z zn)',f'(not {n("reset_n")})']
    rules={
        'first-post-reset-normalizer-cannot-record-a-raw-word':dict(assumptions=root,conclusion=f'(not {nn("record_write_enable","zn")})'),
        'second-post-reset-logical-capture-is-empty':dict(assumptions=root+['(= ncn (nc-next zn nc-zero))'],
            conclusion=eq('(nc-count ncn)',bv(0,10)))}
    return decl,'; No extra reset/idle assumption; one reset edge plus an ordinary successor history update.\n',rules


def body_files():return certificate_files()+['q-trace-bootstrap/history.smt2']


PROVIDERS=['q-normalizer-product','norm-capture-r2','q-raw-scope']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-trace-bootstrap';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-one-reset-three-state-bootstrap-v1',component='q-trace-bootstrap',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-trace-bootstrap-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-trace-bootstrap-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed common-reset trace bootstrap')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Explicit first/two-state bootstrap for the three-state captured-value induction prepared.')

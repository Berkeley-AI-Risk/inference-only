"""Close already-proved source continuity before checking frame algebra.

Same readable native root and endpoint as R1. The smaller first engine query
contains literal checked q-frontier-control/routing consequences in place of
the large parent transition. Every direct premise is retained from the root.
"""
import copy,json
from arithmetic import HERE,bv,eq,sha,write_json
from q_columns import TOP,J,n
from q_frontier_value import specification as original,root,PROVIDERS
from q_frontier_control import specification as control_spec,body_files as control_files
from fact_composition import apply


def specification():
    decl,defs,rules,audit=original();rules=copy.deepcopy(rules)
    applications=[dict(kind='engine',provider='q-frontier-control',rule=name,substitution={})for name in control_spec()[2]]
    applications.append(dict(kind='engine',provider='q-routing-r2',rule='actual-job-to-engine-result',substitution={'a':'an'}))
    facts,source_audit=apply(root(),applications)
    direct=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)','(qmd-inv a fr model)','(qi-inv a ch qi)',
        '(frame-inv an frn)','(qj-inv an qjn)',n(J+'result_valid_o','an'),eq(n(J+'job_q','an'),bv(0,4))]
    if not set(direct)<=set(root()):raise ValueError('Unclosed source-frame direct premise')
    rules['next-output-certified-frame']['assumptions']=direct+facts
    for record in audit:
        if record.get('provider')=='q-frontier-value':record['provider']='q-frontier-value-r2'
    return decl,defs,rules,dict(root_assumptions=root(),source_applications=source_audit,algebra_applications=audit)


def body_files():return control_files()+['q-frontier-value-r2/history.smt2']


def prepare():
    decl,defs,rules,audit=specification();d=HERE/'q-frontier-value-r2';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',audit)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json','q-frontier-value-r2/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-one-edge-endpoint-value-closed-source-r2-v1',component='q-frontier-value-r2',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),
        checks_file='q-frontier-value-r2-CHECKS.json',providers=PROVIDERS,root_assumptions=root(),external_facts={},
        whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-frontier-value-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed closed-source frontier composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Exact source-provider consequences closed before smaller frame query.')

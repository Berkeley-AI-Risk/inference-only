"""Refine the actual normalizer into an independent stuttering algorithm.

The pure algorithm has no native state, private read value, helper response or
candidate as an input. Its only numeric data are the accepted input vector.
Progress ticks choose when an abstract step happens, not its numeric result.
The implementation relation proves the enabled phase, ordered cursor, candidate,
fit/retry decision, output and completion. Interruptions preserve any correct
output transfer that occurs on that same edge, including the watchdog edge.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from selector import TOP,S,n,definitions as selector_definitions
from norm_capture import phase,ARRAY


def constructor(**changes):
    fields=['phase','scan','candidate','any','fit','rows','mantissa','emitted']
    return '(norm-algorithm '+' '.join(changes.get(k,'(na-'+k+' h)')for k in fields)+')'


def definitions(revision=1):
    defs=selector_definitions()
    fields=[('phase','(_ BitVec 3)'),('scan','(_ BitVec 10)'),('candidate','(_ BitVec 8)'),('any','Bool'),
        ('fit','Bool'),('rows','(_ BitVec 10)'),('mantissa','(_ BitVec 16)'),('emitted','(_ BitVec 10)')]
    defs+='(declare-datatypes () ((NormAlgorithm (norm-algorithm '+' '.join('(na-'+k+' '+t+')'for k,t in fields)+'))))\n'
    zero='(norm-algorithm '+' '.join([bv(0,3),bv(0,10),bv(-32,8),'false','true',bv(0,10),bv(0,16),bv(0,10)])+')'
    defs+='(define-fun na-zero () NormAlgorithm '+zero+')\n'
    row='(select vector (na-scan h))';raw='((_ extract 49 0) '+row+')';exponent='((_ extract 57 50) '+row+')'
    defs+='(define-fun na-row ((h NormAlgorithm) (vector '+ARRAY+')) (_ BitVec 58) '+row+')\n'
    first=f'(spec-first-fit (spec-bit-length50 {raw}) {exponent} (= {raw} {bv(0,50)}))'
    defs+='(define-fun na-first ((h NormAlgorithm) (vector '+ARRAY+')) (_ BitVec 8) '+first+')\n'
    count=f'(bvsub ((_ sign_extend 1) (na-candidate h)) ((_ sign_extend 1) {exponent}))'
    shift=f'(shift-history #b000 ((_ sign_extend 14) {raw}) {count})'
    defs+='(define-fun na-shift ((h NormAlgorithm) (vector '+ARRAY+')) ShiftHistory '+shift+')\n'
    fits=both(['(not (sh-fault (na-shift h vector)))',f'(bvsge (sh-result (na-shift h vector)) {bv(-32767,64)})',f'(bvsle (sh-result (na-shift h vector)) {bv(32767,64)})'])
    defs+='(define-fun na-fits ((h NormAlgorithm) (vector '+ARRAY+')) Bool '+fits+')\n'
    nonzero=f'(distinct {raw} {bv(0,50)})';last=f'(= (na-scan h) (bvsub (na-rows h) {bv(1,10)}))'
    defs+='(define-fun na-last ((h NormAlgorithm)) Bool '+last+')\n'
    cand='(ite (bvsgt (na-first h vector) (na-candidate h)) (na-first h vector) (na-candidate h))'
    anynew=f'(or (na-any h) {nonzero})'
    # Pure SELECT fold. All-zero vectors deliberately skip the fit scan.
    select=constructor(scan=f'(ite (na-last h) {bv(0,10)} (bvadd (na-scan h) {bv(1,10)}))',
        candidate=f'(ite (and (na-last h) (not {anynew})) {bv(0,8)} (ite {nonzero} {cand} (na-candidate h)))',
        any=anynew,fit=f'(ite (na-last h) true (na-fit h))',
        phase=f'(ite (na-last h) (ite {anynew} {bv(3,3)} {bv(4,3)}) {bv(2,3)})')
    reject=constructor(phase=bv(7,3))
    retry=constructor(phase=bv(3,3),scan=bv(0,10),candidate=f'(bvadd (na-candidate h) {bv(1,8)})',fit='true')
    fitlast=f'(ite (and (na-fit h) (na-fits h vector)) '+constructor(phase=bv(4,3),scan=bv(0,10))+f' (ite (or (sh-fault (na-shift h vector)) (= (na-candidate h) {bv(31,8)})) {reject} {retry}))'
    fit=f'(ite (na-last h) {fitlast} (ite (sh-fault (na-shift h vector)) {reject} '+constructor(scan=f'(bvadd (na-scan h) {bv(1,10)})',fit='(and (na-fit h) (na-fits h vector))')+'))'
    write=f'(ite (na-fits h vector) '+constructor(phase=bv(5,3),mantissa='((_ extract 15 0) (sh-result (na-shift h vector)))')+f' {reject})'
    result=constructor(phase=f'(ite (na-last h) {bv(6,3)} {bv(4,3)})',scan=f'(ite (na-last h) (na-scan h) (bvadd (na-scan h) {bv(1,10)}))')
    fresh=constructor(phase=bv(1,3),scan=bv(0,10),candidate=bv(-32,8),any='false',fit='true',rows='incoming-rows',mantissa=bv(0,16),emitted=bv(0,10))
    capture=constructor(phase=bv(2,3),scan=bv(0,10),candidate=bv(-32,8),any='false',fit='true')
    branches=[(0,'start',fresh),(1,'capture-complete',capture),(2,'select-tick',select),(3,'shift-tick',fit),(4,'shift-tick',write),(5,'result-fire',result),(6,'done-fire',constructor(phase=bv(0,3)))]
    body='h'
    for p,event,value in reversed(branches):body=f'(ite (= (na-phase h) {bv(p,3)}) (ite {event} {value} h) {body})'
    # Transfer count updates even if an interruption has priority over the
    # ordinary controller branch on this edge. A fresh start resets that count.
    body=f'(let ((next (ite interrupt {reject} {body}))) (norm-algorithm (na-phase next) (na-scan next) (na-candidate next) (na-any next) (na-fit next) (na-rows next) (na-mantissa next) (ite start {bv(0,10)} (bvadd (na-emitted h) (ite result-fire {bv(1,10)} {bv(0,10)})))))'
    args='((h NormAlgorithm) (vector '+ARRAY+') (incoming-rows (_ BitVec 10)) (start Bool) (capture-complete Bool) (select-tick Bool) (shift-tick Bool) (result-fire Bool) (done-fire Bool) (cancel Bool) (interrupt Bool))'
    defs+='(define-fun na-step '+args+' NormAlgorithm (ite cancel na-zero '+body+'))\n'
    active=phase(*range(1,13));notfault='(not '+phase(0,15)+')'
    interrupt='(or '+n('range_fault_o')+' '+both([notfault,f'(bvuge {n("compute_cycles_q")} {bv(1999999,32)})'])+' '+n('upstream_fault_i')+' '+both(['(or '+active+' '+n('start_valid_i')+')','(not '+n('model_lock_i')+')'])+' '+both([n('start_valid_i'),'(not '+phase(0)+')'])+' '+both([n('input_valid_i'),'(not '+phase(1)+')'])+' '+both([n('start_valid_i'),n('start_ready_o'),'(not '+n('descriptor_valid')+')'])+' '+both([n('input_valid_i'),n('input_ready_o'),'(not '+n('record_write_enable')+')'])+')'
    defs+=f'(define-fun na-interrupt ((a {S})) Bool {interrupt})\n'
    events=[f'(nc-job-rows {n("fixed_job_i")})','(nc-start a)',both([n('record_write_enable'),n('input_last_i')]),phase(3),both([phase(6),n('shift_response_valid'),n('shift_response_ready')]),both([n('result_valid_o'),n('result_ready_i')]),both([n('done_valid_o'),n('done_ready_i')]),f'(or (not {n("rst_n")}) {n("clear_i")})','(na-interrupt a)']
    defs+=f'(define-fun na-next ((a {S}) (nc NormCapture) (h NormAlgorithm)) NormAlgorithm (na-step h (nc-vec nc) '+ ' '.join(events)+'))\n'
    # Refinement map from physical read/selector/helper microcycles to the
    # independently defined algorithm phases. Numeric updates above never read
    # this map or the physical candidate/helper output.
    phase_map=[phase(0),phase(1),phase(2,3,11,12),f'(or {phase(4,5)} (and {phase(6)} (not {n("shift_client_q")})))',f'(or {phase(7,8)} (and {phase(6)} {n("shift_client_q")}))',phase(9),phase(10),phase(15)]
    record=f'(select (nc-vec nc) {n("scan_index_q")})';rraw='((_ extract 49 0) '+record+')';rexp='((_ extract 57 50) '+record+')'
    clauses=[
        both([f'(= (= (na-phase h) {bv(p,3)}) {mapping})'for p,mapping in enumerate(phase_map)]),
        eq('(na-rows h)','(nc-rows nc)'),
        f'(=> {phase(2,3,4,5,6,7,8,9,10,11,12)} (= (na-scan h) {n("scan_index_q")}))',
        f'(=> {phase(2,3,4,5,6,7,8,9,10,11,12)} (= (na-candidate h) {n("candidate_q")}))',
        f'(=> {phase(2,3,4,5,6,7,8,9,10,11,12)} (= (na-any h) {n("any_nonzero_q")}))',
        f'(=> {phase(2,3,4,5,6,7,8,9,10,11,12)} (= (na-fit h) {n("all_fit_q")}))',
        f'(=> {phase(12)} '+both([eq(n('fit_length_pipe_q'),f'(spec-bit-length50 {rraw})'),eq(n('fit_source_pipe_q'),rexp),eq(n('fit_zero_pipe_q'),eq(rraw,bv(0,50)))])+')',
        f'(=> {phase(3)} (= {n("fit_first_pipe_q")} (spec-first-fit (spec-bit-length50 {rraw}) {rexp} (= {rraw} {bv(0,50)}))))',
        f'(=> {phase(9)} (= {n("result_mantissa_o")} (na-mantissa h)))',
        f'(=> {phase(1,2,3,4,5,6,7,8,9,11,12)} '+both([f'(bvule (na-emitted h) (na-rows h))',f'(=> (or (= (na-phase h) {bv(4,3)}) (= (na-phase h) {bv(5,3)})) (= (na-emitted h) (na-scan h)))',f'(=> (or (= (na-phase h) {bv(1,3)}) (= (na-phase h) {bv(2,3)}) (= (na-phase h) {bv(3,3)})) (= (na-emitted h) {bv(0,10)}))'])+')',
        f'(=> {phase(10)} (= (na-emitted h) (na-rows h)))',
        f'(=> {phase(2,3,4,5,6,7,8,9,10,11,12)} '+both([f'(bvsge (na-candidate h) {bv(-32,8)})',f'(bvsle (na-candidate h) {bv(31,8)})'])+')',
    ]
    if revision==2:
        # R1 countermodels exposed missing *proved* pipeline-zero alignment,
        # and an overclaim about descriptor ghosts after rejected simultaneous
        # start/input. No input or successful-operation assumption is added.
        clauses[1]=f'(=> {phase(*range(1,13))} (= (na-rows h) (nc-rows nc)))'
        clauses[6]=f'(=> {phase(3,12)} '+both([eq(n('fit_length_pipe_q'),f'(spec-bit-length50 {rraw})'),eq(n('fit_source_pipe_q'),rexp),eq(n('fit_zero_pipe_q'),eq(rraw,bv(0,50)))])+')'
    for i,clause in enumerate(clauses):defs+=f'(define-fun na-clause-{i} ((a {S}) (nc NormCapture) (h NormAlgorithm)) Bool (=> {n("rst_n")} {clause}))\n'
    defs+=f'(define-fun na-inv ((a {S}) (nc NormCapture) (h NormAlgorithm)) Bool '+both([f'(na-clause-{i} a nc h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def provider_facts():
    from norm_shift import specification as ns_spec
    decl,_,rules=ns_spec();r=rules['actual-response-current-vector']
    # Capture-free fixed renaming for this exact already-proved implication.
    from semantic_facts import substitute
    return [substitute('(=> '+both(r['assumptions'])+' '+r['conclusion']+')',{})]


def specification(revision=1):
    defs,clauses=definitions(revision);H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const nc NormCapture)','(declare-const ncn NormCapture)',
        '(declare-const sh ShiftHistory)','(declare-const shn ShiftHistory)','(declare-const h NormAlgorithm)','(declare-const hn NormAlgorithm)']
    current=['(nc-inv a nc)','(shift-inv a sh)','(ns-inv a nc sh)','(na-inv a nc h)']
    step=[H('a'),H('an'),'(norm-memory-native-step a an)',*current,
        '(= ncn (nc-next a nc))','(nc-inv an ncn)','(= shn (shift-next a sh))','(shift-inv an shn)','(ns-inv an ncn shn)',
        '(= hn (na-next a nc h))',*provider_facts()]
    parts=[f'(na-clause-{i} an ncn hn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("rst_n")})','(nc-inv an nc-zero)'],conclusion='(na-inv an nc-zero na-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(na-inv an ncn hn)'),
        'actual-output-algorithm':dict(assumptions=[H('a'),n('rst_n'),*current,n('result_valid_o')],
            conclusion=both([eq('(na-phase h)',bv(5,3)),eq(n('result_row_index_o'),'(na-scan h)'),eq(n('result_mantissa_o'),'(na-mantissa h)'),eq(n('result_exponent_o'),'(na-candidate h)'),eq(n('result_last_o'),'(na-last h)'),eq('(na-emitted h)','(na-scan h)')])),
        'actual-DONE-algorithm':dict(assumptions=[H('a'),n('rst_n'),*current,n('done_valid_o')],
            conclusion=both([eq('(na-phase h)',bv(6,3)),eq('(na-emitted h)','(na-rows h)'),eq('(nc-count nc)','(na-rows h)')]))}
    return decl,defs,rules


def prepare():
    decl,defs,rules=specification();d=HERE/'norm-algorithm';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    providers=['norm-capture-r2','shift','norm-shift','selector']
    bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture-r2/history.smt2','norm-shift/history.smt2','norm-algorithm/history.smt2']
    paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json',*[p+'-PLAN.json'for p in providers],*bodies]
    plan=dict(schema='Typed-Q-whole-normalizer-algorithm-v1',component='norm-algorithm',bodies=bodies,source_manifest='selector-SOURCES.json',native_source='selector/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='norm-algorithm-CHECKS.json',
        providers=providers,provider_facts=provider_facts(),external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'norm-algorithm-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed normalizer algorithm refinement')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Pure vector normalization algorithm and actual microcycle refinement prepared.')

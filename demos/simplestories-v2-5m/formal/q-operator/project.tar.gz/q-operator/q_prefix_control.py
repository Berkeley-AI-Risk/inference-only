"""Boolean ownership/column continuity for the fixed-Q integer induction.

No mathematical sum, product or wanted numerical result is a premise. These
native control conclusions separate source epoch reasoning from integer algebra.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,ENGINE,n,phase,F
from q_model import MODEL
from q_identity import body_files as identity_body_files


def definitions():
    args=f'((a {S}) (th TileHistory) (tile (_ BitVec 2)))'
    defs=f'(define-fun qpc-active ((a {S})) Bool '+both(['(qc-live a)',phase(1,2,3,4,5)])+')\n'
    defs+='(define-fun qpc-pending '+args+' Bool '+both(['(qc-live a)','(th-p th)',f'(not {F("kill_i")})',f'(not {F("begin_i")})'])+')\n'
    defs+='(define-fun qpc-revoke '+args+' Bool (or (not '+F('reset_n')+') '+F('kill_i')+' '+F('begin_i')+'))\n'
    return defs


def specification():
    H=lambda s:f'(|{TOP}_h| {s})'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const qi QIdentity)','(declare-const qin QIdentity)','(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))',f'(declare-const model {MODEL})']
    current=['(capture-inv a ch)','(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(tile-inv a th lane tile)','(qc-inv a pc th ch lane tile)','(qi-inv a ch qi)']
    step=[H('a'),H('an'),'(operand-native-step a an)',*current,'(= chn (capture-next a ch))','(capture-inv an chn)',
        '(= pcn (prefix-next a pc))','(prefix-inv an pcn)','(= thn (tile-next a th lane tile))','(lineage-inv an pcn thn lane tile)','(tile-inv an thn lane tile)',
        '(qc-inv an pcn thn chn lane tile)','(= qin (qi-next a ch qi))','(qi-inv an chn qin)']
    continuing=both(['(qpc-active an)','(not (qpc-revoke a th tile))'])
    tag=both([eq('(pc-pcol pc)','(pc-acc pc)'),eq('(th-pf th)',eq('(pc-acc pc)',bv(0,10))),f'(bvult (pc-acc pc) {bv(256,10)})'])
    rules={
        'sum-owner-and-snapshot-continuity':dict(assumptions=step,conclusion=f'(=> {continuing} '+both(['(qpc-active a)',eq('qin','qi')])+')'),
        'pending-input-and-column-continuity':dict(assumptions=step,conclusion=f'(=> (qpc-pending an thn tile) '+both(['(not (qpc-revoke a th tile))','(qc-op a th tile)',eq('qin','qi'),eq('(pc-pcol pcn)','(pc-opcol pc)')])+')'),
        'sum-pending-is-current-owned':dict(assumptions=step,conclusion=f'(=> (and {continuing} (th-p th)) (qpc-pending a th tile))'),
        'current-pending-count-and-FIRST':dict(assumptions=[H('a'),*current],conclusion=f'(=> (qpc-pending a th tile) {tag})'),
        'revoked-prefix-is-empty':dict(assumptions=step,conclusion=f'(=> (qpc-revoke a th tile) (= (pc-acc pcn) {bv(0,10)}))'),
        'continuing-prefix-count-step':dict(assumptions=step,conclusion=f'(=> (not (qpc-revoke a th tile)) (= (pc-acc pcn) (bvadd (pc-acc pc) (ite (th-p th) {bv(1,10)} {bv(0,10)}))))')}
    return decl,definitions(),rules


def body_files():return identity_body_files()+['q-prefix-control/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-prefix-control';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-identity-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-prefix-owner-continuity-v1',component='q-prefix-control',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-prefix-control-CHECKS.json',
        old_providers=['parentcapture'],new_providers=['q-columns-r3','q-identity'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-prefix-control-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed prefix control/owner facts')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Native owner/column/FIRST continuity facts prepared without a numerical prefix premise.')

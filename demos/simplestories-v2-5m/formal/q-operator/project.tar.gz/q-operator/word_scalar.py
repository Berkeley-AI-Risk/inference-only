"""Small engine-checked word slices and counter/integer bridges."""
import json
from arithmetic import HERE,bv,both,eq,signed,sha,write_json,MAC,compile_model


def specification():
    declarations=['(declare-const w (_ BitVec 48))','(declare-const count (_ BitVec 10))']
    value=signed('w',48);fit=[f'(<= (- 17179869184) {value})',f'(< {value} 17179869184)']
    rules={
        'signed-low35-preserves-bounded-value':dict(assumptions=fit,conclusion=eq(signed('((_ extract 34 0) w)',35),value)),
        'bounded-dot-upper-bits-are-sign':dict(assumptions=fit,conclusion=eq('w','((_ sign_extend 13) ((_ extract 34 0) w))')),
        'bounded-dot-native-overflow-clear':dict(assumptions=fit,conclusion=eq('((_ extract 35 35) w)','((_ extract 34 34) w)')),
        'unsigned10-increment-exact':dict(assumptions=[f'(bvult count {bv(1023,10)})'],conclusion=f'(= (bv2int (bvadd count {bv(1,10)})) (+ (bv2int count) 1))'),
    }
    return declarations,'',rules


def prepare():
    compile_model('mac',MAC,{'cluster-tile.sv':[MAC]})
    declarations,defs,rules=specification();d=HERE/'word-scalar';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['mac/native.smt2','word-scalar/history.smt2'];paths=['mac-SOURCES.json','mac/native.sv','mac/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-word-scalar-v1',component='word-scalar',bodies=bodies,source_manifest='mac-SOURCES.json',native_source='mac/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='word-scalar-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'word-scalar-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed word scalar plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

"""Explicit typed interpretation of two already-proved native word equations.

This is a small mathematical derivation rule in the trusted checking boundary,
not an SMT solver or a receipt claiming an engine returned UNSAT. Its rules
unfold standard word semantics and apply separately engine-proved integer facts.
"""
import copy
import json
from arithmetic import HERE,MAC,MUL,sha,write_json,specification,signed,sext,bv,both,eq
from q_check import check

THEORY='https://smt-lib.org/theories-FixedSizeBitVectors.shtml'


def product():
    _,_,rules=specification('mac')
    n=lambda field,state='a':f'(|{MAC}_n {field}| {state})'
    A=n('activation_i');W=n('weight_i');P=n('product_q','an')
    SA=signed(A,16);SW=signed(W,10);Q=f'(* {SA} {SW})'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='signed-native-product',
        meaning='Mathematical derivation from standard theory definitions and engine-proved facts; not a raw UNSAT answer',
        theory=THEORY,
        U='U_N is unsigned word value in [0,2^N); Z3 bv2int in this campaign and standard ubv_to_int denote U_N',
        S='S_N(b)=U_N(b) when U_N(b)<2^(N-1), otherwise U_N(b)-2^N',
        SR='SR_N(z)=S_N applied to the unsigned residue z mod 2^N',
        typing=dict(activation_signed=16,weight_signed=10,product_signed=26,
            activation_extension=10,weight_extension=16),
        bindings=dict(activation=A,weight=W,next_product=P,multiply_enable=n('multiply_i'),
            signed_activation=SA,signed_weight=SW,integer_product=Q,
            extended_activation=sext(A,10),extended_weight=sext(W,16)),
        source_equation=rules['native-product-recurrence'],
        target=rules['signed-product-integer'],
        instantiations=[
            dict(provider='word-algebra:sign-extend-16-to-26',substitution={'u':f'(bv2int {A})'},
                premise_discharge=dict(rule='unsigned-word-range',term=A,width=16)),
            dict(provider='word-algebra:sign-extend-10-to-26',substitution={'u':f'(bv2int {W})'},
                premise_discharge=dict(rule='unsigned-word-range',term=W,width=10)),
            dict(provider='word-algebra:product-congruence-factorization-26',substitution={'x':SA,'y':SW,
                'k':f'(ite (= ((_ extract 15 15) {A}) #b1) 1 0)',
                'j':f'(ite (= ((_ extract 9 9) {W}) #b1) 1 0)'},premise_discharge='no premises'),
            dict(provider='word-algebra:mod-removes-whole-multiple-26',substitution={'z':Q,
                't':f'(+ (* {SA} (ite (= ((_ extract 9 9) {W}) #b1) 1 0)) (* {SW} (ite (= ((_ extract 15 15) {A}) #b1) 1 0)) (* 67108864 (ite (= ((_ extract 15 15) {A}) #b1) 1 0) (ite (= ((_ extract 9 9) {W}) #b1) 1 0)))'},premise_discharge='no premises'),
            dict(provider='word-semantics:signed16x10-product-fits26',substitution={'x':SA,'y':SW},
                premise_discharge=[dict(rule='signed-word-range',term=A,width=16),dict(rule='signed-word-range',term=W,width=10)]),
            dict(provider='word-semantics:signed-mod-exact-26',substitution={'q':Q},
                premise_discharge=dict(rule='weaken-strict-lower-bound-to-inclusive',provider='word-semantics:signed16x10-product-fits26',
                    actual_premises=[f'(<= (- 33554432) {Q})',f'(< {Q} 33554432)']))],
        steps=[
            dict(rule='enabled-native-equation',provider='mac:native-product-recurrence',
                result='multiply_i implies P_next=bvmul26(sext26(A16),sext26(W10))'),
            dict(rule='unfold-standard-bvmul',result='U26(P_next)=(U26(sext26(A16))*U26(sext26(W10))) mod 2^26'),
            dict(rule='unsigned-sign-extension',providers=['word-algebra:sign-extend-16-to-26','word-algebra:sign-extend-10-to-26'],
                result='U26(sext26(A16))=S16(A16)+2^26*k and U26(sext26(W10))=S10(W10)+2^26*j, where k,j are the respective sign indicators'),
            dict(rule='multiply-residue-congruence',providers=['word-algebra:product-congruence-factorization-26','word-algebra:mod-removes-whole-multiple-26'],
                result='U26(P_next)=(S16(A16)*S10(W10)) mod 2^26'),
            dict(rule='unfold-signed-result',result='S26(P_next)=SR26(S16(A16)*S10(W10))'),
            dict(rule='full-type-product-bound',provider='word-semantics:signed16x10-product-fits26',
                result='-2^25<S16(A16)*S10(W10)<2^25; no exclusion of -32768/-512 is needed'),
            dict(rule='signed-residue-no-wrap',provider='word-semantics:signed-mod-exact-26',
                result='S26(P_next)=S16(A16)*S10(W10)')],
        providers={'mac':['native-product-recurrence'],
            'word-algebra':['sign-extend-16-to-26','sign-extend-10-to-26','product-congruence-factorization-26','mod-removes-whole-multiple-26'],
            'word-semantics':['signed16x10-product-fits26','signed-mod-exact-26']},
        external_hardware_assumptions=[],
        trusted_boundary='SMT-LIB word semantics, typed unfolding/application rule, native frontend and proved-engine trust; configured physical DSP behavior remains explicit',
        whole_Q_operator_proved=False,whole_machine_theorem=False)


def postscale():
    from postscale import specification as postscale_specification
    _,_,rules=postscale_specification()
    L='((_ zero_extend 25) ((_ extract 24 0) d))'
    H='((_ sign_extend 40) ((_ extract 34 25) d))'
    M='((_ zero_extend 35) m)'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='split-postscale-word-ring',
        meaning='Mathematical derivation from standard word-ring semantics and exact engine-proved split; not a raw UNSAT answer',
        theory=THEORY,
        typing=dict(dot_signed=35,multiplier_unsigned=15,result_word=50,low_unsigned=25,high_signed=10,shift=25),
        bindings=dict(dot='d',multiplier='m',dot50='((_ sign_extend 15) d)',low50=L,high50=H,multiplier50=M,modulus=1<<50),
        source_equation=rules['signed35-split-reconstruction'],target=rules['split-multiply-recombine50'],
        instantiations=[dict(provider='bounds:split-postscale-integer-identity',
            substitution={'s':f'(+ (bv2int {L}) (* 33554432 (bv2int {H})))','low':f'(bv2int {L})','high':f'(bv2int {H})','m':f'(bv2int {M})'},
            premise_discharge='the s substitution is definitionally low+33554432*high'),
            dict(provider='word-algebra:product-congruence-factorization-50',
                application='unsigned representatives of operands differing by whole multiples of 2^50; exact definition of bvmul50',premise_discharge='no premises'),
            dict(provider='word-algebra:addition-congruence-factorization-50',
                application='unsigned representatives of summands differing by whole multiples of 2^50; exact definition of bvadd50',premise_discharge='no premises'),
            dict(provider='word-algebra:mod-removes-whole-multiple-50',
                application='remove the whole-multiple terms in the expanded product, shifted term and sum',premise_discharge='no premises')],
        steps=[
            dict(rule='exact-native-word-split',provider='postscale:signed35-split-reconstruction',result='D50=L50+(H50<<25) in BV50'),
            dict(rule='unfold-constant-shift',result='(H50<<25)=H50*2^25 modulo 2^50'),
            dict(rule='word-ring-scaled-distributivity',provider='bounds:split-postscale-integer-identity',
                result='(L50+H50*2^25)*M50=L50*M50+(H50*M50)*2^25 modulo 2^50'),
            dict(rule='fold-standard-bvmul-add-shift',result='The target equality holds as an equality of BV50 words')],
        providers={'postscale':['signed35-split-reconstruction'],'bounds':['split-postscale-integer-identity'],
            'word-algebra':['product-congruence-factorization-50','addition-congruence-factorization-50','mod-removes-whole-multiple-50']},
        external_hardware_assumptions=[],
        trusted_boundary='SMT-LIB bvmul/bvadd/bvshl semantics and exact typed word-ring substitution; actual held pipeline application remains open',
        whole_Q_operator_proved=False,whole_machine_theorem=False)


def accumulator():
    _,_,rules=specification('mac');source=rules['native-accumulator-recurrence']
    n=lambda field,state='a':f'(|{MAC}_n {field}| {state})'
    x=f'(ite {n("first_i")} 0 {signed(n("accumulator_q"),48)})'
    y=signed(n('product_q'),26);total=f'(+ {x} {y})'
    target=dict(assumptions=source['assumptions']+[n('accumulate_i'),f'(<= (- 140737488355328) {total})',f'(< {total} 140737488355328)'],
        conclusion=f'(= {signed(n("accumulator_q","an"),48)} {total})')
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='signed-native-accumulator',theory=THEORY,
        meaning='Conditional integer interpretation of the actual enabled bvadd48/FIRST branch; caller must prove the sum bound',
        typing=dict(product_signed=26,accumulator_signed=48,product_extension=22),
        bindings=dict(old_accumulator=n('accumulator_q'),pending_product=n('product_q'),new_accumulator=n('accumulator_q','an'),
            first=n('first_i'),enable=n('accumulate_i'),base_integer=x,product_integer=y,sum_integer=total),
        source_equation=source,target=target,
        instantiations=[dict(provider='word-algebra:sign-extend-26-to-48',substitution={'u':f'(bv2int {n("product_q")})'},
            premise_discharge=dict(rule='unsigned-word-range',term=n('product_q'),width=26)),
            dict(provider='word-semantics:signed-add48-exact-under-sum-bound',substitution={'x':x,'y':y},premise_discharge='literal sum-bound premises of this conditional target')],
        steps=[dict(rule='enabled-native-equation',provider='mac:native-accumulator-recurrence'),
            dict(rule='FIRST-branch',result='base word is zero for FIRST, otherwise the actual old accumulator; base signed value is x'),
            dict(rule='unsigned-sign-extension',provider='word-algebra:sign-extend-26-to-48'),
            dict(rule='unfold-bvadd48-and-remove-representative-multiples',providers=['word-algebra:addition-congruence-factorization-48','word-algebra:mod-removes-whole-multiple-48'],result='S48(new accumulator)=SR48(x+y)'),
            dict(rule='conditional-signed-residue-no-wrap',provider='word-semantics:signed-add48-exact-under-sum-bound',result='S48(new accumulator)=x+y')],
        providers={'mac':['native-accumulator-recurrence'],'word-algebra':['sign-extend-26-to-48','addition-congruence-factorization-48','mod-removes-whole-multiple-48'],
            'word-semantics':['signed-add48-exact-under-sum-bound']},
        external_hardware_assumptions=[],application_premises_open=['Q prefix/ownership provider must establish the literal sum bound and identify the pending product; no such premise is silently imported'],
        trusted_boundary='standard word semantics and exact enabled typed interpretation rule',whole_Q_operator_proved=False,whole_machine_theorem=False)


def first():
    _,_,rules=specification('mac');source=rules['FIRST-discards-arbitrary-old-accumulator']
    n=lambda field,state='a':f'(|{MAC}_n {field}| {state})'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='FIRST-integer-overwrite',theory=THEORY,
        meaning='FIRST on an actual accumulation overwrites arbitrary old accumulator state with the signed pending product',
        typing=dict(product_signed=26,accumulator_signed=48,extension=22),
        bindings=dict(pending_product=n('product_q'),new_accumulator=n('accumulator_q','an'),enable=n('accumulate_i'),first=n('first_i')),
        source_equation=source,target=dict(assumptions=source['assumptions'],conclusion=f'(= {signed(n("accumulator_q","an"),48)} {signed(n("product_q"),26)})'),
        instantiations=[dict(provider='word-algebra:sign-extend-26-to-48',substitution={'u':f'(bv2int {n("product_q")})'},premise_discharge=dict(rule='unsigned-word-range',term=n('product_q'),width=26))],
        steps=[dict(rule='actual-FIRST-word-overwrite',provider='mac:FIRST-discards-arbitrary-old-accumulator'),
            dict(rule='signed-interpretation-preserved-by-sign-extension',provider='word-algebra:sign-extend-26-to-48',result='S48(sext48(P26))=S26(P26)')],
        providers={'mac':['FIRST-discards-arbitrary-old-accumulator'],'word-algebra':['sign-extend-26-to-48']},external_hardware_assumptions=[],
        trusted_boundary='standard sign-extension semantics and exact enabled typed interpretation rule',whole_Q_operator_proved=False,whole_machine_theorem=False)


def extract_dot():
    n=lambda field:f'(|{MAC}_n {field}| a)'
    word=n('accumulator_q');value=signed(word,48)
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='bounded-dot35-extraction',theory=THEORY,
        meaning='Low35 extraction preserves a signed48 value when its integer value fits signed35; actual tile read/row ownership is a separate provider',
        typing=dict(source_signed=48,extract_high=34,extract_low=0,result_signed=35),bindings=dict(word=word,integer_value=value),
        target=dict(assumptions=[f'(|{MAC}_h| a)',f'(<= (- 17179869184) {value})',f'(< {value} 17179869184)'],
            conclusion=f'(= {signed("((_ extract 34 0) "+word+")",35)} {value})'),
        instantiations=[dict(provider='word-semantics:signed-mod-exact-35',substitution={'q':value},premise_discharge='literal signed35 bound in the target')],
        steps=[dict(rule='unfold-low-word-extraction',result='U35(low35(word))=U48(word) mod 2^35'),
            dict(rule='signed-unsigned-representative-congruence',result='U48(word) differs from S48(word) by zero or 2^48, which is an integer multiple of 2^35'),
            dict(rule='interpret-signed-extracted-word',result='S35(low35(word))=SR35(S48(word))'),
            dict(rule='signed-residue-no-wrap',provider='word-semantics:signed-mod-exact-35')],
        providers={'word-semantics':['signed-mod-exact-35']},external_hardware_assumptions=[],application_premises_open=['Actual Q prefix bound and tile synchronous-read/row ownership'],
        trusted_boundary='standard extraction/word semantics and conditional typed interpretation rule',whole_Q_operator_proved=False,whole_machine_theorem=False)


def multiply48():
    _,_,rules=specification('mul');source=rules['native-multiplier-recurrence']
    n=lambda field:f'(|{MUL}_n {field}| a)'
    A=n('a_i');B=n('b_i');Q=f'(* {signed(A,27)} {signed(B,18)})'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='signed-native-postscale-multiply',theory=THEORY,
        meaning='Every actual combinational signed27 by signed18 multiplication is an exact signed48 integer product',
        typing=dict(a_signed=27,b_signed=18,result_signed=48,a_extension=21,b_extension=30),bindings=dict(a=A,b=B,product=n('product_o'),integer_product=Q),
        source_equation=source,target=dict(assumptions=source['assumptions'],conclusion=f'(= {signed(n("product_o"),48)} {Q})'),
        instantiations=[dict(provider='word-algebra:full-signed27x18-fits48',substitution={'x':signed(A,27),'y':signed(B,18)},premise_discharge=[dict(rule='signed-word-range',term=A,width=27),dict(rule='signed-word-range',term=B,width=18)]),
            dict(provider='word-semantics:signed-mod-exact-48',substitution={'q':Q},premise_discharge='weaken the preceding strict lower bound to the inclusive bound')],
        steps=[dict(rule='actual-native-word-multiply',provider='mul:native-multiplier-recurrence'),
            dict(rule='unsigned-sign-extensions',providers=['word-algebra:sign-extend-27-to-48','word-algebra:sign-extend-18-to-48']),
            dict(rule='product-representative-congruence',providers=['word-algebra:product-congruence-factorization-48','word-algebra:mod-removes-whole-multiple-48'],result='S48(product)=SR48(S27(A)*S18(B))'),
            dict(rule='full-type-product-bound',provider='word-algebra:full-signed27x18-fits48'),
            dict(rule='signed-residue-no-wrap',provider='word-semantics:signed-mod-exact-48')],
        providers={'mul':['native-multiplier-recurrence'],'word-algebra':['sign-extend-27-to-48','sign-extend-18-to-48','product-congruence-factorization-48','mod-removes-whole-multiple-48','full-signed27x18-fits48'],
            'word-semantics':['signed-mod-exact-48']},external_hardware_assumptions=[],
        trusted_boundary='standard word semantics and exact typed product interpretation; physical DSP semantics remain a platform boundary',whole_Q_operator_proved=False,whole_machine_theorem=False)


def scaled_integer():
    from postscale import specification as postscale_specification
    # Use the exact typed split/scale expression, before actual pipeline joining.
    D='((_ sign_extend 15) d)';M='((_ zero_extend 35) m)'
    L='((_ zero_extend 25) ((_ extract 24 0) d))';H='((_ sign_extend 40) ((_ extract 34 25) d))'
    raw=f'(bvadd (bvmul {L} {M}) (bvshl (bvmul {H} {M}) {bv(25,50)}))'
    Q=f'(* {signed("d",35)} (bv2int m))'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='split-postscale-integer',theory=THEORY,
        meaning='The complete word split/multiply/shift/add transform is exact integer D35 times unsigned M15; actual pipeline/row binding remains separate',
        typing=dict(dot_signed=35,multiplier_unsigned=15,raw_signed=50,shift=25),bindings=dict(dot='d',multiplier='m',raw50=raw,integer_product=Q),
        target=dict(declarations=['(declare-const d (_ BitVec 35))','(declare-const m (_ BitVec 15))'],assumptions=[],conclusion=f'(= {signed(raw,50)} {Q})'),
        derived_providers=['split-postscale-word-ring'],
        instantiations=[dict(provider='wide-bounds:signed35-unsigned15-fits50',substitution={'x':signed('d',35),'y':'(bv2int m)'},premise_discharge=[dict(rule='signed-word-range',term='d',width=35),dict(rule='unsigned-word-range',term='m',width=15)]),
            dict(provider='word-semantics:signed-mod-exact-50',substitution={'q':Q},premise_discharge='preceding full-type product bound')],
        steps=[dict(rule='exact-word-ring-transform',provider='derived:split-postscale-word-ring'),
            dict(rule='signed-dot-extension-unsigned-positive-multiplier-extension',provider='word-algebra:sign-extend-35-to-50'),
            dict(rule='product-congruence-and-signed-interpretation',providers=['word-algebra:product-congruence-factorization-50','word-algebra:mod-removes-whole-multiple-50'],result='S50(raw)=SR50(S35(d)*U15(m))'),
            dict(rule='full-type-product-bound',provider='wide-bounds:signed35-unsigned15-fits50'),
            dict(rule='signed-residue-no-wrap',provider='word-semantics:signed-mod-exact-50')],
        providers={'word-algebra':['sign-extend-35-to-50','product-congruence-factorization-50','mod-removes-whole-multiple-50'],
            'wide-bounds':['signed35-unsigned15-fits50'],'word-semantics':['signed-mod-exact-50']},
        external_hardware_assumptions=[],application_premises_open=['Actual low/high48 pipeline products, shift/add ownership and current Q row/metadata provider'],
        trusted_boundary='standard word semantics and exact typed interpretation; no pipeline theorem inferred',whole_Q_operator_proved=False,whole_machine_theorem=False)


def frame_integer():
    Q=f'(* {signed("d",35)} (bv2int m))'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='frame-integer-function',theory=THEORY,
        meaning='Exact integer meaning of the actual frame reference function, including its low48 zero extension; the multiplier bit15 premise remains explicit',
        typing=dict(dot_signed=35,multiplier_unsigned=16,low_product_signed=48,high_product_signed=48,result_signed=50,shift=25),
        bindings=dict(dot='d',multiplier='m',low48='(frame-low d m)',high48='(frame-high d m)',raw50='(frame-raw d m)',integer_product=Q),
        target=dict(declarations=['(declare-const d (_ BitVec 35))','(declare-const m (_ BitVec 16))'],
            assumptions=['(= ((_ extract 15 15) m) #b0)'],conclusion=f'(= {signed("(frame-raw d m)",50)} {Q})'),
        definition_provider=dict(file='frame/history.smt2',checked_by='frame-algebra exact regenerated definition context'),
        instantiations=[
            dict(provider='word-algebra:full-signed27x18-fits48',application='Apply separately to low27/scale18 and high27/scale18 in the exact frame-low/frame-high definitions',
                premise_discharge='signed type ranges of the explicit extended operands; no value premise on the native product'),
            dict(provider='postscale:signed35-integer-split',substitution={'d':'d'},premise_discharge='no premises'),
            dict(provider='bounds:split-postscale-integer-identity',substitution={'s':signed('d',35),'low':'(bv2int ((_ extract 24 0) d))','high':signed('((_ extract 34 25) d)',10),'m':'(bv2int m)'},
                premise_discharge='the exact signed35 integer split above'),
            dict(provider='wide-bounds:signed35-unsigned15-fits50',substitution={'x':signed('d',35),'y':'(bv2int m)'},
                premise_discharge=[dict(rule='signed-word-range',term='d',width=35),dict(provider='frame-algebra:legal-m16-is-m15-embedding',premise='literal multiplier bit15 guard')]),
            dict(provider='word-semantics:signed-mod-exact-50',substitution={'q':Q},premise_discharge='the preceding full-type product bound')],
        steps=[
            dict(rule='unfold-exact-frame-product-definitions',result='frame-low and frame-high are bvmul48 of the exact signed27 and signed18 extended operands'),
            dict(rule='integer-interpretation-of-each-word-product',providers=['word-algebra:product-congruence-factorization-48','word-algebra:mod-removes-whole-multiple-48','word-algebra:full-signed27x18-fits48','word-semantics:signed-mod-exact-48'],
                result='S48(low)=U25(d.low)*U16(m); S48(high)=S10(d.high)*U16(m)',
                operand_conversions=['frame-algebra:low27-is-unsigned25','frame-algebra:high27-is-signed10','frame-algebra:scale18-is-unsigned16']),
            dict(rule='actual-low-zero-extension',providers=['frame-algebra:low48-product-nonnegative','frame-algebra:low48-zero-extension-is-signed-extension'],
                result='S50(zero_extend2(low48))=S48(low48); the physical zero extension is retained'),
            dict(rule='actual-high-sign-extension-and-constant-shift',provider='word-algebra:sign-extend-48-to-50',result='high48 is signed-extended, then multiplied by 2^25 modulo 2^50'),
            dict(rule='addition-and-shift-representative-congruence',providers=['word-algebra:product-congruence-factorization-50','word-algebra:addition-congruence-factorization-50','word-algebra:mod-removes-whole-multiple-50'],
                result='S50(frame-raw)=SR50(U25(d.low)*U16(m)+2^25*S10(d.high)*U16(m))'),
            dict(rule='integer-dot-split-and-distributivity',providers=['postscale:signed35-integer-split','bounds:split-postscale-integer-identity'],result='S50(frame-raw)=SR50(S35(d)*U16(m))'),
            dict(rule='explicit-multiplier-domain',provider='frame-algebra:legal-m16-is-m15-embedding',result='literal bit15 guard gives 0<=U16(m)<32768'),
            dict(rule='product-bound-and-signed-no-wrap',providers=['wide-bounds:signed35-unsigned15-fits50','word-semantics:signed-mod-exact-50'],result='S50(frame-raw)=S35(d)*U16(m)')],
        providers={'frame-algebra':['low48-product-nonnegative','low48-zero-extension-is-signed-extension','scale18-is-unsigned16','low27-is-unsigned25','high27-is-signed10','legal-m16-is-m15-embedding'],
            'word-algebra':['product-congruence-factorization-48','mod-removes-whole-multiple-48','full-signed27x18-fits48','sign-extend-48-to-50','product-congruence-factorization-50','addition-congruence-factorization-50','mod-removes-whole-multiple-50'],
            'word-semantics':['signed-mod-exact-48','signed-mod-exact-50'],'postscale':['signed35-integer-split'],'bounds':['split-postscale-integer-identity'],'wide-bounds':['signed35-unsigned15-fits50']},
        external_hardware_assumptions=[],application_premises_open=['Current row/model dot meaning and actual captured multiplier bit15 guard'],
        trusted_boundary='finite canonical standard word semantic unfolding, exact regenerated frame definitions and checked integer providers',whole_Q_operator_proved=False,whole_machine_theorem=False)


def primitive_product():
    A='A';W='W';P=f'(bvmul {sext(A,10)} {sext(W,16)})';Q=f'(* {signed(A,16)} {signed(W,10)})'
    hardware=product()
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='word16x10-function',theory=THEORY,
        meaning='Pure total word-operation interpretation and full type bound; no hardware result premise or circuit state',
        typing=dict(a_signed=16,w_signed=10,result_signed=26),bindings=dict(a=A,w=W,word_expression=P,integer_product=Q),
        target=dict(declarations=['(declare-const A (_ BitVec 16))','(declare-const W (_ BitVec 10))'],assumptions=[],
            conclusion=both([eq(signed(P,26),Q),f'(<= (- 16777216) {Q})',f'(<= {Q} 16777216)'])),
        steps=[dict(rule='literal-word-multiply-definition',result='The word expression is exactly bvmul26 of signed extensions of the two declared words'),
            dict(rule='unsigned-sign-extensions',providers=['word-algebra:sign-extend-16-to-26','word-algebra:sign-extend-10-to-26']),
            dict(rule='signed-product-residue-congruence',providers=['word-algebra:product-congruence-factorization-26','word-algebra:mod-removes-whole-multiple-26'],result='S26(expression)=SR26(S16(A)*S10(W))'),
            dict(rule='full-type-product-bound',provider='word-semantics:signed16x10-product-fits26',substitution={'x':signed(A,16),'y':signed(W,10)},premise_discharge='signed ranges of the declared BV16/BV10 words'),
            dict(rule='signed-residue-no-wrap',provider='word-semantics:signed-mod-exact-26',substitution={'q':Q})],
        providers={k:v for k,v in hardware['providers'].items()if k!='mac'},external_hardware_assumptions=[],
        trusted_boundary='fixed standard word semantic unfolding and checked integer providers',whole_Q_operator_proved=False,whole_machine_theorem=False)


def primitive_add():
    X='x';Y='y';F='first';total=f'(+ (ite {F} 0 {signed(X,48)}) {signed(Y,26)})'
    word=f'(bvadd (ite {F} {bv(0,48)} {X}) {sext(Y,22)})'
    return dict(schema='Typed-SMT-word-interpretation-v1',kind='word48-add26-function',theory=THEORY,
        meaning='Pure FIRST-selected add48 of signed product26, with literal no-wrap premise',
        typing=dict(accumulator_signed=48,product_signed=26,result_signed=48,extension=22),bindings=dict(x=X,y=Y,first=F,word_expression=word,integer_sum=total),
        target=dict(declarations=['(declare-const x (_ BitVec 48))','(declare-const y (_ BitVec 26))','(declare-const first Bool)'],
            assumptions=[f'(<= (- 140737488355328) {total})',f'(< {total} 140737488355328)'],conclusion=eq(signed(word,48),total)),
        steps=[dict(rule='FIRST-selected-base',result='The base integer is zero for FIRST, otherwise S48(x)'),
            dict(rule='sign-extend-product26',provider='word-algebra:sign-extend-26-to-48'),
            dict(rule='unfold-bvadd48-and-representative-congruence',providers=['word-algebra:addition-congruence-factorization-48','word-algebra:mod-removes-whole-multiple-48']),
            dict(rule='literal-sum-bound-and-no-wrap',provider='word-semantics:signed-add48-exact-under-sum-bound',substitution={'x':f'(ite {F} 0 {signed(X,48)})','y':signed(Y,26)},premise_discharge='the literal target range premises')],
        providers={'word-algebra':['sign-extend-26-to-48','addition-congruence-factorization-48','mod-removes-whole-multiple-48'],
            'word-semantics':['signed-add48-exact-under-sum-bound']},external_hardware_assumptions=[],
        trusted_boundary='fixed standard word semantic unfolding and checked integer providers',whole_Q_operator_proved=False,whole_machine_theorem=False)


def expected(kind):
    return {'signed-native-product':product,'split-postscale-word-ring':postscale,
        'signed-native-accumulator':accumulator,'FIRST-integer-overwrite':first,'bounded-dot35-extraction':extract_dot,
        'signed-native-postscale-multiply':multiply48,'split-postscale-integer':scaled_integer,'frame-integer-function':frame_integer,
        'word16x10-function':primitive_product,'word48-add26-function':primitive_add}[kind]()


def shape(candidate):
    if candidate!=expected(candidate['kind']):raise ValueError('Changed typed word interpretation or missing derivation premise')


def verify(kind,record=True):
    d=expected(kind);shape(d)
    providers={}
    derived={name:verify(name,record)for name in d.get('derived_providers',[])}
    for label,names in d['providers'].items():
        checked=check(label,True,names)
        if checked['selected_rule_count']!=len(names) or checked['queries_verified']!=checked['dependency_closure_count']:raise ValueError('Missing engine provider closure')
        plan=HERE/(label+'-PLAN.json');checks=json.loads((HERE/(label+'-CHECKS.json')).read_text())
        providers[label]=dict(plan_sha256=sha(plan.read_bytes()),rules={name:checks['rules'][name]for name in names})
    controls={}
    cases={}
    bad=copy.deepcopy(d);bad['steps'].pop();cases['missing-interpretation-step']=bad
    bad=copy.deepcopy(d);bad['typing'][next(iter(bad['typing']))]+=1;cases['wrong-native-width']=bad
    bad=copy.deepcopy(d);bad['target']['assumptions'].append('(= native_product desired_product)');cases['desired-result-oracle']=bad
    bad=copy.deepcopy(d);bad['providers'].pop(next(iter(bad['providers'])));cases['missing-source-provider']=bad
    bad=copy.deepcopy(d);bad['meaning']='engine UNSAT';cases['manufactured-engine-answer']=bad
    if kind=='signed-native-product':
        bad=copy.deepcopy(d);bad['bindings']['extended_activation']=bad['bindings']['extended_activation'].replace('sign_extend','zero_extend');cases['zero-extension-in-place-of-sign-extension']=bad
        bad=copy.deepcopy(d);bad['target']['assumptions'].remove(d['bindings']['multiply_enable']);cases['disabled-multiply-branch']=bad
        bad=copy.deepcopy(d);bad['instantiations'][2]['substitution']['k']='0';cases['missing-negative-activation-case']=bad
        bad=copy.deepcopy(d);bad['instantiations'][4]['provider']='bounds:integer-product-bound';cases['legal-bound-without-legal-domain']=bad
        bad=copy.deepcopy(d);bad['instantiations'][-1]['premise_discharge']['actual_premises'][1]='(< desired_product 33554431)';cases['wrong-signed-threshold']=bad
        bad=copy.deepcopy(d);bad['bindings']['activation']=bad['bindings']['activation'].replace(' a)',' an)');cases['wrong-operand-state']=bad
    for name,candidate in cases.items():
        try:shape(candidate)
        except (ValueError,KeyError):controls[name]='rejected after typed reconstruction, independent of candidate hashes'
        else:raise ValueError('Invalid semantic derivation accepted')
    result=dict(kind=kind,checked=True,derivation=d,providers=providers,controls=controls,
        derived_providers=derived,
        receipt_type='checked mathematical semantic derivation, not raw solver UNSAT',
        derivation_sha256=sha((json.dumps(d,sort_keys=True)+'\n').encode()),
        whole_Q_operator_proved=False,whole_machine_theorem=False)
    if record:write_json(HERE/(kind+'-DERIVATION.json'),result)
    return result


if __name__=='__main__':
    import sys
    for kind in sys.argv[1:]or['signed-native-product','split-postscale-word-ring']:
        r=verify(kind);print(json.dumps(dict(kind=kind,checked=r['checked'],receipt_type=r['receipt_type'])))

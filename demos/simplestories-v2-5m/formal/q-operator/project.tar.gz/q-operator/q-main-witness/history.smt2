; Exact original main compatibility assumptions plus concrete witness equalities only.

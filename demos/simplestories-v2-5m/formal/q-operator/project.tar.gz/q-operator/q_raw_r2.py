"""Retain the root watched-row equality in the raw algebra cut.

R1's saved SAT model chose lane1 while output row0. The source root already
requires matching; R2 retains that exact root premise in its stronger engine
query. No new source or expected-data hypothesis is added.
"""
import json
from arithmetic import HERE,sha,write_json
from q_raw import specification as original,root,NEW_PROVIDERS,body_files as original_files


def specification(include_match=True):return original(include_match=include_match)


def body_files():return original_files()[:-1]+['q-raw-r2/history.smt2']


def prepare():
    declarations,defs,rules,audit=specification(include_match=True);d=HERE/'q-raw-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',dict(root_assumptions=root(),applications=audit))
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json','q-raw-r2/APPLICATIONS.json',*[x+'-PLAN.json'for x in NEW_PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-raw-value-closed-composition-r2-v1',component='q-raw-r2',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='q-raw-r2-CHECKS.json',
        providers=NEW_PROVIDERS,root_assumptions=root(),runtime_domain='qc-live; terminal frontier still required',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-raw-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed raw Q value composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Closed fixed-model raw Q theorem prepared with explicit ordinary-runtime scope.')

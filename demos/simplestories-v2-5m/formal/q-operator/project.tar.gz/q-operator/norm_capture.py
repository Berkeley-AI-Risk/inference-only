"""Fresh accepted-vector ownership through the actual normalizer RAM.

The reference array starts at zero and is written only from accepted input
records. Unwritten native RAM is arbitrary. No desired read value is supplied.
The shift helper's register updates are a literal weakening for this control
and memory component; its numerical contract is composed separately.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from selector import TOP,S,n

ARRAY='(Array (_ BitVec 10) (_ BitVec 58))'
phase=lambda *states:'(or '+' '.join(eq(n('state_q'),bv(i,4))for i in states)+')'
ACTIVE=list(range(1,13))
COMPUTE=[2,3,4,5,6,7,8,9,10,11,12]
READ_HELD=[3,5,6,8,9,11,12]


def transition():
    source=(HERE/'selector/native.smt2').read_text()
    start=source.index('(define-fun |'+TOP+'_t|');end=source.index(')) ; end of module '+TOP,start)+2
    lines=source[start:end].splitlines();kept=[];dropped=[]
    for line in lines[1:]:
        if ';'in line and 'u_shift.'in line.split(';',1)[1]:dropped.append(line)
        else:kept.append(line)
    if len(dropped)!=12:raise ValueError('Changed helper transition coverage')
    text='\n'.join([lines[0].replace('|'+TOP+'_t|','norm-memory-native-step'),*kept])+'\n'
    return text,dict(omitted_conjuncts=dropped,omitted_count=len(dropped),
        rule='Literal conjunction weakening; full native T implication checked',
        numerical_helper_claim=False)


def definitions(native_descriptors=True):
    fields=[('nc-vec',ARRAY),('nc-rows','(_ BitVec 10)'),('nc-count','(_ BitVec 10)'),
        ('nc-job','(_ BitVec 4)'),('nc-layer','(_ BitVec 3)'),('nc-readvalid','Bool'),
        ('nc-readindex','(_ BitVec 10)'),('nc-readvalue','(_ BitVec 58)')]
    defs='(declare-datatypes () ((NormCapture (norm-capture '+' '.join('('+k+' '+t+')'for k,t in fields)+'))))\n'
    zeroarray='((as const '+ARRAY+') '+bv(0,58)+')'
    zero='(norm-capture '+' '.join([zeroarray,bv(0,10),bv(0,10),bv(0,4),bv(0,3),'false',bv(0,10),bv(0,58)])+')'
    defs+='(define-fun nc-zero () NormCapture '+zero+')\n'
    rows=f'(ite (or (= job {bv(0,4)}) (= job {bv(3,4)}) (= job {bv(6,4)})) {bv(256,10)} (ite (or (= job {bv(1,4)}) (= job {bv(2,4)})) {bv(128,10)} (ite (or (= job {bv(4,4)}) (= job {bv(5,4)})) {bv(682,10)} {bv(0,10)})))'
    defs+='(define-fun nc-job-rows ((job (_ BitVec 4))) (_ BitVec 10) '+rows+')\n'
    start=both([n('start_valid_i'),n('start_ready_o'),n('descriptor_valid')])
    defs+=f'(define-fun nc-start ((a {S})) Bool {start})\n'
    record=f'(concat {n("input_source_exponent_i")} {n("input_raw_i")})'
    values=[f'(ite {n("record_write_enable")} (store (nc-vec h) {n("input_row_index_i")} {record}) (nc-vec h))',
        '(nc-rows h)',f'(ite {n("record_write_enable")} (bvadd (nc-count h) {bv(1,10)}) (nc-count h))',
        '(nc-job h)','(nc-layer h)',
        f'(ite {n("record_read_enable")} (= (nc-count h) (nc-rows h)) (nc-readvalid h))',
        f'(ite {n("record_read_enable")} {n("scan_index_q")} (nc-readindex h))',
        f'(ite {n("record_read_enable")} (select (nc-vec h) {n("scan_index_q")}) (nc-readvalue h))']
    fresh='(norm-capture '+' '.join([zeroarray,f'(nc-job-rows {n("fixed_job_i")})',bv(0,10),n('fixed_job_i'),n('fixed_layer_i'),'false',bv(0,10),bv(0,58)])+')'
    defs+=f'(define-fun nc-next ((a {S}) (h NormCapture)) NormCapture (ite (or (not {n("rst_n")}) {n("clear_i")}) nc-zero (ite (nc-start a) {fresh} (norm-capture '+ ' '.join(values)+'))))\n'
    count='(nc-count h)';rows='(nc-rows h)';scan=n('scan_index_q')
    clauses=[
        phase(0,*ACTIVE,15),
        f'(=> {n("range_fault_o")} {phase(15)})',
        both(['(or '+' '.join(eq(rows,bv(v,10))for v in [0,128,256,682])+')',f'(bvule {count} {rows})']),
        f'(=> {phase(*ACTIVE)} '+both([eq(n('rows_q'),rows),f'(distinct {rows} {bv(0,10)})']+([eq(n('job_q'),'(nc-job h)'),eq(n('layer_q'),'(nc-layer h)')]if native_descriptors else [])+[f'(bvult (nc-layer h) {bv(6,3)})',eq(rows,'(nc-job-rows (nc-job h))')])+')',
        f'(=> {phase(1)} '+both([eq(count,n('capture_index_q')),f'(bvult {count} {rows})'])+')',
        f'(=> {phase(*COMPUTE)} (= {count} {rows}))',
        f'(=> {phase(*COMPUTE)} (bvult {scan} {rows}))',
        f'(forall ((ix (_ BitVec 10))) (=> (bvult ix {count}) (= (select (|{TOP}_m record_mem_q| a) ix) (select (nc-vec h) ix))))',
        f'(=> (nc-readvalid h) (= {n("record_read_q")} (nc-readvalue h)))',
        f'(=> {phase(*READ_HELD)} '+both(['(nc-readvalid h)',eq('(nc-readindex h)',scan),eq('(nc-readvalue h)',f'(select (nc-vec h) {scan})')])+')',
        f'(=> (nc-readvalid h) '+both([f'(bvult (nc-readindex h) {rows})',eq(count,rows)])+')',
        f'(=> {phase(9)} '+both([eq(n('result_row_index_o'),scan),eq(n('result_exponent_o'),n('candidate_q')),eq(n('result_last_o'),eq(scan,f'(bvsub {rows} {bv(1,10)})'))])+')',
        f'(=> {phase(10)} (= {scan} (bvsub {rows} {bv(1,10)})))',
    ]
    for i,clause in enumerate(clauses):defs+=f'(define-fun nc-clause-{i} ((a {S}) (h NormCapture)) Bool (=> {n("rst_n")} {clause}))\n'
    defs+=f'(define-fun nc-inv ((a {S}) (h NormCapture)) Bool '+both([f'(nc-clause-{i} a h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(native_descriptors=True):
    defs,clauses=definitions(native_descriptors);H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h NormCapture)','(declare-const hn NormCapture)']
    context=[H('a'),H('an')];step=context+['(norm-memory-native-step a an)','(nc-inv a h)','(= hn (nc-next a h))']
    parts=[f'(nc-clause-{i} an hn)'for i in range(len(clauses))]
    rules={'native-step-weakening':dict(assumptions=context+[T],conclusion='(norm-memory-native-step a an)'),
        'reset-base':dict(assumptions=context+[T,f'(not {n("rst_n")})'],conclusion='(nc-inv an nc-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(nc-inv an hn)'),
        'owned-read-consequence':dict(assumptions=[H('a'),n('rst_n'),'(nc-inv a h)',phase(*READ_HELD)],
            conclusion=both([eq(n('record_read_q'),f'(select (nc-vec h) {n("scan_index_q")})'),eq('(nc-count h)','(nc-rows h)'),f'(bvult {n("scan_index_q")} (nc-rows h))'])),
        'output-and-DONE-ownership':dict(assumptions=[H('a'),n('rst_n'),'(nc-inv a h)'],conclusion=both([
            f'(=> {n("result_valid_o")} '+both([eq('(nc-count h)','(nc-rows h)'),eq(n('result_row_index_o'),n('scan_index_q')),eq(n('result_exponent_o'),n('candidate_q'))])+')',
            f'(=> {n("done_valid_o")} '+both([eq('(nc-count h)','(nc-rows h)'),eq(n('scan_index_q'),f'(bvsub (nc-rows h) {bv(1,10)})')])+')']))}
    return decl,defs,rules


def prepare():
    decl,defs,rules=specification();d=HERE/'norm-capture';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    weak,manifest=transition();(d/'control-step.smt2').write_text(weak);write_json(d/'CONTROL-STEP.json',manifest)
    bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture/history.smt2']
    paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json',*bodies]
    plan=dict(schema='Typed-Q-normalizer-vector-capture-v1',component='norm-capture',bodies=bodies,
        source_manifest='selector-SOURCES.json',native_source='selector/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=decl,rules=rules,order=list(rules),checks_file='norm-capture-CHECKS.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'norm-capture-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed vector capture plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Fresh input-only vector history and actual resetless RAM capture induction frozen.')

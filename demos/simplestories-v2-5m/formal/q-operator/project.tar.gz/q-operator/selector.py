"""Native normalizer's optimized leading-bit selection vs a linear definition.

These are conditional local transition lemmas, not the vector/operator theorem.
"""
import json
from arithmetic import HERE,bv,both,eq,sext,sha,write_json,compile_model

TOP='board1_fixed_vector_normalizer';HELPER='board1_fixed_vector_rne_shift_pipeline1'
S='|'+TOP+'_s|'
n=lambda path,s='a':f'(|{TOP}_n {path}| {s})'


def definitions():
    magnitude='(ite (= ((_ extract 49 49) x) #b1) (bvneg x) x)'
    # Linear mathematical bit-length definition, unlike the native parallel
    # threshold tree. Highest true threshold overrides the lower thresholds.
    length=bv(0,6)
    for bit in range(50):length=f'(ite (bvuge {magnitude} {bv(1<<bit,50)}) {bv(bit+1,6)} {length})'
    defs='(define-fun spec-bit-length50 ((x (_ BitVec 50))) (_ BitVec 6) '+length+')\n'
    required=f'(bvsub (bvadd {sext("e",2)} ((_ zero_extend 4) length)) {bv(15,10)})'
    fit=f'(ite zero {bv(-32,8)} (ite (bvslt {required} {bv(-32,10)}) {bv(-32,8)} (ite (bvsgt {required} {bv(31,10)}) {bv(31,8)} ((_ extract 7 0) {required}))))'
    defs+='(define-fun spec-first-fit ((length (_ BitVec 6)) (e (_ BitVec 8)) (zero Bool)) (_ BitVec 8) '+fit+')\n'
    return defs


def specification():
    context=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)',f'(|{TOP}_t| a an)',n('rst_n'),n('rst_n','an'),
        '(not '+n('clear_i')+')','(not '+n('range_fault_o')+')',n('model_lock_i'),
        '(not '+n('upstream_fault_i')+')','(not '+n('start_valid_i')+')','(not '+n('input_valid_i')+')',
        f'(bvult {n("compute_cycles_q")} {bv(1999999,32)})']
    bitcontext=context+[eq(n('state_q'),bv(11,4))]
    expcontext=context+[eq(n('state_q'),bv(12,4))]
    rules={
        'parallel-bit-length-is-independent-linear-bit-length':dict(assumptions=bitcontext,
            conclusion=eq(n('fit_length_pipe_q','an'),f'(spec-bit-length50 {n("selected_raw")})')),
        'source-exponent-and-zero-capture':dict(assumptions=bitcontext,
            conclusion=both([eq(n('fit_source_pipe_q','an'),n('selected_source_exponent')),
                eq(n('fit_zero_pipe_q','an'),eq(n('selected_raw'),bv(0,50)))])),
        'clamped-first-fit-from-length':dict(assumptions=expcontext,
            conclusion=eq(n('fit_first_pipe_q','an'),f'(spec-first-fit {n("fit_length_pipe_q")} {n("fit_source_pipe_q")} {n("fit_zero_pipe_q")})')),
    }
    return [f'(declare-const a {S})',f'(declare-const an {S})'],definitions(),rules


def prepare():
    selection={'normalizer_pipeline.sv':[TOP],'candidate.sv':[HELPER]}
    compile_model('selector',TOP,selection)
    declarations,defs,rules=specification();(HERE/'selector/history.smt2').write_text(defs)
    bodies=['selector/native.smt2','selector/history.smt2'];paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-normalizer-selector-v1',component='selector',bodies=bodies,
        source_manifest='selector-SOURCES.json',native_source='selector/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=declarations,rules=rules,order=list(rules),checks_file='selector-CHECKS.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'selector-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed selector plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Native whole normalizer retained with real default watchdog; local selector lemmas frozen.')

"""Exact all64 native MAC recurrence coverage in the qualified parent context.

Uses the existing frozen model without recompiling it or its operand packet.
The retained transitions are literal conjuncts of full native T.
"""
import json
import re
from arithmetic import HERE,OPERANDS,bv,both,eq,sext,sha,write_json

TOP='core_workflow_control';S='|'+TOP+'_s|'
ENGINE='u_native.u_six_layers.u_datapath.u_projection.u_shared_engine.u_engine.'
n=lambda path,s='a':f'(|{TOP}_n {path}| {s})'


def definitions():
    source=(OPERANDS/'connected/native.smt2').read_text()
    start=source.index('(define-fun |'+TOP+'_t|')
    end=source.index(')) ; end of module '+TOP,start)+2
    native=source[start:end]
    lines=native.splitlines()
    retained={}
    for line in lines[1:]:
        comment=line.split(';',1)[1].strip()if';'in line else''
        if '.u_projection.u_shared_engine.u_engine.g_tile['in comment and'.g_lane['in comment and'.u_mac.'in comment:
            match=re.search(r'g_tile\[(\d+)\].*g_lane\[(\d+)\].*u_mac\.(product_q|accumulator_q)$',comment)
            if not match:raise ValueError('Unsupported native lane register comment')
            t,l,reg=match.groups();key=(int(t),int(l),reg)
            formula=line.split(';',1)[0].strip()
            if key in retained or not formula.startswith('(= ')or formula.count('(')!=formula.count(')'):
                raise ValueError('Unsupported/duplicate native arithmetic conjunct')
            retained[key]=formula
    expected={(t,l,reg)for t in range(4)for l in range(16)for reg in ['product_q','accumulator_q']}
    if set(retained)!=expected:raise ValueError('Incomplete all64 native recurrence coverage')
    definitions=[];rows=[];goals=[]
    for t in range(4):
        for l in range(16):
            at=t*16+l;M=ENGINE+f'g_tile[{t}].u_tile.g_lane[{l}].u_mac.'
            T=ENGINE+f'g_tile[{t}].u_tile.'
            rhs=both([retained[(t,l,'product_q')],retained[(t,l,'accumulator_q')]])
            # Replace only the bound variables of the literal native formulas.
            rhs=re.sub(r'\bnext_state\b','an',rhs);rhs=re.sub(r'\bstate\b','a',rhs)
            definitions.append(f'(define-fun lane-step-{at} ((a {S}) (an {S})) Bool {rhs})')
            product=f'(bvmul {sext(n(M+"activation_i"),10)} {sext(n(M+"weight_i"),16)})'
            acc=f'(bvadd (ite {n(M+"first_i")} {bv(0,48)} {n(M+"accumulator_q")}) {sext(n(M+"product_q"),22)})'
            goal=both([eq(n(M+'product_q','an'),f'(ite {n(M+"multiply_i")} {product} {n(M+"product_q")})'),
                eq(n(M+'accumulator_q','an'),f'(ite {n(M+"accumulate_i")} {acc} {n(M+"accumulator_q")})'),
                eq(n(M+'multiply_i'),n(T+'op_valid_q')),eq(n(M+'accumulate_i'),n(T+'product_valid_q')),
                eq(n(M+'first_i'),n(T+'product_first_q')),eq(n(M+'activation_i'),n(T+'activation_q')),
                eq(n(M+'weight_i'),n(T+f'weight_q[{l}]')),
                eq(n(M+'accumulator_o'),n(M+'accumulator_q'))])
            goals.append(goal)
            rows.append(dict(lane=at,path=M,transitions=['product_q','accumulator_q'],
                inputs=dict(multiply_i=T+'op_valid_q',accumulate_i=T+'product_valid_q',first_i=T+'product_first_q',
                    activation_i=T+'activation_q',weight_i=T+f'weight_q[{l}]')))
    definitions.append(f'(define-fun all-lane-steps ((a {S}) (an {S})) Bool '+both([f'(lane-step-{at} a an)'for at in range(64)])+')')
    return '\n'.join(definitions)+'\n',goals,rows


def specification():
    defs,goals,_=definitions()
    context=[f'(|{TOP}_h| a)',f'(|{TOP}_h| an)']
    rules={'full-native-T-implies-all-lane-projections':dict(assumptions=context+[f'(|{TOP}_t| a an)'],conclusion='(all-lane-steps a an)'),
        'all64-native-recurrences-and-ports':dict(assumptions=context+['(all-lane-steps a an)'],conclusion=both(goals))}
    return [f'(declare-const a {S})',f'(declare-const an {S})'],defs,rules


def verify_sources():
    from build_connected_parent import reconstruct
    files,manifest=reconstruct();recorded=json.loads((OPERANDS/'connected-SOURCES.json').read_text())
    for name,data in files.items():
        if (OPERANDS/'connected'/name).read_bytes()!=data or recorded['files'][name]!=sha(data):raise ValueError('Changed native parent source')
    if sha((OPERANDS/'connected/native.smt2').read_bytes())!=recorded['native_smt_sha256']:raise ValueError('Changed frozen native parent model')


def context_paths():
    bodies=['../model-consumption/connected/native.smt2','lanes/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json',
        '../model-consumption/connected/compile.ys',*bodies,'lanes/INSTANCE-COVERAGE.json']
    return bodies,paths


def prepare():
    verify_sources();declarations,defs,rules=specification();_,_,rows=definitions()
    d=HERE/'lanes';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs)
    write_json(d/'INSTANCE-COVERAGE.json',dict(lanes=rows,count=64,retained_conjuncts=128,
        native_model='existing qualified connected model, unchanged',recompiled=False,
        numerical_meaning='actual finite-width recurrences; integer bridge and accepted dot ownership separate'))
    bodies,paths=context_paths()
    plan=dict(schema='Typed-Q-native-all64-lifting-v1',component='lanes',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='lanes-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'lanes-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed all64 plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Frozen all64 native recurrences and exact connected-port coverage; no recompilation.')

# Fresh independent complete-Q audit

Review snapshot: November 5, 2026 UTC. This review started with no conversational
history and did not read the existing independent review reports. It inspected
the specification, implementation of the proof constructors/checker, selected
source bindings, current plans/receipts, and saved operating evidence. It ran no
solver, compiler, simulation, hardware, publisher, or implementation-changing
command. The only file written by this reviewer is this report.

## Judgment

The proposed baseline SimpleStories Q component is meaningful and useful. Its
independent integer dot/scaling definition and its finite normalization algorithm
are intelligible. The current construction makes substantial progress beyond
the published operand packet: numerical recurrences, current invocation identity,
actual raw records, normalizer values, source write admissions, actual exponent
state, and full successful completion all have relevant component proofs.

I found no demonstrated incorrect arithmetic equality, desired-result oracle, or
intrinsically circular numerical dependency in the reviewed current route. The
source-instance and overapproximation arguments are reasonable within their
stated digital RTL/frontend trust boundary. This is an endorsement of the route,
not a qualified complete-Q result. The final one-trace closure and qualification
remain necessary, and the precise claim about rejection needs attention.

The appropriate eventual claim is a baseline, fixed-source/model, interruptible
Q value/prefix and completion component theorem. It can cover every actual live
raw/normalized result and admitted Q write with current invocation ownership,
plus full-vector successful DONE. It does not establish retained query RAM,
later reads, correct caller RMSNorm, graph composition, RoPE/attention, resource
authorization, arbitrary fault authorization, or physical DSP/bitstream meaning.

## Findings and required dispositions

### F1 — High: finish checked common-trace closure before qualification

Scope: proof-composition obligation, not a counterexample to a local theorem.

`q_main.py:18–30` obtains its current/step premises from output ownership and
adds numerical certificates. These include `qa-inv`, `nc-inv`, `na-inv`,
`pd-inv`, `qj-inv`, `qh-inv`, `qcert-inv`, `qd-source-inv` and `qdone-inv` at
the common state. The raw record/certificate side additionally needs the
previous/current prefix, tile, mathematical sum, frame, identity, metadata and
accepted-vector histories, with their exact updater equalities and watched-lane
selection. `raw_contract.py` correctly closes the old-health premise with a
source theorem, but its root still contains those history obligations.

`fact_composition.py:20–48` is a sensible exact-premise modus-ponens checker.
`q_check.py:715–800,822–877` reconstructs current local implications, exact
providers and canonical/raw receipts. Neither a list of those providers nor all
of their local UNSAT answers automatically establishes that the full current
endpoint context is reachable from a common reset along one source trace.

The missing final closure must explicitly give:

1. One actual parent/normalizer/exponent product trace, common reset, fixed model
   and external operand/memory boundaries.
2. Each functional ghost history's zero constructor and exact updater on that
   same trace, including lane/tile instantiation and the arbitrary fixed watched
   row. The histories themselves must not depend on the desired output.
3. A reset-base application and an ordered or genuinely mutual step schedule for
   every invariant, closing every next-state invariant premise through an
   already-established provider rather than merely asserting it.
4. Exact source lifting for the engine/tile/helper theorems and literal
   full-native-step implications for every weakened transition.
5. Instantiation of the main endpoint rules, the all-current raw implication,
   and raw job DONE/order at their actual observation events.

The reviewed dependency direction appears viable: operand/control histories
feed fixed-prefix and record value; lifecycle/arguments and normalizer histories
feed output ownership; active capture certification and output ownership feed
post-DONE certification. I did not find a requirement to assume the desired
value in order to establish itself. Nevertheless, that observation is weaker
than a checked complete schedule. In particular, `q_certificate.py:30–61` and
`q_done_certificate.py:21–40` discharge temporary guards carefully, but their
larger native roots still have to be supplied on the common trace.

Disposition: a premise-checked trace ledger/checker is substantive remaining
proof work. Once it accepts the full schedule, the absence of a single huge
monolithic SMT query is not a deficiency. A catalogue that only records provider
names, hashes or `passed` flags would be insufficient.

### F2 — Medium: distinguish numerical rejection from named interruption

Scope: public/readable theorem wording and any claimed arithmetic-outcome
equivalence.

`SPECIFICATION.md:33–41` includes either success or arithmetic rejection in the
normalization meaning. The pure numeric branches in `norm_algorithm.py:25–54`
do implement the stated select/fit/retry/write algorithm. However,
`norm_algorithm.py:59–66` additionally permits an `interrupt` to enter the reject
phase. Its actual predicate includes sticky `range_fault_o`, the real watchdog,
upstream fault, lock loss and invalid protocol activity. The current main rules
(`q_main.py:68–78`) establish values/effects, successful DONE and CLEAR; there is
no separate arithmetic-rejection endpoint or classification rule there.

This is suitable for an interruptible prefix/value/completion theorem, including
the correct transfer on the watchdog edge. It must not be read as proving that
every actual range-fault output is exactly a rejection of the vector-only
numeric algorithm. A source-derived range-fault input cannot serve as independent
justification of that stronger assertion.

Disposition: either say explicitly that the component refines the vector-only
algorithm up to the enumerated cancellation/interruption events, and does not
claim exact numeric-fault classification, or add a consequence that separates
algorithmic rejection from external/protocol/watchdog interruptions. Preserve the
already correct prefix when either kind of event occurs. This does not require
authorizing those interruptions in the whole-device theorem.

### F3 — Medium: complete or explicitly qualify the operating/sensitivity scope

Scope: qualification evidence requested by this plan; not a replacement for
symbolic proof.

The saved connected operating result is useful and candidly scoped. It covers
six layers, all four groups/all 64 lanes, 1,536 exact raw and normalized rows,
stalls and CLEAR/drain. It uses actual projection/normalizer modules connected
by the testbench, with a finite model responder; it is not actual-datapath
controller or formal memory composition (`connected_fixture.py:17–64,105–110`,
`connected-operating-r2/operating/RESULT.json`).

Its activation pattern is currently small: one value pattern in [-31,31] per
layer at exponent -10 (`connected_fixture.py:81–85`). The plan explicitly calls
for negative/zero/maximal legal projection values, both signs, back-to-back
columns, cancellation and a fresh invocation without hard reset
(`PLAN.md:142–147`). Standalone normalizer fixtures give useful zero-prefix
rejection, RNE carry, helper limit, mixed-sign, watchdog and mid-helper CLEAR
evidence, but they do not substitute for maximal-legal native projection
arithmetic cases.

The connected source mutations currently present are wrong product sign,
missing FIRST and wrong postscale split (`connected_fixture.py:91–95`). The plan
also names dropped/duplicated accumulation, shifted product/tag and
stale/cross-row normalization (`PLAN.md:149–153`). There is no saved current
operating mutation for those latter cases in the inspected fixture set.

Disposition: complete the promised cases/controls or explicitly narrow the
qualification's operating-evidence statement. Add at least an actual-only
normalizer stale/cross-row defect and an order/product-tag defect, keeping the
independent reference and environment unchanged. The maximal-legal projection
cases are valuable for signedness and bound sensitivity even though the
symbolic local integer proof is broader than these finite patterns. Final
logical refusal controls should include missing provider, missing actual lane
or instance and changed recurrence after ordinary integrity fields are refreshed.

### F4 — Medium: fresh portable qualification remains incomplete

Scope: qualification/replay packaging, after F1 is closed.

At the inspected snapshot, all six main UNSAT endpoints have passing raw logs:
held normalized value, transferred normalized value, actual write value/address/
order, actual exponent update/reset, full Q stage DONE, and CLEAR authority
revocation. The CLEAR/nonzero-exponent compatibility control is SAT. The
nonzero-write compatibility receipt is not yet in `q-main-CHECKS.json`, so its
`all_rules_passed` is false. Both positive controls are explicitly compatibility
with invariant context, not reachability (`q_main.py:76–78,95–97`). That labeling
is correct and must survive qualification.

I independently read selected raw log files and checked their exact expected
answer, log hash, current plan hash and passed flag using a small read-only
standard-library script. This was not a call to `q_check`, canonical-query
reconstruction, or fresh engine replay. Current selected plans/receipts for
output ownership, exponent, post-DONE source/value certification, captured-vector
certification, raw record/capture support, lifecycle/arguments, normalizer,
frontier/raw scope, fixed prefix, integer engine and lanes had complete expected
raw answers and matching plan hashes.

The compiled exponent cone has its own byte-identical source translation replay
(`q_exponent.py:90–104`, `q-exponent/REPLAY.json`). That is good evidence for that
cone; it is explicitly translation-only and is not a complete-Q portable replay.

Disposition: finish the pending control, freeze the complete trace/claim and
source/spec pins, export the full dependency closure, and run the promised fresh
portable replay with canonical-query and transformed-engine-query equality.
Include the trace checker and logical refusal controls in that replay. Keep old
failed/superseded receipts as provenance while selecting only the successful
current derivation. Do not mark qualification complete on the basis of this
read-only review or local logs.

### F5 — Low: update the human continuation documents at the final boundary

Scope: maintainability and avoiding misleading status.

`PLAN.md` and `NORMALIZATION-PROFILE-DRAFT.md` still describe a pre-proof review,
and `CONTINUATION.md` describes older running/missing joins. The specification
appropriately still says not yet proved. Current CHECKS files are more advanced
than that prose. This did not affect my assessment because I inspected the
current constructors/receipts.

Disposition: after qualification, record the exact claimed result, exclusions,
accepted/pending findings, current proof/trace entry point, and fresh replay
packet. Retaining the draft filename for provenance is harmless if incorporation
and the fixed algorithm version are explicit.

## Technical assessment of the current construction

The raw value target is independent. `q_model.py:15–32` defines the model row
layout and `Q-prefix` from the accepted activation array, model image and row/
column identities. No native product, accumulator, private reply or output is
an argument to that prefix. `q_identity.py` records the already accepted input
snapshot at actual engine begin. `q_prefix_r3.py` closes the native control
consequences and retains the fixed-input guard when introducing its implication.

The integer engine covers the numerical implementation rather than reusing the
operand-only transition weakening as arithmetic correctness. `math_fold.py`
tracks mathematical products/sums of captured operands, proves finite-width
representation with type bounds, and connects the completed sum to the 35-bit
dot. The broader full-type product bound is sufficient for this exactness;
the tighter legal-Q bound in the readable specification also follows directly
from the specified input/weight ranges. Split postscale has independent word/
integer correspondence providers. `q_engine.py:44–71` checks the actual engine
ports and identical full numerical subtree, then maps functional histories to
that instance. `lanes.py:20–79` separately inventories all 128 product/accumulator
transition conjuncts and all 64 input/recurrence correspondences.

The all-current raw result extension addresses first-fault safety instead of
simply assuming away current failure. `q_raw_scope.py:17–23` derives previous
nonfailure from next live raw VALID. `raw_contract.py:16–32` composes that result
with the certified frontier theorem, leaving no current or previous arbiter-
health assumption in its root. A source implication and modus ponens are a valid
way to do this; an additional fabricated UNSAT receipt is neither needed nor
appropriate. The remaining history roots are exactly why F1 is necessary.

Normalizer numerical state is not a free expected-output oracle. The candidate,
bit length, Shift/RNE result, fit/retry and mantissa updates in `na-step` use
only the accepted vector and independently defined operations. Native events
select progress/stuttering or interruption, not the desired numerical result.
`norm_capture.py` proves correspondence of the actual resetless record RAM and
reads with a fresh accepted-record array. `norm_shift.py` checks the exact helper
instance and its current-vector relation. `q_normalizer_product.py:74–90` binds
all ten formerly free normalizer outputs, all controls, and Q payloads at actual
Q start/VALID events. Leaving other-stage payloads arbitrary is a conservative
abstraction; the concrete source is a permitted specialization.

Separate start handshakes are handled in the right place. Lifecycle records
actual stage/head epochs and each child acceptance; R2 proves start-seen/done-
seen coherence. Arguments R3 records a complete accepted input-only vector and
scopes ownership to authoritative phases. The watched record, active capture
certificate and post-DONE certificate carry value meaning across the actual
projection completion, normalizer work and parent stage DONE. An arbitrary fixed
watch is an appropriate pointwise argument because the histories do not depend
on the observer; the final trace construction must make that quantification
explicit.

Actual output effects are narrowly and correctly named. `q_write_source.py`
checks the exact guarded production Q write-enable expression and restricts it
to E_PROJ/STAGE_Q. `q_output_ownership.py:17–33` checks the real query-store ports,
including address `output_index_q[7:0]` and data `norm_result_mantissa`. The main
endpoint proves address/data/order and counts actual admissions. None of this
claims retained RAM or subsequent read semantics.

The exponent is actual sequential source state. `q_exponent.py:21–69` retains
the production register, checks all assignments, extracts a complete one-register
fanin and permits exactly nine actual-signal cuts. Those cuts plus reset/CLEAR/
clock are bound to parent getters. It does not replace the register with a
handwritten desired-value state machine. Reset overrides the next observation;
CLEAR holds the physical exponent while revoking authority. The source update
does not acquire an invented child-fault gate. The eventual theorem should keep
that precise observable behavior.

The reviewed abstractions are overapproximations. Forgetting the pure finite
prefix, uniform integer multiplication, selected signed interpretations or
native function definitions preserves the original interpretation as one model
of the more permissive query. Certificate predicate forgetting is suitable for
pure equality transport once source/value premises have been closed. It is not
appropriate to import SAT compatibility controls as provider facts; the current
composition/checker explicitly rejects that. Their usefulness depends on retaining
the exact current typed rule and source/premise reconstruction, which the checker
is designed to do.

## Recommended completion order

1. Close F1 with the actual common-reset and per-edge premise schedule. Audit the
   accepted model/memory boundaries at that root and the arbitrary watched-row
   specialization. Review any newly exposed unclosed premise as a proof gap.
2. Resolve F2 in the exact theorem wording or add the missing rejection
   classification; avoid accidentally promoting safety to termination or fault
   authorization.
3. Finish the compatibility receipt and the explicitly promised operating and
   source/logical sensitivity controls. Label their finite/compatibility scope.
4. Freeze and freshly replay a portable closure, including source translation,
   checker reconstruction, transformed queries, complete bases/steps/cases and
   endpoint instantiation. Only then issue a qualified component result.

The fixed-source/model Q arithmetic and normalization boundary is a worthwhile
checkpoint before caller RMSNorm/whole-graph integration. Its remaining work
should be driven by the exact trace and qualified claim, not by accumulating more
isolated UNSAT counts or enlarging the component to retained storage or physical
hardware semantics.

## F1 follow-up: concrete common-trace interface and schedule

This follow-up inspected the actual old `build_q_composition.py`,
`build_parent_capture.py`, `build_mac_model.py`, `build_tile_metadata.py`,
`build_api.py`, `build_words.py`, and `check_derivation.py`, together with the
new source/history constructors. It still ran no engine/compiler. A separate
read-only standard-library script parsed the current PLAN assumptions and checked
the invariant-dependency topology under the source/state/history renamings below.
It found no open invariant premise in the proposed regular-step order. This is
a concrete positive result about the DAG, not a validation of all remaining
source, updater, guard or bootstrap obligations.

### Smallest useful checker interface

Use a fixed, code-reconstructed trace bundle rather than a free-form inventory.
Let the actual state at edge t be `(a_t,z_t,e_t)` for Root, Norm and QE. The
trace premise contains actual full Root/Norm/QE transitions, each native H
predicate, `qn-bind(a_t,z_t)` and `qe-bind(a_t,e_t)`, and the old qualified
packet's exact source/model/memory boundaries. The additional Norm/QE bindings
restrict the older free numerical model; they do not weaken its theorem.

Define each history by its existing constructor/updater, beginning at the proved
post-reset state a1. Keep one lagged bundle for a_(t-1) and the already-proved
updater equations into a_t. The checker then needs only these small proof-rule
operations:

| Operation | Required check |
|---|---|
| `apply(rule,substitution)` | Reconstruct the exact UNSAT provider rule, perform capture-free typed substitution, require all flattened antecedents already available, then add its conclusion. |
| `parts(label,substitution)` | Apply every required preservation part and its exact `parts-join`; recursively verify declared case dependencies. No omitted part or SAT provider is allowed. |
| `theorem(rule,substitution)` | Import the verified arbitrary-constant rule as its literal implication, rather than importing its conclusion. This is needed for NA's `provider_facts` and the Q-prefix defining laws. |
| `source_lift(instance,rule)` | Check the pinned complete source/ports/parameters, exact mapped getter sorts and history definitions, and actual common reset/clock. Instantiate the universal identical-source local trace rule at that actual instance. |
| `closed_step(component)` | Reconstruct the component's existing meta-composition and guards, verify its exact root implies all pure engine premises, then export its invariant consequence. Supported components are fixed-Q prefix, active certificate and DONE certificate. |

`fact_composition.apply` already supplies most of the first operation. The
closed-step operation must be specific to the current constructors, not a
permission to declare any `root_assumptions` sufficient. In particular,
`Q-prefix-native-step-theorem` is a defined implication whose validity comes from
the checked applications and preservation parts; its presence in a history file
is not itself an engine proof.

For source lifting, using full actual Root T (or Norm T for the helper) as the
replacement source-step premise is the simplest safe choice. Full actual source
behavior supplies the corresponding local T, and the already-checked local
weakening supplies its control step. This avoids pretending that local and
parent SMT state sorts are equal. It also avoids relying on parent MAC/helper-
omitting weakenings for numerical recurrences.

There is a specific current interface gap: `q_engine.translate` maps local state
sort/getters/H and functional history definitions, but it does not map local
T/I or `prefix-native-step`. That is sufficient for the current endpoint
contracts in `source_contracts.py`; it is not a ready-made reset/step trace
lifting API. Extend a checked source-lift schema using the same exact
`q_engine.binding`, `tile_bindings.record('tile-held')`, `lanes` and
`norm_shift.source_binding` evidence. Never silently treat a local T call as a
fact about an unrelated root state.

The invariant family must quantify over fixed BV2 tile/BV4 lane parameters, or
explicitly maintain all 64 histories. A valid formulation is
`th[t,tile,lane]`/`mh[t,tile,lane]`, with all other histories shared where their
definitions are independent of those parameters. For a certificate, fix watch
and use `tile=watch[5:4]`, `lane=watch[3:0]` throughout its history. For the raw
endpoint, instantiate the already-universal family at the live row's lane at
observation time. Do not change a single history's tile/lane selector each edge.

### Exact old-packet interface

The old `qcomposition` conclusion alone is not enough. It exposes actual operand
consequences, whereas new Q-prefix and Q-metadata steps need `macmodel-inv` and
`tilemeta-inv` themselves. Reuse the qualified packet's component trace theorems
on the exact histories:

| Old histories/invariants | Common-trace binding |
|---|---|
| `ApiHistory api`, `api-next(a,api)` | Same actual root accepted-request/response events; embedded OrderedHistory remains unchanged. |
| `WordsHistory w`, `words-next(a,w)` | Same actual root packer/capture events. |
| `CaptureHistory ch`, `capture-next(a,ch)` | Literal actual-parent getter substitution from `build_parent_capture`; zero is `capture-zero(a1)`, which includes actual resetless activation memory. |
| `api-inv`, `reader-inv`, `words-inv`, `header-inv` | Import their proved current/post trace instances with the same `api,w,model`; close service aliases through the packet's already-verified provider chain. |
| `capture-inv`, `macmodel-inv`, `tilemeta-inv` | Import their proved current/post instances at the same `ch,api,w,model`. These are stronger trace consequences needed by the new steps. |

`check_derivation.py` already reconstructs these old schemas/providers and exact
recorded receipts. The trace checker should validate that qualified dependency
and its exact functional-history definitions; it should not invent an internal
correct reply assumption or treat `QUALIFICATION.json:qualified` as the proof.
No old packet file needs to be modified or its 449 engines rerun merely to
instantiate these unchanged trace theorems.

For the reset edge a0→a1, the common premises are the actual product H/T/binds,
the old compiler-initial configuration at a0, and only the actual common reset
low at a0. Check the source aliases from that reset to datapath, engine, tiles
and normalizer; do not insert separate reset assumptions at each leaf. Apply
the existing reset bases in this order:

1. Old packet gives `api-zero`, `words-zero`, `capture-zero(a1)` and their trace
   invariant package. Source-lifted prefix/tile/frame/math/sum-frame/MS bases
   give their zero histories, with lineage after prefix.
2. Q-columns base uses post capture/prefix/lineage; Q-identity uses post capture;
   fixed-Q prefix base uses post capture/prefix. Q-metadata and Q-job bases are
   independent native-root bases.
3. NC and actual-helper SH bases precede NS; NA requires NC. Lifecycle, QA and
   PD have their own actual-product reset bases with the same zero histories.
   QOutput's reset base uses the actual bound QE state at a1, not a free zero
   exponent oracle.
4. Active certificate, DONE-source and DONE-value certificate have unconditional
   empty-history base consequences. Apply them to those same post-reset zero
   histories. Retain the raw-reset-base consequence for the first-step
   certificate bootstrap described below.

No reset-base rule requires an additional idle CLEAR. Because histories begin
at a1, their updater equalities are asserted by definition for t≥1; they are not
silently asserted across a0→a1 in place of the proved zero constructors.

### Regular-step order, with exact post-state dependencies

Every current-state invariant below comes from the induction hypothesis. Every
updater equality comes from the fixed functional recursion, never a selected
desired-result witness. The following linear order passed the read-only
invariant-premise topology check:

| Order | Newly established post-state invariant | Post-state premises supplied earlier |
|---|---|---|
| 0 | Old packet trace package | Old packet's own closed trace theorem and shared histories. |
| 1 | `prefix-inv`, `tile-inv`, `frame-inv` | None; actual-source lifted steps. |
| 2 | `lineage-inv` | `prefix-inv`. |
| 3 | `sumframe-inv`, `math-inv`, `ms-inv` | Prefix/lineage for the first two; frame for metadata safety. |
| 4 | `qc-inv` | Capture, prefix, lineage, tile. |
| 5 | `qi-inv` | Capture, prefix, lineage, tile, qc. |
| 6 | `qp-inv` via closed Q-prefix step | The preceding control/identity posts; current old `macmodel-inv`; exact checked defining-law implications. |
| 7 | `qmd-inv`, `qj-inv` | Capture/tilemeta/frame for qmd; capture for qj. |
| 8 | `nc-inv`, actual-helper `shift-inv` | None; full native Norm/source-helper behavior. |
| 9 | `ns-inv` | NC and helper shift. |
| 10 | `na-inv` | NC, helper shift, NS, plus the verified current response theorem as an implication. |
| 11 | `ql-inv` | None; full bound Root+Norm product. |
| 12 | `qa-inv` | Lifecycle, capture and NC. |
| 13 | `pd-inv` | Lifecycle, capture, NC, QA and qj. |
| 14 | `qh-inv` | Lifecycle, capture, QA, NC, NA, PD and qj; actual QE transition and bound inputs. |
| 15 | `qcert-inv` via closed certificate step | Current and lagged raw family plus current source invariants; post lifecycle/capture/NC/QA/qj. No QOutput or post numeric certificate is needed. |
| 16 | `qd-source-inv` | Same source/control posts used by QOutput; only current QOutput is a premise of the saved step. |
| 17 | `qdone-inv` via closed DONE-certificate step | `qd-source-inv` post, current active certificate and current DONE certificate. Post active certificate is not assumed. |

The table uses some conservative ordering where two rows could be parallel.
There is no regular-step invariant cycle. The full actual product supplies
`operand-native-step`, `norm-memory-native-step`, and `qe-control-step` by their
checked implication rules; the weaker steps must never be primitive environment
assumptions. The actual exponent state has no ghost numerical updater: e/een
follow the compiled QE T with all actual-input bindings.

### Concrete mapping examples

For NA, instantiate the normalizer-local rule with
`a→z_t`, `an→z_(t+1)`, `h→na_t`, `hn→na_(t+1)`, keeping the NC/SH history names
at their matching t/t+1 values. The exact updater is
`na_(t+1)=na-next(z_t,nc_t,na_t)`. NC post and helper-SH post are already proved
in row 8; NS post is proved in row 9. Import
`norm-shift:actual-response-current-vector` as its verified literal implication,
then apply all NA preservation parts and `parts-join`. No native candidate or
helper numerical reply is assigned as a ghost input.

For QOutput, instantiate `q-output-ownership-r3` directly at
`(a_t,a_(t+1),z_t,z_(t+1),e_t,e_(t+1))`, with `life/lifen`, `qa/qan`,
`nc/ncn`, `na/nan`, `qj/qjn`, and `h/hn` at those same two edges. Add the
literal existing updater
`hn=qh-next(a_t,z_t,life_t,e_t,h_t)`. Post lifecycle/QA/NC/NA/PD/qj are all
available before its preservation parts. Supply `qe-control-step` from the full
bound product. This is the precise point where a post QA/NA/PD premise must
be proved, rather than assumed because its provider name is present.

For the active Q certificate, instantiate its reconstructed larger root with:

| Constructor names | Trace values |
|---|---|
| `ap,a,an` | `a_(t-1),a_t,a_(t+1)` |
| `chp,ch,chn`; `qjp,qj,qjn` | Their matching lag/current/post histories and both exact updater edges. |
| `pcp,pc`; `thp,th`; `mhp,mh`; `frp,fr`; `qip,qi` | Lag/current raw history family, with exact previous updater equations. |
| `z,zn`; `life,lifen`; `qa,qan`; `nc,ncn` | Current/post normalizer/lifecycle/argument/capture histories. |
| `watch,tile,lane,model` | One rigid watch/model; tile/lane fixed from watch's low six bits. |

The root needs `sumframe-inv/math-inv/ms-inv` at the current a_t, and
`tile-inv/qc-inv/macmodel-inv/qp-inv/qmd-inv/tilemeta-inv` at the predecessor
a_(t-1), exactly as the saved `q-certificate-PLAN.json` says. Those predicates
come from the lagged induction bundle, not from a fresh source-free oracle.
Its current/post source predicates come from rows 0 and 7–13. Reconstruct the
future-authority and watched-write implication introductions from
`q_certificate.composition`; then apply its pure `preserved` rule. Supplying
only that pure rule's three assumptions as unproved facts would skip the
substantive value proof.

### One concrete initialization gap: the first lagged-certificate step

Existing reset-base rules establish the post-reset bundle at a1. The active
certificate step is a three-state rule, so its first application a1→a2 would
otherwise demand raw predecessor invariants at a0. They are not conclusions of
those reset-base rules. A one-edge ledger that silently begins applying the
three-state root there leaves real premises open.

The smallest clean fix is a source-only bootstrap for this first certificate
preservation step. `q-raw-scope:raw-reset-base` proves no raw VALID at a1 after
the single actual reset edge a0→a1. The initialized NC count at a1 is zero.
Under future certificate authority at a2, the already-proved capture-array rule
requires either an old watched row or a current actual record write. The old
case is impossible at count zero. In the new case,
`q-capture-support:Q-record-write-source-and-arguments` requires raw VALID at
a1, contradicting the reset-base consequence. Thus future authority is empty
and the certificate holds without any raw numerical predecessor premise.

Encode that as a checked small implication/contradiction derivation (or one
small source-free engine join using those exact provider consequences). Begin
the ordinary three-state certificate induction at t≥2, where a_(t-1) already
has the full proved bundle. This requires no extra reset/idle edge and preserves
arbitrary old physical arithmetic/RAM state. Other histories and main endpoints
can use their ordinary first step; first-post-reset raw endpoints are empty by
the same raw-reset-base rule.

An alternative is a checked common-reset-observation lemma establishing all
needed a0 ghost invariants and updater compatibility. It is more cumbersome:
`capture-zero` is state-dependent because it contains resetless activation RAM.
The old reset base yields `capture-zero(a1)`, while the recursive reset updater
yields `capture-zero(a0)`. Equating them requires actual reset-edge memory
stability, not the assertion that reset clears RAM. The source-only bootstrap
avoids introducing that unnecessary first-edge equality.

After this bootstrap and the explicit source-lift/interface work, the existing
regular post-state premises have a sound topological discharge route. The main
and raw endpoint rules can then be instantiated at every edge from the proved
bundle and the named observation guard; no desired-value premise remains at
the public boundary.

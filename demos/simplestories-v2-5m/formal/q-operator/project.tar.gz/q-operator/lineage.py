"""Common engine/tile histories: completed prefix to held stage0 dot argument.

The watched tile/lane are fixed finite proof parameters, covering all64 paths.
No desired dot is an input. The numerical consequence uses the separately
proved identical-source tile contract on its exact mapped history.
"""
import json
import re
from arithmetic import HERE,bv,both,eq,sha,write_json
from prefix_control import TOP,S,n
from tile import TOP as LOCAL
from tile_hold import specification as held_specification
from pruned_arithmetic import parse,emit,atoms


def translated_history():
    _,source,_=held_specification();ast=parse(source)
    names={node[1]for node in ast if node[0]=='define-fun'and node[1]!='tile-zero'}
    local=(HERE/'tile/native.smt2').read_text();parent=(HERE/'prefix/native.smt2').read_text()
    fields=sorted(set(re.findall(r'\|'+LOCAL+r'_n ([^|]+)\|',source)))
    getters={};definitions=[]
    for field in fields:
        marker=f'(define-fun |{LOCAL}_n {field}| ((state |{LOCAL}_s|)) '
        if local.count(marker)!=1:raise ValueError('Missing unique local getter '+field)
        tail=local.split(marker,1)[1]
        match=re.match(r'(Bool|\(_ BitVec \d+\)) ',tail)
        if not match:raise ValueError('Unsupported local getter sort')
        sort=parse(match[1])[0]
        name='|lineage-native '+field+'|';getters[f'|{LOCAL}_n {field}|']=name
        alternatives=[]
        for t in range(4):
            path=f'g_tile[{t}].u_tile.'+field
            if f'|{TOP}_n {path}|'not in parent:raise ValueError('Missing actual source instance getter '+path)
            alternatives.append(parse(n(path))[0])
        value=alternatives[3]
        for t in reversed(range(3)):value=['ite',['=','tile',parse(bv(t,2))[0]],alternatives[t],value]
        definitions.append(['define-fun',name,[['a',S],['tile',['_','BitVec','2']]],sort,value])
    def translate(node):
        if not isinstance(node,list):return S if node==f'|{LOCAL}_s|'else node
        if node and isinstance(node[0],str)and node[0]in getters:
            if len(node)!=2:raise ValueError('Unsupported native getter arity')
            return [getters[node[0]],translate(node[1]),'tile']
        result=[translate(x)for x in node]
        if result and result[0]=='define-fun'and result[1]in names:
            result[2].append(['tile',['_','BitVec','2']])
        elif result and isinstance(result[0],str)and result[0]in names:
            result.append('tile')
        return result
    transformed=[translate(node)for node in ast]
    if f'|{LOCAL}_s|'in set(atoms(transformed))or any(name in set(atoms(transformed))for name in getters):raise ValueError('Incomplete exact instance/history substitution')
    return '\n'.join(emit(node)for node in [*definitions,*transformed])+'\n'


def field(name,state='a'):
    return f'(|lineage-native {name}| {state} tile)'


def definitions():
    defs=translated_history()
    owned='(bvugt (pc-acc pc) '+bv(0,10)+')'
    phase=lambda *states:'(or '+' '.join(eq(n('state_q'),bv(i,3))for i in states)+')'
    pre=phase(1,2,3);emitphase=phase(4)
    v0=f'(= ((_ extract 0 0) {n("scale_valid_q")}) #b1)'
    row=n('row_pipe_q[0]');rowlane=f'((_ extract 3 0) {row})'
    clauses=[
        both([eq(field('op_valid_q'),'(th-o th)'),eq(field('product_valid_q'),'(th-p th)'),
            f'(=> (th-o th) {eq(field("op_first_q"),"(th-f th)")})',
            f'(=> (th-p th) {eq(field("product_first_q"),"(th-pf th)")})']),
        eq('(th-owned th)',owned),
        f'(=> {pre} (not (th-read th)))',
        f'(=> {pre} (= {n("scale_valid_q")} {bv(0,4)}))',
        f'(=> (and {emitphase} {v0}) (= (th-read th) (= {rowlane} lane)))',
        f'(=> (and {emitphase} {v0}) (= {n("selected_tile_q")} ((_ extract 5 4) {row})))',
        f'(=> (and {emitphase} (th-read th)) (= (th-dot th) ((_ extract 34 0) (th-sum th))))',
    ]
    params=f'((a {S}) (pc PrefixHistory) (th TileHistory) (lane (_ BitVec 4)) (tile (_ BitVec 2)))'
    for i,clause in enumerate(clauses):defs+=f'(define-fun lineage-clause-{i} {params} Bool (=> {n("reset_n")} {clause}))\n'
    defs+=f'(define-fun lineage-inv {params} Bool '+both([f'(lineage-clause-{i} a pc th lane tile)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda state:f'(|{TOP}_h| {state})'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))']
    current=['(prefix-inv a pc)','(lineage-inv a pc th lane tile)']
    step=[H('a'),H('an'),'(prefix-native-step a an)',*current,'(= pcn (prefix-next a pc))','(prefix-inv an pcn)',
        '(= thn (tile-next a th lane tile))']
    parts=[f'(lineage-clause-{i} an pcn thn lane tile)'for i in range(len(clauses))]
    root=[H('a'),n('reset_n'),*current]
    phase=eq(n('state_q'),bv(4,3));v0=f'(= ((_ extract 0 0) {n("scale_valid_q")}) #b1)'
    selected=[phase,v0,eq('tile',n('selected_tile_q')),eq('lane',f'((_ extract 3 0) {n("row_pipe_q[0]")})')]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),f'(|{TOP}_t| a an)','(not '+n('reset_n')+')','(prefix-inv an prefix-zero)'],
            conclusion='(lineage-inv an prefix-zero tile-zero lane tile)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(lineage-inv an pcn thn lane tile)'),
        'complete-before-read':dict(assumptions=root+[n('issue')],conclusion=both(['(th-owned th)',eq('(pc-acc pc)',n('columns_q'))])),
        'selected-read-sum':dict(assumptions=root+selected,conclusion=both(['(th-owned th)','(th-read th)',eq('(th-dot th)','((_ extract 34 0) (th-sum th))')])),
        'native-input-dot':dict(assumptions=root+selected+['(tile-inv a th lane tile)'],
            conclusion=eq('(frame-input-D a)','((_ extract 34 0) (th-sum th))'))}
    return declarations,defs,rules


def prepare():
    declarations,defs,rules=specification();d=HERE/'lineage';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-prefix-tile-lineage-v1',component='lineage',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='lineage-CHECKS.json',
        inductive_provider='prefix-r2-PLAN.json',component_provider='tile-held-PLAN.json',binding_policy='exact-four-source-tiles-with-fixed-BV2/BV4-parameters',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'lineage-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed lineage plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Frozen all64 source-instance prefix/owned-sum/held-read lineage; no desired-dot premise.')

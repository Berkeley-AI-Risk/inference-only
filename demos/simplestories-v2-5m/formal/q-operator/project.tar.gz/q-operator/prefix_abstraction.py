"""Forget only the pure recursive Q-prefix definition in a canonical query.

The selected exact defining-law instances remain checked provider theorems.
An arbitrary same-signature function admits the real finite recursive prefix,
so UNSAT is stronger than the original native query. No circuit definition,
constraint, assertion or provider premise is edited or omitted.
"""
from q_model import definitions
from pruned_arithmetic import parse,emit


def transform(text):
    original=[line for line in definitions().splitlines()if line.startswith('(define-fun-rec Q-prefix ')]
    if len(original)!=1:raise ValueError('Missing unique independent prefix definition')
    line=original[0];tree=parse(line)
    if len(tree)!=1 or tree[0][:2]!=['define-fun-rec','Q-prefix'] or len(tree[0])!=5:raise ValueError('Changed recursive prefix declaration')
    declaration=emit(['declare-fun','Q-prefix',[argument[1]for argument in tree[0][2]],tree[0][3]])
    lines=text.splitlines(keepends=True);matches=[i for i,l in enumerate(lines)if l.rstrip('\n')==line]
    if len(matches)!=1:raise ValueError('Exact single prefix definition required')
    i=matches[0];ending='\n'if lines[i].endswith('\n')else''
    changed=list(lines);changed[i]=declaration+ending
    if ''.join(changed[:i]+[line+ending]+changed[i+1:])!=text:raise ValueError('Changed query outside the one pure definition')
    return ''.join(changed)

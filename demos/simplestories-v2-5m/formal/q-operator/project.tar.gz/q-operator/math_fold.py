"""Integer interpretation of the same first-delimited accepted-operand fold.

The integer history multiplies captured input words, not native product or
accumulator replies. Proved word semantics discharge the exact representation
bridges. Model/argument identity remains a separate current-Q application.
"""
import json
from arithmetic import HERE,bv,both,eq,signed,sha,write_json
from lineage import TOP,S,n,field
from semantic_facts import fact

B=1<<24


def total():
    return f'(+ (ite (th-pf th) 0 {signed("(th-sum th)",48)}) {signed("(th-P th)",26)})'


def definitions(corrected=False):
    defs='(declare-datatypes () ((MathHistory (math-history (mh-P Int) (mh-S Int))))))\n'
    if corrected:defs=defs.replace('(mh-S Int))))))','(mh-S Int)))))',1)
    defs+='(define-fun math-zero () MathHistory (math-history 0 0))\n'
    revoke=f'(or (not {field("reset_n")}) {field("kill_i")} {field("begin_i")})'
    product=f'(* {signed("(th-A th)",16)} {signed("(th-W th)",10)})'
    sm='(+ (ite (th-pf th) 0 (mh-S mh)) (mh-P mh))'
    nxt=f'(ite {revoke} math-zero (math-history (ite (th-o th) {product} (mh-P mh)) (ite (th-p th) {sm} (mh-S mh))))'
    defs+=f'(define-fun math-next ((a {S}) (th TileHistory) (mh MathHistory) (tile (_ BitVec 2))) MathHistory {nxt})\n'
    count='(bv2int (pc-acc pc))'
    clauses=[eq(signed('(th-P th)',26),'(mh-P mh)'),
        both([f'(<= (- {B}) (mh-P mh))',f'(<= (mh-P mh) {B})']),
        eq(signed('(th-sum th)',48),'(mh-S mh)'),
        both([f'(<= (- (* {count} {B})) (mh-S mh))',f'(<= (mh-S mh) (* {count} {B}))'])]
    params=f'((a {S}) (pc PrefixHistory) (th TileHistory) (mh MathHistory))'
    for i,clause in enumerate(clauses):defs+=f'(define-fun math-clause-{i} {params} Bool (=> {n("reset_n")} {clause}))\n'
    defs+=f'(define-fun math-inv {params} Bool '+both([f'(math-clause-{i} a pc th mh)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(corrected=False):
    defs,clauses=definitions(corrected);H=lambda state:f'(|{TOP}_h| {state})'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const mh MathHistory)','(declare-const mhn MathHistory)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))']
    product=fact('word16x10-function',{'A':'(th-A th)','W':'(th-W th)'})
    addition=fact('word48-add26-function',{'x':'(th-sum th)','y':'(th-P th)','first':'(th-pf th)'})
    context=[H('a'),H('an'),'(prefix-native-step a an)','(prefix-inv a pc)','(prefix-inv an pcn)',
        '(lineage-inv a pc th lane tile)','(lineage-inv an pcn thn lane tile)',
        '(= pcn (prefix-next a pc))','(= thn (tile-next a th lane tile))','(= mhn (math-next a th mh tile))','(math-inv a pc th mh)',product,addition]
    fit=both([f'(<= (- 140737488355328) {total()})',f'(< {total()} 140737488355328)'])
    parts=[f'(math-clause-{i} an pcn thn mhn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),f'(|{TOP}_t| a an)','(not '+n('reset_n')+')'],conclusion='(math-inv an prefix-zero tile-zero math-zero)'),
        'sum-fits48-before-update':dict(assumptions=context+[n('reset_n')],conclusion=fit),
        **{'preserved-'+str(i):dict(assumptions=context,conclusion=part,**({'dependencies':['sum-fits48-before-update']}if i==2 else{}))for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(math-inv an pcn thn mhn)'),
        'current-sum-fits35':dict(assumptions=[H('a'),n('reset_n'),'(prefix-inv a pc)','(math-inv a pc th mh)'],
            conclusion=both([f'(<= (- 17179869184) {signed("(th-sum th)",48)})',f'(< {signed("(th-sum th)",48)} 17179869184)'])),
        'emit-count-and-reference':dict(assumptions=[H('a'),n('reset_n'),'(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(math-inv a pc th mh)',n('result_valid_o')],
            conclusion=both(['(th-owned th)',eq('(pc-acc pc)',n('columns_q')),eq(signed('(th-sum th)',48),'(mh-S mh)')]))}
    return declarations,defs,rules


def prepare():
    declarations,defs,rules=specification();d=HERE/'math-fold';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','lineage/history.smt2','math-fold/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json','lineage-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-integer-fold-v1',component='math-fold',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='math-fold-CHECKS.json',
        inductive_providers=['prefix-r2','lineage'],component_provider='tile-held',semantic_providers=['word16x10-function','word48-add26-function'],
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'math-fold-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed mathematical fold plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Independent integer history, full input-type bounds and exact word representation frozen; current model identity still separate.')

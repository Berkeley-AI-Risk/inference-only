"""Close exact native control providers before the pure integer induction.

The engine algebra query sees only checked consequences and the two literal
history hypotheses. The recorded root still includes the actual native parent
step and all common source histories; no desired prefix is imported as a fact.
"""
import copy,json
from arithmetic import HERE,both,sha,write_json
from q_columns import TOP,S
from q_prefix_r2 import specification as original,provider_facts
from q_prefix import definitions
from q_identity import body_files as identity_body_files
from q_identity import provider_fact as fixed_input_fact
from fact_composition import apply

CONTROL_RULES=['sum-owner-and-snapshot-continuity','pending-input-and-column-continuity','sum-pending-is-current-owned',
    'current-pending-count-and-FIRST','revoked-prefix-is-empty','continuing-prefix-count-step']


def applications():
    return [dict(kind='engine',provider='q-prefix-control',rule=name,substitution={})for name in CONTROL_RULES]


def guarded_application():return dict(kind='engine',provider='q-identity',rule='current-fixed-Q-snapshot-operands',substitution={})


def specification():
    decl,defs,rules=original();rules=copy.deepcopy(rules)
    old_root=rules['preserved-0']['assumptions']
    theorem_facts=provider_facts()
    if old_root[-len(theorem_facts):]!=theorem_facts:raise ValueError('Changed original provider boundary')
    root=old_root[:-len(theorem_facts)]
    # Each implication is itself an engine-checked theorem in the same body
    # context. The fixed-input theorem is also a premise of q-identity's
    # guarded consequence, so it must be imported explicitly, not guessed.
    theorem_facts=theorem_facts+[fixed_input_fact()]
    available=root+theorem_facts
    facts,audit=apply(available,applications())
    guard='(qc-op a th tile)'
    values,conditional_audit=apply(available+[guard],[guarded_application()])
    conditional='(=> '+guard+' '+both(values)+')'
    # The temporary guard is discharged by implication introduction. Its
    # conclusions are never added as unguarded premises.
    origins=dict(root_assumptions=root,checked_provider_theorems=theorem_facts,applications=audit,guarded_application=dict(
        discharged_guard=guard,applications=conditional_audit,conclusion=conditional,
        rule='Propositional implication introduction; the extra guard is retained in the conclusion'))
    direct=['(qp-inv a pc th mh qi model lane tile)','(= mhn (math-next a th mh tile))']
    if not set(direct)<=set(root):raise ValueError('Unclosed direct induction hypotheses')
    laws=provider_facts()[1:]
    premises=direct+facts+[conditional]+laws
    for name in ['preserved-0','preserved-1']:rules[name]['assumptions']=premises
    # A readable statement of the native-root induction implication. Actual
    # rule applications and the pure engine premises are retained separately.
    root_theorem='(define-fun Q-prefix-native-step-theorem ('+' '.join('('+d.removeprefix('(declare-const ').removesuffix(')')+')'for d in decl)+') Bool (=> '+both(root)+' (qp-inv an pcn thn mhn qin model lane tile)))\n'
    defs+=root_theorem
    return decl,defs,rules,origins,premises


def body_files():return identity_body_files()+['q-prefix-control/history.smt2','q-prefix-r3/history.smt2']


def prepare():
    decl,defs,rules,audit,premises=specification();d=HERE/'q-prefix-r3';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',audit)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json',
        'q-columns-r3-PLAN.json','q-model-PLAN.json','q-identity-PLAN.json','q-prefix-laws-PLAN.json','q-prefix-control-PLAN.json','q-prefix-r3/APPLICATIONS.json',*bodies]
    plan=dict(schema='Typed-Q-fixed-prefix-closed-control-composition-v1',component='q-prefix-r3',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-prefix-r3-CHECKS.json',
        old_providers=['parentcapture','macmodel'],new_providers=['q-columns-r3','q-model','q-identity','q-prefix-laws','q-prefix-control'],
        applications=applications(),guarded_application=guarded_application(),root_step_assumptions=audit['root_assumptions'],engine_step_premises=premises,
        provider_facts=provider_facts(),external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-prefix-r3-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed closed control/integer composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Closed native control applications and guarded fixed-input theorem frozen before pure integer induction.')

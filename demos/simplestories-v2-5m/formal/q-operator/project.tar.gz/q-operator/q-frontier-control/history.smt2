; One-step endpoint control support; no future healthy-root premise.

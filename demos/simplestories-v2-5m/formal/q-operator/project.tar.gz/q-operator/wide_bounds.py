"""Full-type bounds used by explicit word/integer interpretation, not model data."""
import json
from arithmetic import HERE,MAC,sha,write_json,compile_model


def specification():
    declarations=['(declare-const x Int)','(declare-const y Int)']
    rules={
        'signed35-unsigned15-fits50':dict(assumptions=['(<= (- 17179869184) x)','(< x 17179869184)','(<= 0 y)','(< y 32768)'],
            conclusion='(and (< (- 562949953421312) (* x y)) (< (* x y) 562949953421312))'),
        'unsigned25-unsigned15-fits-positive48':dict(assumptions=['(<= 0 x)','(< x 33554432)','(<= 0 y)','(< y 32768)'],
            conclusion='(and (<= 0 (* x y)) (< (* x y) 140737488355328))'),
        'signed10-unsigned15-fits48':dict(assumptions=['(<= (- 512) x)','(< x 512)','(<= 0 y)','(< y 32768)'],
            conclusion='(and (< (- 140737488355328) (* x y)) (< (* x y) 140737488355328))'),
        'legal-Q-scaled-dot-fits48':dict(assumptions=['(<= (- 4286447872) x)','(<= x 4286447872)','(<= 1 y)','(<= y 32767)'],
            conclusion='(and (< (- 140737488355328) (* x y)) (< (* x y) 140737488355328))'),
    }
    return declarations,'',rules


def prepare():
    compile_model('mac',MAC,{'cluster-tile.sv':[MAC]})
    declarations,defs,rules=specification();d=HERE/'wide-bounds';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['mac/native.smt2','wide-bounds/history.smt2'];paths=['mac-SOURCES.json','mac/native.sv','mac/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-wide-type-bounds-v1',component='wide-bounds',bodies=bodies,source_manifest='mac-SOURCES.json',native_source='mac/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='wide-bounds-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'wide-bounds-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed wide bounds plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

"""Retain independent Q value meaning in each authoritative captured row.

The watched index is arbitrary and fixed. This proves pointwise vector meaning;
the actual accepted-vector and normalizer histories are independent of watch.
Existing all-lane universal component theorems supply its low-bit MAC instance.
"""
import json
from arithmetic import HERE,bv,both,sha,write_json
from q_columns import S
from q_model import MODEL
from q_normalizer_product import NS,nn
from q_capture_support import scope
from q_capture_array import specification as array_spec,body_files as array_files
from q_record_value import specification as value_spec,root as value_root
from fact_composition import apply


def guard(a='a',z='z',nc='nc'):
    return both([scope(a,z),f'(bvult watch (nc-count {nc}))'])


def definitions():
    args=f'((a {S}) (z {NS}) (qa QArguments) (nc NormCapture) (watch (_ BitVec 10)) (model {MODEL}))'
    return f'(define-fun qcert-inv {args} Bool (=> {guard()} (Q-record-matches qa model watch (select (nc-vec nc) watch))))\n'


def root():
    base=value_root()
    for endpoint in [scope(),nn('record_write_enable'),'(= '+nn('input_row_index_i')+' watch)']:
        if base.count(endpoint)!=1:raise ValueError('Changed record-value guard boundary')
        base.remove(endpoint)
    future=array_spec()[2]['next-watched-capture-is-retained-or-newly-written']['assumptions']
    futureguard=guard('an','zn','ncn')
    if future.count(futureguard)!=1:raise ValueError('Changed next captured-record authority guard')
    future=list(future);future.remove(futureguard)
    return list(dict.fromkeys(base+future+['(qcert-inv a z qa nc watch model)']))


def composition():
    futureguard=guard('an','zn','ncn')
    array_app=dict(kind='engine',provider='q-capture-array',rule='next-watched-capture-is-retained-or-newly-written',substitution={})
    facts,array_audit=apply(root()+[futureguard],[array_app])
    writeguard=both([nn('record_write_enable'),'(= '+nn('input_row_index_i')+' watch)'])
    value_app=dict(kind='closed',provider='watched-record-Q-value',rule='watched-source-record',substitution={})
    value,value_audit=apply(root()+[futureguard]+facts+[writeguard],[value_app])
    # Both temporary endpoint guards are discharged as implications. They do
    # not restrict the readable native-root induction theorem.
    premises=['(qcert-inv a z qa nc watch model)',
        '(=> '+futureguard+' '+both(facts)+')',
        '(=> '+both([futureguard,writeguard])+' '+both(value)+')']
    audit=dict(root_assumptions=root(),array_guard_discharged=futureguard,array_applications=array_audit,
        value_guard_discharged=both([futureguard,writeguard]),value_applications=value_audit,
        proof_rule='Implication introduction for temporary guards; modus ponens with exact checked source/closed-value providers')
    return premises,audit,[array_app,value_app]


def specification():
    decl=[]
    for d in value_spec()[0]+array_spec()[0]:
        if d not in decl:decl.append(d)
    names=[d.split()[1]for d in decl]
    if len(names)!=len(set(names)):raise ValueError('Conflicting vector-certificate declaration')
    premises,audit,applications=composition()
    rules={
        'empty-capture-reset-base':dict(assumptions=[],conclusion='(qcert-inv an zn qa-zero nc-zero watch model)'),
        'preserved':dict(assumptions=premises,conclusion='(qcert-inv an zn qan ncn watch model)'),
        'complete-vector-watched-value':dict(assumptions=['(qcert-inv a z qa nc watch model)',scope(),
            '(= (nc-count nc) '+bv(256,10)+')','(bvult watch '+bv(256,10)+')'],
            conclusion='(Q-record-matches qa model watch (select (nc-vec nc) watch))')}
    return decl,definitions(),rules,audit,applications


def body_files():return array_files()+['q-record-value/history.smt2','q-certificate/history.smt2']


PROVIDERS=['q-capture-array','q-record-value']


def prepare():
    decl,defs,rules,audit,applications=specification();d=HERE/'q-certificate';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',audit)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-certificate/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-captured-vector-value-certificate-v1',component='q-certificate',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-certificate-CHECKS.json',
        providers=PROVIDERS,root_assumptions=root(),applications=applications,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-certificate-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed captured vector numerical certificate')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Arbitrary watched captured-row value invariant and exact guarded closure prepared.')

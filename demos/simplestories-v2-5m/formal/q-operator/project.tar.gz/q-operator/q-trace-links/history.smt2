; No history or numerical result assumptions in the native reset aliases.

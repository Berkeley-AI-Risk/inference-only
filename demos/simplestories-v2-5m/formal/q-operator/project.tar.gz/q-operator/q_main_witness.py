"""A concrete stronger SAT context for the unchanged nonzero main endpoint.

Added equalities only restrict the original query. SAT therefore witnesses its
compatibility, without function forgetting or a reachability claim. The simple
synthetic model gives watched row0 dot256, multiplier1, source exponent0; the
constant raw vector256 normalizes at candidate -6 to mantissa16384.
"""
import json
from arithmetic import HERE,bv,eq,sha,write_json
from q_main import specification as main_spec,body_files as main_files
from q_model import MODEL,VECTOR
from norm_capture import ARRAY


def witness():
    vector=f'(store ((as const {VECTOR}) {bv(0,16)}) {bv(0,10)} {bv(1,16)})'
    pins=[eq('watch',bv(0,10)),eq('model',f'((as const {MODEL}) {bv(256,256)})'),
        eq('(qa-layer qa)',bv(0,3)),eq('(qa-exponent qa)',bv(15,8)),eq('(qa-vector qa)',vector),
        eq('(nc-vec nc)',f'((as const {ARRAY}) {bv(256,58)})')]
    for key,value,width in [('phase',5,3),('scan',0,10),('candidate',-6,8),('rows',256,10),('mantissa',16384,16),('emitted',0,10)]:
        pins.append(eq('(na-'+key+' na)',bv(value,width)))
    pins+=['(na-any na)','(na-fit na)']
    return pins


def specification():
    decl,defs,main=main_spec();original=main['nonzero-write-compatible-context']
    rule=dict(assumptions=original['assumptions']+witness(),conclusion='false',expected='sat')
    return decl,'; Exact original main compatibility assumptions plus concrete witness equalities only.\n',{'nonzero-write-concrete-compatible-context':rule}


def body_files():return main_files()+['q-main-witness/history.smt2']


PROVIDERS=['q-certificate','q-done-certificate','q-done-support','q-output-ownership-r3','norm-algorithm-r2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-main-witness';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-main-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-main-concrete-compatibility-witness-v1',component='q-main-witness',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-main-witness-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False,
        scope='Stronger synthetic-model compatibility context; no reachability or released-image operating claim')
    path=HERE/'q-main-witness-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed concrete compatibility witness')
    write_json(path,plan)

if __name__=='__main__':prepare();print('Concrete stronger nonzero SAT query frozen; original timeout retained.')

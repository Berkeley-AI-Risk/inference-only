"""One arbitrary watched capture has independent fixed-model Q meaning.

The reference predicate interprets the recorded signed50 raw word as an exact
integer dot-times-multiplier and its exponent as the fixed metadata expression.
No expected numerical reply is supplied by the environment or the observer.
"""
import json
from arithmetic import HERE,bv,both,eq,signed,sha,write_json
from q_columns import S,J,n
from q_model import MODEL
from q_capture_support import specification as capture_spec,body_files as capture_files,scope
from q_normalizer_product import nn
from q_frontier_value_r3 import specification as frontier_spec
from semantic_facts import substitute
from fact_composition import apply,flattened
from raw_contract import proposition


MAPPING={'a':'ap','an':'a','pc':'pcp','pcn':'pc','th':'thp','thn':'th','ch':'chp','chn':'ch',
    'mh':'mhp','mhn':'mh','fr':'frp','frn':'fr','qi':'qip','qin':'qi','qj':'qjp','qjn':'qj','mrn':'mr'}


def definitions():
    group='((_ zero_extend 4) ((_ extract 7 6) row))';local='((_ extract 5 0) row)'
    record=f'(Q-metadata model (qa-layer qa) {group} {local})'
    dot=f'(Q-prefix (qa-vector qa) model (qa-layer qa) {group} {local} {bv(256,10)})'
    exponent=f'(Q-record-exponent (qa-exponent qa) {record})'
    terms=[f'(bvult row {bv(256,10)})',eq(signed('((_ extract 49 0) captured)',50),'(* '+dot+' (bv2int ((_ extract 23 8) '+record+')))'),
        eq('((_ extract 57 50) captured)','((_ extract 7 0) '+exponent+')'),f'(bvsge {exponent} {bv(-128,11)})',f'(bvsle {exponent} {bv(127,11)})']
    return f'(define-fun Q-record-matches ((qa QArguments) (model {MODEL}) (row (_ BitVec 10)) (captured (_ BitVec 58))) Bool '+both(terms)+')\n'


def endpoint_premises():
    return [n(J+'result_valid_o'),eq(n(J+'job_q'),bv(0,4)),
        '(and (= ((_ extract 5 4) (fr-R3 fr)) tile) (= ((_ extract 3 0) (fr-R3 fr)) lane))']


def root():
    raw=[substitute(x,MAPPING)for x in proposition()['root_assumptions']]
    for endpoint in endpoint_premises():
        if raw.count(endpoint)!=1:raise ValueError('Changed raw provider endpoint boundary '+endpoint)
        raw.remove(endpoint)
    current=capture_spec()[2]['watched-source-frame-row']['assumptions']
    return list(dict.fromkeys(raw+current))


def accepted_binding():return both([eq('(qj-layer qj)','(qa-layer qa)'),eq('(qj-exponent qj)','(qa-exponent qa)')])


def app(label,rule,mapping=None,kind='engine'):return dict(kind=kind,provider=label,rule=rule,substitution=mapping or {})


def composition():
    available=root();facts=[];audit=[];applications=[]
    def add(application):
        nonlocal available
        new,record=apply(available,[application]);available+=new;facts.extend(new);audit.extend(record);applications.append(application)
    add(app('q-capture-support','Q-record-write-source-and-arguments'))
    add(app('q-capture-support','watched-source-frame-row'))
    facts.extend(flattened(accepted_binding()));available.extend(flattened(accepted_binding()))
    audit.append(dict(internal_provider='q-record-value:accepted-layer-exponent-binding',premises=capture_spec()[2]['Q-record-write-source-and-arguments']['assumptions'],conclusion=accepted_binding()))
    add(app('q-raw-scope','live-next-raw-has-previous-nonfailed-root',{'a':'ap','an':'a'}))
    add(app('q-frontier-vector','current-raw-identity-is-current-accepted-vector',MAPPING))
    add(app('raw-all-current','all-current-raw-Q-value',MAPPING,kind='closed'))
    # The observed index equality is part of this theorem's root. Keep it in
    # the smaller algebra query; the endpoint guards were discharged above.
    direct=[eq(nn('input_row_index_i'),'watch')]
    if not set(direct)<=set(root()):raise ValueError('Unclosed watched index equality')
    return direct+facts,audit,applications


def specification():
    declarations=[]
    for d in capture_spec()[0]+[substitute(d,MAPPING)for d in frontier_spec()[0]]:
        if d not in declarations:declarations.append(d)
    # The two components both declare a current frame; duplicate declarations
    # were removed above, while differently typed duplicates are forbidden.
    names=[d.split()[1]for d in declarations]
    if len(names)!=len(set(names)):raise ValueError('Conflicting capture/value declaration')
    premises,audit,applications=composition()
    current=capture_spec()[2]['Q-record-write-source-and-arguments']['assumptions']
    captured='(concat '+nn('input_source_exponent_i')+' '+nn('input_raw_i')+')'
    rules={'accepted-layer-exponent-binding':dict(assumptions=current,conclusion=accepted_binding()),
        'watched-raw-record-value':dict(assumptions=premises,conclusion=f'(Q-record-matches qa model watch {captured})',dependencies=['accepted-layer-exponent-binding'])}
    return declarations,definitions(),rules,audit,applications


def body_files():return capture_files()+['q-record-value/history.smt2']


PROVIDERS=['q-capture-support','q-frontier-vector','q-raw-scope','q-frontier-value-r3']


def prepare():
    decl,defs,rules,audit,applications=specification();d=HERE/'q-record-value';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'APPLICATIONS.json',dict(root_assumptions=root(),applications=audit))
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-record-value/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-watched-raw-record-closed-value-v1',component='q-record-value',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-record-value-CHECKS.json',
        providers=PROVIDERS,root_assumptions=root(),applications=applications,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-record-value-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed watched raw record meaning')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Watched accepted raw record value closed against actual source and all-current Q contract.')

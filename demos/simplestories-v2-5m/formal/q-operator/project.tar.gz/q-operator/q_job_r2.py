"""Prove zero output count while the accepted Q vector is still loading.

The R1 SAT induction model allowed a nonzero ghost count in LOAD. This new
invariant is proved from actual start/transfer events, not assumed as success.
"""
import json
from arithmetic import HERE,sha,write_json
from q_job import specification as original


def specification():return original(revision=2)


def prepare():
    decl,defs,rules=specification();d=HERE/'q-job-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2','q-job-r2/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-accepted-job-and-prefix-r2-v1',component='q-job-r2',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-job-r2-CHECKS.json',
        old_providers=['parentcapture'],new_providers=[],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-job-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed Q job/prefix strengthening')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Q output count in LOAD added as an independently preserved phase invariant.')

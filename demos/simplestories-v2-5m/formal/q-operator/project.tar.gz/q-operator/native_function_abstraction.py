"""Same-signature native function forgetting for a closed algebra join only.

Every original model extends the abstract query by interpreting each new UF
as its original function. This is additional freedom, not a desired-value
assumption. Datatypes, declarations, assertions and all provider consequences
are preserved byte-for-byte. Exact source/premise closure precedes this step.
"""
from prefix_arithmetic_abstraction import TOKEN,transform as prefix_transform
from pruned_arithmetic import parse,emit


def spans(text):
    depth=0;start=None
    for match in TOKEN.finditer(text):
        token=match.group(0)
        if token=='(':
            if depth==0:start=match.start()
            depth+=1
        elif token==')':
            depth-=1
            if depth<0:raise ValueError('Unbalanced top-level command')
            if depth==0:yield start,match.end()
        elif depth==0 and not token.startswith(';'):
            raise ValueError('Unexpected bare top-level token')
    if depth:raise ValueError('Incomplete top-level command')


def forget_native(text,extra_names=()):
    pieces=[];last=0;inventory=[];edits={}
    for ordinal,(start,end) in enumerate(spans(text)):
        original=text[start:end];head=parse(original)
        if len(head)!=1 or not isinstance(head[0],list)or not head[0]:raise ValueError('Ambiguous top-level form')
        node=head[0];changed=original
        if node[0] in ['define-funs-rec','define-const']:
            raise ValueError('Unsupported top-level definition form')
        if node[0]in ['define-fun','define-fun-rec']:
            if len(node)!=5 or not isinstance(node[1],str)or not isinstance(node[2],list):raise ValueError('Malformed function definition')
            if node[0]=='define-fun-rec':raise ValueError('Only the separately checked finite prefix may be recursive')
            if node[1].startswith('|core_workflow_control')or node[1]in extra_names:
                if any(not isinstance(a,list)or len(a)!=2 for a in node[2]):raise ValueError('Malformed function signature')
                changed=emit(['declare-fun',node[1],[a[1]for a in node[2]],node[3]])
                inventory.append(dict(name=node[1],arguments=[emit(a[1])for a in node[2]],result=emit(node[3])))
                edits[ordinal]=(changed,original)
        pieces.extend([text[last:start],changed]);last=end
    pieces.append(text[last:]);rewritten=''.join(pieces)
    restore=[];last=0
    for ordinal,(start,end) in enumerate(spans(rewritten)):
        command=rewritten[start:end]
        if ordinal in edits:
            changed,original=edits[ordinal]
            if command!=changed:raise ValueError('Changed function replacement/signature')
            command=original
        restore.extend([rewritten[last:start],command]);last=end
    restore.append(rewritten[last:])
    if ''.join(restore)!=text:raise ValueError('Changed bytes outside function definitions')
    if not inventory:raise ValueError('No native function definitions selected')
    if len({r['name']for r in inventory})!=len(inventory):raise ValueError('Repeated native definition')
    return rewritten,inventory


def transform(text):
    # This checked earlier transformation forgets the unique finite prefix and
    # uniformly abstracts integer multiplication. Retain its exact safeguards.
    prepared=prefix_transform(text)
    rewritten,inventory=forget_native(prepared)
    return rewritten


def transport_relation(text):
    from q_record_value import definitions
    original=definitions().strip()
    if text.splitlines().count(original)!=1:raise ValueError('Missing exact checked record-value predicate')
    prepared=prefix_transform(text)
    rewritten,inventory=forget_native(prepared,extra_names=('Q-record-matches',))
    if sum(row['name']=='Q-record-matches'for row in inventory)!=1:raise ValueError('Record predicate forgetting was not unique')
    return rewritten


def controls():
    fixture='; (define-fun |core_workflow_control_ignored| () Int 0)\n'+\
        '(declare-sort S 0)\n(define-fun |core_workflow_control_n x| ((a S)) (_ BitVec 8) #x01)\n'+\
        '(define-fun keep ((x Int)) Int (+ x 1))\n(assert (= "quoted ( text" "quoted ( text"))\n'
    changed,inventory=forget_native(fixture)
    expected=fixture.replace('(define-fun |core_workflow_control_n x| ((a S)) (_ BitVec 8) #x01)',
        '(declare-fun |core_workflow_control_n x| (S) (_ BitVec 8))')
    if changed!=expected or len(inventory)!=1:raise ValueError('Changed comment/string/helper/assertion/signature')
    for bad in ['(define-funs-rec ((f ((x Int)) Int)) (x))','(define-fun-rec f ((x Int)) Int x)',fixture+'\n)']:
        try:forget_native(bad)
        except ValueError:continue
        raise ValueError('Unsupported/malformed definition accepted')
    return dict(native_only=True,comments_strings_and_assertions_preserved=True,signature_preserved=True,
        exact_restoration=True,unsupported_definition_forms_rejected=True,ordinary_engine_typecheck_required=True)

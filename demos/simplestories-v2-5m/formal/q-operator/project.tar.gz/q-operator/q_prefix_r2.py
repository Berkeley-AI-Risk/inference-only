"""Fixed Q prefix induction with explicit next-snapshot empty-prefix law.

The original recursive-query attempts remain saved. This revision permits a
separate uniform pure-function abstraction, with exact checked ground laws.
"""
import json
from arithmetic import HERE,sha,write_json
from q_prefix import specification as original,provider_facts as original_facts
from q_identity import body_files as identity_body_files


def specification(next_base=True):return original(next_base=next_base)


def provider_facts(next_base=True):return original_facts(next_base=next_base)


def body_files():return identity_body_files()+['q-prefix-r2/history.smt2']


def prepare():
    decl,defs,rules=specification(next_base=True);d=HERE/'q-prefix-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-model-PLAN.json','q-identity-PLAN.json','q-prefix-laws-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-fixed-model-integer-prefix-r2-v1',component='q-prefix-r2',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-prefix-r2-CHECKS.json',
        old_providers=['parentcapture','macmodel'],new_providers=['q-columns-r3','q-model','q-identity','q-prefix-laws'],provider_facts=provider_facts(next_base=True),external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-prefix-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed fixed-model integer Q prefix')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual accepted accumulation vs pure fixed-model finite Q-prefix induction prepared.')

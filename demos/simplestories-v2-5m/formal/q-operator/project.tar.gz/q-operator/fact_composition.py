"""Literal modus-ponens closure for independently proved component facts.

The logical engine join sees the proved consequences, while the checker closes
their exact current-state premises against the readable root theorem. No
desired result is accepted from an unqualified input or a saved status flag.
"""
import json
from arithmetic import HERE,both
from semantic_facts import substitute
from pruned_arithmetic import parse,emit


def flattened(text):
    ast=parse(text)
    if len(ast)!=1:raise ValueError('Expected one proof formula')
    def walk(node):
        if isinstance(node,list)and node and node[0]=='and':
            for child in node[1:]:yield from walk(child)
        else:yield emit(node)
    return list(walk(ast[0]))


def apply(root,applications):
    available=set(x for formula in root for x in flattened(formula));facts=[];audit=[]
    for application in applications:
        mapping=application['substitution']
        if application['kind']=='engine':
            label=application['provider'];name=application['rule']
            plan=json.loads((HERE/(label+'-PLAN.json')).read_text());rule=plan['rules'][name]
            if rule.get('expected','unsat')!='unsat':raise ValueError('SAT example is not a provider')
        elif application['kind']=='semantic':
            from word_derivation import expected
            rule=expected(application['provider'])['target']
        elif application['kind']=='closed':
            if (application['provider'],application['rule'])==('raw-all-current','all-current-raw-Q-value'):
                from raw_contract import proposition
                contract=proposition();rule=dict(assumptions=contract['root_assumptions'],conclusion=contract['conclusion'])
            elif (application['provider'],application['rule'])==('watched-record-Q-value','watched-source-record'):
                from q_record_value import root,specification
                rule=dict(assumptions=root(),conclusion=specification()[2]['watched-raw-record-value']['conclusion'])
            else:raise ValueError('Unsupported closed component contract')
        else:raise ValueError('Unknown fact application rule')
        premises=[substitute(a,mapping)for a in rule['assumptions']]
        needed=set(x for formula in premises for x in flattened(formula))
        if not needed<=available:raise ValueError('Unclosed exact provider premises: '+str(sorted(needed-available)))
        conclusion=substitute(rule['conclusion'],mapping)
        new=flattened(conclusion);available.update(new);facts.extend(x for x in new if x not in facts)
        audit.append(dict(application=application,premises=premises,conclusion=conclusion,closed_by_root_or_earlier_application=True))
    return facts,audit


def verify_providers(applications):
    from q_check import check
    from word_derivation import verify
    grouped={}
    for application in applications:
        if application['kind']=='semantic':verify(application['provider'],False)
        elif application['kind']=='closed':
            if (application['provider'],application['rule'])==('raw-all-current','all-current-raw-Q-value'):
                from raw_contract import verify as verify_raw
                verify_raw()
            elif (application['provider'],application['rule'])==('watched-record-Q-value','watched-source-record'):check('q-record-value',True)
            else:raise ValueError('Unsupported closed provider')
        else:grouped.setdefault(application['provider'],set()).add(application['rule'])
    for label,names in grouped.items():check(label,True,sorted(names))

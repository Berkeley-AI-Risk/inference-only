"""Strengthened native prefix control with independently preserved phase facts.

R1 SAT induction countermodels remain saved. The additional invariants are
proved at reset and each step; they are not new input/success assumptions.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from prefix_control import TOP,n,specification as base_specification


def specification():
    active='(or '+' '.join(eq(n('state_q'),bv(i,3))for i in [1,2,3,4,5])+')'
    extra=[f'(=> (= {n("state_q")} {bv(1,3)}) (= {n("column_q")} {bv(0,10)}))',
        f'(=> {n("fail_q")} (= {n("state_q")} {bv(7,3)}))',
        f'(=> {active} (distinct {n("columns_q")} {bv(0,10)}))']
    return base_specification(extra)


def prepare():
    declarations,defs,rules=specification();d=HERE/'prefix-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2'];paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json',*bodies]
    plan=dict(schema='Typed-Q-engine-prefix-control-r2-v1',component='prefix-r2',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='prefix-r2-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'prefix-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed strengthened prefix plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Three reachable-state invariants added to the induction, with unchanged native model and no new environmental premises.')

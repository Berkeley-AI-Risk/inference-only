"""Compiled projection of the actual exponent register, with explicit cuts.

The original parent optimized this unused register away. Keep it in a separate
source-identical datapath, cut only its nine named current-signal dependencies,
extract its complete fanin, and bind those arbitrary signals to the old parent.
No handwritten state update or expected exponent replaces the production RTL.
"""
import json,re
from pathlib import Path
from arithmetic import HERE,OPERANDS,bv,both,eq,sha,write_json
from q_columns import S
from q_normalizer_product import dn

TOP='q_exponent_projection';ES='|'+TOP+'_s|'
en=lambda field,e='e':f'(|{TOP}_n {field}| {e})'
CUTS={'fault_q':1,'engine_state_q':4,'current_stage_q':5,'norm_result_fire':1,
    'norm_result_index':10,'output_index_q':10,'norm_result_last':1,'projection_result_count':10,'norm_result_exponent':8}
INPUTS=['clk','rst_n','clear_i',*CUTS]


def script():
    return '\n'.join(['read_verilog -formal -sv -nosynthesis -D SYNTHESIS native.sv',
        'hierarchy -top board1_context2048_semantic_datapath','select -module board1_context2048_semantic_datapath',
        'setattr -set keep 1 w:query_exponent_q','proc','cutpoint '+' '.join('w:'+x for x in CUTS),
        'select -set qcone w:query_exponent_q %ci*','select -write cone.txt @qcone',
        'submod -copy -name q_exponent_projection @qcone','select -clear','hierarchy -top q_exponent_projection',
        'async2sync','opt_clean','dffunmap','memory_collect','check -assert',
        'write_json native.json','write_smt2 -wires native.smt2'])+'\n'


def source_binding():
    from lanes import verify_sources
    verify_sources()
    from build_semantic_window import NATIVE
    real=(NATIVE/'production-datapath.sv').read_text();abstract=(OPERANDS/'connected/datapath.sv').read_text()
    start='    // Stage controller and private vector writes.';end='    // Private staging, not permission to use a query.'
    realblock=real[real.index(start):real.index(end)];abstractblock=abstract[abstract.index(start):abstract.index(end)]
    if realblock!=abstractblock:raise ValueError('Actual production controller changed in the abstract source')
    assignments=re.findall(r'query_exponent_q\s*<=\s*([^;]+);',realblock)
    if [re.sub(r'\s+','',x)for x in assignments]!=["8'sd0",'norm_result_exponent','norm_result_exponent']:raise ValueError('Changed complete exponent assignment inventory')
    native=(HERE/'q-exponent/native.sv').read_text()
    if native!=abstract or (HERE/'q-exponent/compile.ys').read_text()!=script():raise ValueError('Changed source/compiler projection')
    graph=json.loads((HERE/'q-exponent/native.json').read_text())
    if set(graph['modules'])!={TOP}:raise ValueError('Unrelated module in exponent projection')
    module=graph['modules'][TOP];cells=module['cells'];nets=module['netnames'];seq=[c for c in cells.values()if c['type']=='$dff']
    if len(seq)!=1 or int(seq[0]['parameters']['WIDTH'],2)!=8 or int(seq[0]['parameters']['CLK_POLARITY'],2)!=1 or seq[0]['connections']['CLK']!=nets['clk']['bits']:
        raise ValueError('Exponent projection must contain exactly one actual positive-edge 8-bit register')
    allowed={'$mux','$anyseq','$eq','$logic_or','$ne','$dff','$pmux','$sub'}
    if {c['type']for c in cells.values()}-allowed:raise ValueError('Unexpected cone cell')
    cuts=[]
    for name,width in CUTS.items():
        bits=nets[name]['bits'];drivers=[c for c in cells.values()if c['type']=='$anyseq'and c['connections']['Y']==bits]
        if len(bits)!=width or len(drivers)!=1:raise ValueError('Changed exact current-signal cut '+name)
        cuts.append(dict(signal=name,width=width,bits=bits))
    if sum(c['type']=='$anyseq'for c in cells.values())!=len(CUTS):raise ValueError('Unrecorded free input in exponent slice')
    root=(OPERANDS/'connected/native.smt2').read_text()
    for name in INPUTS:
        if dn(name).split(' a)')[0][1:]not in root:raise ValueError('Missing actual parent input getter '+name)
    if dn('query_exponent_q').split(' a)')[0][1:]in root:raise ValueError('Exponent now exists in the old parent; reassess the extension')
    return dict(schema='Compiled-actual-Q-exponent-cone-v1',production_source=str(NATIVE/'production-datapath.sv'),
        production_sha256=sha(real.encode()),production_controller_sha256=sha(realblock.encode()),
        unchanged_controller_in_abstract_parent=True,source_sha256=sha(native.encode()),
        assignment_inventory=assignments,cutpoints=cuts,arbitrary_cuts_bound_to_actual_parent=INPUTS,
        only_retained_sequential_state_bits=8,clock='Actual parent clk, positive edge',reset='Actual parent rst_n, asynchronous active low',
        clear_behavior='hold',Q_and_Q_ROPE_updates_retained=True,no_child_fault_gate_added=True,
        no_expected_value_assumption=True,native_smt_sha256=sha((HERE/'q-exponent/native.smt2').read_bytes()),
        native_graph_sha256=sha((HERE/'q-exponent/native.json').read_bytes()),
        rule='Unchanged production controller; standard arbitrary-signal cutpoint weakening; complete fanin extraction; actual-input specialization')


def definitions():
    projorder=both([eq(en('norm_result_index'),en('output_index_q')),
        eq(en('norm_result_last'),eq(en('output_index_q'),f'(bvsub {en("projection_result_count")} {bv(1,10)})'))])
    ropeorder=both([eq(en('norm_result_index'),en('output_index_q')),eq(en('norm_result_last'),eq(en('output_index_q'),bv(255,10)))])
    branches='(or '+both([eq(en('engine_state_q'),bv(2,4)),eq(en('current_stage_q'),bv(1,5)),projorder])+' '+\
        both([eq(en('engine_state_q'),bv(3,4)),eq(en('current_stage_q'),bv(4,5)),ropeorder])+')'
    update=both([en('rst_n'),f'(not {en("clear_i")})',f'(not {en("fault_q")})',en('norm_result_fire'),branches])
    defs=f'(define-fun qe-update ((e {ES})) Bool {update})\n'
    defs+=f'(define-fun qe-value ((e {ES})) (_ BitVec 8) {en("query_exponent_q")})\n'
    nextvalue=f'(ite {en("rst_n","een")} (ite {en("rst_n")} (ite (qe-update e) {en("norm_result_exponent")} (qe-value e)) {bv(0,8)}) {bv(0,8)})'
    defs+=f'(define-fun qe-observed-next ((e {ES}) (een {ES})) (_ BitVec 8) {nextvalue})\n'
    return defs


def parent_definitions():
    bind=both([eq(en(field),dn(field))for field in INPUTS])
    return f'(define-fun qe-bind ((a {S}) (e {ES})) Bool {bind})\n'+\
        f'(define-fun qe-native-step ((a {S}) (an {S}) (z |board1_fixed_vector_normalizer_s|) (zn |board1_fixed_vector_normalizer_s|) (e {ES}) (een {ES})) Bool '+\
        both(['(qn-native-step a an z zn)',f'(|{TOP}_t| e een)','(qe-bind a e)','(qe-bind an een)'])+')\n'


def verify_replay():
    p=HERE/'q-exponent';record=json.loads((p/'REPLAY.json').read_text());d=(p/record['replay_directory']).resolve()
    d.relative_to((p/'replays').resolve())
    if record['exit_code']!=0 or record['proof_result']or not record['translation_only']:raise ValueError('Invalid source translation replay')
    if json.loads((d/'RESULT.json').read_text())!=record:raise ValueError('Changed raw source replay record')
    expected={'native.sv','compile.ys','native.json','native.smt2'}
    if set(record['files_sha256'])!=expected or set(record['canonical_byte_identical'])!=expected:raise ValueError('Incomplete source replay inventory')
    for name in expected:
        if not record['canonical_byte_identical'][name]or (d/name).read_bytes()!=(p/name).read_bytes()or sha((d/name).read_bytes())!=record['files_sha256'][name]:
            raise ValueError('Source compilation replay differs: '+name)
    if sha((d/'yosys.log').read_bytes())!=record['log_sha256']:raise ValueError('Changed source compiler log')
    return record


def specification():
    decl=[f'(declare-const e {ES})',f'(declare-const een {ES})'];H=[f'(|{TOP}_h| e)',f'(|{TOP}_h| een)'];T=f'(|{TOP}_t| e een)'
    rules={
        'actual-compiled-next-observation':dict(assumptions=H+[T],conclusion=eq('(qe-value een)','(qe-observed-next e een)')),
        'asynchronous-reset-observation':dict(assumptions=H+[f'(not {en("rst_n")})'],conclusion=eq('(qe-value e)',bv(0,8))),
        'CLEAR-holds-unless-reset':dict(assumptions=H+[T,en('rst_n'),en('clear_i')],
            conclusion=eq('(qe-value een)',f'(ite {en("rst_n","een")} (qe-value e) {bv(0,8)})')),
        'source-update-or-next-reset':dict(assumptions=H+[T,'(qe-update e)'],
            conclusion=eq('(qe-value een)',f'(ite {en("rst_n","een")} {en("norm_result_exponent")} {bv(0,8)})'))}
    return decl,definitions(),rules


def prepare():
    decl,defs,rules=specification();d=HERE/'q-exponent';(d/'history.smt2').write_text(defs);(d/'parent-bind.smt2').write_text(parent_definitions())
    write_json(d/'SOURCE-BINDING.json',source_binding())
    bodies=['q-exponent/native.smt2','q-exponent/history.smt2'];paths=['../model-consumption/connected-SOURCES.json',
        '../model-consumption/connected/datapath.sv','q-exponent/native.sv','q-exponent/compile.ys','q-exponent/native.json','q-exponent/SOURCE-BINDING.json','q-exponent/REPLAY.json',*bodies]
    plan=dict(schema='Typed-Q-compiled-source-exponent-projection-v1',component='q-exponent',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='q-exponent/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-exponent-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-exponent-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed compiled exponent law')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual compiled one-register exponent cone and parent specialization prepared.')

"""Bounded parallel orchestration using shared canonical implication machinery.

Each answer is atomically saved before the next task. No token cap or old pilot
clock is used. This runner's exit status never means the whole Q theorem.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
from datetime import datetime,timezone
import fcntl
import json
import re
import subprocess
import sys
import threading
import time

from arithmetic import HERE,PILOT,sha
from q_check import check,shape
sys.path.insert(0,str(PILOT))
from native_induction import validate,query
from checkpoint import atomic_bytes,atomic_json


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('component',nargs='+');ap.add_argument('--rule',action='append')
    ap.add_argument('--wait',action='store_true',help='Queue behind the currently owned batch without starting another solver')
    choices=['z3','z3-uniform-mul','z3-uniform-arithmetic','z3-pruned-mul48','z3-pruned','z3-prefix-abstract','z3-prefix-abstract-mul','z3-prefix-abstract-words','z3-prefix-native-abstract','z3-certificate-transport','cvc5-int']
    ap.add_argument('--solver',choices=choices,default='z3')
    ap.add_argument('--solver-rule',action='append',default=[],help='Use component:rule=engine for a selected rule')
    args=ap.parse_args()
    overrides={}
    for item in args.solver_rule:
        name,engine=item.rsplit('=',1)
        if ':'not in name or engine not in choices:raise ValueError('Invalid solver override')
        overrides[name]=engine
    with (HERE/'RUN.lock').open('w')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX if args.wait else fcntl.LOCK_EX|fcntl.LOCK_NB)
        statepath=HERE/'STATE.json';state=json.loads(statepath.read_text())
        if state['active_owned_jobs']:raise ValueError('An owned batch is active')
        contexts={};items=[]
        for label in args.component:
            check(label)
            plan=validate(HERE,label+'-PLAN.json')
            body='\n'.join((HERE/x).read_text()for x in plan['bodies'])
            identity=sha((HERE/(label+'-PLAN.json')).read_bytes())
            checksfile=HERE/plan['checks_file'];checks=json.loads(checksfile.read_text())if checksfile.exists()else{}
            if checks.get('plan_sha256')!=identity:checks=dict(plan_sha256=identity,rules={})
            contexts[label]=(plan,body,identity,checksfile,checks)
            pending=False
            for name in args.rule or plan['order']:
                if name not in plan['rules']:raise ValueError('Unknown rule '+name)
                if not checks['rules'].get(name,{}).get('passed'):items.append((label,name));pending=True
            if pending:
                # Parse/typecheck every ORIGINAL rule together without asking
                # for SAT. This also validates bodies later erased by a sound
                # function abstraction. It is type evidence, never a proof.
                stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
                d=HERE/'typechecks'/(label+'-'+stamp);d.mkdir(parents=True)
                first=query(plan,plan['order'][0],body)
                if not first.endswith('(check-sat)\n'):raise ValueError('Unexpected canonical query terminator')
                typed=first[:-len('(check-sat)\n')]
                for name in plan['order']:
                    rule=plan['rules'][name]
                    typed+='\n'+'\n'.join('(assert '+term+')'for term in rule['assumptions']+[rule['conclusion']])+'\n'
                typed+='(exit)\n';atomic_bytes(d/'typecheck.smt2',typed.encode())
                command=['z3','-memory:'+str(state['memory_mib']),'-T:30',str(d/'typecheck.smt2')]
                begin=time.monotonic()
                with(d/'z3.log').open('w')as log:
                    proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                    state['active_owned_jobs']=[dict(pid=proc.pid,component=label+'-typecheck',rule='all-original-rules-no-check-sat',command=command)]
                    atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
                    try:code=proc.wait(timeout=35)
                    except subprocess.TimeoutExpired:proc.kill();proc.wait();code=-1
                seconds=time.monotonic()-begin;raw=(d/'z3.log').read_bytes()
                result=dict(component=label,typecheck_only=True,proof_result=False,no_check_sat=True,
                    exit_code=code,passed=code==0 and not raw.strip(),seconds=seconds,
                    query_sha256=sha(typed.encode()),log_sha256=sha(raw),plan_sha256=identity,command=command)
                atomic_json(d/'RESULT.json',result)
                state['active_owned_jobs']=[];state['typecheck_seconds']=state.get('typecheck_seconds',0)+seconds
                atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
                if not result['passed']:raise ValueError('Original canonical type check failed: '+str(d.relative_to(HERE)))
        ledger=threading.Lock()
        def run(item):
            label,name=item;plan,body,identity,checksfile,checks=contexts[label]
            solver=overrides.get(label+':'+name,args.solver)
            stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
            d=HERE/'queries'/(label+'-'+name+'-'+stamp);d.mkdir(parents=True)
            text=query(plan,name,body)
            from pruned_arithmetic import parse
            parse(text) # Reject malformed generation before starting any engine.
            atomic_bytes(d/'query.smt2',text.encode())
            engine_text=text;engine_file='query.smt2'
            if solver=='z3-uniform-mul':
                if label not in ['tile','tile-any','tile-cases','tile-held'] or name!='preserved-3':raise ValueError('Uniform arithmetic abstraction not approved for this rule type')
                from abstract_multiply import transform
                engine_text=transform(text);engine_file='query.uniform-mul.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-uniform-arithmetic':
                if label!='tile-any' or name!='preserved-4':raise ValueError('Uniform arithmetic abstraction not approved for this rule type')
                from abstract_multiply import transform_arithmetic
                engine_text=transform_arithmetic(text);engine_file='query.uniform-arithmetic.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-pruned-mul48':
                if label!='frame' or not name.startswith('preserved-'):raise ValueError('Pruned multiplication abstraction not approved for this rule type')
                from pruned_arithmetic import transform
                engine_text=transform(text);engine_file='query.pruned-mul48.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-prefix-abstract':
                if not ((label in ['q-prefix-r2','q-prefix-r3'] and name in ['preserved-0','preserved-1']) or (label in ['q-raw','q-raw-r2'] and name=='joined-raw-Q-value')):raise ValueError('Pure-prefix abstraction not approved for this rule type')
                from prefix_abstraction import transform
                engine_text=transform(text);engine_file='query.prefix-function.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-prefix-abstract-mul':
                if not ((label=='q-prefix-r3' and name in ['preserved-0','preserved-1']) or (label=='q-raw-r2' and name=='joined-raw-Q-value') or (label in ['q-frontier-value','q-frontier-value-r2','q-frontier-value-r3'] and name=='next-output-raw-Q-value')):raise ValueError('Uniform integer multiplication abstraction not approved here')
                from prefix_arithmetic_abstraction import transform
                engine_text=transform(text);engine_file='query.prefix-imul.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-prefix-abstract-words':
                if label!='q-prefix-r3' or name!='preserved-0':raise ValueError('Pure word interpretation abstraction not approved here')
                from prefix_word_abstraction import transform
                engine_text=transform(text);engine_file='query.prefix-words.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-prefix-native-abstract':
                if (label,name)not in [('q-frontier-value-r3','next-output-raw-Q-value'),('q-record-value','watched-raw-record-value')]:raise ValueError('Native function forgetting not approved here')
                from native_function_abstraction import transform
                engine_text=transform(text);engine_file='query.prefix-native.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-certificate-transport':
                if label not in ['q-certificate','q-done-certificate'] or name!='preserved':raise ValueError('Record relation forgetting not approved here')
                from native_function_abstraction import transport_relation
                engine_text=transport_relation(text);engine_file='query.record-relation.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='z3-pruned':
                if label!='engine-integer-r2':raise ValueError('Definitional pruning not approved for this rule type')
                from pruned_arithmetic import prune_only
                engine_text=prune_only(text);engine_file='query.pruned.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            elif solver=='cvc5-int':
                # Z3's bv2int spelling is unsigned on a BV argument. cvc5
                # accepts the standard unsigned conversion under ubv_to_int.
                engine_text=text.replace('(bv2int ','(ubv_to_int ')
                engine_file='query.cvc5.smt2';atomic_bytes(d/engine_file,engine_text.encode())
            engine_log='cvc5.log'if solver=='cvc5-int'else'z3.log'
            command=(['z3','-memory:'+str(state['memory_mib']),'-T:'+str(state['per_query_seconds']),str(d/engine_file)]
                if solver!='cvc5-int'else[sys.executable,'-B',str(HERE.parent/'model-consumption/bounded_engine.py'),
                    '--memory-mib',str(state['memory_mib']),'--wall-seconds',str(state['per_query_seconds']+2),'--',
                    'cvc5','--force-logic=ALL','--solve-bv-as-int=sum','--lang=smt2',
                    '--tlimit='+str(state['per_query_seconds']*1000),str(d/engine_file)])
            started=time.monotonic()
            with (d/engine_log).open('w')as log:
                with ledger:
                    proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                    state['active_owned_jobs'].append(dict(pid=proc.pid,component=label,rule=name,command=command))
                    state['status']='local_arithmetic_batch_running';atomic_json(statepath,state)
                    atomic_json(HERE/'SETUP-STATE.json',state)
                try:code=proc.wait(timeout=state['per_query_seconds']+5)
                except subprocess.TimeoutExpired:proc.kill();proc.wait();code=-1
            seconds=time.monotonic()-started;raw=(d/engine_log).read_bytes()
            expected=plan['rules'][name].get('expected','unsat')
            answers=re.findall(r'^(sat|unsat|unknown|timeout)$',raw.decode(),re.M)
            result=dict(component=label,rule=name,expected=expected,answers=answers,exit_code=code,
                passed=code==0 and raw.strip()==expected.encode(),seconds=seconds,
                query_sha256=sha(text.encode()),log_sha256=sha(raw),command=command,
                solver=solver,engine_log=engine_log,engine_query_file=engine_file,engine_query_sha256=sha(engine_text.encode()),
                plan_sha256=identity,receipt=str((d/'RESULT.json').relative_to(HERE)))
            atomic_json(d/'RESULT.json',result)
            with ledger:
                state['active_owned_jobs']=[x for x in state['active_owned_jobs']if x['pid']!=proc.pid]
                state['solver_seconds']+=seconds
                state['status']='local_arithmetic_batch_running'if state['active_owned_jobs']else'local_arithmetic_batch_finished'
                atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
                checks['rules'][name]=result
                checks['all_rules_passed']=all(checks['rules'].get(x,{}).get('passed')for x in plan['order'])
                checks['whole_Q_operator_proved']=False;atomic_json(checksfile,checks)
            print(json.dumps(dict(component=label,rule=name,passed=result['passed'],answers=answers,seconds=seconds)),flush=True)
            return result['passed']
        results=[];remaining=list(items);running={}
        with ThreadPoolExecutor(max_workers=min(state['max_concurrent'],max(1,len(items))))as pool:
            while remaining or running:
                with ledger:
                    ready=[item for item in remaining if all(contexts[item[0]][4]['rules'].get(dep,{}).get('passed')
                        for dep in contexts[item[0]][0]['rules'][item[1]].get('dependencies',[]))]
                for item in ready[:state['max_concurrent']-len(running)]:
                    remaining.remove(item);running[pool.submit(run,item)]=item
                if not running:break
                done,_=wait(running,return_when=FIRST_COMPLETED)
                for task in done:results.append(task.result());del running[task]
            if remaining:
                print(json.dumps(dict(blocked_by_unproved_dependencies=remaining)),flush=True);results.append(False)
        for label in args.component:check(label)
        if not all(results):sys.exit(1)


if __name__=='__main__':main()

"""Add independently proved MAC-pipeline phase ownership to the parent join.

The R1 SAT model had a spurious live MAC in engine/job IDLE and a stale 682
column descriptor. R2 proves the pipeline phase fact; no success premise is
added and no old qualified packet is changed.
"""
import json
from arithmetic import HERE,sha,write_json
from q_columns import specification as original


def specification():return original(revision=2)


def prepare():
    decl,defs,rules=specification();d=HERE/'q-columns-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2','q-engine/history.smt2','q-columns-r2/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','q-engine/INSTANCE-BINDING.json',*bodies]
    plan=dict(schema='Typed-Q-parent-column-binding-r2-v1',component='q-columns-r2',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-columns-r2-CHECKS.json',
        old_providers=['parentcapture'],engine_specialization='q-engine/INSTANCE-BINDING.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-columns-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed strengthened parent column binding')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Parent column binding strengthened with proved native MAC phase ownership.')

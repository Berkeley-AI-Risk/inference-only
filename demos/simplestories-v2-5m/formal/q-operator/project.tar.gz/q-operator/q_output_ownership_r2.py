"""Restore the actual compiled exponent state in the unchanged parent product.

R1 referenced a getter removed by old optimization; every attempt is rejected.
R2 uses the source-identical, compiled one-register projection with all nine
arbitrary cuts bound to actual parent getters. Reset wins observable updates.
"""
import json
from arithmetic import HERE,sha,write_json
from q_columns import TOP
from q_exponent import ES,TOP as ETOP,parent_definitions,source_binding as exponent_binding
from q_output_ownership import specification as original,body_files as original_files,source_binding as output_binding,PROVIDERS as old_providers
from pruned_arithmetic import parse,emit


PROVIDERS=old_providers+['q-exponent']
QE_SYMBOL='|'+TOP+'_n u_native.u_six_layers.u_datapath.query_exponent_q|'


def qh_name(name):return isinstance(name,str)and(name in ['qh-inv','qh-next']or name.startswith('qh-clause-'))


def extend_node(node):
    if not isinstance(node,list):return node
    if node and node[0]==QE_SYMBOL:
        if len(node)!=2 or node[1]not in ['a','an']:raise ValueError('Unexpected exponent-state argument')
        return ['qe-value','e'if node[1]=='a'else'een']
    value=[extend_node(x)for x in node]
    if value and value[0]=='define-fun'and qh_name(value[1]):
        value[2].insert(len(value[2])-1,['e',ES])
    elif value and qh_name(value[0]):
        if value[1]not in ['a','an']:raise ValueError('Unexpected Q-output root-state argument')
        value.insert(len(value)-1,'e'if value[1]=='a'else'een')
    return value


def extend(text):return '\n'.join(emit(extend_node(node))for node in parse(text))


def specification(revision=2):
    decl,defs,rules=original(revision=revision)
    decl += [f'(declare-const e {ES})',f'(declare-const een {ES})']
    defs=extend(defs)+'\n'
    for rule in rules.values():
        rule['assumptions']=[extend(x)for x in rule['assumptions']]
        rule['assumptions']=[x.replace('(qn-native-step a an z zn)','(qe-native-step a an z zn e een)')for x in rule['assumptions']]
        if any('(qe-native-step 'in x for x in rule['assumptions']):
            rule['assumptions'] += [f'(|{ETOP}_h| e)',f'(|{ETOP}_h| een)']
        elif any('(qn-bind a z)'in x for x in rule['assumptions']):
            rule['assumptions'] += ['(qe-bind a e)',f'(|{ETOP}_h| e)']
        rule['conclusion']=extend(rule['conclusion'])
    return decl,defs,rules


def body_files():
    return original_files()[:-1]+['q-exponent/native.smt2','q-exponent/history.smt2','q-exponent/parent-bind.smt2','q-output-ownership-r2/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-output-ownership-r2';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs);write_json(d/'SOURCE-BINDING.json',dict(output=output_binding(),exponent=exponent_binding()))
    if (HERE/'q-exponent/parent-bind.smt2').read_text()!=parent_definitions():raise ValueError('Changed actual exponent-input specialization')
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json','q-output-ownership-r2/SOURCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-parent-write-exponent-DONE-ownership-r2-v1',component='q-output-ownership-r2',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-output-ownership-r2-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-output-ownership-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed restored Q exponent/output source product')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Compiled source exponent state and reset-aware Q output ownership prepared.')

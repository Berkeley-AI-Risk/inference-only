"""Reconstruct a common-trace induction, refusing every unclosed premise.

This checker is deliberately separate from an inventory of passing solvers.
It schedules exact component implications on one actual Root/Norm/QE trace,
with typed functional histories and one rigid lane/watch family. Unclosed
formulas are diagnostics, never additional environmental assumptions.
"""
import argparse,json,re
from functools import lru_cache
from arithmetic import HERE,OPERANDS,both,sha,write_json
from pruned_arithmetic import parse,emit
from semantic_facts import substitute
from fact_composition import flattened
from trace_source_lifts import transform
from q_columns import TOP,S
from selector import TOP as NORM,S as NS
from q_exponent import TOP as ETOP,ES

# This ordered joint invariant is part of the checked rule, not a saved input.
SCHEDULE=[
 ('prefix-r2','engine','reset-base','parts-join'),
 ('tile-held','tile','reset-base','parts-join'),
 ('frame','engine','reset-base','parts-join'),
 ('lineage','engine','reset-base','parts-join'),
 ('sum-frame','engine','reset-base','parts-join'),
 ('math-fold-r2','engine','reset-base','parts-join'),
 ('meta-safety-r2','engine','reset-base','parts-join'),
 ('q-columns-r3','root','reset-base','parts-join'),
 ('q-identity','root','reset-base','parts-join'),
 ('q-prefix-r3','root','reset-base','parts-join'),
 ('q-metadata','root','reset-base','parts-join'),
 ('q-job-r2','root','reset-base','parts-join'),
 ('norm-capture-r2','normalizer','reset-base','parts-join'),
 ('shift','helper','reset-base','parts-join'),
 ('norm-shift','normalizer','reset-base','parts-join'),
 ('norm-algorithm-r2','normalizer','reset-base','parts-join'),
 ('q-lifecycle-r2','root','reset-base','parts-join'),
 ('q-arguments-r3','root','reset-base','parts-join'),
 ('q-capture-support','root','descriptor-reset-base','descriptor-preserved'),
 ('q-output-ownership-r3','root','reset-base','parts-join'),
 ('q-done-support','root','source-empty-reset-base','source-preserved'),
 ('q-certificate','root','empty-capture-reset-base','preserved'),
 ('q-done-certificate','root','empty-completion-reset-base','preserved'),
 ('normalizer-faults','normalizer','fault-state-reset-base','fault-state-preserved'),
]
HISTORY_NAMES={'PrefixHistory':'pc','TileHistory':'th','FrameHistory':'fr','MathHistory':'mh',
 'MetaRead':'mr','CaptureHistory':'ch','QIdentity':'qi','QJobHistory':'qj',
 'NormCapture':'nc','ShiftHistory':'sh','NormAlgorithm':'na','QLifecycle':'life',
 'QArguments':'qa','QOutput':'out','ApiHistory':'api','WordsHistory':'w'}
ZERO={'pc':'prefix-zero','th':'tile-zero','fr':'frame-zero','mh':'math-zero','mr':'mr-zero',
 'ch':'(capture-zero an)','qi':'qi-zero','qj':'qj-zero','nc':'nc-zero','sh':'shift-zero',
 'na':'na-zero','life':'ql-zero','qa':'qa-zero','out':'qh-zero','api':'api-zero','w':'words-zero'}
UPDATERS={'pc':'(prefix-next a pc)','th':'(tile-next a th lane tile)','fr':'(frame-next a fr)',
 'mh':'(math-next a th mh tile)','mr':'(mr-next a mr)','ch':'(capture-next a ch)',
 'qi':'(qi-next a ch qi)','qj':'(qj-next a qj)','nc':'(nc-next z nc)','sh':'(shift-next z sh)',
 'na':'(na-next z nc na)','life':'(ql-next a z life)','qa':'(qa-next a z life ch qa)',
 'out':'(qh-next a z life e out)','api':'(api-next a api)','w':'(words-next a w)'}
OLD=['api','reader','words','header','parentcapture','macmodel','tilemeta']
CLOSED={'q-prefix-r3','q-certificate','q-done-certificate'}


def literal_substitute(text,mapping):
    # The selected proof interface is quantifier/binder free. Refuse future
    # extensions instead of pretending token replacement is alpha-renaming.
    def check(node):
        if isinstance(node,list):
            if node and isinstance(node[0],str)and node[0]in ['forall','exists','let','lambda']:
                raise ValueError('Binder requires explicit capture-avoiding substitution')
            for x in node:check(x)
    check(parse(text))
    return substitute(text,mapping)

@lru_cache(maxsize=None)
def plan(label,old=False):return json.loads(((OPERANDS if old else HERE)/(label+'-PLAN.json')).read_text())


def mapping(label,profile,old=False):
    result={}
    for decl in plan(label,old)['declarations']:
        _,name,sort=parse(decl)[0];sort=emit(sort)
        if sort in HISTORY_NAMES:
            stem=HISTORY_NAMES[sort]
            # All declarations use n for post and p for the retained predecessor.
            suffix='n'if name.endswith('n')else'p'if name.endswith('p')else''
            result[name]=stem+suffix
        elif sort in [S,NS,ES]or sort.endswith('_s|'):
            if profile in ['normalizer','helper']and name in ['a','an']:result[name]='z'+('n'if name=='an'else'')
            else:result[name]=name
        elif name in ['model','tile','lane','watch']:result[name]=name
        else:raise ValueError('Unregistered trace parameter '+label+':'+decl)
    return result


def inst(text,label,profile,old=False,extra=None):
    m=mapping(label,profile,old);m.update(extra or {})
    return literal_substitute(transform(text,profile),m)


def rule(label,name,profile='root',old=False,closed=False):
    r=plan(label,old)['rules'][name]
    if r.get('expected','unsat')!='unsat':raise ValueError('SAT is not an implication provider')
    assumptions=r['assumptions']
    if profile in ['engine','tile','helper']:
        from trace_source_lifts import ENGINE_LOCAL,TILE_LOCAL,SHIFT_LOCAL
        local={'engine':ENGINE_LOCAL,'tile':TILE_LOCAL,'helper':SHIFT_LOCAL}[profile]
        native={'|'+local+'_'+x+'|'for x in ['h','t','i']}|{'prefix-native-step','tile-native-step'}
        def occurrences(node):
            if not isinstance(node,list):return set()
            result={node[0]}&native if node and isinstance(node[0],str)else set()
            for x in node:result|=occurrences(x)
            return result
        if occurrences(parse(r['conclusion'])):raise ValueError('Source lift cannot strengthen native conclusions')
        for formula in assumptions:
            for term in flattened(formula):
                ast=parse(term)[0]
                if occurrences([ast]) and (not isinstance(ast,list)or ast[0]not in native):
                    raise ValueError('Source lift requires positive native antecedent')
    if closed:
        if label=='q-prefix-r3':
            from q_prefix_r3 import specification
            d,f,rs,audit,premises=specification()
            if rs!=plan(label)['rules']:raise ValueError('Changed closed prefix engine rule')
            assumptions=audit['root_assumptions']
        elif label=='q-certificate':
            from q_certificate import specification
            d,f,rs,audit,apps=specification()
            if rs!=plan(label)['rules']:raise ValueError('Changed closed certificate engine rule')
            assumptions=audit['root_assumptions']
        elif label=='q-done-certificate':
            from q_done_certificate import specification
            d,f,rs,audit,apps=specification()
            if rs!=plan(label)['rules']:raise ValueError('Changed closed DONE engine rule')
            assumptions=audit['root_assumptions']
        else:raise ValueError('Unsupported closed step')
    return dict(assumptions=[inst(x,label,profile,old)for x in assumptions],conclusion=inst(r['conclusion'],label,profile,old))


def invariant(label,profile,join,old=False):
    r=rule(label,join,profile,old)
    return substitute(r['conclusion'],{'an':'a','zn':'z','een':'e',**{h+'n':h for h in HISTORY_NAMES.values()}})


def old_interface():
    results=[]
    for label in OLD:
        p=plan(label,True);name='parts-join'if'parts-join'in p['rules']else'preserved'
        results.append(invariant(label,'root',name,True))
    return results


def product():
    facts=[]
    for a,z,e in [('a','z','e'),('an','zn','een')]:
        facts.extend([f'(|{TOP}_h| {a})',f'(|{NORM}_h| {z})',f'(|{ETOP}_h| {e})',f'(qn-bind {a} {z})',f'(qe-bind {a} {e})'])
    facts.extend([f'(|{TOP}_t| a an)',f'(|{NORM}_t| z zn)',f'(|{ETOP}_t| e een)'])
    return facts


def exact_definitions():
    """Only named product shorthands may fold/unfold; no invariant unfolding."""
    from q_normalizer_product import definitions as qn
    from q_exponent import parent_definitions as qe
    from q_output_ownership_r3 import control_definition as qo
    names={'qn-native-step','qe-native-step','qe-control-step'}
    defs={x[1]:x for x in parse(qn()+'\n'+qe()+'\n'+qo())if isinstance(x,list)and x[0]=='define-fun'and x[1]in names}
    return defs


class Ledger:
    def __init__(self,root):
        self.available=set();self.audit=[];self.missing=[]
        self.add(root)
    def add(self,formulas):
        for f in formulas:self.available.update(flattened(f))
    def folds(self):
        defs=exact_definitions()
        args={'qn-native-step':['a','an','z','zn'],'qe-native-step':['a','an','z','zn','e','een'],
              'qe-control-step':['a','an','z','zn','e','een']}
        changed=True
        while changed:
            changed=False
            for name,d in defs.items():
                values=args[name]
                if len(d[2])!=len(values):raise ValueError('Product shorthand arity changed '+name)
                body=substitute(emit(d[4]),dict(zip([x[0]for x in d[2]],values)))
                f='('+name+' '+' '.join(values)+')'
                if set(flattened(body))<=self.available and f not in self.available:self.add([f]);changed=True
    def fold_instance(self,name,values):
        d=exact_definitions()[name]
        if len(d[2])!=len(values):raise ValueError('Product shorthand arity mismatch')
        body=literal_substitute(emit(d[4]),dict(zip([x[0]for x in d[2]],values)))
        if not set(flattened(body))<=self.available:raise ValueError('Unclosed product shorthand '+name)
        self.add(['('+name+' '+' '.join(values)+')'])
    def operand_weakening(self,a,an):
        native=f'(|{TOP}_t| {a} {an})'
        if native not in self.available:raise ValueError('Operand weakening requires full native transition')
        # The immutable operand_step.verify() checks the literal conjunction
        # weakening. verify() below repeats it before accepting this rule.
        self.add([f'(operand-native-step {a} {an})'])
    def apply(self,label,name,profile,closed=False,extra=None):
        r=rule(label,name,profile,closed=closed)
        if extra:r={k:([substitute(x,extra)for x in v]if k=='assumptions'else substitute(v,extra))for k,v in r.items()}
        needed={f for a in r['assumptions']for f in flattened(a)}
        absent=needed-self.available
        if absent:
            self.missing.append(dict(provider=label,rule=name,missing=sorted(absent)))
            # Diagnostic-only scheduling: report all holes in one pass. The
            # aggregate result MUST reject unless this list is empty.
        self.add([r['conclusion']]);self.audit.append(dict(provider=label,rule=name,source_profile=profile,
            closed_composition=closed,missing_count=len(absent),conclusion=r['conclusion']))
    def parts(self,label,profile,join):
        if join=='parts-join':
            for name in plan(label)['rules']:
                if re.fullmatch(r'preserved-\d+',name):self.apply(label,name,profile,closed=label=='q-prefix-r3')
        self.apply(label,join,profile,closed=label in CLOSED and join!='parts-join')


def invariant_family():return [invariant(l,p,j)for l,p,b,j in SCHEDULE]


def updates():return ['(= '+h+'n '+rhs+')'for h,rhs in UPDATERS.items()]


def bases():
    root=product()+[f'(|{TOP}_i| a)',f'(not (|{TOP}_n reset_n| a))']
    ledger=Ledger(root);ledger.folds()
    ledger.apply('q-output-ownership-r3','full-native-product-implies-control-step','root');ledger.folds()
    ledger.apply('q-trace-links','common-reset-reaches-all-Q-component-instances','root')
    # Qualified old common-reset theorem supplies these exact zero histories.
    for label in OLD:
        r=rule(label,'reset-base','root',old=True)
        ledger.add([r['conclusion']])
    for l,p,b,j in SCHEDULE:ledger.apply(l,b,p)
    expected=[substitute(f,{'a':'an','z':'zn','e':'een',**ZERO})for f in invariant_family()]
    absent=set(expected)-ledger.available
    return dict(root_formulas=root,applications=ledger.audit,unresolved=ledger.missing,unmatched_base_targets=sorted(absent))


def theorem_imports():
    from q_prefix_r2 import provider_facts
    from q_identity import provider_fact
    facts=provider_facts()+[provider_fact()]
    r=rule('norm-shift','actual-response-current-vector','normalizer')
    facts.append('(=> '+both(r['assumptions'])+' '+r['conclusion']+')')
    from semantic_facts import fact
    from word_derivation import expected
    product=expected('word16x10-function')['target']
    if product['assumptions']:raise ValueError('Product semantic fact has unclosed premises')
    facts.append(substitute(product['conclusion'],{'A':'(th-A th)','W':'(th-W th)'}))
    facts.append(fact('word48-add26-function',{'x':'(th-sum th)','y':'(th-P th)','first':'(th-pf th)'}))
    return facts


def endpoints():
    from q_normalizer_product import nn,dn
    from arithmetic import bv
    current=invariant_family()+old_interface()
    post=[substitute(x,{'a':'an','z':'zn','e':'een',**{h:h+'n'for h in HISTORY_NAMES.values()}})for x in current]
    common=product()+current+post+updates()+[f'(bvult watch {bv(256,10)})']
    guards={
        'held-normalized-Q-value':['(qn-Q-mode a)',nn('result_valid_o')],
        'transferred-normalized-Q-value':['(qn-Q-mode a)',nn('result_valid_o'),nn('result_ready_i')],
        'actual-Q-write-value-address-and-order':['(Q-write-admission a z)'],
        'actual-Q-exponent-register-value-or-reset':['(Q-exponent-update a z)'],
        'Q-stage-DONE-full-current-reference-and-writes':[dn('rst_n'),dn('stage_done_q'),f'(= {dn("current_stage_q")} {bv(1,5)})'],
        'CLEAR-revokes-current-operator-authority':[dn('clear_i')]}
    result={}
    for name,guard in guards.items():
        ledger=Ledger(common+guard);ledger.folds();ledger.operand_weakening('a','an');ledger.folds()
        ledger.apply('q-main',name,'root')
        result[name]=dict(observation_guard=guard,applications=ledger.audit,unresolved=ledger.missing)
    first=[f'(not {nn("range_fault_o")})',nn('range_fault_o','zn')]
    for name in ['first-fault-is-named-interruption-or-independent-rejection',
            'clean-first-fault-enters-independent-numeric-rejection','clean-numeric-rejection-preserves-emitted-prefix']:
        guard=first+([]if name.startswith('first-fault-is')else['(not (na-source-external-interrupt z))'])
        ledger=Ledger(common+guard);ledger.apply('normalizer-faults',name,'normalizer')
        result[name]=dict(observation_guard=guard,applications=ledger.audit,unresolved=ledger.missing)
    return result


def raw_endpoints(regular):
    from raw_contract import proposition
    from q_columns import J,n
    from arithmetic import bv
    root=regular['root_formulas']+[a['conclusion']for a in regular['step_applications']]
    value_guard=[n(J+'result_valid_o','an'),f'(= {n(J+"job_q","an")} {bv(0,4)})',
        '(= ((_ extract 5 4) (fr-R3 frn)) tile)','(= ((_ extract 3 0) (fr-R3 frn)) lane)']
    contract=proposition();result={}
    for transferred in [False,True]:
        guard=value_guard+([n(J+'result_ready_i','an')]if transferred else[])
        ledger=Ledger(root+guard);ledger.operand_weakening('a','an')
        needed={f for a in contract['root_assumptions']for f in flattened(a)}
        missing=sorted(needed-ledger.available)
        ledger.add([contract['conclusion']])
        ledger.apply('q-endpoint-links','result_valid_o-requires-actual-job-reset','root',extra={'a':'an'})
        post={'a':'an','ch':'chn','qj':'qjn'}
        ledger.apply('q-job-r2','live-Q-output-prefix','root',extra=post)
        result['transferred-raw-Q-value-and-order'if transferred else'held-raw-Q-value-and-order']=dict(
            observation_guard=guard,contract='raw-all-current',closed_contract=contract['conclusion'],
            unresolved=ledger.missing+([dict(provider='raw-all-current',rule='all-current-raw-Q-value',missing=missing)]if missing else[]),
            applications=ledger.audit)
    done_guard=[n(J+'done_valid_o'),f'(= {n(J+"job_q")} {bv(0,4)})']
    ledger=Ledger(root+done_guard)
    ledger.apply('q-endpoint-links','done_valid_o-requires-actual-job-reset','root')
    ledger.apply('q-job-r2','Q-DONE-full-prefix','root')
    result['raw-Q-DONE-full-ordered-prefix']=dict(observation_guard=done_guard,applications=ledger.audit,unresolved=ledger.missing)
    base=Ledger(regular['reset_base']['root_formulas']);base.operand_weakening('a','an')
    base.apply('q-raw-scope','raw-reset-base','root')
    result['first-post-reset-has-no-raw-VALID']=dict(observation_guard=[],applications=base.audit,unresolved=base.missing)
    return result


def structural(first_step=False,defect=None):
    """Fail closed: this diagnostic is not engine verification/qualification."""
    current=invariant_family();old=old_interface()
    root=product()+current+old+updates()+theorem_imports()
    root+=['(= tile ((_ extract 5 4) watch))','(= lane ((_ extract 3 0) watch))']
    root +=[substitute(x,{'a':'an','api':'apin','w':'wn','ch':'chn'})for x in old]
    # Predecessor facts and exact previous edge are necessary for the numeric
    # capture certificate. They are supplied by the induction hypothesis and
    # the saved recurrence, beginning at t>=2 after the explicit bootstrap.
    lag={'a':'ap','z':'zp','e':'ep',**{h:h+'p'for h in HISTORY_NAMES.values()}}
    if not first_step and defect!='missing-predecessor-invariants':root +=[substitute(x,lag)for x in current+old]
    previous={'an':'a','zn':'z','een':'e',**{h+'n':h for h in HISTORY_NAMES.values()},**lag}
    root +=[substitute(x,previous)for x in product()+([]if first_step else updates())]
    if first_step:root +=[f'(not (|{TOP}_n reset_n| ap))',f'(|{TOP}_i| ap)']
    current_zero={**ZERO,'ch':'(capture-zero a)'}if first_step else{}
    if first_step:root=[substitute(x,current_zero)for x in root]
    if defect=='wrong-normalizer-updater':root=[x.replace('(= ncn (nc-next z nc))','(= ncn (nc-next zn nc))')for x in root]
    if defect=='unfixed-lane':root.remove('(= lane ((_ extract 3 0) watch))')
    ledger=Ledger(root);ledger.folds()
    # Full native source supplies the separately proved control weakenings.
    for label,name,profile in [('norm-capture-r2','native-step-weakening','normalizer'),
            ('q-output-ownership-r3','full-native-product-implies-control-step','root')]:
        ledger.apply(label,name,profile,extra=current_zero);ledger.folds()
    # The old immutable packet verifies full native T => operand-native-step.
    # Export it only through its literal source-conjunct weakening, checked
    # again in verify(), never as a numerical assumption.
    ledger.operand_weakening('a','an');ledger.operand_weakening('ap','a')
    for l,p,b,j in SCHEDULE:
        if defect=='missing-post-lineage-provider'and l=='lineage':continue
        if first_step and l=='q-certificate':
            # Full first reset edge, then ncn=nc-next(z,nc-zero), supplies
            # the second-state empty count without any a0 numeric invariant.
            ledger.fold_instance('qn-native-step',['ap','a','zp','z'])
            ledger.apply('q-trace-bootstrap','second-post-reset-logical-capture-is-empty','root',extra={'a':'ap','an':'a','z':'zp','zn':'z'})
            ledger.apply('q-trace-links','empty-count-implies-active-capture-certificate','root',extra={'a':'an','z':'zn','qa':'qan','nc':'ncn'})
        elif first_step:
            if j=='parts-join':
                for name in plan(l)['rules']:
                    if re.fullmatch(r'preserved-\d+',name):ledger.apply(l,name,p,closed=l=='q-prefix-r3',extra=current_zero)
            ledger.apply(l,j,p,closed=l in CLOSED and j!='parts-join',extra=current_zero)
        else:ledger.parts(l,p,j)
    post=[substitute(x,{'a':'an','z':'zn','e':'een',**{h:h+'n'for h in HISTORY_NAMES.values()}})for x in current]
    absent=set(post)-ledger.available
    if absent:raise ValueError('Scheduled postcondition not exported '+str(sorted(absent)))
    return dict(schema='Typed-Q-common-trace-closure-diagnostic-v1',
        regular_step_complete=not ledger.missing,first_step=first_step,proved=False,qualified=False,
        unresolved=ledger.missing,step_applications=ledger.audit,
        histories=UPDATERS,rigid_parameters=['model','tile','lane','watch'],
        current_invariant=current,old_qualified_interface=old,
        root_formulas=root,
        reset_base=bases(),
        note='Diagnostic missing premises are NEVER accepted as trace assumptions')


def reconstruction():
    result=dict(regular=structural(),bootstrap=structural(True),endpoints=endpoints(),proved=False,qualified=False)
    result['raw_endpoints']=raw_endpoints(result['regular'])
    gaps=result['regular']['unresolved']+result['bootstrap']['unresolved']
    for branch in ['regular','bootstrap']:
        gaps+=result[branch]['reset_base']['unresolved']
        if result[branch]['reset_base']['unmatched_base_targets']:raise ValueError('Reset target mismatch')
    for endpoint in result['endpoints'].values():gaps+=endpoint['unresolved']
    for endpoint in result['raw_endpoints'].values():gaps+=endpoint['unresolved']
    result['all_premises_closed']=not gaps
    return result


def logical_controls():
    import copy
    result={}
    for defect in ['missing-predecessor-invariants','wrong-normalizer-updater','unfixed-lane','missing-post-lineage-provider']:
        try:record=structural(defect=defect);accepted=record['regular_step_complete']
        except ValueError:accepted=False
        if accepted:raise ValueError('Invalid common-trace construction accepted: '+defect)
        result[defect]='rejected by missing exact premises or postcondition; no metadata/hash check involved'
    expected=reconstruction()
    altered=copy.deepcopy(expected)
    altered['regular']['root_formulas'].append('(= native_result desired_result)')
    if altered==reconstruction():raise ValueError('Desired-result oracle accepted')
    result['desired-result-oracle']='rejected by exact code reconstruction of the trace root, independent of candidate hashes'
    try:literal_substitute('(forall ((a Bool)) a)',{'a':'an'})
    except ValueError:result['captured-bound-variable']='rejected before substitution'
    else:raise ValueError('Binder capture accepted')
    return result


def typecheck(result,recorded=None):
    """Check all instantiated formulas in the actual product's native theory."""
    import subprocess,time
    from datetime import datetime,timezone
    files=plan('q-trace-links')['bodies']+['normalizer-faults/history.smt2']
    body='\n'.join((HERE/x).read_text()for x in files)
    decl={}
    for label,profile,base,join in SCHEDULE:
        for declaration in plan(label)['declarations']:
            name,sort=parse(transform(declaration,profile))[0][1:]
            mapped=mapping(label,profile).get(name,name)
            sort=emit(sort)
            if mapped in decl and decl[mapped]!=sort:raise ValueError('Conflicting trace variable type '+mapped)
            decl[mapped]=sort
    decl.update({'ap':S,'zp':NS,'ep':ES,'model':'(Array (_ BitVec 18) (_ BitVec 256))','watch':'(_ BitVec 10)'})
    for sort,stem in HISTORY_NAMES.items():
        for suffix in ['','n','p']:decl[stem+suffix]=sort
    formulas=[]
    for branch in ['regular','bootstrap']:
        for record in [result[branch],result[branch]['reset_base']]:
            formulas+=record['root_formulas']
            formulas+=[a['conclusion']for a in record.get('step_applications',record.get('applications',[]))]
    for endpoint in list(result['endpoints'].values())+list(result['raw_endpoints'].values()):
        formulas+=[a['conclusion']for a in endpoint['applications']]
        if 'closed_contract'in endpoint:formulas.append(endpoint['closed_contract'])
    text=body+'\n'+'\n'.join(f'(declare-const {k} {v})'for k,v in sorted(decl.items()))+'\n'
    text+='\n'.join('(assert '+f+')'for f in formulas)+'\n(exit)\n'
    d=HERE/'trace-closure'/'typechecks'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');d.mkdir(parents=True)
    (d/'typecheck.smt2').write_text(text)
    start=time.monotonic();command=['z3','-memory:8192','-T:30',str(d/'typecheck.smt2')]
    if recorded is None:
        with(d/'z3.log').open('w')as log:proc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=35)
        code=proc.returncode
    else:
        saved=json.loads(recorded.read_text())
        if (not saved.get('passed')or not saved.get('typecheck_only')or not saved.get('no_check_sat')or
                saved.get('proof_result')is not False or saved['exit_code']!=0 or
                saved['query_sha256']!=sha(text.encode())or saved['log_sha256']!=sha(b'')):
            raise ValueError('Recorded trace typecheck differs from the exact original formula')
        (d/'z3.log').write_bytes(b'');code=0
    raw=(d/'z3.log').read_bytes()
    receipt=dict(typecheck_only=True,proof_result=False,no_check_sat=True,command=command,seconds=time.monotonic()-start,
        exit_code=code,passed=code==0 and not raw.strip(),recorded_only=recorded is not None,
        query_sha256=sha(text.encode()),log_sha256=sha(raw),receipt=str((d/'RESULT.json').relative_to(HERE)))
    write_json(d/'RESULT.json',receipt)
    if not receipt['passed']:raise ValueError('Trace typecheck failed: '+str(d.relative_to(HERE)))
    return receipt


def verify(recorded_types=None):
    from q_check import check_many
    from trace_source_lifts import evidence
    result=reconstruction()
    if not result['all_premises_closed']:raise ValueError('Common trace has unclosed proof premises')
    typed=typecheck(result,recorded_types)
    requests=[(l,None)for l,p,b,j in SCHEDULE]
    requests.extend([('q-trace-links',None),('q-trace-bootstrap',None),
        ('q-endpoint-links',None),('q-main-witness',None),('q-frontier-value-r3',None),('q-raw-scope',None),
        ('q-main',[n for n in result['endpoints']if n in plan('q-main')['rules']]+['CLEAR-nonzero-exponent-compatible-context'])])
    providers,census=check_many(requests,with_closure=True)
    from check_derivation import check as old_check
    old={l:old_check(l,True)for l in OLD}
    boundaries=plan('words',True)['root_external_assumptions']
    if boundaries!=['vendor application storage behavior','runtime-entry model-image write-fold identity',
            'static metadata-ROM/model binding','named digital RTL/source/clock/reset semantics']:
        raise ValueError('Changed qualified model/memory boundaries')
    from operand_step import verify as verify_weakening
    verify_weakening()
    sources=evidence()
    result.update(trace_induction_checked=True,source_instantiations=sources,providers=providers,
        verified_engine_rule_census=census,
        logical_controls=logical_controls(),
        old_qualified_trace_providers=old,root_boundaries=boundaries,instantiated_typecheck=typed,
        proof_rule='Joint invariant: common-reset bases; empty-capture first-step bootstrap; two-edge induction with one retained predecessor; literal endpoint implication application',
        selector_rule='Universal fixed tile/lane family. Certificate fixes watch with low-bit tile/lane for its whole trace; shared argument/normalizer histories are watch-independent.',
        qualified=False,whole_Q_operator_proved=False,whole_machine_theorem=False,
        remaining='Operating/sensitivity qualification, positive context completion, independent final audit and portable replay')
    write_json(HERE/'TRACE-CLOSURE.json',result)
    return result


def main():
    from pathlib import Path
    parser=argparse.ArgumentParser();parser.add_argument('--diagnose',action='store_true');parser.add_argument('--verify',action='store_true');parser.add_argument('--recorded-types',type=Path);args=parser.parse_args()
    if args.verify:
        result=verify(args.recorded_types);print('Common-reset, bootstrap, regular-step and all endpoints checked against actual source and raw component receipts. Operator qualification is recorded separately.');return 0
    result=reconstruction()
    gaps=result['regular']['unresolved']+result['bootstrap']['unresolved']+result['regular']['reset_base']['unresolved']
    write_json(HERE/'TRACE-CLOSURE-DIAGNOSTIC.json',result)
    for row in gaps:
        print(row['provider']+':'+row['rule']+' missing '+str(len(row['missing'])))
        for f in row['missing'][:4]:print('  '+f[:300])
    print('All premises closed:',result['all_premises_closed'],'; diagnostic only, NOT qualified.')
    return 0 if result['all_premises_closed']else 1

if __name__=='__main__':raise SystemExit(main())

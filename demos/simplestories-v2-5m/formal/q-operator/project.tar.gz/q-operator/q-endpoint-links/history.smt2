; Actual raw/DONE output validity implies its source instance is out of reset.

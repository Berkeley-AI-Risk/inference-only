"""Checked identical-source module trace instantiation.

This is the explicit source-level module-substitution rule, not equality of
unrelated SMT state sorts. A full actual parent transition is required for
local full/control transitions alike. Numeric histories never specialize from
the parent MAC/helper-omitting transition. The native frontend and ordinary
identical-source hierarchical instantiation are stated trust boundaries.
"""
import re
from functools import lru_cache
from arithmetic import HERE,OPERANDS
from pruned_arithmetic import parse,emit,atoms
from q_columns import TOP,S,ENGINE
from prefix_control import TOP as ENGINE_LOCAL
from selector import TOP as NORM, S as NS
from shift import TOP as SHIFT_LOCAL
from tile import TOP as TILE_LOCAL


@lru_cache(maxsize=None)
def local_initial_is_true(model,top):
    source=(HERE/model/'native.smt2').read_text()
    marker='(define-fun |'+top+'_i|'
    definitions=[x for x in parse(source)if isinstance(x,list)and x[:2]==['define-fun','|'+top+'_i|']]
    if len(definitions)!=1 or definitions[0][4]!='true':raise ValueError('Nontrivial local initialization needs an explicit instance proof')


def replace_step(nodes,local,parent,weak=()):
    old={'engine':ENGINE_LOCAL,'tile':TILE_LOCAL,'helper':SHIFT_LOCAL}[local]
    def tr(x):
        if not isinstance(x,list):return x
        if x and x[0]=='|'+old+'_i|':
            local_initial_is_true({'engine':'prefix','tile':'tile','helper':'shift'}[local],old)
            if len(x)!=2:raise ValueError('Malformed local initializer')
            return 'true'
        if x and x[0]in ['|'+old+'_t|',*weak]:return ['|'+parent+'_t|',*[tr(a)for a in x[1:]]]
        if x and x[0]=='|'+old+'_h|':return ['|'+parent+'_h|',*[tr(a)for a in x[1:]]]
        return [tr(v)for v in x]
    return [tr(x)for x in nodes]


@lru_cache(maxsize=None)
def engine(text):
    from q_engine import translate
    nodes=replace_step(parse(text),'engine',TOP,weak=('prefix-native-step',))
    return translate('\n'.join(emit(x)for x in nodes)).strip()


@lru_cache(maxsize=None)
def tile(text):
    from tile_hold import specification
    definitions=parse(specification()[1])
    names={x[1]for x in definitions if x[0]=='define-fun'and x[1]!='tile-zero'}
    nodes=replace_step(parse(text),'tile',TOP,weak=('tile-native-step',))
    parent=(HERE/'q-engine/history.smt2').read_text()
    def tr(x):
        if not isinstance(x,list):return S if x=='|'+TILE_LOCAL+'_s|'else x
        if x and isinstance(x[0],str)and x[0].startswith('|'+TILE_LOCAL+'_n '):
            field=x[0][len('|'+TILE_LOCAL+'_n '):-1]
            accessor='|lineage-native '+field+'|'
            if '(define-fun '+accessor+' 'not in parent:raise ValueError('Tile trace requires an unmapped actual getter '+field)
            if len(x)!=2:raise ValueError('Unexpected local tile getter arity')
            return [accessor,tr(x[1]),'tile']
        result=[tr(v)for v in x]
        if result and isinstance(result[0],str)and result[0]in names:result.append('tile')
        return result
    result=[tr(x)for x in nodes]
    if any(TILE_LOCAL in x for x in atoms(result)):raise ValueError('Incomplete tile trace specialization')
    return '\n'.join(emit(x)for x in result)


@lru_cache(maxsize=None)
def helper(text):
    nodes=replace_step(parse(text),'helper',NORM)
    local=(HERE/'shift/native.smt2').read_text();parent=(HERE/'selector/native.smt2').read_text()
    fields=sorted(set(re.findall(r'\|'+SHIFT_LOCAL+r'_(n|m) ([^|]+)\|',text)))
    mapping={'|'+SHIFT_LOCAL+'_s|':NS}
    for kind,field in fields:
        left=f'(define-fun |{SHIFT_LOCAL}_{kind} {field}| ((state |{SHIFT_LOCAL}_s|)) '
        right=f'(define-fun |{NORM}_{kind} u_shift.{field}| ((state {NS})) '
        if local.count(left)!=1 or parent.count(right)!=1:raise ValueError('Missing actual helper getter '+field)
        sort=re.match(r'(Bool|\(_ BitVec \d+\)) ',local.split(left,1)[1]).group(1)
        if not parent.split(right,1)[1].startswith(sort+' '):raise ValueError('Helper trace getter sort mismatch')
        mapping['|'+SHIFT_LOCAL+'_'+kind+' '+field+'|']='|'+NORM+'_'+kind+' u_shift.'+field+'|'
    def tr(x):return [tr(v)for v in x]if isinstance(x,list)else mapping.get(x,x)
    result=[tr(x)for x in nodes]
    if any(SHIFT_LOCAL in x for x in atoms(result)):raise ValueError('Incomplete helper trace specialization')
    return '\n'.join(emit(x)for x in result)


def transform(text,profile):
    if profile=='engine':return engine(text)
    if profile=='tile':return tile(text)
    if profile=='helper':return helper(text)
    if profile in ['root','normalizer']:return '\n'.join(emit(x)for x in parse(text))
    raise ValueError('Unknown source trace profile')


def evidence():
    from q_engine import binding,definitions
    from tile_bindings import record
    from norm_shift import source_binding,translated_history
    from q_normalizer_product import source_binding as normalizer_binding
    from q_exponent import source_binding as exponent_binding,verify_replay
    if (HERE/'q-engine/history.smt2').read_text()!=definitions():raise ValueError('Changed source engine functional histories')
    shift=(HERE/'norm-shift/history.smt2').read_text()
    if not shift.startswith(translated_history()):raise ValueError('Changed actual helper functional history')
    return dict(engine=binding(),all64_tiles=record('tile-held'),helper=source_binding(),
        normalizer=normalizer_binding(),exponent=exponent_binding(),exponent_replay=verify_replay(),
        source_rule='Universal identical-source module trace instantiation, exact ports/parameters/clock/reset, full actual transition required',
        no_state_sort_identification=True,no_numerical_reply_assumption=True,
        fixed_selectors='One rigid BV2 tile/BV4 lane per trace instance; all64 universal family. Fixed watch selects its low bits for the entire certificate trace.',
        trust=['Native RTL frontend','Standard identical-source hierarchical module substitution','Named configured DSP behavioral semantics; no physical primitive equivalence claim'])

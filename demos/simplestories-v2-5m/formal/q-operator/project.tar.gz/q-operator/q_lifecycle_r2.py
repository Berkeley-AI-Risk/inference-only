"""Close parent completion/start-seen coherence as a proved mutual invariant.

R1 countermodels started a new child with done-seen=true/start-seen=false. R2
proves those combinations unreachable from actual reset/accept/DONE controls.
"""
import json
from arithmetic import HERE,sha,write_json
from q_lifecycle import specification as original,body_files as original_files,PROVIDERS


def specification():return original(revision=2)


def body_files():return original_files()[:-1]+['q-lifecycle-r2/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-lifecycle-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-parent-child-invocation-lifecycle-r2-v1',component='q-lifecycle-r2',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-lifecycle-r2-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-lifecycle-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed strengthened invocation ownership')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Done-seen implies start-seen added to the jointly proved lifecycle invariant.')

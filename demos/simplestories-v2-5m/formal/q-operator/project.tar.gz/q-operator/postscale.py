"""Finite-word split/extension/recombination lemmas, before pipeline joining."""
import json
from arithmetic import HERE,MUL,bv,both,eq,sext,signed,compile_model,sha,write_json


def specification():
    declarations=['(declare-const d (_ BitVec 35))','(declare-const m (_ BitVec 15))']
    low='((_ zero_extend 25) ((_ extract 24 0) d))'
    high='((_ sign_extend 40) ((_ extract 34 25) d))'
    mult='((_ zero_extend 35) m)'
    D=sext('d',15)
    shifted=f'(bvshl {high} {bv(25,50)})'
    L=f'(bvmul {low} {mult})';H=f'(bvmul {high} {mult})'
    recombined=f'(bvadd {L} (bvshl {H} {bv(25,50)}))'
    rules={
        'signed35-split-reconstruction':dict(assumptions=[],conclusion=eq(D,f'(bvadd {low} {shifted})')),
        'signed35-integer-split':dict(assumptions=[],conclusion=eq(signed('d',35),
            f'(+ (bv2int ((_ extract 24 0) d)) (* 33554432 {signed("((_ extract 34 25) d)",10)}))')),
        'native-low27-extension':dict(assumptions=[],conclusion=eq(sext('((_ zero_extend 2) ((_ extract 24 0) d))',23),low)),
        'native-high27-extension':dict(assumptions=[],conclusion=eq(sext('((_ sign_extend 17) ((_ extract 34 25) d))',23),high)),
        'positive-mult18-extension':dict(assumptions=[],conclusion=eq(sext('((_ zero_extend 3) m)',32),mult)),
        'split-multiply-recombine50':dict(assumptions=[],conclusion=eq(recombined,f'(bvmul {D} {mult})')),
        'low-product-fits48':dict(assumptions=[],conclusion=eq(sext(f'((_ extract 47 0) {L})',2),L)),
        'high-product-fits48':dict(assumptions=[],conclusion=eq(sext(f'((_ extract 47 0) {H})',2),H)),
    }
    return declarations,'',rules


def prepare():
    compile_model('mul',MUL,{'cluster-tile.sv':[MUL]})
    declarations,defs,rules=specification();d=HERE/'postscale';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['mul/native.smt2','postscale/history.smt2'];paths=['mul-SOURCES.json','mul/native.sv','mul/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-postscale-words-v1',component='postscale',bodies=bodies,source_manifest='mul-SOURCES.json',native_source='mul/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='postscale-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'postscale-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed postscale-word plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

"""Finite native projection-to-normalizer arithmetic and defect qualification.

Actual job and normalizer are connected directly at their stream interface.
This is not the actual datapath controller composition or a formal memory proof.
"""
import argparse
import json
import subprocess
import sys
from arithmetic import HERE,OPERANDS,native_source,sha,write_json
from reference import image,q,normalize


def replace_once(text,before,after):
    if text.count(before)!=1:raise ValueError('Fixture/source site changed: '+before)
    return text.replace(before,after,1)


PATTERNS={
    'small':'((c*7+generation*5)%63)-31',
    'maximum-positive':'32767',
    'maximum-negative':'-32767',
    'cancellation':'(c%2==0)?32767:-32767',
    'zero':'0',
    'impulse':'(c==0)?32767:0',
}


def arguments(pattern,layer):
    if pattern=='small':return [((c*7+(layer+3)*5)%63)-31 for c in range(256)]
    if pattern=='maximum-positive':return [32767]*256
    if pattern=='maximum-negative':return [-32767]*256
    if pattern=='cancellation':return [32767 if c%2==0 else -32767 for c in range(256)]
    if pattern=='zero':return [0]*256
    if pattern=='impulse':return [32767]+[0]*255
    raise ValueError('Unknown activation pattern')


def bench(pattern='small'):
    sys.path.insert(0,str(OPERANDS))
    from witness_job import BENCH
    result=BENCH
    result=replace_once(result,'argument=((c*7+generation*5)%63)-31;','argument='+PATTERNS[pattern]+';')
    # Icarus requires these declarations before the new instance/monitor uses.
    declarations=[' integer head=0,tail=0,debt=0,cycle=0,requests=0,responses=0;',
        ' reg active=0,expect_mac=0,expect_read=0;',
        ' integer generation=0,current_layer=0,captures=0,groups=0,current_group=0,meta_count=0;']
    for declaration in declarations:result=replace_once(result,declaration+'\n','')
    result=replace_once(result,'module tb;','module tb;\n'+'\n'.join(declarations))
    result=replace_once(result,' wire sr,ar,req,rr,done,fail;wire[18:0]address;wire[255:0]data;',
        ''' wire sr,ar,req,rr,done,fail;wire[18:0]address;wire[255:0]data;
 wire qv,qr,ql;wire[12:0]qi;wire signed[49:0]qraw;wire signed[7:0]qe;
 wire nsr,nv,nd,nf,nl;wire[9:0]ni;wire signed[15:0]nm;wire signed[7:0]ne;
 wire nr=cycle%5!=0;
 reg job_seen=0,norm_seen=0;
 reg[57:0]raw_expected[0:1535];reg[34:0]norm_expected[0:1535];
 integer raw_count=0,norm_count=0;
 board1_fixed_vector_normalizer normalizer(
  .clk(clk),.rst_n(reset_n),.clear_i(clear_i),.model_lock_i(1'b1),.upstream_fault_i(1'b0),
  .start_valid_i(start),.start_ready_o(nsr),.fixed_layer_i(layer),.fixed_job_i(4'd0),
  .input_valid_i(qv),.input_ready_o(qr),.input_row_index_i(qi[9:0]),.input_raw_i(qraw),.input_source_exponent_i(qe),.input_last_i(ql),
  .result_valid_o(nv),.result_ready_i(nr),.result_row_index_o(ni),.result_mantissa_o(nm),.result_exponent_o(ne),.result_last_o(nl),
  .done_valid_o(nd),.done_ready_i(1'b1),.busy_o(),.range_fault_o(nf));
 always @(posedge clk)begin
  if(!reset_n||clear_i||start)begin job_seen<=0;norm_seen<=0;raw_count=0;norm_count=0;end
  else if(active)begin
   if(done)job_seen<=1;
   if(nd)norm_seen<=1;
   if(nf)$fatal(1,"unexpected normalization fault");
   if(qv)begin
    if(raw_count>=256 || qi!==raw_count || ql!==(raw_count==255) || {qe,qraw}!==raw_expected[current_layer*256+raw_count])
     $fatal(1,"raw arithmetic mismatch L=%0d row=%0d",current_layer,raw_count);
    if(qr)raw_count=raw_count+1;
   end
   if(nv)begin
    if(norm_count>=256 || {ni,nm,ne,nl}!==norm_expected[current_layer*256+norm_count])
     $fatal(1,"normalized arithmetic mismatch L=%0d row=%0d",current_layer,norm_count);
    if(nr)norm_count=norm_count+1;
   end
  end
 end''')
    result=replace_once(result,'.result_valid_o(),.result_ready_i(cycle%5!=0),.result_row_index_o(),.result_scaled_raw_o(),.result_source_exponent_o(),.result_last_o(),',
        '.result_valid_o(qv),.result_ready_i(qr),.result_row_index_o(qi),.result_scaled_raw_o(qraw),.result_source_exponent_o(qe),.result_last_o(ql),')
    result=replace_once(result,'   while(!sr)@(negedge clk);','   while(!sr||!nsr)@(negedge clk);')
    result=replace_once(result,'  $readmemh("model256.memh",model);',
        '  $readmemh("model256.memh",model);\n  $readmemh("raw-expected.memh",raw_expected);\n  $readmemh("norm-expected.memh",norm_expected);')
    result=replace_once(result,'   while(!done)@(negedge clk);',
        '   while(!job_seen||!norm_seen)@(negedge clk);\n   if(raw_count!=256||norm_count!=256)$fatal(1,"missing arithmetic outputs");')
    result=replace_once(result,'PASS: six full Q layers, 393216 coefficient/capture pairs, 1536 current metadata records, registered MAC operands, stalls and CLEAR/drain.',
        'PASS: six full native Q projections and normalizations, 1536 exact raw and normalized rows, all64 lanes, stalls and CLEAR/drain.')
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case',choices=['operating','wrong-product-sign','missing-FIRST','wrong-postscale-split','dropped-accumulation','duplicated-product','wrong-record-read-row','shifted-FIRST-tag'],default='operating')
    ap.add_argument('--pattern',choices=list(PATTERNS),default='small')
    ap.add_argument('--campaign',default='connected-operating-r3')
    args=ap.parse_args()
    if not args.campaign.startswith('connected-operating-')or'/'in args.campaign:raise ValueError('Invalid local campaign name')
    root=HERE/args.campaign/args.pattern;root.mkdir(exist_ok=True,parents=True)
    d=root/args.case;d.mkdir(exist_ok=False)
    raw=image()
    (d/'model256.memh').write_text(''.join('%064x\n'%int.from_bytes(raw[i:i+32],'little')for i in range(0,len(raw),32)))
    raws=[];norms=[]
    for layer in range(6):
        A=arguments(args.pattern,layer)
        records=q(raw,layer,A,-10);prefix,outcome=normalize(records)
        if not outcome['success']or len(prefix)!=256:raise ValueError('Unexpected reference rejection')
        raws.extend(records);norms.extend(prefix)
    (d/'raw-expected.memh').write_text(''.join('%015x\n'%(((e&255)<<50)|(r&((1<<50)-1)))for r,e in raws))
    (d/'norm-expected.memh').write_text(''.join('%09x\n'%((r<<25)|((m&65535)<<9)|((e&255)<<1)|last)for r,m,e,last in norms))
    normalizer,sources=native_source({'normalizer_pipeline.sv':['board1_fixed_vector_normalizer'],'candidate.sv':['board1_fixed_vector_rne_shift_pipeline1']})
    source=(OPERANDS/'job/native.sv').read_text()+'\n'+normalizer
    edits={
        'wrong-product-sign':('product_q<=activation_i*weight_i;','product_q<=$unsigned(activation_i)*$unsigned(weight_i);'),
        'missing-FIRST':("(first_i ? 48'sd0 : accumulator_q)","accumulator_q"),
        'wrong-postscale-split':('<<< 25','<<< 24'),
        'dropped-accumulation':("(first_i ? 48'sd0 : accumulator_q)+", "48'sd0+"),
        'duplicated-product':("{{22{product_q[25]}},product_q};", "{{22{product_q[25]}},product_q}+{{22{product_q[25]}},product_q};"),
        'wrong-record-read-row':('record_read_q <= record_mem_q[scan_index_q];',"record_read_q <= record_mem_q[scan_index_q ^ 10'd1];"),
        'shifted-FIRST-tag':('.first_i(product_first_q),.activation_i(activation_q)', '.first_i(op_first_q),.activation_i(activation_q)'),
    }
    if args.case in edits:source=replace_once(source,*edits[args.case])
    tb=bench(args.pattern);(d/'native.sv').write_text(source);(d/'tb.sv').write_text(tb)
    with (d/'compile.log').open('w')as f:
        cp=subprocess.run(['iverilog','-g2012','-s','tb','-o','sim','native.sv','tb.sv'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    if cp.returncode:raise ValueError('Connected fixture compile failed')
    with(d/'simulation.log').open('w')as f:
        cp=subprocess.run(['vvp','sim'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    log=(d/'simulation.log').read_bytes()
    detected=b'raw arithmetic mismatch'in log or (args.case=='wrong-record-read-row'and b'normalized arithmetic mismatch'in log)
    passed=(cp.returncode==0 and b'PASS: six full native Q'in log)if args.case=='operating'else(cp.returncode!=0 and detected)
    result=dict(passed=passed,case=args.case,pattern=args.pattern,finite_operating_evidence=True,native_sha256=sha(source.encode()),
        unmutated_projection_sha256=sha((OPERANDS/'job/native.sv').read_bytes()),normalizer_sources=sources,
        bench_sha256=sha(tb.encode()),reference_sha256=sha((HERE/'reference.py').read_bytes()),model_image_sha256=sha(raw),
        log_sha256=sha(log),exit_code=cp.returncode,all_six_layers=True,all64_lanes=True,
        projection_to_normalizer_stream='actual native instances; test harness connection, not formal actual-datapath composition',
        memory_responder='finite test provider, not formal memory composition',whole_Q_operator_proved=False,whole_machine_theorem=False)
    write_json(d/'RESULT.json',result);print(log.decode());print(json.dumps(dict(passed=passed,case=args.case)))
    if not passed:raise SystemExit(1)


if __name__=='__main__':main()

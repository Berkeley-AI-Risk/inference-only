"""Read-only native countermodels for unclosed induction steps, saved separately."""
from datetime import datetime,timezone
import fcntl
import json
from pathlib import Path
import subprocess
import time
from arithmetic import HERE,PILOT,sha
from lanes import n,ENGINE
from q_columns import J,A
import sys
sys.path.insert(0,str(PILOT))
from checkpoint import atomic_bytes,atomic_json


def main():
    with(HERE/'RUN.lock').open('w')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        statepath=HERE/'STATE.json';state=json.loads(statepath.read_text())
        if state['active_owned_jobs']:raise ValueError('Owned proof jobs are active')
        checks=json.loads((HERE/'q-columns-CHECKS.json').read_text())
        for rule in ['current-1']:
            prior=checks['rules'][rule];source=(HERE/prior['receipt']).parent/'query.smt2';text=source.read_text()
            fields=['reset_n','u_native.child_reset_n',A+'fail_q',J+'integrated_fail',J+'job_q',J+'state_q',J+'columns_q',ENGINE+'state_q',ENGINE+'columns_q',ENGINE+'kill',ENGINE+'g_tile[0].u_tile.op_valid_q',ENGINE+'g_tile[0].u_tile.product_valid_q']
            observations=[n(field)for field in fields]+['pc','th','(c-mac-column ch)','(c-mac-valid ch)','(j-cols (c-base ch))','tile','lane']
            diagnostic=text+'(get-value ('+' '.join(observations)+'))\n'
            d=HERE/'diagnostics'/('q-columns-'+rule+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));d.mkdir(parents=True)
            atomic_bytes(d/'query.smt2',diagnostic.encode());command=['z3','-memory:8192','-T:30',str(d/'query.smt2')]
            begin=time.monotonic()
            with(d/'z3.log').open('w')as log:
                proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
                state['active_owned_jobs']=[dict(pid=proc.pid,component='q-columns-diagnostic',rule=rule,command=command)]
                atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
                code=proc.wait(timeout=35)
            seconds=time.monotonic()-begin;raw=(d/'z3.log').read_bytes()
            atomic_json(d/'RESULT.json',dict(rule=rule,diagnostic_only=True,proof_result=False,exit_code=code,seconds=seconds,canonical_source_sha256=sha(source.read_bytes()),query_sha256=sha(diagnostic.encode()),log_sha256=sha(raw)))
            state['active_owned_jobs']=[];state['solver_seconds']+=seconds
            atomic_json(statepath,state);atomic_json(HERE/'SETUP-STATE.json',state)
            print(rule,raw.decode())


if __name__=='__main__':main()

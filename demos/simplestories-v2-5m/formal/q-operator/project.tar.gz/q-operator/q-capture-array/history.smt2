; Every authoritative watched record is retained or written from the actual current input.

"""Endpoint-only control continuation from a healthy root to the next edge.

No postterminal API/debt invariant is assumed. The endpoint can use only the
already-complete EMIT sum and held/advancing frame support from the old state.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,ENGINE,J,A,n
from q_raw_r2 import body_files as raw_files
from q_model import MODEL


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const mh MathHistory)','(declare-const mhn MathHistory)','(declare-const fr FrameHistory)','(declare-const frn FrameHistory)',
        '(declare-const qi QIdentity)','(declare-const qin QIdentity)','(declare-const qj QJobHistory)','(declare-const qjn QJobHistory)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))',f'(declare-const model {MODEL})']
    H=lambda s:f'(|{TOP}_h| {s})'
    context=[H('a'),H('an'),'(operand-native-step a an)',f'(not {n(A+"fail_q")})',
        '(capture-inv a ch)','(capture-inv an chn)','(= chn (capture-next a ch))',
        '(prefix-inv a pc)','(prefix-inv an pcn)','(= pcn (prefix-next a pc))',
        '(lineage-inv a pc th lane tile)','(lineage-inv an pcn thn lane tile)','(= thn (tile-next a th lane tile))',
        '(= mhn (math-next a th mh tile))','(frame-inv a fr)','(frame-inv an frn)','(= frn (frame-next a fr))',
        '(qi-inv a ch qi)','(= qin (qi-next a ch qi))','(qj-inv a qj)','(qj-inv an qjn)','(= qjn (qj-next a qj))',
        n(J+'result_valid_o','an'),eq(n(J+'job_q','an'),bv(0,4))]
    flag=lambda i:f'(= ((_ extract {i} {i}) {n(""+ENGINE+"scale_valid_q")}) #b1)'
    held=both([f'(not {n(ENGINE+"advance")})',flag(3),*[eq(f'(fr-{k}3 frn)',f'(fr-{k}3 fr)')for k in ['D','M','E','R']]])
    advancing=both([n(ENGINE+'advance'),flag(2),*[eq(f'(fr-{k}3 frn)',f'(fr-{k}2 fr)')for k in ['D','M','E','R']]])
    facts=[
        both(['(qc-live a)',eq(n(ENGINE+'state_q'),bv(4,3)),f'(not {n(ENGINE+"kill")})',f'(not {n(ENGINE+"g_tile[0].u_tile.begin_i")})']),
        both([eq('qin','qi'),eq('(mh-S mhn)','(mh-S mh)')]),
        both([eq(n(J+field,'an'),n(J+field))for field in ['job_q','layer_q','group_q','activation_exponent_q']]+[eq('(qj-layer qjn)','(qj-layer qj)'),eq('(qj-exponent qjn)','(qj-exponent qj)')]),
        '(or '+held+' '+advancing+')']
    rules={name:dict(assumptions=context,conclusion=fact)for name,fact in zip(['previous-certified-EMIT','sum-and-vector-snapshot-stable','accepted-descriptor-stable','held-or-advancing-certified-frame'],facts)}
    return decl,'; One-step endpoint control support; no future healthy-root premise.\n',rules


def body_files():return raw_files()+['q-frontier-control/history.smt2']


PROVIDERS=['q-prefix-r3','q-job-r2','q-routing-r2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-frontier-control';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-one-edge-endpoint-control-v1',component='q-frontier-control',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-frontier-control-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-frontier-control-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed terminal output continuation')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Old healthy-state endpoint support to next-edge Q output prepared.')

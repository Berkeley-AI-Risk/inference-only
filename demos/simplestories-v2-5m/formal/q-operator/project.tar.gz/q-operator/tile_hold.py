"""Strengthen the tile read ownership window through arbitrary read stalls.

The read value remains owned until a different/unowned read or cancellation.
This is needed when a pending postscale stage0 waits under global backpressure.
"""
import json
from arithmetic import HERE,MAC,bv,both,eq,sha,write_json,compile_model
from tile import TOP,n
from tile_cases import specification as cases_specification


def specification():
    declarations,defs,rules=cases_specification()
    old=both([n('read_i'),eq(n('read_lane_i'),'lane'),'(th-owned h)'])
    # Change only the history constructor's read-valid field. The same event
    # expression still controls dot-data capture; it must remain unchanged.
    before=' '+old+' (ite '+old
    after=f' (ite {n("read_i")} {both([eq(n("read_lane_i"),"lane"),"(th-owned h)"])} (th-read h)) (ite '+old
    if defs.count(before)!=1:raise ValueError('Exact tile history read ownership site changed')
    defs=defs.replace(before,after,1)
    return declarations,defs,rules


def prepare():
    compile_model('tile',TOP,{'cluster-tile.sv':[MAC,TOP]})
    declarations,defs,rules=specification();d=HERE/'tile-held';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['tile/native.smt2','tile-held/history.smt2'];paths=['tile-SOURCES.json','tile/native.sv','tile/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-held-read-tile-history-v1',component='tile-held',bodies=bodies,source_manifest='tile-SOURCES.json',native_source='tile/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='tile-held-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'tile-held-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed held-read tile plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Held synchronous read ownership strengthened; unchanged tile RTL and native model.')

"""The previous completed input snapshot is still the current accepted vector.

The one-edge raw contract uses QIdentity across terminal failure. This source
lemma relates that identity to current JobHistory even when its current healthy
guard is false: no activation store occurs in the previous completed EMIT phase.
"""
import json
from arithmetic import HERE,eq,sha,write_json
from q_frontier_control import specification as control_spec,body_files as control_files


def specification():
    decl,_,rules=control_spec()
    root=rules['previous-certified-EMIT']['assumptions']+['(qc-inv a pc th ch lane tile)']
    goal=eq('(qi-vector qin)','(j-memory (c-base chn))')
    return decl,'; No current arbiter-health premise; actual prior EMIT cannot change accepted activation memory.\n',{
        'current-raw-identity-is-current-accepted-vector':dict(assumptions=root,conclusion=goal)}


def body_files():return control_files()+['q-frontier-vector/history.smt2']


PROVIDERS=['q-frontier-control','q-identity','q-columns-r3']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-frontier-vector';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-terminal-accepted-vector-continuity-v1',component='q-frontier-vector',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-frontier-vector-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-frontier-vector-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed terminal vector identity')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Completed input identity through the first terminal edge prepared.')

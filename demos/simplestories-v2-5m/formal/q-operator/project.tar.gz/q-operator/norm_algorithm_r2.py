"""Strengthened normalizer refinement; R1 countermodels are retained.

The pure independent algorithm is unchanged. R2 proves the pipeline's zero flag
also at SELECT_EVAL and scopes descriptor equality to authoritative phases.
"""
import json
from arithmetic import HERE,sha,write_json
from norm_algorithm import specification as original,provider_facts


def specification():return original(revision=2)


def prepare():
    decl,defs,rules=specification();d=HERE/'norm-algorithm-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    providers=['norm-capture-r2','shift','norm-shift','selector']
    bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture-r2/history.smt2','norm-shift/history.smt2','norm-algorithm-r2/history.smt2']
    paths=['selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json',*[p+'-PLAN.json'for p in providers],*bodies]
    plan=dict(schema='Typed-Q-whole-normalizer-algorithm-r2-v1',component='norm-algorithm-r2',bodies=bodies,source_manifest='selector-SOURCES.json',native_source='selector/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='norm-algorithm-r2-CHECKS.json',
        providers=providers,provider_facts=provider_facts(),external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'norm-algorithm-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed refined normalizer induction')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Unchanged independent algorithm; stronger pipeline refinement and fault ownership scope.')

"""Integer word-interpretation lemmas; native-word application is separate.

These elementary mod/sign lemmas hold independently of any hardware. The
component's passed status does not claim a native BV-to-Int correspondence.
"""
import json
from arithmetic import HERE,MAC,sha,write_json,compile_model


def sval(x,width):
    modulus=1<<width;half=1<<(width-1)
    residue=f'(mod {x} {modulus})'
    return f'(ite (< {residue} {half}) {residue} (- {residue} {modulus}))'


def specification():
    declarations=['(declare-const q Int)','(declare-const x Int)','(declare-const y Int)']
    rules={}
    for width in [16,26,35,48,50,64]:
        half=1<<(width-1)
        rules['signed-mod-exact-%d'%width]=dict(assumptions=[f'(<= (- {half}) q)',f'(< q {half})'],conclusion=f'(= {sval("q",width)} q)')
    rules['signed16x10-product-fits26']=dict(assumptions=['(<= (- 32768) x)','(<= x 32767)','(<= (- 512) y)','(<= y 511)'],
        conclusion='(and (<= (- 16777216) (* x y)) (<= (* x y) 16777216) (< (- 33554432) (* x y)) (< (* x y) 33554432))')
    rules['signed-add48-exact-under-sum-bound']=dict(assumptions=['(<= (- 140737488355328) (+ x y))','(< (+ x y) 140737488355328)'],
        conclusion=f'(= {sval("(+ x y)",48)} (+ x y))')
    return declarations,'',rules


def prepare():
    compile_model('mac',MAC,{'cluster-tile.sv':[MAC]})
    declarations,defs,rules=specification();d=HERE/'word-semantics';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['mac/native.smt2','word-semantics/history.smt2'];paths=['mac-SOURCES.json','mac/native.sv','mac/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-integer-word-semantics-v1',component='word-semantics',bodies=bodies,source_manifest='mac-SOURCES.json',native_source='mac/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='word-semantics-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'word-semantics-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed word-semantics plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

"""Engine-checked defining laws for the independent finite integer Q prefix."""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_model import MODEL,VECTOR,body_files as model_body_files


def specification():
    decl=[f'(declare-const vector {VECTOR})',f'(declare-const model {MODEL})','(declare-const layer (_ BitVec 3))','(declare-const group (_ BitVec 6))','(declare-const row (_ BitVec 6))','(declare-const c (_ BitVec 10))']
    call=lambda c:'(Q-prefix vector model layer group row '+c+')'
    rules={'empty-prefix':dict(assumptions=[],conclusion=eq(call(bv(0,10)),'0')),
        'next-prefix':dict(assumptions=[f'(bvult c {bv(256,10)})'],
            conclusion=eq(call(f'(bvadd c {bv(1,10)})'),f'(+ {call("c")} (Q-product vector model layer group row c))'))}
    return decl,'; Laws use the independent define-fun-rec Q-prefix in q-model/history.smt2.\n',rules


def body_files():return model_body_files()+['q-prefix-laws/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-prefix-laws';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',*bodies]
    plan=dict(schema='Typed-Q-independent-prefix-laws-v1',component='q-prefix-laws',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-prefix-laws-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-prefix-laws-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed independent prefix laws')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Independent finite Q-prefix base and successor laws prepared.')

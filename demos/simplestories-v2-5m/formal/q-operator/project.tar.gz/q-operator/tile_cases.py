"""Exhaustive BV4 case elimination for the arbitrary-lane accumulator proof.

The other native induction rules have byte-identical canonical queries and are
reused, with their original receipts retained. No old failed rule is relabelled.
"""
import copy
import json
from arithmetic import HERE,MAC,bv,sha,write_json,compile_model
from tile import TOP
from tile_any import specification as any_specification


def specification():
    declarations,defs,old=any_specification();rules={}
    for name,rule in old.items():
        if name!='preserved-4':rules[name]=rule;continue
        names=[]
        for lane in range(16):
            key='preserved-4-lane-'+str(lane);names.append(key)
            case=copy.deepcopy(rule);case['assumptions'].append(f'(= lane {bv(lane,4)})');rules[key]=case
        joined=copy.deepcopy(rule);joined['dependencies']=names;rules[name]=joined
    return declarations,defs,rules


def prepare():
    compile_model('tile',TOP,{'cluster-tile.sv':[MAC,TOP]})
    declarations,defs,rules=specification();d=HERE/'tile-cases';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['tile/native.smt2','tile-cases/history.smt2'];paths=['tile-SOURCES.json','tile/native.sv','tile/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-exhaustive-lane-induction-v1',component='tile-cases',bodies=bodies,source_manifest='tile-SOURCES.json',native_source='tile/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='tile-cases-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'tile-cases-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed exhaustive lane plan')
    write_json(path,plan)
    # Reuse only exact canonical implications, checking both their typed source
    # context and original raw engine artifact first.
    from q_check import check
    import sys
    sys.path.insert(0,str(HERE.parent))
    from native_induction import query,validate
    oldplan=validate(HERE,'tile-any-PLAN.json');oldchecks=json.loads((HERE/'tile-any-CHECKS.json').read_text())
    oldbody='\n'.join((HERE/x).read_text()for x in oldplan['bodies'])
    body='\n'.join((HERE/x).read_text()for x in bodies)
    recordpath=HERE/plan['checks_file'];checks=json.loads(recordpath.read_text())if recordpath.exists()else{}
    identity=sha(path.read_bytes())
    if checks.get('plan_sha256')!=identity:checks=dict(plan_sha256=identity,rules={})
    for name,rule in rules.items():
        if not oldchecks['rules'].get(name,{}).get('passed') or query(oldplan,name,oldbody)!=query(plan,name,body):continue
        check('tile-any',True,[name]);row=copy.deepcopy(oldchecks['rules'][name])
        row['reused_exact_canonical_query_from']='tile-any-PLAN.json';checks['rules'][name]=row
    checks['all_rules_passed']=all(checks['rules'].get(k,{}).get('passed')for k in rules)
    checks['whole_Q_operator_proved']=False;write_json(recordpath,checks)
    print(json.dumps(dict(reused_exact_engine_implications=len(checks['rules']),new_cases=16,whole_Q_operator_proved=False)))


if __name__=='__main__':prepare()

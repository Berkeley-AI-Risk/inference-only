"""Exact application of the checked frame-function interpretation at native output.

The resulting theorem is on the captured tuple's values. Current Q dot/model,
row/generation and multiplier-domain discharge remain explicit parent joins.
"""
import json
from arithmetic import HERE,both,eq,signed,sha,write_json
from frame import TOP,S,n
from word_derivation import expected,verify


def specification():
    D='(fr-D3 h)';M='(fr-M3 h)'
    semantic=expected('frame-integer-function')['target']['conclusion'].replace('(frame-raw d m)',f'(frame-raw {D} {M})')
    # Substitute exact symbols in the remaining signed/unsigned arguments.
    from pruned_arithmetic import parse,emit
    ast=parse(expected('frame-integer-function')['target']['conclusion'])[0]
    def substitute(node):
        if isinstance(node,list):return [substitute(x)for x in node]
        if node=='d':return parse(D)[0]
        if node=='m':return parse(M)[0]
        return node
    semantic=emit(substitute(ast))
    guard=f'(= ((_ extract 15 15) {M}) #b0)'
    target=eq(signed(n('result_scaled_raw_o'),50),f'(* {signed(D,35)} (bv2int {M}))')
    assumptions=[f'(|{TOP}_h| a)',n('reset_n'),'(frame-inv a h)',n('result_valid_o'),guard,semantic]
    rules={'current-output-integer':dict(assumptions=assumptions,conclusion=target)}
    return [f'(declare-const a {S})','(declare-const h FrameHistory)'],'',rules


def prepare():
    verify('frame-integer-function')
    declarations,defs,rules=specification();d=HERE/'frame-integer';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','frame/history.smt2','frame-integer/history.smt2'];paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','frame-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-frame-integer-application-v1',component='frame-integer',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='frame-integer-CHECKS.json',
        semantic_provider='frame-integer-function',inductive_provider='frame-PLAN.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'frame-integer-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed frame integer application')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Exact derived interpretation applied to actual held output; multiplier-domain premise remains explicit.')

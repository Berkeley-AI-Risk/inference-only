"""Actual held engine output equals its completed integer accepted-input fold.

Multiplier bit15 remains an explicit caller premise, to be discharged by the
current Q metadata provider. The independent fixed-model vector identity is
also a separate application, not an assumed native arithmetic result.
"""
import json
from arithmetic import HERE,both,eq,signed,sha,write_json
from frame import TOP,S,n
from semantic_facts import fact,substitute
from sum_frame import row_matches


def implication(rule,mapping=None):
    conclusion=rule['conclusion'];assumptions=rule['assumptions']
    if mapping:
        conclusion=substitute(conclusion,mapping);assumptions=[substitute(a,mapping)for a in assumptions]
    return '(=> '+both(assumptions)+' '+conclusion+')'


def specification():
    from frame_integer import specification as frame_specification
    from math_fold_r2 import specification as math_specification
    from word_scalar import specification as scalar_specification
    _,_,frame_rules=frame_specification();_,_,math_rules=math_specification();_,_,scalar_rules=scalar_specification()
    declarations=[f'(declare-const a {S})','(declare-const pc PrefixHistory)','(declare-const th TileHistory)',
        '(declare-const mh MathHistory)','(declare-const fr FrameHistory)','(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))']
    roots=[f'(|{TOP}_h| a)',n('reset_n'),'(prefix-inv a pc)','(lineage-inv a pc th lane tile)',
        '(sumframe-inv a th fr lane tile)','(math-inv a pc th mh)','(frame-inv a fr)',n('result_valid_o'),row_matches(3),
        '(= ((_ extract 15 15) (fr-M3 fr)) #b0)']
    imports=[fact('frame-integer-function',{'d':'(fr-D3 fr)','m':'(fr-M3 fr)'}),
        implication(frame_rules['current-output-integer'],{'h':'fr'}),implication(math_rules['current-sum-fits35']),
        implication(scalar_rules['signed-low35-preserves-bounded-value'],{'w':'(th-sum th)'})]
    goal=both([eq(signed(n('result_scaled_raw_o'),50),'(* (mh-S mh) (bv2int (fr-M3 fr)))'),
        eq('(pc-acc pc)',n('columns_q')),'(th-owned th)'])
    return declarations,'',{'completed-integer-fold-at-output':dict(assumptions=roots+imports,conclusion=goal)}


def prepare():
    declarations,defs,rules=specification();d=HERE/'engine-integer';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2','sum-frame/history.smt2','math-fold-r2/history.smt2','engine-integer/history.smt2']
    providers=['prefix-r2','tile-held','frame','lineage','sum-frame','math-fold-r2','frame-integer','word-scalar']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json',*[p+'-PLAN.json'for p in providers],*bodies]
    plan=dict(schema='Typed-Q-engine-integer-composition-v1',component='engine-integer',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='engine-integer-CHECKS.json',
        providers=providers,semantic_provider='frame-integer-function',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'engine-integer-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed integer engine composition')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual live output/int-fold application frozen with explicit multiplier guard and closed numeric providers.')

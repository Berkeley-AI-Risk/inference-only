"""Compose actual normalization with the immutable qualified parent model.

All ten former normalizer outputs are bound to the native module. Existing
normalizer control inputs and clock/reset are bound unconditionally. Four
payload inputs and job are bound at actual Q VALID/start events; other-stage
payloads remain arbitrary, a deliberate stronger abstraction. No expected
raw/rounded result is supplied. The old parent need not be recompiled.
"""
import json,re,sys
from arithmetic import HERE,OPERANDS,bv,both,eq,sha,write_json
from lanes import TOP,S,n,verify_sources
from selector import TOP as NORM,S as NS

DP='u_native.u_six_layers.u_datapath.'
nn=lambda field,z='z':f'(|{NORM}_n {field}| {z})'
dn=lambda field,a='a':n(DP+field,a)
OUTPUTS={'start_ready_o':'norm_start_ready','input_ready_o':'norm_input_ready','result_valid_o':'norm_result_valid',
    'result_row_index_o':'norm_result_index','result_mantissa_o':'norm_result_mantissa','result_exponent_o':'norm_result_exponent','result_last_o':'norm_result_last',
    'done_valid_o':'norm_done_valid','busy_o':'norm_busy','range_fault_o':'norm_fault'}
CONTROLS={'clk':'clk','rst_n':'rst_n','clear_i':'clear_i','model_lock_i':'model_lock_i','start_valid_i':'norm_start_valid',
    'fixed_layer_i':'current_layer_q','input_valid_i':'norm_input_valid','result_ready_i':'norm_result_ready','done_ready_i':'norm_done_ready'}


def source_binding():
    verify_sources()
    sys.path.insert(0,str(OPERANDS))
    from build_semantic_window import NATIVE,verify_source
    verify_source();source=(NATIVE/'production-datapath.sv').read_text()
    matches=re.findall(r'^    board1_fixed_vector_normalizer\b[\s\S]*?^    \);',source,re.M)
    if len(matches)!=1:raise ValueError('Unique actual normalizer instance required')
    instance=matches[0]
    ports=dict(re.findall(r'\.(\w+)\(([^()]*)\)',instance))
    ports={k:re.sub(r'\s+','',v)for k,v in ports.items()}
    expected={**CONTROLS,'upstream_fault_i':'upstream_fault_i||fault_q','fixed_job_i':'norm_job',
        'input_row_index_i':'norm_input_index','input_raw_i':'norm_input_raw','input_source_exponent_i':'norm_input_exponent','input_last_i':'norm_input_last',**OUTPUTS}
    if ports!=expected:raise ValueError('Actual normalizer port mapping changed')
    inputs=json.loads((NATIVE/'INPUTS.json').read_text());cuts=[r for r in inputs['internal_cuts']if r['instance']=='u_normalizer']
    if len(cuts)!=10 or {r['port']:r['expression']for r in cuts}!=OUTPUTS or any(r['assumptions']for r in cuts):raise ValueError('Changed normalizer cut coverage')
    abstract=(OPERANDS/'connected/datapath.sv').read_text()
    assignments='\n'.join('    assign '+r['expression']+'='+r['replacement']+';'for r in cuts)
    if abstract.count(assignments)!=1:raise ValueError('Changed exact normalizer output abstraction')
    root=(OPERANDS/'connected/native.smt2').read_text();normal=(HERE/'selector/native.smt2').read_text()
    for field in [*CONTROLS.values(),'upstream_fault_i','fault_q','current_stage_q','engine_state_q','projection_result_index','projection_result_raw','projection_result_exponent','projection_result_last']:
        if f'|{TOP}_n {DP+field}|'not in root:raise ValueError('Missing actual parent getter '+field)
    for port in OUTPUTS:
        if f'|{TOP}_n f_dp_f_child_u_normalizer_{port}|'not in root or f'|{NORM}_n {port}|'not in normal:raise ValueError('Missing actual output port alias '+port)
    # These exact ordinary Q-path assignments provide the conditional payload
    # map. The surrounding if/case scope is pinned by the entire source hash.
    required=['norm_job = projection_job;', 'projection_result_ready = norm_input_ready;',
        'norm_input_valid = projection_result_valid;', 'norm_input_index = projection_result_index[9:0];',
        'norm_input_raw = projection_result_raw;', 'norm_input_exponent = projection_result_exponent;', 'norm_input_last = projection_result_last;']
    for line in required:
        if source.count(line)!=1:raise ValueError('Changed exact Q-path normalizer assignment '+line)
    return dict(schema='Native-normalizer-parent-product-binding-v1',original_instance=instance,ports=ports,parameters={},
        source=str(NATIVE/'production-datapath.sv'),source_sha256=sha(source.encode()),old_abstract_parent_sha256=sha(abstract.encode()),
        output_cuts_closed=cuts,unconditional_controls=CONTROLS,conditional_Q_payload_assignments=required,
        other_stage_payloads='Arbitrary inputs, not correct-value assumptions; actual source is a permitted specialization',
        no_expected_arithmetic_reply=True,common_clock='clk',reset='Actual datapath rst_n, including common parent reset',
        native_normalizer='selector/native.smt2',old_parent_recompiled=False,
        remaining_unrestricted_whole_numerical_leaves=18,whole_Q_operator_proved=False)


def definitions():
    qmode=both([eq(dn('engine_state_q'),bv(2,4)),eq(dn('current_stage_q'),bv(1,5))])
    defs=f'(define-fun qn-Q-mode ((a {S})) Bool {qmode})\n'
    bindings=[eq(nn(k),dn(v))for k,v in CONTROLS.items()]
    bindings.append(eq(nn('upstream_fault_i'),'(or '+dn('upstream_fault_i')+' '+dn('fault_q')+')'))
    bindings.extend(eq(nn(port),n('f_dp_f_child_u_normalizer_'+port))for port in OUTPUTS)
    payload=[eq(nn('input_row_index_i'),'((_ extract 9 0) '+dn('projection_result_index')+')'),eq(nn('input_raw_i'),dn('projection_result_raw')),
        eq(nn('input_source_exponent_i'),dn('projection_result_exponent')),eq(nn('input_last_i'),dn('projection_result_last'))]
    bindings.extend([f'(=> (and (qn-Q-mode a) {dn("norm_input_valid")}) {both(payload)})',
        f'(=> (and (qn-Q-mode a) {dn("norm_start_valid")}) (= {nn("fixed_job_i")} {bv(0,4)}))'])
    defs+=f'(define-fun qn-bind ((a {S}) (z {NS})) Bool '+both(bindings)+')\n'
    defs+=f'(define-fun qn-native-step ((a {S}) (an {S}) (z {NS}) (zn {NS})) Bool '+both([f'(|{TOP}_t| a an)',f'(|{NORM}_t| z zn)','(qn-bind a z)','(qn-bind an zn)'])+')\n'
    return defs


def specification():
    decl=[f'(declare-const a {S})',f'(declare-const an {S})',f'(declare-const z {NS})',f'(declare-const zn {NS})']
    H=[f'(|{TOP}_h| a)',f'(|{NORM}_h| z)','(qn-bind a z)']
    rules={
        'common-reset-reaches-normalizer':dict(assumptions=H+[f'(not {n("reset_n")})'],conclusion=f'(not {nn("rst_n")})'),
        'product-retains-old-parent-and-native-normalizer':dict(assumptions=['(qn-native-step a an z zn)'],conclusion=both([f'(|{TOP}_t| a an)',f'(|{NORM}_t| z zn)'])),
        'Q-start-descriptor':dict(assumptions=H+['(qn-Q-mode a)',nn('start_valid_i'),nn('start_ready_o')],conclusion=both([eq(nn('fixed_job_i'),bv(0,4)),eq(nn('fixed_layer_i'),dn('current_layer_q'))])),
        'accepted-Q-raw-is-actual-projection':dict(assumptions=H+['(qn-Q-mode a)',nn('input_valid_i'),nn('input_ready_o')],
            conclusion=both([dn('projection_result_valid'),dn('projection_result_ready'),*[
                eq(nn('input_row_index_i'),'((_ extract 9 0) '+dn('projection_result_index')+')'),eq(nn('input_raw_i'),dn('projection_result_raw')),
                eq(nn('input_source_exponent_i'),dn('projection_result_exponent')),eq(nn('input_last_i'),dn('projection_result_last'))]]))}
    return decl,definitions(),rules


def prepare():
    decl,defs,rules=specification();d=HERE/'q-normalizer-product';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs);write_json(d/'SOURCE-BINDING.json',source_binding())
    bodies=['../model-consumption/connected/native.smt2','selector/native.smt2','q-normalizer-product/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv','q-normalizer-product/SOURCE-BINDING.json',*bodies]
    plan=dict(schema='Typed-Q-native-normalizer-product-v1',component='q-normalizer-product',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-normalizer-product-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-normalizer-product-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed actual normalizer product')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Native normalizer product and all-ten-output closure prepared without recompiling the qualified parent.')

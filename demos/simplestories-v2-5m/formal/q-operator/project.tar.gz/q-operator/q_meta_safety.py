"""Exact metadata-legality source/history specialization in the actual parent."""
import json
from arithmetic import HERE,sha,write_json
from q_engine import translate,binding,verify as engine_verify
from meta_safety_r2 import specification


def definitions():return translate(specification()[1])


def record():
    from q_check import check
    check('meta-safety-r2',True);parent=engine_verify()
    return dict(schema='Native-parent-metadata-legality-specialization-v1',engine_instance=parent['path'],
        source_instance_binding_sha256=sha((HERE/'q-engine/INSTANCE-BINDING.json').read_bytes()),
        component_plan='meta-safety-r2-PLAN.json',component_plan_sha256=sha((HERE/'meta-safety-r2-PLAN.json').read_bytes()),
        component_checks=12,parameters={},history='Same accepted-read mr-next and same actual FrameHistory/frame-next at common engine clock',
        memory_mapping='Each of four native tile multiplier RAMs uses the exact mapped parent array getter and matching BV4→BV16 sort',
        application='Universal identical-source metadata legality contract in the exact already-checked engine subtree',
        whole_Q_operator_proved=False)


def prepare():
    d=HERE/'q-meta-safety';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(definitions());write_json(d/'INSTANCE-BINDING.json',record())


if __name__=='__main__':prepare();print('Native uint15 multiplier guard and functional metadata-read history specialized to actual parent.')

"""Main baseline-Q value endpoints over the actual source-bound product.

Component-history predicates here are discharged by the checked reset/step
composition, not assumptions that an environment supplies correct arithmetic.
This main file includes held normalization, actual write/data/address, actual
exponent-register update, successful completion, and cancellation endpoints.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import S
from q_model import MODEL
from q_normalizer_product import NS,nn,dn
from q_exponent import ES
from q_output_ownership_r3 import specification as output_spec
from q_done_certificate import body_files as done_files


def current():
    result=output_spec()[2]['actual-Q-write-current-ordered-normalizer-output']['assumptions']
    result=list(result);result.remove('(Q-write-admission a z)')
    return result+['(qcert-inv a z qa nc watch model)','(qd-source-inv a qa nc na h)',
        '(qdone-inv a qa nc h watch model)',f'(bvult watch {bv(256,10)})']


def step():
    result=list(output_spec()[2]['actual-Q-exponent-update']['assumptions'])
    event='(Q-exponent-update a z)'
    if result.count(event)!=1:raise ValueError('Changed exact exponent observation guard')
    result.remove(event)
    return result+['(qcert-inv a z qa nc watch model)',f'(bvult watch {bv(256,10)})']


def raw_reference():return '(Q-record-matches qa model watch (select (nc-vec nc) watch))'


def normalized_tuple():
    return both(['(qa-owned qa)','(qa-complete qa)',eq('(qh-layer h)','(qa-layer qa)'),eq('(qh-epoch h)','(qa-epoch qa)'),
        eq('(nc-count nc)',bv(256,10)),eq('(nc-rows nc)',bv(256,10)),eq('(na-rows na)',bv(256,10)),
        eq('(na-phase na)',bv(5,3)),eq(nn('result_row_index_o'),'(na-scan na)'),
        eq(nn('result_mantissa_o'),'(na-mantissa na)'),eq(nn('result_exponent_o'),'(na-candidate na)'),
        eq(nn('result_last_o'),'(na-last na)'),eq(nn('result_row_index_o'),'(na-emitted na)'),
        f'(bvult {nn("result_row_index_o")} {bv(256,10)})',
        f'(bvsge (na-candidate na) {bv(-32,8)})',f'(bvsle (na-candidate na) {bv(31,8)})',raw_reference()])


def definitions():
    # These functions denote the actual source port expressions checked in
    # q-output-ownership-r3/SOURCE-BINDING.json, not retained RAM contents.
    return f'(define-fun Q-source-write-address ((a {S})) (_ BitVec 8) ((_ extract 7 0) {dn("output_index_q")}))\n'+\
        f'(define-fun Q-source-write-data ((a {S})) (_ BitVec 16) {dn("norm_result_mantissa")})\n'


def specification():
    decl=output_spec()[0]+['(declare-const watch (_ BitVec 10))',f'(declare-const model {MODEL})']
    held=current()+['(qn-Q-mode a)',nn('result_valid_o')]
    writes=current()+['(Q-write-admission a z)']
    writegoal=both([normalized_tuple(),eq('(Q-source-write-address a)','((_ extract 7 0) '+nn('result_row_index_o')+')'),
        eq('(Q-source-write-data a)','(na-mantissa na)'),eq('(qh-count h)',nn('result_row_index_o')),
        eq(nn('result_last_o'),eq('(qh-count h)',bv(255,10)))])
    done=current()+[dn('rst_n'),dn('stage_done_q'),eq(dn('current_stage_q'),bv(1,5))]
    donegoal=both(['(qh-owned h)','(qh-Ndone h)','(qh-Pdone h)',eq('(qh-count h)',bv(256,10)),
        '(qa-owned qa)','(qa-complete qa)',eq('(qh-layer h)','(qa-layer qa)'),eq('(qh-epoch h)','(qa-epoch qa)'),
        eq('(nc-count nc)',bv(256,10)),eq('(nc-rows nc)',bv(256,10)),eq('(na-rows na)',bv(256,10)),
        eq('(na-emitted na)',bv(256,10)),eq('(qe-value e)','(na-candidate na)'),raw_reference()])
    cleared=both(['(not (qh-owned hn))','(not (qh-Ndone hn))','(not (qh-Pdone hn))','(not (qa-owned qan))',
        eq('(nc-count ncn)',bv(0,10)),eq('(na-emitted nan)',bv(0,10)),
        eq('(qe-value een)',f'(ite {dn("rst_n","an")} (qe-value e) {bv(0,8)})')])
    rules={
        'held-normalized-Q-value':dict(assumptions=held,conclusion=normalized_tuple()),
        'transferred-normalized-Q-value':dict(assumptions=held+[nn('result_ready_i')],conclusion=normalized_tuple()),
        'actual-Q-write-value-address-and-order':dict(assumptions=writes,conclusion=writegoal),
        'actual-Q-exponent-register-value-or-reset':dict(assumptions=step()+['(Q-exponent-update a z)'],
            conclusion=both([eq('(qe-value een)',f'(ite {dn("rst_n","an")} (na-candidate na) {bv(0,8)})'),raw_reference()])),
        'Q-stage-DONE-full-current-reference-and-writes':dict(assumptions=done,conclusion=donegoal),
        'CLEAR-revokes-current-operator-authority':dict(assumptions=step()+[dn('clear_i')],conclusion=cleared),
        'nonzero-write-compatible-context':dict(assumptions=writes+[f'(distinct {nn("result_mantissa_o")} {bv(0,16)})'],conclusion='false',expected='sat'),
        'CLEAR-nonzero-exponent-compatible-context':dict(assumptions=step()+[dn('clear_i'),dn('rst_n'),dn('rst_n','an'),
            f'(distinct (qe-value e) {bv(0,8)})'],conclusion='false',expected='sat')}
    return decl,definitions(),rules


def body_files():return done_files()+['q-main/history.smt2']


PROVIDERS=['q-certificate','q-done-certificate','q-done-support','q-output-ownership-r3','norm-algorithm-r2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-main';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-main-source-bound-value-endpoints-v1',component='q-main',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-main-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False,
        positive_context_scope='Compatibility with the complete current invariant context; not reachability from reset',
        retained_query_RAM_claimed=False)
    path=HERE/'q-main-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed main baseline Q endpoint theorem')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Main source-bound Q numerical/effect endpoint queries prepared; whole-device theorem excluded.')

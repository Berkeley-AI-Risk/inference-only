"""Native normalization qualification against an independent integer algorithm.

Inputs are finite test fixtures, not a formal raw-producer provider.
No internal state is driven. The actual default watchdog is retained.
"""
import json
import subprocess
from arithmetic import HERE,native_source,sha,write_json
from reference import image,q,normalize

BENCH=r'''
module tb;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,clear=0,start=0,iv=0,il=0;
 reg[9:0]ir=0;reg signed[49:0]raw=0;reg signed[7:0]ex=0;
 wire sr,ready,rv,done,fault;wire[9:0]rr;wire signed[15:0]m;wire signed[7:0]e;wire last;
 integer cycle=0,which=0,count=0,expected_count=0,success=0,i;
 reg[57:0]records[0:255];reg[34:0]expected[0:255];
 wire output_ready=cycle%7!=2 && cycle%7!=3;
 board1_fixed_vector_normalizer dut(
  .clk(clk),.rst_n(rst_n),.clear_i(clear),.model_lock_i(1'b1),.upstream_fault_i(1'b0),
  .start_valid_i(start),.start_ready_o(sr),.fixed_layer_i(3'd0),.fixed_job_i(4'd0),
  .input_valid_i(iv),.input_ready_o(ready),.input_row_index_i(ir),.input_raw_i(raw),.input_source_exponent_i(ex),.input_last_i(il),
  .result_valid_o(rv),.result_ready_i(output_ready),.result_row_index_o(rr),.result_mantissa_o(m),.result_exponent_o(e),.result_last_o(last),
  .done_valid_o(done),.done_ready_i(1'b1),.busy_o(),.range_fault_o(fault));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(cycle>500000)$fatal(1,"fixture timeout");
  if(rst_n&&!clear&&rv)begin
   if(count>=expected_count || {rr,m,e,last}!==expected[count])
    $fatal(1,"normalized result mismatch case=%0d row=%0d count=%0d got=%h expected=%h",which,rr,count,{rr,m,e,last},expected[count]);
   if(output_ready)count=count+1;
  end
 end
 task automatic run_case(input integer number,input integer rows,input integer ok);
  begin
   @(negedge clk);clear=1;iv=0;start=0;
   @(negedge clk);clear=0;which=number;count=0;expected_count=rows;success=ok;
   $readmemh($sformatf("case%0d-input.memh",number),records);
   if(rows>0)$readmemh($sformatf("case%0d-expected.memh",number),expected,0,rows-1);
   while(!sr)@(negedge clk);
   start=1;@(negedge clk);start=0;
   for(i=0;i<256;i=i+1)begin
    ir=i;raw=records[i][49:0];ex=records[i][57:50];il=i==255;iv=1;
    @(posedge clk);while(!ready)@(posedge clk);
    @(negedge clk);iv=0;
    if(i%13==0)@(negedge clk);
   end
   while(!done&&!fault)@(negedge clk);
   if(count!=rows || done!==ok || fault===ok)
    $fatal(1,"normalizer outcome mismatch case=%0d rows=%0d expected=%0d done=%0d fault=%0d",number,count,rows,done,fault);
   $display("CASE %0d PASS rows=%0d success=%0d",number,count,ok);
   @(negedge clk);
  end
 endtask
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  // CASE_CALLS
  $display("PASS: native normalizer prefix/value/outcome, stalls and CLEAR without hard reset");$finish;
 end
endmodule
'''


def main():
    d=HERE/'normalizer-operating-r1';d.mkdir(exist_ok=False)
    raw=image();cases=[]
    cases.append(('zero-success',q(raw,0,[0]*256,-10)))
    cases.append(('zero-prefix-reject-e89',q(raw,0,[0]*256,89)))
    for layer in range(6):
        A=[((c*7+(layer+3)*5)%63)-31 for c in range(256)]
        cases.append(('Q-layer%d'%layer,q(raw,layer,A,-10)))
    cases += [('RNE-fit-carry',[(65535,-1)]*256),
        ('right-tail-zero',[(17,-128)]*256),
        ('left-tail-reject',[(1,127)]*256),
        ('mixed-sign-ties',[(32767 if i%2==0 else -32767,0)for i in range(256)])]
    selection={'normalizer_pipeline.sv':['board1_fixed_vector_normalizer'],'candidate.sv':['board1_fixed_vector_rne_shift_pipeline1']}
    source,sources=native_source(selection)
    (d/'native.sv').write_text(source)
    calls=[];rows=[]
    for i,(name,records)in enumerate(cases):
        prefix,outcome=normalize(records)
        if name=='zero-prefix-reject-e89'and(len(prefix)!=17 or outcome.get('row')!=17):raise ValueError('Independent zero example changed')
        (d/('case%d-input.memh'%i)).write_text(''.join('%015x\n'%(((e&255)<<50)|(r&((1<<50)-1)))for r,e in records))
        (d/('case%d-expected.memh'%i)).write_text(''.join('%09x\n'%((r<<25)|((m&65535)<<9)|((e&255)<<1)|last)for r,m,e,last in prefix))
        calls.append('  run_case(%d,%d,%d);'%(i,len(prefix),outcome['success']))
        rows.append(dict(name=name,expected_rows=len(prefix),outcome=outcome))
    bench=BENCH.replace('  // CASE_CALLS','\n'.join(calls));(d/'tb.sv').write_text(bench)
    with (d/'compile.log').open('w')as f:
        cp=subprocess.run(['iverilog','-g2012','-s','tb','-o','sim','native.sv','tb.sv'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    if cp.returncode:raise ValueError('Normalizer fixture compile failed')
    with (d/'simulation.log').open('w')as f:
        cp=subprocess.run(['vvp','sim'],cwd=d,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    log=(d/'simulation.log').read_bytes()
    result=dict(passed=cp.returncode==0 and b'PASS: native normalizer'in log,cases=rows,sources=sources,
        native_sha256=sha(source.encode()),bench_sha256=sha(bench.encode()),reference_sha256=sha((HERE/'reference.py').read_bytes()),
        model_image_sha256=sha(raw),log_sha256=sha(log),exit_code=cp.returncode,
        finite_operating_evidence=True,raw_rows_provider='independent finite test data, not formal producer composition',
        default_watchdog=2000000,whole_Q_operator_proved=False,whole_machine_theorem=False)
    write_json(d/'RESULT.json',result);print(log.decode());print(json.dumps(dict(passed=result['passed'],cases=len(cases))))
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()

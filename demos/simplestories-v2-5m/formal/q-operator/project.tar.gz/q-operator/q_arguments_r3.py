"""Prove capture phase coherence; exclude retained unowned fault counts.

R2 allowed completed arguments during P LOAD and interpreted old N count after
descriptor rejection as a current vector. R3 proves completion excludes LOAD,
and scopes current-vector ownership to actual active native N phases.
"""
import json
from arithmetic import HERE,sha,write_json
from q_arguments import specification as original
from q_arguments_r2 import body_files as previous_files,PROVIDERS


def specification():return original(revision=2)


def body_files():return [x.replace('q-arguments-r2/history.smt2','q-arguments-r3/history.smt2')for x in previous_files()]


def prepare():
    decl,defs,rules=specification();d=HERE/'q-arguments-r3';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv',
        '../model-consumption/parentcapture-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-persistent-accepted-argument-snapshot-r3-v1',component='q-arguments-r3',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-arguments-r3-CHECKS.json',
        providers=PROVIDERS,old_providers=['parentcapture'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-arguments-r3-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed persistent argument phase ownership')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Completed-vector phase coherence and active normalizer authority prepared.')

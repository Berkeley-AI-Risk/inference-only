; Source-defined qc-live and actual reset/VALID aliases.

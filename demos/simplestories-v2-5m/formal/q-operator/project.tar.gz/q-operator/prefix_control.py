"""Accepted-column/accumulation ordering in the unchanged clustered engine.

Counts observe only actual accept/multiply/accumulate events. No arithmetic
value, coefficient or desired dot is assumed. This is a component control proof.
"""
import json
from arithmetic import HERE,MAC,MUL,bv,both,eq,sha,write_json,compile_model

TOP='board1_clustered_projection_scale2';S='|'+TOP+'_s|'
n=lambda field,state='a':f'(|{TOP}_n {field}| {state})'
T='g_tile[0].u_tile.'


def transition():
    source=(HERE/'prefix/native.smt2').read_text()
    start=source.index('(define-fun |'+TOP+'_t|');end=source.index(')) ; end of module '+TOP,start)+2
    lines=source[start:end].splitlines();kept=[];dropped=[]
    for line in lines[1:]:
        comment=line.split(';',1)[1].strip()if';'in line else''
        if 'g_tile['in comment and'.g_lane['in comment and'.u_mac.'in comment:
            formula=line.split(';',1)[0].strip()
            if not formula.startswith('(= ')or formula.count('(')!=formula.count(')'):raise ValueError('Unsupported native arithmetic conjunct')
            dropped.append(line)
        else:kept.append(line)
    if len(dropped)!=128:raise ValueError('Wrong arithmetic-weakening coverage')
    text='\n'.join([lines[0].replace('|'+TOP+'_t|','prefix-native-step'),*kept])+'\n'
    return text,dict(omitted_conjuncts=dropped,omitted_count=128,rule='Literal conjunction weakening; engine checks full native T implication',arithmetic_result_claim=False)


def definitions(extra_clauses=None):
    defs='(declare-datatypes () ((PrefixHistory (prefix-history (pc-cap (_ BitVec 10)) (pc-acc (_ BitVec 10)) (pc-opcol (_ BitVec 10)) (pc-pcol (_ BitVec 10))))))\n'
    zero='(prefix-history '+ ' '.join([bv(0,10)]*4)+')'
    defs+='(define-fun prefix-zero () PrefixHistory '+zero+')\n'
    revoke=f'(or (not {n("reset_n")}) {n("kill")} {n(T+"begin_i")})'
    inc=lambda event:f'(ite {event} {bv(1,10)} {bv(0,10)})'
    op=n(T+'op_valid_q');p=n(T+'product_valid_q');accept=n('weight_fire')
    values=[f'(bvadd (pc-cap h) {inc(accept)})',f'(bvadd (pc-acc h) {inc(p)})',
        f'(ite {accept} {n("column_q")} (pc-opcol h))',f'(ite {op} (pc-opcol h) (pc-pcol h))']
    defs+=f'(define-fun prefix-next ((a {S}) (h PrefixHistory)) PrefixHistory (ite {revoke} prefix-zero (prefix-history '+ ' '.join(values)+')))\n'
    cap='(pc-cap h)';acc='(pc-acc h)';oc='(pc-opcol h)';pc='(pc-pcol h)';cols=n('columns_q')
    phase=lambda *states:'(or '+' '.join(eq(n('state_q'),bv(i,3))for i in states)+')'
    full=both([eq(cap,cols),eq(acc,cols),f'(not {op})',f'(not {p})',f'(distinct {cols} {bv(0,10)})'])
    clauses=[
        '(or '+ ' '.join(eq(cols,bv(v,10))for v in [0,256,682])+')',
        f'(bvule {cap} {cols})',f'(bvule {acc} {cap})',
        eq(cap,f'(bvadd (bvadd {acc} {inc(op)}) {inc(p)})'),
        f'(=> {op} '+both([eq(oc,f'(bvsub {cap} {bv(1,10)})'),f'(bvult {oc} {cols})',
            eq(n(T+'op_first_q'),eq(oc,bv(0,10))),eq(n(T+'op_last_q'),eq(oc,f'(bvsub {cols} {bv(1,10)})'))])+')',
        f'(=> {p} '+both([eq(pc,acc),f'(bvult {pc} {cols})',eq(n(T+'product_first_q'),eq(pc,bv(0,10))),
            eq(n(T+'product_last_q'),eq(pc,f'(bvsub {cols} {bv(1,10)})'))])+')',
        f'(=> {phase(1)} (= {cap} {bv(0,10)}))',
        f'(=> (and {phase(2)} (not {n("kill")})) '+both([eq(cap,n('column_q')),f'(bvult {cap} {cols})'])+')',
        f'(=> {phase(3,4,5)} (= {cap} {cols}))',
        f'(=> {n(T+"done_o")} (= {acc} {cols}))',
        f'(=> {phase(4,5)} {full})',
        both([eq(n(f'g_tile[{t}].u_tile.'+field),n(T+field))for t in range(1,4)for field in ['op_valid_q','product_valid_q','op_first_q','op_last_q','product_first_q','product_last_q','done_o']]),
    ]+(extra_clauses or [])
    for i,clause in enumerate(clauses):defs+=f'(define-fun prefix-clause-{i} ((a {S}) (h PrefixHistory)) Bool (=> {n("reset_n")} {clause}))\n'
    defs+=f'(define-fun prefix-inv ((a {S}) (h PrefixHistory)) Bool '+both([f'(prefix-clause-{i} a h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification(extra_clauses=None):
    defs,clauses=definitions(extra_clauses);H=lambda state:f'(|{TOP}_h| {state})';N=f'(|{TOP}_t| a an)'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h PrefixHistory)','(declare-const hn PrefixHistory)']
    context=[H('a'),H('an')];step=context+['(prefix-native-step a an)','(prefix-inv a h)','(= hn (prefix-next a h))']
    parts=[f'(prefix-clause-{i} an hn)'for i in range(len(clauses))]
    complete=both([eq('(pc-cap h)',n('columns_q')),eq('(pc-acc h)',n('columns_q')),
        '(not '+n(T+'op_valid_q')+')','(not '+n(T+'product_valid_q')+')'])
    rules={'native-step-weakening':dict(assumptions=context+[N],conclusion='(prefix-native-step a an)'),
        'reset-base':dict(assumptions=context+[N,'(not '+n('reset_n')+')'],conclusion='(prefix-inv an prefix-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(prefix-inv an hn)'),
        'consequence':dict(assumptions=[H('a'),n('reset_n'),'(prefix-inv a h)'],conclusion=both([
            f'(=> {n("result_valid_o")} {complete})',f'(=> {n("done_valid_o")} {complete})',
            f'(=> {n(T+"product_valid_q")} '+both([eq('(pc-pcol h)','(pc-acc h)'),eq(n(T+'product_first_q'),eq('(pc-pcol h)',bv(0,10)))])+')']))}
    return declarations,defs,rules


def prepare():
    selection={'cluster-engine.sv':[TOP],'cluster-tile.sv':[MAC,MUL,'board1_projection_tile16']}
    compile_model('prefix',TOP,selection)
    weak,manifest=transition();(HERE/'prefix/control-step.smt2').write_text(weak);write_json(HERE/'prefix/CONTROL-STEP.json',manifest)
    declarations,defs,rules=specification();(HERE/'prefix/history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix/history.smt2'];paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json',*bodies]
    plan=dict(schema='Typed-Q-engine-prefix-control-v1',component='prefix',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='prefix-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'prefix-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed prefix control plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Frozen actual clustered-engine accepted-prefix control induction; no arithmetic result assumed.')

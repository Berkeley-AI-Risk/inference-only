
module tb;
 integer head=0,tail=0,debt=0,cycle=0,requests=0,responses=0;
 reg active=0,expect_mac=0,expect_read=0;
 integer generation=0,current_layer=0,captures=0,groups=0,current_group=0,meta_count=0;
 reg clk=0;always #5 clk=~clk;
 reg reset_n=0,clear_i=0,start=0,av=0,last=0;
 reg[2:0]layer=0;reg signed[15:0]activation=0;
 wire sr,ar,req,rr,done,fail;wire[18:0]address;wire[255:0]data;
 wire qv,qr,ql;wire[12:0]qi;wire signed[49:0]qraw;wire signed[7:0]qe;
 wire nsr,nv,nd,nf,nl;wire[9:0]ni;wire signed[15:0]nm;wire signed[7:0]ne;
 wire nr=cycle%5!=0;
 reg job_seen=0,norm_seen=0;
 reg[57:0]raw_expected[0:1535];reg[34:0]norm_expected[0:1535];
 integer raw_count=0,norm_count=0;
 board1_fixed_vector_normalizer normalizer(
  .clk(clk),.rst_n(reset_n),.clear_i(clear_i),.model_lock_i(1'b1),.upstream_fault_i(1'b0),
  .start_valid_i(start),.start_ready_o(nsr),.fixed_layer_i(layer),.fixed_job_i(4'd0),
  .input_valid_i(qv),.input_ready_o(qr),.input_row_index_i(qi[9:0]),.input_raw_i(qraw),.input_source_exponent_i(qe),.input_last_i(ql),
  .result_valid_o(nv),.result_ready_i(nr),.result_row_index_o(ni),.result_mantissa_o(nm),.result_exponent_o(ne),.result_last_o(nl),
  .done_valid_o(nd),.done_ready_i(1'b1),.busy_o(),.range_fault_o(nf));
 always @(posedge clk)begin
  if(!reset_n||clear_i||start)begin job_seen<=0;norm_seen<=0;raw_count=0;norm_count=0;end
  else if(active)begin
   if(done)job_seen<=1;
   if(nd)norm_seen<=1;
   if(nf)$fatal(1,"unexpected normalization fault");
   if(qv)begin
    if(raw_count>=256 || qi!==raw_count || ql!==(raw_count==255) || {qe,qraw}!==raw_expected[current_layer*256+raw_count])
     $fatal(1,"raw arithmetic mismatch L=%0d row=%0d",current_layer,raw_count);
    if(qr)raw_count=raw_count+1;
   end
   if(nv)begin
    if(norm_count>=256 || {ni,nm,ne,nl}!==norm_expected[current_layer*256+norm_count])
     $fatal(1,"normalized arithmetic mismatch L=%0d row=%0d",current_layer,norm_count);
    if(nr)norm_count=norm_count+1;
   end
  end
 end
 reg[255:0]model[0:227061];reg[18:0]pending[0:4095];
 wire reqready=debt<64 && cycle%7!=2;
 wire rspvalid=debt!=0 && cycle%3!=1;
 assign data=model[pending[head]];
 wire push=req&&reqready,pop=rspvalid&&rr;
 board1_fixed_group_projection_scale_job #(.ADDR_W(19)) dut(
  .clk(clk),.reset_n(reset_n),.clear_i(clear_i),.model_locked_i(1'b1),.upstream_fail_closed_i(1'b0),
  .start_valid_i(start),.start_ready_o(sr),.fixed_layer_i(layer),.fixed_job_i(4'd0),.activation_exponent_i(-8'sd10),
  .activation_valid_i(av),.activation_ready_o(ar),.activation_i(activation),.activation_last_i(last),
  .private_word_req_valid_o(req),.private_word_req_ready_i(reqready),.private_word_req_index_o(address),
  .private_word_rsp_valid_i(rspvalid),.private_word_rsp_ready_o(rr),.private_word_rsp_data_i(data),.private_word_rsp_fault_i(1'b0),
  .result_valid_o(qv),.result_ready_i(qr),.result_row_index_o(qi),.result_scaled_raw_o(qraw),.result_source_exponent_o(qe),.result_last_o(ql),
  .done_valid_o(done),.done_ready_i(1'b1),.busy_o(),.fail_closed_o(fail));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(!reset_n)begin head<=0;tail<=0;debt<=0;end
  else begin
   if(push)begin
    if(address>=227062)$fatal(1,"address out of model");
    pending[tail]<=address;tail<=(tail+1)%4096;requests<=requests+1;
   end
   if(pop)begin head<=(head+1)%4096;responses<=responses+1;end
   case({push,pop})2'b10:debt<=debt+1;2'b01:debt<=debt-1;endcase
   if(fail)$fatal(1,"unexpected native failure cycle=%0d",cycle);
  end
  if(cycle>150000)$fatal(1,"operating timeout");
 end
 function automatic signed[15:0]argument(input integer c,input integer generation);
  argument=0;
 endfunction
 function automatic[9:0]coefficient(input integer L,g,c,l);
  integer bit_at,word_at,offset;reg[511:0]pair;
  begin
   bit_at=L*914560*8+10*((g*256+c)*64+l);word_at=bit_at/256;offset=bit_at%256;
   pair={model[word_at+1],model[word_at]};coefficient=(pair>>offset);
  end
 endfunction
 function automatic[31:0]metadata(input integer L,g,l);
  integer at;begin at=211920+304*L+8*g+l/8;metadata=model[at]>>((l%8)*32);end
 endfunction
 integer full_runs=0,mac_pairs=0,metadata_records=0;
 reg[639:0]expected_weights;
 reg signed[15:0]expected_activation;
 reg[15:0]expected_mult[0:3];reg signed[7:0]expected_exp[0:3];
 integer k,t;reg[31:0]record;integer exp_sum;
 wire capture=dut.u_shared_engine.u_engine.weight_fire;
 wire meta_fire=dut.u_shared_engine.u_engine.metadata_fire;
 wire issue=dut.u_shared_engine.u_engine.issue;
 always @(posedge clk)begin
  if(!reset_n||clear_i)begin expect_mac<=0;expect_read<=0;end
  else begin
   expect_mac<=active&&capture;
   expect_read<=active&&issue;
   if(active&&dut.stream_start_transfer)begin
    if(dut.group_q!=groups)$fatal(1,"group order");
    current_group=groups;groups=groups+1;meta_count=0;
   end
   if(active&&meta_fire)begin
    record=metadata(current_layer,current_group,meta_count);
    if(dut.u_shared_engine.u_engine.metadata_row_index_i!=64*current_group+meta_count ||
       dut.u_shared_engine.u_engine.metadata_multiplier_i!=record[23:8] ||
       dut.u_shared_engine.u_engine.metadata_exponent_i!=record[7:0] ||
       dut.u_shared_engine.u_engine.metadata_last_i!=(meta_count==63))$fatal(1,"metadata record");
    meta_count=meta_count+1;metadata_records=metadata_records+1;
   end
   if(active&&capture)begin
    if(!dut.u_shared_engine.u_engine.weight_ready_o)$fatal(1,"capture readiness");
    if(dut.activation_q!==argument(captures%256,generation))$fatal(1,"activation capture L=%0d c=%0d",current_layer,captures%256);
    if(current_group!=captures/256)$fatal(1,"capture group");
    for(k=0;k<64;k=k+1)begin
     if(dut.stream_weight_data[k*10+:10]!==coefficient(current_layer,captures/256,captures%256,k))
      $fatal(1,"weight capture L=%0d g=%0d c=%0d lane=%0d",current_layer,captures/256,captures%256,k);
     expected_weights[k*10+:10]<=coefficient(current_layer,captures/256,captures%256,k);
    end
    expected_activation<=argument(captures%256,generation);captures=captures+1;
   end
   if(active&&issue)begin
    for(t=0;t<4;t=t+1)begin
     record=metadata(current_layer,current_group,t*16+dut.u_shared_engine.u_engine.issue_count_q[3:0]);
     exp_sum=-10+$signed(record[7:0])-15;
     expected_mult[t]<=record[23:8];expected_exp[t]<=exp_sum;
    end
   end
   if(active&&dut.u_shared_engine.u_engine.state_q==4 && dut.u_shared_engine.u_engine.scale_valid_q[1])begin
    record=metadata(current_layer,current_group,dut.u_shared_engine.u_engine.row_pipe_q[1]);
    exp_sum=-10+$signed(record[7:0])-15;
    if(dut.u_shared_engine.u_engine.scale_operand_q!=={2'b00,record[23:8]} ||
       dut.u_shared_engine.u_engine.u_scale_low.b_i!=={2'b00,record[23:8]} ||
       dut.u_shared_engine.u_engine.u_scale_high.b_i!=={2'b00,record[23:8]} ||
       dut.u_shared_engine.u_engine.exponent_pipe_q[1]!==exp_sum[7:0])$fatal(1,"postscale metadata coefficient");
   end
  end
 end
 genvar tile,lane;
 generate for(tile=0;tile<4;tile=tile+1)begin:monitor_tile
  always @(posedge clk)if(reset_n&&!clear_i&&active&&expect_read)begin
   if(dut.u_shared_engine.u_engine.g_tile[tile].u_tile.multiplier_o!==expected_mult[tile] ||
      dut.u_shared_engine.u_engine.g_tile[tile].u_tile.exponent_o!==expected_exp[tile])$fatal(1,"retained metadata tile=%0d",tile);
  end
  for(lane=0;lane<16;lane=lane+1)begin:monitor_lane
   always @(posedge clk)if(reset_n&&!clear_i&&active&&expect_mac&&!dut.u_shared_engine.u_engine.kill)begin
    if(!dut.u_shared_engine.u_engine.g_tile[tile].u_tile.g_lane[lane].u_mac.multiply_i ||
       dut.u_shared_engine.u_engine.g_tile[tile].u_tile.g_lane[lane].u_mac.activation_i!==expected_activation ||
       dut.u_shared_engine.u_engine.g_tile[tile].u_tile.g_lane[lane].u_mac.weight_i!==expected_weights[(tile*16+lane)*10+:10])
      $fatal(1,"MAC use tile=%0d lane=%0d",tile,lane);
   end
  end
 end endgenerate
 task automatic begin_job(input integer L,input integer gen);
  integer c;
  begin
   while(!sr||!nsr)@(negedge clk);
   @(negedge clk);current_layer=L;generation=gen;layer=L;captures=0;groups=0;meta_count=0;active=1;start=1;
   @(negedge clk);start=0;
   for(c=0;c<256;c=c+1)begin
    activation=argument(c,gen);last=c==255;av=1;
    @(posedge clk);while(!ar)@(posedge clk);
    @(negedge clk);av=0;
    if(c%11==0)@(negedge clk);
   end
  end
 endtask
 integer L;
 initial begin
  $readmemh("model256.memh",model);
  $readmemh("raw-expected.memh",raw_expected);
  $readmemh("norm-expected.memh",norm_expected);
  repeat(3)@(negedge clk);reset_n=1;
  begin_job(0,1);wait(captures>=3);
  @(negedge clk);clear_i=1;active=0;
  if(debt==0)$fatal(1,"CLEAR control needs old outstanding words");
  repeat(2)@(negedge clk);clear_i=0;
  while(!sr)@(negedge clk);
  if(debt!=0)$fatal(1,"old words not drained at fresh admission");
  for(L=0;L<6;L=L+1)begin
   begin_job(L,L+3);
   while(!job_seen||!norm_seen)@(negedge clk);
   if(raw_count!=256||norm_count!=256)$fatal(1,"missing arithmetic outputs");
   if(captures!=1024||groups!=4||meta_count!=64)$fatal(1,"incomplete Q invocation");
   full_runs=full_runs+1;
   @(negedge clk);active=0;
  end
  $display("PASS: six full native Q projections and normalizations, 1536 exact raw and normalized rows, all64 lanes, stalls and CLEAR/drain. requests=%0d responses=%0d",requests,responses);
  $finish;
 end
endmodule

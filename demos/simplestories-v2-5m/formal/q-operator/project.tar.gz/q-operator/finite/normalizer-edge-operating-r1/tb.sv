
module tb;
 reg clk=0;always #5 clk=~clk;
 reg rst=0,clear=0,start=0,iv=0,last=0,ready=0;
 reg[9:0]row=0;reg signed[49:0]value=0;
 wire sr,ir,rv,done,fault,rl;wire[9:0]rr;wire signed[15:0]m;wire signed[7:0]e;
 integer transfers=0,mode=0,cycle=0;
 board1_fixed_vector_normalizer dut(
  .clk(clk),.rst_n(rst),.clear_i(clear),.model_lock_i(1'b1),.upstream_fault_i(1'b0),
  .start_valid_i(start),.start_ready_o(sr),.fixed_layer_i(3'd0),.fixed_job_i(4'd0),
  .input_valid_i(iv),.input_ready_o(ir),.input_row_index_i(row),.input_raw_i(value),.input_source_exponent_i(8'sd0),.input_last_i(last),
  .result_valid_o(rv),.result_ready_i(ready),.result_row_index_o(rr),.result_mantissa_o(m),.result_exponent_o(e),.result_last_o(rl),
  .done_valid_o(done),.done_ready_i(1'b1),.busy_o(),.range_fault_o(fault));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(cycle>2100000)$fatal(1,"fixture timeout");
  if(rst&&!clear&&rv&&ready)begin
   if(rr!=transfers || rl!=(transfers==255))$fatal(1,"row/last mismatch");
   if(mode==0 && (m!=0||e!=0))$fatal(1,"deadline result mismatch");
   if(mode==1 && (m!=24576||e!=-13))$fatal(1,"fresh result leaked stale helper response");
   transfers=transfers+1;
  end
 end
 task automatic begin_vector(input integer raw);
  integer i;
  begin
   while(!sr)@(negedge clk);
   start=1;@(negedge clk);start=0;
   for(i=0;i<256;i=i+1)begin
    row=i;value=raw;last=i==255;iv=1;
    @(posedge clk);while(!ir)@(posedge clk);
    @(negedge clk);iv=0;
   end
  end
 endtask
 task automatic do_clear;
  begin
   @(negedge clk);clear=1;iv=0;start=0;ready=0;
   @(negedge clk);clear=0;transfers=0;
  end
 endtask
 initial begin
  repeat(3)@(negedge clk);rst=1;
  begin_vector(0);
  while(!rv)@(negedge clk);
  while(dut.compute_cycles_q<1999999)@(negedge clk);
  if(!rv||fault||done)$fatal(1,"deadline pre-edge not live");
  ready=1;
  @(posedge clk);#1;
  if(transfers!=1 || !fault || rv || done)$fatal(1,"deadline must accept one correct prefix row, then fault");
  $display("PASS deadline: actual count=MAX-1 accepted one correct result before priority fault");
  do_clear();
  begin_vector(1);
  while(dut.u_shift.state_q!=1)@(negedge clk);
  do_clear();mode=1;
  begin_vector(3);ready=1;
  while(!done&&!fault)@(negedge clk);
  if(fault||transfers!=256)$fatal(1,"fresh vector after mid-helper CLEAR failed");
  $display("PASS: real default watchdog boundary and mid-helper CLEAR/fresh vector without hard reset");$finish;
 end
endmodule


module tb;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,clear=0,start=0,iv=0,il=0;
 reg[9:0]ir=0;reg signed[49:0]raw=0;reg signed[7:0]ex=0;
 wire sr,ready,rv,done,fault;wire[9:0]rr;wire signed[15:0]m;wire signed[7:0]e;wire last;
 integer cycle=0,which=0,count=0,expected_count=0,success=0,i;
 reg[57:0]records[0:255];reg[34:0]expected[0:255];
 wire output_ready=cycle%7!=2 && cycle%7!=3;
 board1_fixed_vector_normalizer dut(
  .clk(clk),.rst_n(rst_n),.clear_i(clear),.model_lock_i(1'b1),.upstream_fault_i(1'b0),
  .start_valid_i(start),.start_ready_o(sr),.fixed_layer_i(3'd0),.fixed_job_i(4'd0),
  .input_valid_i(iv),.input_ready_o(ready),.input_row_index_i(ir),.input_raw_i(raw),.input_source_exponent_i(ex),.input_last_i(il),
  .result_valid_o(rv),.result_ready_i(output_ready),.result_row_index_o(rr),.result_mantissa_o(m),.result_exponent_o(e),.result_last_o(last),
  .done_valid_o(done),.done_ready_i(1'b1),.busy_o(),.range_fault_o(fault));
 always @(posedge clk)begin
  cycle<=cycle+1;
  if(cycle>500000)$fatal(1,"fixture timeout");
  if(rst_n&&!clear&&rv)begin
   if(count>=expected_count || {rr,m,e,last}!==expected[count])
    $fatal(1,"normalized result mismatch case=%0d row=%0d count=%0d got=%h expected=%h",which,rr,count,{rr,m,e,last},expected[count]);
   if(output_ready)count=count+1;
  end
 end
 task automatic run_case(input integer number,input integer rows,input integer ok);
  begin
   @(negedge clk);clear=1;iv=0;start=0;
   @(negedge clk);clear=0;which=number;count=0;expected_count=rows;success=ok;
   $readmemh($sformatf("case%0d-input.memh",number),records);
   if(rows>0)$readmemh($sformatf("case%0d-expected.memh",number),expected,0,rows-1);
   while(!sr)@(negedge clk);
   start=1;@(negedge clk);start=0;
   for(i=0;i<256;i=i+1)begin
    ir=i;raw=records[i][49:0];ex=records[i][57:50];il=i==255;iv=1;
    @(posedge clk);while(!ready)@(posedge clk);
    @(negedge clk);iv=0;
    if(i%13==0)@(negedge clk);
   end
   while(!done&&!fault)@(negedge clk);
   if(count!=rows || done!==ok || fault===ok)
    $fatal(1,"normalizer outcome mismatch case=%0d rows=%0d expected=%0d done=%0d fault=%0d",number,count,rows,done,fault);
   $display("CASE %0d PASS rows=%0d success=%0d",number,count,ok);
   @(negedge clk);
  end
 endtask
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  run_case(0,256,1);
  run_case(1,17,0);
  run_case(2,256,1);
  run_case(3,256,1);
  run_case(4,256,1);
  run_case(5,256,1);
  run_case(6,256,1);
  run_case(7,256,1);
  run_case(8,256,1);
  run_case(9,256,1);
  run_case(10,0,0);
  run_case(11,256,1);
  $display("PASS: native normalizer prefix/value/outcome, stalls and CLEAR without hard reset");$finish;
 end
endmodule

"""Source ownership of the completed reference until parent cancellation/reuse.

This concerns the independent accepted-argument/capture histories, not physical
RAM erasure or later query-RAM reads. qh-Ndone records the actual current Q
normalizer DONE handshake and is revoked at parent acceptance/CLEAR/reset.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import S
from q_normalizer_product import dn
from q_capture_support import scope
from q_output_ownership_r3 import specification as output_spec,body_files as output_files


def guard(a='a',h='h'):return both([dn('rst_n',a),f'(qh-Ndone {h})'])


def definitions():
    values=['(qa-owned qa)','(qa-complete qa)',eq('(qa-layer qa)','(qh-layer h)'),eq('(qa-epoch qa)','(qh-epoch h)'),
        eq('(nc-count nc)',bv(256,10)),eq('(nc-rows nc)',bv(256,10)),eq('(nc-job nc)',bv(0,4)),eq('(nc-layer nc)','(qa-layer qa)'),
        eq('(na-rows na)',bv(256,10)),eq('(na-emitted na)',bv(256,10))]
    args=f'((a {S}) (qa QArguments) (nc NormCapture) (na NormAlgorithm) (h QOutput))'
    return f'(define-fun qd-source-inv {args} Bool (=> {guard()} {both(values)}))\n'


def step():return output_spec()[2]['preserved-0']['assumptions']+['(qd-source-inv a qa nc na h)']


def specification():
    decl=output_spec()[0]
    retained=both([dn('rst_n'),eq('qan','qa'),eq('(nc-vec ncn)','(nc-vec nc)'),
        '(or (qh-Ndone h) '+both([scope(),eq('(nc-count nc)',bv(256,10))])+')'])
    rules={
        'source-empty-reset-base':dict(assumptions=[],conclusion='(qd-source-inv an qa-zero nc-zero na-zero qh-zero)'),
        'source-preserved':dict(assumptions=step(),conclusion='(qd-source-inv an qan ncn nan hn)'),
        'retained-completed-reference-or-current-native-DONE':dict(assumptions=step()+['(qd-source-inv an qan ncn nan hn)',guard('an','hn')],conclusion=retained)}
    return decl,definitions(),rules


def body_files():return output_files()+['q-done-support/history.smt2']


PROVIDERS=['q-output-ownership-r3']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-done-support';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-post-DONE-reference-source-ownership-v1',component='q-done-support',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-done-support-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-done-support-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed completed reference source scope')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Completed accepted reference ownership and cancellation/reuse source support prepared.')

"""Actual integer accumulation equals the independent fixed-Q prefix.

Unlike an event-trace sum alone, Q-prefix is a pure finite recursive function
of one stable accepted vector and fixed model row. The actual proved column
order selects its successive terms. No expected product or dot is an input.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from q_columns import TOP,S,ENGINE,n,phase,F
from q_model import MODEL
from q_identity import body_files as identity_body_files
from semantic_facts import substitute


def prefix(count):
    return f'(Q-prefix (qi-vector qi) model (qi-layer qi) (qi-group qi) (concat tile lane) {count})'


def product(column):
    return f'(Q-product (qi-vector qi) model (qi-layer qi) (qi-group qi) (concat tile lane) {column})'


def definitions():
    pending=both(['(qc-live a)','(th-p th)',f'(not {F("kill_i")})',f'(not {F("begin_i")})'])
    active=both(['(qc-live a)',phase(1,2,3,4,5)])
    clauses=[f'(=> {pending} (= (mh-P mh) {product("(pc-pcol pc)")}))',
        f'(=> {active} (= (mh-S mh) {prefix("(pc-acc pc)")}))']
    args=f'((a {S}) (pc PrefixHistory) (th TileHistory) (mh MathHistory) (qi QIdentity) (model {MODEL}) (lane (_ BitVec 4)) (tile (_ BitVec 2)))'
    defs=''
    for i,c in enumerate(clauses):defs+=f'(define-fun qp-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun qp-inv {args} Bool '+both([f'(qp-clause-{i} a pc th mh qi model lane tile)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def provider_facts(next_base=False):
    from q_identity import specification as identity_spec
    from q_prefix_laws import specification as law_spec
    identity=identity_spec()[2]['current-fixed-Q-snapshot-operands']
    facts=['(=> '+both(identity['assumptions'])+' '+identity['conclusion']+')']
    mapping={'vector':'(qi-vector qi)','model':'model','layer':'(qi-layer qi)','group':'(qi-group qi)','row':'(concat tile lane)','c':'(pc-acc pc)'}
    for rule in law_spec()[2].values():
        facts.append(substitute('(=> '+both(rule['assumptions'])+' '+rule['conclusion']+')',mapping))
    if next_base:
        rule=law_spec()[2]['empty-prefix']
        mapping.update(vector='(qi-vector qin)',layer='(qi-layer qin)',group='(qi-group qin)')
        facts.append(substitute('(=> '+both(rule['assumptions'])+' '+rule['conclusion']+')',mapping))
    return facts


def specification(next_base=False):
    defs,clauses=definitions();H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const mh MathHistory)','(declare-const mhn MathHistory)','(declare-const qi QIdentity)','(declare-const qin QIdentity)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))',f'(declare-const model {MODEL})']
    current=['(capture-inv a ch)','(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(tile-inv a th lane tile)',
        '(qc-inv a pc th ch lane tile)','(qi-inv a ch qi)','(macmodel-inv a ch model)','(qp-inv a pc th mh qi model lane tile)']
    step=[H('a'),H('an'),'(operand-native-step a an)',*current,'(= chn (capture-next a ch))','(capture-inv an chn)',
        '(= pcn (prefix-next a pc))','(prefix-inv an pcn)','(= thn (tile-next a th lane tile))','(lineage-inv an pcn thn lane tile)','(tile-inv an thn lane tile)',
        '(qc-inv an pcn thn chn lane tile)','(= qin (qi-next a ch qi))','(qi-inv an chn qin)',
        '(= mhn (math-next a th mh tile))',*provider_facts(next_base)]
    parts=[f'(qp-clause-{i} an pcn thn mhn qin model lane tile)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("reset_n")})','(capture-inv an (capture-zero an))','(prefix-inv an prefix-zero)'],
        conclusion='(qp-inv an prefix-zero tile-zero math-zero qi-zero model lane tile)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qp-inv an pcn thn mhn qin model lane tile)'),
        'completed-fixed-Q-dot':dict(assumptions=[H('a'),*current,'(qc-live a)',n(ENGINE+'result_valid_o')],
            conclusion=both([eq('(pc-acc pc)',bv(256,10)),eq('(mh-S mh)',prefix(bv(256,10))),'(qi-owned qi)']))}
    return decl,defs,rules


def body_files():return identity_body_files()+['q-prefix/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-prefix';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-model-PLAN.json','q-identity-PLAN.json','q-prefix-laws-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-fixed-model-integer-prefix-v1',component='q-prefix',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-prefix-CHECKS.json',
        old_providers=['parentcapture','macmodel'],new_providers=['q-columns-r3','q-model','q-identity','q-prefix-laws'],provider_facts=provider_facts(),external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-prefix-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed fixed-model integer Q prefix')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual accepted accumulation vs pure fixed-model finite Q-prefix induction prepared.')

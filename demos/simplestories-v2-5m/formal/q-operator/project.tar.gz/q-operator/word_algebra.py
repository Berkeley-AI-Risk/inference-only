"""Explicit unsigned/signed/congruence lemmas for word-semantic application."""
import json
from arithmetic import HERE,MAC,sha,write_json,compile_model


def specification():
    declarations=['(declare-const u Int)','(declare-const x Int)','(declare-const y Int)',
        '(declare-const k Int)','(declare-const j Int)','(declare-const z Int)','(declare-const t Int)']
    rules={}
    for small,large in [(16,26),(10,26),(27,48),(18,48),(26,48),(35,50),(48,50)]:
        lo=1<<small;hi=1<<large;half=lo//2
        signed=f'(ite (< u {half}) u (- u {lo}))'
        rules['sign-extend-%d-to-%d'%(small,large)]=dict(assumptions=['(<= 0 u)',f'(< u {lo})'],
            conclusion=f'(= (mod {signed} {hi}) (ite (< u {half}) u (+ u {hi-lo})))')
    for width in [26,48,50]:
        M=1<<width
        rules['product-congruence-factorization-%d'%width]=dict(assumptions=[],
            conclusion=f'(= (* (+ x (* {M} k)) (+ y (* {M} j))) (+ (* x y) (* {M} (+ (* x j) (* y k) (* {M} k j)))))')
        rules['addition-congruence-factorization-%d'%width]=dict(assumptions=[],
            conclusion=f'(= (+ (+ x (* {M} k)) (+ y (* {M} j))) (+ (+ x y) (* {M} (+ k j))))')
        rules['mod-removes-whole-multiple-%d'%width]=dict(assumptions=[],
            conclusion=f'(= (mod (+ z (* {M} t)) {M}) (mod z {M}))')
    rules['full-signed27x18-fits48']=dict(assumptions=['(<= (- 67108864) x)','(< x 67108864)','(<= (- 131072) y)','(< y 131072)'],
        conclusion='(and (< (- 140737488355328) (* x y)) (< (* x y) 140737488355328))')
    return declarations,'',rules


def prepare():
    compile_model('mac',MAC,{'cluster-tile.sv':[MAC]})
    declarations,defs,rules=specification();d=HERE/'word-algebra';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['mac/native.smt2','word-algebra/history.smt2'];paths=['mac-SOURCES.json','mac/native.sv','mac/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-word-congruence-v1',component='word-algebra',bodies=bodies,source_manifest='mac-SOURCES.json',native_source='mac/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='word-algebra-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'word-algebra-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed word-algebra plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

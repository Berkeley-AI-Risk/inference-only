(define-fun Q-source-write-address ((a |core_workflow_control_s|)) (_ BitVec 8) ((_ extract 7 0) (|core_workflow_control_n u_native.u_six_layers.u_datapath.output_index_q| a)))
(define-fun Q-source-write-data ((a |core_workflow_control_s|)) (_ BitVec 16) (|core_workflow_control_n u_native.u_six_layers.u_datapath.norm_result_mantissa| a))

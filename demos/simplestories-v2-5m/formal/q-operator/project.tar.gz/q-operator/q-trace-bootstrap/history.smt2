; No extra reset/idle assumption; one reset edge plus an ordinary successor history update.

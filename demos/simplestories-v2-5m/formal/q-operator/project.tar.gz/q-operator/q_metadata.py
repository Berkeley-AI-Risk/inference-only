"""Fixed-model row multiplier/exponent through the actual held frame pipeline."""
import json
from arithmetic import HERE,OPERANDS,bv,both,eq,sha,write_json
from q_columns import TOP,S,ENGINE,J,A,n,phase
from q_model import MODEL


def flag(i,a='a'):return eq('((_ extract '+str(i)+' '+str(i)+') '+n(ENGINE+'scale_valid_q',a)+')','#b1')


def definitions():
    defs=f'(define-fun Q-metadata ((model {MODEL}) (layer (_ BitVec 3)) (group (_ BitVec 6)) (row (_ BitVec 6))) (_ BitVec 24) (model-Q-metadata-record model (bvadd {bv(211920,19)} (bvadd (bvmul ((_ zero_extend 16) layer) {bv(304,19)}) (bvmul ((_ zero_extend 13) group) {bv(8,19)}))) row))\n'
    defs+='(define-fun Q-record-exponent ((e (_ BitVec 8)) (record (_ BitVec 24))) (_ BitVec 11) (bvsub (bvadd ((_ sign_extend 3) e) ((_ sign_extend 3) ((_ extract 7 0) record))) '+bv(15,11)+'))\n'
    live=both([n('reset_n'),f'(not {n(A+"fail_q")})',n('u_native.child_reset_n'),f'(not {n(J+"integrated_fail")})',eq(n(J+'job_q'),bv(0,4)),phase(4)])
    defs+=f'(define-fun qmd-live ((a {S})) Bool {live})\n'
    clauses=[]
    for i in [1,2,3]:
        record=f'(Q-metadata model {n(J+"layer_q")} {n(J+"group_q")} (fr-R{i} fr))'
        exponent=f'(Q-record-exponent {n(J+"activation_exponent_q")} {record})'
        values=[eq(f'(fr-M{i} fr)','((_ extract 23 8) '+record+')'),eq(f'(fr-E{i} fr)','((_ extract 7 0) '+exponent+')'),
            f'(bvsge {exponent} {bv(-128,11)})',f'(bvsle {exponent} {bv(127,11)})']
        clauses.append(f'(=> (and (qmd-live a) {flag(i)}) {both(values)})')
    args=f'((a {S}) (fr FrameHistory) (model {MODEL}))'
    for i,c in enumerate(clauses):defs+=f'(define-fun qmd-clause-{i} {args} Bool {c})\n'
    defs+=f'(define-fun qmd-inv {args} Bool '+both([f'(qmd-clause-{i} a fr model)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda a:f'(|{TOP}_h| {a})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const fr FrameHistory)','(declare-const frn FrameHistory)',f'(declare-const model {MODEL})']
    current=['(capture-inv a ch)','(tilemeta-inv a model)','(frame-inv a fr)','(qmd-inv a fr model)']
    step=[H('a'),H('an'),'(operand-native-step a an)',*current,'(= chn (capture-next a ch))','(capture-inv an chn)',
        '(tilemeta-inv an model)','(= frn (frame-next a fr))','(frame-inv an frn)']
    parts=[f'(qmd-clause-{i} an frn model)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("reset_n")})'],conclusion='(qmd-inv an frame-zero model)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qmd-inv an frn model)'),
        'current-stage1':dict(assumptions=[H('a'),'(capture-inv a ch)','(tilemeta-inv a model)','(frame-inv a fr)'],conclusion='(qmd-clause-0 a fr model)'),
        'current-output-metadata':dict(assumptions=[H('a'),*current,'(qmd-live a)',n(ENGINE+'result_valid_o')],conclusion='(qmd-clause-2 a fr model)')}
    return decl,defs,rules


def body_files():
    old=json.loads((OPERANDS/'tilemeta-PLAN.json').read_text())
    return ['../model-consumption/'+p for p in old['bodies']]+['q-engine/history.smt2','q-metadata/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-metadata';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/tilemeta-PLAN.json','q-engine/INSTANCE-BINDING.json',*bodies]
    plan=dict(schema='Typed-Q-fixed-metadata-frame-v1',component='q-metadata',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-metadata-CHECKS.json',
        old_providers=['parentcapture','tilemeta'],new_providers=[],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-metadata-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed fixed Q metadata frame')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Fixed-model multiplier and representable row exponent through held actual output frame prepared.')

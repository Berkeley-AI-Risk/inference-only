"""Corrected syntax and explicit Boolean cases for integer word-fold induction.

The malformed first-version artifacts and parse failures remain untouched.
"""
import copy
import json
from arithmetic import HERE,bv,both,sha,write_json
from lineage import field
from math_fold import specification as base_specification


def specification():
    declarations,defs,old=base_specification(True);rules={}
    revoke=f'(or (not {field("reset_n")}) {field("kill_i")} {field("begin_i")})'
    for name,rule in old.items():
        if name not in ['preserved-0','preserved-2']:
            rules[name]=rule;continue
        enabled='(th-o th)'if name=='preserved-0'else'(th-p th)'
        cases=[('revoked',revoke),('enabled',f'(and (not {revoke}) {enabled})'),('held',f'(and (not {revoke}) (not {enabled}))')]
        names=[]
        for suffix,guard in cases:
            key=name+'-'+suffix;names.append(key);case=copy.deepcopy(rule)
            case['assumptions'].append(guard);rules[key]=case
        joined=copy.deepcopy(rule);joined['dependencies']=list(dict.fromkeys(rule.get('dependencies',[])+names));rules[name]=joined
    return declarations,defs,rules


def prepare():
    declarations,defs,rules=specification();d=HERE/'math-fold-r2';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    from pruned_arithmetic import parse
    parse(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','lineage/history.smt2','math-fold-r2/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json','lineage-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-integer-fold-r2-v1',component='math-fold-r2',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='math-fold-r2-CHECKS.json',
        inductive_providers=['prefix-r2','lineage'],component_provider='tile-held',semantic_providers=['word16x10-function','word48-add26-function'],
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'math-fold-r2-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed corrected fold plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Corrected parsed datatype and exhaustive enabled/held/revoked cases frozen.')

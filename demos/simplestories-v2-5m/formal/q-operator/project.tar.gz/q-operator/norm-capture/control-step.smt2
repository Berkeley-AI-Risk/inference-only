(define-fun norm-memory-native-step ((state |board1_fixed_vector_normalizer_s|) (next_state |board1_fixed_vector_normalizer_s|)) Bool (and
  (= (|board1_fixed_vector_normalizer#172| state) (|board1_fixed_vector_normalizer#81| next_state)) ; $procdff$16056 \record_read_q
  (= (|board1_fixed_vector_normalizer#208| state) (|board1_fixed_vector_normalizer#21| next_state)) ; $procdff$15850 $auto$async2sync.cc:253:execute$16104
  (= (|board1_fixed_vector_normalizer#222| state) (|board1_fixed_vector_normalizer#20| next_state)) ; $procdff$15845 $auto$async2sync.cc:253:execute$16102
  (= (|board1_fixed_vector_normalizer#253| state) (|board1_fixed_vector_normalizer#19| next_state)) ; $procdff$15840 $auto$async2sync.cc:253:execute$16100
  (= (|board1_fixed_vector_normalizer#267| state) (|board1_fixed_vector_normalizer#18| next_state)) ; $procdff$15835 $auto$async2sync.cc:253:execute$16098
  (= (|board1_fixed_vector_normalizer#294| state) (|board1_fixed_vector_normalizer#17| next_state)) ; $procdff$15830 $auto$async2sync.cc:253:execute$16096
  (= (|board1_fixed_vector_normalizer#320| state) (|board1_fixed_vector_normalizer#16| next_state)) ; $procdff$15825 $auto$async2sync.cc:253:execute$16094
  (= (|board1_fixed_vector_normalizer#337| state) (|board1_fixed_vector_normalizer#15| next_state)) ; $procdff$15820 $auto$async2sync.cc:253:execute$16092
  (= (|board1_fixed_vector_normalizer#369| state) (|board1_fixed_vector_normalizer#14| next_state)) ; $procdff$15815 $auto$async2sync.cc:253:execute$16090
  (= (|board1_fixed_vector_normalizer#412| state) (|board1_fixed_vector_normalizer#13| next_state)) ; $procdff$15800 $auto$async2sync.cc:253:execute$16088
  (= (|board1_fixed_vector_normalizer#422| state) (|board1_fixed_vector_normalizer#12| next_state)) ; $procdff$15795 $auto$async2sync.cc:253:execute$16086
  (= (|board1_fixed_vector_normalizer#431| state) (|board1_fixed_vector_normalizer#11| next_state)) ; $procdff$15790 $auto$async2sync.cc:253:execute$16084
  (= (|board1_fixed_vector_normalizer#2765| state) (|board1_fixed_vector_normalizer#10| next_state)) ; $procdff$15785 $auto$async2sync.cc:253:execute$16082
  (= (|board1_fixed_vector_normalizer#2806| state) (|board1_fixed_vector_normalizer#9| next_state)) ; $procdff$15780 $auto$async2sync.cc:253:execute$16080
  (= (|board1_fixed_vector_normalizer#2838| state) (|board1_fixed_vector_normalizer#8| next_state)) ; $procdff$15775 $auto$async2sync.cc:253:execute$16078
  (= (|board1_fixed_vector_normalizer#2850| state) (|board1_fixed_vector_normalizer#7| next_state)) ; $procdff$15770 $auto$async2sync.cc:253:execute$16076
  (= (|board1_fixed_vector_normalizer#2862| state) (|board1_fixed_vector_normalizer#6| next_state)) ; $procdff$15765 $auto$async2sync.cc:253:execute$16074
  (= (|board1_fixed_vector_normalizer#2874| state) (|board1_fixed_vector_normalizer#5| next_state)) ; $procdff$15760 $auto$async2sync.cc:253:execute$16072
  (= (|board1_fixed_vector_normalizer#2886| state) (|board1_fixed_vector_normalizer#4| next_state)) ; $procdff$15755 $auto$async2sync.cc:253:execute$16070
  (= (|board1_fixed_vector_normalizer#170#1| state) (|board1_fixed_vector_normalizer#170#0| next_state)) ; record_mem_q
))

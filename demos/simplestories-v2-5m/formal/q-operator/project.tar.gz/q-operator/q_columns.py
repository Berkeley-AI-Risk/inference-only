"""Same-edge column/input binding between qualified Q and integer engine.

All old operand artifacts remain immutable. Functional arithmetic histories are
specialized at the actual source engine; the new invariant joins its accepted
column tags to the already-qualified parent capture history.
"""
import json
from arithmetic import HERE,OPERANDS,bv,both,eq,sha,write_json
from lanes import TOP,S,ENGINE,n
from q_engine import definitions as engine_definitions

J='u_native.u_six_layers.u_datapath.u_projection.'
A='u_native.u_private_ddr_arbiter.'
F=lambda field:f'(|lineage-native {field}| a tile)'
phase=lambda *states:'(or '+' '.join(eq(n(ENGINE+'state_q'),bv(i,3))for i in states)+')'


def definitions(revision=1):
    live=both([n('reset_n'),f'(not {n(A+"fail_q")})',n('u_native.child_reset_n'),f'(not {n(J+"integrated_fail")})',eq(n(J+'job_q'),bv(0,4))])
    defs=f'(define-fun qc-live ((a {S})) Bool {live})\n'
    guard=both(['(qc-live a)','(th-o th)',f'(not {F("kill_i")})',f'(not {F("begin_i")})'])
    defs+=f'(define-fun qc-op ((a {S}) (th TileHistory) (tile (_ BitVec 2))) Bool {guard})\n'
    clauses=[f'(=> (qc-op a th tile) (= (pc-opcol pc) (c-mac-column ch)))']
    if revision in [2,3]:
        guard=both([n(ENGINE+'reset_n'),'(or (th-o th) (th-p th))']+([f'(not {n(ENGINE+"fail_q")})']if revision==3 else []))
        clauses.append(f'(=> {guard} {phase(2,3)})')
    # A lane's input word is selected without a new numerical oracle. The old
    # actual-register relation and generic tile history identify both sides.
    # Multiplication by ten is in a 10-bit shift count; the source all64 lane
    # correspondence supplies the actual ten-bit slice, including all lanes.
    index=f'(bvmul ((_ zero_extend 4) (concat tile lane)) {bv(10,10)})'
    w=f'((_ extract 9 0) (bvlshr (c-mac-W ch) ((_ zero_extend 630) {index})))'
    matching=both(['(c-mac-valid ch)',eq('(th-A th)','(c-mac-A ch)'),eq('(th-W th)',w)])
    values=[
        f'(=> (qc-op a th tile) {matching})',
        f'(=> (qc-op a th tile) '+both([f'(bvult (pc-opcol pc) {bv(256,10)})',eq(n(ENGINE+'columns_q'),bv(256,10)),eq('(j-cols (c-base ch))',bv(256,10))])+')',
        f'(=> (and (qc-live a) {phase(1,2,3,4,5)}) '+both(['(j-active (c-base ch))','(j-complete (c-base ch))',eq(n(J+'state_q'),bv(3,3)),f'(bvult {n(J+"layer_q")} {bv(6,3)})',f'(bvult {n(J+"group_q")} {bv(4,6)})'])+')',
    ]
    args=f'((a {S}) (pc PrefixHistory) (th TileHistory) (ch CaptureHistory) (lane (_ BitVec 4)) (tile (_ BitVec 2)))'
    for i,clause in enumerate(clauses):defs+=f'(define-fun qc-clause-{i} {args} Bool {clause})\n'
    defs+=f'(define-fun qc-inv {args} Bool '+both([f'(qc-clause-{i} a pc th ch lane tile)'for i in range(len(clauses))])+')\n'
    return defs,clauses,values


def specification(revision=1):
    defs,clauses,values=definitions(revision);H=lambda s:f'(|{TOP}_h| {s})';T=f'(|{TOP}_t| a an)'
    decl=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const ch CaptureHistory)','(declare-const chn CaptureHistory)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))']
    current=['(capture-inv a ch)','(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(tile-inv a th lane tile)','(qc-inv a pc th ch lane tile)']
    step=[H('a'),H('an'),'(operand-native-step a an)',*current,'(= pcn (prefix-next a pc))','(prefix-inv an pcn)',
        '(= thn (tile-next a th lane tile))','(lineage-inv an pcn thn lane tile)','(tile-inv an thn lane tile)',
        '(= chn (capture-next a ch))','(capture-inv an chn)']
    parts=[f'(qc-clause-{i} an pcn thn chn lane tile)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=[H('a'),H('an'),T,f'(not {n("reset_n")})','(capture-inv an (capture-zero an))','(prefix-inv an prefix-zero)','(lineage-inv an prefix-zero tile-zero lane tile)'],
        conclusion='(qc-inv an prefix-zero tile-zero (capture-zero an) lane tile)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(qc-inv an pcn thn chn lane tile)'),
        **{'current-'+str(i):dict(assumptions=[H('a'),*current],conclusion=v)for i,v in enumerate(values)}}
    return decl,defs,rules


def prepare():
    decl,defs,rules=specification();d=HERE/'q-columns';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2','q-engine/history.smt2','q-columns/history.smt2']
    paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','q-engine/INSTANCE-BINDING.json',*bodies]
    plan=dict(schema='Typed-Q-parent-column-binding-v1',component='q-columns',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-columns-CHECKS.json',
        old_providers=['parentcapture'],engine_specialization='q-engine/INSTANCE-BINDING.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-columns-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed parent column binding')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Qualified Q capture and arithmetic engine histories joined at the actual parent column events.')

"""Reconstruct local rule types and raw engine implications, not just hashes."""
import copy
import json
from pathlib import Path
import re
import sys

from arithmetic import HERE,PILOT,sha,specification
sys.path.insert(0,str(PILOT))
from native_induction import validate,query


def shape(plan):
    if plan['schema']=='Typed-Q-local-arithmetic-v1':
        declarations,defs,rules=specification(plan['component'])
    elif plan['schema']=='Typed-Q-owned-tile-history-v1':
        from tile import specification as tile_specification
        declarations,defs,rules=tile_specification()
    elif plan['schema']=='Typed-Q-integer-profile-v1':
        from profile import specification as profile_specification
        declarations,defs,rules=profile_specification()
    elif plan['schema']=='Typed-Q-native-all64-lifting-v1':
        from lanes import specification as lanes_specification
        declarations,defs,rules=lanes_specification()
    elif plan['schema']=='Typed-Q-shift-history-v1':
        from shift import specification as shift_specification
        declarations,defs,rules=shift_specification()
    elif plan['schema']=='Typed-Q-postscale-words-v1':
        from postscale import specification as postscale_specification
        declarations,defs,rules=postscale_specification()
    elif plan['schema']=='Typed-Q-normalizer-selector-v1':
        from selector import specification as selector_specification
        declarations,defs,rules=selector_specification()
    elif plan['schema']=='Typed-Q-any-lane-tile-history-v1':
        from tile_any import specification as tile_any_specification
        declarations,defs,rules=tile_any_specification()
    elif plan['schema']=='Typed-Q-integer-word-semantics-v1':
        from word_semantics import specification as word_semantics_specification
        declarations,defs,rules=word_semantics_specification()
    elif plan['schema']=='Typed-Q-word-congruence-v1':
        from word_algebra import specification as word_algebra_specification
        declarations,defs,rules=word_algebra_specification()
    elif plan['schema']=='Typed-Q-exhaustive-lane-induction-v1':
        from tile_cases import specification as tile_cases_specification
        declarations,defs,rules=tile_cases_specification()
    elif plan['schema']=='Typed-Q-wide-type-bounds-v1':
        from wide_bounds import specification as wide_bounds_specification
        declarations,defs,rules=wide_bounds_specification()
    elif plan['schema']=='Typed-Q-engine-prefix-control-v1':
        from prefix_control import specification as prefix_specification
        declarations,defs,rules=prefix_specification()
    elif plan['schema']=='Typed-Q-engine-prefix-control-r2-v1':
        from prefix_r2 import specification as prefix_r2_specification
        declarations,defs,rules=prefix_r2_specification()
    elif plan['schema']=='Typed-Q-postscale-frame-v1':
        from frame import specification as frame_specification
        declarations,defs,rules=frame_specification()
    elif plan['schema']=='Typed-Q-held-read-tile-history-v1':
        from tile_hold import specification as tile_hold_specification
        declarations,defs,rules=tile_hold_specification()
    elif plan['schema']=='Typed-Q-frame-algebra-v1':
        from frame_algebra import specification as frame_algebra_specification
        declarations,defs,rules=frame_algebra_specification()
    elif plan['schema']=='Typed-Q-frame-integer-application-v1':
        from frame_integer import specification as frame_integer_specification
        declarations,defs,rules=frame_integer_specification()
    elif plan['schema']=='Typed-Q-prefix-tile-lineage-v1':
        from lineage import specification as lineage_specification
        declarations,defs,rules=lineage_specification()
    elif plan['schema']=='Typed-Q-sum-frame-composition-v1':
        from sum_frame import specification as sum_frame_specification
        declarations,defs,rules=sum_frame_specification()
    elif plan['schema']=='Typed-Q-word-scalar-v1':
        from word_scalar import specification as word_scalar_specification
        declarations,defs,rules=word_scalar_specification()
    elif plan['schema']=='Typed-Q-integer-fold-v1':
        from math_fold import specification as math_fold_specification
        declarations,defs,rules=math_fold_specification()
    elif plan['schema']=='Typed-Q-integer-fold-r2-v1':
        from math_fold_r2 import specification as math_fold_r2_specification
        declarations,defs,rules=math_fold_r2_specification()
    elif plan['schema']=='Typed-Q-engine-integer-composition-v1':
        from engine_integer import specification as engine_integer_specification
        declarations,defs,rules=engine_integer_specification()
    elif plan['schema']=='Typed-Q-engine-integer-fact-composition-v1':
        from engine_integer_r2 import specification as engine_integer_r2_specification
        declarations,defs,rules,_,_=engine_integer_r2_specification()
    elif plan['schema']=='Typed-Q-normalizer-vector-capture-v1':
        from norm_capture import specification as norm_capture_specification
        declarations,defs,rules=norm_capture_specification()
    elif plan['schema']=='Typed-Q-normalizer-vector-capture-r2-v1':
        from norm_capture_r2 import specification as norm_capture_specification
        declarations,defs,rules=norm_capture_specification()
    elif plan['schema']=='Typed-Q-normalizer-shift-composition-v1':
        from norm_shift import specification as norm_shift_specification
        declarations,defs,rules=norm_shift_specification()
    elif plan['schema']=='Typed-Q-whole-normalizer-algorithm-v1':
        from norm_algorithm import specification as norm_algorithm_specification
        declarations,defs,rules=norm_algorithm_specification()
    elif plan['schema']=='Typed-Q-whole-normalizer-algorithm-r2-v1':
        from norm_algorithm_r2 import specification as norm_algorithm_specification
        declarations,defs,rules=norm_algorithm_specification()
    elif plan['schema']=='Typed-Q-parent-column-binding-v1':
        from q_columns import specification as q_columns_specification
        declarations,defs,rules=q_columns_specification()
    elif plan['schema']=='Typed-Q-parent-column-binding-r3-v1':
        from q_columns_r3 import specification as q_columns_specification
        declarations,defs,rules=q_columns_specification()
    elif plan['schema']=='Typed-Q-fixed-model-input-binding-v1':
        from q_model import specification as q_model_specification
        declarations,defs,rules=q_model_specification()
    elif plan['schema']=='Typed-Q-accepted-vector-identity-v1':
        from q_identity import specification as q_identity_specification
        declarations,defs,rules=q_identity_specification()
    elif plan['schema']=='Typed-Q-independent-prefix-laws-v1':
        from q_prefix_laws import specification as q_prefix_laws_specification
        declarations,defs,rules=q_prefix_laws_specification()
    elif plan['schema']=='Typed-Q-fixed-model-integer-prefix-r2-v1':
        from q_prefix_r2 import specification as q_prefix_specification
        declarations,defs,rules=q_prefix_specification()
    elif plan['schema']=='Typed-Q-fixed-model-integer-prefix-v1':
        from q_prefix import specification as q_prefix_specification
        declarations,defs,rules=q_prefix_specification()
    elif plan['schema']=='Typed-Q-native-metadata-legality-v1':
        from meta_safety import specification as meta_safety_specification
        declarations,defs,rules=meta_safety_specification()
    elif plan['schema']=='Typed-Q-native-metadata-legality-r2-v1':
        from meta_safety_r2 import specification as meta_safety_specification
        declarations,defs,rules=meta_safety_specification()
    elif plan['schema']=='Typed-Q-prefix-owner-continuity-v1':
        from q_prefix_control import specification as q_prefix_control_specification
        declarations,defs,rules=q_prefix_control_specification()
    elif plan['schema']=='Typed-Q-fixed-prefix-closed-control-composition-v1':
        from q_prefix_r3 import specification as q_prefix_r3_specification
        declarations,defs,rules,_,_=q_prefix_r3_specification()
    elif plan['schema']=='Typed-Q-fixed-metadata-frame-v1':
        from q_metadata import specification as q_metadata_specification
        declarations,defs,rules=q_metadata_specification()
    elif plan['schema']=='Typed-Q-native-result-routing-r2-v1':
        from q_routing_r2 import specification as q_routing_specification
        declarations,defs,rules=q_routing_specification()
    elif plan['schema']=='Typed-Q-accepted-job-and-prefix-v1':
        from q_job import specification as q_job_specification
        declarations,defs,rules=q_job_specification()
    elif plan['schema']=='Typed-Q-accepted-job-and-prefix-r2-v1':
        from q_job_r2 import specification as q_job_specification
        declarations,defs,rules=q_job_specification()
    elif plan['schema']=='Typed-Q-current-source-scope-v1':
        from q_scope import specification as q_scope_specification
        declarations,defs,rules=q_scope_specification()
    elif plan['schema']=='Typed-Q-terminal-frontier-v1':
        from q_terminal import specification as q_terminal_specification
        declarations,defs,rules=q_terminal_specification()
    elif plan['schema']=='Typed-Q-raw-value-closed-composition-r2-v1':
        from q_raw_r2 import specification as q_raw_specification
        declarations,defs,rules,_=q_raw_specification()
    elif plan['schema']=='Typed-Q-complete-EMIT-dot-v1':
        from q_emit import specification as q_emit_specification
        declarations,defs,rules=q_emit_specification()
    elif plan['schema']=='Typed-Q-one-edge-endpoint-control-v1':
        from q_frontier_control import specification as q_frontier_specification
        declarations,defs,rules=q_frontier_specification()
    elif plan['schema']=='Typed-Q-one-edge-endpoint-value-v1':
        from q_frontier_value import specification as q_frontier_specification
        declarations,defs,rules,_=q_frontier_specification()
    elif plan['schema']=='Typed-Q-one-edge-endpoint-value-closed-source-r2-v1':
        from q_frontier_value_r2 import specification as q_frontier_specification
        declarations,defs,rules,_=q_frontier_specification()
    elif plan['schema']=='Typed-Q-one-edge-endpoint-value-closed-source-r3-v1':
        from q_frontier_value_r3 import specification as q_frontier_specification
        declarations,defs,rules,_=q_frontier_specification()
    elif plan['schema']=='Typed-Q-parent-child-invocation-lifecycle-v1':
        from q_lifecycle import specification as q_lifecycle_specification
        declarations,defs,rules=q_lifecycle_specification()
    elif plan['schema']=='Typed-Q-parent-child-invocation-lifecycle-r2-v1':
        from q_lifecycle_r2 import specification as q_lifecycle_specification
        declarations,defs,rules=q_lifecycle_specification()
    elif plan['schema']=='Typed-Q-persistent-accepted-argument-snapshot-v1':
        from q_arguments import specification as q_arguments_specification
        declarations,defs,rules=q_arguments_specification()
    elif plan['schema']=='Typed-Q-persistent-accepted-argument-snapshot-r2-v1':
        from q_arguments_r2 import specification as q_arguments_specification
        declarations,defs,rules=q_arguments_specification()
    elif plan['schema']=='Typed-Q-persistent-accepted-argument-snapshot-r3-v1':
        from q_arguments_r3 import specification as q_arguments_specification
        declarations,defs,rules=q_arguments_specification()
    elif plan['schema']=='Typed-Q-terminal-row-offset-continuity-v1':
        from q_frontier_rows import specification as q_rows_specification
        declarations,defs,rules=q_rows_specification()
    elif plan['schema']=='Typed-Q-all-current-raw-endpoint-classification-v1':
        from q_raw_scope import specification as q_raw_scope_specification
        declarations,defs,rules=q_raw_scope_specification()
    elif plan['schema']=='Typed-Q-terminal-accepted-vector-continuity-v1':
        from q_frontier_vector import specification as q_frontier_vector_specification
        declarations,defs,rules=q_frontier_vector_specification()
    elif plan['schema']=='Typed-Q-native-raw-record-capture-support-v1':
        from q_capture_support import specification as q_capture_support_specification
        declarations,defs,rules=q_capture_support_specification()
    elif plan['schema']=='Typed-Q-watched-raw-record-closed-value-v1':
        from q_record_value import specification as q_record_value_specification
        declarations,defs,rules,_,_=q_record_value_specification()
    elif plan['schema']=='Typed-Q-native-watched-capture-array-v1':
        from q_capture_array import specification as q_capture_array_specification
        declarations,defs,rules=q_capture_array_specification()
    elif plan['schema']=='Typed-Q-captured-vector-value-certificate-v1':
        from q_certificate import specification as q_certificate_specification
        declarations,defs,rules,_,_=q_certificate_specification()
    elif plan['schema']=='Typed-Q-parent-write-exponent-DONE-ownership-v1':
        from q_output_ownership import specification as q_output_specification
        declarations,defs,rules=q_output_specification()
    elif plan['schema']=='Typed-Q-parent-write-exponent-DONE-ownership-r2-v1':
        from q_output_ownership_r2 import specification as q_output_specification
        declarations,defs,rules=q_output_specification()
    elif plan['schema']=='Typed-Q-parent-write-exponent-DONE-ownership-r3-v1':
        from q_output_ownership_r3 import specification as q_output_specification
        declarations,defs,rules=q_output_specification()
    elif plan['schema']=='Typed-Q-compiled-source-exponent-projection-v1':
        from q_exponent import specification as q_exponent_specification
        declarations,defs,rules=q_exponent_specification()
    elif plan['schema']=='Typed-Q-post-DONE-reference-source-ownership-v1':
        from q_done_support import specification as q_done_support_specification
        declarations,defs,rules=q_done_support_specification()
    elif plan['schema']=='Typed-Q-post-DONE-reference-value-certificate-v1':
        from q_done_certificate import specification as q_done_certificate_specification
        declarations,defs,rules,_,_=q_done_certificate_specification()
    elif plan['schema']=='Typed-Q-main-source-bound-value-endpoints-v1':
        from q_main import specification as q_main_specification
        declarations,defs,rules=q_main_specification()
    elif plan['schema']=='Typed-Q-first-normalizer-rejection-classification-v1':
        from normalizer_faults import specification as normalizer_fault_specification
        declarations,defs,rules=normalizer_fault_specification()
    elif plan['schema']=='Typed-Q-live-raw-endpoint-guard-v1':
        from q_endpoint_links import specification as endpoint_links_specification
        declarations,defs,rules=endpoint_links_specification()
    elif plan['schema']=='Typed-Q-main-concrete-compatibility-witness-v1':
        from q_main_witness import specification as main_witness_specification
        declarations,defs,rules=main_witness_specification()
    elif plan['schema']=='Typed-Q-common-trace-source-links-v1':
        from q_trace_links import specification as trace_links_specification
        declarations,defs,rules=trace_links_specification()
    elif plan['schema']=='Typed-Q-one-reset-three-state-bootstrap-v1':
        from q_trace_bootstrap import specification as trace_bootstrap_specification
        declarations,defs,rules=trace_bootstrap_specification()
    elif plan['schema']=='Typed-Q-raw-value-closed-composition-v1':
        from q_raw import specification as q_raw_specification
        declarations,defs,rules,_=q_raw_specification()
    elif plan['schema']=='Typed-Q-native-normalizer-product-v1':
        from q_normalizer_product import specification as q_normalizer_product_specification
        declarations,defs,rules=q_normalizer_product_specification()
    elif plan['schema']=='Typed-Q-parent-column-binding-r2-v1':
        from q_columns_r2 import specification as q_columns_specification
        declarations,defs,rules=q_columns_specification()
    else:raise ValueError('Unsupported arithmetic rule type')
    if plan['rules']!=rules or plan['order']!=list(rules) or plan['declarations']!=declarations:
        raise ValueError('Changed canonical local arithmetic rule')
    if plan.get('external_facts') or plan.get('whole_Q_operator_proved') or plan.get('whole_machine_theorem'):
        raise ValueError('Unexpected provider or completion claim')
    if (HERE/(plan['component']+'/history.smt2')).read_text()!=defs:
        raise ValueError('Changed arithmetic definitions')
    label=plan['component'];native={'bounds':'mac','postscale':'mul','tile-any':'tile','tile-cases':'tile','tile-held':'tile','word-semantics':'mac','word-algebra':'mac','wide-bounds':'mac','word-scalar':'mac'}.get(label,label)
    if label=='q-main-witness':
        from q_main_witness import body_files,PROVIDERS
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json','q-main-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=PROVIDERS or
            plan.get('scope')!='Stronger synthetic-model compatibility context; no reachability or released-image operating claim'):
            raise ValueError('Changed concrete compatibility context')
        return
    if label in ['normalizer-faults','q-trace-bootstrap','q-trace-links','q-endpoint-links']:
        if label=='normalizer-faults':
            from normalizer_faults import body_files,PROVIDERS
            source='selector-SOURCES.json';sv='selector/native.sv';extra={'selector/compile.ys'}
        elif label=='q-endpoint-links':
            from q_endpoint_links import body_files,PROVIDERS
            source='../model-consumption/connected-SOURCES.json';sv='../model-consumption/connected/projection-native.sv';extra={'q-engine/INSTANCE-BINDING.json'}
        elif label=='q-trace-links':
            from q_trace_links import body_files,PROVIDERS
            source='../model-consumption/connected-SOURCES.json';sv='../model-consumption/connected/projection-native.sv';extra={'q-engine/INSTANCE-BINDING.json'}
        else:
            from q_trace_bootstrap import body_files,PROVIDERS
            source='../model-consumption/connected-SOURCES.json';sv='../model-consumption/connected/projection-native.sv';extra={'q-engine/INSTANCE-BINDING.json'}
        bodies=body_files();paths={source,sv,*extra,*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!=source or
            plan['native_source']!=sv or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=PROVIDERS):raise ValueError('Changed rejection/bootstrap source context')
        return
    if label=='q-main':
        from q_main import body_files,PROVIDERS
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=PROVIDERS or
            plan.get('positive_context_scope')!='Compatibility with the complete current invariant context; not reachability from reset' or
            plan.get('retained_query_RAM_claimed')is not False):raise ValueError('Changed main Q endpoint scope/context')
        return
    if label in ['q-done-support','q-done-certificate']:
        if label=='q-done-support':
            from q_done_support import body_files,PROVIDERS
            extra=set()
        else:
            from q_done_certificate import body_files,PROVIDERS,root,specification as done_certificate_spec
            _,_,_,audit,applications=done_certificate_spec();extra={label+'/APPLICATIONS.json'}
            if (plan.get('root_assumptions')!=root()or plan.get('applications')!=applications or
                json.loads((HERE/(label+'/APPLICATIONS.json')).read_text())!=audit):raise ValueError('Changed completed reference numerical closure')
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json',*extra,*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=PROVIDERS):
            raise ValueError('Changed completed-reference source/value context')
        return
    if label=='q-exponent':
        from q_exponent import source_binding,verify_replay
        bodies=['q-exponent/native.smt2','q-exponent/history.smt2']
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/datapath.sv',
            'q-exponent/native.sv','q-exponent/compile.ys','q-exponent/native.json','q-exponent/SOURCE-BINDING.json','q-exponent/REPLAY.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='q-exponent/native.sv'or plan['checks_file']!=label+'-CHECKS.json' or
            json.loads((HERE/'q-exponent/SOURCE-BINDING.json').read_text())!=source_binding()):raise ValueError('Changed actual compiled exponent source cone')
        verify_replay();return
    if label in ['q-output-ownership','q-output-ownership-r2','q-output-ownership-r3']:
        if label=='q-output-ownership-r3':
            from q_output_ownership_r3 import body_files,PROVIDERS,output_binding,exponent_binding
            from q_exponent import parent_definitions
            binding=dict(output=output_binding(),exponent=exponent_binding(),
                control_step='Full native product implies the literal MAC-update weakening; native normalization and exponent transitions retained')
            if (HERE/'q-exponent/parent-bind.smt2').read_text()!=parent_definitions():raise ValueError('Changed exponent-input specialization')
        elif label=='q-output-ownership-r2':
            from q_output_ownership_r2 import body_files,PROVIDERS,output_binding,exponent_binding,parent_definitions
            binding=dict(output=output_binding(),exponent=exponent_binding())
            if (HERE/'q-exponent/parent-bind.smt2').read_text()!=parent_definitions():raise ValueError('Changed exponent-input specialization')
        else:
            from q_output_ownership import body_files,PROVIDERS,source_binding
            binding=source_binding()
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json',label+'/SOURCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if label=='q-output-ownership-r3':paths.add('../model-consumption/OPERAND-STEP.json')
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('providers')!=PROVIDERS or json.loads((HERE/(label+'/SOURCE-BINDING.json')).read_text())!=binding):
            raise ValueError('Changed actual Q write/exponent/completion source context')
        return
    if label in ['q-capture-array','q-certificate']:
        if label=='q-capture-array':
            from q_capture_array import body_files,PROVIDERS
            extra=set()
        else:
            from q_certificate import body_files,PROVIDERS,root,specification as certificate_spec
            _,_,_,audit,applications=certificate_spec();extra={label+'/APPLICATIONS.json'}
            if (plan.get('root_assumptions')!=root()or plan.get('applications')!=applications or
                json.loads((HERE/(label+'/APPLICATIONS.json')).read_text())!=audit):raise ValueError('Changed guarded vector certificate composition')
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json',*extra,*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=PROVIDERS):
            raise ValueError('Changed captured vector source/value context')
        return
    if label=='q-record-value':
        from q_record_value import body_files,PROVIDERS,root,specification as record_spec
        _,_,_,audit,applications=record_spec();bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json',label+'/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('providers')!=PROVIDERS or plan.get('root_assumptions')!=root() or plan.get('applications')!=applications or
            json.loads((HERE/(label+'/APPLICATIONS.json')).read_text())!=dict(root_assumptions=root(),applications=audit)):
            raise ValueError('Changed watched capture/source/value composition')
        return
    if label=='q-capture-support':
        from q_capture_support import body_files,PROVIDERS
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json','../model-consumption/parentcapture-PLAN.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('providers')!=PROVIDERS or plan.get('old_providers')!=['parentcapture']):raise ValueError('Changed source-only Q record capture support')
        return
    if label in ['q-lifecycle','q-lifecycle-r2','q-arguments','q-arguments-r2','q-arguments-r3','q-frontier-rows','q-raw-scope']:
        if label=='q-raw-scope':
            from q_raw_scope import body_files,PROVIDERS
            extra={'../model-consumption/OPERAND-STEP.json'}
        elif label=='q-lifecycle-r2':
            from q_lifecycle_r2 import body_files,PROVIDERS
            extra=set()
        elif label=='q-lifecycle':
            from q_lifecycle import body_files,PROVIDERS
            extra=set()
        elif label=='q-frontier-rows':
            from q_frontier_rows import body_files,PROVIDERS
            extra={'../model-consumption/tilemeta-PLAN.json'}
            if plan.get('old_providers')!=['tilemeta']:raise ValueError('Changed row-offset provider')
        elif label=='q-arguments-r2':
            from q_arguments_r2 import body_files,PROVIDERS
            extra={'../model-consumption/parentcapture-PLAN.json'}
            if plan.get('old_providers')!=['parentcapture']:raise ValueError('Changed argument snapshot provider')
        elif label=='q-arguments-r3':
            from q_arguments_r3 import body_files,PROVIDERS
            extra={'../model-consumption/parentcapture-PLAN.json'}
            if plan.get('old_providers')!=['parentcapture']:raise ValueError('Changed argument snapshot provider')
        else:
            from q_arguments import body_files,PROVIDERS
            extra={'../model-consumption/parentcapture-PLAN.json'}
            if plan.get('old_providers')!=['parentcapture']:raise ValueError('Changed argument snapshot provider')
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if label in ['q-frontier-rows','q-raw-scope']:
            paths.discard('selector-SOURCES.json');paths.discard('selector/native.sv');paths.add('../model-consumption/connected/projection-native.sv')
        paths.update(extra)
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=PROVIDERS):
            raise ValueError('Changed parent/child lifecycle context')
        return
    if label in ['q-frontier-value','q-frontier-value-r2','q-frontier-value-r3']:
        if label=='q-frontier-value-r3':
            from q_frontier_value_r3 import body_files,root,specification as frontier_spec,PROVIDERS
        elif label=='q-frontier-value-r2':
            from q_frontier_value_r2 import body_files,root,specification as frontier_spec,PROVIDERS
        else:
            from q_frontier_value import body_files,root,specification as frontier_spec,PROVIDERS
        _,_,_,audit=frontier_spec();bodies=body_files()
        expected_audit=dict(root_assumptions=root(),applications=audit)if label=='q-frontier-value'else audit
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
            'q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json',label+'/APPLICATIONS.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('providers')!=PROVIDERS or plan.get('root_assumptions')!=root() or
            json.loads((HERE/(label+'/APPLICATIONS.json')).read_text())!=expected_audit):
            raise ValueError('Changed one-edge source/value composition')
        return
    if label in ['q-emit','q-frontier-control','q-frontier-vector']:
        if label=='q-emit':
            from q_emit import body_files
            providers=['q-prefix-r3']
            extra=['q-prefix-r3-PLAN.json']
        elif label=='q-frontier-vector':
            from q_frontier_vector import body_files,PROVIDERS
            providers=PROVIDERS;extra=['q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in providers]]
        else:
            from q_frontier_control import body_files,PROVIDERS
            providers=PROVIDERS;extra=['q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in providers]]
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',*extra,*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('providers')!=providers):raise ValueError('Changed Q output/frontier support context')
        return
    if label in ['q-raw','q-raw-r2']:
        if label=='q-raw-r2':
            from q_raw_r2 import body_files,root,specification as raw_spec,NEW_PROVIDERS
        else:
            from q_raw import body_files,root,specification as raw_spec,NEW_PROVIDERS
        from q_engine import definitions as qe_def,binding
        from q_meta_safety import definitions as ms_def,record
        _,_,_,audit=raw_spec();bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json','q-meta-safety/INSTANCE-BINDING.json',label+'/APPLICATIONS.json',*[x+'-PLAN.json'for x in NEW_PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('providers')!=NEW_PROVIDERS or plan.get('root_assumptions')!=root() or plan.get('runtime_domain')!='qc-live; terminal frontier still required' or
            json.loads((HERE/(label+'/APPLICATIONS.json')).read_text())!=dict(root_assumptions=root(),applications=audit) or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding() or
            (HERE/'q-meta-safety/history.smt2').read_text()!=ms_def()):raise ValueError('Changed raw Q source/premise composition')
        return
    if label=='q-terminal':
        from q_write_source import binding
        from q_normalizer_product import definitions as product_def,source_binding
        bodies=['../model-consumption/connected/native.smt2','selector/native.smt2','q-normalizer-product/history.smt2','q-terminal/history.smt2']
        paths={'../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv','q-normalizer-product-PLAN.json','q-normalizer-product/SOURCE-BINDING.json','q-terminal/WRITE-SOURCE.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-terminal-CHECKS.json' or plan.get('providers')!=['q-normalizer-product'] or
            (HERE/'q-normalizer-product/history.smt2').read_text()!=product_def() or json.loads((HERE/'q-normalizer-product/SOURCE-BINDING.json').read_text())!=source_binding() or
            json.loads((HERE/'q-terminal/WRITE-SOURCE.json').read_text())!=binding()):raise ValueError('Changed terminal frontier/source-defined Q write')
        return
    if label=='q-scope':
        from q_engine import definitions as qe_def,binding
        from q_columns_r3 import specification as qc_spec
        bodies=['../model-consumption/connected/native.smt2','../model-consumption/parentcapture/history.smt2','q-engine/history.smt2','q-columns-r3/history.smt2','q-scope/history.smt2']
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-scope-CHECKS.json' or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-columns-r3/history.smt2').read_text()!=qc_spec()[1] or
            json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed source runtime guard/aliases')
        return
    if label=='q-routing-r2':
        from q_routing_r2 import body_files
        from q_engine import definitions as qe_def,binding
        from q_job_r2 import specification as qj_spec
        bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/tilemeta-PLAN.json','q-engine/INSTANCE-BINDING.json','q-job-r2-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-routing-r2-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture','tilemeta'] or plan.get('new_providers')!=['q-job-r2'] or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-job-r2/history.smt2').read_text()!=qj_spec()[1] or
            json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed actual Q job/engine result routing')
        return
    if label in ['q-job','q-job-r2']:
        bodies=['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2',label+'/history.smt2']
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture'] or plan.get('new_providers')!=[]):raise ValueError('Changed accepted Q job/prefix history')
        return
    if label=='q-metadata':
        from q_metadata import body_files
        from q_engine import definitions as qe_def,binding
        bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/tilemeta-PLAN.json','q-engine/INSTANCE-BINDING.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-metadata-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture','tilemeta'] or plan.get('new_providers')!=[] or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed fixed Q metadata/frame binding')
        return
    if label=='q-prefix-r3':
        from q_prefix_r3 import body_files,specification as spec,applications,guarded_application
        from q_engine import definitions as qe_def,binding
        from q_columns_r3 import specification as qc_spec
        from q_model import definitions as qm_def
        from q_identity import definitions as qi_def
        from q_prefix_control import definitions as qpc_def
        _,_,_,audit,premises=spec();bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json',
            'q-columns-r3-PLAN.json','q-model-PLAN.json','q-identity-PLAN.json','q-prefix-laws-PLAN.json','q-prefix-control-PLAN.json','q-prefix-r3/APPLICATIONS.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-prefix-r3-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture','macmodel'] or plan.get('new_providers')!=['q-columns-r3','q-model','q-identity','q-prefix-laws','q-prefix-control'] or
            plan.get('provider_facts')!=__import__('q_prefix_r2').provider_facts() or plan.get('applications')!=applications() or plan.get('guarded_application')!=guarded_application() or
            plan.get('root_step_assumptions')!=audit['root_assumptions'] or plan.get('engine_step_premises')!=premises or json.loads((HERE/'q-prefix-r3/APPLICATIONS.json').read_text())!=audit or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-columns-r3/history.smt2').read_text()!=qc_spec()[1] or
            (HERE/'q-model/history.smt2').read_text()!=qm_def() or (HERE/'q-identity/history.smt2').read_text()!=qi_def()[0] or
            (HERE/'q-prefix-control/history.smt2').read_text()!=qpc_def() or json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed closed fixed-Q prefix composition/premise closure')
        return
    if label=='q-prefix-control':
        from q_prefix_control import body_files
        from q_engine import definitions as qe_def,binding
        from q_columns_r3 import specification as qc_spec
        from q_identity import definitions as qi_def
        bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-identity-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-prefix-control-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture'] or plan.get('new_providers')!=['q-columns-r3','q-identity'] or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-columns-r3/history.smt2').read_text()!=qc_spec()[1] or
            (HERE/'q-identity/history.smt2').read_text()!=qi_def()[0] or json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed prefix owner/column continuity')
        return
    if label=='q-normalizer-product':
        from q_normalizer_product import source_binding
        bodies=['../model-consumption/connected/native.smt2','selector/native.smt2','q-normalizer-product/history.smt2']
        paths={'../model-consumption/connected-SOURCES.json','selector-SOURCES.json','selector/native.sv','q-normalizer-product/SOURCE-BINDING.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-normalizer-product-CHECKS.json' or
            json.loads((HERE/'q-normalizer-product/SOURCE-BINDING.json').read_text())!=source_binding()):raise ValueError('Changed native normalizer product/source binding')
        return
    if label in ['meta-safety','meta-safety-r2']:
        from prefix_control import transition
        from frame import definitions as frame_def
        weak,manifest=transition()
        bodies=['prefix/native.smt2','prefix/control-step.smt2','frame/history.smt2',label+'/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','frame-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or plan['native_source']!='prefix/native.sv' or
            plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=['frame'] or
            (HERE/'prefix/control-step.smt2').read_text()!=weak or json.loads((HERE/'prefix/CONTROL-STEP.json').read_text())!=manifest or
            (HERE/'frame/history.smt2').read_text()!=frame_def()[0]):raise ValueError('Changed metadata legality context/providers')
        return
    if label in ['q-prefix','q-prefix-r2']:
        if label=='q-prefix-r2':
            from q_prefix_r2 import body_files,provider_facts
        else:
            from q_prefix import body_files,provider_facts
        from q_engine import definitions as qe_def,binding
        from q_columns_r3 import specification as qc_spec
        from q_model import definitions as qm_def
        from q_identity import definitions as qi_def
        bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-model-PLAN.json','q-identity-PLAN.json','q-prefix-laws-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture','macmodel'] or plan.get('new_providers')!=['q-columns-r3','q-model','q-identity','q-prefix-laws'] or plan.get('provider_facts')!=provider_facts() or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-columns-r3/history.smt2').read_text()!=qc_spec()[1] or
            (HERE/'q-model/history.smt2').read_text()!=qm_def() or (HERE/'q-identity/history.smt2').read_text()!=qi_def()[0] or
            json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed fixed Q integer prefix composition')
        return
    if label=='q-prefix-laws':
        from q_prefix_laws import body_files
        from q_model import definitions as qm_def
        bodies=body_files();paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-prefix-laws-CHECKS.json' or
            (HERE/'q-model/history.smt2').read_text()!=qm_def()):raise ValueError('Changed independent Q-prefix defining laws')
        return
    if label=='q-identity':
        from q_identity import body_files,provider_fact
        from q_engine import definitions as qe_def,binding
        from q_columns_r3 import specification as qc_spec
        from q_model import definitions as qm_def
        bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json','q-model-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-identity-CHECKS.json' or
            plan.get('old_providers')!=['parentcapture','macmodel'] or plan.get('new_providers')!=['q-columns-r3','q-model'] or plan.get('provider_facts')!=[provider_fact()] or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-columns-r3/history.smt2').read_text()!=qc_spec()[1] or
            (HERE/'q-model/history.smt2').read_text()!=qm_def() or json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed accepted Q vector/row identity')
        return
    if label=='q-model':
        from q_model import body_files
        from q_engine import definitions as qe_def,binding
        from q_columns_r3 import specification as qc_spec
        bodies=body_files()
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/macmodel-PLAN.json','q-engine/INSTANCE-BINDING.json','q-columns-r3-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!='q-model-CHECKS.json' or
            plan.get('old_providers')!=['macmodel'] or plan.get('new_providers')!=['q-columns-r3'] or
            (HERE/'q-engine/history.smt2').read_text()!=qe_def() or (HERE/'q-columns-r3/history.smt2').read_text()!=qc_spec()[1] or
            json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed fixed Q model/input binding')
        return
    if label in ['q-columns','q-columns-r2','q-columns-r3']:
        from q_engine import binding,definitions as qe_def
        bodies=['../model-consumption/connected/native.smt2','../model-consumption/operand-step.smt2','../model-consumption/parentcapture/history.smt2','q-engine/history.smt2',label+'/history.smt2']
        paths={'../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','../model-consumption/OPERAND-STEP.json','../model-consumption/parentcapture-PLAN.json','q-engine/INSTANCE-BINDING.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('old_providers')!=['parentcapture'] or
            plan.get('engine_specialization')!='q-engine/INSTANCE-BINDING.json' or (HERE/'q-engine/history.smt2').read_text()!=qe_def() or
            json.loads((HERE/'q-engine/INSTANCE-BINDING.json').read_text())!=binding()):raise ValueError('Changed native parent column/history binding')
        return
    if label in ['norm-algorithm','norm-algorithm-r2']:
        from norm_algorithm import provider_facts
        from norm_shift import definitions as ns_def
        from norm_capture import transition
        from norm_capture_r2 import specification as nc_spec
        weak,manifest=transition();providers=['norm-capture-r2','shift','norm-shift','selector']
        bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture-r2/history.smt2','norm-shift/history.smt2',label+'/history.smt2']
        paths={'selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json',*[p+'-PLAN.json'for p in providers],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='selector-SOURCES.json' or
            plan['native_source']!='selector/native.sv' or plan['checks_file']!=label+'-CHECKS.json' or plan.get('providers')!=providers or plan.get('provider_facts')!=provider_facts() or
            (HERE/'norm-capture/control-step.smt2').read_text()!=weak or json.loads((HERE/'norm-capture/CONTROL-STEP.json').read_text())!=manifest or
            (HERE/'norm-capture-r2/history.smt2').read_text()!=nc_spec()[1] or (HERE/'norm-shift/history.smt2').read_text()!=ns_def()[0]):
            raise ValueError('Changed whole-normalizer algorithm refinement/context')
        return
    if label=='norm-shift':
        from norm_shift import source_binding
        from norm_capture import transition
        from norm_capture_r2 import specification as nc_spec
        weak,manifest=transition()
        bodies=['selector/native.smt2','norm-capture/control-step.smt2','norm-capture-r2/history.smt2','norm-shift/history.smt2']
        paths={'selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json','norm-capture-r2-PLAN.json','shift-PLAN.json','norm-shift/INSTANCE-BINDING.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='selector-SOURCES.json' or
            plan['native_source']!='selector/native.sv' or plan['checks_file']!='norm-shift-CHECKS.json' or plan.get('providers')!=['norm-capture-r2','shift'] or
            (HERE/'norm-capture/control-step.smt2').read_text()!=weak or json.loads((HERE/'norm-capture/CONTROL-STEP.json').read_text())!=manifest or
            (HERE/'norm-capture-r2/history.smt2').read_text()!=nc_spec()[1] or
            json.loads((HERE/'norm-shift/INSTANCE-BINDING.json').read_text())!=source_binding()):raise ValueError('Changed normalizer helper composition/context')
        return
    if label in ['norm-capture','norm-capture-r2']:
        from norm_capture import transition
        weak,manifest=transition()
        bodies=['selector/native.smt2','norm-capture/control-step.smt2',label+'/history.smt2']
        paths={'selector-SOURCES.json','selector/native.sv','selector/compile.ys','norm-capture/CONTROL-STEP.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='selector-SOURCES.json' or
            plan['native_source']!='selector/native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            (HERE/'norm-capture/control-step.smt2').read_text()!=weak or
            json.loads((HERE/'norm-capture/CONTROL-STEP.json').read_text())!=manifest):
            raise ValueError('Changed normalizer vector ownership context')
        return
    if label=='engine-integer-r2':
        from engine_integer_r2 import applications,specification as spec,PROVIDERS
        _,theorem,_,root,audit=spec()
        bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2','sum-frame/history.smt2','math-fold-r2/history.smt2','engine-integer-r2/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','engine-integer-r2/APPLICATIONS.json',*[p+'-PLAN.json'for p in PROVIDERS],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or plan['native_source']!='prefix/native.sv' or
            plan['checks_file']!='engine-integer-r2-CHECKS.json' or plan.get('providers')!=PROVIDERS or plan.get('applications')!=applications() or
            plan.get('root_assumptions')!=root or plan.get('root_theorem')!=theorem or
            json.loads((HERE/'engine-integer-r2/APPLICATIONS.json').read_text())!=dict(root_assumptions=root,applications=audit,engine_join_uses_only_checked_provider_consequences=True)):
            raise ValueError('Changed closed integer fact application')
        return
    if label=='engine-integer':
        bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2','sum-frame/history.smt2','math-fold-r2/history.smt2','engine-integer/history.smt2']
        providers=['prefix-r2','tile-held','frame','lineage','sum-frame','math-fold-r2','frame-integer','word-scalar']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json',*[p+'-PLAN.json'for p in providers],*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or
            plan['native_source']!='prefix/native.sv' or plan['checks_file']!='engine-integer-CHECKS.json' or
            plan.get('providers')!=providers or plan.get('semantic_provider')!='frame-integer-function'):raise ValueError('Changed integer engine provider application')
        return
    if label in ['math-fold','math-fold-r2']:
        from prefix_control import transition
        from lineage import definitions as lineage_definitions
        weak,manifest=transition()
        bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','lineage/history.smt2',label+'/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json','lineage-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or plan['native_source']!='prefix/native.sv' or
            plan['checks_file']!=label+'-CHECKS.json' or plan.get('inductive_providers')!=['prefix-r2','lineage'] or plan.get('component_provider')!='tile-held' or
            plan.get('semantic_providers')!=['word16x10-function','word48-add26-function'] or
            (HERE/'prefix/control-step.smt2').read_text()!=weak or json.loads((HERE/'prefix/CONTROL-STEP.json').read_text())!=manifest or
            (HERE/'lineage/history.smt2').read_text()!=lineage_definitions()[0]):raise ValueError('Changed mathematical fold providers/context')
        return
    if label=='sum-frame':
        from prefix_control import transition
        from frame import definitions as frame_definitions
        from lineage import definitions as lineage_definitions
        weak,manifest=transition()
        bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2','sum-frame/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json','lineage-PLAN.json','frame-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or
            plan['native_source']!='prefix/native.sv' or plan['checks_file']!='sum-frame-CHECKS.json' or
            plan.get('inductive_providers')!=['prefix-r2','lineage','frame'] or plan.get('component_provider')!='tile-held' or
            plan.get('binding_policy')!='same-state-clock-and-functional-histories' or
            (HERE/'prefix/control-step.smt2').read_text()!=weak or json.loads((HERE/'prefix/CONTROL-STEP.json').read_text())!=manifest or
            (HERE/'frame/history.smt2').read_text()!=frame_definitions()[0] or (HERE/'lineage/history.smt2').read_text()!=lineage_definitions()[0]):raise ValueError('Changed sum/frame provider context')
        return
    if label=='lineage':
        from prefix_control import transition
        from frame import definitions as frame_definitions
        weak,manifest=transition()
        bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or
            plan['native_source']!='prefix/native.sv' or plan['checks_file']!='lineage-CHECKS.json' or
            plan.get('inductive_provider')!='prefix-r2-PLAN.json' or plan.get('component_provider')!='tile-held-PLAN.json' or
            plan.get('binding_policy')!='exact-four-source-tiles-with-fixed-BV2/BV4-parameters' or
            (HERE/'prefix/control-step.smt2').read_text()!=weak or json.loads((HERE/'prefix/CONTROL-STEP.json').read_text())!=manifest or
            (HERE/'frame/history.smt2').read_text()!=frame_definitions()[0]):raise ValueError('Changed lineage context/provider application')
        return
    if label in ['frame-algebra','frame-integer']:
        from frame import definitions as frame_definitions
        bodies=['prefix/native.smt2','frame/history.smt2',label+'/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys',*bodies}
        if label=='frame-integer':paths.add('frame-PLAN.json')
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or
            plan['native_source']!='prefix/native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            (HERE/'frame/history.smt2').read_text()!=frame_definitions()[0]):
            raise ValueError('Changed actual postscale frame function context')
        if label=='frame-integer':
            if plan.get('semantic_provider')!='frame-integer-function' or plan.get('inductive_provider')!='frame-PLAN.json':raise ValueError('Missing exact frame integer providers')
        return
    if label in ['prefix','prefix-r2','frame']:
        from prefix_control import transition
        weak,manifest=transition()
        bodies=['prefix/native.smt2','prefix/control-step.smt2',label+'/history.smt2']
        paths={'prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json',*bodies}
        if (plan['bodies']!=bodies or set(plan['inputs'])!=paths or plan['source_manifest']!='prefix-SOURCES.json' or
            plan['native_source']!='prefix/native.sv' or plan['checks_file']!=label+'-CHECKS.json' or
            (HERE/'prefix/control-step.smt2').read_text()!=weak or json.loads((HERE/'prefix/CONTROL-STEP.json').read_text())!=manifest):
            raise ValueError('Changed prefix transition weakening/model context')
        return
    if label=='lanes':
        from lanes import context_paths,definitions
        bodies,paths=context_paths()
        if (plan['bodies']!=bodies or set(plan['inputs'])!=set(paths) or
            plan['source_manifest']!='../model-consumption/connected-SOURCES.json' or
            plan['native_source']!='../model-consumption/connected/projection-native.sv' or
            plan['checks_file']!='lanes-CHECKS.json'):
            raise ValueError('Unexpected all64 model/formula context')
        _,_,rows=definitions()
        if json.loads((HERE/'lanes/INSTANCE-COVERAGE.json').read_text())['lanes']!=rows:
            raise ValueError('Changed/missing native lane coverage')
        return
    bodies=[native+'/native.smt2',label+'/history.smt2']
    expected_paths={native+'-SOURCES.json',native+'/native.sv',native+'/compile.ys',*bodies}
    if (plan['bodies']!=bodies or set(plan['inputs'])!=expected_paths or
        plan['source_manifest']!=native+'-SOURCES.json' or plan['native_source']!=native+'/native.sv' or
        plan['checks_file']!=label+'-CHECKS.json'):
        raise ValueError('Unexpected arithmetic model/formula context')


def _check(label,recorded=False,only_rules=None):
    plan=validate(HERE,label+'-PLAN.json');shape(plan)
    from arithmetic import compile_model,MAC,MUL
    if label=='q-exponent':
        from q_exponent import source_binding,verify_replay
        source_binding();verify_replay()
    elif label in ['lanes','q-columns','q-columns-r2','q-columns-r3','q-model','q-identity','q-prefix-laws','q-prefix-r2','q-prefix-r3','q-prefix','q-prefix-control','q-normalizer-product','q-terminal','q-metadata','q-job','q-job-r2','q-routing-r2','q-scope','q-raw','q-raw-r2','q-emit','q-frontier-control','q-frontier-vector','q-frontier-value','q-frontier-value-r2','q-frontier-value-r3','q-lifecycle','q-lifecycle-r2','q-arguments','q-arguments-r2','q-arguments-r3','q-frontier-rows','q-raw-scope','q-capture-support','q-record-value','q-capture-array','q-certificate','q-output-ownership','q-output-ownership-r2','q-output-ownership-r3','q-done-support','q-done-certificate','q-main','q-main-witness','q-trace-bootstrap','q-trace-links','q-endpoint-links']:
        from lanes import verify_sources
        verify_sources()
        if label in ['q-normalizer-product','q-terminal','q-lifecycle','q-lifecycle-r2','q-arguments','q-arguments-r2','q-arguments-r3','q-capture-support','q-record-value','q-capture-array','q-certificate','q-output-ownership','q-output-ownership-r2','q-output-ownership-r3','q-done-support','q-done-certificate','q-main']:
            from selector import TOP,HELPER
            compile_model('selector',TOP,{'normalizer_pipeline.sv':[TOP],'candidate.sv':[HELPER]})
    elif label in ['prefix','prefix-r2','frame','frame-algebra','frame-integer','lineage','sum-frame','math-fold','math-fold-r2','engine-integer','engine-integer-r2','meta-safety','meta-safety-r2']:
        from prefix_control import TOP
        compile_model('prefix',TOP,{'cluster-engine.sv':[TOP],'cluster-tile.sv':[MAC,MUL,'board1_projection_tile16']})
    elif label in ['selector','norm-capture','norm-capture-r2','norm-shift','norm-algorithm','norm-algorithm-r2','normalizer-faults']:
        from selector import TOP,HELPER
        compile_model('selector',TOP,{'normalizer_pipeline.sv':[TOP],'candidate.sv':[HELPER]})
    elif label=='shift':
        from shift import TOP
        compile_model(label,TOP,{'candidate.sv':[TOP]})
    elif label in ['tile','tile-any','tile-cases','tile-held']:
        from tile import TOP
        compile_model('tile',TOP,{'cluster-tile.sv':[MAC,TOP]})
    elif label in ['bounds','word-semantics','word-algebra','wide-bounds','word-scalar']:compile_model('mac',MAC,{'cluster-tile.sv':[MAC]})
    elif label=='postscale':compile_model('mul',MUL,{'cluster-tile.sv':[MUL]})
    else:compile_model(label,MAC if label=='mac' else MUL,{'cluster-tile.sv':[MAC if label=='mac' else MUL]})
    if label=='frame-integer':
        # Reconstruct every provider; a saved checked:true is not an import.
        from word_derivation import verify
        verify('frame-integer-function',False)
        check('frame',True)
    if label=='lineage':
        check('prefix-r2',True);check('tile-held',True)
        from tile_bindings import record
        record('tile-held')
    if label=='sum-frame':
        for provider in ['prefix-r2','lineage','frame','tile-held']:check(provider,True)
    if label in ['math-fold','math-fold-r2']:
        for provider in ['prefix-r2','lineage','tile-held']:check(provider,True)
        from word_derivation import verify
        for provider in ['word16x10-function','word48-add26-function']:verify(provider,False)
    if label=='engine-integer':
        for provider in plan['providers']:check(provider,True)
        from word_derivation import verify
        verify('frame-integer-function',False)
    if label=='engine-integer-r2':
        for provider in plan['providers']:check(provider,True)
        from fact_composition import verify_providers
        verify_providers(plan['applications'])
    if label in ['norm-shift','norm-algorithm','norm-algorithm-r2']:
        for provider in plan['providers']:check(provider,True)
    if label in ['q-terminal','q-emit','q-frontier-control','q-frontier-vector','q-lifecycle','q-lifecycle-r2','q-arguments','q-arguments-r2','q-arguments-r3','q-frontier-rows','q-capture-support']:
        for provider in plan['providers']:check(provider,True)
    if label in ['q-arguments','q-arguments-r2','q-arguments-r3','q-frontier-rows','q-capture-support']:
        from check_derivation import check as operand_check
        for provider in plan['old_providers']:operand_check(provider,True)
    if label=='q-raw-scope':
        from operand_step import verify
        verify()
    if label=='q-capture-support':
        from q_engine import verify
        verify()
    if label in ['q-record-value','q-capture-array','q-certificate','q-output-ownership','q-output-ownership-r2','q-output-ownership-r3','q-done-support','q-done-certificate','q-main','q-main-witness','normalizer-faults','q-trace-bootstrap','q-trace-links','q-endpoint-links']:
        from fact_composition import verify_providers
        for provider in plan['providers']:check(provider,True)
        if label in ['q-record-value','q-certificate','q-done-certificate']:verify_providers(plan['applications'])
    if label=='q-output-ownership-r3':
        from operand_step import verify
        verify()
    if label in ['q-raw','q-raw-r2','q-frontier-value','q-frontier-value-r2','q-frontier-value-r3']:
        from source_contracts import verify
        verify()
        for provider in plan['providers']:check(provider,True)
    if label in ['meta-safety','meta-safety-r2']:
        for provider in plan['providers']:check(provider,True)
    if label in ['q-columns','q-columns-r2','q-columns-r3','q-model','q-identity','q-prefix','q-prefix-r2','q-prefix-r3','q-prefix-control','q-metadata','q-routing-r2']:
        from q_engine import verify
        verify()
        from check_derivation import check as operand_check
        for provider in plan['old_providers']:operand_check(provider,True)
        for provider in plan.get('new_providers',[]):check(provider,True)
    if label in ['q-job','q-job-r2']:
        from check_derivation import check as operand_check
        operand_check('parentcapture',True)
    body='\n'.join((HERE/x).read_text()for x in plan['bodies'])
    controls={}
    for name,edit in [('desired-result-oracle','oracle'),('wrong-next-state','state'),('missing-rule','missing'),('extra-assumption-body','body')]:
        bad=copy.deepcopy(plan);first=next(iter(bad['rules']))
        if edit=='oracle':bad['rules'][first]['assumptions'].append('(= desired actual)')
        if edit=='state':bad['rules'][first]['conclusion']='true'
        if edit=='missing':del bad['rules'][first]
        if edit=='body':bad['bodies'].append('false-premise.smt2');bad['inputs']['false-premise.smt2']=sha(b'(assert false)')
        try:shape(bad)
        except (ValueError,KeyError):controls[name]='rejected after logical reconstruction'
        else:raise ValueError('Invalid arithmetic rule accepted')
    count=0
    selected=set(plan['rules'] if only_rules is None else only_rules)
    if selected-set(plan['rules']):raise ValueError('Unknown selected provider rule')
    requested=set(selected)
    def close(name):
        for dependency in plan['rules'][name].get('dependencies',[]):
            if dependency not in plan['rules']:raise ValueError('Untyped external provider dependency')
            if plan['rules'][dependency].get('expected','unsat')!='unsat':raise ValueError('A SAT example cannot be imported')
            if dependency not in selected:selected.add(dependency);close(dependency)
    for name in list(selected):close(name)
    if recorded:
        checks=json.loads((HERE/plan['checks_file']).read_text())
        if checks['plan_sha256']!=sha((HERE/(label+'-PLAN.json')).read_bytes()):raise ValueError('Stale arithmetic checks')
        for name,rule in plan['rules'].items():
            if name not in selected:continue
            row=checks['rules'][name];directory=HERE/Path(row['receipt']).parent
            canonical=query(plan,name,body).encode();raw=(directory/row.get('engine_log','z3.log')).read_bytes()
            if (directory/'query.smt2').read_bytes()!=canonical or row['query_sha256']!=sha(canonical):raise ValueError('Changed canonical arithmetic query')
            engine=canonical
            if row.get('solver')=='z3-uniform-mul':
                if label not in ['tile','tile-any','tile-cases','tile-held'] or name!='preserved-3':raise ValueError('Wrong abstraction application')
                from abstract_multiply import transform
                engine=transform(canonical.decode()).encode()
            elif row.get('solver')=='cvc5-int':
                engine=canonical.replace(b'(bv2int ',b'(ubv_to_int ')
            elif row.get('solver')=='z3-uniform-arithmetic':
                if label!='tile-any' or name!='preserved-4':raise ValueError('Wrong addition abstraction application')
                from abstract_multiply import transform_arithmetic
                engine=transform_arithmetic(canonical.decode()).encode()
            elif row.get('solver')=='z3-pruned-mul48':
                if label!='frame' or not name.startswith('preserved-'):raise ValueError('Wrong pruned multiplication abstraction application')
                from pruned_arithmetic import transform
                engine=transform(canonical.decode()).encode()
            elif row.get('solver')=='z3-prefix-abstract':
                if not ((label in ['q-prefix-r2','q-prefix-r3'] and name in ['preserved-0','preserved-1']) or (label in ['q-raw','q-raw-r2'] and name=='joined-raw-Q-value')):raise ValueError('Wrong pure-prefix abstraction application')
                from prefix_abstraction import transform
                engine=transform(canonical.decode()).encode()
            elif row.get('solver')=='z3-prefix-abstract-mul':
                if not ((label=='q-prefix-r3' and name in ['preserved-0','preserved-1']) or (label=='q-raw-r2' and name=='joined-raw-Q-value') or (label in ['q-frontier-value','q-frontier-value-r2','q-frontier-value-r3'] and name=='next-output-raw-Q-value')):raise ValueError('Wrong uniform integer multiplication abstraction')
                from prefix_arithmetic_abstraction import transform
                engine=transform(canonical.decode()).encode()
            elif row.get('solver')=='z3-prefix-abstract-words':
                if label!='q-prefix-r3' or name!='preserved-0':raise ValueError('Wrong pure signed-word abstraction')
                from prefix_word_abstraction import transform
                engine=transform(canonical.decode()).encode()
            elif row.get('solver')=='z3-prefix-native-abstract':
                if (label,name)not in [('q-frontier-value-r3','next-output-raw-Q-value'),('q-record-value','watched-raw-record-value')]:raise ValueError('Wrong native function forgetting application')
                from native_function_abstraction import transform
                engine=transform(canonical.decode()).encode()
            elif row.get('solver')=='z3-certificate-transport':
                if label not in ['q-certificate','q-done-certificate'] or name!='preserved':raise ValueError('Wrong record relation forgetting application')
                from native_function_abstraction import transport_relation
                engine=transport_relation(canonical.decode()).encode()
            elif row.get('solver')=='z3-pruned':
                if label!='engine-integer-r2':raise ValueError('Wrong definitional-pruning application')
                from pruned_arithmetic import prune_only
                engine=prune_only(canonical.decode()).encode()
            if ((directory/row.get('engine_query_file','query.smt2')).read_bytes()!=engine or
                row.get('engine_query_sha256',sha(engine))!=sha(engine)):
                raise ValueError('Changed arithmetic engine query or unsound abstraction')
            expected=rule.get('expected','unsat')
            if raw.strip()!=expected.encode() or row['log_sha256']!=sha(raw) or not row['passed']:raise ValueError('Unproved arithmetic rule '+name)
            count+=1
    return dict(component=label,typed_shape_checked=True,queries_verified=count,controls=controls,
        selected_rule_count=len(requested),dependency_closure_count=len(selected),
        verified_rule_names=sorted(selected)if recorded else[],
        whole_Q_operator_proved=False,whole_machine_theorem=False)


_CHECK_SESSION=None


def check(label,recorded=False,only_rules=None):
    """Reuse a proved provider only inside one read-only dependency closure.

    No persistent checked flag/cache is imported. Every external invocation
    starts a fresh session and rechecks its files, formulas and raw receipts.
    Proof artifacts are immutable while this closure is being checked.
    """
    global _CHECK_SESSION
    outer=_CHECK_SESSION is None
    if outer:_CHECK_SESSION={}
    key=(label,recorded,None if only_rules is None else tuple(sorted(only_rules)))
    try:
        if key not in _CHECK_SESSION:_CHECK_SESSION[key]=_check(label,recorded,only_rules)
        return copy.deepcopy(_CHECK_SESSION[key])
    finally:
        if outer:_CHECK_SESSION=None


def check_many(requests,with_closure=False):
    """Check one immutable dependency bundle in a single transient session."""
    global _CHECK_SESSION
    if _CHECK_SESSION is not None:raise ValueError('A dependency bundle is already being checked')
    _CHECK_SESSION={}
    try:
        reports={label:check(label,True,names)for label,names in requests}
        census={}
        for (label,recorded,names),result in _CHECK_SESSION.items():
            if recorded:census.setdefault(label,set()).update(result['verified_rule_names'])
        return (reports,{l:sorted(names)for l,names in sorted(census.items())})if with_closure else reports
    finally:_CHECK_SESSION=None


if __name__=='__main__':
    recorded='--recorded'in sys.argv
    for label in [x for x in sys.argv[1:]if x!='--recorded']or['mac','mul']:
        print(json.dumps(check(label,recorded)))

"""Native held postscale pipeline from actual synchronous tile-read arguments.

This traces the dot/multiplier/exponent/row actually captured at stage0. It does
not assume the dot is a desired Q result. Its upstream value/row premise must
still be supplied by the qualified accepted-prefix and metadata providers.
"""
import json
from arithmetic import HERE,bv,both,eq,sext,sha,write_json
from prefix_control import TOP,S,n


def flag(i,state='a'):
    return f'(= ((_ extract {i} {i}) {n("scale_valid_q",state)}) #b1)'


def definitions():
    fields=[(f'{name}{i}',width)for i in [1,2,3]for name,width in [('D',35),('M',16),('E',8),('R',6)]]
    defs='(declare-datatypes () ((FrameHistory (frame-history '+' '.join(f'(fr-{name} (_ BitVec {width}))'for name,width in fields)+'))))\n'
    defs+='(define-fun frame-zero () FrameHistory (frame-history '+' '.join(bv(0,w)for _,w in fields)+'))\n'
    selected=n('selected_tile_q')
    for name,wire,width in [('D','tile_dot',35),('M','tile_multiplier',16),('E','tile_exponent',8)]:
        value=n(wire+'[3]')
        for t in reversed(range(3)):value=f'(ite (= {selected} {bv(t,2)}) {n(wire+f"[{t}]")} {value})'
        defs+=f'(define-fun frame-input-{name} ((a {S})) (_ BitVec {width}) {value})\n'
    low27='((_ zero_extend 2) ((_ extract 24 0) d))'
    high27='((_ sign_extend 17) ((_ extract 34 25) d))'
    mult18='((_ zero_extend 2) m)'
    for name,arg in [('low',low27),('high',high27)]:
        product=f'(bvmul {sext(arg,21)} {sext(mult18,30)})'
        defs+=f'(define-fun frame-{name} ((d (_ BitVec 35)) (m (_ BitVec 16))) (_ BitVec 48) {product})\n'
    raw=f'(bvadd ((_ zero_extend 2) (frame-low d m)) (bvshl ((_ sign_extend 2) (frame-high d m)) {bv(25,50)}))'
    defs+=f'(define-fun frame-raw ((d (_ BitVec 35)) (m (_ BitVec 16))) (_ BitVec 50) {raw})\n'
    values=[]
    for name,width in fields:
        base=name[0];stage=int(name[1:]);guard=both([n('advance'),flag(stage-1)])
        capture=(n('row_pipe_q[0]')if base=='R'else f'(frame-input-{base} a)')if stage==1 else f'(fr-{base}{stage-1} h)'
        values.append(f'(ite {guard} {capture} (fr-{name} h))')
    defs+=f'(define-fun frame-next ((a {S}) (h FrameHistory)) FrameHistory (ite (not {n("reset_n")}) frame-zero (frame-history '+' '.join(values)+')))\n'
    metadata=lambda stage:[eq(n(f'row_pipe_q[{stage}]'),f'(fr-R{stage} h)'),eq(n(f'exponent_pipe_q[{stage}]'),f'(fr-E{stage} h)')]
    clauses=[
        f'(=> {flag(1)} '+both([eq(n('low_operand_q'),'((_ zero_extend 2) ((_ extract 24 0) (fr-D1 h)))'),
            eq(n('high_operand_q'),'((_ sign_extend 17) ((_ extract 34 25) (fr-D1 h)))'),
            eq(n('scale_operand_q'),'((_ zero_extend 2) (fr-M1 h))'),*metadata(1)])+')',
        f'(=> {flag(2)} '+both([eq(n('low_product_q'),'(frame-low (fr-D2 h) (fr-M2 h))'),eq(n('high_product_q'),'(frame-high (fr-D2 h) (fr-M2 h))'),*metadata(2)])+')',
        f'(=> {flag(3)} '+both([eq(n('result_q'),'(frame-raw (fr-D3 h) (fr-M3 h))'),*metadata(3)])+')',
    ]
    for i,clause in enumerate(clauses):defs+=f'(define-fun frame-clause-{i} ((a {S}) (h FrameHistory)) Bool (=> {n("reset_n")} {clause}))\n'
    defs+=f'(define-fun frame-inv ((a {S}) (h FrameHistory)) Bool '+both([f'(frame-clause-{i} a h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda x:f'(|{TOP}_h| {x})';N=f'(|{TOP}_t| a an)'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h FrameHistory)','(declare-const hn FrameHistory)']
    context=[H('a'),H('an')]
    step=context+['(prefix-native-step a an)','(frame-inv a h)','(= hn (frame-next a h))']
    parts=[f'(frame-clause-{i} an hn)'for i in range(len(clauses))]
    result=both([eq(n('result_scaled_raw_o'),'(frame-raw (fr-D3 h) (fr-M3 h))'),
        eq(n('result_source_exponent_o'),'(fr-E3 h)'),
        eq(n('result_row_index_o'),f'(bvadd {n("row_base")} ((_ zero_extend 7) (fr-R3 h)))'),
        eq(n('result_last_o'),f'(= ((_ zero_extend 1) (fr-R3 h)) (bvsub {n("valid_lanes_q")} {bv(1,7)}))')])
    rules={'native-step-weakening':dict(assumptions=context+[N],conclusion='(prefix-native-step a an)'),
        'reset-base':dict(assumptions=context+[N,'(not '+n('reset_n')+')'],conclusion='(frame-inv an frame-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(frame-inv an hn)'),
        'consequence':dict(assumptions=[H('a'),n('reset_n'),'(frame-inv a h)',n('result_valid_o')],conclusion=result),
        'held-arguments':dict(assumptions=[H('a'),H('an'),'(prefix-native-step a an)','(frame-inv a h)',n('reset_n'),n('result_valid_o'),'(not '+n('result_ready_i')+')','(= hn (frame-next a h))'],
            conclusion='(= hn h)')}
    return declarations,defs,rules


def prepare():
    declarations,defs,rules=specification();d=HERE/'frame';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','frame/history.smt2'];paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json',*bodies]
    plan=dict(schema='Typed-Q-postscale-frame-v1',component='frame',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='frame-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'frame-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed postscale frame plan')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Frozen postscale tuple/value/held-argument induction on unchanged native clustered engine.')

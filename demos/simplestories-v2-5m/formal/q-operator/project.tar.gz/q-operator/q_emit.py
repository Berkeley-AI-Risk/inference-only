"""Completed fixed-model dot throughout EMIT, including pipeline fill cycles."""
import copy,json
from arithmetic import HERE,bv,eq,sha,write_json
from q_columns import ENGINE,n
from q_prefix_r3 import specification as prefix_spec,body_files as prefix_files


def specification():
    declarations,_,old,_,_=prefix_spec();rule=copy.deepcopy(old['completed-fixed-Q-dot'])
    valid=n(ENGINE+'result_valid_o')
    if rule['assumptions'].count(valid)!=1:raise ValueError('Changed prefix endpoint')
    rule['assumptions'].remove(valid);rule['assumptions'].append(eq(n(ENGINE+'state_q'),bv(4,3)))
    return declarations,'; The full owned Q dot is ready before the output pipeline first asserts VALID.\n',{'all-EMIT-completed-Q-dot':rule}


def body_files():return prefix_files()+['q-emit/history.smt2']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-emit';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv','q-prefix-r3-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-complete-EMIT-dot-v1',component='q-emit',bodies=bodies,source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-emit-CHECKS.json',
        providers=['q-prefix-r3'],external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-emit-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed EMIT dot support')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Completed dot support for all EMIT pipeline stages prepared.')

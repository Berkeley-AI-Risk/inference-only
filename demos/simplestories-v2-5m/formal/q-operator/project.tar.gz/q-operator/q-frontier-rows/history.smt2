; The row offset uses the captured engine group, not a free next-state group.

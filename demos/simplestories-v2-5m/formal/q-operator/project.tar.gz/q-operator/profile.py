"""Elementary independent integer lemmas for the Q arithmetic profile.

These do not by themselves connect RTL bit-vectors to integer multiplication.
That bridge and the current accepted-prefix ownership are separate obligations.
"""
import json
from arithmetic import HERE,MAC,both,sha,write_json,compile_model


def specification():
    declarations=['(declare-const a Int)','(declare-const w Int)',
        '(declare-const c Int)','(declare-const s Int)','(declare-const p Int)',
        '(declare-const m Int)','(declare-const low Int)','(declare-const high Int)']
    B=32767*511
    rules={
        'integer-product-bound':dict(assumptions=['(<= (- 32767) a)','(<= a 32767)','(<= (- 511) w)','(<= w 511)'],
            conclusion=f'(and (<= (- {B}) (* a w)) (<= (* a w) {B}))'),
        'dot-prefix-base':dict(assumptions=['(= c 0)','(= s 0)'],conclusion=f'(and (<= (- (* c {B})) s) (<= s (* c {B})))'),
        'dot-prefix-induction':dict(assumptions=['(<= 0 c)','(< c 256)',f'(<= (- (* c {B})) s)',f'(<= s (* c {B}))',f'(<= (- {B}) p)',f'(<= p {B})'],
            conclusion=f'(and (<= (- (* (+ c 1) {B})) (+ s p)) (<= (+ s p) (* (+ c 1) {B})))'),
        'dot-prefix-width':dict(assumptions=['(<= 0 c)','(<= c 256)',f'(<= (- (* c {B})) s)',f'(<= s (* c {B}))'],
            conclusion='(and (<= (- 4286447872) s) (<= s 4286447872) (< (- 17179869184) s) (< s 17179869184) (< (- 140737488355328) s) (< s 140737488355328))'),
        'scale-bound':dict(assumptions=['(<= (- 4286447872) s)','(<= s 4286447872)','(<= 1 m)','(<= m 32767)'],
            conclusion='(and (<= (- 140454037421824) (* s m)) (<= (* s m) 140454037421824) (< (- 562949953421312) (* s m)) (< (* s m) 562949953421312))'),
        'split-postscale-integer-identity':dict(assumptions=['(= s (+ low (* 33554432 high)))'],
            conclusion='(= (* s m) (+ (* low m) (* 33554432 (* high m))))'),
        'split-low-product-width':dict(assumptions=['(<= 0 low)','(< low 33554432)','(<= 1 m)','(<= m 32767)'],
            conclusion='(and (<= 0 (* low m)) (< (* low m) 140737488355328))'),
        'split-high-product-width':dict(assumptions=['(<= (- 512) high)','(<= high 511)','(<= 1 m)','(<= m 32767)'],
            conclusion='(and (< (- 140737488355328) (* high m)) (< (* high m) 140737488355328))'),
    }
    return declarations,'',rules


def prepare():
    compile_model('mac',MAC,{'cluster-tile.sv':[MAC]})
    declarations,defs,rules=specification();d=HERE/'bounds';d.mkdir(exist_ok=True)
    (d/'history.smt2').write_text(defs)
    bodies=['mac/native.smt2','bounds/history.smt2']
    paths=['mac-SOURCES.json','mac/native.sv','mac/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-integer-profile-v1',component='bounds',bodies=bodies,source_manifest='mac-SOURCES.json',native_source='mac/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='bounds-CHECKS.json',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'bounds-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed integer-profile plan')
    write_json(path,plan)


if __name__=='__main__':prepare()

"""Source-only watched normalizer vector provenance and argument stability."""
import json
from arithmetic import HERE,both,eq,sha,write_json
from q_normalizer_product import nn
from q_capture_support import specification as support_spec,body_files as support_files,scope


def specification():
    decl=support_spec()[0]
    root=support_spec()[2]['next-authoritative-record-comes-from-old-current-invocation']['assumptions']
    old='(select (nc-vec nc) watch)';new='(select (nc-vec ncn) watch)'
    captured='(concat '+nn('input_source_exponent_i')+' '+nn('input_raw_i')+')'
    retained=both(['(bvult watch (nc-count nc))',eq(new,old)])
    written=both([nn('record_write_enable'),eq(nn('input_row_index_i'),'watch'),eq(new,captured)])
    goal=both([scope(),eq('qan','qa'),'(or '+retained+' '+written+')'])
    return decl,'; Every authoritative watched record is retained or written from the actual current input.\n',{
        'next-watched-capture-is-retained-or-newly-written':dict(assumptions=root,conclusion=goal)}


def body_files():return support_files()+['q-capture-array/history.smt2']


PROVIDERS=['q-capture-support']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-capture-array';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-native-watched-capture-array-v1',component='q-capture-array',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-capture-array-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-capture-array-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed watched array provenance')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Actual capture-array retained/new selected record provenance prepared.')

; No current arbiter-health premise; actual prior EMIT cannot change accepted activation memory.

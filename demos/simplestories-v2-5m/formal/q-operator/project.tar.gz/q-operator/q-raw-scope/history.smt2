; No arbiter-health restriction on the current raw endpoint.

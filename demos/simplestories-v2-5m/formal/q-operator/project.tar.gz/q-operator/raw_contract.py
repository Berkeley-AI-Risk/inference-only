"""Literal all-current endpoint composition of the checked one-edge theorem.

This is a derived implication, not a fabricated additional solver UNSAT. The
root contains no current or previous arbiter-health premise. A checked source
lemma supplies previous nonfailure whenever a next raw endpoint is live.
"""
import json
from arithmetic import HERE,sha,write_json
from q_columns import A,n
from q_frontier_value_r3 import root as frontier_root,specification
from fact_composition import apply,flattened


def proposition():
    root=frontier_root();old_health=f'(not {n(A+"fail_q")})'
    if root.count(old_health)!=1:raise ValueError('Changed exact frontier health boundary')
    root.remove(old_health)
    application=dict(kind='engine',provider='q-raw-scope',rule='live-next-raw-has-previous-nonfailed-root',substitution={})
    facts,audit=apply(root,[application])
    available={x for formula in root+facts for x in flattened(formula)}
    needed={x for formula in frontier_root()for x in flattened(formula)}
    if not needed<=available:raise ValueError('Unclosed all-current raw theorem root')
    goal=specification()[2]['next-output-raw-Q-value']['conclusion']
    return dict(schema='Closed-all-current-raw-Q-implication-v1',root_assumptions=root,conclusion=goal,
        source_applications=audit,closed_component='q-frontier-value-r3',closed_component_root=frontier_root(),
        derivation='Checked source consequence, then modus ponens with the closed two-rule frontier component',
        no_current_or_previous_arbiter_health_assumption=True,arbitrary_current_private_VALID=True,
        common_reset_base_provider='q-raw-scope:raw-reset-base',
        trace_rule='At every subsequent edge apply this implication to previous/current native states and their actual functional histories',
        whole_Q_operator_proved=False,whole_machine_theorem=False)


def verify():
    from q_check import check
    # A root contract can be exported only after BOTH source and algebra rules
    # pass with every exact provider/source premise reconstructed.
    checks={label:check(label,True)for label in ['q-frontier-value-r3','q-raw-scope']}
    result=proposition()
    result['providers']={label:dict(plan_sha256=sha((HERE/(label+'-PLAN.json')).read_bytes()),
        checks_sha256=sha((HERE/(label+'-CHECKS.json')).read_bytes()),reconstructed=report)for label,report in checks.items()}
    return result


if __name__=='__main__':
    result=verify();write_json(HERE/'RAW-ALL-CURRENT-DERIVATION.json',result)
    print('Derived all-current raw endpoint implication; not the complete normalized Q operator.')

"""Forget four pure signed-word interpretations in the pending-product miter.

This is a solver overapproximation of the same canonical mathematical query.
Each fresh BV16/BV10→Int function can be interpreted as ordinary signed decode.
The paired actual/expected operand expressions use the same fresh function.
No source constraints or desired product assumptions are inserted.
"""
from arithmetic import signed
from prefix_arithmetic_abstraction import transform as arithmetic_transform,TOKEN

F16='q_prefix_signed16';F10='q_prefix_signed10'


def transform(text):
    for name in [F16,F10]:
        if any(m.group(0)in [name,'|'+name+'|']for m in TOKEN.finditer(text)):raise ValueError('Signed interpretation symbol not fresh')
    original=arithmetic_transform(text);changed=original
    substitutions=[(signed('(th-A th)',16),'('+F16+' (th-A th))'),
        (signed('(select vector column)',16),'('+F16+' (select vector column))'),
        (signed('(th-W th)',10),'('+F10+' (th-W th))'),
        (signed('(Q-weight model layer group row column)',10),'('+F10+' (Q-weight model layer group row column))')]
    for old,new in substitutions:
        if changed.count(old)!=1:raise ValueError('Exact unique signed operand interpretation required')
        changed=changed.replace(old,new,1)
    restored=changed
    for old,new in substitutions:
        if restored.count(new)!=1:raise ValueError('Ambiguous signed interpretation application')
        restored=restored.replace(new,old,1)
    if restored!=original:raise ValueError('Changed query outside the four pure word interpretations')
    return '(declare-fun '+F16+' ((_ BitVec 16)) Int)\n(declare-fun '+F10+' ((_ BitVec 10)) Int)\n'+changed

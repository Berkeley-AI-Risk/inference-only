"""Exact four-tile/64-lane source specialization, without a parent value oracle."""
import json
import re
from arithmetic import HERE,OPERANDS,MAC,sha,write_json,native_source
from lanes import ENGINE,verify_sources
from q_check import check


def record(contract='tile-cases'):
    if contract not in ['tile-cases','tile-held']:raise ValueError('Unsupported tile contract')
    verify_sources();source=(OPERANDS/'connected/projection-native.sv').read_text()
    begin=source.index('    generate for (tile=0; tile<4; tile=tile+1) begin : g_tile')
    end=source.index('    end endgenerate',begin)+len('    end endgenerate')
    instance=source[begin:end]
    expected={
        'clk':'clk','reset_n':'reset_n','kill_i':'kill','begin_i':'start_fire&&descriptor_ok',
        'valid_lanes_i':'tile_lanes','accept_i':'weight_fire','first_i':'column_q==0',
        'last_i':"column_q==columns_q-10'd1",'activation_i':'activation_i',
        'weights_i':'weight_data_i[tile*160+:160]',
        'metadata_write_i':'metadata_fire&&!metadata_error&&metadata_count_q[5:4]==tile',
        'metadata_lane_i':'metadata_count_q[3:0]','metadata_multiplier_i':'metadata_multiplier_i',
        'metadata_exponent_i':'exponent_sum[7:0]','read_i':'issue','read_lane_i':'issue_count_q[3:0]',
        'dot_o':'tile_dot[tile]','multiplier_o':'tile_multiplier[tile]','exponent_o':'tile_exponent[tile]',
        'done_o':'tile_done[tile]','fault_o':'tile_fault[tile]'}
    ports={k:re.sub(r'\s+','',v)for k,v in re.findall(r'\.(\w+)\(([^()]*)\)',instance)}
    if ports!=expected:raise ValueError('Actual source tile ports changed')
    native,rows=native_source({'cluster-tile.sv':['board1_projection_tile16']})
    if 'generate for (lane=0; lane<16; lane=lane+1) begin : g_lane'not in native:raise ValueError('Actual tile lane count changed')
    # Fixed source bodies and the all64 parent recurrence proof, not the names
    # alone, establish that these are instances of the proved component.
    checks=check(contract,True);lanechecks=check('lanes',True)
    return dict(schema='Typed-native-Q-tile-source-specialization-v1',actual_generate_block=instance,
        generate_block_sha256=sha(instance.encode()),projection_sha256=sha(source.encode()),native_tile_sources=rows,
        literal_ports=ports,tiles=[dict(tile=t,path=ENGINE+f'g_tile[{t}].u_tile.',
            lanes=[dict(watch_lane=l,global_lane=t*16+l,path=ENGINE+f'g_tile[{t}].u_tile.g_lane[{l}].u_mac.')for l in range(16)])for t in range(4)],
        common_clock='clk',actual_reset='engine reset_n; no extra reset or CLEAR-as-reset assumption',parameters={},
        component_contract=contract+'-PLAN.json',component_queries_verified=checks['queries_verified'],
        parent_native_recurrences='lanes-PLAN.json',parent_native_queries_verified=lanechecks['queries_verified'],
        application='Universal identical-source component behavior at each exact actual instance under its mapped inputs/reset; SMT frontend and source-level module substitution are trusted',
        caller_premises_open=['Current Q invocation/layer/group ownership','Exactly256 ordered accepted columns and FIRST/last alignment','Correct model and activation histories on the same events','Dot read/row, postscale and parent completion joins'],
        whole_Q_operator_proved=False,whole_machine_theorem=False)


if __name__=='__main__':
    result=record();write_json(HERE/'TILE-INSTANCE-BINDINGS.json',result)
    print(json.dumps(dict(source_specializations=4,MAC_lanes=64,component_queries=result['component_queries_verified'],whole_Q_operator_proved=False)))

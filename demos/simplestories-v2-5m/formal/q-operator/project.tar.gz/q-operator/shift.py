"""Actual shift pipeline against direct checked-shift and magnitude-RNE meaning."""
import json
from arithmetic import HERE,bv,both,eq,sext,sha,write_json,compile_model

TOP='board1_fixed_vector_rne_shift_pipeline1';S='|'+TOP+'_s|'
n=lambda path,s='a':f'(|{TOP}_n {path}| {s})'


def definitions():
    defs='(declare-datatypes () ((ShiftHistory (shift-history (sh-phase (_ BitVec 3)) (sh-value (_ BitVec 64)) (sh-count (_ BitVec 9))))))\n'
    defs+='(define-fun shift-zero () ShiftHistory (shift-history #b000 '+bv(0,64)+' '+bv(0,9)+'))\n'
    amount='((_ extract 5 0) (ite (bvslt (sh-count h) '+bv(0,9)+') (bvneg (sh-count h)) (sh-count h)))'
    defs+='(define-fun sh-amount ((h ShiftHistory)) (_ BitVec 6) '+amount+')\n'
    magnitude=f'(ite (= ((_ extract 63 63) (sh-value h)) #b1) (bvneg (sh-value h)) (sh-value h))'
    defs+='(define-fun sh-magnitude ((h ShiftHistory)) (_ BitVec 64) '+magnitude+')\n'
    rev=lambda x:'(concat '+' '.join('((_ extract %d %d) %s)'%(i,i,x)for i in range(128))+')'
    # SMT concat is binary; build a balanced-enough right-associated expression.
    def reverse(x):
        bits=['((_ extract %d %d) %s)'%(i,i,x)for i in range(128)]
        result=bits[-1]
        for bit in reversed(bits[:-1]):result='(concat '+bit+' '+result+')'
        return result
    source=f'(ite (bvslt (sh-count h) {bv(0,9)}) {reverse(sext("(sh-value h)",64))} (concat (sh-magnitude h) {bv(0,64)}))'
    defs+='(define-fun sh-source ((h ShiftHistory)) (_ BitVec 128) '+source+')\n'
    left=f'(bvshl {sext("(sh-value h)",64)} ((_ zero_extend 122) (sh-amount h)))'
    defs+='(define-fun sh-left ((h ShiftHistory)) (_ BitVec 128) '+left+')\n'
    fault=both(['true'])
    overflow=f'(distinct ((_ extract 127 64) (sh-left h)) (ite (= ((_ extract 63 63) (sh-left h)) #b1) {bv((1<<64)-1,64)} {bv(0,64)}))'
    fault=f'(or (bvslt (sh-count h) {bv(-62,9)}) (and (bvslt (sh-count h) {bv(0,9)}) {overflow}))'
    defs+='(define-fun sh-fault ((h ShiftHistory)) Bool '+fault+')\n'
    count64='((_ zero_extend 58) (sh-amount h))'
    quotient=f'(bvlshr (sh-magnitude h) {count64})'
    mask=f'(bvsub (bvshl {bv(1,64)} {count64}) {bv(1,64)})'
    remainder=f'(bvand (sh-magnitude h) {mask})'
    half=f'(bvlshr (bvshl {bv(1,64)} {count64}) {bv(1,64)})'
    inc=f'(and (distinct (sh-amount h) {bv(0,6)}) (or (bvugt {remainder} {half}) (and (= {remainder} {half}) (= ((_ extract 0 0) {quotient}) #b1))))'
    rounded=f'(bvadd {quotient} (ite {inc} {bv(1,64)} {bv(0,64)}))'
    right=f'(ite (= ((_ extract 63 63) (sh-value h)) #b1) (bvneg {rounded}) {rounded})'
    value=f'(ite (or (sh-fault h) (bvsgt (sh-count h) {bv(62,9)})) {bv(0,64)} (ite (bvslt (sh-count h) {bv(0,9)}) ((_ extract 63 0) (sh-left h)) {right}))'
    defs+='(define-fun sh-result ((h ShiftHistory)) (_ BitVec 64) '+value+')\n'
    phase='(sh-phase h)'
    fire=n('request_fire')
    nxtphase=f'(ite (= {phase} #b000) (ite {fire} #b001 #b000) (ite (= {phase} #b001) #b010 (ite (= {phase} #b010) #b011 (ite (= {phase} #b011) #b101 (ite {n("response_ready_i")} #b000 #b101)))))'
    nxt=f'(ite (or (not {n("rst_n")}) {n("clear_i")}) shift-zero (shift-history {nxtphase} (ite {fire} {n("request_value_i")} (sh-value h)) (ite {fire} {n("request_shift_i")} (sh-count h))))'
    defs+=f'(define-fun shift-next ((a {S}) (h ShiftHistory)) ShiftHistory {nxt})\n'
    low=f'(bvlshr (sh-source h) ((_ zero_extend 125) ((_ extract 2 0) (sh-amount h))))'
    shifted=f'(bvlshr (sh-source h) ((_ zero_extend 122) (sh-amount h)))'
    phase_active='(or (= (sh-phase h) #b001) (= (sh-phase h) #b010) (= (sh-phase h) #b011))'
    fields=[eq(n('source_q'),'(sh-source h)'),eq(n('amount_q'),'(sh-amount h)'),
        eq(n('left_q'),f'(bvslt (sh-count h) {bv(0,9)})'),eq(n('negative_q'),'(= ((_ extract 63 63) (sh-value h)) #b1)'),
        eq(n('bad_count_q'),f'(bvslt (sh-count h) {bv(-62,9)})'),eq(n('force_zero_q'),f'(bvsgt (sh-count h) {bv(62,9)})')]
    clauses=[f'(or (= {phase} #b000) (= {phase} #b001) (= {phase} #b010) (= {phase} #b011) (= {phase} #b101))',
        eq(n('state_q'),phase),eq(n('response_valid_o'),f'(= {phase} #b101)'),
        f'(=> {phase_active} '+both(fields)+')',
        f'(=> (= {phase} #b010) {eq(n("low_q"),low)})',
        f'(=> (= {phase} #b011) {eq(n("shifted_q"),shifted)})',
        f'(=> (= {phase} #b101) '+both([eq(n('response_result_o'),'(sh-result h)'),eq(n('response_fault_o'),'(sh-fault h)')])+')']
    for i,clause in enumerate(clauses):defs+=f'(define-fun shift-clause-{i} ((a {S}) (h ShiftHistory)) Bool (=> {n("rst_n")} {clause}))\n'
    defs+=f'(define-fun shift-inv ((a {S}) (h ShiftHistory)) Bool '+both([f'(shift-clause-{i} a h)'for i in range(len(clauses))])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda x:f'(|{TOP}_h| {x})';T=f'(|{TOP}_t| a an)'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const h ShiftHistory)','(declare-const hn ShiftHistory)']
    context=[H('a'),H('an'),T]
    step=context+['(shift-inv a h)','(= hn (shift-next a h))']
    parts=[f'(shift-clause-{i} an hn)'for i in range(len(clauses))]
    rules={'reset-base':dict(assumptions=context+['(not '+n('rst_n')+')'],conclusion='(shift-inv an shift-zero)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=p)for i,p in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(shift-inv an hn)'),
        'consequence':dict(assumptions=[H('a'),'(shift-inv a h)',n('rst_n'),n('response_valid_o')],
            conclusion=both([eq(n('response_result_o'),'(sh-result h)'),eq(n('response_fault_o'),'(sh-fault h)')]))}
    return declarations,defs,rules


def prepare():
    compile_model('shift',TOP,{'candidate.sv':[TOP]})
    declarations,defs,rules=specification();(HERE/'shift/history.smt2').write_text(defs)
    bodies=['shift/native.smt2','shift/history.smt2'];paths=['shift-SOURCES.json','shift/native.sv','shift/compile.ys',*bodies]
    plan=dict(schema='Typed-Q-shift-history-v1',component='shift',bodies=bodies,
        source_manifest='shift-SOURCES.json',native_source='shift/native.sv',inputs={x:sha((HERE/x).read_bytes())for x in paths},
        declarations=declarations,rules=rules,order=list(rules),checks_file='shift-CHECKS.json',external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'shift-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed shift plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Exact native pipelined shift/RNE and total accepted-request history prepared.')

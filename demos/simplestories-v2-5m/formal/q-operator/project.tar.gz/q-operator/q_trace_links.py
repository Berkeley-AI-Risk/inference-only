"""Native reset aliases and the empty-count three-state certificate bridge."""
import json
from arithmetic import HERE,bv,both,sha,write_json
from q_columns import TOP,S,n,ENGINE
from q_normalizer_product import NORM,NS,nn,dn
from q_main import specification as main_spec,body_files as main_files
from q_model import MODEL


def specification():
    decl=main_spec()[0]+['(declare-const tile (_ BitVec 2))','(declare-const lane (_ BitVec 4))']
    root=[f'(|{TOP}_h| a)',f'(|{NORM}_h| z)','(qn-bind a z)',f'(not {n("reset_n")})']
    aliases=[f'(not {n(ENGINE+"reset_n")})','(not (|lineage-native reset_n| a tile))',
        f'(not {nn("rst_n")})',f'(not {nn("u_shift.rst_n")})',f'(not {dn("rst_n")})']
    return decl,'; No history or numerical result assumptions in the native reset aliases.\n',{
        'common-reset-reaches-all-Q-component-instances':dict(assumptions=root,conclusion=both(aliases)),
        'empty-count-implies-active-capture-certificate':dict(assumptions=[f'(= (nc-count nc) {bv(0,10)})'],
            conclusion='(qcert-inv a z qa nc watch model)')}


def body_files():return main_files()+['q-trace-links/history.smt2']


PROVIDERS=['q-normalizer-product','q-certificate','q-trace-bootstrap']


def prepare():
    decl,defs,rules=specification();d=HERE/'q-trace-links';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=body_files();paths=['../model-consumption/connected-SOURCES.json','../model-consumption/connected/projection-native.sv',
        'q-engine/INSTANCE-BINDING.json',*[x+'-PLAN.json'for x in PROVIDERS],*bodies]
    plan=dict(schema='Typed-Q-common-trace-source-links-v1',component='q-trace-links',bodies=bodies,
        source_manifest='../model-consumption/connected-SOURCES.json',native_source='../model-consumption/connected/projection-native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=decl,rules=rules,order=list(rules),checks_file='q-trace-links-CHECKS.json',
        providers=PROVIDERS,external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'q-trace-links-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed common-trace source links')
    write_json(path,plan)

if __name__=='__main__':prepare();print('Actual common-reset aliases and the no-extra-reset empty-capture bridge frozen.')

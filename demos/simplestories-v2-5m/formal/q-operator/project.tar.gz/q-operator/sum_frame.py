"""The completed selected tile sum survives into each actual postscale slot.

Joins separately proved prefix, tile/read and pipeline histories in one native
clock/state context. No mathematical model dot or private word is assumed.
"""
import json
from arithmetic import HERE,bv,both,eq,sha,write_json
from frame import TOP,S,n,flag


def row_matches(stage,history='fr'):
    row=f'(fr-R{stage} {history})'
    return both([eq(f'((_ extract 5 4) {row})','tile'),eq(f'((_ extract 3 0) {row})','lane')])


def definitions():
    params=f'((a {S}) (th TileHistory) (fr FrameHistory) (lane (_ BitVec 4)) (tile (_ BitVec 2)))'
    active=eq(n('state_q'),bv(4,3))
    clauses=[f'(=> {both([active,flag(i),row_matches(i)])} (= (fr-D{i} fr) ((_ extract 34 0) (th-sum th))))'for i in [1,2,3]]
    defs='\n'.join(f'(define-fun sumframe-clause-{i} {params} Bool (=> {n("reset_n")} {clause}))'for i,clause in enumerate(clauses))+'\n'
    defs+=f'(define-fun sumframe-inv {params} Bool '+both([f'(sumframe-clause-{i} a th fr lane tile)'for i in range(3)])+')\n'
    return defs,clauses


def specification():
    defs,clauses=definitions();H=lambda state:f'(|{TOP}_h| {state})'
    declarations=[f'(declare-const a {S})',f'(declare-const an {S})','(declare-const pc PrefixHistory)','(declare-const pcn PrefixHistory)',
        '(declare-const th TileHistory)','(declare-const thn TileHistory)','(declare-const fr FrameHistory)','(declare-const frn FrameHistory)',
        '(declare-const lane (_ BitVec 4))','(declare-const tile (_ BitVec 2))']
    pcnext='(= pcn (prefix-next a pc))';thnext='(= thn (tile-next a th lane tile))';frnext='(= frn (frame-next a fr))'
    providers=['(prefix-inv a pc)','(prefix-inv an pcn)','(lineage-inv a pc th lane tile)','(lineage-inv an pcn thn lane tile)']
    step=[H('a'),H('an'),'(prefix-native-step a an)',*providers,pcnext,thnext,frnext,'(tile-inv a th lane tile)','(sumframe-inv a th fr lane tile)']
    parts=[f'(sumframe-clause-{i} an thn frn lane tile)'for i in range(3)]
    base=[H('a'),H('an'),f'(|{TOP}_t| a an)','(not '+n('reset_n')+')']
    root=[H('a'),n('reset_n'),'(prefix-inv a pc)','(lineage-inv a pc th lane tile)','(sumframe-inv a th fr lane tile)',
        '(frame-inv a fr)',n('result_valid_o'),row_matches(3)]
    rules={'reset-base':dict(assumptions=base,conclusion='(sumframe-inv an tile-zero frame-zero lane tile)'),
        **{'preserved-'+str(i):dict(assumptions=step,conclusion=part)for i,part in enumerate(parts)},
        'parts-join':dict(assumptions=parts,conclusion='(sumframe-inv an thn frn lane tile)'),
        'current-result-dot-argument':dict(assumptions=root,conclusion=both([
            eq('(fr-D3 fr)','((_ extract 34 0) (th-sum th))'),'(th-owned th)',eq('(pc-acc pc)',n('columns_q'))]))}
    return declarations,defs,rules


def prepare():
    declarations,defs,rules=specification();d=HERE/'sum-frame';d.mkdir(exist_ok=True);(d/'history.smt2').write_text(defs)
    bodies=['prefix/native.smt2','prefix/control-step.smt2','prefix-r2/history.smt2','frame/history.smt2','lineage/history.smt2','sum-frame/history.smt2']
    paths=['prefix-SOURCES.json','prefix/native.sv','prefix/compile.ys','prefix/CONTROL-STEP.json','prefix-r2-PLAN.json','tile-held-PLAN.json','lineage-PLAN.json','frame-PLAN.json',*bodies]
    plan=dict(schema='Typed-Q-sum-frame-composition-v1',component='sum-frame',bodies=bodies,source_manifest='prefix-SOURCES.json',native_source='prefix/native.sv',
        inputs={x:sha((HERE/x).read_bytes())for x in paths},declarations=declarations,rules=rules,order=list(rules),checks_file='sum-frame-CHECKS.json',
        inductive_providers=['prefix-r2','lineage','frame'],component_provider='tile-held',binding_policy='same-state-clock-and-functional-histories',
        external_facts={},whole_Q_operator_proved=False,whole_machine_theorem=False)
    path=HERE/'sum-frame-PLAN.json'
    if path.exists()and json.loads(path.read_text())!=plan:raise ValueError('Changed sum/frame plan; create a new revision')
    write_json(path,plan)


if __name__=='__main__':prepare();print('Frozen actual completed-sum to held postscale tuple composition with checked component providers.')

"""Replay declarative native SMT induction rules with bounded engine resources.

This is shared orchestration for source-bound setup checks. Its return value
reports the selected rules, not completion of a whole inference-only theorem.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import time

from checkpoint import atomic_bytes, atomic_json, snapshot
from prepare import sha,PUBLIC


def conjunction(items):
    return '(and '+' '.join(items)+')' if items else 'true'


def validate(project, plan_name='PLAN.json', ancestors=None):
    ancestors = set() if ancestors is None else set(ancestors)
    path = (project/plan_name).resolve()
    if path in ancestors: raise ValueError('Circular external proof dependency')
    ancestors.add(path)
    plan = json.loads((project/plan_name).read_text())
    for name, expected in plan['inputs'].items():
        if sha((project/name).read_bytes()) != expected:
            raise ValueError('Input identity changed: '+name)
    source = json.loads((project/plan.get('source_manifest','SOURCES.json')).read_text())
    for row in source['sources'].values():
        for key in ['baseline', 'public_export']:
            if sha((PUBLIC/row[key].removeprefix('production:')).read_bytes()) != row['sha256']:
                raise ValueError('Source identity changed: '+row[key])
    external = {}
    for alias, descriptor in plan.get('external_facts', {}).items():
        prior = validate(project, descriptor['plan'], ancestors)
        if (not set(prior['bodies']) <= set(plan['bodies']) or
                not set(prior['declarations']) <= set(plan['declarations'])):
            raise ValueError('External fact has a different source/formula context')
        checks = json.loads((project/prior.get('checks_file','CHECKS.json')).read_text())
        if checks['plan_sha256'] != sha((project/descriptor['plan']).read_bytes()):
            raise ValueError('External verification is stale')
        name = descriptor['rule'];rule = prior['rules'][name];result = checks['rules'][name]
        if rule.get('expected','unsat') != 'unsat' or not result['passed']:
            raise ValueError('External fact is not a proved implication')
        body = '\n'.join((project/filename).read_text() for filename in prior['bodies'])
        exact = query(prior,name,body).encode()
        query_path = Path(result['command'][-1]).resolve()
        if not query_path.is_relative_to((project/'queries').resolve()):
            raise ValueError('External engine query outside this project')
        raw = (query_path.parent/'z3.log').read_bytes()
        if (query_path.read_bytes() != exact or sha(exact) != result['query_sha256'] or
                sha(raw) != result['log_sha256'] or raw.strip() != b'unsat'):
            raise ValueError('External engine evidence differs from its exact rule')
        external[alias] = rule
    plan['_external_rules'] = external
    seen = set(external)
    for name in plan['order']:
        rule = plan['rules'][name]
        if not set(rule.get('dependencies', [])) <= seen:
            raise ValueError('Forward/circular proof dependency')
        seen.add(name)
    if seen != set(plan['rules']) | set(external):
        raise ValueError('Proof order omits rules')
    return plan


def query(plan, rule_name, body):
    rule = plan['rules'][rule_name]
    facts = list(rule['assumptions'])
    for name in rule.get('dependencies', []):
        prior = plan['rules'].get(name,plan.get('_external_rules',{}).get(name))
        if prior.get('expected', 'unsat') != 'unsat':
            raise ValueError('A satisfiable example is not a theorem import')
        facts.append('(=> '+conjunction(prior['assumptions'])+' '+prior['conclusion']+')')
    return ('(set-option :produce-models true)\n'+body+'\n'+
            '\n'.join(plan['declarations'])+'\n'+
            '\n'.join('(assert '+fact+')' for fact in facts)+'\n'+
            '(assert (not '+rule['conclusion']+'))\n(check-sat)\n')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('project', type=Path)
    ap.add_argument('--plan', default='PLAN.json')
    ap.add_argument('--rule', action='append')
    ap.add_argument('--model', action='store_true')
    args = ap.parse_args()
    project = args.project.resolve()
    plan = validate(project, args.plan)
    selected = args.rule or plan['order']
    state_path = project/'SETUP-STATE.json'
    body = '\n'.join((project/name).read_text() for name in plan['bodies'])
    identity = sha((project/args.plan).read_bytes())
    record_path = project/plan.get('checks_file','CHECKS.json')
    checks = json.loads(record_path.read_text()) if record_path.exists() else {}
    if checks.get('plan_sha256') != identity:
        checks = dict(plan_sha256=identity, rules={})
    for name in selected:
        rule = plan['rules'][name]
        for dep in rule.get('dependencies', []):
            if dep not in plan.get('_external_rules',{}) and not checks['rules'].get(dep, {}).get('passed'):
                raise ValueError('Unproved dependency: '+dep)
        state = json.loads(state_path.read_text())
        if state['active_owned_jobs']:
            raise ValueError('An owned job is already active')
        limit = state['per_query_seconds']
        now = datetime.now(timezone.utc)
        deadline = datetime.fromisoformat(state['deadline_utc'])
        if ((deadline-now).total_seconds() < limit+10 or
                state['solver_seconds']+limit+10 > state['solver_seconds_cap']):
            snapshot('Native setup resource stop before '+name)
            raise ValueError('Setup query would cross its resource bound')
        run = project/'queries'/(name+'-'+now.strftime('%Y%m%dT%H%M%S%fZ'))
        run.mkdir(parents=True)
        text = query(plan, name, body)
        if args.model:
            text += '(get-value ('+' '.join(plan['observations'])+'))\n'
        atomic_bytes(run/'query.smt2', text.encode())
        command = ['z3', '-memory:'+str(state['memory_mib']), '-T:'+str(limit), str(run/'query.smt2')]
        snapshot('Before native setup '+name)
        started = time.monotonic()
        with (run/'z3.log').open('w') as log:
            proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            state['active_owned_jobs'] = [dict(pid=proc.pid, rule=name, command=command)]
            state['status'] = 'running_native_setup_rule'
            atomic_json(state_path, state)
            try:
                code = proc.wait(timeout=limit+10)
            except subprocess.TimeoutExpired:
                # Only this runner's child is terminated.
                proc.kill()
                proc.wait()
                code = -1
        elapsed = time.monotonic()-started
        raw = (run/'z3.log').read_text()
        answers = re.findall(r'^(sat|unsat|unknown|timeout)$', raw, re.M)
        expected = rule.get('expected', 'unsat')
        result = dict(rule=name, passed=code == 0 and answers == [expected],
                      answers=answers, expected=expected, exit_code=code, seconds=elapsed,
                      query_sha256=sha(text.encode()), log_sha256=sha(raw.encode()),
                      command=command, plan_sha256=identity)
        atomic_json(run/'RESULT.json', result)
        state['active_owned_jobs'] = []
        state['solver_seconds'] += elapsed
        state['status'] = 'native_setup_rule_finished'
        atomic_json(state_path, state)
        checks['rules'][name] = dict(result, receipt=str((run/'RESULT.json').relative_to(project)))
        checks['all_rules_passed'] = all(checks['rules'].get(n, {}).get('passed', False) for n in plan['order'])
        checks['whole_model_consumption_proved'] = False
        atomic_json(record_path, checks)
        snapshot('Native setup result '+name)
        print(json.dumps(result), flush=True)
        if not result['passed']:
            return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

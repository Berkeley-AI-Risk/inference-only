"""Regenerate independent P16 numerical media using the pinned public integer oracle."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGES = ('self_attn.q_proj', 'self_attn.k_proj', 'self_attn.v_proj', 'self_attn.o_proj',
          'mlp.gate_proj', 'mlp.up_proj', 'mlp.down_proj')
NAMES = ['model.layers.0.' + stem + '.weight' for stem in STAGES]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify(reference, rom):
    import numpy as np
    if np.__version__ != '1.26.4':
        raise ValueError('use numpy 1.26.4 for the recorded oracle')
    pins = json.loads((ROOT/'provenance.json').read_text())
    for name, expected in pins['reference_source_hashes'].items():
        if sha((reference/name).read_bytes()) != expected:
            raise ValueError('different public reference: ' + name)
    sys.path.insert(0, str(reference))
    from quantization.oracle import IntegerLlama, QuantizedModel
    model = QuantizedModel.load(rom)
    fixtures = {}
    def put(name, values, width):
        mask = (1 << width) - 1
        fixtures[name+'.memh'] = sha(''.join(
            f'{int(i)&mask:0{(width+3)//4}x}\n' for i in values).encode())
    def scaled_pairs(matrix, vector):
        dots = matrix.value.astype(np.int64) @ vector.value.astype(np.int64)
        return [(int(i), int(e)) for i,e in zip(dots*matrix.multiplier.astype(np.int64),
                matrix.exponent.astype(np.int16)+vector.exponent-15)]
    def encoded(scores):
        return [((exp & 255) << 50) | (value & ((1<<50)-1)) for value,exp in scores]

    class Recorder(IntegerLlama):
        def _attention(self, query, layer):
            result = super()._attention(query, layer)
            for head,row in enumerate(result.value.reshape(4,64)):
                index = ((self.slot*17+self.position)*6+layer)*4+head
                attention[index] = ((int(result.exponent)&255)<<1024) | int.from_bytes(row.astype('<i2').tobytes(),'little')
            return result

        def _matvec(self, name, vector):
            result = super()._matvec(name,vector)
            if self.position==16 and name in NAMES:
                stage = NAMES.index(name)
                slot = self.slot*7+stage
                index = slot*682
                inputs[index:index+len(vector.value)] = vector.value
                outputs[index:index+len(result.value)] = result.value
                scores[index:index+len(result.value)] = encoded(scaled_pairs(model.tensors[name],vector))
                xe[slot],ye[slot] = vector.exponent,result.exponent
                if stage<3:
                    key = 'qkv'[stage]
                    put(key+str(self.slot),result.value,16)
                    exponents[key].append(result.exponent)
                    if stage==0:
                        put('x'+str(self.slot),vector.value,16)
                        exponents['x'].append(vector.exponent)
            return result

        def _argmax(self, vector):
            self.final_input = vector
            return super()._argmax(vector)

    size = 2*7*682
    inputs,outputs,scores = ([0]*size for _ in range(3))
    xe,ye = [0]*14,[0]*14
    exponents = {q:[] for q in 'xqkv'}
    kv,attention,head_exp = [0]*(3*6*17*18),[0]*(3*17*6*4),[]
    for slot,history in enumerate(json.loads((ROOT/'reference-histories.json').read_text())):
        machine = Recorder(model)
        machine.slot = slot
        if machine.position or any(machine.keys + machine.values):
            raise ValueError('nonempty starting history')
        sequence = history['inputs']
        tokens = [int(machine.forward_token(token)[0]) for token in sequence]
        if tokens[-2:] != history['outputs']:
            raise ValueError('oracle continuation mismatch')
        final = machine.final_input
        head = scaled_pairs(model.tensors['model.embed_tokens.weight'],final)
        if sha((json.dumps(head,separators=(',',':'))+'\n').encode()) != history['head_sha256']:
            raise ValueError('full head scores differ')
        head_exp.append(final.exponent)
        put('hx'+str(slot),final.value,16)
        put('head'+str(slot),encoded(head),58)
        if slot<2:
            put('prompt'+str(slot),sequence[:16],12)
        for layer in range(6):
            for pos,(key,value) in enumerate(zip(machine.keys[layer],machine.values[layer])):
                for h in range(2):
                    start=(((slot*6+layer)*17+pos)*2+h)*9
                    for offset,vector in ((0,key),(4,value)):
                        data=vector.value[h*64:(h+1)*64].astype('<i2').tobytes()
                        for beat in range(4):
                            kv[start+offset+beat]=int.from_bytes(data[beat*32:(beat+1)*32],'little')
                    kv[start+8]=(key.exponent&255) | ((value.exponent&255)<<8)
    put('equal_kv',kv,256)
    put('equal_attention',attention,1032)
    put('hxe',head_exp,8)
    for key,rows in exponents.items():
        put(key+'exp',rows,8)
    for name,rows,width in [('layer_in',inputs,16),('layer_out',outputs,16),('layer_raw',scores,58),
                             ('layer_ae',xe,8),('layer_ye',ye,8)]:
        put(name,rows,width)
    manifest=json.loads((ROOT/'rope.json').read_text())
    expected={n:h for n,h in manifest.items() if pins['members_by_sha256'][h]['role']=='independent integer reference or token IDs'}
    if expected != fixtures:
        raise ValueError('regenerated fixture set differs: '+str(sorted(n for n in expected.keys() | fixtures.keys() if expected.get(n)!=fixtures.get(n))))
    print(f'{len(fixtures)} model-derived files match; all three separate integer machines matched scores and tokens')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference',type=Path)
    parser.add_argument('rom',type=Path)
    args=parser.parse_args()
    verify(args.reference.resolve(),args.rom.resolve())

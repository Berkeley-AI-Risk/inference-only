#!/usr/bin/env python3
"""Hydrate, check, build and score the two frozen equal-P16 decoder revisions."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
RECORDED = json.loads((ROOT/'recorded.json').read_bytes())
ARMS = RECORDED['arms']
SEALS = RECORDED['native_builds']
PINS = json.loads((ROOT/'provenance.json').read_bytes())
FIELDS = re.compile(rb' (\w+)=(-?\d+)')
NUMERIC = re.compile(rb'^(KV_NUMERICAL|ATTN_ACCEPT|ATTN_QK|ATTN_PV|SEMANTIC_COMMIT|TOKEN) tape=(\d+) generation=(\d+) ')
TOP = 'two_tape_numerical_tb'
BASE_FLAGS = ['--timing','--assert','--top-module',TOP,'+define+TWO_TAPE_VERIFY','-Wall','-Wno-fatal']

def digest(data):
    return hashlib.sha256(data).hexdigest()

def require(ok,message):
    if not ok:
        raise ValueError(message)

def manifest(kind):
    data=(ROOT/(kind+'.json')).read_bytes()
    require(digest(data)==SEALS[kind]['manifest_sha256'],'packet seal differs')
    return json.loads(data)

def git_input(repo, name):
    if (repo/'.git').exists() or (repo/'HEAD').is_file():
        return subprocess.check_output(['git','-C',str(repo),'show',PINS['commit']+':'+name])
    return (repo/name).read_bytes()

def prepare(repo,out):
    require(not out.exists() or not any(out.iterdir()),'select an empty output directory')
    image=git_input(repo,PINS['model_image']['path'])
    require(digest(image)==PINS['model_image']['sha256'],'different public image')
    image_hex=b''.join(word[::-1].hex().encode()+b'\n' for word in (image[i:i+32] for i in range(0,len(image),32)))
    pages=b''.join(hashlib.sha256(image[i:i+4096].ljust(4096,b'\0')).digest() for i in range(0,len(image),4096))
    digests_hex=b''.join(pages[i:i+4].hex().encode()+b'\n' for i in range(0,len(pages),4))
    transforms={'image.memh':image_hex,'digests32.memh':digests_hex}
    for kind in SEALS:
        files=manifest(kind)
        for name,h in files.items():
            src=PINS['members_by_sha256'][h]
            if 'file' in src:
                data=(ROOT/src['file']).read_bytes()
            elif src['role']=='public git blob':
                data=git_input(repo,src['path'])
            else:
                data=transforms[src['format']]
            require(digest(data)==h,'member differs: '+name)
            path=out/kind/name
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(data)
        print(kind,len(files),'sealed regular files')

def check_files(root,kind):
    for name,h in manifest(kind).items():
        member=root/name
        require(not member.is_symlink() and digest(member.read_bytes())==h,'member differs: '+name)

def fixture(root):
    with tempfile.TemporaryDirectory() as td:
        vvp=Path(td)/'fixture.vvp'
        subprocess.run(['iverilog','-g2012','-s','fixture_probe','-o',str(vvp),'fixture_probe.sv'],cwd=root,check=True)
        for args,marker in [(None,'FIXTURE_PROBE_PASS'),('wrong_epoch','invalid fixture epoch'),('out_of_range','invalid K/V fixture coordinates'),('swap_inputs','signature')]:
            p=subprocess.run(['vvp',str(vvp)]+(['+'+args] if args else []),cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            require((p.returncode!=0)==bool(args) and marker in p.stdout.decode(),p.stdout.decode()[-900:])
            print('fixture',args or 'valid','matched expected exit',p.returncode)

def fields(line):
    return {k.decode():int(v) for k,v in FIELDS.findall(line)}

def score(lines,name):
    expected=ARMS[name]
    events=collections.defaultdict(list)
    streams=collections.defaultdict(hashlib.sha256)
    counts=collections.Counter()
    old=None
    after=collections.Counter()
    port=hashlib.sha256()
    pc=collections.Counter()
    raw=hashlib.sha256()
    for line in lines:
        raw.update(line)
        m=NUMERIC.match(line)
        if m:
            t,g=int(m[2]),int(m[3])
            key=f'{t}:{g}'
            alias=(0,1) if g>0 else (t,g)
            streams[key].update(line[:m.start(2)]+b'%d generation=%d '%alias+line[m.end():])
            counts[key]+=1
            if old==(t,g):
                after[m[1].decode()]+=1
            continue
        tag=line.split(b' ',1)[0].strip()
        if tag in (b'ROPE_TRACE',b'ROPE_DDR'):
            port.update(line)
            pc[tag.decode()]+=1
        elif tag in (b'TOKEN',b'L0_PUBLIC',b'L0_TOTAL',b'L0_CLEAR',b'INTEGRATED_PASS',b'EQUAL_RETIRE',b'OFFER',
                     b'ROPE_LAYER',b'ROPE_LOCK_INVALIDATED',b'ROPE_HELD',b'ROPE_OWNED_MISS',b'ROPE_MISS_RETURN'):
            row=fields(line)
            events[tag.decode()].append(row)
            if tag==b'L0_CLEAR':
                old=row['t'],row['gen']
    numerical={k:{'count':counts[k],'sha256':v.hexdigest()} for k,v in streams.items()}
    checks={'by_tape_numerical':numerical==expected['numerical'],
            'public_valid':events['L0_PUBLIC']==expected['public'],
            'totals':events['L0_TOTAL']==[expected['total']],
            'traffic_at_public':events['EQUAL_RETIRE']==expected['traffic_at_public'],
            'clear':events['L0_CLEAR']==expected['clear'],'zero_late_canceled_records':not after}
    release=expected['release']
    transfers=[{'c':r['c'],'t':r['tape'],'g':r['generation'],'token':r['id']} for r in events['TOKEN'] if r['c']>=release]
    checks['public_transfers']=transfers==expected['public']
    checks['matched_offers']=events['OFFER'][2:4]==[{'c':release,'t':0,'g':1},{'c':release+1,'t':1,'g':0}]
    checks['bench_pass']=events['INTEGRATED_PASS']==[{'mode':expected['total']['mode']}]
    if 'control_events' in expected:
        actual={k:v for k,v in events.items() if k.startswith('ROPE_')}
        checks['lookup_controls']=actual==expected['control_events']
        checks['older_port_timeline']=port.hexdigest()==expected['older_port_stream_sha256'] and dict(pc)==expected['older_port_stream_events']
    return {'arm':name,'checks':checks,'passed':all(checks.values()),'source_manifest_sha256':SEALS[expected['packet']]['manifest_sha256'],
            'public':events['L0_PUBLIC'],'latencies_from_first_offer':[r['c']-release for r in events['L0_PUBLIC']],
            'traffic_at_public':events['EQUAL_RETIRE'],'numerical':numerical,'clear':events['L0_CLEAR'],
            'canceled_records_after_clear':dict(after),'raw_output_sha256':raw.hexdigest()}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='action',required=True)
    p=sub.add_parser('prepare');p.add_argument('repo',type=Path);p.add_argument('out',type=Path)
    for action in ('fixture','lint','build'):
        p=sub.add_parser(action);p.add_argument('out',type=Path);p.add_argument('packet',choices=SEALS)
    p=sub.add_parser('run');p.add_argument('out',type=Path);p.add_argument('arm',choices=ARMS);p.add_argument('receipt',type=Path)
    p=sub.add_parser('score');p.add_argument('arm',choices=ARMS);p.add_argument('log',type=Path)
    a=parser.parse_args()
    if a.action=='prepare':
        prepare(a.repo.resolve(),a.out.resolve())
        return
    if a.action=='score':
        with a.log.open('rb') as log:
            receipt=score(log,a.arm)
        print(json.dumps(receipt,indent=2))
        require(receipt['passed'],'score mismatch')
        return
    kind=ARMS[a.arm]['packet'] if a.action=='run' else a.packet
    root=a.out.resolve()/kind
    check_files(root,kind)
    if a.action=='fixture':
        fixture(root)
    elif a.action=='lint':
        subprocess.run(['verilator','--lint-only']+BASE_FLAGS+['-f','batch_sources.f'],cwd=root,check=True)
    elif a.action=='build':
        require(not any(c.isspace() for c in str(root)), 'GNU Make requires a space-free build path')
        require(not (root/'obj').exists(),'use a fresh build directory')
        subprocess.run(['verilator','--binary','--build-jobs','1','--Mdir','obj']+BASE_FLAGS+
                       ['-MAKEFLAGS','OPT_FAST=-O2 OPT_SLOW=-O1 OBJCACHE=','-f','batch_sources.f'],cwd=root,check=True)
        binary=root/'obj'/('V'+TOP)
        (root/'build.json').write_text(json.dumps({'manifest':SEALS[kind]['manifest_sha256'],'binary':digest(binary.read_bytes())})+'\n')
    else:
        binary=root/'obj'/('V'+TOP)
        build=json.loads((root/'build.json').read_bytes())
        require(build=={'manifest':SEALS[kind]['manifest_sha256'],'binary':digest(binary.read_bytes())},'build seal differs')
        with a.receipt.open('x') as out:
            with subprocess.Popen([str(binary)]+ARMS[a.arm]['args'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT) as proc:
                try:
                    receipt=score(proc.stdout,a.arm)
                finally:
                    if sys.exc_info()[0] is not None:
                        proc.terminate()
            receipt['child_status']=proc.returncode
            receipt['binary_sha256']=build['binary']
            receipt['passed']=receipt['passed'] and proc.returncode==0
            json.dump(receipt,out,indent=2);out.write('\n')
        require(receipt['passed'],'native arm failed; see receipt')
        print(a.arm,receipt['latencies_from_first_offer'],'passed')
if __name__=='__main__':
    main()

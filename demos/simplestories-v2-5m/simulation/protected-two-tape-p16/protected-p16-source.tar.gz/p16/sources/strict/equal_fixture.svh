    reg [255:0] eq_kv[0:5507];
    reg [1031:0] eq_attention[0:1223];
    reg [15:0] oracle_q[0:511],oracle_x[0:511],oracle_k[0:255],oracle_v[0:255];
    reg [7:0] oracle_xe[0:1],oracle_qe[0:1],oracle_ke[0:1],oracle_ve[0:1];
    reg [11:0] eq_prompts[0:31];
    `include "equal_signatures.svh"
    function automatic integer fixture_slot(input integer t,input longint unsigned g);
        if(t==0 && g==1) fixture_slot=0;
        else if(t==1 && g==0) fixture_slot=1;
        else if((t==0 && g==2) || (t==1 && g==1)) fixture_slot=2;
        else begin $fatal(1,"invalid fixture epoch t=%0d g=%0d",t,g);fixture_slot=-1;end
    endfunction
    function automatic integer kv_index(input integer s,l,p,h,w);
        if(s<0 || s>2 || l<0 || l>=6 || p<0 || p>=(s==2 ? 1:17) || h<0 || h>=2 || w<0 || w>=9)
            $fatal(1,"invalid K/V fixture coordinates");
        kv_index=(((s*6+l)*17+p)*2+h)*9+w;
    endfunction
    function automatic integer attn_index(input integer s,p,l,h);
        if(s<0 || s>2 || l<0 || l>=6 || p<0 || p>=(s==2 ? 1:17) || h<0 || h>=4)
            $fatal(1,"invalid attention fixture coordinates");
        attn_index=((s*17+p)*6+l)*4+h;
    endfunction
    function automatic [255:0] ref_word(input integer t,input longint unsigned g,input integer l,p,h,w);
        ref_word=eq_kv[kv_index(fixture_slot(t,g),l,p,h,w)];
    endfunction
    function automatic [63:0] mix32(input reg [63:0] acc,input reg [31:0] value);
        mix32=(acc^{32'b0,value})*64'd1099511628211;
    endfunction
    function automatic [63:0] history_signature(input integer s);
        integer p,l,h,w,lane,k;
        reg [63:0] acc;
        reg [1055:0] wordx;
        begin
            acc=64'hcbf29ce484222325;
            for(l=0;l<6;l++) for(p=0;p<(s==2?1:17);p++)
                for(h=0;h<2;h++) for(w=0;w<9;w++) begin
                    wordx=eq_kv[kv_index(s,l,p,h,w)];
                    for(lane=0;lane<8;lane++) acc=mix32(acc,wordx[lane*32+:32]);
                end
            for(p=0;p<(s==2?1:17);p++) for(l=0;l<6;l++) for(h=0;h<4;h++) begin
                wordx=eq_attention[attn_index(s,p,l,h)];
                for(lane=0;lane<33;lane++) acc=mix32(acc,wordx[lane*32+:32]);
            end
            if(s<2) begin
                for(k=0;k<256;k++) acc=mix32(acc,oracle_x[s*256+k]);acc=mix32(acc,oracle_xe[s]);
                for(k=0;k<256;k++) acc=mix32(acc,oracle_q[s*256+k]);acc=mix32(acc,oracle_qe[s]);
                for(k=0;k<128;k++) acc=mix32(acc,oracle_k[s*128+k]);acc=mix32(acc,oracle_ke[s]);
                for(k=0;k<128;k++) acc=mix32(acc,oracle_v[s*128+k]);acc=mix32(acc,oracle_ve[s]);
                for(k=0;k<16;k++) acc=mix32(acc,eq_prompts[s*16+k]);
            end
            history_signature=acc;
        end
    endfunction
    task automatic load_equal_fixtures;
        begin
            $readmemh("equal_kv.memh",eq_kv);$readmemh("equal_attention.memh",eq_attention);
            $readmemh("prompt0.memh",eq_prompts,0,15);$readmemh("prompt1.memh",eq_prompts,16,31);
            $readmemh("x0.memh",oracle_x,0,255);$readmemh("x1.memh",oracle_x,256,511);
            $readmemh("q0.memh",oracle_q,0,255);$readmemh("q1.memh",oracle_q,256,511);
            $readmemh("k0.memh",oracle_k,0,127);$readmemh("k1.memh",oracle_k,128,255);
            $readmemh("v0.memh",oracle_v,0,127);$readmemh("v1.memh",oracle_v,128,255);
            $readmemh("xexp.memh",oracle_xe);$readmemh("qexp.memh",oracle_qe);
            $readmemh("kexp.memh",oracle_ke);$readmemh("vexp.memh",oracle_ve);
        end
    endtask
    task automatic bind_equal_fixtures;
        begin
            if(history_signature(0)!==EXPECT_A || history_signature(1)!==EXPECT_B ||
               history_signature(2)!==EXPECT_FRESH) $fatal(1,"equal fixture signature mismatch");
            $display("EQUAL_FIXTURES_BOUND a=%016h b=%016h fresh=%016h",EXPECT_A,EXPECT_B,EXPECT_FRESH);
        end
    endtask

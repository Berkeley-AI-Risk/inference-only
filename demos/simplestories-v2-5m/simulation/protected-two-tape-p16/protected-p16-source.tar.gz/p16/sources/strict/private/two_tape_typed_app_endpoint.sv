`timescale 1ns/1ps
`default_nettype none

// PRIVATE LOCAL normalized-endpoint candidate, not a boot/CDC/board result.
// Depends on the UNCHANGED public mapper_portable.sv and the unchanged
// board1_fixed_kv_shadow_match helper from the original typed app boundary.
// Virtual shadow stays19 bits; only the certified physical endpoint is20 bits.
// A captured ordinary endpoint offer is irrevocable until its handshake:
// late faults poison its eventual response, never invent acceptance/credit.
// A capability rejected BEFORE any raw offer may return a local fault/zero
// ACK. That ACK certifies rejection only, never a write success/persistence.
module two_tape_typed_app_endpoint #(
    parameter integer TAPE_COUNT = 2,
    parameter logic [255:0] MODEL_ID =
        256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0
) (
    input wire clk,
    input wire reset_n,
    input wire model_locked_i,
    input wire upstream_fault_i,

    input wire req_valid_i,
    output wire req_ready_o,
    input wire [1:0] req_kind_i,
    input wire req_tape_i,
    input wire [63:0] req_generation_i,
    input wire [255:0] req_model_id_i,
    input wire [18:0] req_model_word_i,
    input wire [2:0] req_layer_i,
    input wire [11:0] req_position_i,
    input wire [1:0] req_head_i,
    input wire [3:0] req_row_word_i,
    input wire [18:0] req_shadow_address_i,
    input wire [255:0] req_write_data_i,

    output wire rsp_valid_o,
    input wire rsp_ready_i,
    output wire [1:0] rsp_kind_o,
    output wire [360:0] rsp_identity_o,
    output wire [255:0] rsp_data_o,
    output wire rsp_fault_o,

    output wire endpoint_req_valid_o,
    input wire endpoint_req_ready_i,
    output wire [19:0] endpoint_req_word_address_o,
    output wire endpoint_req_write_o,
    output wire [255:0] endpoint_req_write_data_o,
    input wire endpoint_rsp_valid_i,
    output wire endpoint_rsp_ready_o,
    input wire [255:0] endpoint_rsp_data_i,
    input wire endpoint_rsp_error_i,

    output wire busy_o,
    output wire fail_closed_o
);
    localparam logic [255:0] SS_MODEL_ID =
        256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0;
    localparam logic [1:0] KIND_MODEL_READ=2'd0, KIND_KV_WRITE=2'd1, KIND_KV_READ=2'd2;
    localparam logic [1:0] IDLE=2'd0, OFFER=2'd1, WAIT_READ=2'd2, RETURN=2'd3;
    wire configuration_ok=(TAPE_COUNT==1 || TAPE_COUNT==2) && MODEL_ID==SS_MODEL_ID;
    logic [1:0] state_q;
    logic fault_q, lock_seen_q, offer_reject_q, offer_poison_q;
    logic [1:0] owner_kind_q;
    logic [360:0] owner_identity_q;
    logic [19:0] offer_address_q;
    logic offer_write_q;
    logic [3:0] owner_word_q;
    logic [255:0] offer_data_q, return_data_q;
    logic return_fault_q, return_is_data_q;

    // This is the actual public fixed-function mapper, not a repeated oracle.
    logic [1:0] mapper_class;
    always_comb begin
        case(req_kind_i)
            KIND_MODEL_READ: mapper_class=2'b00;
            KIND_KV_WRITE,KIND_KV_READ: mapper_class=2'b01;
            default: mapper_class=2'b11;
        endcase
    end
    wire mapper_valid,mapper_write,mapper_reject;
    wire [18:0] mapper_word;
    board1_context2048_typed_address_mapper u_virtual_mapper (
        .request_valid_i(req_valid_i),.request_class_i(mapper_class),
        .request_direction_i(req_kind_i==KIND_KV_WRITE),
        .model_word_index_i(req_model_word_i),.layer_i(req_layer_i),
        .position_i(req_position_i),.kv_head_i(req_head_i),.row_word_i(req_row_word_i),
        .private_command_valid_o(mapper_valid),.private_word_address_o(mapper_word),
        .private_write_o(mapper_write),.request_reject_o(mapper_reject));

    // Independent original parallel certificate, still on the19-bit virtual
    // proposal. Full fields are range-checked before their low bits may encode.
    wire [13:0] layer_position={req_layer_i,req_position_i[10:0]};
    wire [14:0] row={layer_position,1'b0}+{13'd0,req_head_i};
    wire shadow_matches;
    board1_fixed_kv_shadow_match u_shadow_certificate (
        .row_i(row),.word_i(req_row_word_i),.shadow_i(req_shadow_address_i),
        .matches_o(shadow_matches));

    wire tape_legal=(req_tape_i==1'b0) ||
                    (TAPE_COUNT==2 && req_tape_i==1'b1);
    wire fields_legal=req_layer_i<3'd6 && req_position_i<12'd2048 &&
                      req_head_i<2'd2 && req_row_word_i<4'd9;
    wire virtual_legal=mapper_word>=19'd227072 && mapper_word<19'd448256 &&
                       mapper_word==req_shadow_address_i && shadow_matches;
    // Widen BEFORE adding. Physical bank0[227072,448256), bank1[448256,669440).
    wire [19:0] kv_physical={1'b0,mapper_word}+
                           (req_tape_i ? 20'd221184 : 20'd0);
    wire physical_legal=(!req_tape_i && kv_physical>=20'd227072 &&
                         kv_physical<20'd448256) ||
                        (TAPE_COUNT==2 && req_tape_i && kv_physical>=20'd448256 &&
                         kv_physical<20'd669440);
    wire model_descriptor_legal=req_kind_i==KIND_MODEL_READ &&
        req_model_id_i==MODEL_ID && req_tape_i==0 && req_generation_i==0 &&
        req_model_word_i<19'd227062 && req_layer_i==0 && req_position_i==0 &&
        req_head_i==0 && req_row_word_i==0 && req_shadow_address_i==0 &&
        req_write_data_i==0 && mapper_valid && !mapper_reject && !mapper_write;
    wire kv_base_legal=req_model_id_i==MODEL_ID && req_model_word_i==0 &&
        tape_legal && fields_legal && virtual_legal && physical_legal &&
        mapper_valid && !mapper_reject;
    wire write_descriptor_legal=req_kind_i==KIND_KV_WRITE && kv_base_legal &&
        mapper_write && (req_row_word_i!=4'd8 || req_write_data_i[255:16]==240'd0);
    wire read_descriptor_legal=req_kind_i==KIND_KV_READ && kv_base_legal &&
        !mapper_write && req_write_data_i==256'd0;
    wire descriptor_legal=model_descriptor_legal || write_descriptor_legal ||
                          read_descriptor_legal;

    logic simulation_x_fault;
    always_comb begin
        simulation_x_fault=1'b0;
`ifndef SYNTHESIS
`ifndef FORMAL
        if($isunknown({reset_n,model_locked_i,upstream_fault_i,req_valid_i,
                       endpoint_rsp_valid_i,state_q}))
            simulation_x_fault=1'b1;
        if(req_valid_i && $isunknown({req_kind_i,req_tape_i,req_generation_i,
            req_model_id_i,req_model_word_i,req_layer_i,req_position_i,req_head_i,
            req_row_word_i,req_shadow_address_i,req_write_data_i}))
            simulation_x_fault=1'b1;
        if(state_q==OFFER && !offer_reject_q && $isunknown(endpoint_req_ready_i))
            simulation_x_fault=1'b1;
        if(state_q==RETURN && $isunknown(rsp_ready_i)) simulation_x_fault=1'b1;
        if(endpoint_rsp_valid_i && $isunknown({endpoint_rsp_data_i,endpoint_rsp_error_i}))
            simulation_x_fault=1'b1;
`endif
`endif
    end
    wire unexpected_response=endpoint_rsp_valid_i && state_q!=WAIT_READ;
    wire padding_fault=state_q==WAIT_READ && endpoint_rsp_valid_i &&
        owner_kind_q==KIND_KV_READ && owner_word_q==4'd8 &&
        endpoint_rsp_data_i[255:16]!=240'd0;
    wire independent_fault_now=!configuration_ok || upstream_fault_i ||
        (lock_seen_q && !model_locked_i) || simulation_x_fault ||
        unexpected_response || padding_fault ||
        (req_valid_i && (!descriptor_legal || !model_locked_i)) ||
        (state_q==WAIT_READ && endpoint_rsp_valid_i && endpoint_rsp_error_i);
    wire terminal_now=fault_q || independent_fault_now;

    assign endpoint_req_valid_o=reset_n && state_q==OFFER && !offer_reject_q;
    assign endpoint_req_word_address_o=endpoint_req_valid_o ? offer_address_q : 20'd0;
    assign endpoint_req_write_o=endpoint_req_valid_o && offer_write_q;
    assign endpoint_req_write_data_o=endpoint_req_valid_o ? offer_data_q : 256'd0;
    assign req_ready_o=reset_n && state_q==OFFER &&
        (offer_reject_q || (endpoint_req_ready_i===1'b1));
    // There is no write-style raw response. READ is at least one cycle after
    // its accepted request, ordered and single-outstanding in this endpoint.
    // Unexpected returns are drained as an error, never credited as a request.
    assign endpoint_rsp_ready_o=reset_n && (state_q==WAIT_READ || unexpected_response);
    wire endpoint_take=endpoint_req_valid_o && endpoint_req_ready_i;
    wire read_return_take=state_q==WAIT_READ && endpoint_rsp_valid_i && endpoint_rsp_ready_o;

    assign rsp_valid_o=reset_n && state_q==RETURN;
    assign rsp_kind_o=owner_kind_q;
    assign rsp_identity_o=owner_identity_q;
    assign rsp_fault_o=rsp_valid_o && (return_fault_q || terminal_now);
    assign rsp_data_o=rsp_valid_o && !rsp_fault_o && return_is_data_q ? return_data_q : 256'd0;
    assign busy_o=reset_n && (state_q!=IDLE || req_valid_i);
    assign fail_closed_o=reset_n && terminal_now;

    // Private resetless payload; validity and fault/zero authority guard use.
    always_ff @(posedge clk) begin
        if(reset_n && state_q==IDLE && req_valid_i) offer_data_q<=req_write_data_i;
        if(reset_n && read_return_take) return_data_q<=endpoint_rsp_data_i;
    end
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state_q<=IDLE;fault_q<=0;lock_seen_q<=0;
            offer_reject_q<=0;offer_poison_q<=0;owner_kind_q<=KIND_MODEL_READ;
            owner_identity_q<=0;offer_address_q<=0;offer_write_q<=0;owner_word_q<=0;
            return_fault_q<=0;return_is_data_q<=0;
        end else begin
            if(model_locked_i) lock_seen_q<=1;
            if(independent_fault_now) fault_q<=1;
            if(state_q==OFFER && terminal_now) offer_poison_q<=1;
            case(state_q)
                IDLE: if(req_valid_i) begin
                    owner_identity_q<={req_tape_i,req_generation_i,req_model_id_i,
                        req_layer_i,req_position_i,req_head_i,req_row_word_i,req_shadow_address_i};
                    owner_kind_q<=req_kind_i;
                    owner_word_q<=req_row_word_i;
                    offer_address_q<=req_kind_i==KIND_MODEL_READ ? {1'b0,mapper_word} : kv_physical;
                    offer_write_q<=req_kind_i==KIND_KV_WRITE;
                    // This is the ONLY rejection decision, BEFORE raw VALID.
                    // Once a well-formed offer is presented, late terminal
                    // state can only poison it, not synthesize its retirement.
                    offer_reject_q<=terminal_now || !descriptor_legal || !model_locked_i;
                    offer_poison_q<=terminal_now;
                    return_fault_q<=0;return_is_data_q<=0;
                    state_q<=OFFER;
                end
                OFFER: if(offer_reject_q || endpoint_take) begin
                    if(offer_reject_q || offer_write_q) begin
                        // reject=>fault1, with no raw offer. Otherwise even a
                        // faulted WRITE reaches here ONLY on endpoint_take,
                        // which the composition must join to actual command
                        // AND data acceptance. No raw write response exists.
                        return_fault_q<=offer_reject_q || offer_poison_q || terminal_now;
                        return_is_data_q<=0;state_q<=RETURN;
                    end else state_q<=WAIT_READ;
                end
                WAIT_READ: if(read_return_take) begin
                    return_fault_q<=terminal_now || endpoint_rsp_error_i;
                    return_is_data_q<=1;state_q<=RETURN;
                end
                RETURN: if(rsp_valid_o && rsp_ready_i) state_q<=IDLE;
                default: fault_q<=1;
            endcase
        end
    end
    initial begin
        if(TAPE_COUNT!=1 && TAPE_COUNT!=2) $fatal(1,"TAPE_COUNT must be1or2");
        if(MODEL_ID!=SS_MODEL_ID) $fatal(1,"This local candidate binds the fixed SimpleStories MODEL_ID");
    end
endmodule
`default_nettype wire

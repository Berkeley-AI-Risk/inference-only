`timescale 1ns/1ps
`default_nettype none

// PRIVATE LOCAL W composition, not the released shared-token/CDC/boot top.
// Two actual core-domain clients share the geometry-only released arbiter:
//   authenticated model service RAW fetch19, and retained typed two-tape KV20.
// Frozen B mapper/front, adapter ADDR_W20 and frozen N width-only transport
// remain unchanged. The latter is the sole core/DDR crossing in this cut.
// GOOD writeCPL still certifies command-FIFO enqueue, NOT physical persistence.
// No ordinary CLEAR or transient-engine-reset input exists on accepted owners.
module parent_shared_model_runtime20 #(
    parameter [255:0] MODEL_ID=256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0
) (
    input wire core_clk_i,ddr_clk_i,reset_n_i,model_locked_i,upstream_fault_i,
    input wire model_raw_req_valid_i,
    output wire model_raw_req_ready_o,
    input wire [18:0] model_raw_req_word_i,
    output wire model_raw_rsp_valid_o,
    output wire [255:0] model_raw_rsp_data_o,
    output wire model_raw_rsp_error_o,
    input wire m_wr_valid_i,
    output wire m_wr_ready_o,
    input wire m_wr_tape_i,
    input wire [63:0] m_wr_generation_i,
    input wire [255:0] m_wr_model_id_i,
    input wire [2:0] m_wr_layer_i,
    input wire [11:0] m_wr_position_i,
    input wire [1:0] m_wr_head_i,
    input wire [3:0] m_wr_word_i,
    input wire [18:0] m_wr_shadow_i,
    input wire [255:0] m_wr_data_i,
    output wire m_wr_cpl_valid_o,
    input wire m_wr_cpl_ready_i,
    output wire m_wr_cpl_fault_o,
    input wire m_rd_valid_i,
    output wire m_rd_ready_o,
    input wire m_rd_tape_i,
    input wire [63:0] m_rd_generation_i,
    input wire [255:0] m_rd_model_id_i,
    input wire [2:0] m_rd_layer_i,
    input wire [11:0] m_rd_position_i,
    input wire [1:0] m_rd_head_i,
    input wire [3:0] m_rd_word_i,
    input wire [18:0] m_rd_shadow_i,
    output wire m_rd_rsp_valid_o,
    input wire m_rd_rsp_ready_i,
    output wire [255:0] m_rd_rsp_data_o,
    output wire m_rd_rsp_fault_o,
    output wire [360:0] private_return_identity_o,
    output wire [1:0] private_return_kind_o,
    output wire busy_o,fault_o,
    output wire private_normalized_valid_o,private_normalized_ready_o,
    output wire private_normalized_fire_o,private_normalized_write_o,
    output wire [19:0] private_normalized_word_o,
    output wire private_model_front_accept_o,private_kv_front_accept_o,
    output wire private_kv_write_pending_o,private_shared_busy_o,
    output wire private_shared_kv_rsp_valid_o,private_shared_kv_rsp_ready_o,
    output wire private_raw_req_valid_o,private_raw_req_ready_o,
    output wire [24:0] private_raw_word_o,
    output wire private_raw_write_o,
    output wire [255:0] private_raw_data_o,
    output wire private_raw_cmd_owner_kv_o,
    output wire private_raw_rsp_valid_o,private_raw_rsp_owned_o,private_raw_rsp_owner_kv_o,
    output wire [255:0] private_raw_rsp_data_o,
    output wire core_enqueue_o,core_bad_o,core_write_o,
    output wire [28:0] core_addr_o,
    output wire [255:0] core_wr_data_o,
    output wire core_rd_valid_o,core_rd_end_o,core_controller_good_o,
    input wire controller_pll_lock_i,controller_calibrated_i,
    input wire app_cmd_ready_i,app_wr_ready_i,
    output wire [2:0] app_cmd_o,
    output wire app_cmd_en_o,
    output wire [28:0] app_addr_o,
    output wire [255:0] app_wr_data_o,
    output wire app_wr_en_o,app_wr_end_o,
    output wire [31:0] app_wr_mask_o,
    input wire [255:0] app_rd_data_i,
    input wire app_rd_valid_i,app_rd_end_i,
    output wire app_burst_o,app_self_refresh_o,app_refresh_o
);
    wire endpoint_valid,endpoint_ready,endpoint_write,endpoint_rsp_valid,endpoint_rsp_ready;
    wire [19:0] endpoint_word;
    wire [255:0] endpoint_data,endpoint_rsp_data;
    wire endpoint_rsp_error,endpoint_busy,endpoint_fault;
    wire shared_kv_ready,shared_kv_valid,shared_kv_rsp_ready,shared_kv_error,shared_busy,shared_fault;
    wire [255:0] shared_kv_data;
    wire raw_valid,raw_ready,raw_write,raw_rsp_valid,raw_rsp_error;
    wire [24:0] raw_word;
    wire [255:0] raw_data,raw_rsp_data;
    wire adapter_ready,adapter_protocol_fault,adapter_calib_error,adapter_calib_done;
    wire [2:0] core_cmd;
    wire core_cmd_ready,core_wr_ready,core_cmd_en,core_wr_en,core_wr_end;
    wire [31:0] core_wr_mask;
    wire core_burst,core_self_refresh,core_refresh,transport_fault;
    wire [255:0] core_rd_data;
    wire adapter_cmd_en,adapter_wr_en,adapter_wr_end,adapter_burst,adapter_sr,adapter_ref;
    logic kv_write_pending_q,path_fault_q;

    // Exact released shared_token_probe69..79 retirement convention. B's
    // normalized WRITE READY means completion, whereas shared KV READY means
    // front admission. Retain one pending write and suppress repeat admission
    // until the real shared response certifies raw command/data acceptance.
    assign endpoint_ready=endpoint_write ?
        (kv_write_pending_q && shared_kv_valid) : shared_kv_ready;
    assign endpoint_rsp_valid=shared_kv_valid && !kv_write_pending_q;
    assign endpoint_rsp_data=shared_kv_data;
    assign endpoint_rsp_error=shared_kv_error;
    assign shared_kv_rsp_ready=kv_write_pending_q || endpoint_rsp_ready;
    always_ff @(posedge core_clk_i or negedge reset_n_i) begin
        if(!reset_n_i) kv_write_pending_q<=0;
        else if(kv_write_pending_q && shared_kv_valid) kv_write_pending_q<=0;
        else if(endpoint_valid && shared_kv_ready && endpoint_write) kv_write_pending_q<=1;
    end

    // Immediate adapter return-error gates cannot create a false normalized
    // acceptance/read credit or a suppressed command's write completion.
    // Registered aggregate feedback avoids a request-validation callback loop.
    // This local healthy-path composition makes no universal same-edge claim.
    wire raw_high_bad=raw_valid && (|raw_word[24:20]);
    wire stable_external=upstream_fault_i || adapter_protocol_fault ||
        adapter_calib_error || raw_rsp_error || transport_fault || raw_high_bad;
    wire stop_now=path_fault_q || stable_external || shared_fault || endpoint_fault;
    wire physical_open=reset_n_i && !stop_now;
    assign fault_o=stop_now;
    assign raw_ready=adapter_ready && physical_open;
    assign busy_o=endpoint_busy || shared_busy || kv_write_pending_q;
    always_ff @(posedge core_clk_i or negedge reset_n_i) begin
        if(!reset_n_i) path_fault_q<=0;
        else if(stable_external || shared_fault || endpoint_fault) path_fault_q<=1;
    end

    two_tape_shared_endpoint #(.TAPE_COUNT(2),.MODEL_ID(MODEL_ID)) u_endpoint (
        .clk(core_clk_i),.reset_n(reset_n_i),.model_locked_i(model_locked_i),
        .upstream_fault_i(path_fault_q || stable_external),
        .model_req_valid_i(1'b0),.model_req_ready_o(),.model_req_word_i(19'd0),
        .model_rsp_valid_o(),.model_rsp_data_o(),.model_rsp_fault_o(),
        .m_wr_valid_i(m_wr_valid_i),.m_wr_ready_o(m_wr_ready_o),
        .m_wr_tape_i(m_wr_tape_i),.m_wr_generation_i(m_wr_generation_i),.m_wr_model_id_i(m_wr_model_id_i),
        .m_wr_layer_i(m_wr_layer_i),.m_wr_position_i(m_wr_position_i),.m_wr_head_i(m_wr_head_i),
        .m_wr_word_i(m_wr_word_i),.m_wr_shadow_i(m_wr_shadow_i),.m_wr_data_i(m_wr_data_i),
        .m_wr_cpl_valid_o(m_wr_cpl_valid_o),.m_wr_cpl_ready_i(m_wr_cpl_ready_i),.m_wr_cpl_fault_o(m_wr_cpl_fault_o),
        .m_rd_valid_i(m_rd_valid_i),.m_rd_ready_o(m_rd_ready_o),
        .m_rd_tape_i(m_rd_tape_i),.m_rd_generation_i(m_rd_generation_i),.m_rd_model_id_i(m_rd_model_id_i),
        .m_rd_layer_i(m_rd_layer_i),.m_rd_position_i(m_rd_position_i),.m_rd_head_i(m_rd_head_i),
        .m_rd_word_i(m_rd_word_i),.m_rd_shadow_i(m_rd_shadow_i),
        .m_rd_rsp_valid_o(m_rd_rsp_valid_o),.m_rd_rsp_ready_i(m_rd_rsp_ready_i),
        .m_rd_rsp_data_o(m_rd_rsp_data_o),.m_rd_rsp_fault_o(m_rd_rsp_fault_o),
        .private_return_identity_o(private_return_identity_o),.private_return_kind_o(private_return_kind_o),
        .endpoint_req_valid_o(endpoint_valid),.endpoint_req_ready_i(endpoint_ready),
        .endpoint_req_word_address_o(endpoint_word),.endpoint_req_write_o(endpoint_write),
        .endpoint_req_write_data_o(endpoint_data),.endpoint_rsp_valid_i(endpoint_rsp_valid),
        .endpoint_rsp_ready_o(endpoint_rsp_ready),.endpoint_rsp_data_i(endpoint_rsp_data),
        .endpoint_rsp_error_i(endpoint_rsp_error),.busy_o(endpoint_busy),.fail_closed_o(endpoint_fault));

    board1_private_shared_ddr_transaction_boundary_geometry #(
        .KV_ADDR_W(20),.TAPE_COUNT(2)) u_shared (
        .clk(core_clk_i),.reset_n(reset_n_i),.model_locked_i(model_locked_i),
        .upstream_fault_i(path_fault_q || stable_external),
        .model_req_valid_i(model_raw_req_valid_i),.model_req_ready_o(model_raw_req_ready_o),
        .model_req_word_i(model_raw_req_word_i),.model_rsp_valid_o(model_raw_rsp_valid_o),
        .model_rsp_data_o(model_raw_rsp_data_o),.model_rsp_error_o(model_raw_rsp_error_o),
        .kv_req_valid_i(endpoint_valid && !kv_write_pending_q),.kv_req_ready_o(shared_kv_ready),
        .kv_req_word_i(endpoint_word),.kv_req_write_i(endpoint_write),.kv_req_data_i(endpoint_data),
        .kv_rsp_valid_o(shared_kv_valid),.kv_rsp_ready_i(shared_kv_rsp_ready),
        .kv_rsp_data_o(shared_kv_data),.kv_rsp_error_o(shared_kv_error),
        .raw_req_valid_o(raw_valid),.raw_req_ready_i(raw_ready),.raw_req_word_o(raw_word),
        .raw_req_write_o(raw_write),.raw_req_data_o(raw_data),.raw_rsp_valid_i(raw_rsp_valid),
        .raw_rsp_data_i(raw_rsp_data),.raw_rsp_error_i(raw_rsp_error),.busy_o(shared_busy),.fault_o(shared_fault));

    board1_gowin_ddr3_app_adapter #(.ADDR_W(20),.MAX_OUTSTANDING_READS(1)) u_adapter (
        .clk(core_clk_i),.reset_n(reset_n_i),.phy_req_valid_i(raw_valid && physical_open),
        .phy_req_ready_o(adapter_ready),.phy_req_write_i(raw_write),
        .phy_req_word_addr_i(raw_word[19:0]),.phy_req_wdata_i(raw_data),
        .phy_rsp_valid_o(raw_rsp_valid),.phy_rsp_data_o(raw_rsp_data),.phy_rsp_error_o(raw_rsp_error),
        .controller_pll_lock_i(core_controller_good_o),.controller_init_calib_complete_i(core_controller_good_o),
        .calib_done_o(adapter_calib_done),.calib_error_o(adapter_calib_error),.protocol_fault_o(adapter_protocol_fault),
        .app_cmd_ready_i(core_cmd_ready),.app_wr_data_ready_i(core_wr_ready),
        .app_cmd_o(core_cmd),.app_cmd_en_o(adapter_cmd_en),.app_addr_o(core_addr_o),
        .app_wr_data_o(core_wr_data_o),.app_wr_data_en_o(adapter_wr_en),.app_wr_data_end_o(adapter_wr_end),
        .app_wr_data_mask_o(core_wr_mask),.app_rd_data_i(core_rd_data),.app_rd_data_valid_i(core_rd_valid_o),
        .app_rd_data_end_i(core_rd_end_o),.app_burst_o(adapter_burst),
        .app_self_refresh_req_o(adapter_sr),.app_refresh_req_o(adapter_ref));
    assign core_cmd_en=adapter_cmd_en && physical_open;
    assign core_wr_en=adapter_wr_en && physical_open;
    assign core_wr_end=adapter_wr_end && physical_open;
    assign core_burst=adapter_burst && physical_open;
    assign core_self_refresh=adapter_sr && physical_open;
    assign core_refresh=adapter_ref && physical_open;
    assign core_write_o=core_cmd==3'd0;
    two_tape_width_only_thin_ddr_app_transport u_transport (
        .core_clk_i(core_clk_i),.core_reset_n_i(reset_n_i),.app_clk_i(ddr_clk_i),.app_reset_n_i(reset_n_i),
        .core_stop_i(upstream_fault_i || path_fault_q),.core_fault_o(transport_fault),
        .core_controller_good_o(core_controller_good_o),.core_cmd_i(core_cmd),.core_cmd_en_i(core_cmd_en),
        .core_addr_i(core_addr_o),.core_wr_data_i(core_wr_data_o),.core_wr_en_i(core_wr_en),
        .core_wr_end_i(core_wr_end),.core_wr_mask_i(core_wr_mask),.core_burst_i(core_burst),
        .core_self_refresh_i(core_self_refresh),.core_refresh_i(core_refresh),
        .core_cmd_ready_o(core_cmd_ready),.core_wr_ready_o(core_wr_ready),
        .core_rd_data_o(core_rd_data),.core_rd_valid_o(core_rd_valid_o),.core_rd_end_o(core_rd_end_o),
        .controller_pll_lock_i(controller_pll_lock_i),.controller_calibrated_i(controller_calibrated_i),
        .app_cmd_ready_i(app_cmd_ready_i),.app_wr_ready_i(app_wr_ready_i),
        .app_cmd_o(app_cmd_o),.app_cmd_en_o(app_cmd_en_o),.app_addr_o(app_addr_o),
        .app_wr_data_o(app_wr_data_o),.app_wr_en_o(app_wr_en_o),.app_wr_end_o(app_wr_end_o),
        .app_wr_mask_o(app_wr_mask_o),.app_rd_data_i(app_rd_data_i),.app_rd_valid_i(app_rd_valid_i),
        .app_rd_end_i(app_rd_end_i),.app_burst_o(app_burst_o),.app_self_refresh_o(app_self_refresh_o),.app_refresh_o(app_refresh_o));

    assign private_normalized_valid_o=endpoint_valid;
    assign private_normalized_ready_o=endpoint_ready;
    assign private_normalized_fire_o=endpoint_valid && endpoint_ready;
    assign private_normalized_write_o=endpoint_write;
    assign private_normalized_word_o=endpoint_word;
    assign private_model_front_accept_o=model_raw_req_valid_i && model_raw_req_ready_o;
    assign private_kv_front_accept_o=endpoint_valid && !kv_write_pending_q && shared_kv_ready;
    assign private_kv_write_pending_o=kv_write_pending_q;
    assign private_shared_busy_o=shared_busy;
    assign private_shared_kv_rsp_valid_o=shared_kv_valid;
    assign private_shared_kv_rsp_ready_o=shared_kv_rsp_ready;
    assign private_raw_req_valid_o=raw_valid;
    assign private_raw_req_ready_o=raw_ready;
    assign private_raw_word_o=raw_word;
    assign private_raw_write_o=raw_write;
    assign private_raw_data_o=raw_data;
    assign private_raw_rsp_valid_o=raw_rsp_valid;
    assign private_raw_rsp_data_o=raw_rsp_data;
    // These are actual retained arbiter RAM/slot state, OBSERVATION ONLY.
    // No observer output feeds a command, owner, permission, READY or datapath.
    assign private_raw_cmd_owner_kv_o=u_shared.u_backend.cmd_kv_q;
    assign private_raw_rsp_owned_o=u_shared.u_backend.read_nonempty_q;
    assign private_raw_rsp_owner_kv_o=u_shared.u_backend.read_owner_q[u_shared.u_backend.read_head_q];
    assign core_enqueue_o=u_transport.enqueue;
    assign core_bad_o=u_transport.core_bad;
    always_ff @(posedge core_clk_i) if(reset_n_i) begin
        if(raw_valid && (|raw_word[24:20])) $fatal(1,"shared arbiter raw address would truncate before adapter20");
        if(raw_rsp_valid && (!u_shared.u_backend.read_nonempty_q || raw_rsp_error))
            $fatal(1,"unexpected/error owned raw adapter response");
        if(stop_now && (core_cmd_en || core_wr_en || core_wr_end || (raw_valid && raw_ready)))
            $fatal(1,"terminal current fault escaped raw acceptance gate");
    end
    wire _unused_calib=adapter_calib_done;
endmodule
`default_nettype wire

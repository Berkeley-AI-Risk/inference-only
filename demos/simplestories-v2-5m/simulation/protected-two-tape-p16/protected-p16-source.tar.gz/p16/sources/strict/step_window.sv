`timescale 1ns/1ps
`default_nettype none
// One two-tape, layer-0 window. The parent supplies actual STEP eligibility
// and the synchronous data taps from its single embedding/RMS/projection path.
module step_window #(
    parameter logic [255:0] MODEL_ID = 256'd0
)(
    input wire clk, rst_n, upstream_fault,
    input wire [1:0] clear_tapes,
    input wire [63:0] generation0, generation1,
    input wire admit_valid, admit_tape, admit_eligible,
    input wire [11:0] admit_position,
    output wire admit_ready,
    input wire ingress_valid, ingress_tape, ingress_is_rms,
    input wire [63:0] ingress_generation,
    input wire [11:0] ingress_position,
    input wire [7:0] ingress_row,
    input wire signed [15:0] ingress_value,
    input wire signed [7:0] ingress_exponent,
    input wire ingress_last,
    input wire issue_pair, pair_done, abort_batch,
    output wire pair_ready, pair_started,
    output wire [1:0] survivors,
    input wire q_valid, q_tape,
    input wire [9:0] q_row,
    input wire signed [15:0] q_value,
    input wire signed [7:0] q_exponent,
    input wire q_last,
    output wire q_ready,
    input wire load_valid, load_tape,
    input wire [63:0] load_generation,
    input wire [11:0] load_position,
    input wire [7:0] load_row,
    output wire load_ready,
    output wire load_response_valid,
    output wire signed [15:0] residual_out, rms_out, query_out,
    output wire signed [7:0] residual_exp_out, rms_exp_out, query_exp_out,
    input wire activation_tape,
    input wire [7:0] activation_column,
    output wire signed [15:0] activation_data,
    output wire signed [7:0] activation_exponent,
    input wire retire_valid, retire_tape,
    input wire [63:0] retire_generation,
    input wire [11:0] retire_position,
    output wire [1:0] occupied, prepared, query_complete,
    output wire fault
);
    reg [1:0] live, have_residual, have_rms, have_q;
    reg [63:0] generation [0:1];
    reg [11:0] position [0:1];
    reg [8:0] count_residual [0:1], count_rms [0:1], count_q [0:1];
    reg signed [7:0] residual_exp [0:1], rms_exp [0:1], query_exp [0:1];
    // Storage validity is exclusively descriptor-owned. No payload array is reset.
    reg signed [15:0] residual [0:511], rms [0:511], query [0:511];
    reg q_active, fault_q, read_pending, read_owner;
    reg [63:0] read_generation;
    reg signed [15:0] residual_read, rms_read, query_read;
    reg signed [7:0] residual_exp_read, rms_exp_read, query_exp_read;
    assign residual_out=load_response_valid ? residual_read : 16'sd0;
    assign rms_out=load_response_valid ? rms_read : 16'sd0;
    assign query_out=load_response_valid ? query_read : 16'sd0;
    assign residual_exp_out=load_response_valid ? residual_exp_read : 8'sd0;
    assign rms_exp_out=load_response_valid ? rms_exp_read : 8'sd0;
    assign query_exp_out=load_response_valid ? query_exp_read : 8'sd0;
    wire [63:0] current [0:1];
    assign current[0]=generation0;
    assign current[1]=generation1;
    wire [1:0] live_now = {live[1] && generation[1]==current[1],
                           live[0] && generation[0]==current[0]} & ~clear_tapes;
    wire known_model = MODEL_ID != 256'd0;
    wire operational = rst_n && known_model && !fault_q && !upstream_fault;
    assign occupied = live_now;
    assign survivors = operational ? live_now : 2'b0;
    assign prepared = have_residual & have_rms & survivors;
    assign query_complete = have_q & survivors;
    assign admit_ready = operational && !q_active && !live[admit_tape] &&
                         !clear_tapes[admit_tape] && admit_eligible &&
                         admit_position < 12'd2048;
    assign pair_ready = operational && !q_active && prepared != 0 && prepared == live_now;
    assign pair_started = issue_pair && pair_ready;
    assign q_ready = operational && q_active && !abort_batch && live_now[q_tape] && !have_q[q_tape];
    assign load_ready = operational && query_complete[load_tape] &&
        load_generation==generation[load_tape] && load_position==position[load_tape];
    assign load_response_valid = operational && read_pending && live_now[read_owner] &&
        current[read_owner]==read_generation;
    wire activation_live = operational && q_active && prepared[activation_tape];
    // Matches the pilot's same-cycle column interface. In a BRAM-backed
    // projection this read needs the engine's existing look-ahead address.
    assign activation_data = activation_live ? rms[{activation_tape,activation_column}] : 16'sd0;
    assign activation_exponent = activation_live ? rms_exp[activation_tape] : 8'sd0;
    wire ingress_owned = operational && live_now[ingress_tape] &&
        generation[ingress_tape]==ingress_generation && position[ingress_tape]==ingress_position;
    wire [8:0] ingress_count = ingress_is_rms ? count_rms[ingress_tape] : count_residual[ingress_tape];
    wire signed [7:0] ingress_expected_exp = ingress_is_rms ? rms_exp[ingress_tape] : residual_exp[ingress_tape];
    wire ingress_ok = !q_active && ingress_count == {1'b0,ingress_row} &&
        ingress_last==(ingress_row==8'd255) &&
        (ingress_count==0 || ingress_expected_exp==ingress_exponent) &&
        (!ingress_is_rms || have_residual[ingress_tape]);
    wire query_ok = q_row < 256 && count_q[q_tape]==q_row[8:0] &&
        q_last==(q_row==10'd255) &&
        (count_q[q_tape]==0 || q_exponent==query_exp[q_tape]);
    wire retire_ok = live_now[retire_tape] && generation[retire_tape]==retire_generation &&
        position[retire_tape]==retire_position && have_q[retire_tape] && !q_active;
    assign fault = fault_q || upstream_fault || !known_model;
    always @(posedge clk) begin
        if (ingress_valid && ingress_owned && ingress_ok) begin
            if (ingress_is_rms)
                rms[{ingress_tape,ingress_row}] <= ingress_value;
            else
                residual[{ingress_tape,ingress_row}] <= ingress_value;
        end
        if (q_valid && q_ready && query_ok)
            query[{q_tape,q_row[7:0]}] <= q_value;
        if (load_valid && load_ready) begin
            residual_read <= residual[{load_tape,load_row}];
            rms_read <= rms[{load_tape,load_row}];
            query_read <= query[{load_tape,load_row}];
            residual_exp_read <= residual_exp[load_tape];
            rms_exp_read <= rms_exp[load_tape];
            query_exp_read <= query_exp[load_tape];
        end
    end
    integer tape;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            live<=0; have_residual<=0; have_rms<=0; have_q<=0;
            q_active<=0; fault_q<=0; read_pending<=0; read_owner<=0; read_generation<=0;
            for (tape=0;tape<2;tape=tape+1) begin
                generation[tape]<=0; position[tape]<=0;
                count_residual[tape]<=0; count_rms[tape]<=0; count_q[tape]<=0;
                residual_exp[tape]<=0; rms_exp[tape]<=0; query_exp[tape]<=0;
            end
        end else begin
            read_pending <= load_valid && load_ready;
            if (load_valid && load_ready) begin
                read_owner <= load_tape;
                read_generation <= load_generation;
            end
            if (upstream_fault || !known_model ||
                (ingress_valid && ingress_owned && !ingress_ok) ||
                (q_valid && q_ready && !query_ok) ||
                (pair_done && !abort_batch && (!q_active || ((have_q & live_now)!=live_now))) ||
                (retire_valid && !clear_tapes[retire_tape] && !retire_ok))
                fault_q<=1;
            if (pair_started) q_active<=1;
            if (pair_done) q_active<=0;
            if (admit_valid && admit_ready) begin
                live[admit_tape]<=1;
                generation[admit_tape]<=current[admit_tape];
                position[admit_tape]<=admit_position;
                have_residual[admit_tape]<=0; have_rms[admit_tape]<=0; have_q[admit_tape]<=0;
                count_residual[admit_tape]<=0; count_rms[admit_tape]<=0; count_q[admit_tape]<=0;
            end
            if (ingress_valid && ingress_owned && ingress_ok) begin
                if (ingress_is_rms) begin
                    count_rms[ingress_tape]<=ingress_count+1'b1;
                    rms_exp[ingress_tape]<=ingress_exponent;
                    if (ingress_last) have_rms[ingress_tape]<=1;
                end else begin
                    count_residual[ingress_tape]<=ingress_count+1'b1;
                    residual_exp[ingress_tape]<=ingress_exponent;
                    if (ingress_last) have_residual[ingress_tape]<=1;
                end
            end
            if (q_valid && q_ready && query_ok) begin
                count_q[q_tape]<=count_q[q_tape]+1'b1;
                query_exp[q_tape]<=q_exponent;
                if (q_last) have_q[q_tape]<=1;
            end
            if (retire_valid && retire_ok) live[retire_tape]<=0;
            // An active scalar CLEAR resets the physical group engine under
            // the parent drain protocol. A parked survivor can replay from
            // its ordinary tape. Incomplete outputs never acquire authority.
            if (abort_batch) begin
                q_active<=0;
                have_q<=0;
                count_q[0]<=0; count_q[1]<=0;
            end
            for (tape=0;tape<2;tape=tape+1)
                if (clear_tapes[tape] || (live[tape] && generation[tape]!=current[tape])) begin
                    live[tape]<=0; have_residual[tape]<=0; have_rms[tape]<=0; have_q[tape]<=0;
                end
        end
    end
endmodule
`default_nettype wire

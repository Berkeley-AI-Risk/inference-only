`timescale 1ns/1ps
`default_nettype none
// Layer-0 Q/K/V use the same private normalized inputs before rotary embedding.
module batch_q_scheduler(
    input wire [1:0] matrix_job, input wire oldest_tape,
    batch_resources shared, input wire external_fault,
    input wire clk, reset_n, start, pair_order,
    input wire [1:0] requests, clear_tapes,
    output wire activation_owner, output wire [7:0] activation_column,
    input wire signed [15:0] activation_data, input wire signed [7:0] activation_exponent,
    output wire q_valid, input wire q_ready, output wire q_owner, output wire [9:0] q_row,
    output wire signed [15:0] q_mantissa, output wire signed [7:0] q_exponent,
    output wire q_last, done, fault
);
    localparam S_IDLE=0,S_SELECT=1,S_FETCH=2,S_RUN=3,S_ADVANCE=4,S_DRAIN=5;
    reg [2:0] state, ordinal;
    reg paired, owner, hit, producer_done, engine_done, header_accepted;
    reg [1:0] live, group_id, cache_group;
    reg valid_cache;
    reg [1:0] cache_job;
    wire [7:0] last_row=(matrix_job==0) ? 8'd255 : 8'd127;
    wire [2:0] last_ordinal=(matrix_job==0) ? 3'd7 : 3'd3;
    reg [8:0] column;
    wire next_owner=(paired ? ordinal[0]:ordinal[2]) ^ oldest_tape;
    wire [1:0] next_group=paired ? ordinal[2:1]:ordinal[1:0];
    wire [1:0] allowed=live & ~clear_tapes;
    wire serving=state==S_RUN;
    wire serving_live=serving && allowed[owner];
    wire cancel_group=serving && clear_tapes[owner];
    assign activation_owner=owner;
    assign activation_column=column[7:0];

    wire memory_fault;
    wire [18:0] request_word;
    wire [255:0] response_data;
    assign memory_fault=external_fault;

    wire src_ready,src_header,src_header_ready,src_weight,src_weight_ready,src_last,src_done,src_fault;
    wire [2:0] src_layer; wire [3:0] src_job; wire [5:0] src_group; wire [6:0] src_lanes;
    wire [511:0] src_exponents; wire [1023:0] src_multipliers; wire [639:0] src_data;
    assign shared.batch_src_clear_i = 1'b0;
    assign shared.batch_src_upstream_fail_closed_i = memory_fault;
    assign shared.batch_src_start_valid_i = state==S_FETCH;
    assign src_ready = shared.batch_src_start_ready_o;
    assign shared.batch_src_fixed_layer_i = 3'd0;
    assign shared.batch_src_fixed_job_i = {2'd0,matrix_job};
    assign shared.batch_src_fixed_group_i = {4'd0,group_id};
    assign src_header = shared.batch_src_group_valid_o;
    assign shared.batch_src_group_ready_i = src_header_ready;
    assign src_layer = shared.batch_src_group_layer_o;
    assign src_job = shared.batch_src_group_job_o;
    assign src_group = shared.batch_src_group_index_o;
    assign src_lanes = shared.batch_src_group_valid_lanes_o;
    assign src_exponents = shared.batch_src_group_row_exponent_o;
    assign src_multipliers = shared.batch_src_group_row_multiplier_o;
    assign src_data = shared.batch_src_weight_data_o;
    assign src_weight = shared.batch_src_weight_valid_o;
    assign shared.batch_src_weight_ready_i = src_weight_ready;
    assign src_last = shared.batch_src_weight_last_o;
    assign src_done = shared.batch_src_done_valid_o;
    assign shared.batch_src_done_ready_i = 1'b1;
    assign src_fault = shared.batch_src_fail_closed_o;

    // A tag becomes readable after a complete group. The sole model binding
    // and layer are fixed; the job and group are tagged. Mutable activation/state never enter
    // this store. A clear may drain an immutable fill while the engine resets.
    (* ram_style="block" *) reg [639:0] saved_weight[0:255];
    reg [511:0] saved_exponents; reg [1023:0] saved_multipliers; reg [639:0] replay_word;
    wire header_ready,weight_ready,eng_result,eng_done,eng_fault;
    wire [12:0] eng_row; wire signed [49:0] eng_scaled; wire signed [7:0] eng_exp;
    wire eng_header=serving_live && (hit ? !header_accepted : src_header);
    wire eng_weight=serving_live && (hit ? (header_accepted && column<256) : src_weight);
    wire [639:0] selected_weight=hit ? replay_word : src_data;
    wire eng_weight_fire=eng_weight && weight_ready;
    assign src_header_ready=serving && !hit && (!allowed[owner] || header_ready);
    assign src_weight_ready=serving && !hit && (!allowed[owner] || weight_ready);
    wire fill_beat=src_weight && src_weight_ready;
    wire capture_header=src_header && src_header_ready;
    wire load_column=hit ? eng_weight_fire : fill_beat;
    wire [7:0] replay_address=eng_weight_fire && column<255 ? column[7:0]+8'd1 : column[7:0];
    always @(posedge clk) begin
        if(fill_beat) saved_weight[column[7:0]]<=src_data;
        if(capture_header) begin saved_exponents<=src_exponents; saved_multipliers<=src_multipliers; end
        if(serving && hit) replay_word<=saved_weight[replay_address];
    end
    assign shared.batch_eng_clear_i = cancel_group;
    assign shared.batch_eng_upstream_fail_closed_i = memory_fault || src_fault;
    assign shared.batch_eng_group_valid_i = eng_header;
    assign header_ready = shared.batch_eng_group_ready_o;
    assign shared.batch_eng_group_layer_i = 3'd0;
    assign shared.batch_eng_group_job_i = {2'd0,matrix_job};
    assign shared.batch_eng_group_index_i = {4'd0,group_id};
    assign shared.batch_eng_group_valid_lanes_i = 7'd64;
    assign shared.batch_eng_group_row_exponent_i = hit?saved_exponents:src_exponents;
    assign shared.batch_eng_group_row_multiplier_i = hit?saved_multipliers:src_multipliers;
    assign shared.batch_eng_activation_exponent_i = activation_exponent;
    assign shared.batch_eng_weight_valid_i = eng_weight;
    assign weight_ready = shared.batch_eng_weight_ready_o;
    assign shared.batch_eng_activation_i = activation_data;
    assign shared.batch_eng_weight_data_i = selected_weight;
    assign shared.batch_eng_weight_last_i = hit ? column==255 : src_last;
    assign eng_result = shared.batch_eng_result_valid_o;
    assign shared.batch_eng_result_ready_i = 1'b1;
    assign eng_row = shared.batch_eng_result_row_index_o;
    assign eng_scaled = shared.batch_eng_result_scaled_raw_o;
    assign eng_exp = shared.batch_eng_result_source_exponent_o;
    assign eng_done = shared.batch_eng_done_valid_o;
    assign shared.batch_eng_done_ready_i = 1'b1;
    assign eng_fault = shared.batch_eng_fail_closed_o;

    wire capture_raw=serving_live && eng_result;
    reg [1:0] raw_complete, normalized;
    wire accept_start=start && (state==S_IDLE || done);
    // Independent private spans allow one shared normalizer to start a full
    // vector as soon as its last row retires, concurrently with other groups.
    (* ram_style="block" *) reg [57:0] raw_vectors[0:511];
    reg [57:0] norm_input;
    localparam N_IDLE=0,N_START=1,N_READ=2,N_SEND=3,N_OUTPUT=4;
    reg [2:0] norm_state; reg norm_owner; reg [7:0] norm_row;
    wire norm_start_ready,norm_input_ready,norm_valid,norm_done,norm_fault;
    wire cancel_norm=norm_state!=N_IDLE && clear_tapes[norm_owner];
    wire [1:0] eligible_norm=raw_complete & ~normalized & allowed;
    always @(posedge clk) begin
        if(capture_raw) raw_vectors[{owner,eng_row[7:0]}]<={eng_exp,eng_scaled};
        if(norm_state==N_READ) norm_input<=raw_vectors[{norm_owner,norm_row}];
    end
    wire [9:0] norm_output_row;
    wire signed [15:0] norm_output_mantissa;
    wire signed [7:0] norm_output_exponent;
    wire norm_output_last;
    assign q_valid=norm_valid && allowed[norm_owner] && !fault;
    assign q_owner=q_valid && norm_owner;
    assign q_row=q_valid ? norm_output_row : 10'd0;
    assign q_mantissa=q_valid ? norm_output_mantissa : 16'sd0;
    assign q_exponent=q_valid ? norm_output_exponent : 8'sd0;
    assign q_last=q_valid && norm_output_last;
    assign shared.batch_norm_clear_i = cancel_norm;
    assign shared.batch_norm_upstream_fault_i = memory_fault || eng_fault || src_fault;
    assign shared.batch_norm_start_valid_i = norm_state==N_START && !cancel_norm;
    assign norm_start_ready = shared.batch_norm_start_ready_o;
    assign shared.batch_norm_fixed_layer_i = 3'd0;
    assign shared.batch_norm_fixed_job_i = {2'd0,matrix_job};
    assign shared.batch_norm_input_valid_i = norm_state==N_SEND && !cancel_norm;
    assign norm_input_ready = shared.batch_norm_input_ready_o;
    assign shared.batch_norm_input_row_index_i = {2'd0,norm_row};
    assign shared.batch_norm_input_raw_i = norm_input[49:0];
    assign shared.batch_norm_input_source_exponent_i = norm_input[57:50];
    assign shared.batch_norm_input_last_i = norm_row==last_row;
    assign norm_valid = shared.batch_norm_result_valid_o;
    assign shared.batch_norm_result_ready_i = q_ready && allowed[norm_owner];
    assign norm_output_row = shared.batch_norm_result_row_index_o;
    assign norm_output_mantissa = shared.batch_norm_result_mantissa_o;
    assign norm_output_exponent = shared.batch_norm_result_exponent_o;
    assign norm_output_last = shared.batch_norm_result_last_o;
    assign norm_done = shared.batch_norm_done_valid_o;
    assign shared.batch_norm_done_ready_i = 1'b1;
    assign norm_fault = shared.batch_norm_range_fault_o;
    assign fault=memory_fault || src_fault || eng_fault || norm_fault;
    assign done=state==S_DRAIN && (normalized & allowed)==allowed && norm_state==N_IDLE && !fault;

    always @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state<=S_IDLE; live<=0; raw_complete<=0; paired<=0; owner<=0; group_id<=0; ordinal<=0;
            column<=0; hit<=0; header_accepted<=0; engine_done<=0; producer_done<=0; valid_cache<=0; cache_group<=0; cache_job<=0;
        end else if(accept_start) begin
            live<=requests & ~clear_tapes; raw_complete<=0; ordinal<=0; paired<=pair_order; state<=S_SELECT;
        end else begin
            live<=allowed; raw_complete<=raw_complete & allowed;
            if(!fault) case(state)
                S_SELECT: begin
                    group_id<=next_group; owner<=next_owner; column<=0; header_accepted<=0; engine_done<=0; producer_done<=0;
                    hit<=valid_cache && cache_job==matrix_job && cache_group==next_group;
                    if(!allowed[next_owner]) state<=S_ADVANCE;
                    else if(valid_cache && cache_job==matrix_job && cache_group==next_group) state<=S_RUN;
                    else begin valid_cache<=0; state<=S_FETCH; end
                end
                S_FETCH: if(src_ready) state<=S_RUN;
                S_RUN: begin
                    if(load_column) column<=column+1'b1;
                    if(eng_header && header_ready) header_accepted<=1;
                    if(eng_done) engine_done<=1;
                    if(src_done) begin
                        producer_done<=1;
                        if(column==256) begin cache_group<=group_id; cache_job<=matrix_job; valid_cache<=1; end
                    end
                    if(capture_raw && eng_row=={5'd0,last_row}) raw_complete[owner]<=1;
                    if((hit || producer_done) && (engine_done || !allowed[owner])) state<=S_ADVANCE;
                end
                S_ADVANCE: if(ordinal==last_ordinal) state<=S_DRAIN;
                           else begin ordinal<=ordinal+1'b1;state<=S_SELECT;end
            endcase
            if(fault) valid_cache<=0;
        end
    end
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n || accept_start) begin norm_state<=N_IDLE; norm_row<=0; norm_owner<=0; normalized<=0; end
        else if(cancel_norm) norm_state<=N_IDLE;
        else if(!fault) case(norm_state)
            N_IDLE: if(|eligible_norm) begin norm_owner<=!eligible_norm[0]; norm_row<=0; norm_state<=N_START; end
            N_START: if(norm_start_ready) norm_state<=N_READ;
            N_READ: norm_state<=N_SEND;
            N_SEND: if(norm_input_ready) begin
                if(norm_row==last_row) norm_state<=N_OUTPUT;
                else begin norm_row<=norm_row+1'b1; norm_state<=N_READ; end
            end
            N_OUTPUT: if(norm_done) begin normalized[norm_owner]<=1; norm_state<=N_IDLE; end
        endcase
    end
endmodule
`default_nettype wire

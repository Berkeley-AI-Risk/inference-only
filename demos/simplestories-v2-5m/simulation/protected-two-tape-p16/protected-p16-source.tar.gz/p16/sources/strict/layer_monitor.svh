    reg [15:0] layer_inputs[0:9547],layer_norms[0:9547];
    reg [57:0] layer_scaled[0:9547],gold_head[0:12056];
    reg [7:0] gold_ae[0:13],gold_ye[0:13];reg [15:0] gold_head_input[0:767];reg[7:0] gold_hxe[0:2];
    integer checked_raw[0:1][0:6],checked_norm[0:1][0:6],checked_input[0:1][0:6];
    integer scored[0:2],input_head[0:2],appended[0:2],public_first[0:2],mat_words[0:6];
    integer arith=0,starts=0,hits=0,swaps=0,cut_count=0,checkpoint_marks=0;
    function automatic int rows_for(input int j);return j==1||j==2?128:j==4||j==5?682:256;endfunction
    initial begin
        $readmemh("layer_in.memh",layer_inputs);$readmemh("layer_out.memh",layer_norms);
        $readmemh("layer_raw.memh",layer_scaled);$readmemh("layer_ae.memh",gold_ae);$readmemh("layer_ye.memh",gold_ye);
        $readmemh("head0.memh",gold_head,0,4018);$readmemh("head1.memh",gold_head,4019,8037);$readmemh("head2.memh",gold_head,8038,12056);
        $readmemh("hx0.memh",gold_head_input,0,255);$readmemh("hx1.memh",gold_head_input,256,511);$readmemh("hx2.memh",gold_head_input,512,767);$readmemh("hxe.memh",gold_hxe);
        for(int k=0;k<3;k++) public_first[k]=-1;
    end
    always @(posedge clk) if(reset_n && release_tick>0)begin:score_layer
        int t,j,r,k;reg [57:0] pair_raw;reg [15:0] nv;reg[7:0] ne;
        if(dut.batch.save || dut.batch.load)begin
            if(dut.model_owners_q!=0 || dut.guard_busy || dut.kv_external || dut.attention_external || !dut.local_empty)
                $fatal(1,"unretired external or local owner at switch");
            if(dut.batch.save && (!dut.batch.safe_stage || !dut.batch.barrier || !dut.batch.live[dut.batch.source_owner] ||
                private_job_generation_o!=generation(dut.batch.source_owner)))$fatal(1,"invalid park descriptor");
            if(dut.batch.load && !dut.batch.live[dut.batch.target_owner])$fatal(1,"invalid restore descriptor");
            if(dut.batch.save && dut.batch.job>=3)begin
                if(!`D.atomic_pending_authorized || !`D.summary_commit_legal || `A.context_active_q || `A.cache_owner_q ||
                    `D.u_kv_cache.external_owner_q || `D.u_kv_cache.state_q!=4 || !`F.consumed_q)
                    $fatal(1,"post-attention ownership");
                checkpoint_marks++;
            end
            if(dut.swap)swaps++;
            $display("L0_PARK c=%0d src=%0d dst=%0d save=%0d load=%0d j=%0d pending=%0d",cycles,dut.batch.source_owner,dut.batch.target_owner,dut.batch.save,dut.batch.load,dut.batch.job,`D.atomic_pending_authorized);
        end
        if(`D.batch_start)begin starts++;$display("L0_JOB c=%0d job=%0d",cycles,dut.batch.job);end
        if(`G.weight_response_accept && `G.layer_q==0 && `G.job_q<7)mat_words[`G.job_q]++;
        if(`D.batch_running && `D.scheduler.state==1 && `D.scheduler.allowed[`D.scheduler.next_owner] &&
            `D.scheduler.valid_cache && `D.scheduler.cache_job==`D.batch_matrix && `D.scheduler.cache_group==`D.scheduler.next_group)hits++;
        if(`D.batch_running && `D.scheduler.eng_weight_fire)begin
            t=`D.act_owner;j=`D.batch_matrix;r=`D.act_column;
            if(clear_tapes_i[t] || !dut.batch.live[t] || `D.scheduler.gen_capture[t]!=generation(t) ||
                `D.scheduler.activation_data!==layer_inputs[(t*7+j)*682+r] ||
                `D.scheduler.activation_exponent!==gold_ae[t*7+j])$fatal(1,"wrong paired activation t=%0d j=%0d r=%0d",t,j,r);
            checked_input[t][j]++;arith++;
        end
        if(`D.batch_running && `D.scheduler.capture_raw || (private_job_valid_o && `D.current_position_q==16 && `D.current_layer_q==0 &&
            `D.engine_state_q==2 && `D.projection_result_valid && `D.projection_result_ready))begin
            t=`D.batch_running ? `D.scheduler.owner:private_job_tape_o;
            j=`D.batch_running ? `D.batch_matrix:`D.stage_matrix(`D.current_stage_q);
            r=`D.batch_running ? `D.scheduler.eng_row:`D.projection_result_index;
            pair_raw=`D.batch_running ? {`D.scheduler.eng_exp,`D.scheduler.eng_scaled}:{`D.projection_result_exponent,`D.projection_result_raw};
            if(clear_tapes_i[t] || fixture_slot(t,generation(t))!=t || r!=checked_raw[t][j] || pair_raw!==layer_scaled[(t*7+j)*682+r])
                $fatal(1,"wrong scaled row t=%d j=%d r=%d",t,j,r);
            checked_raw[t][j]++;
        end
        if(`D.out_valid && `D.batch_running || (private_job_valid_o && `D.current_position_q==16 && `D.current_layer_q==0 &&
            `D.engine_state_q==2 && `D.norm_result_fire))begin
            t=`D.batch_running ? `D.out_owner:private_job_tape_o;j=`D.batch_running ? `D.batch_matrix:`D.stage_matrix(`D.current_stage_q);
            r=`D.batch_running ? `D.out_row:`D.norm_result_index;nv=`D.batch_running?`D.out_value:`D.norm_result_mantissa;
            ne=`D.batch_running?`D.out_exp:`D.norm_result_exponent;
            if(clear_tapes_i[t] || fixture_slot(t,generation(t))!=t || r!=checked_norm[t][j] ||
                nv!==layer_norms[(t*7+j)*682+r] || ne!==gold_ye[t*7+j])$fatal(1,"wrong normalized row t=%d j=%d r=%d",t,j,r);
            checked_norm[t][j]++;
        end
        if(`S.rms_result_transfer || `S.head_result_transfer || `S.generated_commit)begin
            t=private_job_tape_o;k=fixture_slot(t,private_job_generation_o);
            if(clear_tapes_i[t] || !private_job_valid_o || private_job_generation_o!=generation(t))$fatal(1,"stale public computation");
            if(`S.rms_result_transfer)begin
                r=input_head[k];if(r>=256 || r!=`S.rms_result_index || `S.rms_result_mantissa!==gold_head_input[k*256+r] || `S.rms_result_exponent!==gold_hxe[k])$fatal(1,"wrong head vector");
                input_head[k]++;
            end
            if(`S.head_result_transfer)begin
                r=scored[k];if(r>=4019 || r!=`S.private_head_result_row_index_i ||
                    {`S.private_head_result_source_exponent_i,`S.private_head_result_scaled_raw_i}!==gold_head[k*4019+r])$fatal(1,"wrong head score");
                scored[k]++;
            end
            if(`S.generated_commit)begin
                if(scored[k]!=4019 || appended[k]!=0 || `S.completing_winner!=(k==0?85:k==1?490:15))$fatal(1,"wrong append");
                appended[k]++;
            end
        end
        if(token_valid_o)begin k=fixture_slot(token_tape_o,generation(token_tape_o));
            if(appended[k]!=1)$fatal(1,"public token without own append");
            if(public_first[k]<0)begin public_first[k]=cycles;$display("L0_PUBLIC c=%0d t=%0d g=%0d token=%0d",cycles,token_tape_o,generation(token_tape_o),token_o);end
        end
    end


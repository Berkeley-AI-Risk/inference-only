    localparam [63:0] EXPECT_A=64'he6ac0f70e50545aa;
    localparam [63:0] EXPECT_B=64'hdcd75d6a294e6336;
    localparam [63:0] EXPECT_FRESH=64'h46b1253e7d9a0c92;

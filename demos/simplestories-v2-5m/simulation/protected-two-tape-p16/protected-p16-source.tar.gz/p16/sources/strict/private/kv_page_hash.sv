`timescale 1ns/1ps
`default_nettype none

// PRIVATE finite component derivative of the released SimpleStories hash stage.
// One real, unchanged board1_sha256_compact_compress is shared by both tapes.
// Header bytes are network order; payload bytes retain the original little-
// endian order. No state import, seed hierarchy, encryption or board claim.
module two_tape_kv_page_hash #(
    parameter logic [255:0] MODEL_ID=256'd0
) (
    input wire clk,reset_n,clear_i,
    input wire begin_valid_i,
    output wire begin_ready_o,
    input wire tape_i,
    input wire [63:0] generation_i,
    input wire [2:0] layer_i,
    input wire [6:0] page_i,
    input wire head_i,role_i,
    input wire [4:0] positions_i,
    input wire word_valid_i,
    output wire word_ready_o,
    input wire [255:0] word_i,
    output wire digest_valid_o,
    input wire digest_ready_i,
    output wire [255:0] digest_o,
    output wire fault_o
);
    localparam [3:0] IDLE=0,H0START=1,H0WAIT=2,H1START=3,H1WAIT=4,
        LOW=5,HIGH=6,DSTART=7,DWAIT=8,PSTART=9,PWAIT=10,RESULT=11,FAULT=12;
    localparam [255:0] IV=256'h6a09e667bb67ae853c6ef372a54ff53a510e527f9b05688c1f83d9ab5be0cd19;
    localparam [127:0] DOMAIN=128'h494f2d4b562d32544150452d76310000;
    logic [3:0] state_q;
    logic [511:0] header0_q,header1_q,block_q;
    logic [255:0] hash_q;
    logic [6:0] words_q,total_words_q;
    logic final_data_block_q;
    logic [63:0] length_bits_q;
    wire sha_done,sha_busy;
    wire [255:0] sha_state;
    wire configured=MODEL_ID!=256'd0;
    wire live=reset_n && configured && !clear_i && state_q!=FAULT;
    assign begin_ready_o=live && state_q==IDLE;
    assign word_ready_o=live && (state_q==LOW || state_q==HIGH);
    assign digest_valid_o=live && state_q==RESULT;
    assign digest_o=digest_valid_o ? hash_q : 256'd0;
    assign fault_o=reset_n && (!configured || state_q==FAULT);
    wire sha_start=live && (state_q==H0START || state_q==H1START || state_q==DSTART || state_q==PSTART);
    wire [511:0] sha_block=state_q==H0START ? header0_q :
        state_q==H1START ? header1_q : state_q==PSTART ? {1'b1,447'd0,length_bits_q} : block_q;

    board1_sha256_compact_compress u_sha(
        .clk_i(clk),.reset_n_i(reset_n && !clear_i),.start_i(sha_start),
        .block_i(sha_block),.state_i(hash_q),.busy_o(sha_busy),
        .done_o(sha_done),.state_o(sha_state));

    function automatic [255:0] byte_order(input [255:0] value);
        for(integer i=0;i<32;i=i+1) byte_order[255-8*i -:8]=value[8*i +:8];
    endfunction
    wire begin_fire=begin_valid_i && begin_ready_o;
    wire word_fire=word_valid_i && word_ready_o;
`ifndef SYNTHESIS
    wire unknown_control=$isunknown({reset_n,clear_i,begin_valid_i,word_valid_i,digest_ready_i,MODEL_ID}) ||
        (begin_fire && $isunknown({tape_i,generation_i,layer_i,page_i,head_i,role_i,positions_i})) ||
        (word_fire && $isunknown(word_i));
`else
    wire unknown_control=1'b0;
`endif
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state_q<=IDLE;words_q<=0;total_words_q<=0;final_data_block_q<=0;
            hash_q<=IV;length_bits_q<=0;header0_q<=0;header1_q<=0;block_q<=0;
        end else if(clear_i) begin
            // The guard retains a sticky fault for the canceled owner. Clearing
            // this shared engine must permit the healthy peer to use it later.
            state_q<=IDLE;words_q<=0;total_words_q<=0;final_data_block_q<=0;
            hash_q<=IV;length_bits_q<=0;
        end else if(!configured || state_q==FAULT || unknown_control) begin
            state_q<=FAULT;
        end else case(state_q)
            IDLE: if(begin_fire) begin
                if(layer_i>=6 || positions_i==0 || positions_i>16) state_q<=FAULT;
                else begin
                    // Exactly128 header bytes, in two full SHA blocks:
                    // domain16 + installed MODEL_ID32 + tapeu64 + generationu64;
                    // sevenu32(layer,page,head,role,positions,16,32) +36zero.
                    header0_q<={DOMAIN,MODEL_ID,63'd0,tape_i,generation_i};
                    header1_q<={29'd0,layer_i,25'd0,page_i,31'd0,head_i,31'd0,role_i,
                        27'd0,positions_i,32'd16,32'd32,288'd0};
                    total_words_q<={positions_i,2'b0}+{2'd0,positions_i};
                    words_q<=0;hash_q<=IV;final_data_block_q<=0;
                    length_bits_q<=64'd1024+{49'd0,positions_i,10'd0}+{51'd0,positions_i,8'd0};
                    state_q<=H0START;
                end
            end
            H0START: state_q<=H0WAIT;
            H0WAIT: if(sha_done) begin hash_q<=sha_state;state_q<=H1START;end
            H1START: state_q<=H1WAIT;
            H1WAIT: if(sha_done) begin hash_q<=sha_state;state_q<=LOW;end
            LOW: if(word_fire) begin
                block_q[511:256]<=byte_order(word_i);words_q<=words_q+1'b1;
                if(words_q==total_words_q-1'b1) begin
                    block_q[255:0]<={1'b1,191'd0,length_bits_q};
                    final_data_block_q<=1;state_q<=DSTART;
                end else state_q<=HIGH;
            end
            HIGH: if(word_fire) begin
                block_q[255:0]<=byte_order(word_i);words_q<=words_q+1'b1;state_q<=DSTART;
            end
            DSTART: state_q<=DWAIT;
            DWAIT: if(sha_done) begin
                hash_q<=sha_state;
                state_q<=final_data_block_q ? RESULT : (words_q==total_words_q ? PSTART : LOW);
            end
            PSTART: state_q<=PWAIT;
            PWAIT: if(sha_done) begin hash_q<=sha_state;state_q<=RESULT;end
            RESULT: if(digest_ready_i) state_q<=IDLE;
            default: state_q<=FAULT;
        endcase
    end
endmodule
`default_nettype wire

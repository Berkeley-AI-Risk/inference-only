`timescale 1ns/1ps
`default_nettype none
// PRIVATE SOURCE-ONLY populated-peer shared-model fixture. Released parent, page service/bank/SHA,
// B typed mapper/front, adapter and N20 command/return async FIFOs unchanged.
// Only the shared arbiter geometry is a named private derivative (19/1 default,
// explicit20/2). Model remains19/exclusive227062; KV is20/[227072,669440).
// Model service and arbiter share core clock; released model CDC/boot/top19
// handoff are OUTSIDE this local cut. No full-board/physical/security claim.
// ONE actual DDR APP port serves immutable model image and ordinarily written
// K/V banks. No alternate raw-ROM response path; no KV preload/seed/physicalRAMCLEAR.
// Fixed program: T1g0 APPEND379x16/STEP111; ordinary EMPTY T0 CLEAR,
// T0g1 APPEND380/STEP15/STEP3; T1g0 STEP490. Both prefixes coexist.
// No canceled/partial T0 job, physical-RAM clear, preloaded KV or new oracle.
// Observer-only model context is captured at actual child admissions and
// conserved through the real request/response FIFO and owner-arbiter stages.
// Model raw ownership/address transitions are all logged. Actual payload is
// logged ONLY for first bank0/page0 fill128, first weightwords0/1/2 and first
// consumed640 weight group. Every unlogged actual model payload is checked
// against image.memh by compiled assertions, NOT independently replayable.
// Selected4KiB+80B weight witness payload may enter the PRIVATE archive;
// this is not a claim all model payload is absent. No full ROM payload copy.
// All K/V raw/operand data is logged by this fixture + unchanged RTL emitters.
// References are immutable CPU expectations, NEVER DUT/DDR seed data.
`define D dut.u_core.u_six_layers.u_datapath
`define A dut.u_core.u_six_layers.u_datapath.u_attention
`define F dut.u_core.u_six_layers.u_datapath.u_value_fit
`define P dut.u_core.u_six_layers.u_datapath.u_projection
`define G dut.u_core.u_six_layers.u_datapath.u_projection.u_group_stream
`define B0 u_model_service.g_bank[0].u_bank
`define C dut.u_core
`define S dut.u_core.u_token_shell
`define MA dut.u_core.u_private_ddr_arbiter
`define SB u_rt.u_shared.u_backend
`define TILE0 dut.u_core.u_six_layers.u_datapath.u_projection.u_shared_engine.u_engine.g_tile[0].u_tile
module two_tape_numerical_tb #(
    // Simulation logical cycle bounds only; NOT native CPU/wall policy caps.
    parameter integer GLOBAL_MAX_CYCLES=2000000000,
    parameter integer OP_MAX_CYCLES=700000000
);
    localparam [255:0] MODEL_ID=256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0;
    // Observer encodings are bound to selected attention SHA285e36fd...;
    // avoid this compiler's cross-module EnumItemRef internal error only.
    localparam logic [5:0] OBS_SCORE_QUERY_USE=6'd33, OBS_VALUE_ACCUMULATE=6'd24;
    reg clk=0,ddr_clk=0;
    initial begin #1; forever #7 ddr_clk=~ddr_clk; end
    always #5 clk=~clk;
    reg reset_n=0,model_locked_i=1;
    wire upstream_fault_i;
    reg private_batch_enable_i=0;
    reg command_tape_i=0,append_valid_i=0,step_valid_i=0,token_ready_i=0;
    reg [1:0] clear_tapes_i=0;
    reg [11:0] append_token_i=0;
    reg verification_hold_guard_reply_i=0;
    wire append_ready_o,step_ready_o,token_valid_o,token_tape_o,busy_o,permanent_fault_o;
    wire [11:0] token_o;
    wire [1:0] tape_fault_o;
    wire [63:0] generation0_o,generation1_o;
    wire model_req_valid_o,model_req_ready_i,model_rsp_valid_i,model_rsp_ready_o,model_rsp_fault_i;
    wire [18:0] model_req_word_o;
    wire [255:0] model_rsp_data_i;
    wire m_wr_valid_o,m_wr_tape_o,m_wr_cpl_ready_o,m_rd_valid_o,m_rd_tape_o,m_rd_rsp_ready_o;
    wire [63:0] m_wr_generation_o,m_rd_generation_o;
    wire [255:0] m_wr_model_id_o,m_rd_model_id_o,m_wr_data_o;
    wire [2:0] m_wr_layer_o,m_rd_layer_o;
    wire [11:0] m_wr_position_o,m_rd_position_o;
    wire [1:0] m_wr_head_o,m_rd_head_o;
    wire [3:0] m_wr_word_o,m_rd_word_o;
    wire [18:0] m_wr_shadow_o,m_rd_shadow_o;
    wire m_wr_cpl_valid_i,m_wr_cpl_fault_i,m_rd_rsp_valid_i,m_rd_rsp_fault_i;
    wire [255:0] m_rd_rsp_data_i;
    wire [23:0] private_tape_counts_o,private_committed_counts_o;
    wire [143:0] private_semantic_prefixes_o,private_summary_prefixes_o;
    wire [1:0] private_last_hidden_valid_o;
    wire private_job_valid_o,private_job_tape_o,private_all_external_drained_o;
    wire [63:0] private_job_generation_o;
    integer case_id=9,profile=1,cycles=0;
    integer token_acks[0:1];
    integer stage_coordinates[0:2][0:1][0:5][0:17];
    integer cache_good[0:1][0:5][0:1][0:1];
    integer qk_groups[0:1][0:5][0:3],pv_groups[0:1][0:5][0:3];
    reg [255:0] reference_words[0:11663],model_rom[0:227061];
    localparam integer BASE=227072,BANK_WORDS=221184,WORDS=442368;
    localparam integer KV_COMMANDS=32768,RING=256;
    localparam integer MODEL_STALL_EDGES=1000,KV_STALL_EDGES=1000000;
    wire rt_fault,rt_busy,rt_rsp_valid,rt_rsp_fault;
    wire [255:0] rt_rsp_data;
    wire [360:0] rt_return_identity;
    wire [1:0] rt_return_kind;
    wire normalized_valid,normalized_ready,normalized_fire,normalized_write;
    wire [19:0] normalized_word;
    wire model_front_accept,kv_front_accept,kv_write_pending,shared_busy,shared_kv_rsp_valid,shared_kv_rsp_ready;
    wire shared_raw_valid,shared_raw_ready,shared_raw_write,shared_raw_kv,shared_raw_rsp,shared_raw_owned,shared_raw_rsp_kv;
    wire [24:0] shared_raw_word;
    wire [255:0] shared_raw_data,shared_raw_rsp_data;
    wire core_enqueue,core_bad,core_write,core_return,core_end,core_good;
    wire [28:0] core_address,app_address;
    wire [255:0] core_write_data,app_write_data;
    wire [2:0] app_command;
    wire app_command_en,app_write_en,app_write_end,app_burst,app_sr,app_ref;
    wire [31:0] app_write_mask;
    reg [255:0] app_read_data=0;
    reg app_read_valid=0,app_read_end=0;
    reg [255:0] physical_memory[0:WORDS-1];
    reg ordinary_origin[0:WORDS-1];
    integer ordinary_write_count[0:WORDS-1];
    // B retains361; the arbiter's retained class bit and FIFO order supply
    // observation lineage. Neither physical DDR nor parent has these361 ports.
    reg memory_pending=0,memory_write=0;
    reg [360:0] memory_identity=0;
    reg [255:0] memory_value=0;
    integer memory_seq=0;
    reg kv_admitted=0,kv_enqueued=0,kv_normalized=0;
    integer memory_raw_seq=0;
    reg [360:0] typed_identity[0:KV_COMMANDS-1];
    reg typed_write[0:KV_COMMANDS-1];
    reg [255:0] typed_data[0:KV_COMMANDS-1];
    integer typed_raw_seq[0:KV_COMMANDS-1];
    integer typed_requests=0,typed_acks=0,normalized_accepts=0,kv_admissions=0;
    // BOUNDED inflight rings, never arrays sized to millions of model reads.
    // Monotonic seq logged in full; stamp/occupancy assertions forbid reuse
    // before physical acceptance/owned return. No observer feeds DUT READY.
    integer raw_stamp[0:RING-1],raw_client_seq[0:RING-1];
    reg raw_is_kv[0:RING-1],raw_is_write[0:RING-1];
    reg [19:0] raw_word[0:RING-1];
    reg [360:0] raw_identity[0:RING-1];
    reg [255:0] raw_kv_data[0:RING-1];
    reg [18:0] model_front_word[0:RING-1];
    integer model_front_raw_seq[0:RING-1];
    integer model_fronts=0,model_issues=0,model_deliveries=0;
    integer backend_accepts=0,model_backend_accepts=0,kv_backend_accepts=0;
    integer backend_client_seq[0:RING-1];
    reg backend_kv[0:RING-1],backend_write[0:RING-1];
    reg [19:0] backend_word[0:RING-1];
    integer read_seq[0:RING-1],read_issue_count=0,read_return_count=0;
    integer enqueued_commands=0,physical_commands=0,core_returns=0;
    integer physical_writes=0,physical_reads=0,physical_returns=0,return_accepts=0;
    integer model_physical_reads=0,model_physical_returns=0,model_core_returns=0;
    integer kv_physical_reads=0,kv_physical_returns=0,kv_core_returns=0;
    integer high_physical_writes=0,high_physical_reads=0,high_physical_returns=0;
    integer writes=0,reads=0,guard_write_acks=0,guard_read_acks=0,atomic_external_takes=0;
    integer staged_scalars=0,parent_commits=0,pending_replies=0,external_replies=0;
    integer accepted_results=0,all_qk_groups=0,all_pv_groups=0,append_accepts=0,step_accepts=0;
    integer model_requests=0,model_responses=0,raw_requests=0,raw_responses=0;
    integer token_order=0,clear_rises=0,peer_resume_accepts=0;
    reg [1:0] previous_clear=0,preserve_context=0;
    reg [63:0] expected_generation[0:1];
    reg clear_presented=0,clear_metadata_sampled=0;
    longint unsigned clear_present_ps=0,clear_sample_ps=0,clear_metadata_ps=0,peer_resume_ps=0;
    reg [11:0] saved_tape_count[0:1],saved_committed_count[0:1];
    reg [71:0] saved_prefixes[0:1],saved_summaries[0:1];
    reg saved_hidden_valid[0:1];
    reg [63:0] saved_generation[0:1];
    reg signed [7:0] saved_maximum[0:1][0:5][0:1];
    reg saved_nonzero[0:1][0:5][0:1];
    reg snapshot_ready[0:1],physical_snapshot_ready[0:1];
    integer snapshot_positions[0:1];
    reg [255:0] saved_physical_words[0:1][0:1727];
    reg [18:0] numerical_model_word[0:RING-1];
    reg quiet=0,read_pending=0;
    integer read_pending_seq=0,read_delay=0;
    reg read_pending_kv=0;
    reg [19:0] read_pending_word=0;
    reg [255:0] read_pending_data=0;
    longint unsigned ddr_negative_edges=0,model_stall_edge=0,kv_stall_edge=0;
    reg model_stall_started=0,model_release=0,kv_stall_started=0,kv_release=0;
    integer page0_physical_reads=0,target_writes=0,raw_stall_cycles=0,backend_both_offer_cycles=0;
    // Observer-only model context metadata. These are NOT bus tags or
    // protection state. Their real FIFO/arbiter stage transitions are asserted;
    // only context changes and top accepted request/reply echoes are logged.
    // Signature[353]=sessionVALID,[352]=tape,[351:288]=generation,
    // [287:32]=model,[31:29]=op,[28]=positionVALID,[27:16]=position,
    // [15]=layerVALID,[14:12]=layer,[11]=jobVALID,[10:7]=job,
    // [6]=groupVALID,[5:0]=group. Invalid descriptor fields are zero.
    integer os_req_head[0:1],os_req_tail[0:1],os_req_count[0:1];
    integer os_rsp_head[0:1],os_rsp_tail[0:1],os_rsp_count[0:1];
    integer os_source_requests[0:1],os_source_consumed[0:1];
    integer os_req_word[0:1][0:1],os_req_ctx[0:1][0:1],os_req_seq[0:1][0:1];
    integer os_rsp_word[0:1][0:1],os_rsp_ctx[0:1][0:1],os_rsp_seq[0:1][0:1];
    reg [353:0] os_req_signature[0:1][0:1],os_rsp_signature[0:1][0:1];
    integer os_global_head=0,os_global_tail=0,os_global_count=0;
    integer os_global_source[0:15],os_global_word[0:15],os_global_ctx[0:15],os_global_seq[0:15];
    reg [353:0] os_global_signature[0:15],os_last_signature[0:1];
    reg os_context_seen[0:1];
    integer os_last_ctx[0:1],os_context_count=0,os_NONE_requests=0;
    integer os_top_req_source=0,os_top_req_ctx=0,os_top_req_seq=0;
    integer os_top_rsp_source=0,os_top_rsp_ctx=0,os_top_rsp_seq=0;
    // Same-cut arbitration RLE, sampled on actual core-positive edges.
    //23bits={MV,KV,MR,KR,MF,KF,EN,ROOM,CV,CW,KVBUSY,PREFERKV,
    // READSPACE,READCOUNT[5:0],RAWVALID,RAWREADY,RAWFIRE,RETURNING}.
    reg arb_rle_valid=0;
    reg [22:0] arb_rle_state=0;
    longint unsigned arb_rle_start_ps=0,arb_rle_first_cycle=0,arb_rle_cycles=0,arb_last_cycle=0;
    longint unsigned arb_samples=0,arb_model_offers=0,arb_kv_offers=0,arb_rle_runs=0;
    integer arb_previous_read_count=0;
    reg arb_previous_read_issue=0,arb_previous_returning=0;
    longint unsigned arb_model_only=0,arb_kv_only=0,arb_neither=0,arb_both_room=0,arb_both_eligible=0;
    longint unsigned arb_both_eligible_model=0,arb_both_eligible_kv=0,arb_offered_no_grant=0;
    longint unsigned arb_raw_read_issues=0,arb_raw_write_issues=0,arb_owned_returns=0;
    reg arb_held_model=0,arb_held_kv=0,arb_held_cmd=0,arb_saved_kv_write=0,arb_saved_cmd_write=0,arb_saved_cmd_kv=0;
    reg [18:0] arb_saved_model_word=0;
    reg [19:0] arb_saved_kv_word=0,arb_saved_cmd_word=0;
    reg [255:0] arb_saved_kv_data=0,arb_saved_cmd_data=0;
    longint unsigned arb_model_grants=0,arb_kv_grants=0,arb_both_model_grants=0,arb_both_kv_grants=0;
    longint unsigned arb_any_closed=0,arb_any_no_room=0,arb_lone_kv_busy=0;
    longint unsigned arb_raw_idle=0,arb_raw_closed=0,arb_raw_credit=0,arb_raw_stall=0,arb_raw_fire=0;

    wire ddr_ready=!((model_stall_started && !model_release)||(kv_stall_started && !kv_release));
    wire geometry_done;
    shared_arbiter_geometry_probe u_geometry(.clk(clk),.start_i(1'b1),.done_o(geometry_done));
    reg runtime_fault_q=0;
    always @(posedge clk or negedge reset_n)
        if(!reset_n) runtime_fault_q<=0;else runtime_fault_q<=runtime_fault_q||rt_fault;
    assign upstream_fault_i=runtime_fault_q;
    wire m_wr_ready_i,m_rd_ready_i;
    assign rt_rsp_valid=m_wr_cpl_valid_i||m_rd_rsp_valid_i;
    assign rt_rsp_fault=m_wr_cpl_valid_i ? m_wr_cpl_fault_i : m_rd_rsp_fault_i;
    assign rt_rsp_data=m_wr_cpl_valid_i ? 256'd0 : m_rd_rsp_data_i;
    wire raw_req_valid,raw_req_ready,raw_rsp_valid,raw_rsp_error,immutable_fault;
    wire [18:0] raw_req_word;
    wire [255:0] raw_rsp_data;
    parent_shared_model_runtime20 #(.MODEL_ID(MODEL_ID)) u_rt(
        .core_clk_i(clk),.ddr_clk_i(ddr_clk),.reset_n_i(reset_n),
        .model_locked_i(model_locked_i),.upstream_fault_i(1'b0),
        .model_raw_req_valid_i(raw_req_valid),.model_raw_req_ready_o(raw_req_ready),.model_raw_req_word_i(raw_req_word),
        .model_raw_rsp_valid_o(raw_rsp_valid),.model_raw_rsp_data_o(raw_rsp_data),.model_raw_rsp_error_o(raw_rsp_error),
        .m_wr_valid_i(m_wr_valid_o),.m_wr_ready_o(m_wr_ready_i),
        .m_wr_tape_i(m_wr_tape_o),.m_wr_generation_i(m_wr_generation_o),.m_wr_model_id_i(m_wr_model_id_o),
        .m_wr_layer_i(m_wr_layer_o),.m_wr_position_i(m_wr_position_o),.m_wr_head_i(m_wr_head_o),
        .m_wr_word_i(m_wr_word_o),.m_wr_shadow_i(m_wr_shadow_o),.m_wr_data_i(m_wr_data_o),
        .m_wr_cpl_valid_o(m_wr_cpl_valid_i),.m_wr_cpl_ready_i(m_wr_cpl_ready_o),.m_wr_cpl_fault_o(m_wr_cpl_fault_i),
        .m_rd_valid_i(m_rd_valid_o),.m_rd_ready_o(m_rd_ready_i),
        .m_rd_tape_i(m_rd_tape_o),.m_rd_generation_i(m_rd_generation_o),.m_rd_model_id_i(m_rd_model_id_o),
        .m_rd_layer_i(m_rd_layer_o),.m_rd_position_i(m_rd_position_o),.m_rd_head_i(m_rd_head_o),
        .m_rd_word_i(m_rd_word_o),.m_rd_shadow_i(m_rd_shadow_o),
        .m_rd_rsp_valid_o(m_rd_rsp_valid_i),.m_rd_rsp_ready_i(m_rd_rsp_ready_o),
        .m_rd_rsp_data_o(m_rd_rsp_data_i),.m_rd_rsp_fault_o(m_rd_rsp_fault_i),
        .private_return_identity_o(rt_return_identity),.private_return_kind_o(rt_return_kind),
        .busy_o(rt_busy),.fault_o(rt_fault),
        .private_normalized_valid_o(normalized_valid),.private_normalized_ready_o(normalized_ready),
        .private_normalized_fire_o(normalized_fire),.private_normalized_word_o(normalized_word),
        .private_normalized_write_o(normalized_write),
        .private_model_front_accept_o(model_front_accept),.private_kv_front_accept_o(kv_front_accept),
        .private_kv_write_pending_o(kv_write_pending),.private_shared_busy_o(shared_busy),
        .private_shared_kv_rsp_valid_o(shared_kv_rsp_valid),.private_shared_kv_rsp_ready_o(shared_kv_rsp_ready),
        .private_raw_req_valid_o(shared_raw_valid),.private_raw_req_ready_o(shared_raw_ready),
        .private_raw_word_o(shared_raw_word),.private_raw_write_o(shared_raw_write),.private_raw_data_o(shared_raw_data),
        .private_raw_cmd_owner_kv_o(shared_raw_kv),.private_raw_rsp_valid_o(shared_raw_rsp),
        .private_raw_rsp_owned_o(shared_raw_owned),.private_raw_rsp_owner_kv_o(shared_raw_rsp_kv),
        .private_raw_rsp_data_o(shared_raw_rsp_data),
        .controller_pll_lock_i(1'b1),.controller_calibrated_i(1'b1),
        .app_cmd_ready_i(ddr_ready),.app_wr_ready_i(ddr_ready),
        .app_cmd_o(app_command),.app_cmd_en_o(app_command_en),.app_addr_o(app_address),
        .app_wr_data_o(app_write_data),.app_wr_en_o(app_write_en),.app_wr_end_o(app_write_end),
        .app_wr_mask_o(app_write_mask),.app_rd_data_i(app_read_data),
        .app_rd_valid_i(app_read_valid),.app_rd_end_i(app_read_end),
        .app_burst_o(app_burst),.app_self_refresh_o(app_sr),.app_refresh_o(app_ref),
        .core_enqueue_o(core_enqueue),.core_bad_o(core_bad),
        .core_addr_o(core_address),.core_write_o(core_write),.core_wr_data_o(core_write_data),
        .core_rd_valid_o(core_return),.core_rd_end_o(core_end),.core_controller_good_o(core_good));
    function automatic longint unsigned ps();
        ps=longint'($realtime*1000.0);
    endfunction
    two_tape_numerical_machine #(.MODEL_ID(MODEL_ID)) dut(.*);
    board1_verified_ddr_page_service #(.ADDR_W(19),.BANKS(8),
        .DIGEST_HEX("digests32.memh"),.METADATA_HEX("metadata192.memh")) u_model_service(
        .clk(clk),.reset_n(reset_n),.cancel_i(1'b0),.model_locked_i(model_locked_i),
        .request_valid_i(model_req_valid_o),.request_ready_o(model_req_ready_i),.request_word_i(model_req_word_o),
        .response_valid_o(model_rsp_valid_i),.response_ready_i(model_rsp_ready_o),.response_data_o(model_rsp_data_i),
        .ddr_request_valid_o(raw_req_valid),.ddr_request_ready_i(raw_req_ready),.ddr_request_word_o(raw_req_word),
        .ddr_response_valid_i(raw_rsp_valid),.ddr_response_data_i(raw_rsp_data),
        .ddr_response_error_i(raw_rsp_error),.fault_o(immutable_fault));
    assign model_rsp_fault_i=immutable_fault;
    wire immutable_idle=model_fronts==model_deliveries && u_model_service.dma_state_q==0 &&
        u_model_service.request_count_q==0 && !u_model_service.head_valid_q && u_model_service.response_count_q==0;
    function automatic [18:0] shadow(input integer l,p,h,w);
        shadow=227072+18*(l*2048+p)+9*h+w;
    endfunction
    function automatic [19:0] physical_shadow(input bit t,input integer l,p,h,w);
        physical_shadow={1'b0,shadow(l,p,h,w)}+(t ? 20'd221184 : 20'd0);
    endfunction
    function automatic [63:0] generation(input bit t);
        generation=t ? generation1_o : generation0_o;
    endfunction
    `include "equal_fixture.svh"
    integer matrix_verified[0:2], release_matrix[0:2], matrix_beats[0:2];
    integer restored_kv[0:1], scalar_k[0:1], scalar_v[0:1];
    integer mode=0, accepted_steps=0, accepted_tokens=0, parked_count=0, pair_count=0, restored_count=0;
    integer verified_words=0, q_verified=0, last_gen[0:WORDS-1], q_seen[0:1], rms_seen[0:1];
    integer pair_issue_count=0, pair_hit_count=0, pair_engine_input=0, attention_count=0;
    integer release_model_responses=0;
    integer release_kv_reads=0, release_kv_writes=0;
    integer first_accept=0, release_tick=0, release_raw=0, release_weights=0, release_q=0;
    integer expected_a=867,expected_b=111,accepted_a=0,accepted_b=0,a_return=0,b_return=0;
    reg [63:0] incoming_gen;
    always @(posedge ddr_clk) if(reset_n && app_command_en) begin:memory_access
        integer a,i,t,l,p,h,w,g,fixture_gen,fixture_tape;
        a=int'(app_address[22:3]);
        if(!ddr_ready || app_address[28:23]!=0 || app_address[2:0]!=0 || app_burst || app_sr || app_ref) $fatal(1,"DDR protocol");
        if(a<227062) begin
            if(app_command!=1 || app_write_en || app_write_end || read_pending) $fatal(1,"bad model read");
            read_pending_data=model_rom[a];model_physical_reads++;
            if(a<128) page0_physical_reads++;
        end else begin
            i=a-BASE;t=i/BANK_WORDS;l=(i%BANK_WORDS)/(2048*18);p=(i/18)%2048;h=(i%18)/9;w=i%9;
            if(i<0 || i>=WORDS || l>=6 || p>=17) $fatal(1,"KV bounds");
            g=int'(generation(t[0]));
            if((t && (g<0 || g>1)) || (!t && (g<1 || g>2))) $fatal(1,"KV generation");
            if(app_command==0) begin
                if(!app_write_en || !app_write_end || app_write_mask!=0 || last_gen[i]==g ||
                   app_write_data!==ref_word(t,64'(g),l,p,h,w)) $fatal(1,"KV write t%0d g%0d l%0d p%0d h%0d w%0d",t,g,l,p,h,w);
                physical_memory[i]=app_write_data;last_gen[i]=g;physical_writes++;
                if(t==1 && l==3 && p==0) target_writes++;
            end else if(app_command==1) begin
                if(app_write_en || app_write_end || read_pending || last_gen[i]!=g ||
                   physical_memory[i]!==ref_word(t,64'(g),l,p,h,w)) $fatal(1,"KV read");
                read_pending_data=physical_memory[i];kv_physical_reads++;
            end else $fatal(1,"DDR verb");
        end
        if(app_command==1) begin read_pending=1;read_delay=3;end
    end
    always @(negedge ddr_clk) if(reset_n) begin
        ddr_negative_edges++;
        if(!model_stall_started && page0_physical_reads==17) begin model_stall_started=1;model_stall_edge=ddr_negative_edges;end
        if(model_stall_started && ddr_negative_edges-model_stall_edge==MODEL_STALL_EDGES) model_release=1;
        if(!kv_stall_started && target_writes==17) begin kv_stall_started=1;kv_stall_edge=ddr_negative_edges;end
        if(kv_stall_started && ddr_negative_edges-kv_stall_edge==KV_STALL_EDGES) kv_release=1;
        app_read_valid=0;app_read_end=0;
        if(read_pending && read_delay==0) begin app_read_data=read_pending_data;app_read_valid=1;app_read_end=1;read_pending=0;physical_returns++;end
        else if(read_pending) read_delay--;
    end

    always @(posedge clk) if(reset_n) begin:observe
        integer t,idx;
        cycles++;
        if(cycles%10000000==0) begin $display("PROGRESS clocks=%0d tokens=%0d",cycles,accepted_tokens);$fflush();end
        if(cycles>150000000 || permanent_fault_o || (|tape_fault_o) || immutable_fault || rt_fault || core_bad) begin
            $display("FAULT c=%0d phase=%0d root=%0d owner=%0d shell=%0d seq=%0d dp=%0d expected=%0d stage=%0d running=%0d sf=%0d input=%0d rootfail=%0d corefail=%0d dpfail=%0d atomic=%0d summary=%0d attention=%0d",
                cycles,dut.phase,dut.state_q,private_job_tape_o,`S.state_q,dut.u_core.u_six_layers.u_sequence.state_q,`D.engine_state_q,`D.expected_stage_q,`D.current_stage_q,`D.batch_running,`D.batch_sched_fault,`D.input_fault,
                permanent_fault_o,dut.core_permanent,`D.fault_q,`D.kv_context_fault,`D.summary_global_fault,`D.attention_context_fault);
            $fatal(1,"protected integration fault/timeout");end
        if(`G.weight_response_accept) begin verified_words++;if(`G.layer_q==0 && `G.job_q<=2) matrix_verified[`G.job_q]++;
            if(`G.layer_q==0 && `G.job_q==0) q_verified++;end
        if(model_req_valid_o && model_req_ready_i) begin numerical_model_word[model_requests%RING]=model_req_word_o;model_requests++;end
        if(model_rsp_valid_i && model_rsp_ready_o) begin
            if(model_responses>=model_requests || model_rsp_fault_i ||
               model_rsp_data_i!==model_rom[numerical_model_word[model_responses%RING]]) $fatal(1,"model FIFO/verification");
            model_responses++;
        end
        t=int'(private_job_tape_o);
        if(m_wr_valid_o && m_wr_ready_i && m_wr_generation_o!==generation(m_wr_tape_o)) $fatal(1,"stale K/V store");
        if(m_rd_valid_o && m_rd_ready_i && m_rd_generation_o!==generation(m_rd_tape_o)) $fatal(1,"stale K/V read");
        if(`D.attention_result_valid && `D.attention_result_ready) begin
            idx=attn_index(fixture_slot(t,generation(t)),int'(`D.current_position_q),int'(`D.current_layer_q),int'(`D.attention_result_head_q));
            if({`D.attention_result_exponent,`D.attention_result_vector}!==eq_attention[idx]) $fatal(1,"actual attention versus singleton t%0d idx%0d",t,idx);
            attention_count++;
        end
        if(step_valid_i && step_ready_o) begin
            accepted_steps++;if(accepted_steps==1) first_accept=cycles;
            $display("ACCEPT c=%0d n=%0d t=%0d g=%0d",cycles,accepted_steps,command_tape_i,generation(command_tape_i));$fflush();
        end
        if(token_valid_o && token_ready_i) begin
            if(token_tape_o) begin if(token_o!=expected_b) $fatal(1,"B token");accepted_b++;b_return=cycles;end
            else begin if(token_o!=expected_a) $fatal(1,"A token");accepted_a++;a_return=cycles;end
            if(release_tick>0) $display("EQUAL_RETIRE c=%0d t=%0d g=%0d projection_bytes=%0d model_interface_bytes=%0d external_model_bytes=%0d physical_kv_read_bytes=%0d physical_kv_write_bytes=%0d",cycles,token_tape_o,generation(token_tape_o),(verified_words-release_weights)*32,(model_responses-release_model_responses)*32,(model_physical_reads-release_raw)*32,(kv_physical_reads-release_kv_reads)*32,(physical_writes-release_kv_writes)*32);
            accepted_tokens++;$display("TOKEN c=%0d tape=%0d generation=%0d id=%0d",cycles,token_tape_o,generation(token_tape_o),token_o);$fflush();
        end
    end
    task automatic idle;
        while(busy_o || private_job_valid_o || !private_all_external_drained_o || rt_busy || !immutable_idle) @(negedge clk);
    endtask
    task automatic append(input bit t,input integer tok);
        begin @(negedge clk);command_tape_i=t;append_token_i=tok;append_valid_i=1;
        do @(posedge clk);while(!append_ready_o);
        @(negedge clk);append_valid_i=0;end
    endtask
    task automatic offer(input bit t);
        begin $display("OFFER c=%0d t=%0d g=%0d",cycles,t,generation(t));
        command_tape_i=t;step_valid_i=1;do @(posedge clk);while(!step_ready_o);
        @(negedge clk);step_valid_i=0;end
    endtask
    task automatic clear_a;
        begin clear_tapes_i=1;@(posedge clk);@(negedge clk);clear_tapes_i=0;end
    endtask
    task automatic context_check(input integer t,input integer n,input integer materialized);
        integer l;
        begin
            if(private_tape_counts_o[t*12 +:12]!=n || private_committed_counts_o[t*12 +:12]!=materialized ||
               private_last_hidden_valid_o[t]!=(materialized!=0)) $fatal(1,"tape/hidden context");
            for(l=0;l<6;l++) if(private_semantic_prefixes_o[(t*6+l)*12 +:12]!=materialized ||
                private_summary_prefixes_o[(t*6+l)*12 +:12]!=materialized || dut.u_guard.prefix_q[t][l]!=materialized)
                $fatal(1,"prefix context");
        end
    endtask
    task automatic clear_b;
        begin clear_tapes_i=2;@(posedge clk);@(negedge clk);clear_tapes_i=0;end
    endtask
    `include "layer_monitor.svh"
    initial begin:run
        integer i;
        if(!$value$plusargs("mode=%d",mode)) mode=0;
        if(mode<0 || mode>3) $fatal(1,"unsupported equal arm");
        load_equal_fixtures;bind_equal_fixtures;
        $readmemh("image.memh",model_rom);
        for(i=0;i<WORDS;i++) last_gen[i]=-1;
        wait(geometry_done);repeat(6) @(negedge clk);reset_n=1;while(!core_good) @(negedge clk);
        repeat(3) @(negedge clk);idle;token_ready_i=1;
        if(mode!=5) begin
            for(i=0;i<16;i++) append(1,eq_prompts[16+i]);
            offer(1);wait(accepted_b==1);@(negedge clk);idle;context_check(1,17,16);
        end
        clear_a;idle;
        for(i=0;i<16;i++) append(0,eq_prompts[i]);
        offer(0);wait(accepted_a==1);@(negedge clk);idle;context_check(0,17,16);
        if(mode==5) begin
            release_kv_reads=kv_physical_reads;release_kv_writes=physical_writes;
            expected_a=85;offer(0);wait(accepted_a==2);@(negedge clk);idle;
            context_check(0,18,17);context_check(1,0,0);
            if(accepted_steps!=2 || attention_count!=408 || q_seen[0]!=256 || scalar_k[0]!=128 ||
               scalar_v[0]!=128 || model_requests!=model_responses || read_pending ||
               physical_returns!=kv_physical_reads+model_physical_reads) $fatal(1,"A singleton monitor");
            $display("EQUAL_SINGLETON_PASS a=85 attention_outputs=%0d kv_reads=%0d kv_writes=%0d score_kv_reads=%0d score_kv_writes=%0d",
                attention_count,kv_physical_reads,physical_writes,kv_physical_reads-release_kv_reads,physical_writes-release_kv_writes);
            $display("INTEGRATED_PASS mode=%0d",mode);$finish;
        end else begin
        context_check(1,17,16);
        if(accepted_steps!=2 || generation0_o!=1 || generation1_o!=0 || attention_count!=768)
            $fatal(1,"both decode-ready P16 tapes required at release");
        expected_a=85;expected_b=490;private_batch_enable_i=mode!=0;
        for(i=0;i<3;i++) release_matrix[i]=matrix_verified[i];
        release_model_responses=model_responses;release_kv_reads=kv_physical_reads;release_kv_writes=physical_writes;
        release_tick=cycles;release_raw=model_physical_reads;release_weights=verified_words;release_q=q_verified;
        offer(0);offer(1);
        if(mode==2 || mode==3)begin : cancel_parked
            integer victim;
            victim=mode==2?1:0;
            wait(dut.parked_valid[victim] && dut.parked_job[victim]>=3 && private_job_valid_o &&
                 private_job_tape_o!=victim && !`D.batch_running);
            @(negedge clk);
            if(dut.guard_busy || dut.kv_external || dut.attention_external || dut.batch.load)
                $fatal(1,"cut coincides with outstanding owner or load");
            $display("L0_CLEAR c=%0d t=%0d gen=%0d parked_job=%0d",cycles,victim,generation(victim),dut.parked_job[victim]);
            cut_count++;
            if(victim)begin clear_b;expected_b=15;end else begin clear_a;expected_a=15;end
        end
        wait(accepted_b==(mode==2 ? 1:2) && accepted_a==(mode>=3 ? 1:2));@(negedge clk);idle;
        if(mode==2) begin context_check(0,18,17);context_check(1,0,0);end
        else if(mode>=3) begin context_check(0,0,0);context_check(1,18,17);end
        else begin context_check(0,18,17);context_check(1,18,17);end
        for(int t=0;t<2;t++)if(mode<=1 || t!=(mode==2?1:0))begin
            for(int j=0;j<7;j++) if(checked_raw[t][j]!=rows_for(j) || checked_norm[t][j]!=rows_for(j))
                $fatal(1,"missing layer rows mode=%0d t=%0d j=%0d n=%0d/%0d",mode,t,j,checked_raw[t][j],checked_norm[t][j]);
            if(scored[t]!=4019 || input_head[t]!=256 || appended[t]!=1)$fatal(1,"missing or repeated head");
        end
        if(mode==0 && (swaps!=0 || starts!=0 || hits!=0 || arith!=0))$fatal(1,"serial mode");
        if(mode==1 && (swaps==0 || checkpoint_marks<2 || starts!=7 || hits!=38 || arith!=22864))
            $fatal(1,"paired schedule census s=%d h=%d mac=%d swap=%d parks=%d",starts,hits,arith,swaps,checkpoint_marks);
        for(int j=0;j<7;j++) begin
            int n;
            n=j==6?682:256;
            if(mode<=1 && mat_words[j]!=((rows_for(j)+63)/64)*n*5/2*(mode==0?2:1))$fatal(1,"matrix traffic");
            $display("L0_MATRIX j=%0d words=%0d raw_a=%0d raw_b=%0d norm_a=%0d norm_b=%0d",j,mat_words[j],
                checked_raw[0][j],checked_raw[1][j],checked_norm[0][j],checked_norm[1][j]);
        end
        if(mode<=1 && (a_return>=b_return || attention_count!=816))$fatal(1,"joint attention/public ordering");
        if(mode>=2 && (cut_count!=1 || appended[mode==2?1:0]!=0))$fatal(1,"stale append after CLEAR");
        $display("L0_TOTAL mode=%0d release=%0d A=%0d B=%0d drain=%0d weights=%0d model=%0d external=%0d kv_reads=%0d kv_writes=%0d starts=%0d hits=%0d mac=%0d swaps=%0d pending_parks=%0d",mode,release_tick,a_return,b_return,cycles,
            (verified_words-release_weights)*32,(model_responses-release_model_responses)*32,(model_physical_reads-release_raw)*32,
            (kv_physical_reads-release_kv_reads)*32,(physical_writes-release_kv_writes)*32,starts,hits,arith,swaps,checkpoint_marks);
        if(mode>=2) begin
            private_batch_enable_i=0;
            if(mode==2) begin
                if(generation1_o!=1 || accepted_b!=1) $fatal(1,"stale B");
                append(1,380);offer(1);wait(accepted_b==2);@(negedge clk);idle;
                context_check(0,18,17);context_check(1,2,1);
            end else begin
                if(generation0_o!=2 || accepted_a!=1) $fatal(1,"stale A");
                append(0,380);offer(0);wait(accepted_a==2);@(negedge clk);idle;
                context_check(0,2,1);context_check(1,18,17);
            end
        end
        if(mode>=2 && (scored[2]!=4019 || input_head[2]!=256 || appended[2]!=1))$fatal(1,"fresh output");
        if(model_requests!=model_responses || physical_returns!=kv_physical_reads+model_physical_reads || read_pending)
            $fatal(1,"final drain");
        $display("INTEGRATED_PASS mode=%0d",mode);$finish;
        end
    end
endmodule

// PRIVATE integration derivative of8eb70f3db25a484d42635c5cd6f1054c65ae50069e658b50154ecfaf96c4feae. Original passing component remains frozen.
`timescale 1ns/1ps
`default_nettype none

// PRIVATE finite two-tape component, derived from the released real guard.
// One shared transport/stage/cache/hash/SHA engine; two actual mutable owners.
// Each tape starts empty. Trusted fixed-controller inputs only, not host ports.
// Transport contract remains one completion per accepted downstream request;
// reset requires coordinated transport cancellation, as in the baseline.
module board1_two_tape_kv_integrity_guard #(
    parameter integer DDR_TIMEOUT_CYCLES=50000000,
    parameter logic [255:0] MODEL_ID=256'd0
) (
    input wire clk,reset_n,model_locked_i,
    input wire [1:0] clear_i,upstream_fault_i,
    input wire s_wr_valid,s_wr_tape,
    output wire s_wr_ready,
    input wire [2:0] s_wr_layer,
    input wire [11:0] s_wr_position,
    input wire [1:0] s_wr_head,
    input wire [3:0] s_wr_word,
    input wire [18:0] s_wr_shadow,
    input wire [255:0] s_wr_data,
    output wire s_wr_cpl_valid,
    input wire s_wr_cpl_ready,
    output wire s_wr_cpl_fault,s_wr_cpl_tape,
    output wire [63:0] s_wr_cpl_generation,
    output wire [255:0] s_wr_cpl_model_id,
    output wire [2:0] s_wr_cpl_layer,
    output wire [11:0] s_wr_cpl_position,
    output wire [6:0] s_wr_cpl_page,
    output wire [1:0] s_wr_cpl_head,s_wr_cpl_role,
    output wire [4:0] s_wr_cpl_positions,
    output wire [3:0] s_wr_cpl_word,
    output wire [18:0] s_wr_cpl_shadow,
    input wire s_rd_valid,s_rd_tape,
    output wire s_rd_ready,
    input wire [2:0] s_rd_layer,
    input wire [11:0] s_rd_position,
    input wire [1:0] s_rd_head,
    input wire [3:0] s_rd_word,
    input wire [18:0] s_rd_shadow,
    output wire s_rd_rsp_valid,
    input wire s_rd_rsp_ready,
    output wire [255:0] s_rd_rsp_data,
    output wire s_rd_rsp_fault,s_rd_rsp_tape,
    output wire [63:0] s_rd_rsp_generation,
    output wire [255:0] s_rd_rsp_model_id,
    output wire [2:0] s_rd_rsp_layer,
    output wire [11:0] s_rd_rsp_position,
    output wire [6:0] s_rd_rsp_page,
    output wire [1:0] s_rd_rsp_head,s_rd_rsp_role,
    output wire [4:0] s_rd_rsp_positions,
    output wire [3:0] s_rd_rsp_word,
    output wire [18:0] s_rd_rsp_shadow,
    output wire m_wr_valid,m_wr_tape,
    input wire m_wr_ready,
    output wire [63:0] m_wr_generation,
    output wire [255:0] m_wr_model_id,
    output wire [2:0] m_wr_layer,
    output wire [11:0] m_wr_position,
    output wire [1:0] m_wr_head,
    output wire [3:0] m_wr_word,
    output wire [18:0] m_wr_shadow,
    output wire [255:0] m_wr_data,
    input wire m_wr_cpl_valid,
    output wire m_wr_cpl_ready,
    input wire m_wr_cpl_fault,
    output wire m_rd_valid,m_rd_tape,
    input wire m_rd_ready,
    output wire [63:0] m_rd_generation,
    output wire [255:0] m_rd_model_id,
    output wire [2:0] m_rd_layer,
    output wire [11:0] m_rd_position,
    output wire [1:0] m_rd_head,
    output wire [3:0] m_rd_word,
    output wire [18:0] m_rd_shadow,
    input wire m_rd_rsp_valid,
    output wire m_rd_rsp_ready,
    input wire [255:0] m_rd_rsp_data,
    input wire m_rd_rsp_fault,
    output wire [1:0] fault_o,
    output wire [1:0] integrity_fault_o,
    output wire permanent_fault_o,
    output wire raw_transport_protocol_fault_o,
    output wire [63:0] generation0_o,generation1_o,
    output wire busy_o
);
    localparam [4:0] IDLE=0,WREQ=1,WWAIT=2,WSTORE=3,WRETURN=4,
        RREQ=5,RWAIT=6,RSTORE=7,TREAD=8,TCAP=9,HBEGIN=10,HREAD=11,
        HCAP=12,HWORD=13,HDIGEST=14,TWRITE=15,OREAD=16,OCAP=17,RRETURN=18;
    localparam [1:0] NONE=0,WRITE_OWNER=1,READ_OWNER=2;
    localparam integer WATCH_W=DDR_TIMEOUT_CYCLES>1 ? $clog2(DDR_TIMEOUT_CYCLES+1) : 1;
    initial if(DDR_TIMEOUT_CYCLES<1) $fatal(1,"Invalid two-tape DDR timeout");
    logic [4:0] state_q;
    logic [1:0] owner_q,fault_q,clear_seen_q;
    logic lock_seen_q,aborted_q,owner_tape_q;
    logic [63:0] generation_q[0:1],owner_generation_q;
    logic [255:0] owner_model_id_q;
    logic [11:0] prefix_q[0:1][0:5];
    logic [1:0] population_q,next_head_q;
    logic [2:0] population_layer_q[0:1];
    logic [11:0] population_position_q[0:1];
    logic [3:0] next_word_q[0:1];
    // Original accepted request identity is NEVER reused as scan/hash storage.
    logic [2:0] request_layer_q;
    logic [11:0] request_position_q;
    logic [6:0] request_page_q;
    logic [1:0] request_head_q,request_role_q;
    logic [4:0] request_positions_q;
    logic [3:0] request_word_q;
    logic [18:0] request_shadow_q;
    logic [2:0] layer_q;
    logic [11:0] position_q;
    logic head_q;
    logic [3:0] row_word_q;
    logic [6:0] page_q;
    logic [4:0] positions_q;
    logic group_head_q,role_q;
    logic [6:0] target_slot_q,scan_slot_q,hash_slot_q,total_slots_q;
    logic [3:0] scan_position_q,hash_position_q;
    logic [2:0] scan_group_word_q,hash_group_word_q,chunk_q;
    logic hash_write_q;
    logic [255:0] word_q,assembly_q,expected_q,digest_q;
    logic cache_valid_q,cache_tape_q,cache_head_q,cache_role_q;
    logic [2:0] cache_layer_q;
    logic [4:0] cache_positions_q;
    logic [6:0] cache_page_q;
    logic [63:0] cache_generation_q;
    logic [255:0] cache_model_id_q;
    logic [WATCH_W-1:0] watchdog_q;

    function automatic [18:0] address(input [2:0] layer,
        input [11:0] position,input [1:0] head,input [3:0] word_index);
        reg [14:0] row;
        begin
            row={layer,position[10:0],1'b0}+{13'd0,head};
            address=19'd227072+{1'b0,row,3'd0}+{4'd0,row}+{15'd0,word_index};
        end
    endfunction
    function automatic [8:0] partial_slot_for(input [3:0] position_mod,input head,input [3:0] word_index);
        partial_slot_for={1'b0,position_mod,4'd0}+{4'd0,position_mod,1'b0}+
            {5'd0,head,3'd0}+{8'd0,head}+{5'd0,word_index};
    endfunction
    function automatic [6:0] role_slot(input [3:0] position_mod,input [3:0] word_index);
        role_slot={1'b0,position_mod,2'd0}+{3'd0,position_mod}+
            (word_index==8 ? 7'd4 : {5'd0,word_index[1:0]});
    endfunction
    function automatic [3:0] role_word(input role,input [2:0] index);
        role_word=index==4 ? 4'd8 : {1'b0,role,index[1:0]};
    endfunction
    function automatic [13:0] layer_base(input [2:0] layer);
        layer_base={layer,11'd0}+{3'd0,layer,8'd0};
    endfunction
    wire wr_tape_known=(s_wr_tape===1'b0)||(s_wr_tape===1'b1);
    wire rd_tape_known=(s_rd_tape===1'b0)||(s_rd_tape===1'b1);
    wire wr_shape=wr_tape_known && s_wr_layer<6 && s_wr_position<2048 && s_wr_head<2 && s_wr_word<9;
    wire rd_shape=rd_tape_known && s_rd_layer<6 && s_rd_position<2048 && s_rd_head<2 && s_rd_word<9;
    wire wr_legal=wr_shape && s_wr_shadow==address(s_wr_layer,s_wr_position,s_wr_head,s_wr_word) &&
        (population_q[s_wr_tape] ?
            (s_wr_layer==population_layer_q[s_wr_tape] && s_wr_position==population_position_q[s_wr_tape] &&
             s_wr_head=={1'b0,next_head_q[s_wr_tape]} && s_wr_word==next_word_q[s_wr_tape]) :
            (s_wr_head==0 && s_wr_word==0 && s_wr_position==prefix_q[s_wr_tape][s_wr_layer]));
    wire rd_legal=rd_shape && s_rd_shadow==address(s_rd_layer,s_rd_position,s_rd_head,s_rd_word) &&
        !population_q[s_rd_tape] && s_rd_position<prefix_q[s_rd_tape][s_rd_layer];
    wire [11:0] page_valid_remaining=rd_shape ?
        prefix_q[s_rd_tape][s_rd_layer]-{s_rd_position[11:4],4'd0} : 12'd0;
    wire [4:0] read_positions=page_valid_remaining>=16 ? 5'd16 : page_valid_remaining[4:0];
    wire cache_identity=cache_valid_q && cache_tape_q==s_rd_tape &&
        cache_generation_q==generation_q[s_rd_tape] && cache_model_id_q==MODEL_ID &&
        cache_layer_q==s_rd_layer && cache_page_q==s_rd_position[10:4] &&
        cache_positions_q==read_positions && {1'b0,cache_head_q}==s_rd_head;
    wire read_role=s_rd_word==8 ? (cache_identity && cache_role_q) : s_rd_word[2];
    wire cache_hit=cache_identity && cache_role_q==read_role;
    wire hash_begin_ready,hash_word_ready,hash_digest_valid,hash_fault;
    wire [255:0] hash_digest;
    wire owner_present=owner_q!=NONE;
    wire owner_current=owner_present && owner_generation_q==generation_q[owner_tape_q] && owner_model_id_q==MODEL_ID;
    wire active_clear=owner_present && clear_i[owner_tape_q];
    wire wr_completion=m_wr_cpl_valid===1'b1;
    wire rd_completion=m_rd_rsp_valid===1'b1;
    wire unexpected=(m_wr_cpl_valid && state_q!=WWAIT)||(m_rd_rsp_valid && state_q!=RWAIT);
    // Reg-state/raw-input only: safe for same-edge publication veto without
    // feeding request validation back into the producer VALID path.
    assign raw_transport_protocol_fault_o=reset_n && unexpected;
    wire timeout_now=(state_q==WWAIT || state_q==RWAIT) && watchdog_q==WATCH_W'(DDR_TIMEOUT_CYCLES-1);
`ifndef SYNTHESIS
    wire unknown_global=$isunknown({reset_n,clear_i,model_locked_i,upstream_fault_i,
        m_wr_cpl_valid,m_rd_rsp_valid,MODEL_ID,state_q,owner_q,owner_tape_q,
        generation_q[0],generation_q[1],owner_generation_q,owner_model_id_q}) ||
        (state_q==WREQ && $isunknown(m_wr_ready)) || (state_q==RREQ && $isunknown(m_rd_ready));
    wire wr_unknown=state_q==IDLE && s_wr_valid &&
        $isunknown({s_wr_tape,s_wr_layer,s_wr_position,s_wr_head,s_wr_word,s_wr_shadow,s_wr_data});
    wire rd_unknown=state_q==IDLE && s_rd_valid &&
        $isunknown({s_rd_tape,s_rd_layer,s_rd_position,s_rd_head,s_rd_word,s_rd_shadow});
    wire request_global_unknown=$isunknown({s_wr_valid,s_rd_valid}) ||
        (state_q==IDLE && ((s_wr_valid && !wr_tape_known)||(s_rd_valid && !rd_tape_known)));
    wire owned_unknown=owner_present &&
        ((state_q==WWAIT && m_wr_cpl_valid && $isunknown(m_wr_cpl_fault)) ||
         (state_q==RWAIT && m_rd_rsp_valid && $isunknown({m_rd_rsp_data,m_rd_rsp_fault})) ||
         (state_q==WRETURN && $isunknown(s_wr_cpl_ready)) ||
         (state_q==RRETURN && $isunknown(s_rd_rsp_ready)));
`else
    wire unknown_global=1'b0,wr_unknown=1'b0,rd_unknown=1'b0;
    wire request_global_unknown=1'b0,owned_unknown=1'b0;
`endif
    wire global_fault_event=(MODEL_ID==256'd0) || (lock_seen_q && !model_locked_i) || unexpected || unknown_global;
    logic [1:0] local_fault_event,request_violation;
    always_comb begin
        local_fault_event=upstream_fault_i;
        request_violation=2'b00;
        for(integer t=0;t<2;t=t+1) begin
            if(clear_i[t] && !clear_seen_q[t] && (&generation_q[t])) local_fault_event[t]=1;
        end
        if(owner_present && (hash_fault || timeout_now || owned_unknown ||
            (state_q==WWAIT && m_wr_cpl_valid && m_wr_cpl_fault && !aborted_q && !active_clear) ||
            (state_q==RWAIT && m_rd_rsp_valid && m_rd_rsp_fault && !aborted_q && !active_clear)))
            local_fault_event[owner_tape_q]=1;
        // No combinational request-valid -> fault_o -> parent-valid loop.
        if(request_global_unknown) request_violation=2'b11;
        else begin
            if(wr_unknown && wr_tape_known) request_violation[s_wr_tape]=1;
            if(rd_unknown && rd_tape_known) request_violation[s_rd_tape]=1;
            if(state_q==IDLE && s_wr_valid && s_rd_valid) begin
                if(wr_tape_known) request_violation[s_wr_tape]=1;
                if(rd_tape_known) request_violation[s_rd_tape]=1;
            end
        end
    end
    wire [1:0] terminal_now=fault_q | local_fault_event | {2{global_fault_event}};
    wire active_fault=owner_present && terminal_now[owner_tape_q];
    wire canceled=owner_present && (aborted_q || active_clear || !owner_current);
    wire live=reset_n && model_locked_i && owner_present && !canceled && !active_fault;
    wire wr_live=reset_n && model_locked_i && wr_tape_known && !clear_i[s_wr_tape] && !terminal_now[s_wr_tape];
    wire rd_live=reset_n && model_locked_i && rd_tape_known && !clear_i[s_rd_tape] && !terminal_now[s_rd_tape];
    assign fault_o=reset_n ? terminal_now : 2'b00;
    assign generation0_o=generation_q[0];
    assign generation1_o=generation_q[1];
    assign busy_o=owner_present || state_q!=IDLE;
    assign s_wr_ready=wr_live && state_q==IDLE && !s_rd_valid;
    assign s_rd_ready=rd_live && state_q==IDLE && !s_wr_valid;
    wire write_fire=s_wr_valid && s_wr_ready;
    wire read_fire=s_rd_valid && s_rd_ready;
    // ONLY an actual retained-owner read digest mismatch is locally
    // quarantinable. Timeout/protocol/transport/unknown/overflow stays global.
    logic [1:0] integrity_fault_q;
    logic permanent_cause_q;
    wire digest_mismatch_event=live && state_q==HDIGEST && !hash_write_q &&
        hash_digest_valid && hash_digest!=expected_q;
    logic digest_unknown;
    always_comb begin
        digest_unknown=1'b0;
`ifndef SYNTHESIS
        if(state_q==HDIGEST && hash_digest_valid && $isunknown({hash_digest,expected_q}))
            digest_unknown=1'b1;
`endif
    end
    // A canceled upstream ACK is expected and is not a transport error.
    // A fault status on an actual downstream completion is different: it
    // remains permanently attributable to the shared transport even when
    // CLEAR has already canceled the retained computation.
    wire raw_transport_fault_event=(m_wr_cpl_valid && m_wr_cpl_fault) ||
        (m_rd_rsp_valid && m_rd_rsp_fault);
    wire independent_guard_event=global_fault_event || (|local_fault_event) || raw_transport_fault_event ||
        (|request_violation) || state_q>RRETURN || owner_q>READ_OWNER || digest_unknown ||
        (write_fire && (wr_unknown || !wr_legal)) ||
        (read_fire && (rd_unknown || !rd_legal));
    assign integrity_fault_o=reset_n ? (integrity_fault_q |
        (digest_mismatch_event ? (owner_tape_q ? 2'b10 : 2'b01) : 2'b00)) : 2'b00;
    assign permanent_fault_o=reset_n && (permanent_cause_q || independent_guard_event);
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin integrity_fault_q<=0;permanent_cause_q<=0;end
        else begin
            if(independent_guard_event) permanent_cause_q<=1;
            if(digest_mismatch_event) integrity_fault_q[owner_tape_q]<=1;
        end
    end
    assign s_wr_cpl_valid=reset_n && state_q==WRETURN && owner_q==WRITE_OWNER;
    assign s_rd_rsp_valid=reset_n && state_q==RRETURN && owner_q==READ_OWNER;
    assign s_wr_cpl_fault=s_wr_cpl_valid && (active_fault || canceled || !model_locked_i);
    assign s_rd_rsp_fault=s_rd_rsp_valid && (active_fault || canceled || !model_locked_i);
    assign s_rd_rsp_data=s_rd_rsp_valid && !s_rd_rsp_fault ? assembly_q : 256'd0;
    assign s_wr_cpl_tape=owner_tape_q; assign s_rd_rsp_tape=owner_tape_q;
    assign s_wr_cpl_generation=owner_generation_q; assign s_rd_rsp_generation=owner_generation_q;
    assign s_wr_cpl_model_id=owner_model_id_q; assign s_rd_rsp_model_id=owner_model_id_q;
    assign s_wr_cpl_layer=request_layer_q; assign s_rd_rsp_layer=request_layer_q;
    assign s_wr_cpl_position=request_position_q; assign s_rd_rsp_position=request_position_q;
    assign s_wr_cpl_page=request_page_q; assign s_rd_rsp_page=request_page_q;
    assign s_wr_cpl_head=request_head_q; assign s_rd_rsp_head=request_head_q;
    assign s_wr_cpl_role=request_role_q; assign s_rd_rsp_role=request_role_q;
    assign s_wr_cpl_positions=request_positions_q; assign s_rd_rsp_positions=request_positions_q;
    assign s_wr_cpl_word=request_word_q; assign s_rd_rsp_word=request_word_q;
    assign s_wr_cpl_shadow=request_shadow_q; assign s_rd_rsp_shadow=request_shadow_q;
    assign m_wr_valid=live && state_q==WREQ; assign m_rd_valid=live && state_q==RREQ;
    assign m_wr_tape=owner_tape_q; assign m_rd_tape=owner_tape_q;
    assign m_wr_generation=owner_generation_q; assign m_rd_generation=owner_generation_q;
    assign m_wr_model_id=owner_model_id_q; assign m_rd_model_id=owner_model_id_q;
    assign m_wr_layer=layer_q; assign m_wr_position=position_q; assign m_wr_head={1'b0,head_q};
    assign m_wr_word=row_word_q; assign m_wr_data=word_q;
    assign m_wr_shadow=address(layer_q,position_q,{1'b0,head_q},row_word_q);
    assign m_wr_cpl_ready=reset_n && state_q==WWAIT;
    assign m_rd_layer=layer_q; assign m_rd_position={1'b0,page_q,scan_position_q};
    assign m_rd_head={1'b0,group_head_q}; assign m_rd_word=role_word(role_q,scan_group_word_q);
    assign m_rd_shadow=address(m_rd_layer,m_rd_position,m_rd_head,m_rd_word);
    assign m_rd_rsp_ready=reset_n && state_q==RWAIT;

    // Per-tape partial/tag banks; exactly ONE shared retained stage/cache bank.
    // RAM bits have no reset: only current generation/prefix/cache authority
    // makes them accessible. Writes from empty initialize every committed byte.
    (* ram_style="block" *) logic [31:0] partial_memory[0:1][0:13823];
    (* ram_style="block" *) logic [31:0] stage_memory[0:639];
    logic [31:0] partial_data_q,stage_data_q;
    wire [8:0] partial_slot=state_q==WSTORE ? partial_slot_for(position_q[3:0],head_q,row_word_q) :
        partial_slot_for(hash_position_q,group_head_q,role_word(role_q,hash_group_word_q));
    wire [13:0] partial_address=layer_base(layer_q)+{2'd0,partial_slot,chunk_q};
    wire [6:0] stage_slot=state_q==RSTORE ? scan_slot_q :
        ((state_q==OREAD || state_q==OCAP) ? target_slot_q : hash_slot_q);
    wire [9:0] stage_address={stage_slot,chunk_q};
    wire tag_read=live && state_q==TREAD;
    wire tag_write=live && state_q==TWRITE;
    wire [11:0] tag_address={page_q,group_head_q,role_q,chunk_q};
    wire [31:0] tag_data[0:1][0:5];
    for(genvar tape=0;tape<2;tape=tape+1) begin:g_tapes
        for(genvar bank=0;bank<6;bank=bank+1) begin:g_tags
            (* ram_style="block" *) logic [31:0] memory[0:4095];
            logic [31:0] read_q;
            always_ff @(posedge clk) begin
                if(tag_write && owner_tape_q==tape && layer_q==bank) memory[tag_address]<=digest_q[chunk_q*32 +:32];
                if(tag_read && owner_tape_q==tape) read_q<=memory[tag_address];
            end
            assign tag_data[tape][bank]=read_q;
        end
    end
    always_ff @(posedge clk) begin
        if(live && state_q==WSTORE) partial_memory[owner_tape_q][partial_address]<=word_q[chunk_q*32 +:32];
        if(live && state_q==RSTORE) stage_memory[stage_address]<=word_q[chunk_q*32 +:32];
        if(live && state_q==HREAD && hash_write_q) partial_data_q<=partial_memory[owner_tape_q][partial_address];
        if(live && ((state_q==HREAD && !hash_write_q) || state_q==OREAD)) stage_data_q<=stage_memory[stage_address];
        if(live && state_q==HCAP) assembly_q[chunk_q*32 +:32]<=hash_write_q ? partial_data_q : stage_data_q;
        if(live && state_q==OCAP) assembly_q[chunk_q*32 +:32]<=stage_data_q;
        if(live && state_q==TCAP) expected_q[chunk_q*32 +:32]<=tag_data[owner_tape_q][layer_q];
        if(write_fire) word_q<=s_wr_data;
        if(live && state_q==RWAIT && rd_completion) word_q<=m_rd_rsp_data;
        if(live && state_q==HDIGEST && hash_digest_valid) digest_q<=hash_digest;
    end
    wire hash_clear=owner_present && (active_clear || active_fault || aborted_q || !owner_current);
    two_tape_kv_page_hash #(.MODEL_ID(MODEL_ID)) u_hash(
        .clk(clk),.reset_n(reset_n),.clear_i(hash_clear),
        .begin_valid_i(live && state_q==HBEGIN),.begin_ready_o(hash_begin_ready),
        .tape_i(owner_tape_q),.generation_i(owner_generation_q),.layer_i(layer_q),.page_i(page_q),
        .head_i(group_head_q),.role_i(role_q),.positions_i(positions_q),
        .word_valid_i(live && state_q==HWORD),.word_ready_o(hash_word_ready),.word_i(assembly_q),
        .digest_valid_o(hash_digest_valid),.digest_ready_i(live && state_q==HDIGEST),
        .digest_o(hash_digest),.fault_o(hash_fault));

    integer t,l;
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state_q<=IDLE;owner_q<=NONE;fault_q<=0;clear_seen_q<=0;lock_seen_q<=0;aborted_q<=0;
            owner_tape_q<=0;owner_generation_q<=0;owner_model_id_q<=0;
            for(t=0;t<2;t=t+1) begin
                generation_q[t]<=0;population_q[t]<=0;population_layer_q[t]<=0;
                population_position_q[t]<=0;next_head_q[t]<=0;next_word_q[t]<=0;
                for(l=0;l<6;l=l+1) prefix_q[t][l]<=0;
            end
            request_layer_q<=0;request_position_q<=0;request_page_q<=0;request_head_q<=0;
            request_role_q<=0;request_positions_q<=0;request_word_q<=0;request_shadow_q<=0;
            layer_q<=0;position_q<=0;head_q<=0;row_word_q<=0;page_q<=0;positions_q<=0;
            target_slot_q<=0;scan_slot_q<=0;hash_slot_q<=0;total_slots_q<=0;
            scan_position_q<=0;scan_group_word_q<=0;chunk_q<=0;hash_write_q<=0;
            hash_position_q<=0;hash_group_word_q<=0;group_head_q<=0;role_q<=0;
            cache_valid_q<=0;cache_tape_q<=0;cache_head_q<=0;cache_role_q<=0;
            cache_layer_q<=0;cache_positions_q<=0;cache_page_q<=0;cache_generation_q<=0;cache_model_id_q<=0;
            watchdog_q<=0;
        end else begin
            clear_seen_q<=clear_i;
            if(model_locked_i) lock_seen_q<=1;
            fault_q<=fault_q | local_fault_event | request_violation | {2{global_fault_event}};
            if(state_q!=WWAIT && state_q!=RWAIT) watchdog_q<=0;
            else if(!timeout_now) watchdog_q<=watchdog_q+1'b1;
            for(t=0;t<2;t=t+1) begin
                if(clear_i[t]) begin
                    if(!clear_seen_q[t] && !(&generation_q[t])) generation_q[t]<=generation_q[t]+1'b1;
                end
                if(clear_i[t] || terminal_now[t] || request_violation[t]) begin
                    for(l=0;l<6;l=l+1) prefix_q[t][l]<=0;
                    population_q[t]<=0;next_head_q[t]<=0;next_word_q[t]<=0;
                    if(cache_valid_q && cache_tape_q==t) cache_valid_q<=0;
                end
            end
            if(owner_present && (active_clear || active_fault || !owner_current)) aborted_q<=1;

            // An issued old-generation word must drain under its captured owner.
            // Neither timeout nor CLEAR opens the transport for a fresh request.
            // An upstream canceled/fault response is an owned bad ACK, never a
            // good attention operand; its captured identity remains unchanged.
            if(owner_present && (active_clear || aborted_q || active_fault || !owner_current)) begin
                if((state_q==WWAIT && !wr_completion)||(state_q==RWAIT && !rd_completion)) begin
                    // Wait indefinitely if necessary; peer availability cannot
                    // be promised when the one physical transport never drains.
                end else if(owner_q==WRITE_OWNER) begin
                    if(state_q==WRETURN && s_wr_cpl_ready) begin owner_q<=NONE;state_q<=IDLE;aborted_q<=0;end
                    else state_q<=WRETURN;
                end else if(owner_q==READ_OWNER) begin
                    if(state_q==RRETURN && s_rd_rsp_ready) begin owner_q<=NONE;state_q<=IDLE;aborted_q<=0;end
                    else state_q<=RRETURN;
                end
            end else case(state_q)
                IDLE: begin
                    if(write_fire) begin
                        owner_q<=WRITE_OWNER;owner_tape_q<=s_wr_tape;
                        owner_generation_q<=generation_q[s_wr_tape];owner_model_id_q<=MODEL_ID;aborted_q<=0;
                        request_layer_q<=s_wr_layer;request_position_q<=s_wr_position;request_page_q<=s_wr_position[10:4];
                        request_head_q<=s_wr_head;request_word_q<=s_wr_word;request_shadow_q<=s_wr_shadow;
                        request_role_q<=s_wr_word==8 ? 2'd2 : {1'b0,s_wr_word[2]};
                        request_positions_q<={1'b0,s_wr_position[3:0]}+5'd1;
                        if(cache_valid_q && cache_tape_q==s_wr_tape) cache_valid_q<=0;
                        if(wr_unknown || !wr_legal) begin fault_q[s_wr_tape]<=1;state_q<=WRETURN;end
                        else begin
                            layer_q<=s_wr_layer;position_q<=s_wr_position;head_q<=s_wr_head[0];row_word_q<=s_wr_word;
                            page_q<=s_wr_position[10:4];positions_q<={1'b0,s_wr_position[3:0]}+5'd1;
                            if(!population_q[s_wr_tape]) begin
                                population_q[s_wr_tape]<=1;population_layer_q[s_wr_tape]<=s_wr_layer;
                                population_position_q[s_wr_tape]<=s_wr_position;
                            end
                            state_q<=WREQ;
                        end
                    end else if(read_fire) begin
                        owner_q<=READ_OWNER;owner_tape_q<=s_rd_tape;
                        owner_generation_q<=generation_q[s_rd_tape];owner_model_id_q<=MODEL_ID;aborted_q<=0;
                        request_layer_q<=s_rd_layer;request_position_q<=s_rd_position;request_page_q<=s_rd_position[10:4];
                        request_head_q<=s_rd_head;request_word_q<=s_rd_word;request_shadow_q<=s_rd_shadow;
                        request_role_q<={1'b0,read_role};request_positions_q<=read_positions;
                        if(rd_unknown || !rd_legal) begin fault_q[s_rd_tape]<=1;state_q<=RRETURN;end
                        else begin
                            layer_q<=s_rd_layer;page_q<=s_rd_position[10:4];positions_q<=read_positions;
                            group_head_q<=s_rd_head[0];role_q<=read_role;
                            target_slot_q<=role_slot(s_rd_position[3:0],s_rd_word);
                            total_slots_q<={read_positions,2'b0}+{2'd0,read_positions};chunk_q<=0;
                            if(cache_hit) state_q<=OREAD;
                            else begin
                                cache_valid_q<=0;scan_slot_q<=0;scan_position_q<=0;scan_group_word_q<=0;state_q<=RREQ;
                            end
                        end
                    end
                end
                WREQ: if(m_wr_ready) state_q<=WWAIT;
                WWAIT: if(wr_completion) begin chunk_q<=0;state_q<=WSTORE;end
                WSTORE: if(chunk_q==7) begin
                    chunk_q<=0;
                    if(head_q && row_word_q==8) begin
                        hash_write_q<=1;hash_slot_q<=0;hash_position_q<=0;hash_group_word_q<=0;
                        group_head_q<=0;role_q<=0;
                        total_slots_q<={positions_q,2'b0}+{2'd0,positions_q};state_q<=HBEGIN;
                    end else state_q<=WRETURN;
                end else chunk_q<=chunk_q+1'b1;
                WRETURN: if(s_wr_cpl_ready) begin
                    owner_q<=NONE;state_q<=IDLE;
                    if(row_word_q==8) begin
                        next_word_q[owner_tape_q]<=0;next_head_q[owner_tape_q]<=1;
                        if(head_q) begin population_q[owner_tape_q]<=0;next_head_q[owner_tape_q]<=0;end
                    end else next_word_q[owner_tape_q]<=row_word_q+1'b1;
                end
                RREQ: if(m_rd_ready) state_q<=RWAIT;
                RWAIT: if(rd_completion) begin chunk_q<=0;state_q<=RSTORE;end
                RSTORE: if(chunk_q==7) begin
                    chunk_q<=0;
                    if(scan_slot_q==total_slots_q-1'b1) state_q<=TREAD;
                    else begin
                        scan_slot_q<=scan_slot_q+1'b1;
                        if(scan_group_word_q==4) begin scan_group_word_q<=0;scan_position_q<=scan_position_q+1'b1;end
                        else scan_group_word_q<=scan_group_word_q+1'b1;
                        state_q<=RREQ;
                    end
                end else chunk_q<=chunk_q+1'b1;
                TREAD: state_q<=TCAP;
                TCAP: if(chunk_q==7) begin
                    chunk_q<=0;hash_write_q<=0;hash_slot_q<=0;hash_position_q<=0;hash_group_word_q<=0;state_q<=HBEGIN;
                end else begin chunk_q<=chunk_q+1'b1;state_q<=TREAD;end
                HBEGIN: if(hash_begin_ready) begin chunk_q<=0;state_q<=HREAD;end
                HREAD: state_q<=HCAP;
                HCAP: if(chunk_q==7) begin chunk_q<=0;state_q<=HWORD;end
                    else begin chunk_q<=chunk_q+1'b1;state_q<=HREAD;end
                HWORD: if(hash_word_ready) begin
                    if(hash_slot_q==total_slots_q-1'b1) state_q<=HDIGEST;
                    else begin
                        hash_slot_q<=hash_slot_q+1'b1;chunk_q<=0;state_q<=HREAD;
                        if(hash_group_word_q==4) begin hash_group_word_q<=0;hash_position_q<=hash_position_q+1'b1;end
                        else hash_group_word_q<=hash_group_word_q+1'b1;
                    end
                end
                HDIGEST: if(hash_digest_valid) begin
                    chunk_q<=0;
                    if(hash_write_q) state_q<=TWRITE;
                    else if(hash_digest==expected_q) begin
                        cache_valid_q<=1;cache_tape_q<=owner_tape_q;cache_model_id_q<=owner_model_id_q;
                        cache_layer_q<=layer_q;cache_page_q<=page_q;cache_positions_q<=positions_q;
                        cache_generation_q<=owner_generation_q;cache_head_q<=group_head_q;cache_role_q<=role_q;state_q<=OREAD;
                    end else begin fault_q[owner_tape_q]<=1;state_q<=RRETURN;end
                end
                TWRITE: if(chunk_q==7) begin
                    chunk_q<=0;
                    if(group_head_q && role_q) begin
                        prefix_q[owner_tape_q][layer_q]<=prefix_q[owner_tape_q][layer_q]+1'b1;state_q<=WRETURN;
                    end else begin
                        if(role_q) begin group_head_q<=1;role_q<=0;end else role_q<=1;
                        hash_slot_q<=0;hash_position_q<=0;hash_group_word_q<=0;state_q<=HBEGIN;
                    end
                end else chunk_q<=chunk_q+1'b1;
                OREAD: state_q<=OCAP;
                OCAP: if(chunk_q==7) begin chunk_q<=0;state_q<=RRETURN;end
                    else begin chunk_q<=chunk_q+1'b1;state_q<=OREAD;end
                RRETURN: if(s_rd_rsp_ready) begin owner_q<=NONE;state_q<=IDLE;end
                default: begin fault_q<=2'b11;state_q<=IDLE;end
            endcase
        end
    end
endmodule
`default_nettype wire


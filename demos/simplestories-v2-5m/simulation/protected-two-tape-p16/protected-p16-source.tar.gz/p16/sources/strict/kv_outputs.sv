`timescale 1ns/1ps
`default_nettype none
// K and V complete independently under the same tape/generation descriptor
// as Q. A new generation cannot be admitted while the group engine owns it.
module kv_outputs(
    input wire clk, rst_n, abort_pair,
    input wire [1:0] live,clear_tapes,
    input wire valid,tape,
    input wire [1:0] matrix_job,
    input wire [9:0] row,
    input wire signed [15:0] mantissa,
    input wire signed [7:0] exponent,
    input wire last,
    output wire ready,fault,
    output wire [1:0] complete,
    input wire read_valid,read_tape,
    input wire [7:0] read_row,
    output reg signed [15:0] key_read,value_read,
    output reg signed [7:0] key_exp_read,value_exp_read
);
    reg signed [15:0] data[0:1][0:255];
    reg signed [7:0] exps[0:1][0:1];
    reg [7:0] count[0:1][0:1];
    reg [1:0] done[0:1];
    reg failed;
    wire is_value=matrix_job==2;
    assign ready=rst_n && !failed && !abort_pair && (matrix_job==1 || matrix_job==2) &&
                 live[tape] && !clear_tapes[tape] && !done[is_value][tape];
    wire ordered=row<128 && count[is_value][tape]==row[7:0] && last==(row==127) &&
                 (row==0 || exponent==exps[is_value][tape]) && (!is_value || done[0][tape]);
    assign complete=done[0] & done[1] & live & ~clear_tapes;
    assign fault=failed;
    always @(posedge clk) begin
        if(valid && ready && ordered) data[is_value][{tape,row[6:0]}]<=mantissa;
        if(read_valid && read_row<128 && complete[read_tape]) begin
            key_read<=data[0][{read_tape,read_row[6:0]}];value_read<=data[1][{read_tape,read_row[6:0]}];
            key_exp_read<=exps[0][read_tape];value_exp_read<=exps[1][read_tape];
        end
    end
    integer m,t;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            failed<=0;
            for(m=0;m<2;m=m+1) for(t=0;t<2;t=t+1) begin
                done[m][t]<=0;count[m][t]<=0;exps[m][t]<=0;
            end
        end else begin
            if(valid && ready) begin
                if(!ordered) failed<=1;
                else begin
                    count[is_value][tape]<=count[is_value][tape]+1'b1;
                    exps[is_value][tape]<=exponent;
                    if(last) done[is_value][tape]<=1;
                end
            end
            for(m=0;m<2;m=m+1) for(t=0;t<2;t=t+1) begin
                if(abort_pair || clear_tapes[t] || !live[t]) begin done[m][t]<=0;count[m][t]<=0;end
            end
        end
    end
endmodule
`default_nettype wire

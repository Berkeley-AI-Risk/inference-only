`timescale 1ns/1ps
`default_nettype none
// PRIVATE local numerical candidate. No physical/CDC/board qualification.
// The model seam is fixed read-only authenticated data. The typed KV seam has
// two modeled banks; its19-bit shadow is virtual, NOT a widened physical map.
// Exactly one real token/layer/attention arithmetic engine is instantiated.
module two_tape_numerical_machine #(
    parameter logic [255:0] MODEL_ID=256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0
)(
    input wire clk,reset_n,model_locked_i,upstream_fault_i,
    input wire command_tape_i, private_batch_enable_i,
    input wire [1:0] clear_tapes_i,
    input wire append_valid_i,step_valid_i,
    input wire [11:0] append_token_i,
    output wire append_ready_o,step_ready_o,token_valid_o,token_tape_o,
    input wire token_ready_i,
    output wire [11:0] token_o,
    output wire [1:0] tape_fault_o,
    output wire permanent_fault_o,busy_o,
    output wire [63:0] generation0_o,generation1_o,
    output wire model_req_valid_o,
    input wire model_req_ready_i,
    output wire [18:0] model_req_word_o,
    input wire model_rsp_valid_i,
    output wire model_rsp_ready_o,
    input wire [255:0] model_rsp_data_i,
    input wire model_rsp_fault_i,
    output wire m_wr_valid_o,m_wr_tape_o,
    input wire m_wr_ready_i,
    output wire [63:0] m_wr_generation_o,
    output wire [255:0] m_wr_model_id_o,
    output wire [2:0] m_wr_layer_o,
    output wire [11:0] m_wr_position_o,
    output wire [1:0] m_wr_head_o,
    output wire [3:0] m_wr_word_o,
    output wire [18:0] m_wr_shadow_o,
    output wire [255:0] m_wr_data_o,
    input wire m_wr_cpl_valid_i,m_wr_cpl_fault_i,
    output wire m_wr_cpl_ready_o,
    output wire m_rd_valid_o,m_rd_tape_o,
    input wire m_rd_ready_i,
    output wire [63:0] m_rd_generation_o,
    output wire [255:0] m_rd_model_id_o,
    output wire [2:0] m_rd_layer_o,
    output wire [11:0] m_rd_position_o,
    output wire [1:0] m_rd_head_o,
    output wire [3:0] m_rd_word_o,
    output wire [18:0] m_rd_shadow_o,
    input wire m_rd_rsp_valid_i,m_rd_rsp_fault_i,
    output wire m_rd_rsp_ready_o,
    input wire [255:0] m_rd_rsp_data_i,
    output wire [23:0] private_tape_counts_o,private_committed_counts_o,
    output wire [143:0] private_semantic_prefixes_o,private_summary_prefixes_o,
    output wire [1:0] private_last_hidden_valid_o,
    output wire private_job_valid_o,private_job_tape_o,
    output wire [63:0] private_job_generation_o,
    output wire private_all_external_drained_o
`ifdef TWO_TAPE_VERIFY
    ,input wire verification_hold_guard_reply_i
`endif
);
    localparam [2:0] IDLE=0,RUN=1,NORMAL_DRAIN=2,CANCEL_DRAIN=3,ARM_RESET=4,RESET_ENGINE=5,RELEASE_ENGINE=6;
    logic [2:0] state_q;
    logic [2:0] quiet_q;
    logic job_valid_q,owner_tape_q,cancel_q,permanent_q;
    logic [63:0] owner_generation_q;
    // GLOBAL-reset ownership observer at the actual verified-model seam.
    // Transient arbiter reset can never hide an unsolicited/duplicate reply.
    logic [4:0] model_owners_q;
    wire model_request_fire=model_req_valid_o && model_req_ready_i;
    wire model_response_fire=model_rsp_valid_i && model_rsp_ready_o;
    wire raw_model_protocol_fault=(model_rsp_valid_i && model_owners_q==0) ||
        (model_request_fire && model_owners_q>=16);
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) model_owners_q<=0;
        else case({model_request_fire,model_response_fire && model_owners_q!=0})
            2'b10: if(model_owners_q!=31) model_owners_q<=model_owners_q+1'b1;
            2'b01: model_owners_q<=model_owners_q-1'b1;
            default: begin end
        endcase
    end
    wire [1:0] guard_fault,guard_integrity_fault;
    wire guard_permanent,guard_raw_transport_protocol_fault;
    wire guard_busy;
    wire model_external,kv_external,attention_external,pending_semantic,local_empty,normal_idle;
    wire core_permanent,core_fail,core_busy,core_locked,core_append_ready,core_step_ready,core_token_valid;
    wire [11:0] core_token;
    batch_context batch();
    localparam [3:0] W_IDLE=0,W_INVITE=1,W_YOUNG_START=2,W_YOUNG_PREP=3,W_OLD_START=4,
                     W_OLD_WORK=5,W_PEER_START=6,W_PEER_WORK=7;
    reg [3:0] phase;
    reg older_tape,younger_tape,older_valid,younger_valid;
    reg [11:0] older_position,younger_position;
    reg [63:0] older_generation,younger_generation;
    reg [1:0] parked_valid;
    reg [2:0] parked_job[0:1];
    wire private_window_busy=phase!=W_IDLE;
    wire [11:0] requested_count=private_tape_counts_o[command_tape_i*12 +:12];
    wire [11:0] requested_prefix=private_committed_counts_o[command_tape_i*12 +:12];
    wire continuation_ok=requested_prefix>0 && requested_prefix<2048 && requested_count==requested_prefix+1 &&
        private_semantic_prefixes_o[command_tape_i*72 +:72]=={6{requested_prefix}} &&
        private_summary_prefixes_o[command_tape_i*72 +:72]=={6{requested_prefix}} &&
        private_last_hidden_valid_o[command_tape_i] && !tape_fault_o[command_tape_i] && !clear_tapes_i[command_tape_i];
    wire [63:0] requested_generation=command_tape_i?generation1_o:generation0_o;
    wire older_live=older_valid && !clear_tapes_i[older_tape] && !tape_fault_o[older_tape] &&
        older_generation==(older_tape?generation1_o:generation0_o);
    wire younger_live=younger_valid && !clear_tapes_i[younger_tape] && !tape_fault_o[younger_tape] &&
        younger_generation==(younger_tape?generation1_o:generation0_o);
    wire [1:0] tickets=(older_live ? (2'b01<<older_tape) : 0) | (younger_live ? (2'b01<<younger_tape) : 0);
    wire pair_live=older_live && younger_live;
    wire invite_eligible=phase==W_IDLE && private_batch_enable_i && continuation_ok && !append_valid_i;
    wire normal_ready=phase==W_IDLE && admission && core_step_ready;
    wire secondary_ready=phase==W_INVITE && older_live && command_tape_i!=older_tape && continuation_ok &&
        !permanent_fault_o && !append_valid_i;
    wire primary_fire=step_valid_i && normal_ready,secondary_fire=step_valid_i && secondary_ready;
    wire old_start=phase==W_OLD_START && older_live;
    wire peer_start=(phase==W_YOUNG_START || phase==W_PEER_START) && younger_live;
    wire internal_start=old_start || peer_start;
    wire command_int=old_start?older_tape:peer_start?younger_tape:command_tape_i;
    wire resume=internal_start && parked_valid[command_int] && tickets[command_int] && admission &&
        drained && local_empty && !permanent_fault_o;
    wire scalar_valid=(phase==W_IDLE && !invite_eligible && step_valid_i) ||
        (internal_start && !parked_valid[command_int]);
    wire scalar_fire=scalar_valid && admission && core_step_ready;
    wire eligible_checkpoint=state_q==RUN && batch.barrier && batch.safe_stage && drained && local_empty && !active_cancel;
    wire park=phase==W_YOUNG_PREP && pair_live && eligible_checkpoint && batch.job==0;
    wire other_owner=!owner_tape_q;
    wire peer_at_job=parked_valid[other_owner] && parked_job[other_owner]==batch.job;
    wire want_older=phase==W_OLD_WORK && pair_live && batch.job==6 && batch.available && owner_tape_q!=older_tape;
    wire swap=phase==W_OLD_WORK && pair_live && eligible_checkpoint && parked_valid[other_owner] &&
        ((!batch.available && !peer_at_job) || want_older);
    wire token_fire=token_valid_o && token_ready_i;
    assign batch.save=park || swap;
    assign batch.load=swap || resume;
    assign batch.source_owner=owner_tape_q;
    assign batch.target_owner=swap?other_owner:command_int;
    assign batch.oldest_tape=older_tape;
    assign batch.live=tickets;
    assign batch.ticket_pos0=older_tape==0?older_position:younger_position;
    assign batch.ticket_pos1=older_tape==1?older_position:younger_position;
    assign batch.admit_valid=(primary_fire && invite_eligible) || secondary_fire;
    assign batch.admit_tape=command_tape_i;
    assign batch.pair_issue=phase==W_OLD_WORK && pair_live && eligible_checkpoint && peer_at_job && !batch.available;
    assign batch.hold_stage=(phase==W_YOUNG_PREP && pair_live) ||
        (phase==W_OLD_WORK && pair_live && (!batch.available || want_older));
    assign batch.prepared=parked_valid;
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n)begin
            phase<=W_IDLE;older_valid<=0;younger_valid<=0;older_tape<=0;younger_tape<=1;
            older_position<=0;younger_position<=0;older_generation<=0;younger_generation<=0;
            parked_valid<=0;parked_job[0]<=0;parked_job[1]<=0;
        end else begin
            parked_valid<=parked_valid & tickets;
            if(batch.save)begin parked_valid[batch.source_owner]<=1;parked_job[batch.source_owner]<=batch.job;end
            if(batch.load) parked_valid[batch.target_owner]<=0;
            case(phase)
              W_IDLE: begin
                older_valid<=0;younger_valid<=0;parked_valid<=0;
                if(primary_fire && invite_eligible)begin older_valid<=1;older_tape<=command_tape_i;
                    older_generation<=requested_generation;older_position<=requested_prefix;phase<=W_INVITE;end
              end
              W_INVITE: if(secondary_fire)begin younger_valid<=1;younger_tape<=command_tape_i;
                  younger_generation<=requested_generation;younger_position<=requested_prefix;phase<=W_YOUNG_START;
                end else phase<=older_live?W_OLD_START:W_IDLE;
              W_YOUNG_START: if(!younger_live)phase<=W_OLD_START;else if(scalar_fire)phase<=W_YOUNG_PREP;
              W_YOUNG_PREP: if(!younger_live)begin younger_valid<=0;phase<=W_OLD_START;end
                  else if(park)phase<=W_OLD_START;else if(token_fire)begin younger_valid<=0;phase<=W_IDLE;end
              W_OLD_START: if(!older_live)begin older_valid<=0;phase<=W_PEER_START;end
                  else if(scalar_fire || resume)phase<=W_OLD_WORK;
              W_OLD_WORK,W_PEER_WORK: begin
                if(state_q==RUN && job_valid_q && (token_fire || !tickets[owner_tape_q]))begin
                  if(owner_tape_q==older_tape)begin older_valid<=0;phase<=younger_live?W_PEER_START:W_IDLE;end
                  else begin younger_valid<=0;phase<=older_live?W_OLD_START:W_IDLE;end
                end
              end
              W_PEER_START: if(!younger_live)begin younger_valid<=0;phase<=W_IDLE;end
                  else if(scalar_fire || resume)phase<=W_PEER_WORK;
              default:phase<=W_IDLE;
            endcase
        end
    end


    wire command_healthy=!guard_fault[command_int];
    wire parked_tape=command_healthy ? command_int : !command_int;
    wire reset_phase=state_q==RESET_ENGINE || state_q==RELEASE_ENGINE;
    wire selected_tape=job_valid_q ? owner_tape_q : reset_phase ? !owner_tape_q : parked_tape;
    wire [63:0] current_generation=selected_tape ? generation1_o : generation0_o;
    wire owner_clear=job_valid_q && clear_tapes_i[owner_tape_q];
    wire owner_quarantine=job_valid_q && guard_integrity_fault[owner_tape_q];
    // This cut is independent of our request VALID/READY callbacks. It may
    // safely reach prospective publication gates in the current cycle.
    // Full internal/protocol cause capture below remains a separate signal.
    // model_rsp_fault_i also carries the authenticated service's persistent
    // fault indication; it need not wait for a response VALID to close us.
    wire stable_external_fault=upstream_fault_i || model_rsp_fault_i ||
        (model_rsp_valid_i && model_owners_q==0) ||
        guard_raw_transport_protocol_fault ||
        (m_wr_cpl_valid_i && m_wr_cpl_fault_i) ||
        (m_rd_rsp_valid_i && m_rd_rsp_fault_i) || MODEL_ID==0;
    wire independent_event=upstream_fault_i || batch.fault || model_rsp_fault_i || raw_model_protocol_fault || core_permanent || guard_permanent ||
        MODEL_ID==0 || (job_valid_q && !cancel_q && !owner_clear && !owner_quarantine &&
        owner_generation_q!=(owner_tape_q ? generation1_o : generation0_o));
    assign permanent_fault_o=reset_n && (permanent_q || independent_event);
    assign tape_fault_o=guard_fault;
    wire engine_reset_n=state_q!=RESET_ENGINE;
    // Independent cause capture is registered outside the transient engine.
    // All immediate independent events veto public transfers. Stable external
    // causes also veto persistent child publication on this edge; internal
    // prospective commit gates veto their own invalid publication locally.
    // The next clock closes producers and starts retained-owner cancellation.
    wire active_cancel=cancel_q || owner_clear || owner_quarantine || permanent_q || upstream_fault_i;
    wire admission=reset_n && model_locked_i && state_q==IDLE && !permanent_fault_o &&
        command_healthy && !clear_tapes_i[command_int];
    assign append_ready_o=!private_window_busy && admission && core_append_ready;
    assign step_ready_o=normal_ready || secondary_ready;
    assign token_valid_o=state_q==RUN && job_valid_q && core_token_valid &&
        !active_cancel && !permanent_fault_o &&
        owner_generation_q==(owner_tape_q ? generation1_o : generation0_o);
    assign token_tape_o=owner_tape_q;
    assign token_o=token_valid_o ? core_token : 12'd0;
    assign busy_o=private_window_busy || state_q!=IDLE || guard_busy || model_external;
    assign private_job_valid_o=job_valid_q;
    assign private_job_tape_o=owner_tape_q;
    assign private_job_generation_o=owner_generation_q;
    wire drained=!batch.execution && !model_external && model_owners_q==0 && !guard_busy && !kv_external && !attention_external;
    assign private_all_external_drained_o=drained;
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin state_q<=IDLE;quiet_q<=0;job_valid_q<=0;owner_tape_q<=0;
            owner_generation_q<=0;cancel_q<=0;permanent_q<=0;end
        else begin
            if(independent_event) permanent_q<=1;
            if(owner_clear || owner_quarantine || permanent_q || independent_event) begin
                cancel_q<=1;
                if(state_q!=CANCEL_DRAIN && state_q!=ARM_RESET && state_q!=RESET_ENGINE &&
                   state_q!=RELEASE_ENGINE) begin state_q<=CANCEL_DRAIN;quiet_q<=0;end
            end else case(state_q)
                IDLE: if(resume) begin
                    owner_tape_q<=command_int;owner_generation_q<=command_int?generation1_o:generation0_o;
                    job_valid_q<=1;state_q<=RUN;
                end else if(scalar_fire) begin
                    owner_tape_q<=command_int;owner_generation_q<=current_generation;
                    job_valid_q<=1;state_q<=RUN;
                end
                RUN: if(swap) begin owner_tape_q<=other_owner;
                    owner_generation_q<=other_owner?generation1_o:generation0_o;
                end else if(park) begin job_valid_q<=0;state_q<=RESET_ENGINE;quiet_q<=0;end
                else if(token_valid_o && token_ready_i) state_q<=NORMAL_DRAIN;
                NORMAL_DRAIN: if(drained && normal_idle && local_empty && !pending_semantic) begin
                    job_valid_q<=0;state_q<=IDLE;
                end
                CANCEL_DRAIN: begin end
                ARM_RESET: begin end
                RESET_ENGINE: begin end
                RELEASE_ENGINE: begin end
                default: permanent_q<=1;
            endcase
            // Canceled external work is never declared retired by a timeout,
            // missing PID, fault flag or masked child-busy indicator.
            if(state_q==CANCEL_DRAIN && drained && local_empty && !pending_semantic) begin
                if(!permanent_q && !independent_event) begin state_q<=ARM_RESET;quiet_q<=0;end
                else job_valid_q<=0;
            end
            if(state_q==ARM_RESET) begin
                if(!drained || !local_empty || pending_semantic || permanent_q || independent_event) begin
                    state_q<=CANCEL_DRAIN;quiet_q<=0;
                end else if(quiet_q==2) begin
                    // Old owner is retired ONLY now, after real drain and
                    // explicit local queue cancellation under held CLEAR.
                    job_valid_q<=0;state_q<=RESET_ENGINE;quiet_q<=0;
                end else quiet_q<=quiet_q+1'b1;
            end
            if(state_q==RESET_ENGINE) begin
                if(!drained || permanent_q || independent_event) permanent_q<=1;
                if(quiet_q==2) begin state_q<=RELEASE_ENGINE;quiet_q<=0;cancel_q<=0;end
                else quiet_q<=quiet_q+1'b1;
            end
            if(state_q==RELEASE_ENGINE) begin
                if(!drained || permanent_q || independent_event) begin permanent_q<=1;state_q<=CANCEL_DRAIN;end
                else if(quiet_q==2 && normal_idle && local_empty) begin state_q<=IDLE;quiet_q<=0;end
                else if(quiet_q<2) quiet_q<=quiet_q+1'b1;
            end
        end
    end
    wire wr_valid,wr_ready,wr_cpl_valid,wr_cpl_ready,wr_cpl_fault;
    wire rd_valid,rd_ready,rd_rsp_valid,rd_rsp_ready,rd_rsp_fault;
    wire [2:0] wr_layer,rd_layer;
    wire [11:0] wr_position,rd_position;
    wire [1:0] wr_head,rd_head;
    wire [3:0] wr_word,rd_word;
    wire [18:0] wr_shadow,rd_shadow;
    wire [255:0] wr_data,rd_data;
    wire [374:0] wr_identity,rd_identity;
    wire guard_rd_rsp_valid,guard_rd_rsp_ready;
    wire hold_guard_reply=
`ifdef TWO_TAPE_VERIFY
        verification_hold_guard_reply_i;
`else
        1'b0;
`endif
    assign rd_rsp_valid=guard_rd_rsp_valid && !hold_guard_reply;
    assign guard_rd_rsp_ready=rd_rsp_ready && !hold_guard_reply;
    board1_context2048_token_machine_core #(.ADDR_W(19),.MODEL_ID(MODEL_ID)) u_core(
        .batch(batch),        .clk(clk),.reset_n(reset_n),.clear_i(active_cancel),.model_locked_i(model_locked_i),
        .upstream_fail_closed_i(permanent_q || stable_external_fault),.engine_reset_n_i(engine_reset_n),
        .selected_tape_i(selected_tape),.job_valid_i(job_valid_q),.clear_tapes_i(clear_tapes_i),
        .tape_fault_i(guard_integrity_fault),.job_generation_i(owner_generation_q),
        .generation0_i(generation0_o),.generation1_i(generation1_o),
        .kv_write_cpl_identity_i(wr_identity),.kv_read_rsp_identity_i(rd_identity),
        .permanent_fault_o(core_permanent),.model_external_owner_o(model_external),
        .kv_external_owner_o(kv_external),.attention_external_owner_o(attention_external),
        .pending_semantic_o(pending_semantic),.local_queues_empty_o(local_empty),.normal_idle_o(normal_idle),
        .all_committed_prefixes_o(private_semantic_prefixes_o),.value_fit_all_prefixes_o(private_summary_prefixes_o),
        .private_tape_counts_o(private_tape_counts_o),.private_committed_counts_o(private_committed_counts_o),
        .private_last_hidden_valid_o(private_last_hidden_valid_o),
        .append_valid_i(append_valid_i && !private_window_busy && admission),.append_ready_o(core_append_ready),.append_token_i(append_token_i),
        .step_valid_i(scalar_valid && admission),.step_ready_o(core_step_ready),
        .token_valid_o(core_token_valid),.token_ready_i(token_ready_i && token_valid_o),.token_o(core_token),
        .private_runtime_req_valid_o(model_req_valid_o),.private_runtime_req_ready_i(model_req_ready_i),
        .private_runtime_req_word_index_o(model_req_word_o),.private_runtime_rsp_valid_i(model_rsp_valid_i),
        .private_runtime_rsp_ready_o(model_rsp_ready_o),.private_runtime_rsp_data_i(model_rsp_data_i),
        .private_runtime_rsp_fault_i(model_rsp_fault_i),
        .kv_write_req_valid_o(wr_valid),.kv_write_req_ready_i(wr_ready),
        .kv_write_req_layer_o(wr_layer),.kv_write_req_position_o(wr_position),.kv_write_req_head_o(wr_head),
        .kv_write_req_row_word_o(wr_word),.kv_write_req_shadow_address_o(wr_shadow),.kv_write_req_data_o(wr_data),
        .kv_write_cpl_valid_i(wr_cpl_valid),.kv_write_cpl_ready_o(wr_cpl_ready),.kv_write_cpl_fault_i(wr_cpl_fault),
        .kv_read_req_valid_o(rd_valid),.kv_read_req_ready_i(rd_ready),
        .kv_read_req_layer_o(rd_layer),.kv_read_req_position_o(rd_position),.kv_read_req_head_o(rd_head),
        .kv_read_req_row_word_o(rd_word),.kv_read_req_shadow_address_o(rd_shadow),
        .kv_read_rsp_valid_i(rd_rsp_valid),.kv_read_rsp_ready_o(rd_rsp_ready),.kv_read_rsp_data_i(rd_data),
        .kv_read_rsp_fault_i(rd_rsp_fault),.kv_endpoint_fault_i(job_valid_q && guard_integrity_fault[owner_tape_q]),
        .busy_o(core_busy),.model_locked_o(core_locked),.fail_closed_o(core_fail));
    board1_two_tape_kv_integrity_guard #(.MODEL_ID(MODEL_ID)) u_guard(
        .clk(clk),.reset_n(reset_n),.model_locked_i(model_locked_i),.clear_i(clear_tapes_i),
        .upstream_fault_i((permanent_q || upstream_fault_i) ? 2'b11 : 2'b00),
        .s_wr_valid(wr_valid && job_valid_q),.s_wr_tape(owner_tape_q),.s_wr_ready(wr_ready),
        .s_wr_layer(wr_layer),.s_wr_position(wr_position),.s_wr_head(wr_head),.s_wr_word(wr_word),
        .s_wr_shadow(wr_shadow),.s_wr_data(wr_data),
        .s_wr_cpl_valid(wr_cpl_valid),.s_wr_cpl_ready(wr_cpl_ready),.s_wr_cpl_fault(wr_cpl_fault),
        .s_wr_cpl_tape(wr_identity[374]),
        .s_wr_cpl_generation(wr_identity[373:310]),
        .s_wr_cpl_model_id(wr_identity[309:54]),
        .s_wr_cpl_layer(wr_identity[53:51]),
        .s_wr_cpl_position(wr_identity[50:39]),
        .s_wr_cpl_page(wr_identity[38:32]),
        .s_wr_cpl_head(wr_identity[31:30]),
        .s_wr_cpl_role(wr_identity[29:28]),
        .s_wr_cpl_positions(wr_identity[27:23]),
        .s_wr_cpl_word(wr_identity[22:19]),
        .s_wr_cpl_shadow(wr_identity[18:0]),
        .s_rd_valid(rd_valid && job_valid_q),.s_rd_tape(owner_tape_q),.s_rd_ready(rd_ready),
        .s_rd_layer(rd_layer),.s_rd_position(rd_position),.s_rd_head(rd_head),.s_rd_word(rd_word),.s_rd_shadow(rd_shadow),
        .s_rd_rsp_valid(guard_rd_rsp_valid),.s_rd_rsp_ready(guard_rd_rsp_ready),
        .s_rd_rsp_data(rd_data),.s_rd_rsp_fault(rd_rsp_fault),
        .s_rd_rsp_tape(rd_identity[374]),
        .s_rd_rsp_generation(rd_identity[373:310]),
        .s_rd_rsp_model_id(rd_identity[309:54]),
        .s_rd_rsp_layer(rd_identity[53:51]),
        .s_rd_rsp_position(rd_identity[50:39]),
        .s_rd_rsp_page(rd_identity[38:32]),
        .s_rd_rsp_head(rd_identity[31:30]),
        .s_rd_rsp_role(rd_identity[29:28]),
        .s_rd_rsp_positions(rd_identity[27:23]),
        .s_rd_rsp_word(rd_identity[22:19]),
        .s_rd_rsp_shadow(rd_identity[18:0]),
        .m_wr_valid(m_wr_valid_o),
        .m_wr_ready(m_wr_ready_i),
        .m_wr_tape(m_wr_tape_o),
        .m_wr_generation(m_wr_generation_o),
        .m_wr_model_id(m_wr_model_id_o),
        .m_wr_layer(m_wr_layer_o),
        .m_wr_position(m_wr_position_o),
        .m_wr_head(m_wr_head_o),
        .m_wr_word(m_wr_word_o),
        .m_wr_shadow(m_wr_shadow_o),
        .m_wr_data(m_wr_data_o),
        .m_wr_cpl_valid(m_wr_cpl_valid_i),.m_wr_cpl_ready(m_wr_cpl_ready_o),.m_wr_cpl_fault(m_wr_cpl_fault_i),
        .m_rd_valid(m_rd_valid_o),
        .m_rd_ready(m_rd_ready_i),
        .m_rd_tape(m_rd_tape_o),
        .m_rd_generation(m_rd_generation_o),
        .m_rd_model_id(m_rd_model_id_o),
        .m_rd_layer(m_rd_layer_o),
        .m_rd_position(m_rd_position_o),
        .m_rd_head(m_rd_head_o),
        .m_rd_word(m_rd_word_o),
        .m_rd_shadow(m_rd_shadow_o),
        .m_rd_rsp_valid(m_rd_rsp_valid_i),.m_rd_rsp_ready(m_rd_rsp_ready_o),
        .m_rd_rsp_data(m_rd_rsp_data_i),.m_rd_rsp_fault(m_rd_rsp_fault_i),
        .fault_o(guard_fault),.integrity_fault_o(guard_integrity_fault),.permanent_fault_o(guard_permanent),
        .raw_transport_protocol_fault_o(guard_raw_transport_protocol_fault),
        .generation0_o(generation0_o),.generation1_o(generation1_o),.busy_o(guard_busy));
`ifndef SYNTHESIS
    always_ff @(posedge clk) if(reset_n) begin
        if(append_valid_i && append_ready_o)
            $display("APPEND tape=%0d generation=%0d token=%0d",command_tape_i,current_generation,append_token_i);
        if(step_valid_i && step_ready_o)
            $display("STEP tape=%0d generation=%0d",command_tape_i,current_generation);
        if(token_valid_o && token_ready_i)
            $display("TOKEN tape=%0d generation=%0d token=%0d",owner_tape_q,owner_generation_q,token_o);
        if(state_q==ARM_RESET && quiet_q==2 && drained)
            $display("OWNER_DRAINED tape=%0d generation=%0d fault=%02b",owner_tape_q,owner_generation_q,guard_fault);
    end
`endif
endmodule
`default_nettype wire


`timescale 1ns/1ps
`default_nettype none

// PRIVATE, SOURCE-ONLY integration candidate, derived from parent SHA256
// a41a61dd6a1a585adc6aaa3f36643a05046c98ed9350187d96c8dce7a5f79af7.
// One pending row/FSM/stage RAM/assembled vector; two committed prefix banks.
// Global reset requires coordinated external cancellation, as in the parent.
// engine_reset_n_i is a synchronous transient-state reset, never a bank reset.
// The caller may assert it only after authoritative model/KV/local-queue drain.
// endpoint_fault_i is ONLY the separately recorded selected guard quarantine;
// independent shared transport/model/arithmetic/controller failure belongs on
// upstream_fault_i and cannot be erased by transient recovery. Scalar clear_i
// cancels the active owner; only clear_tapes_i changes committed prefix banks.
// The private guard/outer mapping supplies the captured job's tape selection;
// these 19-bit shadow addresses remain virtual, not the two-tape physical map.
module board1_context2048_atomic_kv_typed #(
    parameter logic [255:0] MODEL_ID = 256'd0
) (
    batch_context batch,
    input wire clk, reset_n, engine_reset_n_i,
    input wire clear_i,
    input wire [1:0] clear_tapes_i,
    input wire model_locked_i, upstream_fault_i, endpoint_fault_i,
    input wire job_valid_i, job_tape_i,
    input wire [63:0] job_generation_i, generation0_i, generation1_i,

    input wire stage_begin_valid_i,
    output logic stage_begin_ready_o,
    input wire [2:0] stage_layer_i,
    input wire [11:0] stage_position_i,
    input wire signed [15:0] stage_key_exponents_i, stage_value_exponents_i,
    input wire stage_payload_valid_i,
    output logic stage_payload_ready_o,
    input wire [6:0] stage_coordinate_i,
    input wire signed [15:0] stage_key_i, stage_value_i,
    input wire stage_last_i,
    output logic pending_complete_o,

    input wire commit_valid_i,
    output logic commit_ready_o,
    input wire [2:0] commit_layer_i,
    input wire [11:0] commit_position_i,
    // LOCAL prospective predicate: independent of commit_valid_i and the
    // valid-dependent protocol/terminal aggregate. Join with the independent
    // stats predicate and permanent-cause gates before one common commit fire.
    output wire commit_local_legal_o,

    // 00 full K/V, 01 K only, 10 V only, 11 illegal, unchanged from parent.
    input wire attention_req_valid_i,
    output logic attention_req_ready_o,
    input wire [1:0] attention_req_kind_i,
    input wire [2:0] attention_layer_i,
    input wire [11:0] attention_position_i,
    input wire [1:0] attention_kv_head_i,
    output logic attention_rsp_valid_o,
    input wire attention_rsp_ready_i,
    output logic [1:0] attention_rsp_kind_o,
    output logic [1023:0] attention_rsp_key_vector_o,
    output logic signed [7:0] attention_rsp_key_exponent_o,
    output logic [1023:0] attention_rsp_value_vector_o,
    output logic signed [7:0] attention_rsp_value_exponent_o,
    output logic attention_rsp_fault_o, attention_rsp_from_pending_o,
    // {model256,tape1,generation64,layer3,position12,head2,kind2}.
    // Retained original accepted request, including a canceled/fault ACK.
    output wire [339:0] attention_rsp_identity_o,

    output logic kv_write_req_valid_o,
    input wire kv_write_req_ready_i,
    output logic [2:0] kv_write_req_layer_o,
    output logic [11:0] kv_write_req_position_o,
    output logic [1:0] kv_write_req_head_o,
    output logic [3:0] kv_write_req_row_word_o,
    output logic [18:0] kv_write_req_shadow_address_o,
    output logic [255:0] kv_write_req_data_o,
    input wire kv_write_cpl_valid_i,
    output logic kv_write_cpl_ready_o,
    input wire kv_write_cpl_fault_i,
    input wire [374:0] kv_write_cpl_identity_i,

    output logic kv_read_req_valid_o,
    input wire kv_read_req_ready_i,
    output logic [2:0] kv_read_req_layer_o,
    output logic [11:0] kv_read_req_position_o,
    output logic [1:0] kv_read_req_head_o,
    output logic [3:0] kv_read_req_row_word_o,
    output logic [18:0] kv_read_req_shadow_address_o,
    input wire kv_read_rsp_valid_i,
    output logic kv_read_rsp_ready_o,
    input wire [255:0] kv_read_rsp_data_i,
    input wire kv_read_rsp_fault_i,
    input wire [374:0] kv_read_rsp_identity_i,

    output logic [71:0] committed_prefixes_o,
    output wire [143:0] all_committed_prefixes_o,
    // Raw retained authority/ownership, NOT live or nonfault operand permits.
    output wire pending_owned_o, pending_persisted_o, external_owner_o,
    output wire pending_authorized_o,
    output wire context_fault_o,
    output logic busy_o, fail_closed_o
);
    localparam logic [1:0] REQ_FULL_KV=2'b00, REQ_KEY_ONLY=2'b01,
        REQ_VALUE_ONLY=2'b10;
    localparam logic [3:0] ST_IDLE=0, ST_STAGE=1, ST_WRITE_REQ=2,
        ST_WRITE_WAIT=3, ST_PENDING=4, ST_READ_REQ=5, ST_READ_WAIT=6,
        ST_RESPONSE=7, ST_PENDING_LOAD=8;

    logic [3:0] state_q;
    logic [11:0] committed_prefix_q [0:1][0:5];
    logic [63:0] bank_generation_q [0:1];
    logic bank_generation_known_q [0:1];
    logic context_fault_q, lock_seen_q;
    logic owner_valid_q, owner_tape_q, owner_canceled_q;
    logic [63:0] owner_generation_q;
    logic [255:0] owner_model_q;
    logic [2:0] pending_layer_q;
    logic [11:0] pending_position_q;
    logic signed [15:0] pending_key_exponents_q, pending_value_exponents_q;
    logic [6:0] expected_coordinate_q;
    logic pending_persisted_q, write_head_q, write_aborted_q;
    logic [3:0] write_word_q, read_word_q;
    logic [1:0] response_kind_q, response_original_head_q;
    logic response_head_q, response_tape_q;
    logic [2:0] response_layer_q;
    logic [11:0] response_position_q;
    logic [63:0] response_generation_q;
    logic [255:0] response_model_q;
    logic response_fault_q, response_from_pending_q, read_aborted_q;
    logic [2063:0] assembled_row_q;
    logic fault_q;
    logic stage_begin_consumed_q, stage_payload_consumed_q,
        commit_consumed_q, attention_req_consumed_q;

    // This record is deliberately NOT reset by scalar CLEAR, descriptor
    // invalidation, or engine_reset_n_i. Only exact matching receipt ACK (or
    // coordinated GLOBAL reset) retires it. A mismatched receipt is permanent
    // protocol failure, not evidence that the real outstanding owner retired.
    logic external_owner_q, external_write_q;
    logic [374:0] expected_receipt_q;
    wire write_receipt_matches = external_owner_q && external_write_q &&
        kv_write_cpl_identity_i == expected_receipt_q;
    wire read_receipt_matches = external_owner_q && !external_write_q &&
        kv_read_rsp_identity_i == expected_receipt_q;
    wire write_receipt_take = kv_write_cpl_valid_i && kv_write_cpl_ready_o &&
        write_receipt_matches;
    wire read_receipt_take = kv_read_rsp_valid_i && kv_read_rsp_ready_o &&
        read_receipt_matches;
    wire write_request_take = kv_write_req_valid_o && kv_write_req_ready_i;
    wire read_request_take = kv_read_req_valid_o && kv_read_req_ready_i;

    wire configured = MODEL_ID != 256'd0;
    wire [63:0] job_current_generation = job_tape_i ? generation1_i : generation0_i;
    wire [63:0] owner_current_generation = owner_tape_q ? generation1_i : generation0_i;
    wire [63:0] response_current_generation = response_tape_q ? generation1_i : generation0_i;
    wire job_bank_matches = !bank_generation_known_q[job_tape_i] ||
        bank_generation_q[job_tape_i] == job_generation_i;
    wire job_context_legal = configured && job_valid_i &&
        job_generation_i == job_current_generation && job_bank_matches;
    wire owner_job_matches = owner_valid_q && job_valid_i &&
        owner_tape_q == job_tape_i && owner_generation_q == job_generation_i &&
        owner_model_q == MODEL_ID;
    wire owner_generation_live = owner_generation_q == owner_current_generation;
    wire owner_bank_matches = bank_generation_known_q[owner_tape_q] &&
        bank_generation_q[owner_tape_q] == owner_generation_q;
    wire owner_current = owner_job_matches && owner_generation_live && owner_bank_matches;
    wire owner_vector_clear = owner_valid_q && clear_tapes_i[owner_tape_q];
    wire job_vector_clear = job_valid_i && clear_tapes_i[job_tape_i];
    wire response_vector_clear = clear_tapes_i[response_tape_q];
    wire cancel_now = clear_i || owner_vector_clear || owner_canceled_q;
    wire response_identity_live = owner_current && response_model_q == MODEL_ID &&
        response_tape_q == owner_tape_q && response_generation_q == owner_generation_q &&
        response_generation_q == response_current_generation && !response_vector_clear;
    // A transient reset cannot destroy an external owner or held upstream ACK.
    // On this caller violation, retain the FSM and its drain readiness; the
    // permanent latch forbids a later reset from reviving the lane.
    wire unsafe_engine_reset = !engine_reset_n_i &&
        (external_owner_q || state_q == ST_RESPONSE ||
         (owner_valid_q && !owner_canceled_q && !clear_i && !owner_vector_clear &&
          !endpoint_fault_i && !fault_q && !context_fault_q));
    wire may_reset_transient = !external_owner_q && state_q != ST_RESPONSE;
    wire external_state_fault =
        (external_owner_q != (state_q == ST_WRITE_WAIT || state_q == ST_READ_WAIT)) ||
        (external_owner_q && external_write_q != (state_q == ST_WRITE_WAIT)) ||
        (state_q != ST_IDLE && !owner_valid_q);

    logic write_mapper_command_valid, write_mapper_direction, write_mapper_reject;
    logic [18:0] write_mapper_word_address;
    logic read_mapper_command_valid, read_mapper_direction, read_mapper_reject;
    logic [18:0] read_mapper_word_address;
    logic stage_begin_legal, stage_payload_legal, commit_legal;
    logic attention_request_legal, attention_request_pending, attention_kind_legal;
    logic protocol_fault_now, unexpected_typed_completion, typed_identity_fault;
    logic typed_mapper_fault, typed_padding_fault, unclassified_receipt_fault;
    logic independent_context_event, context_event, terminal_fault_event;
    logic terminal_fault_now, accept_window, live;
`ifndef SYNTHESIS
    logic simulation_x_fault;
`else
    wire simulation_x_fault=1'b0;
`endif

    // The payload packing and stage population order are the parent's exact
    // 128 {V,K} pairs, sixteen parallel lanes and eight words per lane.
    wire stage_memory_write = stage_payload_valid_i && stage_payload_ready_o &&
        stage_payload_legal && live && owner_current;
    wire stage_memory_head = state_q == ST_PENDING_LOAD ? response_head_q : write_head_q;
    wire [3:0] stage_memory_word = state_q == ST_PENDING_LOAD ? read_word_q : write_word_q;
    wire [2:0] stage_memory_address = {stage_memory_head,stage_memory_word[1:0]};
    wire [255:0] stage_memory_keys, stage_memory_values;
    for (genvar lane=0; lane<16; lane=lane+1) begin:g_stage_memory
        logic [31:0] memory [0:7] /* synthesis syn_ramstyle="distributed_ram" */;
        wire [31:0] pair_data=memory[stage_memory_address];
        always_ff @(posedge clk) begin
            if (stage_memory_write && expected_coordinate_q[3:0] == 4'(lane))
                memory[expected_coordinate_q[6:4]] <= {stage_value_i,stage_key_i};
        end
        assign stage_memory_keys[lane*16 +:16]=pair_data[15:0];
        assign stage_memory_values[lane*16 +:16]=pair_data[31:16];
    end
    wire [15:0] stage_memory_exponents = stage_memory_head ?
        {pending_value_exponents_q[15:8],pending_key_exponents_q[15:8]} :
        {pending_value_exponents_q[7:0],pending_key_exponents_q[7:0]};
    wire [255:0] stage_memory_data = stage_memory_word < 8 ?
        (stage_memory_word[2] ? stage_memory_values : stage_memory_keys) :
        (stage_memory_word == 8 ? {240'd0,stage_memory_exponents} : 256'd0);

    wire committed_payload_take = reset_n && engine_reset_n_i &&
        state_q == ST_READ_WAIT && read_receipt_take && owner_current &&
        response_identity_live && !cancel_now && !read_aborted_q &&
        !terminal_fault_now && !kv_read_rsp_fault_i;
    wire pending_payload_take = reset_n && engine_reset_n_i &&
        state_q == ST_PENDING_LOAD && owner_current && response_identity_live &&
        pending_persisted_q && !cancel_now && !terminal_fault_now;
    wire [255:0] assembly_data = pending_payload_take ? stage_memory_data : kv_read_rsp_data_i;
    always_ff @(posedge clk) begin
        if (committed_payload_take || pending_payload_take) begin
            case (read_word_q)
                0: assembled_row_q[255:0] <= assembly_data;
                1: assembled_row_q[511:256] <= assembly_data;
                2: assembled_row_q[767:512] <= assembly_data;
                3: assembled_row_q[1023:768] <= assembly_data;
                4: assembled_row_q[1279:1024] <= assembly_data;
                5: assembled_row_q[1535:1280] <= assembly_data;
                6: assembled_row_q[1791:1536] <= assembly_data;
                7: assembled_row_q[2047:1792] <= assembly_data;
                8: assembled_row_q[2063:2048] <= assembly_data[15:0];
                default: begin end
            endcase
        end
    end

    always_comb begin
        stage_begin_legal = job_context_legal && stage_layer_i < 6 &&
            stage_position_i < 2048 &&
            stage_position_i == committed_prefix_q[job_tape_i][stage_layer_i] &&
            committed_prefix_q[job_tape_i][stage_layer_i] < 2048 &&
            $signed(stage_key_exponents_i[7:0]) >= -32 &&
            $signed(stage_key_exponents_i[7:0]) <= 31 &&
            $signed(stage_key_exponents_i[15:8]) >= -32 &&
            $signed(stage_key_exponents_i[15:8]) <= 31 &&
            $signed(stage_value_exponents_i[7:0]) >= -32 &&
            $signed(stage_value_exponents_i[7:0]) <= 31 &&
            $signed(stage_value_exponents_i[15:8]) >= -32 &&
            $signed(stage_value_exponents_i[15:8]) <= 31;
        stage_payload_legal = owner_current &&
            stage_coordinate_i == expected_coordinate_q &&
            stage_last_i == (expected_coordinate_q == 127) &&
            stage_key_i != 16'sh8000 && stage_value_i != 16'sh8000;
        commit_legal = owner_current && pending_persisted_q && commit_layer_i < 6 &&
            commit_layer_i == pending_layer_q && commit_position_i == pending_position_q &&
            commit_position_i == committed_prefix_q[owner_tape_q][commit_layer_i] &&
            committed_prefix_q[owner_tape_q][commit_layer_i] < 2048;
        attention_kind_legal = attention_req_kind_i == REQ_FULL_KV ||
            attention_req_kind_i == REQ_KEY_ONLY || attention_req_kind_i == REQ_VALUE_ONLY;
        attention_request_pending = pending_persisted_q && owner_current &&
            attention_layer_i == pending_layer_q && attention_position_i == pending_position_q;
        attention_request_legal = owner_current && pending_persisted_q &&
            attention_layer_i == pending_layer_q && attention_layer_i < 6 &&
            attention_position_i < 2048 && attention_kv_head_i < 2 && attention_kind_legal &&
            attention_position_i <= pending_position_q &&
            (attention_request_pending ||
             attention_position_i < committed_prefix_q[owner_tape_q][attention_layer_i]);

        // Revoked readiness alone is not a new controller protocol cause.
        // Diagnose structure/descriptor independent of a known guard fault.
        // CLEAR is the parent's explicit cancel exception; unsent offers may
        // still be visible on its edge. Unexpected receipts remain checked.
        protocol_fault_now=1'b0;
        if (reset_n && engine_reset_n_i && model_locked_i && !clear_i &&
            !owner_vector_clear && !job_vector_clear && !owner_canceled_q) begin
            if (stage_begin_valid_i && !stage_begin_consumed_q &&
                (!(state_q == ST_IDLE && !owner_valid_q && !attention_req_valid_i) ||
                 !stage_begin_legal)) protocol_fault_now=1'b1;
            if (stage_payload_valid_i && !stage_payload_consumed_q &&
                (state_q != ST_STAGE || !stage_payload_legal)) protocol_fault_now=1'b1;
            if (commit_valid_i && !commit_consumed_q &&
                (state_q != ST_PENDING || attention_req_valid_i || !commit_legal))
                protocol_fault_now=1'b1;
            if (attention_req_valid_i && !attention_req_consumed_q &&
                (state_q != ST_PENDING || commit_valid_i || !attention_request_legal))
                protocol_fault_now=1'b1;
        end
        unexpected_typed_completion =
            (kv_write_cpl_valid_i &&
                (state_q != ST_WRITE_WAIT || !external_owner_q || !external_write_q)) ||
            (kv_read_rsp_valid_i &&
                (state_q != ST_READ_WAIT || !external_owner_q || external_write_q));
        typed_identity_fault = (kv_write_cpl_valid_i && !write_receipt_matches) ||
            (kv_read_rsp_valid_i && !read_receipt_matches);
        typed_mapper_fault = (state_q == ST_WRITE_REQ &&
            (!write_mapper_command_valid || !write_mapper_direction || write_mapper_reject)) ||
            (state_q == ST_READ_REQ &&
            (!read_mapper_command_valid || read_mapper_direction || read_mapper_reject));
        // expected_receipt word occupies bits22:19, independent of zeroed
        // pending descriptors or later FSM traversal metadata on CLEAR.
        typed_padding_fault = kv_read_rsp_valid_i && read_receipt_matches &&
            expected_receipt_q[22:19] == 8 && kv_read_rsp_data_i[255:16] != 240'd0;
        unclassified_receipt_fault =
            ((kv_write_cpl_valid_i && write_receipt_matches && kv_write_cpl_fault_i) ||
             (kv_read_rsp_valid_i && read_receipt_matches && kv_read_rsp_fault_i)) &&
            !clear_i && !owner_vector_clear && !owner_canceled_q &&
            !endpoint_fault_i && !fault_q;
        independent_context_event = !configured || upstream_fault_i ||
            state_q > ST_PENDING_LOAD ||
            (lock_seen_q && !model_locked_i) || unsafe_engine_reset || external_state_fault ||
            unexpected_typed_completion || typed_identity_fault || typed_mapper_fault ||
            typed_padding_fault || unclassified_receipt_fault ||
            (owner_valid_q && !cancel_now &&
                (!owner_job_matches || !owner_generation_live || !owner_bank_matches));
        context_event = independent_context_event || protocol_fault_now || simulation_x_fault;
        terminal_fault_event = endpoint_fault_i || context_event;
        terminal_fault_now = fault_q || context_fault_q || terminal_fault_event;
        accept_window = reset_n && engine_reset_n_i && configured && model_locked_i &&
            job_context_legal && !clear_i && !job_vector_clear && !owner_vector_clear &&
            !owner_canceled_q && !fault_q && !context_fault_q &&
            !upstream_fault_i && !endpoint_fault_i && !simulation_x_fault;
        live = accept_window && !protocol_fault_now && !independent_context_event;
        stage_begin_ready_o = accept_window && state_q == ST_IDLE && !owner_valid_q && !external_owner_q &&
            !attention_req_valid_i && !stage_begin_consumed_q;
        stage_payload_ready_o = accept_window && state_q == ST_STAGE &&
            owner_current && !stage_payload_consumed_q;
        commit_ready_o = accept_window && state_q == ST_PENDING && owner_current &&
            !attention_req_valid_i && !commit_consumed_q;
        attention_req_ready_o = accept_window && state_q == ST_PENDING && owner_current &&
            !commit_valid_i && !attention_req_consumed_q;
        pending_complete_o = live && owner_current && pending_persisted_q &&
            (state_q == ST_PENDING || state_q == ST_READ_REQ || state_q == ST_READ_WAIT ||
             state_q == ST_PENDING_LOAD || state_q == ST_RESPONSE);

        attention_rsp_valid_o = reset_n && state_q == ST_RESPONSE;
        attention_rsp_kind_o = response_kind_q;
        attention_rsp_fault_o = attention_rsp_valid_o &&
            (response_fault_q || terminal_fault_now || cancel_now ||
             !engine_reset_n_i || !response_identity_live || !model_locked_i);
        attention_rsp_from_pending_o = attention_rsp_valid_o &&
            !attention_rsp_fault_o && response_from_pending_q;
        attention_rsp_key_vector_o=0;
        attention_rsp_key_exponent_o=0;
        attention_rsp_value_vector_o=0;
        attention_rsp_value_exponent_o=0;
        if (attention_rsp_valid_o && !attention_rsp_fault_o) begin
            if (response_kind_q != REQ_VALUE_ONLY) begin
                attention_rsp_key_vector_o=assembled_row_q[1023:0];
                attention_rsp_key_exponent_o=$signed(assembled_row_q[2055:2048]);
            end
            if (response_kind_q != REQ_KEY_ONLY) begin
                attention_rsp_value_vector_o=assembled_row_q[2047:1024];
                attention_rsp_value_exponent_o=$signed(assembled_row_q[2063:2056]);
            end
        end
        committed_prefixes_o=0;
        if (reset_n && configured && model_locked_i && job_context_legal &&
            !job_vector_clear && !context_fault_q && !upstream_fault_i &&
            bank_generation_known_q[job_tape_i]) begin
            for (integer l=0;l<6;l=l+1)
                committed_prefixes_o[l*12 +:12]=committed_prefix_q[job_tape_i][l];
        end
        // Do not mask ownership by engine reset, fault, or model release.
        busy_o=reset_n && (state_q != ST_IDLE || owner_valid_q || external_owner_q);
`ifndef SYNTHESIS
        fail_closed_o=(reset_n === 1'b0) ? 1'b0 : terminal_fault_now;
`else
        fail_closed_o=reset_n && terminal_fault_now;
`endif
    end

    assign commit_local_legal_o=reset_n && engine_reset_n_i && configured && model_locked_i &&
        job_context_legal && owner_current && !clear_i && !owner_vector_clear &&
        !job_vector_clear && !owner_canceled_q && !fault_q && !context_fault_q &&
        !independent_context_event &&
        !upstream_fault_i && !endpoint_fault_i && state_q == ST_PENDING &&
        !external_owner_q && !commit_consumed_q && commit_legal &&
        !attention_req_valid_i && !stage_begin_valid_i && !stage_payload_valid_i;
    // Prospective persistence certificate, without commit/read callbacks.
    assign pending_authorized_o=reset_n && engine_reset_n_i &&
        model_locked_i && owner_current && pending_persisted_q && state_q==ST_PENDING &&
        !clear_i && !owner_vector_clear && !owner_canceled_q &&
        !upstream_fault_i && !endpoint_fault_i && !fault_q && !context_fault_q &&
        !independent_context_event;
    assign context_fault_o=reset_n && (context_fault_q || context_event);
    assign pending_owned_o=reset_n && owner_valid_q;
    assign pending_persisted_o=reset_n && pending_persisted_q;
    assign external_owner_o=reset_n && external_owner_q;
    assign attention_rsp_identity_o={response_model_q,response_tape_q,response_generation_q,
        response_layer_q,response_position_q,response_original_head_q,response_kind_q};
    for (genvar t=0;t<2;t=t+1) begin:g_prefixes
        for (genvar l=0;l<6;l=l+1) begin:g_layer
            assign all_committed_prefixes_o[(t*6+l)*12 +:12]=committed_prefix_q[t][l];
        end
    end

`ifndef SYNTHESIS
    always_comb begin
        simulation_x_fault=$isunknown({reset_n,engine_reset_n_i,clear_i,clear_tapes_i,
            model_locked_i,upstream_fault_i,endpoint_fault_i,job_valid_i,generation0_i,
            generation1_i,MODEL_ID,stage_begin_valid_i,stage_payload_valid_i,commit_valid_i,
            attention_req_valid_i,attention_rsp_ready_i,kv_write_req_ready_i,
            kv_write_cpl_valid_i,kv_write_cpl_fault_i,kv_read_req_ready_i,
            kv_read_rsp_valid_i,kv_read_rsp_fault_i,state_q,fault_q,context_fault_q,
            owner_valid_q,owner_tape_q,owner_generation_q,owner_model_q,owner_canceled_q,
            external_owner_q,external_write_q,expected_receipt_q,
            bank_generation_known_q[0],bank_generation_known_q[1],
            bank_generation_q[0],bank_generation_q[1],all_committed_prefixes_o,
            pending_layer_q,pending_position_q,expected_coordinate_q,pending_persisted_q,
            pending_key_exponents_q,pending_value_exponents_q,write_head_q,write_word_q,
            read_word_q,write_aborted_q,read_aborted_q,response_kind_q,response_head_q,
            response_original_head_q,response_layer_q,response_position_q,response_tape_q,
            response_generation_q,response_model_q,response_fault_q,response_from_pending_q,
            stage_begin_consumed_q,stage_payload_consumed_q,commit_consumed_q,
            attention_req_consumed_q});
        if (job_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown({job_tape_i,job_generation_i});
        if (stage_begin_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown({stage_layer_i,
                stage_position_i,stage_key_exponents_i,stage_value_exponents_i});
        if (stage_payload_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown({stage_coordinate_i,
                stage_key_i,stage_value_i,stage_last_i});
        if (commit_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown({commit_layer_i,commit_position_i});
        if (attention_req_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown({attention_req_kind_i,
                attention_layer_i,attention_position_i,attention_kv_head_i});
        if (kv_write_cpl_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown(kv_write_cpl_identity_i);
        if (kv_read_rsp_valid_i)
            simulation_x_fault=simulation_x_fault || $isunknown({kv_read_rsp_data_i,kv_read_rsp_identity_i});
    end
`endif

    board1_context2048_typed_address_mapper u_write_shadow_mapper (
        .request_valid_i(state_q == ST_WRITE_REQ),.request_class_i(2'b01),
        .request_direction_i(1'b1),.model_word_index_i(19'd0),
        .layer_i(pending_layer_q),.position_i(pending_position_q),
        .kv_head_i({1'b0,write_head_q}),.row_word_i(write_word_q),
        .private_command_valid_o(write_mapper_command_valid),
        .private_word_address_o(write_mapper_word_address),.private_write_o(write_mapper_direction),
        .request_reject_o(write_mapper_reject));
    board1_context2048_typed_address_mapper u_read_shadow_mapper (
        .request_valid_i(state_q == ST_READ_REQ),.request_class_i(2'b01),
        .request_direction_i(1'b0),.model_word_index_i(19'd0),
        .layer_i(response_layer_q),.position_i(response_position_q),
        .kv_head_i({1'b0,response_head_q}),.row_word_i(read_word_q),
        .private_command_valid_o(read_mapper_command_valid),
        .private_word_address_o(read_mapper_word_address),.private_write_o(read_mapper_direction),
        .request_reject_o(read_mapper_reject));
    always_comb begin
        kv_write_req_valid_o=live && owner_current && state_q == ST_WRITE_REQ &&
            !external_owner_q && write_mapper_command_valid && write_mapper_direction &&
            !write_mapper_reject;
        kv_write_req_layer_o=pending_layer_q;
        kv_write_req_position_o=pending_position_q;
        kv_write_req_head_o={1'b0,write_head_q};
        kv_write_req_row_word_o=write_word_q;
        kv_write_req_shadow_address_o=kv_write_req_valid_o ? write_mapper_word_address : 19'd0;
        kv_write_req_data_o=kv_write_req_valid_o ? stage_memory_data : 256'd0;
        kv_write_cpl_ready_o=reset_n && state_q == ST_WRITE_WAIT && external_owner_q && external_write_q;
        kv_read_req_valid_o=live && owner_current && response_identity_live &&
            state_q == ST_READ_REQ && !external_owner_q && read_mapper_command_valid &&
            !read_mapper_direction && !read_mapper_reject;
        kv_read_req_layer_o=response_layer_q;
        kv_read_req_position_o=response_position_q;
        kv_read_req_head_o={1'b0,response_head_q};
        kv_read_req_row_word_o=read_word_q;
        kv_read_req_shadow_address_o=kv_read_req_valid_o ? read_mapper_word_address : 19'd0;
        kv_read_rsp_ready_o=reset_n && state_q == ST_READ_WAIT && external_owner_q && !external_write_q;
    end

    wire [4:0] write_page_positions={1'b0,pending_position_q[3:0]}+5'd1;
    wire [11:0] read_page_remaining=(pending_position_q+12'd1)-
        {response_position_q[11:4],4'd0};
    wire [4:0] read_page_positions=read_page_remaining >= 16 ? 5'd16 : read_page_remaining[4:0];
    wire [1:0] write_role=write_word_q == 8 ? 2'd2 : {1'b0,write_word_q[2]};
    wire [1:0] read_role=read_word_q == 8 ?
        (response_kind_q == REQ_KEY_ONLY ? 2'd0 : 2'd1) : {1'b0,read_word_q[2]};
    // {tape1,generation64,model256,layer3,position12,page7,head2,
    //  role2,positions5,word4,shadow19}. Capture the ACTUAL accepted offer.
    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            external_owner_q<=0;external_write_q<=0;expected_receipt_q<=0;
        end else begin
            if (write_request_take) begin
                external_owner_q<=1;external_write_q<=1;
                expected_receipt_q<={owner_tape_q,owner_generation_q,owner_model_q,
                    kv_write_req_layer_o,kv_write_req_position_o,kv_write_req_position_o[10:4],
                    kv_write_req_head_o,write_role,write_page_positions,
                    kv_write_req_row_word_o,kv_write_req_shadow_address_o};
            end else if (read_request_take) begin
                external_owner_q<=1;external_write_q<=0;
                expected_receipt_q<={response_tape_q,response_generation_q,response_model_q,
                    kv_read_req_layer_o,kv_read_req_position_o,kv_read_req_position_o[10:4],
                    kv_read_req_head_o,read_role,read_page_positions,
                    kv_read_req_row_word_o,kv_read_req_shadow_address_o};
            end else if (write_receipt_take || read_receipt_take) begin
                external_owner_q<=0;
                // Preserve the last receipt bytes for audit, even after ACK.
            end
        end
    end

    wire stage_begin_fire=stage_begin_valid_i && stage_begin_ready_o && stage_begin_legal && live;
    wire commit_fire=commit_valid_i && commit_ready_o && commit_legal && live && owner_current;
    // GLOBAL/persistent reset domain: no engine_reset_n_i in this block.
    integer reset_tape,reset_layer;
    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            context_fault_q<=0;lock_seen_q<=0;
            for (reset_tape=0;reset_tape<2;reset_tape=reset_tape+1) begin
                bank_generation_q[reset_tape]<=0;bank_generation_known_q[reset_tape]<=0;
                for (reset_layer=0;reset_layer<6;reset_layer=reset_layer+1)
                    committed_prefix_q[reset_tape][reset_layer]<=0;
            end
        end else begin
            if (model_locked_i) lock_seen_q<=1;
            if (context_event) context_fault_q<=1;
            for (reset_tape=0;reset_tape<2;reset_tape=reset_tape+1) begin
                if (clear_tapes_i[reset_tape]) begin
                    bank_generation_known_q[reset_tape]<=0;
                    for (reset_layer=0;reset_layer<6;reset_layer=reset_layer+1)
                        committed_prefix_q[reset_tape][reset_layer]<=0;
                end else begin
                    if (stage_begin_fire && job_tape_i == reset_tape) begin
                        bank_generation_q[reset_tape]<=job_generation_i;
                        bank_generation_known_q[reset_tape]<=1;
                    end
                    if (commit_fire && owner_tape_q == reset_tape)
                        committed_prefix_q[reset_tape][commit_layer_i]<=
                            committed_prefix_q[reset_tape][commit_layer_i]+1'b1;
                end
            end
        end
    end


    // Written only when the owner is parked at a drained layer-zero projection boundary.
    localparam integer PARKED_STATE_WIDTH=$bits(state_q) + $bits(owner_valid_q) + $bits(owner_tape_q) + $bits(owner_generation_q) + $bits(owner_model_q) + $bits(pending_layer_q) + $bits(pending_position_q) + $bits(pending_key_exponents_q) + $bits(pending_value_exponents_q) + $bits(pending_persisted_q) + $bits(owner_canceled_q) + $bits(stage_begin_consumed_q) + $bits(stage_payload_consumed_q) + $bits(commit_consumed_q) + $bits(attention_req_consumed_q);
    logic [PARKED_STATE_WIDTH-1:0] parked_state[0:1];
    always_ff @(posedge clk) if(batch.save)
        parked_state[batch.source_owner] <= {state_q, owner_valid_q, owner_tape_q, owner_generation_q, owner_model_q, pending_layer_q, pending_position_q, pending_key_exponents_q, pending_value_exponents_q, pending_persisted_q, owner_canceled_q, stage_begin_consumed_q, stage_payload_consumed_q, commit_consumed_q, attention_req_consumed_q};
    // Shared transient state. An illegal reset cannot erase an accepted typed
    // owner/held vector: those states keep running their bad-ACK drain path.
    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state_q<=ST_IDLE;owner_valid_q<=0;owner_tape_q<=0;owner_generation_q<=0;
            owner_model_q<=0;owner_canceled_q<=0;pending_layer_q<=0;pending_position_q<=0;
            pending_key_exponents_q<=0;pending_value_exponents_q<=0;expected_coordinate_q<=0;
            pending_persisted_q<=0;write_head_q<=0;write_word_q<=0;write_aborted_q<=0;
            response_kind_q<=REQ_FULL_KV;response_head_q<=0;response_original_head_q<=0;
            response_layer_q<=0;response_position_q<=0;response_tape_q<=0;
            response_generation_q<=0;response_model_q<=0;response_fault_q<=0;
            response_from_pending_q<=0;read_word_q<=0;read_aborted_q<=0;fault_q<=0;
            stage_begin_consumed_q<=0;stage_payload_consumed_q<=0;
            commit_consumed_q<=0;attention_req_consumed_q<=0;
        end else if (!engine_reset_n_i && may_reset_transient) begin
            state_q<=ST_IDLE;owner_valid_q<=0;owner_canceled_q<=0;
            pending_layer_q<=0;pending_position_q<=0;pending_key_exponents_q<=0;
            pending_value_exponents_q<=0;expected_coordinate_q<=0;pending_persisted_q<=0;
            write_head_q<=0;write_word_q<=0;write_aborted_q<=0;read_word_q<=0;
            read_aborted_q<=0;response_fault_q<=0;response_from_pending_q<=0;fault_q<=0;
            stage_begin_consumed_q<=0;stage_payload_consumed_q<=0;
            commit_consumed_q<=0;attention_req_consumed_q<=0;
            // Retained identity bytes need not reset; no output is valid.
        end else if(batch.load) begin
            {state_q, owner_valid_q, owner_tape_q, owner_generation_q, owner_model_q, pending_layer_q, pending_position_q, pending_key_exponents_q, pending_value_exponents_q, pending_persisted_q, owner_canceled_q, stage_begin_consumed_q, stage_payload_consumed_q, commit_consumed_q, attention_req_consumed_q} <= parked_state[batch.target_owner];
        end else begin
            if (!stage_begin_valid_i) stage_begin_consumed_q<=0;
            else if (stage_begin_ready_o) stage_begin_consumed_q<=1;
            if (!stage_payload_valid_i) stage_payload_consumed_q<=0;
            else if (stage_payload_ready_o) stage_payload_consumed_q<=1;
            if (!commit_valid_i) commit_consumed_q<=0;
            else if (commit_ready_o) commit_consumed_q<=1;
            if (!attention_req_valid_i) attention_req_consumed_q<=0;
            else if (attention_req_ready_o) attention_req_consumed_q<=1;
            if (terminal_fault_event) fault_q<=1;
            if (owner_valid_q && (clear_i || owner_vector_clear || terminal_fault_now ||
                    !owner_generation_live || !engine_reset_n_i)) begin
                owner_canceled_q<=1;pending_persisted_q<=0;
                pending_layer_q<=0;pending_position_q<=0;expected_coordinate_q<=0;
            end
            // Capture a faulted accepted attention request too. Never build
            // its identity from descriptors zeroed by the cancellation path.
            if (attention_req_valid_i && attention_req_ready_o) begin
                response_kind_q<=attention_req_kind_i;response_original_head_q<=attention_kv_head_i;
                response_head_q<=attention_kv_head_i[0];response_layer_q<=attention_layer_i;
                response_position_q<=attention_position_i;response_tape_q<=owner_tape_q;
                response_generation_q<=owner_generation_q;response_model_q<=owner_model_q;
            end
            case (state_q)
                ST_IDLE: begin
                    write_aborted_q<=0;read_aborted_q<=0;
                    response_fault_q<=0;response_from_pending_q<=0;
                    if (!external_owner_q) begin
                        owner_valid_q<=0;owner_canceled_q<=0;pending_persisted_q<=0;
                    end
                    if (stage_begin_fire) begin
                        owner_valid_q<=1;owner_tape_q<=job_tape_i;
                        owner_generation_q<=job_generation_i;owner_model_q<=MODEL_ID;
                        owner_canceled_q<=0;pending_layer_q<=stage_layer_i;
                        pending_position_q<=stage_position_i;
                        pending_key_exponents_q<=stage_key_exponents_i;
                        pending_value_exponents_q<=stage_value_exponents_i;
                        expected_coordinate_q<=0;state_q<=ST_STAGE;
                    end
                end
                ST_STAGE: begin
                    if (cancel_now || terminal_fault_now || !owner_current) begin
                        owner_valid_q<=0;pending_persisted_q<=0;state_q<=ST_IDLE;
                    end else if (stage_payload_valid_i && stage_payload_ready_o && stage_payload_legal) begin
                        if (expected_coordinate_q == 127) begin
                            write_head_q<=0;write_word_q<=0;write_aborted_q<=0;state_q<=ST_WRITE_REQ;
                        end else expected_coordinate_q<=expected_coordinate_q+1'b1;
                    end
                end
                ST_WRITE_REQ: begin
                    if (cancel_now || terminal_fault_now || !owner_current) begin
                        owner_valid_q<=0;pending_persisted_q<=0;state_q<=ST_IDLE;
                    end else if (write_request_take) state_q<=ST_WRITE_WAIT;
                end
                ST_WRITE_WAIT: begin
                    if (cancel_now || terminal_fault_now || !owner_current || !engine_reset_n_i)
                        write_aborted_q<=1;
                    if (write_receipt_take) begin
                        if (cancel_now || write_aborted_q || terminal_fault_now ||
                            !owner_current || !engine_reset_n_i || kv_write_cpl_fault_i) begin
                            pending_persisted_q<=0;owner_valid_q<=0;state_q<=ST_IDLE;
                        end else if (write_head_q && write_word_q == 8) begin
                            pending_persisted_q<=1;state_q<=ST_PENDING;
                        end else begin
                            if (write_word_q == 8) begin write_head_q<=1;write_word_q<=0;end
                            else write_word_q<=write_word_q+1'b1;
                            state_q<=ST_WRITE_REQ;
                        end
                    end
                end
                ST_PENDING: begin
                    if (cancel_now || terminal_fault_now || !owner_current) begin
                        pending_persisted_q<=0;
                        if (attention_req_valid_i && attention_req_ready_o) begin
                            response_fault_q<=1;response_from_pending_q<=0;state_q<=ST_RESPONSE;
                        end else begin owner_valid_q<=0;state_q<=ST_IDLE;end
                    end else if (commit_fire) begin
                        pending_persisted_q<=0;pending_layer_q<=0;pending_position_q<=0;
                        owner_valid_q<=0;state_q<=ST_IDLE;
                    end else if (attention_req_valid_i && attention_req_ready_o && attention_request_legal) begin
                        response_fault_q<=0;read_aborted_q<=0;
                        response_from_pending_q<=attention_request_pending;
                        read_word_q<=attention_req_kind_i == REQ_VALUE_ONLY ? 4'd4 : 4'd0;
                        state_q<=attention_request_pending ? ST_PENDING_LOAD : ST_READ_REQ;
                    end
                end
                ST_PENDING_LOAD: begin
                    if (cancel_now || terminal_fault_now || !owner_current || !response_identity_live) begin
                        response_fault_q<=1;response_from_pending_q<=0;state_q<=ST_RESPONSE;
                    end else if (read_word_q == 8) state_q<=ST_RESPONSE;
                    else if (response_kind_q == REQ_KEY_ONLY && read_word_q == 3) read_word_q<=8;
                    else read_word_q<=read_word_q+1'b1;
                end
                ST_READ_REQ: begin
                    if (cancel_now || terminal_fault_now || !owner_current || !response_identity_live) begin
                        response_fault_q<=1;response_from_pending_q<=0;state_q<=ST_RESPONSE;
                    end else if (read_request_take) state_q<=ST_READ_WAIT;
                end
                ST_READ_WAIT: begin
                    if (cancel_now || terminal_fault_now || !owner_current ||
                            !response_identity_live || !engine_reset_n_i) read_aborted_q<=1;
                    if (read_receipt_take) begin
                        if (cancel_now || read_aborted_q || terminal_fault_now || !owner_current ||
                            !response_identity_live || !engine_reset_n_i || kv_read_rsp_fault_i) begin
                            response_fault_q<=1;response_from_pending_q<=0;state_q<=ST_RESPONSE;
                        end else if (read_word_q == 8) state_q<=ST_RESPONSE;
                        else begin
                            if (response_kind_q == REQ_KEY_ONLY && read_word_q == 3) read_word_q<=8;
                            else read_word_q<=read_word_q+1'b1;
                            state_q<=ST_READ_REQ;
                        end
                    end
                end
                ST_RESPONSE: begin
                    if (cancel_now || terminal_fault_now || !response_identity_live || !engine_reset_n_i) begin
                        response_fault_q<=1;response_from_pending_q<=0;
                    end
                    if (attention_rsp_valid_o && attention_rsp_ready_i) begin
                        response_fault_q<=0;response_from_pending_q<=0;
                        if (!cancel_now && !terminal_fault_now && engine_reset_n_i &&
                            owner_current && pending_persisted_q) state_q<=ST_PENDING;
                        else begin
                            owner_valid_q<=0;pending_persisted_q<=0;state_q<=ST_IDLE;
                        end
                    end
                end
                default: begin
                    // Malformed state is independently permanent (the context
                    // event above); do not erase an external owner.
                    pending_persisted_q<=0;response_fault_q<=1;fault_q<=1;
                    if (!external_owner_q) begin owner_valid_q<=0;state_q<=ST_IDLE;end
                end
            endcase
        end
    end

`ifdef FORMAL
    logic formal_past_valid;
    always_ff @(posedge clk) begin
        formal_past_valid<=1;
        if (reset_n) begin
            assert (write_word_q <= 8);assert (read_word_q <= 8);
            assert (pending_position_q < 2048 || !pending_persisted_q);
            if (kv_write_req_valid_o) begin
                assert (kv_write_req_shadow_address_o >= 19'd227072);
                assert (kv_write_req_shadow_address_o < 19'd448256);
                assert (owner_current);
                if (write_word_q == 8) assert (kv_write_req_data_o[255:16] == 0);
            end
            if (kv_read_req_valid_o) begin
                assert (kv_read_req_shadow_address_o >= 19'd227072);
                assert (kv_read_req_shadow_address_o < 19'd448256);
                assert (response_identity_live);
            end
            if (pending_complete_o) assert (pending_persisted_q && owner_current);
            if (attention_rsp_fault_o) begin
                assert (attention_rsp_key_vector_o == 0);assert (attention_rsp_value_vector_o == 0);
            end
            if (fault_q || context_fault_q) begin
                assert (!stage_begin_ready_o);assert (!stage_payload_ready_o);
                assert (!commit_ready_o);assert (!attention_req_ready_o);
            end
            if (formal_past_valid && $past(reset_n)) begin
                if ($past(context_fault_q)) assert (context_fault_q);
                if ($past(fault_q) && $past(engine_reset_n_i) && engine_reset_n_i) assert (fault_q);
                if ($past(attention_rsp_valid_o && !attention_rsp_ready_i)) begin
                    assert (attention_rsp_valid_o);
                    assert (attention_rsp_identity_o == $past(attention_rsp_identity_o));
                end
                if ($past(clear_tapes_i[0])) assert (all_committed_prefixes_o[71:0] == 0);
                if ($past(clear_tapes_i[1])) assert (all_committed_prefixes_o[143:72] == 0);
            end
        end
    end
`endif
endmodule

`default_nettype wire

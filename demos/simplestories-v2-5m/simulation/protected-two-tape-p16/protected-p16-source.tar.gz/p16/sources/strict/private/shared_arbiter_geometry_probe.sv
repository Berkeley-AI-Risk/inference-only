`timescale 1ns/1ps
`default_nettype none
// PRIVATE finite source-only geometry checkpoint. No authenticated weights,
// mapper, CDC, security, parent-numerical or hardware qualification is implied.
// All data below are explicitly synthetic transaction fixtures. No image/tag
// files, hierarchy writes, force, or application-directed address interface.
// Parent holds its reset until done_o. This component never calls $finish.
// Released arbiter.sv remains unchanged; compile it beside the uniquely named
// shared_ddr_arbiter_geometry.sv derivative and the unchanged request FIFO.
// Source contract reviewed: released287e2354477d6fe01254616d1b2b8b5a4937eb3ff8b6aa5dd40a8ada26b66ae6;
// geometry7b4fb714c8d3b846b7afab51ddfc8185d9c826bd3981ea6f4c6bb1b80fcb6479.
// These are supplied source pins, not hashes computed by this unexecuted probe.
module shared_arbiter_geometry_probe(
    input wire clk,
    input wire start_i,
    output logic done_o
);
    logic active=0;
    integer cycle=0;
    always @(posedge clk) if(active && !done_o) begin
        cycle<=cycle+1;
        if(cycle>5000) $fatal(1,"GEOMETRY finite logical-cycle watchdog");
    end
    function automatic [255:0] synthetic_model(input [24:0] a);
        synthetic_model={8{32'h61c70000 ^ {7'd0,a}}};
    endfunction
    localparam [255:0] DATA_A={8{32'h19a00001}}, DATA_B={8{32'h19b00002}};
    localparam [255:0] DATA_C={8{32'h20c00003}}, DATA_D={8{32'h20d00004}}, DATA_E={8{32'h20e00005}};
    function automatic [18:0] model_script(input integer n);
        case(n)
            0:model_script=0;
            1:model_script=227061;
            2:model_script=41;
            3:model_script=127;
            4:model_script=128;
            5:model_script=65535;
            default:begin model_script=0;$fatal(1,"GEOMETRY default model script overrun");end
        endcase
    endfunction
    function automatic [18:0] kv19_address(input integer n);
        kv19_address=n<2 ? 19'd227072 : 19'd448255;
    endfunction
    function automatic [255:0] kv19_value(input integer n);
        kv19_value=n<2 ? DATA_A : DATA_B;
    endfunction

    logic reset19=0,mvalid19=0,kvalid19=0,kwrite19=0,kready19=0;
    logic [18:0] mword19=0,kword19=0;
    logic [255:0] kdata19=0;
    logic rawready19=0,rawreturn19=0;
    logic [255:0] returndata19=0;
    wire [1:0] mrdy19,krdy19,mrsp19,krsp19,merr19,kerr19,rawvalid19,rawwrite19,busy19,fault19;
    wire [255:0] mdata19[0:1],krdata19[0:1],rawdata19[0:1];
    wire [24:0] rawword19[0:1];
    board1_private_shared_ddr_transaction_boundary #(.WATCHDOG_CYCLES(1000)) u_baseline(
        .clk(clk),.reset_n(reset19),.model_locked_i(1'b1),.upstream_fault_i(1'b0),
        .model_req_valid_i(mvalid19),.model_req_ready_o(mrdy19[0]),.model_req_word_i(mword19),
        .model_rsp_valid_o(mrsp19[0]),.model_rsp_data_o(mdata19[0]),.model_rsp_error_o(merr19[0]),
        .kv_req_valid_i(kvalid19),.kv_req_ready_o(krdy19[0]),.kv_req_word_i(kword19),
        .kv_req_write_i(kwrite19),.kv_req_data_i(kdata19),.kv_rsp_valid_o(krsp19[0]),
        .kv_rsp_ready_i(kready19),.kv_rsp_data_o(krdata19[0]),.kv_rsp_error_o(kerr19[0]),
        .raw_req_valid_o(rawvalid19[0]),.raw_req_ready_i(rawready19),.raw_req_word_o(rawword19[0]),
        .raw_req_write_o(rawwrite19[0]),.raw_req_data_o(rawdata19[0]),.raw_rsp_valid_i(rawreturn19),
        .raw_rsp_data_i(returndata19),.raw_rsp_error_i(1'b0),.busy_o(busy19[0]),.fault_o(fault19[0]));
    // No geometry overrides: actual default19/1 behavior is what is compared.
    board1_private_shared_ddr_transaction_boundary_geometry #(.WATCHDOG_CYCLES(1000)) u_default(
        .clk(clk),.reset_n(reset19),.model_locked_i(1'b1),.upstream_fault_i(1'b0),
        .model_req_valid_i(mvalid19),.model_req_ready_o(mrdy19[1]),.model_req_word_i(mword19),
        .model_rsp_valid_o(mrsp19[1]),.model_rsp_data_o(mdata19[1]),.model_rsp_error_o(merr19[1]),
        .kv_req_valid_i(kvalid19),.kv_req_ready_o(krdy19[1]),.kv_req_word_i(kword19),
        .kv_req_write_i(kwrite19),.kv_req_data_i(kdata19),.kv_rsp_valid_o(krsp19[1]),
        .kv_rsp_ready_i(kready19),.kv_rsp_data_o(krdata19[1]),.kv_rsp_error_o(kerr19[1]),
        .raw_req_valid_o(rawvalid19[1]),.raw_req_ready_i(rawready19),.raw_req_word_o(rawword19[1]),
        .raw_req_write_o(rawwrite19[1]),.raw_req_data_o(rawdata19[1]),.raw_rsp_valid_i(rawreturn19),
        .raw_rsp_data_i(returndata19),.raw_rsp_error_i(1'b0),.busy_o(busy19[1]),.fault_o(fault19[1]));

    integer front_m19=0,front_k19=0,raw_m19=0,raw_k19=0,raw_w19=0,raw_r19=0;
    integer rsp_m19=0,rsp_k19=0,returns19=0,overlap19=0,stalls19=0,held_edges19=0,hold19=0;
    integer head19=0,tail19=0,count19=0;
    logic [255:0] queue19[0:31];
    integer due19[0:31];
    logic [255:0] mem_a19=0,mem_b19=0;
    logic rawheld19=0,replyheld19=0;
    logic [24:0] heldword19=0;
    logic heldwrite19=0;
    logic [255:0] helddata19=0,heldreply19=0;
    // Raw READY, ordered raw returns and held-response READY change ONLY on
    // falling edges. Each return belongs to one actually accepted raw read.
    always @(negedge clk) begin
        rawready19=reset19 && cycle%5==4;
        rawreturn19=reset19 && count19!=0 && cycle>=due19[head19];
        returndata19=rawreturn19 ? queue19[head19] : 256'd0;
        kready19=reset19 && krsp19[0] && hold19>=3;
    end
    always @(posedge clk) begin:default_lockstep
        logic [255:0] expected;
        if(!reset19) begin
            head19=0;tail19=0;count19=0;hold19=0;rawheld19=0;replyheld19=0;
        end else begin
            if($isunknown({mrdy19,krdy19,mrsp19,krsp19,merr19,kerr19,rawvalid19,rawwrite19,busy19,fault19}))
                $fatal(1,"GEOMETRY default unknown control");
            if({mrdy19[0],krdy19[0],mrsp19[0],krsp19[0],merr19[0],kerr19[0],rawvalid19[0],busy19[0],fault19[0]}
                !=={mrdy19[1],krdy19[1],mrsp19[1],krsp19[1],merr19[1],kerr19[1],rawvalid19[1],busy19[1],fault19[1]})
                $fatal(1,"GEOMETRY default baseline control/handshake mismatch cycle=%0d",cycle);
            if(fault19!==0) $fatal(1,"GEOMETRY default unexpected fault");
            if(rawvalid19[0] && {rawword19[0],rawwrite19[0],rawdata19[0]}!=={rawword19[1],rawwrite19[1],rawdata19[1]})
                $fatal(1,"GEOMETRY default baseline raw address/op/data mismatch");
            if(mrsp19[0] && mdata19[0]!==mdata19[1]) $fatal(1,"GEOMETRY default baseline model response mismatch");
            if(krsp19[0] && krdata19[0]!==krdata19[1]) $fatal(1,"GEOMETRY default baseline KV response mismatch");
            if(rawheld19 && (!rawvalid19[0] || {rawword19[0],rawwrite19[0],rawdata19[0]}!=={heldword19,heldwrite19,helddata19}))
                $fatal(1,"GEOMETRY baseline valid stalled command changed");
            if(replyheld19 && (!krsp19[0] || krdata19[0]!==heldreply19)) $fatal(1,"GEOMETRY default held KV reply changed");
            rawheld19=rawvalid19[0] && !rawready19;
            if(rawheld19) begin
                heldword19=rawword19[0];heldwrite19=rawwrite19[0];helddata19=rawdata19[0];stalls19=stalls19+1;
            end
            replyheld19=krsp19[0] && !kready19;
            if(replyheld19) begin heldreply19=krdata19[0];hold19=hold19+1;held_edges19=held_edges19+1;end
            if(mvalid19 && kvalid19) overlap19=overlap19+1;
            if(mvalid19 && mrdy19[0]) begin
                if(front_m19>=6 || mword19!==model_script(front_m19)) $fatal(1,"GEOMETRY default front model mismatch");
                $display("GEOMETRY_FRONT profile=default kind=M index=%0d word=%0d cycle=%0d",front_m19,mword19,cycle);
                front_m19=front_m19+1;
            end
            if(kvalid19 && krdy19[0]) begin
                if(front_k19>=4 || kword19!==kv19_address(front_k19) || kwrite19!==(front_k19%2==0) || kdata19!==kv19_value(front_k19))
                    $fatal(1,"GEOMETRY default front KV mismatch");
                $display("GEOMETRY_FRONT profile=default kind=K index=%0d word=%0d write=%0d data=%064h cycle=%0d",front_k19,kword19,kwrite19,kdata19,cycle);
                front_k19=front_k19+1;
            end
            if(mrsp19[0]) begin
                expected=synthetic_model({6'd0,model_script(rsp_m19)});
                if(mdata19[0]!==expected || merr19[0]!==0) $fatal(1,"GEOMETRY default owned model return mismatch");
                $display("GEOMETRY_RESPONSE profile=default kind=M index=%0d data=%064h cycle=%0d",rsp_m19,mdata19[0],cycle);
                rsp_m19=rsp_m19+1;
            end
            if(krsp19[0] && kready19) begin
                expected=rsp_k19%2==0 ? 256'd0 : kv19_value(rsp_k19);
                if(rsp_k19>=4 || krdata19[0]!==expected || kerr19[0]!==0 || hold19<3)
                    $fatal(1,"GEOMETRY default held owned KV return mismatch");
                $display("GEOMETRY_RESPONSE profile=default kind=K index=%0d data=%064h held_edges=%0d cycle=%0d",rsp_k19,krdata19[0],hold19,cycle);
                rsp_k19=rsp_k19+1;hold19=0;
            end
            if(rawreturn19) begin
                if(count19==0) $fatal(1,"GEOMETRY default unowned synthetic return");
                $display("GEOMETRY_RAW_RETURN profile=default data=%064h cycle=%0d",returndata19,cycle);
                head19=(head19+1)%32;count19=count19-1;returns19=returns19+1;
            end
            if(rawvalid19[0] && rawready19) begin
                $display("GEOMETRY_RAW profile=default word=%0d write=%0d data=%064h cycle=%0d",rawword19[0],rawwrite19[0],rawdata19[0],cycle);
                if(rawword19[0]<227062) begin
                    if(rawwrite19[0] || raw_m19>=6 || rawword19[0]!=={6'd0,model_script(raw_m19)})
                        $fatal(1,"GEOMETRY default raw model owner/address mismatch");
                    expected=synthetic_model(rawword19[0]);raw_m19=raw_m19+1;
                end else begin
                    if(raw_k19>=4 || rawword19[0]!=={6'd0,kv19_address(raw_k19)} || rawwrite19[0]!==(raw_k19%2==0))
                        $fatal(1,"GEOMETRY default raw KV owner/address mismatch");
                    if(rawwrite19[0]) begin
                        if(rawdata19[0]!==kv19_value(raw_k19)) $fatal(1,"GEOMETRY default raw write data mismatch");
                        if(rawword19[0]==227072) mem_a19=rawdata19[0];else mem_b19=rawdata19[0];
                    end
                    expected=rawword19[0]==227072 ? mem_a19 : mem_b19;raw_k19=raw_k19+1;
                end
                if(rawwrite19[0]) raw_w19=raw_w19+1;
                else begin
                    if(count19>=32) $fatal(1,"GEOMETRY default synthetic FIFO overflow");
                    queue19[tail19]=expected;due19[tail19]=cycle+3;tail19=(tail19+1)%32;count19=count19+1;raw_r19=raw_r19+1;
                end
            end
        end
    end

    logic reset20=0,mvalid20=0,kvalid20=0,kwrite20=0,kready20=0;
    logic [18:0] mword20=0;
    logic [19:0] kword20=0;
    logic [255:0] kdata20=0;
    logic rawready20=0,rawreturn20=0;
    logic [255:0] returndata20=0;
    wire mrdy20,krdy20,mrsp20,krsp20,merr20,kerr20,rawvalid20,rawwrite20,busy20,fault20;
    wire [255:0] mdata20,krdata20,rawdata20;
    wire [24:0] rawword20;
    board1_private_shared_ddr_arbiter_geometry #(.WATCHDOG_CYCLES(1000),.KV_ADDR_W(20),.TAPE_COUNT(2)) u_explicit20(
        .clk(clk),.reset_n(reset20),.model_locked_i(1'b1),.upstream_fault_i(1'b0),
        .model_req_valid_i(mvalid20),.model_req_ready_o(mrdy20),.model_req_word_i(mword20),
        .model_rsp_valid_o(mrsp20),.model_rsp_data_o(mdata20),.model_rsp_error_o(merr20),
        .kv_req_valid_i(kvalid20),.kv_req_ready_o(krdy20),.kv_req_word_i(kword20),
        .kv_req_write_i(kwrite20),.kv_req_data_i(kdata20),.kv_rsp_valid_o(krsp20),
        .kv_rsp_ready_i(kready20),.kv_rsp_data_o(krdata20),.kv_rsp_error_o(kerr20),
        .raw_req_valid_o(rawvalid20),.raw_req_ready_i(rawready20),.raw_req_word_o(rawword20),
        .raw_req_write_o(rawwrite20),.raw_req_data_o(rawdata20),.raw_rsp_valid_i(rawreturn20),
        .raw_rsp_data_i(returndata20),.raw_rsp_error_i(1'b0),.busy_o(busy20),.fault_o(fault20));
    integer front_m20=0,front_k20=0,raw_m20=0,raw_k20=0,raw_w20=0,raw_r20=0;
    integer rsp_m20=0,rsp_k20=0,returns20=0,stalls20=0,hold20=0,held_edges20=0;
    integer head20=0,tail20=0,count20=0,rejections20=0;
    logic illegal20=0,rawheld20=0,replyheld20=0;
    logic [255:0] queue20[0:7];
    integer due20[0:7];
    logic [255:0] mem_c20=0,mem_d20=0,mem_e20=0,helddata20=0,heldreply20=0;
    logic [24:0] heldword20=0;
    logic heldwrite20=0;
    function automatic [19:0] kv20_address(input integer n);
        case(n/2)
            0:kv20_address=524287;
            1:kv20_address=524288;
            2:kv20_address=669439;
            default:begin kv20_address=0;$fatal(1,"GEOMETRY explicit20 KV script overrun");end
        endcase
    endfunction
    function automatic [255:0] kv20_value(input integer n);
        case(n/2)
            0:kv20_value=DATA_C;
            1:kv20_value=DATA_D;
            2:kv20_value=DATA_E;
            default:begin kv20_value=0;$fatal(1,"GEOMETRY explicit20 data script overrun");end
        endcase
    endfunction
    always @(negedge clk) begin
        rawready20=reset20 && cycle%5==4;
        rawreturn20=reset20 && count20!=0 && cycle>=due20[head20];
        returndata20=rawreturn20 ? queue20[head20] : 256'd0;
        kready20=reset20 && krsp20 && hold20>=3;
    end
    always @(posedge clk) begin:explicit_edges
        logic [255:0] expected;
        if(!reset20) begin head20=0;tail20=0;count20=0;hold20=0;rawheld20=0;replyheld20=0;end
        else begin
            if($isunknown({mrdy20,krdy20,mrsp20,krsp20,merr20,kerr20,rawvalid20,rawwrite20,busy20,fault20}))
                $fatal(1,"GEOMETRY explicit20 unknown control");
            if(!illegal20 && fault20!==0) $fatal(1,"GEOMETRY explicit20 legal request fault");
            if(illegal20 && ((mvalid20 && mrdy20)||(kvalid20 && krdy20)||rawvalid20||mrsp20||krsp20))
                $fatal(1,"GEOMETRY explicit20 illegal offer admitted or produced transaction");
            if(rawheld20 && (!rawvalid20 || {rawword20,rawwrite20,rawdata20}!=={heldword20,heldwrite20,helddata20}))
                $fatal(1,"GEOMETRY explicit20 stalled command lost high address/data");
            rawheld20=rawvalid20 && !rawready20;
            if(rawheld20) begin heldword20=rawword20;heldwrite20=rawwrite20;helddata20=rawdata20;stalls20=stalls20+1;end
            if(replyheld20 && (!krsp20 || krdata20!==heldreply20)) $fatal(1,"GEOMETRY explicit20 held KV response changed");
            replyheld20=krsp20 && !kready20;
            if(replyheld20) begin heldreply20=krdata20;hold20=hold20+1;held_edges20=held_edges20+1;end
            if(mvalid20 && mrdy20) begin
                if(front_m20!=0 || mword20!==19'd227061) $fatal(1,"GEOMETRY explicit20 model width/range mismatch");
                $display("GEOMETRY_FRONT profile=20_2 kind=M word=%0d cycle=%0d",mword20,cycle);front_m20=front_m20+1;
            end
            if(kvalid20 && krdy20) begin
                if(front_k20>=6 || kword20!==kv20_address(front_k20) || kwrite20!==(front_k20%2==0) || kdata20!==kv20_value(front_k20))
                    $fatal(1,"GEOMETRY explicit20 front KV mismatch");
                $display("GEOMETRY_FRONT profile=20_2 kind=K index=%0d word=%0d write=%0d data=%064h cycle=%0d",front_k20,kword20,kwrite20,kdata20,cycle);
                front_k20=front_k20+1;
            end
            if(mrsp20) begin
                if(rsp_m20!=0 || mdata20!==synthetic_model(25'd227061) || merr20!==0) $fatal(1,"GEOMETRY explicit20 model return mismatch");
                $display("GEOMETRY_RESPONSE profile=20_2 kind=M data=%064h cycle=%0d",mdata20,cycle);rsp_m20=rsp_m20+1;
            end
            if(krsp20 && kready20) begin
                expected=rsp_k20%2==0 ? 256'd0 : kv20_value(rsp_k20);
                if(rsp_k20>=6 || krdata20!==expected || kerr20!==0 || hold20<3) $fatal(1,"GEOMETRY explicit20 owned KV return mismatch");
                $display("GEOMETRY_RESPONSE profile=20_2 kind=K index=%0d data=%064h held_edges=%0d cycle=%0d",rsp_k20,krdata20,hold20,cycle);
                rsp_k20=rsp_k20+1;hold20=0;
            end
            if(rawreturn20) begin
                if(count20==0) $fatal(1,"GEOMETRY explicit20 unowned synthetic return");
                $display("GEOMETRY_RAW_RETURN profile=20_2 data=%064h cycle=%0d",returndata20,cycle);
                head20=(head20+1)%8;count20=count20-1;returns20=returns20+1;
            end
            if(rawvalid20 && rawready20) begin
                $display("GEOMETRY_RAW profile=20_2 word=%0d write=%0d data=%064h cycle=%0d",rawword20,rawwrite20,rawdata20,cycle);
                if(rawword20<227062) begin
                    if(rawwrite20 || rawword20!==25'd227061 || raw_m20!=0) $fatal(1,"GEOMETRY explicit20 raw model mismatch");
                    expected=synthetic_model(rawword20);raw_m20=raw_m20+1;
                end else begin
                    if(raw_k20>=6 || rawword20!=={5'd0,kv20_address(raw_k20)} || rawwrite20!==(raw_k20%2==0))
                        $fatal(1,"GEOMETRY explicit20 physical known word truncated/changed");
                    if(rawwrite20) begin
                        if(rawdata20!==kv20_value(raw_k20)) $fatal(1,"GEOMETRY explicit20 raw write data mismatch");
                        case(rawword20)
                            524287:mem_c20=rawdata20;
                            524288:mem_d20=rawdata20;
                            669439:mem_e20=rawdata20;
                            default:$fatal(1,"GEOMETRY explicit20 unexpected mutable address");
                        endcase
                    end
                    case(rawword20)
                        524287:expected=mem_c20;
                        524288:expected=mem_d20;
                        669439:expected=mem_e20;
                        default:$fatal(1,"GEOMETRY explicit20 unknown fixture location");
                    endcase
                    raw_k20=raw_k20+1;
                end
                if(rawwrite20) raw_w20=raw_w20+1;
                else begin
                    if(count20>=8) $fatal(1,"GEOMETRY explicit20 synthetic FIFO overflow");
                    queue20[tail20]=expected;due20[tail20]=cycle+3;tail20=(tail20+1)%8;count20=count20+1;raw_r20=raw_r20+1;
                end
            end
        end
    end

    task automatic send_model19(input integer n);
        begin
            @(negedge clk);mword19=model_script(n);mvalid19=1;
            begin:accept_m19 forever begin @(posedge clk);if(mrdy19[0]) disable accept_m19;end end
            @(negedge clk);mvalid19=0;
        end
    endtask
    task automatic send_kv19(input integer n);
        begin
            @(negedge clk);kword19=kv19_address(n);kwrite19=n%2==0;kdata19=kv19_value(n);kvalid19=1;
            begin:accept_k19 forever begin @(posedge clk);if(krdy19[0]) disable accept_k19;end end
            @(negedge clk);kvalid19=0;
            while(rsp_k19<n+1) @(negedge clk);
        end
    endtask
    task automatic send_model20;
        begin
            @(negedge clk);mword20=227061;mvalid20=1;
            begin:accept_m20 forever begin @(posedge clk);if(mrdy20) disable accept_m20;end end
            @(negedge clk);mvalid20=0;
        end
    endtask
    task automatic send_kv20(input integer n);
        begin
            @(negedge clk);kword20=kv20_address(n);kwrite20=n%2==0;kdata20=kv20_value(n);kvalid20=1;
            begin:accept_k20 forever begin @(posedge clk);if(krdy20) disable accept_k20;end end
            @(negedge clk);kvalid20=0;
            while(rsp_k20<n+1) @(negedge clk);
        end
    endtask
    task automatic reset_explicit20;
        begin
            @(negedge clk);reset20=0;mvalid20=0;kvalid20=0;illegal20=0;
            repeat(3) @(negedge clk);
            reset20=1;@(negedge clk);
            if(fault20!==0 || busy20!==0 || count20!=0) $fatal(1,"GEOMETRY explicit20 reset not empty");
        end
    endtask
    task automatic reject20(input bit model_offer,input [19:0] word_index);
        integer before_raw,before_front;
        begin
            reset_explicit20;
            before_raw=raw_m20+raw_k20;before_front=front_m20+front_k20;
            @(negedge clk);illegal20=1;
            if(model_offer) begin mword20=word_index[18:0];mvalid20=1;end
            else begin kword20=word_index;kwrite20=0;kdata20=0;kvalid20=1;end
            @(posedge clk);
            if(mrdy20!==0 || krdy20!==0 || rawvalid20!==0) $fatal(1,"GEOMETRY invalid range offered a ready/command");
            @(negedge clk);mvalid20=0;kvalid20=0;
            repeat(3) begin
                @(negedge clk);
                if(fault20!==1 || mrdy20!==0 || krdy20!==0 || rawvalid20!==0 || mrsp20!==0 || krsp20!==0 || busy20!==0 || count20!=0)
                    $fatal(1,"GEOMETRY invalid range did not stay fail-closed without ownership");
            end
            if(raw_m20+raw_k20!=before_raw || front_m20+front_k20!=before_front) $fatal(1,"GEOMETRY rejection changed accepted transaction counts");
            rejections20=rejections20+1;
            $display("GEOMETRY_REJECT profile=20_2 model_offer=%0d word=%0d fault=%0d accepted=0 raw=0 cycle=%0d",model_offer,word_index,fault20,cycle);
        end
    endtask
    initial begin:fixed_component_program
        done_o=0;
        wait(start_i===1'b1);active=1;
        $display("GEOMETRY_BEGIN scope=SYNTHETIC_COMPONENT_ONLY default=19_1 explicit=20_2");
        repeat(3) @(negedge clk);reset19=1;
        fork
            begin for(integer n=0;n<6;n=n+1) send_model19(n);end
            begin for(integer n=0;n<4;n=n+1) send_kv19(n);end
        join
        while(rsp_m19<6 || rsp_k19<4 || busy19!==0 || count19!=0 || rawreturn19) @(negedge clk);
        repeat(3) @(negedge clk);
        if(front_m19!=6 || front_k19!=4 || raw_m19!=6 || raw_k19!=4 || raw_w19!=2 || raw_r19!=8 ||
            rsp_m19!=6 || rsp_k19!=4 || returns19!=8 || overlap19<1 || stalls19<1 || held_edges19<12 || fault19!==0 || busy19!==0)
            $fatal(1,"GEOMETRY default exact count/stall/drain summary mismatch");
        $display("GEOMETRY_DEFAULT_SUMMARY model_front=6 kv_front=4 model_raw=6 kv_raw=4 raw_writes=2 raw_reads=8 raw_returns=8 model_responses=6 kv_responses=4 overlap_edges=%0d raw_stall_edges=%0d held_kv_edges=%0d clean_drain=1 baseline_match=1",overlap19,stalls19,held_edges19);
        reset19=0;
        reset_explicit20;
        fork
            send_model20;
            begin for(integer n=0;n<6;n=n+1) send_kv20(n);end
        join
        while(rsp_m20<1 || rsp_k20<6 || busy20 || count20!=0 || rawreturn20) @(negedge clk);
        repeat(3) @(negedge clk);
        if(front_m20!=1 || front_k20!=6 || raw_m20!=1 || raw_k20!=6 || raw_w20!=3 || raw_r20!=4 ||
            rsp_m20!=1 || rsp_k20!=6 || returns20!=4 || stalls20<1 || held_edges20<18 || fault20!==0 || busy20!==0)
            $fatal(1,"GEOMETRY explicit20 exact count/stall/drain summary mismatch");
        $display("GEOMETRY_20_SUMMARY model_front=1 kv_front=6 model_raw=1 kv_raw=6 raw_writes=3 raw_reads=4 raw_returns=4 model_responses=1 kv_responses=6 tested_words=524287,524288,669439 raw_stall_edges=%0d held_kv_edges=%0d clean_drain=1",stalls20,held_edges20);
        reject20(0,20'd669440);
        reject20(1,20'd227062);
        reject20(0,20'd227062);
        if(rejections20!=3) $fatal(1,"GEOMETRY missing exact rejection cases");
        @(negedge clk);reset20=0;
        repeat(3) @(negedge clk);
        $display("GEOMETRY_COMPLETE default_front=10 default_raw=10 default_returns=8 default_responses=10 explicit_front=7 explicit_raw=7 explicit_returns=4 explicit_responses=7 rejected_offers=3 scope=SYNTHETIC_GEOMETRY_ONLY_NOT_PARENT_OR_SECURITY_QUALIFICATION");
        done_o=1;
    end
endmodule
`default_nettype wire

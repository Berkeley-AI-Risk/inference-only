// PRIVATE integration derivative of exact48c1deaa4b36ca54ffdcfc197471561aabec9592b5d2746a95ac6e11042120a6; original source/review frozen.
`timescale 1ns/1ps
`default_nettype none

// PRIVATE integration candidate. Derived from board1_attention_value_fit_prefix.
// Two persistent prefix/fit banks, ONE pending scalar observer. No arithmetic
// array, external-memory request, host import, reset-on-job-switch, or model data.
// rst_n is GLOBAL only. A transient engine reset must instead cancel its owned
// pending transaction with abort_job_i after the integration has retained/drained
// external owners. The caller holds the internal job identity until that drain.
// This source is not yet connected to the token/attention implementation.
module two_tape_value_fit_prefix #(
    parameter logic [255:0] MODEL_ID = 256'd0
) (
    batch_context batch,
    input wire clk, rst_n, model_lock_i, upstream_fault_i,
    input wire [255:0] installed_model_id_i,
    input wire [1:0] clear_i, tape_fault_i,
    input wire job_valid_i, job_tape_i,
    input wire [63:0] job_generation_i, generation0_i, generation1_i,
    input wire abort_job_i,
    input wire stage_begin_i, stage_value_valid_i,
    input wire [2:0] layer_i,
    input wire [10:0] position_i,
    input wire [6:0] coordinate_i,
    input wire signed [15:0] value_i,
    input wire signed [7:0] exponent_i,
    input wire pending_complete_i, read_i, commit_i,
    output wire read_valid_o,read_local_legal_o,global_fault_latched_o,
    output wire signed [7:0] exponent0_o, exponent1_o,
    output wire read_tape_o,
    output wire [63:0] read_generation_o,
    output wire [255:0] read_model_id_o,
    output wire [2:0] read_layer_o,
    output wire [10:0] read_position_o,
    // Prospective LOCAL predicate: independent of commit_i and the external
    // pending_complete_i certificate. The caller MUST join it with atomic
    // K/V's independent persisted/owner/descriptor predicate before firing
    // the one common commit edge into both modules. It is not a commit pulse.
    output wire commit_local_legal_o,
    output wire [143:0] committed_prefixes_o,
    output wire pending_busy_o,
    output wire [1:0] fault_o,
    output wire global_fault_o
);
    logic [11:0] prefix_q [0:1][0:5];
    logic signed [7:0] maximum_q [0:1][0:5][0:1];
    logic nonzero_q [0:1][0:5][0:1];
    logic bank_generation_known_q [0:1];
    logic [63:0] bank_generation_q [0:1];
    logic signed [7:0] pending_max_q [0:1];
    logic pending_nonzero_q [0:1];
    logic owner_tape_q;
    logic [63:0] owner_generation_q;
    logic [255:0] owner_model_q;
    logic [2:0] pending_layer_q;
    logic [10:0] pending_position_q;
    logic signed [7:0] pending_exponent_q;
    logic [6:0] next_coordinate_q;
    logic staging_q, pending_valid_q, consumed_q, lock_seen_q;
    logic [1:0] fault_q;
    logic global_fault_q;

    function automatic signed [7:0] first_fit(
        input signed [15:0] v, input signed [7:0] e
    );
        reg [15:0] magnitude;
        integer bits_needed, b, required;
        begin
            magnitude = v[15] ? $unsigned(-v) : $unsigned(v);
            bits_needed = 0;
            for (b = 0; b < 15; b = b + 1)
                if (magnitude[b]) bits_needed = b + 1;
            required = $signed(e) + bits_needed - 15;
            if (v == 0 || required < -32) first_fit = -8'sd32;
            else if (required > 31) first_fit = 8'sd31;
            else first_fit = required;
        end
    endfunction

    wire event_present = stage_begin_i || stage_value_valid_i || read_i || commit_i;
    wire [63:0] current_generation = job_tape_i ? generation1_i : generation0_i;
    wire [63:0] owner_current_generation = owner_tape_q ? generation1_i : generation0_i;
    wire configured = MODEL_ID != 256'd0;
    wire installed_matches = installed_model_id_i == MODEL_ID;
    wire layer_legal = layer_i < 6;
    wire pending_live = staging_q || pending_valid_q;
    wire cancel_owned = pending_live && (clear_i[owner_tape_q] || abort_job_i);
    wire job_matches = job_valid_i && job_tape_i == owner_tape_q &&
        job_generation_i == owner_generation_q && owner_model_q == MODEL_ID &&
        owner_generation_q == owner_current_generation;
    wire bank_matches = !bank_generation_known_q[job_tape_i] ||
        bank_generation_q[job_tape_i] == job_generation_i;
    wire context_legal = job_valid_i && configured && installed_matches &&
        job_generation_i == current_generation && bank_matches;
    wire tuple_matches = layer_legal && job_matches &&
        pending_layer_q == layer_i && pending_position_q == position_i &&
        prefix_q[owner_tape_q][layer_i] == {1'b0, position_i};
    wire structural_pending_owned = pending_valid_q && tuple_matches;
    wire pending_owned = structural_pending_owned && pending_complete_i;
    wire base_read_valid = rst_n && model_lock_i && context_legal &&
        !clear_i[job_tape_i] && !abort_job_i && !upstream_fault_i &&
        !global_fault_q && !fault_q[job_tape_i] && !tape_fault_i[job_tape_i] &&
        pending_owned && !consumed_q;
    wire stage_bad = stage_begin_i && (!layer_legal || pending_live ||
        prefix_q[job_tape_i][layer_i] != {1'b0, position_i} ||
        prefix_q[job_tape_i][layer_i] >= 2048 || exponent_i < -32 || exponent_i > 31);
    wire value_bad = stage_value_valid_i && (!staging_q || !tuple_matches ||
        coordinate_i != next_coordinate_q || exponent_i != pending_exponent_q ||
        value_i == -16'sd32768);
    // Protocol meaning is distinct from revocation. An otherwise owned read
    // canceled by a separately recorded guard quarantine is not, by itself,
    // an independent malformed-descriptor event.
    wire owner_quarantined = fault_q[owner_tape_q] || tape_fault_i[owner_tape_q];
    wire read_bad = read_i && (!structural_pending_owned || consumed_q ||
        (!pending_complete_i && !owner_quarantined));
    wire commit_bad = commit_i && (!pending_owned || !consumed_q || staging_q);
    wire event_collision = (stage_begin_i && (stage_value_valid_i || read_i || commit_i)) ||
        (stage_value_valid_i && (read_i || commit_i)) || (read_i && commit_i);

    logic unknown_event;
    always_comb begin
        unknown_event = 1'b0;
`ifndef SYNTHESIS
        if ($isunknown({rst_n, model_lock_i, upstream_fault_i, installed_model_id_i,
                clear_i, tape_fault_i, job_valid_i, abort_job_i, stage_begin_i,
                stage_value_valid_i, pending_complete_i, read_i, commit_i,
                generation0_i, generation1_i})) unknown_event = 1'b1;
        if (job_valid_i && $isunknown({job_tape_i, job_generation_i})) unknown_event = 1'b1;
        if (event_present && $isunknown({layer_i, position_i})) unknown_event = 1'b1;
        if (stage_begin_i && $isunknown(exponent_i)) unknown_event = 1'b1;
        if (stage_value_valid_i && $isunknown({coordinate_i, value_i, exponent_i})) unknown_event = 1'b1;
`endif
    end
    wire protocol_event = rst_n && context_legal && !clear_i[job_tape_i] &&
        !abort_job_i && (stage_bad || value_bad || read_bad || commit_bad || event_collision);
    // A malformed controller event is permanent even if its tape is known.
    // Only externally recorded, attributable guard quarantine may be local.
    // Keep this independent cause outside transient compute reset.
    wire global_event = !configured || upstream_fault_i || unknown_event ||
        protocol_event || (model_lock_i && !installed_matches) ||
        (lock_seen_q && !model_lock_i) ||
        (event_present && !abort_job_i && !clear_i[job_tape_i] && !context_legal) ||
        (pending_live && !cancel_owned && !job_matches);
    assign global_fault_o = rst_n && (global_fault_q || global_event);
    assign fault_o = rst_n ? (fault_q | tape_fault_i) : 2'b00;
    assign read_local_legal_o = base_read_valid;
    assign global_fault_latched_o = rst_n && global_fault_q;
    assign read_valid_o = base_read_valid && !global_event;
    wire signed [7:0] fit = first_fit(value_i, exponent_i);
    wire signed [7:0] combined0 = (maximum_q[owner_tape_q][layer_i][0] > pending_max_q[0]) ?
        maximum_q[owner_tape_q][layer_i][0] : pending_max_q[0];
    wire signed [7:0] combined1 = (maximum_q[owner_tape_q][layer_i][1] > pending_max_q[1]) ?
        maximum_q[owner_tape_q][layer_i][1] : pending_max_q[1];
    assign exponent0_o = read_valid_o &&
        (nonzero_q[owner_tape_q][layer_i][0] || pending_nonzero_q[0]) ? combined0 : 8'sd0;
    assign exponent1_o = read_valid_o &&
        (nonzero_q[owner_tape_q][layer_i][1] || pending_nonzero_q[1]) ? combined1 : 8'sd0;
    assign read_tape_o = owner_tape_q;
    assign read_generation_o = owner_generation_q;
    assign read_model_id_o = owner_model_q;
    assign read_layer_o = pending_layer_q;
    assign read_position_o = pending_position_q;
    assign commit_local_legal_o = rst_n && model_lock_i && context_legal &&
        !clear_i[job_tape_i] && !abort_job_i && !upstream_fault_i &&
        !global_fault_q && !fault_q[job_tape_i] && !tape_fault_i[job_tape_i] &&
        pending_valid_q && tuple_matches && consumed_q && !staging_q &&
        !stage_begin_i && !stage_value_valid_i && !read_i;
    assign pending_busy_o = rst_n && pending_live;
    for (genvar t = 0; t < 2; t = t + 1) begin : g_prefix_output
        for (genvar l = 0; l < 6; l = l + 1) begin : g_layer
            assign committed_prefixes_o[(t*6+l)*12 +: 12] = prefix_q[t][l];
        end
    end

    localparam integer PARKED_STATE_WIDTH=$bits(owner_tape_q) + $bits(owner_generation_q) + $bits(owner_model_q) + $bits(pending_layer_q) + $bits(pending_position_q) + $bits(pending_exponent_q) + $bits(staging_q) + $bits(pending_valid_q) + $bits(consumed_q) + $bits(next_coordinate_q) + $bits(pending_max_q[0]) + $bits(pending_max_q[1]) + $bits(pending_nonzero_q[0]) + $bits(pending_nonzero_q[1]);
    logic [PARKED_STATE_WIDTH-1:0] parked_state[0:1];
    always_ff @(posedge clk) if(batch.save)
        parked_state[batch.source_owner] <= {owner_tape_q, owner_generation_q, owner_model_q, pending_layer_q, pending_position_q, pending_exponent_q, staging_q, pending_valid_q, consumed_q, next_coordinate_q, pending_max_q[0], pending_max_q[1], pending_nonzero_q[0], pending_nonzero_q[1]};
    integer t, l, h;
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fault_q <= 0; global_fault_q <= 0; lock_seen_q <= 0;
            staging_q <= 0; pending_valid_q <= 0; consumed_q <= 0;
            next_coordinate_q <= 0; pending_layer_q <= 0; pending_position_q <= 0;
            pending_exponent_q <= 0; owner_tape_q <= 0;
            owner_generation_q <= 0; owner_model_q <= 0;
            for (t = 0; t < 2; t = t + 1) begin
                bank_generation_known_q[t] <= 0; bank_generation_q[t] <= 0;
                for (l = 0; l < 6; l = l + 1) begin
                    prefix_q[t][l] <= 0;
                    for (h = 0; h < 2; h = h + 1) begin
                        maximum_q[t][l][h] <= -32; nonzero_q[t][l][h] <= 0;
                    end
                end
            end
            for (h = 0; h < 2; h = h + 1) begin
                pending_max_q[h] <= -32; pending_nonzero_q[h] <= 0;
            end
        end else begin
            if (model_lock_i) lock_seen_q <= 1;
            if (global_event) global_fault_q <= 1;
            fault_q <= fault_q | tape_fault_i;
            for (t = 0; t < 2; t = t + 1) begin
                if (clear_i[t]) begin
                    bank_generation_known_q[t] <= 0;
                    for (l = 0; l < 6; l = l + 1) begin
                        prefix_q[t][l] <= 0;
                        for (h = 0; h < 2; h = h + 1) begin
                            maximum_q[t][l][h] <= -32; nonzero_q[t][l][h] <= 0;
                        end
                    end
                end
            end
            if(batch.load) begin
                {owner_tape_q, owner_generation_q, owner_model_q, pending_layer_q, pending_position_q, pending_exponent_q, staging_q, pending_valid_q, consumed_q, next_coordinate_q, pending_max_q[0], pending_max_q[1], pending_nonzero_q[0], pending_nonzero_q[1]} <= parked_state[batch.target_owner];
            end else if (abort_job_i || cancel_owned || global_event || global_fault_q ||
                    (pending_live && fault_o[owner_tape_q])) begin
                staging_q <= 0; pending_valid_q <= 0; consumed_q <= 0; next_coordinate_q <= 0;
            end else if (context_legal && model_lock_i && !clear_i[job_tape_i] &&
                    !fault_o[job_tape_i] && !protocol_event) begin
                if (stage_begin_i) begin
                    owner_tape_q <= job_tape_i; owner_generation_q <= job_generation_i;
                    owner_model_q <= MODEL_ID;
                    bank_generation_known_q[job_tape_i] <= 1;
                    bank_generation_q[job_tape_i] <= job_generation_i;
                    pending_layer_q <= layer_i; pending_position_q <= position_i;
                    pending_exponent_q <= exponent_i; next_coordinate_q <= 0;
                    staging_q <= 1; consumed_q <= 0;
                    for (h = 0; h < 2; h = h + 1) begin
                        pending_max_q[h] <= -32; pending_nonzero_q[h] <= 0;
                    end
                end
                if (stage_value_valid_i) begin
                    if (fit > pending_max_q[coordinate_i[6]]) pending_max_q[coordinate_i[6]] <= fit;
                    if (value_i != 0) pending_nonzero_q[coordinate_i[6]] <= 1;
                    if (coordinate_i == 127) begin staging_q <= 0; pending_valid_q <= 1; end
                    else next_coordinate_q <= next_coordinate_q + 1'b1;
                end
                if (read_i && read_valid_o) consumed_q <= 1;
                if (commit_i) begin
                    maximum_q[owner_tape_q][layer_i][0] <= combined0;
                    maximum_q[owner_tape_q][layer_i][1] <= combined1;
                    nonzero_q[owner_tape_q][layer_i][0] <=
                        nonzero_q[owner_tape_q][layer_i][0] || pending_nonzero_q[0];
                    nonzero_q[owner_tape_q][layer_i][1] <=
                        nonzero_q[owner_tape_q][layer_i][1] || pending_nonzero_q[1];
                    prefix_q[owner_tape_q][layer_i] <= prefix_q[owner_tape_q][layer_i] + 1'b1;
                    pending_valid_q <= 0; consumed_q <= 0;
                end
            end
        end
    end
endmodule
`default_nettype wire


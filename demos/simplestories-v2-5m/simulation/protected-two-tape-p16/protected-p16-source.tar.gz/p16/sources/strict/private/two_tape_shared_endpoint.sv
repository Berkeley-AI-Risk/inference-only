`timescale 1ns/1ps
`default_nettype none

// PRIVATE LOCAL first normalized shared endpoint; not a full token engine,
// boot, CDC, shared32 arbiter, FPGA or board qualification. Exactly ONE total
// request owns the path until its selected response ACK. There is no ordinary
// CLEAR/reset port: accepted work is never erased by tape cancellation.
// Dependency modules are unchanged; no model image is copied by this source.
module two_tape_shared_endpoint #(
    parameter integer TAPE_COUNT = 2,
    parameter logic [255:0] MODEL_ID =
        256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0
) (
    input wire clk,
    input wire reset_n,
    input wire model_locked_i,
    input wire upstream_fault_i,

    input wire model_req_valid_i,
    output wire model_req_ready_o,
    input wire [18:0] model_req_word_i,
    output wire model_rsp_valid_o,
    output wire [255:0] model_rsp_data_o,
    output wire model_rsp_fault_o,

    input wire m_wr_valid_i,
    output wire m_wr_ready_o,
    input wire m_wr_tape_i,
    input wire [63:0] m_wr_generation_i,
    input wire [255:0] m_wr_model_id_i,
    input wire [2:0] m_wr_layer_i,
    input wire [11:0] m_wr_position_i,
    input wire [1:0] m_wr_head_i,
    input wire [3:0] m_wr_word_i,
    input wire [18:0] m_wr_shadow_i,
    input wire [255:0] m_wr_data_i,
    output wire m_wr_cpl_valid_o,
    input wire m_wr_cpl_ready_i,
    output wire m_wr_cpl_fault_o,

    input wire m_rd_valid_i,
    output wire m_rd_ready_o,
    input wire m_rd_tape_i,
    input wire [63:0] m_rd_generation_i,
    input wire [255:0] m_rd_model_id_i,
    input wire [2:0] m_rd_layer_i,
    input wire [11:0] m_rd_position_i,
    input wire [1:0] m_rd_head_i,
    input wire [3:0] m_rd_word_i,
    input wire [18:0] m_rd_shadow_i,
    output wire m_rd_rsp_valid_o,
    input wire m_rd_rsp_ready_i,
    output wire [255:0] m_rd_rsp_data_o,
    output wire m_rd_rsp_fault_o,

    output wire [360:0] private_return_identity_o,
    output wire [1:0] private_return_kind_o,
    output wire endpoint_req_valid_o,
    input wire endpoint_req_ready_i,
    output wire [19:0] endpoint_req_word_address_o,
    output wire endpoint_req_write_o,
    output wire [255:0] endpoint_req_write_data_o,
    input wire endpoint_rsp_valid_i,
    output wire endpoint_rsp_ready_o,
    input wire [255:0] endpoint_rsp_data_i,
    input wire endpoint_rsp_error_i,

    output wire busy_o,
    output wire fail_closed_o
);
    localparam logic [255:0] SS_MODEL_ID =
        256'hcad8d015db37a3603e340edfc0009f36d6b12de2bc789d60687011fc700cc3b0;
    localparam logic [1:0] KIND_MODEL_READ=2'd0, KIND_KV_WRITE=2'd1, KIND_KV_READ=2'd2, NONE=2'd3;
    localparam logic [1:0] IDLE=2'd0, PRESENT=2'd1, WAIT_RETURN=2'd2;
    wire configuration_ok=(TAPE_COUNT==1 || TAPE_COUNT==2) && MODEL_ID==SS_MODEL_ID;
    logic [1:0] state_q, grant_kind_q, next_kind_q;
    logic [360:0] grant_identity_q;
    logic [18:0] grant_model_word_q;
    logic [255:0] grant_data_q;
    logic fault_q,lock_seen_q;
    logic [1:0] selected_kind;
    wire model_present=(model_req_valid_i===1'b1);
    wire write_present=(m_wr_valid_i===1'b1);
    wire read_present=(m_rd_valid_i===1'b1);

    // Small fixed round-robin arbitration is ONLY at front acceptance.
    // No selector or input descriptor remains live underneath the app child.
    always_comb begin
        selected_kind=NONE;
        case(next_kind_q)
            KIND_MODEL_READ: begin
                if(model_present) selected_kind=KIND_MODEL_READ;
                else if(write_present) selected_kind=KIND_KV_WRITE;
                else if(read_present) selected_kind=KIND_KV_READ;
            end
            KIND_KV_WRITE: begin
                if(write_present) selected_kind=KIND_KV_WRITE;
                else if(read_present) selected_kind=KIND_KV_READ;
                else if(model_present) selected_kind=KIND_MODEL_READ;
            end
            KIND_KV_READ: begin
                if(read_present) selected_kind=KIND_KV_READ;
                else if(model_present) selected_kind=KIND_MODEL_READ;
                else if(write_present) selected_kind=KIND_KV_WRITE;
            end
            default: begin end
        endcase
    end

    wire app_req_ready,app_rsp_valid,app_rsp_ready,app_rsp_fault,app_busy,app_fault;
    wire [1:0] app_rsp_kind;
    wire [360:0] app_rsp_identity;
    wire [255:0] app_rsp_data;
    wire app_response_matches=app_rsp_kind==grant_kind_q && app_rsp_identity==grant_identity_q;
    wire correspondence_fault=app_rsp_valid && (state_q!=WAIT_RETURN || !app_response_matches);
    logic simulation_x_fault;
    always_comb begin
        simulation_x_fault=1'b0;
`ifndef SYNTHESIS
`ifndef FORMAL
        if($isunknown({reset_n,model_locked_i,upstream_fault_i,
                       model_req_valid_i,m_wr_valid_i,m_rd_valid_i,state_q,next_kind_q}))
            simulation_x_fault=1'b1;
        if(model_req_valid_i && $isunknown(model_req_word_i)) simulation_x_fault=1'b1;
        if(m_wr_valid_i && $isunknown({m_wr_tape_i,m_wr_generation_i,m_wr_model_id_i,
            m_wr_layer_i,m_wr_position_i,m_wr_head_i,m_wr_word_i,m_wr_shadow_i,m_wr_data_i}))
            simulation_x_fault=1'b1;
        if(m_rd_valid_i && $isunknown({m_rd_tape_i,m_rd_generation_i,m_rd_model_id_i,
            m_rd_layer_i,m_rd_position_i,m_rd_head_i,m_rd_word_i,m_rd_shadow_i}))
            simulation_x_fault=1'b1;
        if(state_q==WAIT_RETURN && grant_kind_q==KIND_KV_WRITE && $isunknown(m_wr_cpl_ready_i))
            simulation_x_fault=1'b1;
        if(state_q==WAIT_RETURN && grant_kind_q==KIND_KV_READ && $isunknown(m_rd_rsp_ready_i))
            simulation_x_fault=1'b1;
        if(app_rsp_valid && $isunknown({app_rsp_kind,app_rsp_identity,app_rsp_fault,app_rsp_data}))
            simulation_x_fault=1'b1;
`endif
`endif
    end
    wire independent_fault_now=!configuration_ok || upstream_fault_i ||
        (lock_seen_q && !model_locked_i) || simulation_x_fault ||
        correspondence_fault || app_fault || state_q==NONE || next_kind_q==NONE;
    wire terminal_now=fault_q || independent_fault_now;
    wire admission=reset_n && state_q==IDLE && model_locked_i && !terminal_now;
    assign model_req_ready_o=admission && selected_kind==KIND_MODEL_READ;
    assign m_wr_ready_o=admission && selected_kind==KIND_KV_WRITE;
    assign m_rd_ready_o=admission && selected_kind==KIND_KV_READ;
    wire model_take=model_req_valid_i && model_req_ready_o;
    wire write_take=m_wr_valid_i && m_wr_ready_o;
    wire read_take=m_rd_valid_i && m_rd_ready_o;
    wire request_take=model_take || write_take || read_take;

    // The complete grant was captured on an EARLIER edge before app VALID.
    // Thus app's private pre-READY offer capture sees one immutable descriptor.
    two_tape_typed_app_endpoint #(.TAPE_COUNT(TAPE_COUNT),.MODEL_ID(MODEL_ID)) u_app (
        .clk(clk),.reset_n(reset_n),.model_locked_i(model_locked_i),
        .upstream_fault_i(upstream_fault_i || fault_q),
        .req_valid_i(reset_n && state_q==PRESENT),.req_ready_o(app_req_ready),
        .req_kind_i(grant_kind_q),.req_tape_i(grant_identity_q[360]),
        .req_generation_i(grant_identity_q[359:296]),.req_model_id_i(grant_identity_q[295:40]),
        .req_model_word_i(grant_model_word_q),.req_layer_i(grant_identity_q[39:37]),
        .req_position_i(grant_identity_q[36:25]),.req_head_i(grant_identity_q[24:23]),
        .req_row_word_i(grant_identity_q[22:19]),.req_shadow_address_i(grant_identity_q[18:0]),
        .req_write_data_i(grant_data_q),
        .rsp_valid_o(app_rsp_valid),.rsp_ready_i(app_rsp_ready),.rsp_kind_o(app_rsp_kind),
        .rsp_identity_o(app_rsp_identity),.rsp_data_o(app_rsp_data),.rsp_fault_o(app_rsp_fault),
        .endpoint_req_valid_o(endpoint_req_valid_o),.endpoint_req_ready_i(endpoint_req_ready_i),
        .endpoint_req_word_address_o(endpoint_req_word_address_o),.endpoint_req_write_o(endpoint_req_write_o),
        .endpoint_req_write_data_o(endpoint_req_write_data_o),
        .endpoint_rsp_valid_i(endpoint_rsp_valid_i),.endpoint_rsp_ready_o(endpoint_rsp_ready_o),
        .endpoint_rsp_data_i(endpoint_rsp_data_i),.endpoint_rsp_error_i(endpoint_rsp_error_i),
        .busy_o(app_busy),.fail_closed_o(app_fault));

    // One accepted model request implicitly reserves the only return slot.
    // Model return has implicit READY1; KV ACK uses ONLY its captured kind.
    // A pre-offer local reject is a fault/zero ACK, NOT a write-completion
    // certificate. Every GOOD write CPL, and every response to a WRITE that
    // actually became a raw offer, follows that offer's final handshake.
    wire owned_return=reset_n && state_q==WAIT_RETURN && app_rsp_valid && app_response_matches;
    wire returned_fault=app_rsp_fault || terminal_now;
    assign model_rsp_valid_o=owned_return && grant_kind_q==KIND_MODEL_READ;
    assign model_rsp_fault_o=model_rsp_valid_o && returned_fault;
    assign model_rsp_data_o=model_rsp_valid_o && !returned_fault ? app_rsp_data : 256'd0;
    assign m_wr_cpl_valid_o=owned_return && grant_kind_q==KIND_KV_WRITE;
    assign m_wr_cpl_fault_o=m_wr_cpl_valid_o && returned_fault;
    assign m_rd_rsp_valid_o=owned_return && grant_kind_q==KIND_KV_READ;
    assign m_rd_rsp_fault_o=m_rd_rsp_valid_o && returned_fault;
    assign m_rd_rsp_data_o=m_rd_rsp_valid_o && !returned_fault ? app_rsp_data : 256'd0;
    assign private_return_identity_o=grant_identity_q;
    assign private_return_kind_o=grant_kind_q;
    assign app_rsp_ready=owned_return &&
        ((grant_kind_q==KIND_MODEL_READ) ||
         (grant_kind_q==KIND_KV_WRITE && m_wr_cpl_ready_i) ||
         (grant_kind_q==KIND_KV_READ && m_rd_rsp_ready_i));
    wire response_take=app_rsp_valid && app_rsp_ready;
    assign busy_o=reset_n && (state_q!=IDLE || app_busy);
    assign fail_closed_o=reset_n && terminal_now;

    // A genuine identity/type mismatch cannot retire this owned request.
    // Late fault/lock loss still permits the matching old response to ACK as
    // fault/zero. No terminal bit erases a live grant or fabricates a return.
    always_ff @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state_q<=IDLE;next_kind_q<=KIND_MODEL_READ;
            grant_kind_q<=KIND_MODEL_READ;grant_identity_q<=0;
            grant_model_word_q<=0;grant_data_q<=0;fault_q<=0;lock_seen_q<=0;
        end else begin
            if(model_locked_i) lock_seen_q<=1;
            if(independent_fault_now) fault_q<=1;
            case(state_q)
                IDLE: if(request_take) begin
                    grant_kind_q<=selected_kind;
                    if(model_take) begin
                        grant_identity_q<={1'b0,64'd0,MODEL_ID,3'd0,12'd0,2'd0,4'd0,19'd0};
                        grant_model_word_q<=model_req_word_i;grant_data_q<=0;
                        next_kind_q<=KIND_KV_WRITE;
                    end else if(write_take) begin
                        grant_identity_q<={m_wr_tape_i,m_wr_generation_i,m_wr_model_id_i,m_wr_layer_i,
                            m_wr_position_i,m_wr_head_i,m_wr_word_i,m_wr_shadow_i};
                        grant_model_word_q<=0;grant_data_q<=m_wr_data_i;next_kind_q<=KIND_KV_READ;
                    end else begin
                        grant_identity_q<={m_rd_tape_i,m_rd_generation_i,m_rd_model_id_i,m_rd_layer_i,
                            m_rd_position_i,m_rd_head_i,m_rd_word_i,m_rd_shadow_i};
                        grant_model_word_q<=0;grant_data_q<=0;next_kind_q<=KIND_MODEL_READ;
                    end
                    state_q<=PRESENT;
                end
                PRESENT: if(app_req_ready) state_q<=WAIT_RETURN;
                WAIT_RETURN: if(response_take) state_q<=IDLE;
                default: fault_q<=1;
            endcase
        end
    end
    initial begin
        if(TAPE_COUNT!=1 && TAPE_COUNT!=2) $fatal(1,"TAPE_COUNT must be1or2");
        if(MODEL_ID!=SS_MODEL_ID) $fatal(1,"This local candidate binds the fixed SimpleStories MODEL_ID");
    end
endmodule
`default_nettype wire

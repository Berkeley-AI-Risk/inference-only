module fixture_probe;
    `include "equal_fixture.svh"
    reg [255:0] answer;
    integer i;
    initial begin
        load_equal_fixtures;
        if($test$plusargs("wrong_epoch")) answer=ref_word(1,2,0,0,0,0);
        if($test$plusargs("out_of_range")) answer=ref_word(0,2,0,16,0,0);
        if($test$plusargs("swap_inputs"))
            for(i=0;i<256;i++) oracle_x[i]=oracle_x[256+i];
        bind_equal_fixtures;
        if(ref_word(0,1,5,16,0,0)===ref_word(1,0,5,16,0,0)) $fatal(1,"aliased independent contexts");
        if(ref_word(0,2,0,0,0,0)!==ref_word(1,1,0,0,0,0)) $fatal(1,"fresh 380 remap");
        $display("FIXTURE_PROBE_PASS");$finish;
    end
endmodule

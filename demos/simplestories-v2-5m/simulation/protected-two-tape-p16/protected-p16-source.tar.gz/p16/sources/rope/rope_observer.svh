    `define L `D.u_lookup
    integer rope_requests[0:5],rope_hits[0:5],rope_returns[0:5];
    integer held_clear_edges=0,miss_clear_edges=0,local_after_clear=0,canceled_physical_returns=0;
    bit canceled_old=0,miss_return_required=0;
    always @(posedge clk)begin:rope_monitor
        integer l;
        reg[255:0] expected_word;
        if(reset_n && release_tick>0)begin
            if(mode==1 && accepted_a==1 && (model_req_valid_o && model_req_ready_i || model_rsp_valid_i && model_rsp_ready_o ||
                core_enqueue || token_valid_o || m_rd_valid_o && m_rd_ready_i || m_wr_valid_o && m_wr_ready_i))
                $display("ROPE_TRACE time=%0t rq=%0d:%0d rp=%0d bus=%0d:%0d:%0d:%0d kv=%0d:%0d token=%0d",
                    $time,model_req_valid_o && model_req_ready_i,(model_req_valid_o && model_req_ready_i)?model_req_word_o:0,
                    model_rsp_valid_i && model_rsp_ready_o,core_enqueue,core_enqueue?core_write:0,core_enqueue?core_address:0,
                    core_enqueue?shared_raw_kv:0,m_rd_valid_o && m_rd_ready_i,m_wr_valid_o && m_wr_ready_i,token_valid_o);
            if(dut.older_published_q && private_job_valid_o && private_job_tape_o && private_job_generation_o==0 &&
                `L.request_transfer && `L.fixed_kind_i<2 && `D.current_layer_q>0)begin
                l=`D.current_layer_q;rope_requests[l]++;
                if(`L.rope_hit)begin
                    if(!`L.reuse_rope_i || !dut.batch.rope_reuse || clear_tapes_i[1])$fatal(1,"wrong hit owner");
                    rope_hits[l]++;
                end
            end
            if(`L.state_q==3 && `L.local_hold_q && `L.response_transfer)begin
                if(!dut.older_published_q || !private_job_valid_o || !private_job_tape_o || private_job_generation_o!=0 ||
                    generation1_o!=0 || clear_tapes_i[1] || !model_locked_i)$fatal(1,"stale locally served rotary operand");
                expected_word=model_rom[`L.word_index_q];
                if(`L.response_value_o!==expected_word[`L.lane_q*16+:16])$fatal(1,"wrong cached rotary operand");
                rope_returns[`D.current_layer_q]++;
                if(canceled_old)local_after_clear++;
            end
            if(rope_arm>=4 && clear_tapes_i[1] && !canceled_old && generation1_o==0)begin
                canceled_old=1;
                if(rope_arm==4)begin
                    if(`L.state_q!=3 || !`L.local_hold_q || `L.response_transfer || `D.rope_raw_ram_write_enable)
                        $fatal(1,"canceled held local transfer");
                    held_clear_edges++;
                end else begin
                    if(`L.state_q!=2 || !`L.requested_rope_q)$fatal(1,"unowned miss at CLEAR");
                    miss_return_required=1;miss_clear_edges++;
                end
            end
            if(miss_return_required && model_rsp_valid_i && model_rsp_ready_o)begin
                canceled_physical_returns++;miss_return_required=0;
                $display("ROPE_MISS_RETURN c=%0d clear=%0d source_tape=%0d",cycles,clear_tapes_i[1],private_job_tape_o);
            end
        end
    end
    always @(posedge ddr_clk) if(reset_n && release_tick>0 && mode==1 && accepted_a==1 && app_command_en && ddr_ready)
        $display("ROPE_DDR time=%0t cmd=%0d address=%0d",$time,app_command,app_address);

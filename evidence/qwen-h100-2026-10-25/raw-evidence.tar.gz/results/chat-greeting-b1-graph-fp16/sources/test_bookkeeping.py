"""Standard-library-only bookkeeping and released-workload checks.

Run `python3.12 -I -S -B test_bookkeeping.py`.
An optional explicit path checks the pinned public measurement correspondence.
These tests never import torch, load a model, access a device or use a network.
"""

import argparse
import contextlib
import io
import json
from pathlib import Path
import sys
import unittest
from unittest import mock

# Isolated-mode invocation deliberately admits only this reviewed directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import benchmark as bench
import model_snapshot as snapshot


class BookkeepingTests(unittest.TestCase):
    def test_counting_cached_intervals(self):
        samples = [{"wall_seconds": 2.0, "cuda_event_seconds": 1.9},
                   {"wall_seconds": 1.0, "cuda_event_seconds": 0.9},
                   {"wall_seconds": 3.0, "cuda_event_seconds": 2.9}]
        result = bench.summarize(samples, batch=8, tokens_per_call=127, iterations=2)
        self.assertEqual(result["counted_tokens_per_trial"], 2032)
        self.assertEqual(result["aggregate_tokens_per_second"], 1016)
        self.assertEqual(result["tokens_per_second_per_sequence"], 127)

    def test_reject_bad_times_and_counts(self):
        for bad in (0, -1, float("nan"), float("inf")):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                bench.summarize([{"wall_seconds": bad, "cuda_event_seconds": 1}], 1, 1, 1)
            with self.subTest(event_bad=bad), self.assertRaises(ValueError):
                bench.summarize([{"wall_seconds": 1, "cuda_event_seconds": bad}], 1, 1, 1)
        with self.assertRaises(ValueError):
            bench.summarize([], 1, 1, 1)

    def test_memory_admission(self):
        self.assertEqual(bench.KV_BYTES_PER_POSITION, 114688)
        self.assertTrue(bench.admitted(2048, 128))
        self.assertFalse(bench.admitted(4096, 128))
        self.assertTrue(bench.admitted(32, 8192))
        self.assertFalse(bench.admitted(128, 8192))
        self.assertFalse(bench.admitted(1, 128, free_memory=1024))

    def test_plan_cannot_import_gpu_stack(self):
        with mock.patch.object(bench, "load_stack", side_effect=AssertionError("GPU stack imported")):
            result = bench.plan()
        self.assertTrue(result["no_model_download_or_gpu_started"])
        self.assertEqual(len(result["fixed_context_candidates"]), 28)
        self.assertEqual(set(result["matched_prompts"]), {"raw_story", "raw_geography", "chat_greeting"})
        self.assertEqual(result["model"], "Qwen/Qwen3-1.7B")

    def test_no_silent_default_execution(self):
        for bad in ([], ["--run"], ["--plan", "--seconds", "nan"],
                    ["--plan", "--batch", "4097"], ["--plan", "--context", "32769"],
                    ["--plan", "--workload", "continuation", "--mode", "compile-graph"]):
            with self.subTest(args=bad), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    bench.parse_args(bad)

    def test_explicit_fixed_compile_arguments(self):
        a = bench.parse_args(["--plan", "--workload", "fixed", "--mode", "compile-graph"])
        self.assertEqual(a.context, 128)
        self.assertEqual(a.dtype, "bfloat16")

    def test_primary_single_token_geometry(self):
        self.assertEqual(bench.parse_args(["--plan"]).prompt, "single_token")
        case = bench.prompt_case("single_token")
        self.assertEqual(case["prompt_tokens"], [9707])
        self.assertEqual(case["cached_decode_contexts_including_current_input"], [2, 128])
        self.assertIsNone(case["fpga_expected_tokens"])
        self.assertEqual(bench.plan()["primary_continuation"]["name"], "single_token")

    def test_rounding_policy_is_explicit_and_limited(self):
        self.assertFalse(bench.parse_args(["--plan"]).allow_greedy_rounding)
        good = ["--plan", "--workload", "fixed", "--mode", "compile-graph",
                "--dtype", "float16", "--allow-greedy-rounding"]
        self.assertTrue(bench.parse_args(good).allow_greedy_rounding)
        for bad in (["--plan", "--allow-greedy-rounding"],
                    ["--plan", "--workload", "fixed", "--mode", "graph", "--dtype", "float16", "--allow-greedy-rounding"],
                    ["--plan", "--workload", "fixed", "--mode", "compile-graph", "--allow-greedy-rounding"]):
            with self.subTest(args=bad), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    bench.parse_args(bad)

    def test_pending_fpga_data_is_not_counted_as_agreement(self):
        panel = bench.fpga_parent_panel("single_token", [9707] * 128)
        self.assertEqual(panel["comparisons"], 0)
        self.assertIsNone(panel["fpga_token_ids"])
        self.assertNotIn("agreement_fraction", panel)
        old = bench.workloads()["raw_story"]["fpga_expected_tokens"]
        self.assertEqual(bench.fpga_parent_panel("raw_story", old)["agreement_fraction"], 1)
        with self.assertRaises(ValueError):
            bench.fpga_parent_panel("single_token", [9707] * 3)

    def test_snapshot_is_correct_model_not_retired_qwen25(self):
        self.assertEqual(snapshot.REPOSITORY, "Qwen/Qwen3-1.7B")
        self.assertEqual(snapshot.REVISION, "70d244cc86ccca08cf5af4e1e306ecf908b1ad5e")
        self.assertEqual(snapshot.FILES["model-00001-of-00002.safetensors"][0], 3441185608)

    def test_parent_and_fpga_not_labeled_equal(self):
        spec = json.loads((bench.HERE / "SPEC.json").read_text())
        self.assertFalse(spec["model"]["fpga_exact_numerical_function"])
        self.assertEqual(spec["paper"]["current_term"], "residual training factor")
        self.assertFalse(spec["capacity_interpretation"]["smallstories_h100_rate_reused"])
        self.assertTrue(spec["capacity_interpretation"]["no_phi_less_than_1e_minus_4_claim"])

    def test_changed_measurement_is_rejected(self):
        with mock.patch.object(Path, "read_bytes", return_value=b"changed"):
            with self.assertRaises(ValueError):
                bench.validate_release_measurements("unused")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--release-measurements", type=Path)
    args, remainder = p.parse_known_args()
    result = unittest.main(argv=[sys.argv[0], *remainder], exit=False)
    if not result.result.wasSuccessful():
        return 1
    if args.release_measurements:
        print(json.dumps(bench.validate_release_measurements(args.release_measurements), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

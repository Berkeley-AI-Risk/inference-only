"""Exercise the real Qwen3 cache adapter with a tiny random CPU model.

No pretrained data, network, CUDA, compilation or device performance test.
Run using the pinned requirements and torch. The benchmark GPU guard remains
unchanged; only these tests replace CUDA synchronization for CPU construction.
"""
from pathlib import Path
import sys
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent))
import benchmark as bench
import torch
from transformers import Qwen3Config, Qwen3ForCausalLM


class RuntimeCPUChecks(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(2)
        torch.manual_seed(20261025)
        self.constants = mock.patch.multiple(
            bench, VOCAB=97, LAYERS=2, WIDTH=32, FFN=64,
            Q_HEADS=4, KV_HEADS=2, HEAD=8)
        self.constants.start()
        self.addCleanup(self.constants.stop)
        config = Qwen3Config(vocab_size=97, hidden_size=32, intermediate_size=64,
                            num_hidden_layers=2, num_attention_heads=4,
                            num_key_value_heads=2, head_dim=8,
                            max_position_embeddings=256, tie_word_embeddings=True)
        config._attn_implementation = "sdpa"
        self.model = Qwen3ForCausalLM(config).eval()
        self.model.requires_grad_(False)

    @torch.inference_mode()
    def test_changed_inputs_and_cached_full_at_chunk_boundary(self):
        # Includes empty prefix, ordinary prefix, and multi-chunk prefill.
        for context in (1, 7, 133):
            with self.subTest(context=context):
                checks = bench.validate_inputs(self.model, "float32", context, 31)
                self.assertTrue(all(x["greedy_mismatch_count"] == 0 for x in checks))

    @torch.inference_mode()
    def assert_trajectory(self, prompt_length):
        ids = bench.make_tapes(2, prompt_length, 43, device="cpu")
        with mock.patch.object(torch.cuda, "synchronize"):
            case = bench.Continuation(self.model, ids)
        got_logits, got_tokens = bench.snapshot(case())
        # Independent uncached full forward at every step checks causality,
        # cache offsets and all 128 feedback-dependent outputs.
        tape = ids.clone()
        expected = []
        for _ in range(128):
            logits = self.model(input_ids=tape, use_cache=False,
                                logits_to_keep=1).logits[:, -1, :]
            token = logits.argmax(-1, keepdim=True)
            expected.append(token)
            tape = torch.cat((tape, token), dim=1)
        self.assertTrue(torch.equal(got_tokens, torch.cat(expected, dim=1)))
        torch.testing.assert_close(got_logits, logits, rtol=0.005, atol=0.05)
        replay_logits, replay_tokens = case()
        self.assertTrue(torch.equal(replay_tokens, got_tokens))
        self.assertTrue(torch.equal(replay_logits, got_logits))
        case.ids[:, 0].add_(1).remainder_(97)
        case.restore_prefix()
        changed_logits, _ = case()
        self.assertFalse(torch.equal(changed_logits, got_logits))

    def test_true_feedback_trajectory_and_replay(self):
        self.assert_trajectory(5)

    def test_one_token_128_output_feedback_trajectory(self):
        self.assert_trajectory(1)

    def test_rounding_policy_retains_logit_and_finiteness_checks(self):
        expected = (torch.tensor([[0.01, 0.0]]), torch.tensor([[0]]))
        changed = (torch.tensor([[0.0, 0.01]]), torch.tensor([[1]]))
        with self.assertRaises(bench.ValidationFailure):
            bench.comparison(changed, expected, "strict")
        record = bench.comparison(changed, expected, "explicit_reference", strict=False)
        self.assertEqual(record["greedy_mismatch_count"], 1)
        self.assertAlmostEqual(record["mismatching_rows_top_two_margins"][0]["expected_gap"], 0.01)
        for bad in (torch.tensor([[1.0, 0.0]]), torch.tensor([[float('nan'), 0.0]])):
            with self.assertRaises(bench.ValidationFailure):
                bench.comparison((bad, torch.tensor([[0]])), expected, "invalid", strict=False)


if __name__ == "__main__":
    unittest.main()

"""Prepared, not yet qualified, Qwen3-1.7B H100 reference benchmark.

No default invocation rents hardware, downloads a model or starts a sweep.
`--plan` uses only the standard library. Each explicit `--run` executes one
reviewed case in a new output directory. Read SPEC.json before interpreting it.

The small explicit cache below retains native GQA head counts and returns only
the actually populated prefix. It does not replace any layer, projection,
normalization, rotary calculation, vocabulary head or argmax of the parent.
It intentionally avoids generic static-cache masking that can cause complete
K/V expansion on every decode. Cached/full and changed-input checks are gates,
not optional benchmark decorations. CPU adapter checks do not qualify CUDA
graph capture, compilation or H100 performance.
"""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import inspect
import io
import json
import math
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

from model_snapshot import REPOSITORY, REVISION, verify

HERE = Path(__file__).resolve().parent
VOCAB, LAYERS, WIDTH, FFN, Q_HEADS, KV_HEADS, HEAD = 151936, 28, 2048, 6144, 16, 8, 128
UNIQUE_PARAMETERS = 1720574976
KV_BYTES_PER_POSITION = 2 * LAYERS * KV_HEADS * HEAD * 2
SOURCE_NAMES = ("benchmark.py", "model_snapshot.py", "test_bookkeeping.py",
                "test_runtime_cpu.py", "README.md", "SPEC.json", "workloads.json", "requirements.txt")
MAX_KV_BYTES, OTHER_HEADROOM = 40 * 1024**3, 12 * 1024**3


class ValidationFailure(ValueError):
    def __init__(self, message, record):
        super().__init__(message)
        self.record = record


def positive_int(value):
    result = int(value)
    if result <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return result


def source_hashes():
    return {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
            for name in SOURCE_NAMES}


def workloads():
    record = json.loads((HERE / "workloads.json").read_text())
    if record["measurement_sha256"] != "8266c1a3e9057302af4cc1cdf5085ca496d688541d04feffe07d041ab3b7140b":
        raise ValueError("Unexpected released measurement binding")
    if set(record["cases"]) != {"raw_story", "raw_geography", "chat_greeting"}:
        raise ValueError("Unexpected matched workload inventory")
    for case in record["cases"].values():
        if len(case["fpga_expected_tokens"]) != 128 or not case["prompt_tokens"]:
            raise ValueError("Malformed released workload")
        if any(type(x) is not int or not 0 <= x < VOCAB
               for x in case["prompt_tokens"] + case["fpga_expected_tokens"]):
            raise ValueError("Out-of-domain released token")
    return record["cases"]


def prompt_case(name):
    if name == "single_token":
        return {"prompt_tokens": [9707], "fpga_expected_tokens": None,
                "cached_decode_contexts_including_current_input": [2, 128],
                "fpga_measurement_status": "128-output FPGA run pending; existing smoke has three outputs"}
    return workloads()[name]


def fpga_parent_panel(name, parent_tokens):
    if len(parent_tokens) != 128:
        raise ValueError("Expected all 128 parent outputs")
    expected = prompt_case(name)["fpga_expected_tokens"]
    if expected is None:
        return {"row": 0, "comparisons": 0, "parent_token_ids": parent_tokens,
                "fpga_token_ids": None, "status": "matching_128_output_fpga_record_pending"}
    mismatches = [i for i, (a, b) in enumerate(zip(parent_tokens, expected)) if a != b]
    return {"row": 0, "comparisons": 128, "mismatch_count": len(mismatches),
            "disagreement_positions": mismatches,
            "agreement_fraction": 1 - len(mismatches) / 128,
            "parent_token_ids": parent_tokens, "fpga_token_ids": expected,
            "acceptance_role": "reported numerical-model difference, not a silent equivalence claim"}


def validate_release_measurements(path):
    """Read-only independent check that the small workload copy is exact."""
    raw = Path(path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != "8266c1a3e9057302af4cc1cdf5085ca496d688541d04feffe07d041ab3b7140b":
        raise ValueError("Released measurement identity changed")
    selected = workloads()
    campaigns = json.loads(raw)["campaigns"]
    matched = [c for c in campaigns if c["name"] == "sustained-128-run2"]
    if len(matched) != 1:
        raise ValueError("Ambiguous selected campaign")
    originals = {c["name"]: c for c in matched[0]["cases"] if c["name"] in selected}
    if set(originals) != set(selected):
        raise ValueError("Missing selected hardware workload")
    for name, case in selected.items():
        original = originals[name]
        if (case["prompt_tokens"] != original["prompt_tokens"]
                or case["fpga_expected_tokens"] != original["expected_tokens"]):
            raise ValueError("Prompt/output copy differs: " + name)
        lines = [json.loads(line) for line in original["stdout"].splitlines()]
        rate = 127e9 / (lines[-1]["generation_elapsed_ns"] - lines[0]["generation_elapsed_ns"])
        if rate != case["fpga_cached_tokens_per_second"]:
            raise ValueError("Cached-rate copy differs: " + name)
        if lines[0]["prompt_elapsed_ns"] / 1e9 != case["fpga_first_token_seconds"]:
            raise ValueError("First-token copy differs: " + name)
        length = len(case["prompt_tokens"])
        if case["cached_decode_contexts_including_current_input"] != [length + 1, length + 127]:
            raise ValueError("Incorrect cached-context endpoints: " + name)
    return {"passed": True, "measurement_sha256": digest,
            "cases": sorted(selected), "output_ids_checked": 384}


def summarize(samples, batch, tokens_per_call, iterations):
    if not samples or min(batch, tokens_per_call, iterations) <= 0:
        raise ValueError("Empty samples or invalid counted work")
    for sample in samples:
        if any(not math.isfinite(sample[key]) or sample[key] <= 0
               for key in ("wall_seconds", "cuda_event_seconds")):
            raise ValueError("Invalid timing")
    count = batch * tokens_per_call * iterations
    wall = [x["wall_seconds"] for x in samples]
    return {"aggregate_tokens_per_second": count / statistics.median(wall),
            "tokens_per_second_per_sequence": count / batch / statistics.median(wall),
            "aggregate_tps_min": count / max(wall),
            "aggregate_tps_max": count / min(wall),
            "counted_tokens_per_trial": count, "samples": samples}


def admitted(batch, cache_positions, total_memory=None, free_memory=None):
    required = batch * cache_positions * KV_BYTES_PER_POSITION
    if required > MAX_KV_BYTES:
        return False
    if total_memory is not None and required + OTHER_HEADROOM > total_memory:
        return False
    if free_memory is not None and required + OTHER_HEADROOM > free_memory:
        return False
    return True


def plan():
    batches = (1, 8, 32, 128, 512, 2048, 4096)
    cases = []
    for context in (128, 512, 2048, 8192):
        for batch in batches:
            cases.append({"workload": "fixed", "context": context, "batch": batch,
                          "minimum_kv_bytes": batch * context * KV_BYTES_PER_POSITION,
                          "memory_admitted_before_runtime_check": admitted(batch, context)})
    return {"status": "preparation_only_not_executed", "model": REPOSITORY,
            "revision": REVISION, "source_sha256": source_hashes(),
            "primary_continuation": {"name": "single_token", **prompt_case("single_token")},
            "matched_prompts": workloads(), "fixed_context_candidates": cases,
            "execution_policy": "Select staged cases explicitly; no automatic Cartesian compile sweep.",
            "no_model_download_or_gpu_started": True}


_STACK = None


def load_stack():
    global _STACK
    if _STACK is None:
        import torch
        from transformers import Qwen3ForCausalLM
        _STACK = torch, Qwen3ForCausalLM
    return _STACK


def stack_versions():
    expected = {"torch": "2.10.0", "transformers": "5.17.0", "tokenizers": "0.23.2",
                "safetensors": "0.8.0", "huggingface-hub": "1.33.0", "numpy": "1.26.4"}
    found = {name: importlib.metadata.version(name) for name in expected}
    if any(found[name].split("+")[0] != version for name, version in expected.items()):
        raise ValueError("Unreviewed dependency versions: " + json.dumps(found))
    return found


def nvidia_query(fields, gpu=None):
    command = ["nvidia-smi"]
    if gpu is not None:
        command += ["-i", gpu]
    command += ["--query-gpu=" + fields, "--format=csv,noheader,nounits"]
    result = subprocess.run(command, capture_output=True, text=True, timeout=20, check=False)
    if result.returncode:
        raise ValueError("nvidia-smi qualification failed: " + result.stderr.strip())
    return list(csv.reader(io.StringIO(result.stdout.strip())))


def gpu_identity(torch):
    visible = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if not visible or "," in visible or "MIG-" in visible:
        raise ValueError("Set CUDA_VISIBLE_DEVICES to exactly one whole GPU")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise ValueError("Exactly one CUDA-visible GPU is required")
    p = torch.cuda.get_device_properties(0)
    if ("H100" not in p.name or p.multi_processor_count != 132
            or (p.major, p.minor) != (9, 0) or p.total_memory < 79_000_000_000):
        raise ValueError("Expected full H100 SXM 80 GB, not PCIe/MIG/another GPU")
    uuid = str(p.uuid)
    if not uuid.startswith("GPU-"):
        uuid = "GPU-" + uuid
    fields = "uuid,name,driver_version,memory.total,mig.mode.current,power.limit,clocks.current.sm,clocks.current.memory"
    rows = nvidia_query(fields, uuid)
    if len(rows) != 1 or len(rows[0]) != 8 or rows[0][4].strip() != "Disabled":
        raise ValueError("Selected whole-GPU identity/MIG state could not be qualified")
    record = dict(zip(fields.split(","), [x.strip() for x in rows[0]]))
    processes = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=gpu_uuid,pid,process_name,used_memory", "--format=csv,noheader,nounits"],
        capture_output=True, text=True, timeout=20, check=False)
    if processes.returncode:
        raise ValueError("Cannot check selected-GPU competing workloads")
    other = []
    for row in csv.reader(io.StringIO(processes.stdout.strip())):
        if len(row) >= 2 and row[0].strip() == uuid and int(row[1].strip()) != os.getpid():
            other.append(row)
    if other:
        raise ValidationFailure("Another workload is using the selected GPU", {"processes": other})
    record.update({"torch_name": p.name, "multiprocessor_count": p.multi_processor_count,
                   "total_memory_bytes": p.total_memory, "compute_capability": [p.major, p.minor],
                   "cuda_visible_devices": visible, "selected_uuid": uuid,
                   "other_compute_processes_on_selected_gpu": other})
    return record


def load_model(directory, dtype):
    torch, Qwen3ForCausalLM = load_stack()
    model = Qwen3ForCausalLM.from_pretrained(
        str(directory), local_files_only=True, trust_remote_code=False, use_safetensors=True,
        dtype=getattr(torch, dtype), attn_implementation="sdpa").eval().to("cuda")
    model.requires_grad_(False)
    if sum(p.numel() for p in model.parameters()) != UNIQUE_PARAMETERS:
        raise ValueError("Wrong unique parameter inventory")
    config = model.config
    actual = (config.hidden_size, config.intermediate_size, config.num_hidden_layers,
              config.num_attention_heads, config.num_key_value_heads, config.head_dim, config.vocab_size)
    if actual != (WIDTH, FFN, LAYERS, Q_HEADS, KV_HEADS, HEAD, VOCAB):
        raise ValueError("Wrong model architecture")
    if any(kind != "full_attention" for kind in config.layer_types):
        raise ValueError("This benchmark has no sliding-window cache adapter")
    if model.lm_head.weight.data_ptr() != model.model.embed_tokens.weight.data_ptr():
        raise ValueError("Tied embedding/head storage was not preserved")
    return model


class PinnedCache:
    """Private benchmark-only native-head cache; not a model approximation.

    `position` is set by the reviewed workload, never inferred from data values.
    Every returned position has just been written or was populated by prefill.
    Fixed decode overwrites exactly its last slot on every invocation. Closed
    loop writes each following slot before any layer attends to that slot.
    No model tensor or output is memoized. Keys/values have disjoint row storage.
    """
    def __init__(self, model, batch, capacity):
        torch, _ = load_stack()
        self.position, self.capacity = 0, capacity
        shape = (batch, KV_HEADS, capacity, HEAD)
        self.keys = [torch.empty(shape, dtype=model.dtype, device=model.device) for _ in range(LAYERS)]
        self.values = [torch.empty_like(k) for k in self.keys]

    def update(self, key_states, value_states, layer_idx, *args, **kwargs):
        end = self.position + key_states.shape[-2]
        if end > self.capacity:
            raise ValueError("Cache write out of bounds")
        self.keys[layer_idx][:, :, self.position:end, :].copy_(key_states)
        self.values[layer_idx][:, :, self.position:end, :].copy_(value_states)
        return self.keys[layer_idx][:, :, :end, :], self.values[layer_idx][:, :, :end, :]

    def get_seq_length(self, layer_idx=0):
        return self.position


def forward_at(model, cache, ids, position, position_ids):
    torch, _ = load_stack()
    cache.position = position
    length = ids.shape[1]
    mask = None
    if length > 1:
        q = torch.arange(position, position + length, device=ids.device)
        k = torch.arange(position + length, device=ids.device)
        mask = (k[None, :] <= q[:, None])[None, None, :, :]
    # For a one-token query, every returned cache entry is populated and past
    # or current. None is exactly its causal mask, permitting native GQA SDPA.
    return model(input_ids=ids, position_ids=position_ids,
                 attention_mask={"full_attention": mask}, past_key_values=cache,
                 use_cache=True, logits_to_keep=1).logits[:, -1, :]


def populate(model, cache, ids, chunk=128):
    torch, _ = load_stack()
    logits = None
    for start in range(0, ids.shape[1], chunk):
        stop = min(start + chunk, ids.shape[1])
        positions = torch.arange(start, stop, device=ids.device).view(1, -1)
        logits = forward_at(model, cache, ids[:, start:stop], start, positions)
    return logits


def make_tapes(batch, length, seed, matched=None, device="cuda"):
    torch, _ = load_stack()
    g = torch.Generator(device="cpu").manual_seed(seed)
    ids = torch.randint(0, VOCAB, (batch, length), generator=g)
    if matched is not None:
        ids[0] = torch.tensor(matched, dtype=torch.long)
    return ids.to(device)


class FixedDecode:
    tokens_per_call = 1

    def __init__(self, model, ids):
        torch, _ = load_stack()
        self.model, self.ids = model, ids.clone()
        self.batch, self.context = ids.shape
        self.cache = PinnedCache(model, self.batch, self.context)
        self.input_ids = self.ids[:, -1:].clone()
        self.position_ids = torch.tensor([[self.context - 1]], device=ids.device)
        self.restore_prefix()

    def restore_prefix(self):
        if self.context > 1:
            populate(self.model, self.cache, self.ids[:, :-1])
        self.input_ids.copy_(self.ids[:, -1:])

    def __call__(self):
        logits = forward_at(self.model, self.cache, self.input_ids,
                            self.context - 1, self.position_ids)
        return logits, logits.argmax(-1, keepdim=True)


class Continuation:
    tokens_per_call = 127

    def __init__(self, model, ids):
        torch, _ = load_stack()
        self.model, self.ids = model, ids.clone()
        self.batch, self.prompt_length = ids.shape
        self.cache = PinnedCache(model, self.batch, self.prompt_length + 127)
        self.positions = [torch.tensor([[self.prompt_length + i]], device=ids.device) for i in range(127)]
        self.first_token = torch.empty((self.batch, 1), dtype=torch.long, device=ids.device)
        torch.cuda.synchronize()
        started = time.perf_counter()
        self.restore_prefix()
        torch.cuda.synchronize()
        self.initial_prefill_seconds = time.perf_counter() - started

    def restore_prefix(self):
        logits = populate(self.model, self.cache, self.ids)
        self.first_token.copy_(logits.argmax(-1, keepdim=True))

    def __call__(self):
        torch, _ = load_stack()
        token = self.first_token
        outputs = [token]
        for i in range(127):
            logits = forward_at(self.model, self.cache, token,
                                self.prompt_length + i, self.positions[i])
            token = logits.argmax(-1, keepdim=True)
            outputs.append(token)
        return logits, torch.cat(outputs, dim=1)


def comparison(actual, expected, label, strict=True):
    torch, _ = load_stack()
    a_logits, a_tokens = actual
    e_logits, e_tokens = expected
    if not torch.isfinite(a_logits).all() or not torch.isfinite(e_logits).all():
        raise ValidationFailure(label + ": nonfinite logits", {"finite": False})
    delta = a_logits.float() - e_logits.float()
    mismatch = a_tokens != e_tokens
    positions = mismatch.nonzero().cpu().tolist()
    record = {"label": label, "token_comparisons": e_tokens.numel(),
              "greedy_mismatch_count": len(positions), "first_mismatch_coordinates": positions[:64],
              "max_absolute_logit_error": delta.abs().max().item(),
              "rms_logit_error": delta.square().mean().sqrt().item(),
              "last_step_reference_top_two_margins_first_8_rows":
                  (e_logits.float().topk(2, dim=-1).values.diff(dim=-1).abs())[:8, 0].cpu().tolist(),
              "margins_do_not_explain_earlier_trajectory_disagreements": True,
              "logit_rtol": 0.005, "logit_atol": 0.05, "strict_greedy": strict}
    if e_tokens.shape[-1] == 1:
        record["mismatching_rows_top_two_margins"] = [
            {"row": row, "expected_token": e_tokens[row, 0].item(),
             "actual_token": a_tokens[row, 0].item(),
             "expected_gap": e_logits[row].float().topk(2).values.diff().abs().item(),
             "actual_gap": a_logits[row].float().topk(2).values.diff().abs().item()}
            for row, _ in positions[:64]]
    try:
        torch.testing.assert_close(a_logits, e_logits, rtol=0.005, atol=0.05)
    except AssertionError as error:
        raise ValidationFailure(label + ": logits outside stated tolerance", record) from error
    if strict and positions:
        raise ValidationFailure(label + ": greedy predictions changed", record)
    return record


def snapshot(output):
    return tuple(x.detach().clone() for x in output)


def validate_inputs(model, dtype, context, seed):
    """Small independent whole-model cache adapter gates, before large timing."""
    torch, _ = load_stack()
    ids = make_tapes(2, context, seed, device=model.device)
    case = FixedDecode(model, ids)
    cached = snapshot(case())
    full_logits = model(input_ids=ids, use_cache=False, logits_to_keep=1).logits[:, -1, :]
    checks = [comparison(cached, (full_logits, full_logits.argmax(-1, keepdim=True)), "cached_vs_full")]
    old_prefix = [x[:, :, :-1, :].clone()
                  for x in case.cache.keys + case.cache.values]
    replay = snapshot(case())
    checks.append(comparison(replay, cached, "same_input_replay"))
    if any(not torch.equal(old, value[:, :, :-1, :])
           for old, value in zip(old_prefix, case.cache.keys + case.cache.values)):
        raise ValueError("Fixed decode changed previously cached keys or values")
    case.input_ids.add_(3).remainder_(VOCAB)
    changed_ids = ids.clone()
    changed_ids[:, -1:] = case.input_ids
    changed = snapshot(case())
    full_changed = model(input_ids=changed_ids, use_cache=False, logits_to_keep=1).logits[:, -1, :]
    checks.append(comparison(changed, (full_changed, full_changed.argmax(-1, keepdim=True)), "changed_final_token"))
    if torch.equal(changed[0], cached[0]):
        raise ValueError("Changed final token had no observable model effect")
    if context > 1:
        case.ids[:, 0].add_(7).remainder_(VOCAB)
        case.restore_prefix()
        changed_prefix = snapshot(case())
        full_prefix = model(input_ids=case.ids, use_cache=False, logits_to_keep=1).logits[:, -1, :]
        checks.append(comparison(changed_prefix, (full_prefix, full_prefix.argmax(-1, keepdim=True)), "changed_prefix"))
        if torch.equal(changed_prefix[0], cached[0]):
            raise ValueError("Changed prefix had no observable model effect")
    return checks


def prepare_runner(case, mode, allow_greedy_rounding=False):
    torch, _ = load_stack()
    expected = snapshot(case())
    if mode == "eager":
        return case, comparison(case(), expected, "eager_replay")
    if mode == "compile-graph" and isinstance(case, Continuation):
        raise ValueError("Do not unroll/compile a 127-step continuation; first qualify eager/graph")
    function = case
    if mode == "compile-graph":
        function = torch.compile(case, fullgraph=True, dynamic=False,
                                 mode="max-autotune-no-cudagraphs")
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        for _ in range(3):
            function()
    torch.cuda.current_stream().wait_stream(stream)
    torch.cuda.synchronize()
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        output = function()
    graph.replay()
    torch.cuda.synchronize()
    check = comparison(output, expected, "optimized_vs_eager", strict=not allow_greedy_rounding)

    def replay():
        graph.replay()
        return output

    # The modified prefix uses the same allocated cache/input buffers as capture.
    original = case.ids.clone()
    case.ids[:, 0].add_(7).remainder_(VOCAB)
    case.restore_prefix()
    changed_expected = snapshot(case())
    check["changed_prefix_after_capture"] = comparison(replay(), changed_expected, "graph_changed_prefix", strict=not allow_greedy_rounding)
    if torch.equal(changed_expected[0], expected[0]):
        raise ValueError("Captured graph changed-prefix guard was ineffective")
    case.ids.copy_(original)
    case.restore_prefix()
    check["restored_inputs_after_capture"] = comparison(replay(), expected, "graph_restored_inputs", strict=not allow_greedy_rounding)
    return replay, check


def time_calls(function, count):
    torch, _ = load_stack()
    torch.cuda.synchronize()
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    start.record()
    began = time.perf_counter()
    for _ in range(count):
        function()
    end.record()
    end.synchronize()
    return {"wall_seconds": time.perf_counter() - began,
            "cuda_event_seconds": start.elapsed_time(end) / 1000}


def profile_decode(case, outdir):
    torch, _ = load_stack()
    if isinstance(case, Continuation):
        # Profile one real next decode, not 127 iterations or model setup.
        def one():
            logits = forward_at(case.model, case.cache, case.first_token,
                                case.prompt_length, case.positions[0])
            return logits.argmax(-1)
    else:
        one = case
    torch.cuda.synchronize()
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                           torch.profiler.ProfilerActivity.CUDA],
                                record_shapes=True, profile_memory=True) as prof:
        one()
        torch.cuda.synchronize()
    events = []
    for event in prof.key_averages(group_by_input_shape=True):
        events.append({"name": event.key, "count": event.count, "input_shapes": event.input_shapes,
                       "cpu_time_total_us": event.cpu_time_total,
                       "device_time_total_us": getattr(event, "device_time_total", None),
                       "self_device_memory_usage": getattr(event, "self_device_memory_usage", None)})
    prof.export_chrome_trace(str(outdir / "profile-trace.json"))
    return {"scope": "one eager whole-model cached decode, outside timing",
            "operators": events,
            "copy_and_attention_survey": [e for e in events if any(
                name in e["name"] for name in ("clone", "copy", "repeat", "expand", "scaled_dot_product", "flash", "cudnn"))],
            "interpretation": "Operator/shape evidence, not an assumption that all copies are cache expansion or that a plateau is hardware peak."}


def module_sources():
    import transformers.cache_utils as cache_module
    import transformers.integrations.sdpa_attention as sdpa_module
    import transformers.models.qwen3.modeling_qwen3 as model_module
    torch, _ = load_stack()
    result = {}
    for name, module in (("transformers_qwen3", model_module), ("transformers_cache", cache_module),
                         ("transformers_sdpa", sdpa_module), ("torch", torch)):
        path = Path(inspect.getfile(module)).resolve()
        result[name] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    return result


def run(args, output, event):
    started = time.monotonic()

    def retain(name, value):
        with (output / name).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")

    def budget(stage):
        event(stage)
        if time.monotonic() - started > args.max_runtime:
            raise ValueError("Explicit case runtime budget exceeded between stages; no retry")

    model_files = verify(args.model_dir)
    packages = stack_versions()
    retain("model-and-dependencies.json", {"model_files": model_files, "packages": packages})
    torch, _ = load_stack()
    torch.set_num_threads(8)
    torch.set_grad_enabled(False)
    torch.manual_seed(args.seed)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
    torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
    identity = gpu_identity(torch)
    retain("gpu-qualification.json", identity)
    budget("verified_model_stack_gpu")
    model = load_model(args.model_dir, args.dtype)
    budget("model_loaded")
    required_context = args.context if args.workload == "fixed" else len(prompt_case(args.prompt)["prompt_tokens"]) + 127
    free, total = torch.cuda.mem_get_info()
    if not admitted(args.batch, required_context, total, free):
        raise ValueError("Case fails reviewed K/V plus workspace memory admission")
    checks = validate_inputs(model, args.dtype, min(required_context, 8192), args.seed + 1)
    retain("cache-input-correctness.json", checks)
    torch.cuda.empty_cache()
    budget("independent_whole_model_input_checks_passed")
    if args.workload == "fixed":
        ids = make_tapes(args.batch, args.context, args.seed)
        case = FixedDecode(model, ids)
    else:
        prompt = prompt_case(args.prompt)["prompt_tokens"]
        ids = make_tapes(args.batch, len(prompt), args.seed, matched=prompt)
        case = Continuation(model, ids)
    budget("workload_prefix_constructed")
    runner, optimization = prepare_runner(case, args.mode, args.allow_greedy_rounding)
    retain("runner-correctness.json", optimization)
    budget("runner_correctness_passed")
    for _ in range(args.warmup):
        runner()
    calibration = time_calls(runner, 1)
    iterations = max(1, min(10000, math.ceil(args.seconds / calibration["wall_seconds"])))
    samples = []
    for trial in range(args.trials):
        budget("timing_trial_" + str(trial))
        sample = time_calls(runner, iterations)
        retain("cached-trial-" + str(trial) + ".json", sample)
        samples.append(sample)
    first_token_samples, full_samples = [], []
    if isinstance(case, Continuation):
        def full_generation():
            case.restore_prefix()
            return runner()
        for trial in range(args.trials):
            budget("separate_first_and_full_generation_trial_" + str(trial))
            first_sample = time_calls(case.restore_prefix, 1)
            full_sample = time_calls(full_generation, 1)
            retain("first-and-full-trial-" + str(trial) + ".json",
                   {"first_output": first_sample, "all_128_outputs": full_sample})
            first_token_samples.append(first_sample)
            full_samples.append(full_sample)
    final = snapshot(runner())
    token_ids = final[1].cpu().tolist()
    fpga_comparison = None
    if args.workload == "continuation":
        fpga_comparison = fpga_parent_panel(args.prompt, token_ids[0])
    profile = profile_decode(case, output) if args.profile else None
    identity_after = gpu_identity(torch)
    retain("gpu-qualification-after.json", identity_after)
    budget("completed")
    return {"schema": "qwen17b-h100-case-v1", "status": "pass",
            "numerical_acceptance_policy": {
                "compiled_greedy_rounding_allowed": args.allow_greedy_rounding,
                "all_logit_rtol": 0.005, "all_logit_atol": 0.05,
                "nonfinite_outputs_rejected": True,
                "cache_full_input_checks_strict_greedy": True,
                "scope": "Any waiver applies only to compiled fixed-context FP16 optimized/eager checks; discrepancies are recorded."},
            "model": {"repository": REPOSITORY, "revision": REVISION, "dtype": args.dtype,
                      "unique_parameters": UNIQUE_PARAMETERS, "files": model_files,
                      "fpga_exact_numerical_function": False},
            "environment": {"gpu": identity, "python": sys.version, "executable": sys.executable,
                            "resolved_executable": str(Path(sys.executable).resolve()),
                            "platform": platform.platform(), "os_release": platform.freedesktop_os_release(),
                            "packages": packages, "cuda_runtime": torch.version.cuda,
                            "cudnn": torch.backends.cudnn.version(), "tf32": False,
                            "reduced_precision_gemm_reduction": False,
                            "module_sources": module_sources(),
                            "all_packages": {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}},
            "workload": {"kind": args.workload, "prompt": args.prompt if args.workload == "continuation" else None,
                         "context": args.context if args.workload == "fixed" else None,
                         "batch": args.batch, "seed": args.seed, "mode": args.mode,
                         "tokens_per_call_in_timing": case.tokens_per_call, "iterations": iterations,
                         "prefix_population_chunk": 128, "independent_kv_storage": True,
                         "independent_content_except_matched_row_zero": True,
                         "eos_stopping": False, "argmax_included": True,
                         "host_launches_and_sync_included": True,
                         "host_token_copy_and_text_decoding_included": False,
                         "fixed_context_repeats_are_not_closed_loop_generation": args.workload == "fixed",
                         "first_token_prefill_seconds_before_runner_setup": getattr(case, "initial_prefill_seconds", None)},
            "checks": {"whole_model_cache_input_checks": checks, "optimized": optimization,
                       "fpga_parent_agreement": fpga_comparison,
                       "token_ids_sha256": hashlib.sha256(json.dumps(token_ids, separators=(",", ":")).encode()).hexdigest()},
            "timing": summarize(samples, args.batch, case.tokens_per_call, iterations),
            "separate_first_output_timing": summarize(first_token_samples, args.batch, 1, 1) if first_token_samples else None,
            "separate_all_128_output_timing": summarize(full_samples, args.batch, 128, 1) if full_samples else None,
            "profile": profile,
            "gpu_peak_memory_allocated": torch.cuda.max_memory_allocated(),
            "gpu_peak_memory_reserved": torch.cuda.max_memory_reserved(),
            "limitations": ["Achieved implementation rate, not a proved peak or licensed rating.",
                            "Upstream BF16/FP16 parent, not the exact FPGA numerical function.",
                            "No training attack or certified residual training factor demonstrated.",
                            "Fixed-context panels and growing-context continuation are distinct workloads."]}


def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    action = p.add_mutually_exclusive_group(required=True)
    action.add_argument("--plan", action="store_true")
    action.add_argument("--run", action="store_true", help="Explicitly run one case on an already approved H100")
    p.add_argument("--model-dir", type=Path)
    p.add_argument("--output-dir", type=Path)
    p.add_argument("--workload", choices=("fixed", "continuation"), default="continuation")
    p.add_argument("--prompt", choices=("single_token", "raw_story", "raw_geography", "chat_greeting"), default="single_token")
    p.add_argument("--context", type=positive_int, default=128)
    p.add_argument("--batch", type=positive_int, default=1)
    p.add_argument("--dtype", choices=("bfloat16", "float16"), default="bfloat16")
    p.add_argument("--mode", choices=("eager", "graph", "compile-graph"), default="eager")
    p.add_argument("--trials", type=positive_int, default=5)
    p.add_argument("--seconds", type=float, default=3)
    p.add_argument("--warmup", type=positive_int, default=5)
    p.add_argument("--max-runtime", type=positive_int, default=900)
    p.add_argument("--seed", type=int, default=20261022)
    p.add_argument("--profile", action="store_true", help="Retain one eager decode operator/copy/kernel trace")
    p.add_argument("--allow-greedy-rounding", action="store_true",
                   help="Explicit compiled fixed-context FP16 reference: retain all-logit checks and report greedy disagreements")
    a = p.parse_args(argv)
    if not math.isfinite(a.seconds) or not 0 < a.seconds <= 30:
        p.error("--seconds must be finite and in (0,30]")
    if not 1 <= a.context <= 32768 or a.batch > 4096:
        p.error("context/batch outside reviewed bounds")
    if a.workload == "continuation" and a.mode == "compile-graph":
        p.error("Compile selected fixed-context cases only; continuation uses eager/graph")
    if a.allow_greedy_rounding and (a.workload != "fixed" or a.mode != "compile-graph" or a.dtype != "float16"):
        p.error("--allow-greedy-rounding requires --workload fixed --mode compile-graph --dtype float16")
    if a.run and (a.model_dir is None or a.output_dir is None):
        p.error("--run requires --model-dir and a fresh --output-dir")
    return a


def main(argv=None):
    args = parse_args(argv)
    if args.plan:
        print(json.dumps(plan(), indent=2))
        return 0
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ.setdefault("TORCHINDUCTOR_COMPILE_THREADS", "4")
    args.output_dir.mkdir(parents=True, exist_ok=False)
    sources = source_hashes()
    (args.output_dir / "sources").mkdir()
    for name, digest in sources.items():
        raw = (HERE / name).read_bytes()
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError("Source changed while snapshotting: " + name)
        with (args.output_dir / "sources" / name).open("xb") as stream:
            stream.write(raw)
    envelope = {"time_utc": datetime.now(timezone.utc).isoformat(), "argv": sys.argv,
                "pid": os.getpid(), "source_sha256": sources}

    def event(stage):
        record = {"time_utc": datetime.now(timezone.utc).isoformat(), "stage": stage}
        with (args.output_dir / "progress.jsonl").open("a") as stream:
            stream.write(json.dumps(record) + "\n")
        print(json.dumps(record), flush=True)

    try:
        result = run(args, args.output_dir, event)
        code = 0
    except BaseException as error:
        result = {"schema": "qwen17b-h100-case-v1", "status": "failed",
                  "error_type": type(error).__name__, "error": str(error),
                  "validation_record": getattr(error, "record", None)}
        code = 1
    result["execution"] = envelope
    result["execution"]["completed_utc"] = datetime.now(timezone.utc).isoformat()
    if source_hashes() != sources:
        result["status"] = "failed"
        result["source_changed_during_run"] = True
        code = 1
    with (args.output_dir / "result.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "result": str(args.output_dir / "result.json")}), flush=True)
    return code


if __name__ == "__main__":
    raise SystemExit(main())

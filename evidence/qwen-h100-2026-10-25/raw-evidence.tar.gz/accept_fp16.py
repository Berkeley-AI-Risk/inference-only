from pathlib import Path
import subprocess, os, json, time, signal
root=Path('/home/ubuntu/qwen17b-h100-20261025T2351Z')
env=os.environ.copy(); env.update({'CUDA_VISIBLE_DEVICES':'0','PYTHONDONTWRITEBYTECODE':'1','TOKENIZERS_PARALLELISM':'false'})
py=str(root/'.venv/bin/python')
steps=[]
for name, argv, timeout in [
 ('verify_snapshot_fp16',[py,'-B','model_snapshot.py','.model'],120),
 ('accept_eager_fp16',[py,'-B','benchmark.py','--run','--model-dir','.model','--dtype','float16','--workload','fixed','--context','128','--batch','1','--mode','eager','--profile','--seconds','0.3','--trials','3','--max-runtime','300','--output-dir','results/accept-eager-fp16'],600)]:
 print(json.dumps({'stage':name+'_started'}),flush=True)
 began=time.monotonic()
 with (root/'controller-logs-v2'/(name+'-after-config-fix.log')).open('xb') as log:
  p=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try: code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);p.wait();code=-9
 steps.append({'name':name,'exit_code':code,'elapsed_seconds':time.monotonic()-began})
 print(json.dumps(steps[-1]),flush=True)
 if code: break
result={'passed':len(steps)==2 and all(s['exit_code']==0 for s in steps),'steps':steps,'prior_failed_setup_preserved':'SETUP-RESULT-v2.json.initial'}
(root/'ACCEPTANCE-FP16.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['passed'] else 1)

"""Reproduce compiled/eager differences and inspect a higher-precision row."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.environ.update({'CUDA_VISIBLE_DEVICES': '0', 'HF_HUB_OFFLINE': '1',
                   'TRANSFORMERS_OFFLINE': '1', 'TORCHINDUCTOR_COMPILE_THREADS': '4'})
import benchmark as bench
import torch
torch.set_num_threads(8)
torch.set_grad_enabled(False)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
original_comparison = bench.comparison


def diagnostic_comparison(actual, expected, label, strict=True):
    # Diagnostic only: retain all-logit/finiteness checks and explicitly record
    # greedy differences. This does not relabel the original failed benchmark.
    return original_comparison(actual, expected, label, strict=False)


bench.comparison = diagnostic_comparison
model = bench.load_model(ROOT / '.model', 'float16')
ids = bench.make_tapes(512, 128, 20261022)
case = bench.FixedDecode(model, ids)
runner, checks = bench.prepare_runner(case, 'compile-graph')
case.ids[:, 0].add_(7).remainder_(bench.VOCAB)
case.restore_prefix()
eager = bench.snapshot(case())
compiled = bench.snapshot(runner())
torch.cuda.synchronize()
rows = (compiled[1] != eager[1]).nonzero()[:, 0].tolist()
selected_ids = case.ids[rows].clone()
records = []
for row in rows:
    records.append({'row': row, 'eager_token': eager[1][row, 0].item(),
                    'compiled_token': compiled[1][row, 0].item(),
                    'eager_top3': eager[0][row].float().topk(3).values.cpu().tolist(),
                    'eager_top3_ids': eager[0][row].topk(3).indices.cpu().tolist(),
                    'compiled_top3': compiled[0][row].float().topk(3).values.cpu().tolist(),
                    'compiled_top3_ids': compiled[0][row].topk(3).indices.cpu().tolist()})
reference = bench.load_model(ROOT / '.model', 'float32')
if rows:
    logits = reference(input_ids=selected_ids, use_cache=False, logits_to_keep=1).logits[:, -1, :]
    for i, record in enumerate(records):
        record.update({'fp32_token': logits[i].argmax().item(),
                       'fp32_top3': logits[i].topk(3).values.cpu().tolist(),
                       'fp32_top3_ids': logits[i].topk(3).indices.cpu().tolist()})
result = {'diagnostic_only': True, 'original_failed_case_preserved': True,
          'source_sha256': bench.source_hashes(), 'checks': checks,
          'changed_prefix_mismatch_rows': records}
with (ROOT / 'compiled-rounding-diagnostic.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'diagnostic_only': True, 'rows': records}), flush=True)

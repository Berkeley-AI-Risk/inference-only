"""Archive completed experiment evidence, excluding model/venv/cache data."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

p = argparse.ArgumentParser()
p.add_argument('label')
args = p.parse_args()
if not args.label.replace('-', '').isalnum():
    raise SystemExit('Invalid label')
root = Path(__file__).resolve().parent
inventory_name = 'REMOTE-INVENTORY-' + args.label + '.json'
archive = root.parent / ('qwen17b-evidence-' + args.label + '.tar.gz')
if archive.exists() or (root / inventory_name).exists():
    raise SystemExit('Preserve earlier inventory/archive')
files = {}
for folder, dirs, names in os.walk(root):
    dirs[:] = [d for d in dirs if d not in ('.model', '.model-small', '.venv', '__pycache__', '.cache', '.git')]
    for name in names:
        path = Path(folder) / name
        if path.is_symlink():
            raise SystemExit('Unexpected linked evidence file')
        raw = path.read_bytes()
        files[path.relative_to(root).as_posix()] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
gpu = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_memory',
                      '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=20)
inventory = {'time_utc': datetime.now(timezone.utc).isoformat(), 'files': files,
             'gpu_processes_at_backup': {'exit_code': gpu.returncode, 'stdout': gpu.stdout, 'stderr': gpu.stderr},
             'excluded': ['.model', '.model-small', '.venv', '__pycache__', '.cache', '.git'],
             'scope': 'SHA-256 evidence inventory, not a model/driver installation backup.'}
(root / inventory_name).write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
with tarfile.open(archive, 'w:gz') as target:
    for name in sorted(files):
        target.add(root / name, arcname=name, recursive=False)
    target.add(root / inventory_name, arcname=inventory_name, recursive=False)
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                  'payload_files': len(files), 'inventory': inventory_name}), flush=True)

"""Bounded setup and one acceptance case on the user-provided Linux host."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / 'controller-logs'
LOGS.mkdir(exist_ok=True)
ENV = os.environ.copy()
ENV.update({'CUDA_VISIBLE_DEVICES': '0', 'TOKENIZERS_PARALLELISM': 'false',
            'TORCHINDUCTOR_COMPILE_THREADS': '4', 'PYTHONDONTWRITEBYTECODE': '1'})
PY = str(ROOT / '.venv/bin/python')
steps = []


def event(name, **fields):
    value = {'time_utc': datetime.now(timezone.utc).isoformat(), 'stage': name, **fields}
    with (ROOT / 'setup-progress.jsonl').open('a') as stream:
        stream.write(json.dumps(value) + '\n')
    print(json.dumps(value), flush=True)


def run(name, argv, seconds):
    event(name + '_started')
    started = time.monotonic()
    with (LOGS / (name + '.log')).open('xb') as log:
        process = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            raise RuntimeError(name + ' exceeded its hard timeout')
    steps.append({'name': name, 'argv': argv, 'exit_code': code,
                  'elapsed_seconds': time.monotonic() - started})
    event(name + '_finished', exit_code=code)
    if code:
        raise RuntimeError(name + ' failed; retain its log')


try:
    os.chdir(ROOT)
    if (ROOT / '.venv').exists():
        raise RuntimeError('Use a fresh setup directory')
    event('setup_started', source_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                        for p in ROOT.iterdir() if p.is_file()})
    run('venv', [sys.executable, '-m', 'venv', '.venv'], 60)
    run('install_torch', [PY, '-m', 'pip', 'install', '--report', 'torch-install.json',
                         'torch==2.10.0', '--index-url', 'https://download.pytorch.org/whl/cu126'], 1200)
    run('install_requirements', [PY, '-m', 'pip', 'install', '--report', 'requirements-install.json',
                                '-r', 'requirements.txt'], 600)
    run('pip_check', [PY, '-m', 'pip', 'check'], 60)
    run('bookkeeping', [PY, '-I', '-S', '-B', 'test_bookkeeping.py', '-v'], 60)
    run('cpu_runtime', [PY, '-I', '-B', 'test_runtime_cpu.py', '-v'], 120)
    run('model_snapshot', [PY, '-B', 'model_snapshot.py', '.model', '--download'], 1200)
    run('accept_eager', [PY, '-B', 'benchmark.py', '--run', '--model-dir', '.model',
                        '--workload', 'fixed', '--context', '128', '--batch', '1',
                        '--mode', 'eager', '--profile', '--seconds', '0.3', '--trials', '3',
                        '--max-runtime', '300', '--output-dir', 'results/accept-eager'], 600)
    result = {'passed': True, 'steps': steps}
    event('setup_and_acceptance_passed')
except BaseException as error:
    result = {'passed': False, 'steps': steps, 'error_type': type(error).__name__, 'error': str(error)}
    event('setup_or_acceptance_failed', error=str(error))
(ROOT / 'SETUP-RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
raise SystemExit(0 if result['passed'] else 1)

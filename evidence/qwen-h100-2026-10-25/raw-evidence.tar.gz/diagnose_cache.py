"""Compare actual cached/full Qwen forwards across precision; no timing claim."""
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.environ.update({'CUDA_VISIBLE_DEVICES': '0', 'HF_HUB_OFFLINE': '1',
                   'TRANSFORMERS_OFFLINE': '1', 'HF_HUB_DISABLE_IMPLICIT_TOKEN': '1'})
import benchmark as bench
import torch

torch.set_num_threads(8)
torch.set_grad_enabled(False)
torch.backends.cuda.matmul.allow_tf32 = False
torch.backends.cudnn.allow_tf32 = False
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
identity = bench.gpu_identity(torch)
outputs = {}
records = []
for dtype in ('bfloat16', 'float16', 'float32'):
    print(json.dumps({'stage': 'load_' + dtype}), flush=True)
    model = bench.load_model(ROOT / '.model', dtype)
    for seed in (20261023, 20261024):
        ids = bench.make_tapes(2, 128, seed)
        case = bench.FixedDecode(model, ids)
        cached = case()[0].detach().float().cpu()
        full = model(input_ids=ids, use_cache=False, logits_to_keep=1).logits[:, -1, :].detach().float().cpu()
        delta = cached - full
        record = {'dtype': dtype, 'seed': seed, 'max_abs_cached_full': delta.abs().max().item(),
                  'rms_cached_full': delta.square().mean().sqrt().item(),
                  'cached_tokens': cached.argmax(-1).tolist(), 'full_tokens': full.argmax(-1).tolist(),
                  'original_tolerance_passed': bool(torch.allclose(cached, full, rtol=0.005, atol=0.05))}
        if dtype == 'float32':
            record['tight_fp32_tolerance_passed'] = bool(torch.allclose(cached, full, rtol=0.0001, atol=0.0001))
            record['input_mutation_checks'] = bench.validate_inputs(model, dtype, 128, seed)
        outputs[(dtype, seed, 'cached')] = cached
        outputs[(dtype, seed, 'full')] = full
        records.append(record)
        print(json.dumps(record), flush=True)
        del case, ids
    del model
    gc.collect()
    torch.cuda.empty_cache()
comparisons = []
for dtype in ('bfloat16', 'float16'):
    for seed in (20261023, 20261024):
        for mode in ('cached', 'full'):
            x, ref = outputs[(dtype, seed, mode)], outputs[('float32', seed, mode)]
            delta = x - ref
            comparisons.append({'dtype': dtype, 'seed': seed, 'mode': mode,
                                'max_abs_vs_fp32': delta.abs().max().item(),
                                'rms_vs_fp32': delta.square().mean().sqrt().item(),
                                'greedy_mismatches_vs_fp32': int((x.argmax(-1) != ref.argmax(-1)).sum())})
result = {'gpu': identity, 'records': records, 'fp32_comparisons': comparisons,
          'source_sha256': bench.source_hashes(), 'packages': bench.stack_versions()}
target = ROOT / 'cache-precision-diagnostic.json'
with target.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'stage': 'diagnostic_finished', 'result': str(target)}), flush=True)

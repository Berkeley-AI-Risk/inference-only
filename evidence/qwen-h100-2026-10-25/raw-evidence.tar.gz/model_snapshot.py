"""Explicit public-data acquisition, separate from offline benchmark execution.

Implementation-only preparation: no invocation has been qualified yet.
Small data use the publisher Git blob identities; weights use SHA-256.
No credentials, remote model code, pickle files or mutable model revisions.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import urllib.request

REPOSITORY = "Qwen/Qwen3-1.7B"
REVISION = "70d244cc86ccca08cf5af4e1e306ecf908b1ad5e"
FILES = {
    "LICENSE": (11343, "git_blob_sha1", "6634c8cc3133b3848ec74b9f275acaaa1ea618ab"),
    "README.md": (13963, "git_blob_sha1", "88aaef81cfe31bcdfe47203649a69ff12042826a"),
    "config.json": (726, "git_blob_sha1", "044a86ecf7cb32238f3fae4184e55d354787edec"),
    "generation_config.json": (239, "git_blob_sha1", "20a8a9156fc8c3f25295ca067f61fdf120d517c5"),
    "model-00001-of-00002.safetensors": (3441185608, "sha256", "169ad53ec313c3a34b06c0809216e4fc072cce444a5d4ff2b59690d064130ed5"),
    "model-00002-of-00002.safetensors": (622329984, "sha256", "912becff8d60672aa8628ef08c05898d9adf17c2ad4ae3caf99b065622fdeff9"),
    "model.safetensors.index.json": (25605, "git_blob_sha1", "986d7db875b47d21f68530f6baac038f1b297b39"),
}


def digest_file(path, git=False):
    h = hashlib.sha1() if git else hashlib.sha256()
    if git:
        h.update(("blob " + str(path.stat().st_size) + "\0").encode("ascii"))
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def check_file(name, path):
    size, kind, expected = FILES[name]
    if not path.is_file() or path.is_symlink() or path.stat().st_size != size:
        raise ValueError("Missing/wrong-size pinned file: " + name)
    if digest_file(path, git=kind == "git_blob_sha1") != expected:
        raise ValueError("Changed pinned public data: " + name)
    return {"bytes": size, "publisher_identity_kind": kind,
            "publisher_identity": expected, "sha256": digest_file(path)}


def verify(directory):
    directory = Path(directory)
    records = {name: check_file(name, directory / name) for name in FILES}
    config = json.loads((directory / "config.json").read_text())
    required = {"model_type": "qwen3", "hidden_size": 2048,
                "intermediate_size": 6144, "num_hidden_layers": 28,
                "num_attention_heads": 16, "num_key_value_heads": 8,
                "head_dim": 128, "vocab_size": 151936,
                "max_position_embeddings": 40960, "tie_word_embeddings": True}
    if any(config.get(key) != value for key, value in required.items()):
        raise ValueError("Pinned model geometry differs from Qwen3-1.7B")
    return records


def fetch(directory):
    """Only an explicit operator invocation performs these public downloads."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    if directory.is_symlink():
        raise ValueError("Use a real output directory")
    for name, (size, _, _) in FILES.items():
        target = directory / name
        if target.exists() or target.is_symlink():
            check_file(name, target)
            continue
        partial = directory / (name + ".partial")
        # An incomplete old attempt is preserved, not silently resumed/replaced.
        request = urllib.request.Request(
            f"https://huggingface.co/{REPOSITORY}/resolve/{REVISION}/{name}",
            headers={"User-Agent": "fixed-qwen17b-reference/1"})
        with partial.open("xb") as out:
            with urllib.request.urlopen(request, timeout=180) as incoming:
                received = 0
                while True:
                    block = incoming.read(4 * 1024 * 1024)
                    if not block:
                        break
                    received += len(block)
                    if received > size:
                        raise ValueError("Oversized download: " + name)
                    out.write(block)
        check_file(name, partial)
        os.link(partial, target)  # Refuses an intervening writer's target.
        partial.unlink()
        print(json.dumps({"verified": name, "bytes": size}), flush=True)
    return verify(directory)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--download", action="store_true",
                        help="Explicitly acquire approximately 4.1 GB of pinned public model data")
    args = parser.parse_args()
    result = fetch(args.directory) if args.download else verify(args.directory)
    print(json.dumps({"repository": REPOSITORY, "revision": REVISION,
                      "files": result}, indent=2))


if __name__ == "__main__":
    main()

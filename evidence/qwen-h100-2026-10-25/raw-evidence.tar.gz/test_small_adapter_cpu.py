"""Check the Llama cache/mask adapter against independent full forwards."""
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'packet'))
import calibrate_simplestories as calibration
import benchmark as bench
import torch
from transformers import LlamaConfig, LlamaForCausalLM


class SmallAdapterChecks(unittest.TestCase):
    @torch.inference_mode()
    def test_actual_architecture_cached_full_mutations_and_native_heads(self):
        calibration.configure()
        torch.set_num_threads(2)
        torch.manual_seed(20261025)
        config = LlamaConfig(vocab_size=4019, hidden_size=256, intermediate_size=682,
                             num_hidden_layers=6, num_attention_heads=4,
                             num_key_value_heads=2, max_position_embeddings=2048,
                             tie_word_embeddings=True)
        config._attn_implementation = 'sdpa'
        model = LlamaForCausalLM(config).eval()
        self.assertEqual(sum(p.numel() for p in model.parameters()), 5354496)
        for context in (1, 128, 133):
            with self.subTest(context=context):
                checks = bench.validate_inputs(model, 'float32', context, 20261023)
                self.assertTrue(all(x['greedy_mismatch_count'] == 0 for x in checks))
        ids = bench.make_tapes(2, 128, 20261024, device='cpu')
        case = bench.FixedDecode(model, ids)
        full = model(input_ids=ids, use_cache=False, logits_to_keep=1).logits[:, -1, :]
        torch.testing.assert_close(case()[0], full, rtol=0.0001, atol=0.0001)
        cache = bench.PinnedCache(model, 2, 128)
        self.assertEqual(cache.keys[0].shape, (2, 2, 128, 64))
        cache.position = 127
        self.assertEqual(cache.get_mask_sizes(1), (128, 0))
        self.assertEqual(bench.KV_BYTES_PER_POSITION, 3072)


if __name__ == '__main__':
    unittest.main()

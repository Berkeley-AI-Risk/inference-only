"""SmallStories parent calibration using the same cache/timing core as Qwen.

Only model geometry, pinned acquisition, loader and the Llama mask API differ.
No layer, projection, norm, rotary operation, head or argmax is replaced.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import benchmark as bench
import small_model_snapshot as small
import torch
from transformers import LlamaForCausalLM
import transformers.models.llama.modeling_llama as llama_module

BASE_CACHE = bench.PinnedCache
ORIGINAL_MODULE_SOURCES = bench.module_sources
ORIGINAL_MASK_FACTORY = llama_module.create_causal_mask


class LlamaPinnedCache(BASE_CACHE):
    is_compileable = False

    def get_query_offset(self, layer_idx=0):
        return self.position

    def get_mask_sizes(self, query_length, layer_idx=0):
        return self.position + query_length, 0


def owned_prefix_mask(config, inputs_embeds, attention_mask, past_key_values,
                      position_ids, **kwargs):
    # Qwen exposes a native precomputed-mask mapping; Llama has a mask-factory
    # API instead. Only this benchmark-owned cache uses this equivalent path.
    # All returned cache slots are populated and past/current for decode;
    # multi-position prefill supplies its explicit causal 4D mask below.
    if isinstance(past_key_values, LlamaPinnedCache):
        if inputs_embeds.shape[1] > 1 and attention_mask is None:
            raise ValueError('Owned multi-position prefill requires a causal mask')
        return attention_mask
    return ORIGINAL_MASK_FACTORY(config=config, inputs_embeds=inputs_embeds,
                                  attention_mask=attention_mask,
                                  past_key_values=past_key_values,
                                  position_ids=position_ids, **kwargs)


def forward_small(model, cache, ids, position, position_ids):
    cache.position = position
    length = ids.shape[1]
    mask = None
    if length > 1:
        q = torch.arange(position, position + length, device=ids.device)
        k = torch.arange(position + length, device=ids.device)
        mask = (k[None, :] <= q[:, None])[None, None, :, :]
    # Llama's mask factory accepts 4D masks and uses the populated-prefix
    # lengths above to omit the causal mask for a single-token query.
    return model(input_ids=ids, position_ids=position_ids, attention_mask=mask,
                 past_key_values=cache, use_cache=True,
                 logits_to_keep=1).logits[:, -1, :]


def verify_small(directory):
    hashes = small.verify(directory)
    return {name: {'bytes': small.FILES[name][0], 'sha256': digest}
            for name, digest in hashes.items()}


def load_small(directory, dtype):
    model = LlamaForCausalLM.from_pretrained(
        str(directory), local_files_only=True, trust_remote_code=False,
        use_safetensors=True, dtype=getattr(torch, dtype),
        attn_implementation='sdpa').eval().to('cuda')
    model.requires_grad_(False)
    c = model.config
    geometry = (c.hidden_size, c.intermediate_size, c.num_hidden_layers,
                c.num_attention_heads, c.num_key_value_heads,
                getattr(c, 'head_dim', c.hidden_size // c.num_attention_heads), c.vocab_size)
    if geometry != (256, 682, 6, 4, 2, 64, 4019):
        raise ValueError('Wrong SimpleStories model geometry')
    if sum(p.numel() for p in model.parameters()) != 5354496:
        raise ValueError('Wrong SimpleStories unique parameter count')
    if model.lm_head.weight.data_ptr() != model.model.embed_tokens.weight.data_ptr():
        raise ValueError('Expected tied embedding/head storage')
    return model


def module_sources():
    import transformers.models.llama.modeling_llama as module
    result = ORIGINAL_MODULE_SOURCES()
    result.pop('transformers_qwen3', None)
    path = Path(inspect.getfile(module))
    result['transformers_llama'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    return result


def configure():
    values = {'VOCAB': 4019, 'LAYERS': 6, 'WIDTH': 256, 'FFN': 682,
              'Q_HEADS': 4, 'KV_HEADS': 2, 'HEAD': 64,
              'UNIQUE_PARAMETERS': 5354496, 'KV_BYTES_PER_POSITION': 3072}
    for name, value in values.items():
        setattr(bench, name, value)
    bench.REPOSITORY, bench.REVISION = small.REPOSITORY, small.REVISION
    bench._STACK = torch, LlamaForCausalLM
    bench.PinnedCache, bench.forward_at = LlamaPinnedCache, forward_small
    bench.verify, bench.load_model = verify_small, load_small
    bench.module_sources = module_sources
    llama_module.create_causal_mask = owned_prefix_mask


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', type=int, required=True)
    parser.add_argument('--mode', choices=('graph', 'compile-graph'), required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=20261022)
    parser.add_argument('--profile', action='store_true')
    parser.add_argument('--allow-greedy-rounding', action='store_true')
    args = parser.parse_args()
    if args.batch not in (8192, 32768, 57344):
        parser.error('Only the reviewed independent-cache batches8192,32768,57344 are admitted')
    if args.allow_greedy_rounding and args.mode != 'compile-graph':
        parser.error('Rounding reference policy requires an explicit compiled case')
    args.output_dir.mkdir(parents=True, exist_ok=False)
    os.environ.update({'CUDA_VISIBLE_DEVICES': '0', 'HF_HUB_OFFLINE': '1',
                       'TRANSFORMERS_OFFLINE': '1', 'HF_HUB_DISABLE_IMPLICIT_TOKEN': '1',
                       'TORCHINDUCTOR_COMPILE_THREADS': '4'})
    configure()
    args.model_dir = ROOT / '.model-small'
    args.dtype, args.workload, args.context, args.prompt = 'float16', 'fixed', 128, 'unused'
    args.seconds, args.trials, args.warmup, args.max_runtime = 3, 5, 5, 900
    names = (*bench.SOURCE_NAMES, 'calibrate_simplestories.py', 'small_model_snapshot.py')
    sources = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names}
    (args.output_dir / 'sources').mkdir()
    for name in names:
        (args.output_dir / 'sources' / name).write_bytes((ROOT / name).read_bytes())

    def event(stage):
        value = {'time_utc': datetime.now(timezone.utc).isoformat(), 'stage': stage}
        print(json.dumps(value), flush=True)
        with (args.output_dir / 'progress.jsonl').open('a') as stream:
            stream.write(json.dumps(value) + '\n')

    try:
        result = bench.run(args, args.output_dir, event)
        result['calibration'] = {'same_cache_timing_core_as_qwen': True,
                                 'llama_mask_api_adapter': True,
                                 'owned_cache_only_precomputed_mask_path': True,
                                 'uncached_full_forward_uses_original_mask_factory': True,
                                 'all_original_layers_and_head_executed': True,
                                 'old_transformers_reference_version': '4.48.3',
                                 'current_transformers_reference_version': '5.17.0',
                                 'no_bit_exact_old_backend_claim': True}
        code = 0
    except BaseException as error:
        result = {'status': 'failed', 'error_type': type(error).__name__, 'error': str(error),
                  'validation_record': getattr(error, 'record', None)}
        code = 1
    result['execution'] = {'argv': sys.argv, 'source_sha256': sources,
                           'completed_utc': datetime.now(timezone.utc).isoformat()}
    if any(hashlib.sha256((ROOT / n).read_bytes()).hexdigest() != digest for n, digest in sources.items()):
        result['status'], result['source_changed_during_run'], code = 'failed', True, 1
    (args.output_dir / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status']}), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())

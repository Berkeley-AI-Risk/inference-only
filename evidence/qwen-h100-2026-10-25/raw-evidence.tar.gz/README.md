# Qwen3 1.7B H100 reference experiment

This private benchmark preparation measures the pinned BF16 parent of the released 100 MHz Qwen3-1.7B FPGA circuit. It supplies the missing inference-reference rate for conditional residual training analysis. It does not measure training access. CPU cache/trajectory checks and standard-library bookkeeping pass; CUDA graphs, compilation, the full checkpoint on H100 and GPU performance remain unqualified.

The primary continuation uses one input token, `[9707]`, and 128 feedback-dependent outputs, matching the headline workload geometry of the other demonstrations. Its 127 cached intervals have input contexts 2 through 128. A matching 128-output FPGA run is still pending; the benchmark records its parent outputs without claiming FPGA agreement. The three previously released prompts remain additional checks.

The upstream model is not the FPGA's exact quantized numerical function. Retain that distinction in every reported ratio. Read `SPEC.json` for workload and timing details and `ASSESSMENT.json` for the earlier source assessment. The public-release documentation is `../fpga-demo/public-release/demos/qwen3-1.7b/TRAINING-CAPACITY.md` and `../fpga-demo/public-release/RESIDUAL-TRAINING-METHODOLOGY.md`.

## Hardware and rental

Use one full **H100 SXM 80 GB**, with MIG disabled and no competing process on that GPU. The guard requires 132 SMs and compute capability 9.0 and records clocks/power. Expose only that GPU with `CUDA_VISIBLE_DEVICES=0`. A GPU with another form factor or configuration needs a separately labeled benchmark and normalization convention.

[AWS P5](https://aws.amazon.com/ec2/instance-types/p5/) lists `p5.4xlarge` with one H100 and 80 GB HBM3; check the actual GPU against the guard and check region, quota, availability and rate before launch. [Lambda](https://lambda.ai/instances) also lists a one-GPU H100 SXM 80 GB instance. Its advertised one-GPU rate checked October 25, 2026 is $4.29/GPU-hour before tax; the $3.99 figure applies to its eight-GPU size. AWS pricing must be checked for the chosen region and purchasing option.

Plan a bounded initial 2–4 hour engineering session for installation, acceptance and selected measurements; this is a planning allowance, not a runtime guarantee. If acceptance fails, preserve the failure and stop the sweep for repair. The operator controls the billing deadline. These tools do not rent, stop or terminate instances, upload the repository or publish results.

## Prepare the environment

Copy only this benchmark directory, excluding caches, environments and results. The checkpoint is public. No private repository, AWS credentials or SSH private key is needed by the benchmark.

On the approved Linux H100 host, in this directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install torch==2.10.0 --index-url https://download.pytorch.org/whl/cu126
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -B test_bookkeeping.py -v
.venv/bin/python -B test_runtime_cpu.py -v
.venv/bin/python -B benchmark.py --plan
.venv/bin/python -B model_snapshot.py .model --download
```

Retain pip's resolved package list, downloaded wheel identities, Python/OS/driver versions and setup logs. The existing local CPU environment has the exact requested package versions, including Transformers 5.17.0 and torch 2.10.0; this does not qualify the Linux CUDA wheel/driver combination. Model acquisition checks pinned Git/LFS identities. Benchmark execution verifies the local files again and disables model networking and remote code.

When the release measurements are available locally, also run:

```sh
.venv/bin/python -B test_bookkeeping.py --release-measurements ../fpga-demo/public-release/demos/qwen3-1.7b/measurements.json -v
```

That optional check binds all three prompts, their 384 saved output IDs and copied rates to the released evidence. It can be performed before copying the benchmark to the GPU host.

## Run staged cases

Begin with a small fixed-context eager acceptance case and profiler, using a fresh output directory for each invocation. The external timeout bounds a hung import/kernel/compile as well as normal stages; `--max-runtime` alone checks only between stages. Linux `timeout` is from GNU coreutils.

```sh
timeout --signal=TERM --kill-after=30s 20m env CUDA_VISIBLE_DEVICES=0 \
  .venv/bin/python -B benchmark.py --run --model-dir .model \
  --workload fixed --context 128 --batch 1 --mode eager --profile \
  --seconds 0.3 --trials 3 --max-runtime 300 --output-dir results/accept-eager
```

After that passes, run the primary one-token geometry, first eager and then graph mode. These calls generate 128 outputs with true feedback and time the 127 cached intervals separately from first-output/full-generation timing.

```sh
timeout --signal=TERM --kill-after=30s 20m env CUDA_VISIBLE_DEVICES=0 \
  .venv/bin/python -B benchmark.py --run --model-dir .model \
  --workload continuation --prompt single_token --batch 1 --mode eager \
  --output-dir results/single-token-eager
timeout --signal=TERM --kill-after=30s 20m env CUDA_VISIBLE_DEVICES=0 \
  .venv/bin/python -B benchmark.py --run --model-dir .model \
  --workload continuation --prompt single_token --batch 1 --mode graph \
  --output-dir results/single-token-graph
```

Repeat for the three additional prompts `raw_story`, `raw_geography` and `chat_greeting`. Repeat the primary one-token case in a fresh process with a second seed, as well as retaining the five timing trials. GPU-parent versus FPGA token disagreements are reported numerical-model differences. Optimized versus same-dtype eager disagreements fail acceptance; there is no silent near-tie waiver.

Then select aggregate continuation and fixed-context graph batches from 1, 8, 32, 128, 512 and 2,048. The 4,096 candidate is rejected at context 128 by the current 40 GiB K/V admission limit. Profile a representative aggregate fixed decode and inspect attention kernels, GQA and copy traffic. The plan lists memory-admitted geometry; actual free-memory/headroom admission is checked again at runtime.

Compile only selected **fixed-context** cases with `--mode compile-graph` after eager/graph checks pass. Do not compile the 127-step continuation as one unrolled program. After the context-128 sweep, investigate 512, 2,048 and 8,192 separately with smaller admitted batches. Fixed-context repeated evaluations and growing-context generation must keep separate rates.

Repeat selected best cases in fresh processes with another `--seed`, retaining all five timing repetitions. A throughput plateau is an achieved implementation result, not a proved hardware ceiling. If memory or this backend limits the sweep before a plateau, report that limitation and consider an independently validated alternative backend.

## Evidence and interpretation

Each case keeps source snapshots and hashes, model identities, GPU qualification before/after, checks, individual timing samples and `result.json`; `--profile` additionally writes a Chrome trace. If a hard timeout prevents final JSON, preserve the partial directory and controller log as a failed/incomplete case. Never overwrite it or relabel it successful.

The CPU tests include the one-token/128-output trajectory and use a tiny random Qwen3 model with the same cache adapter and real pinned Transformers implementation. They compare cached and full forwards at contexts 1, 7 and 133, then all 128 feedback-dependent outputs against independent uncached forwards. They check replay and changed prefixes. This does not exercise pretrained full-size numerical behavior, CUDA graph capture, compilation or GPU performance.

The original October 22 review is historical evidence for the old source hashes. The October 25 changes use the model's device for cache buffers so the adapter can be checked on CPU, and check both K and V prefix stability. The actual benchmark still requires and qualifies an H100. Record new hashes for every GPU run.

Use host-wall medians for the reported achieved rate; retain CUDA event spans and the full sample spread. Timing includes layers, final norm/head and argmax, host launches and synchronization. Prefix construction, compilation, warmup, CPU token copying, text decoding and networking are excluded from cached timing. First-output/full-generation panels are separate. The FPGA timings include command/communication overhead.

Back up JSON, source snapshots, traces and logs, verify copied hashes and confirm the durable copy before releasing the rental. A GPU inference benchmark alone does not establish a certified residual training factor.

"""Acquire the pinned tiny parent and run a bounded calibration on GPU0."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path(__file__).resolve().parent
logs = root / 'controller-logs/small-calibration'
logs.mkdir(parents=True, exist_ok=False)
py = str(root / '.venv/bin/python')
env = os.environ.copy()
env.update({'CUDA_VISIBLE_DEVICES': '0', 'TOKENIZERS_PARALLELISM': 'false',
            'PYTHONDONTWRITEBYTECODE': '1', 'TORCHINDUCTOR_COMPILE_THREADS': '4'})
jobs = [('small-acquisition', [py, '-B', 'small_model_snapshot.py', '.model-small'], 180, None),
        ('small-cpu-check', [py, '-I', '-B', 'test_small_adapter_cpu.py', '-v'], 60, None)]
for batch, mode, profile in [(8192, 'graph', True), (32768, 'graph', False), (32768, 'compile-graph', False)]:
    name = f'small-ctx128-b{batch}-{mode}-fp16'
    argv = [py, '-B', 'calibrate_simplestories.py', '--batch', str(batch), '--mode', mode,
            '--output-dir', 'results/' + name]
    if profile:
        argv += ['--profile']
    if mode == 'compile-graph':
        argv += ['--allow-greedy-rounding']
    jobs.append((name, argv, 1200 if mode == 'compile-graph' else 600, root / 'results' / name / 'result.json'))
records = []
for name, argv, timeout, result_file in jobs:
    print(json.dumps({'time_utc': datetime.now(timezone.utc).isoformat(), 'stage': 'started', 'name': name}), flush=True)
    started = time.monotonic()
    with (logs / (name + '.log')).open('xb') as log:
        p = subprocess.Popen(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
            code = -9
    result = json.loads(result_file.read_text()) if result_file and result_file.exists() else {}
    record = {'name': name, 'exit_code': code, 'elapsed_seconds': time.monotonic() - started,
              'status': result.get('status'), 'error': result.get('error'),
              'aggregate_tps': result.get('timing', {}).get('aggregate_tokens_per_second')}
    records.append(record)
    (logs / 'summary.json').write_text(json.dumps({'jobs': records}, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if code:
        raise SystemExit(1)

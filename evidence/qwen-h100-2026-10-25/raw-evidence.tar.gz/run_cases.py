"""Sequential fresh-process benchmark cases with hard process-group timeouts."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('case_file', type=Path)
args = parser.parse_args()
ROOT = Path(__file__).resolve().parent
config = json.loads(args.case_file.read_text())
label = config['label']
if not label.replace('-', '').isalnum():
    raise SystemExit('Invalid run label')
if not json.loads((ROOT / 'ACCEPTANCE-FP16.json').read_text())['passed']:
    raise SystemExit('Full-checkpoint eager acceptance must pass first')
directory = ROOT / 'controller-logs' / label
directory.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env.update({'CUDA_VISIBLE_DEVICES': '0', 'TORCHINDUCTOR_COMPILE_THREADS': '4',
            'TOKENIZERS_PARALLELISM': 'false', 'PYTHONDONTWRITEBYTECODE': '1'})
records = []
started = time.monotonic()


def emit(stage, **fields):
    event = {'time_utc': datetime.now(timezone.utc).isoformat(), 'stage': stage, **fields}
    print(json.dumps(event), flush=True)
    with (directory / 'progress.jsonl').open('a') as stream:
        stream.write(json.dumps(event) + '\n')


for case in config['cases']:
    name = case['name']
    if not name.replace('-', '').isalnum():
        raise SystemExit('Invalid case name')
    if time.monotonic() - started > config.get('max_wall_seconds', 1800):
        emit('wall_budget_exhausted')
        break
    output = ROOT / 'results' / name
    if output.exists():
        raise SystemExit('Preserve existing result: ' + name)
    argv = [str(ROOT / '.venv/bin/python'), '-B', str(ROOT / 'benchmark.py'),
            '--run', '--model-dir', str(ROOT / '.model'), '--output-dir', str(output),
            *case['args']]
    emit('case_started', name=name)
    began = time.monotonic()
    timed_out = False
    with (directory / (name + '.log')).open('xb') as log:
        process = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=case.get('hard_timeout_seconds', 600))
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code = process.returncode
    result_file = output / 'result.json'
    result = json.loads(result_file.read_text()) if result_file.exists() else None
    record = {'name': name, 'argv': argv, 'exit_code': code, 'hard_timeout': timed_out,
              'elapsed_seconds': time.monotonic() - began,
              'status': result.get('status') if result else 'incomplete',
              'aggregate_tps': result.get('timing', {}).get('aggregate_tokens_per_second') if result else None,
              'error': result.get('error') if result else None}
    records.append(record)
    (directory / 'summary.json').write_text(json.dumps({
        'case_file_sha256': hashlib.sha256(args.case_file.read_bytes()).hexdigest(),
        'cases': records}, indent=2) + '\n')
    emit('case_finished', **record)
    if code or record['status'] != 'pass':
        if case.get('continue_after_failure', False):
            emit('failure_retained_continuing_independent_cases', name=name)
            continue
        emit('stopped_after_failure')
        raise SystemExit(1)
failed = sum(record['status'] != 'pass' or record['exit_code'] != 0 for record in records)
emit('all_selected_cases_completed', completed=len(records), failed=failed)
raise SystemExit(1 if failed else 0)

"""Last independent repeat/context checks and final local preparation tests."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path(__file__).resolve().parent
logs = root / 'controller-logs/final-misc'
logs.mkdir(parents=True, exist_ok=False)
py = str(root / '.venv/bin/python')
env = os.environ.copy()
env.update({'CUDA_VISIBLE_DEVICES': '0', 'PYTHONDONTWRITEBYTECODE': '1',
            'TOKENIZERS_PARALLELISM': 'false', 'TORCHINDUCTOR_COMPILE_THREADS': '4'})
jobs = [
    ('small-repeat', [py, '-B', 'calibrate_simplestories.py', '--batch', '32768',
                      '--mode', 'compile-graph', '--seed', '20261026', '--allow-greedy-rounding',
                      '--output-dir', 'results/small-ctx128-b32768-compiled-fp16-repeat'], 1200),
    ('context-panels', [py, '-u', 'run_cases.py', str(root / 'context-panels.json')], 2400),
    ('final-bookkeeping', [py, '-I', '-S', '-B', 'test_bookkeeping.py', '-v'], 60),
    ('final-cpu', [py, '-I', '-B', 'test_runtime_cpu.py', '-v'], 120),
]
records = []
for name, argv, timeout in jobs:
    print(json.dumps({'time_utc': datetime.now(timezone.utc).isoformat(), 'stage': 'started', 'name': name}), flush=True)
    started = time.monotonic()
    with (logs / (name + '.log')).open('xb') as log:
        p = subprocess.Popen(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
            code = -9
    record = {'name': name, 'exit_code': code, 'elapsed_seconds': time.monotonic() - started}
    records.append(record)
    (logs / 'summary.json').write_text(json.dumps({'jobs': records}, indent=2) + '\n')
    print(json.dumps(record), flush=True)
raise SystemExit(1 if any(r['exit_code'] for r in records) else 0)
